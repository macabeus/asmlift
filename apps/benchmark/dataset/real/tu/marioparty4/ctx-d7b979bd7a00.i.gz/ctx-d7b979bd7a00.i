#pragma simple_prepdump on
#pragma msg_show_realref off

#pragma cplusplus off
typedef signed char s8;
typedef signed short int s16;
typedef signed long s32;
typedef signed long long int s64;
typedef unsigned char u8;
typedef unsigned short int u16;
typedef unsigned long u32;
typedef unsigned long long int u64;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef struct
{
u32 _pad0 :2;
u32 loadScale :6;
u32 _pad1 :5;
u32 loadType :3;
u32 _pad2 :2;
u32 storeScale :6;
u32 _pad3 :5;
u32 storeType :3;
} PPC_GQR_t;
typedef union
{
u32 val;
PPC_GQR_t f;
} PPC_GQR_u;
typedef struct
{
u32 memAddr :27;
u32 dmaLenU :5;
} PPC_DMA_U_t;
typedef union
{
u32 val;
PPC_DMA_U_t f;
} PPC_DMA_U_u;
typedef struct
{
u32 lcAddr :27;
u32 dmaLd :1;
u32 dmaLenL :2;
u32 dmaTrigger :1;
u32 dmaFlush :1;
} PPC_DMA_L_t;
typedef union
{
u32 val;
PPC_DMA_L_t f;
} PPC_DMA_L_u;
u32 PPCMfmsr();
void PPCMtmsr(u32 newMSR);
u32 PPCOrMsr(u32 value);
u32 PPCMfhid0();
void PPCMthid0(u32 newHID0);
u32 PPCMfl2cr();
void PPCMtl2cr(u32 newL2cr);
void PPCMtdec(u32 newDec);
void PPCSync();
void PPCHalt();
u32 PPCMffpscr();
void PPCMtfpscr(u32 newFPSCR);
u32 PPCMfhid2();
void PPCMthid2(u32 newhid2);
u32 PPCMfwpar();
void PPCMtwpar(u32 newwpar);
void PPCEnableSpeculation();
void PPCDisableSpeculation();
void PPCSetFpIEEEMode();
void PPCSetFpNonIEEEMode();
typedef struct DBInterface
{
u32 bPresent;
u32 exceptionMask;
void (*ExceptionDestination) ( void );
void *exceptionReturn;
} DBInterface;
extern DBInterface* __DBInterface;
void DBInit(void);
void DBInitComm(int* inputFlagPtr, int* mtrCallback);
static void __DBExceptionDestination(void);
void DBPrintf(char* format, ...);
typedef u8 GXBool;
typedef enum _GXProjectionType {
GX_PERSPECTIVE,
GX_ORTHOGRAPHIC
} GXProjectionType;
typedef enum _GXCompare {
GX_NEVER,
GX_LESS,
GX_EQUAL,
GX_LEQUAL,
GX_GREATER,
GX_NEQUAL,
GX_GEQUAL,
GX_ALWAYS
} GXCompare;
typedef enum _GXAlphaOp {
GX_AOP_AND,
GX_AOP_OR,
GX_AOP_XOR,
GX_AOP_XNOR,
GX_MAX_ALPHAOP
} GXAlphaOp;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR,
GX_ZC_NEAR,
GX_ZC_MID,
GX_ZC_FAR
} GXZFmt16;
typedef enum _GXGamma {
GX_GM_1_0,
GX_GM_1_7,
GX_GM_2_2
} GXGamma;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24,
GX_PF_RGBA6_Z24,
GX_PF_RGB565_Z16,
GX_PF_Z24,
GX_PF_Y8,
GX_PF_U8,
GX_PF_V8,
GX_PF_YUV420
} GXPixelFmt;
typedef enum _GXPrimitive {
GX_QUADS = 0x80,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xA0,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_POINTS = 0xB8
} GXPrimitive;
typedef enum _GXVtxFmt {
GX_VTXFMT0,
GX_VTXFMT1,
GX_VTXFMT2,
GX_VTXFMT3,
GX_VTXFMT4,
GX_VTXFMT5,
GX_VTXFMT6,
GX_VTXFMT7,
GX_MAX_VTXFMT
} GXVtxFmt;
typedef enum _GXAttr {
GX_VA_PNMTXIDX,
GX_VA_TEX0MTXIDX,
GX_VA_TEX1MTXIDX,
GX_VA_TEX2MTXIDX,
GX_VA_TEX3MTXIDX,
GX_VA_TEX4MTXIDX,
GX_VA_TEX5MTXIDX,
GX_VA_TEX6MTXIDX,
GX_VA_TEX7MTXIDX,
GX_VA_POS,
GX_VA_NRM,
GX_VA_CLR0,
GX_VA_CLR1,
GX_VA_TEX0,
GX_VA_TEX1,
GX_VA_TEX2,
GX_VA_TEX3,
GX_VA_TEX4,
GX_VA_TEX5,
GX_VA_TEX6,
GX_VA_TEX7,
GX_POS_MTX_ARRAY,
GX_NRM_MTX_ARRAY,
GX_TEX_MTX_ARRAY,
GX_LIGHT_ARRAY,
GX_VA_NBT,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF
} GXAttr;
typedef enum _GXAttrType {
GX_NONE,
GX_DIRECT,
GX_INDEX8,
GX_INDEX16
} GXAttrType;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_CTF_R4 = 0x0 | 0x20 ,
GX_CTF_RA4 = 0x2 | 0x20 ,
GX_CTF_RA8 = 0x3 | 0x20 ,
GX_CTF_YUVA8 = 0x6 | 0x20 ,
GX_CTF_A8 = 0x7 | 0x20 ,
GX_CTF_R8 = 0x8 | 0x20 ,
GX_CTF_G8 = 0x9 | 0x20 ,
GX_CTF_B8 = 0xA | 0x20 ,
GX_CTF_RG8 = 0xB | 0x20 ,
GX_CTF_GB8 = 0xC | 0x20 ,
GX_TF_Z8 = 0x1 | 0x10 ,
GX_TF_Z16 = 0x3 | 0x10 ,
GX_TF_Z24X8 = 0x6 | 0x10 ,
GX_CTF_Z4 = 0x0 | 0x10 | 0x20 ,
GX_CTF_Z8M = 0x9 | 0x10 | 0x20 ,
GX_CTF_Z8L = 0xA | 0x10 | 0x20 ,
GX_CTF_Z16L = 0xC | 0x10 | 0x20 ,
GX_TF_A8 = GX_CTF_A8
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xa
} GXCITexFmt;
typedef enum _GXTexWrapMode {
GX_CLAMP,
GX_REPEAT,
GX_MIRROR,
GX_MAX_TEXWRAPMODE
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR,
GX_LINEAR,
GX_NEAR_MIP_NEAR,
GX_LIN_MIP_NEAR,
GX_NEAR_MIP_LIN,
GX_LIN_MIP_LIN
} GXTexFilter;
typedef enum _GXAnisotropy {
GX_ANISO_1,
GX_ANISO_2,
GX_ANISO_4,
GX_MAX_ANISOTROPY
} GXAnisotropy;
typedef enum _GXTexMapID {
GX_TEXMAP0,
GX_TEXMAP1,
GX_TEXMAP2,
GX_TEXMAP3,
GX_TEXMAP4,
GX_TEXMAP5,
GX_TEXMAP6,
GX_TEXMAP7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100
} GXTexMapID;
typedef enum _GXTexCoordID {
GX_TEXCOORD0,
GX_TEXCOORD1,
GX_TEXCOORD2,
GX_TEXCOORD3,
GX_TEXCOORD4,
GX_TEXCOORD5,
GX_TEXCOORD6,
GX_TEXCOORD7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF
} GXTexCoordID;
typedef enum _GXTevStageID {
GX_TEVSTAGE0,
GX_TEVSTAGE1,
GX_TEVSTAGE2,
GX_TEVSTAGE3,
GX_TEVSTAGE4,
GX_TEVSTAGE5,
GX_TEVSTAGE6,
GX_TEVSTAGE7,
GX_TEVSTAGE8,
GX_TEVSTAGE9,
GX_TEVSTAGE10,
GX_TEVSTAGE11,
GX_TEVSTAGE12,
GX_TEVSTAGE13,
GX_TEVSTAGE14,
GX_TEVSTAGE15,
GX_MAX_TEVSTAGE
} GXTevStageID;
typedef enum _GXTevMode {
GX_MODULATE,
GX_DECAL,
GX_BLEND,
GX_REPLACE,
GX_PASSCLR
} GXTevMode;
typedef enum _GXTexMtxType {
GX_MTX3x4,
GX_MTX2x4
} GXTexMtxType;
typedef enum _GXTexGenType {
GX_TG_MTX3x4,
GX_TG_MTX2x4,
GX_TG_BUMP0,
GX_TG_BUMP1,
GX_TG_BUMP2,
GX_TG_BUMP3,
GX_TG_BUMP4,
GX_TG_BUMP5,
GX_TG_BUMP6,
GX_TG_BUMP7,
GX_TG_SRTG
} GXTexGenType;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 0,
GX_PNMTX1 = 3,
GX_PNMTX2 = 6,
GX_PNMTX3 = 9,
GX_PNMTX4 = 12,
GX_PNMTX5 = 15,
GX_PNMTX6 = 18,
GX_PNMTX7 = 21,
GX_PNMTX8 = 24,
GX_PNMTX9 = 27
} GXPosNrmMtx;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30,
GX_TEXMTX1 = 33,
GX_TEXMTX2 = 36,
GX_TEXMTX3 = 39,
GX_TEXMTX4 = 42,
GX_TEXMTX5 = 45,
GX_TEXMTX6 = 48,
GX_TEXMTX7 = 51,
GX_TEXMTX8 = 54,
GX_TEXMTX9 = 57,
GX_IDENTITY = 60
} GXTexMtx;
typedef enum _GXChannelID {
GX_COLOR0,
GX_COLOR1,
GX_ALPHA0,
GX_ALPHA1,
GX_COLOR0A0,
GX_COLOR1A1,
GX_COLOR_ZERO,
GX_ALPHA_BUMP,
GX_ALPHA_BUMPN,
GX_COLOR_NULL = 0xFF
} GXChannelID;
typedef enum _GXTexGenSrc {
GX_TG_POS,
GX_TG_NRM,
GX_TG_BINRM,
GX_TG_TANGENT,
GX_TG_TEX0,
GX_TG_TEX1,
GX_TG_TEX2,
GX_TG_TEX3,
GX_TG_TEX4,
GX_TG_TEX5,
GX_TG_TEX6,
GX_TG_TEX7,
GX_TG_TEXCOORD0,
GX_TG_TEXCOORD1,
GX_TG_TEXCOORD2,
GX_TG_TEXCOORD3,
GX_TG_TEXCOORD4,
GX_TG_TEXCOORD5,
GX_TG_TEXCOORD6,
GX_TG_COLOR0,
GX_TG_COLOR1,
GX_MAX_TEXGENSRC
} GXTexGenSrc;
typedef enum _GXBlendMode {
GX_BM_NONE,
GX_BM_BLEND,
GX_BM_LOGIC,
GX_BM_SUBTRACT,
GX_MAX_BLENDMODE
} GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO,
GX_BL_ONE,
GX_BL_SRCCLR,
GX_BL_INVSRCCLR,
GX_BL_SRCALPHA,
GX_BL_INVSRCALPHA,
GX_BL_DSTALPHA,
GX_BL_INVDSTALPHA,
GX_BL_DSTCLR = GX_BL_SRCCLR,
GX_BL_INVDSTCLR = GX_BL_INVSRCCLR
} GXBlendFactor;
typedef enum _GXLogicOp {
GX_LO_CLEAR,
GX_LO_AND,
GX_LO_REVAND,
GX_LO_COPY,
GX_LO_INVAND,
GX_LO_NOOP,
GX_LO_XOR,
GX_LO_OR,
GX_LO_NOR,
GX_LO_EQUIV,
GX_LO_INV,
GX_LO_REVOR,
GX_LO_INVCOPY,
GX_LO_INVOR,
GX_LO_NAND,
GX_LO_SET
} GXLogicOp;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5
} GXCompType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64,
GX_PTTEXMTX1 = 67,
GX_PTTEXMTX2 = 70,
GX_PTTEXMTX3 = 73,
GX_PTTEXMTX4 = 76,
GX_PTTEXMTX5 = 79,
GX_PTTEXMTX6 = 82,
GX_PTTEXMTX7 = 85,
GX_PTTEXMTX8 = 88,
GX_PTTEXMTX9 = 91,
GX_PTTEXMTX10 = 94,
GX_PTTEXMTX11 = 97,
GX_PTTEXMTX12 = 100,
GX_PTTEXMTX13 = 103,
GX_PTTEXMTX14 = 106,
GX_PTTEXMTX15 = 109,
GX_PTTEXMTX16 = 112,
GX_PTTEXMTX17 = 115,
GX_PTTEXMTX18 = 118,
GX_PTTEXMTX19 = 121,
GX_PTIDENTITY = 125
} GXPTTexMtx;
typedef enum _GXTevRegID {
GX_TEVPREV,
GX_TEVREG0,
GX_TEVREG1,
GX_TEVREG2,
GX_MAX_TEVREG
} GXTevRegID;
typedef enum _GXDiffuseFn {
GX_DF_NONE,
GX_DF_SIGN,
GX_DF_CLAMP
} GXDiffuseFn;
typedef enum _GXColorSrc {
GX_SRC_REG,
GX_SRC_VTX
} GXColorSrc;
typedef enum _GXAttnFn {
GX_AF_SPEC,
GX_AF_SPOT,
GX_AF_NONE
} GXAttnFn;
typedef enum _GXLightID {
GX_LIGHT0 = 0x001,
GX_LIGHT1 = 0x002,
GX_LIGHT2 = 0x004,
GX_LIGHT3 = 0x008,
GX_LIGHT4 = 0x010,
GX_LIGHT5 = 0x020,
GX_LIGHT6 = 0x040,
GX_LIGHT7 = 0x080,
GX_MAX_LIGHT = 0x100,
GX_LIGHT_NULL = 0
} GXLightID;
typedef enum _GXTexOffset {
GX_TO_ZERO,
GX_TO_SIXTEENTH,
GX_TO_EIGHTH,
GX_TO_FOURTH,
GX_TO_HALF,
GX_TO_ONE,
GX_MAX_TEXOFFSET
} GXTexOffset;
typedef enum _GXSpotFn {
GX_SP_OFF,
GX_SP_FLAT,
GX_SP_COS,
GX_SP_COS2,
GX_SP_SHARP,
GX_SP_RING1,
GX_SP_RING2
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF,
GX_DA_GENTLE,
GX_DA_MEDIUM,
GX_DA_STEEP
} GXDistAttnFn;
typedef enum _GXCullMode {
GX_CULL_NONE,
GX_CULL_FRONT,
GX_CULL_BACK,
GX_CULL_ALL
} GXCullMode;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1,
GX_TEV_SWAP2,
GX_TEV_SWAP3,
GX_MAX_TEVSWAP
} GXTevSwapSel;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN,
GX_CH_BLUE,
GX_CH_ALPHA
} GXTevColorChan;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_PERSP_LIN = 2,
GX_FOG_PERSP_EXP = 4,
GX_FOG_PERSP_EXP2 = 5,
GX_FOG_PERSP_REVEXP = 6,
GX_FOG_PERSP_REVEXP2 = 7,
GX_FOG_ORTHO_LIN = 10,
GX_FOG_ORTHO_EXP = 12,
GX_FOG_ORTHO_EXP2 = 13,
GX_FOG_ORTHO_REVEXP = 14,
GX_FOG_ORTHO_REVEXP2 = 15,
GX_FOG_LIN = GX_FOG_PERSP_LIN,
GX_FOG_EXP = GX_FOG_PERSP_EXP,
GX_FOG_EXP2 = GX_FOG_PERSP_EXP2,
GX_FOG_REVEXP = GX_FOG_PERSP_REVEXP,
GX_FOG_REVEXP2 = GX_FOG_PERSP_REVEXP2
} GXFogType;
typedef enum _GXTevColorArg {
GX_CC_CPREV,
GX_CC_APREV,
GX_CC_C0,
GX_CC_A0,
GX_CC_C1,
GX_CC_A1,
GX_CC_C2,
GX_CC_A2,
GX_CC_TEXC,
GX_CC_TEXA,
GX_CC_RASC,
GX_CC_RASA,
GX_CC_ONE,
GX_CC_HALF,
GX_CC_KONST,
GX_CC_ZERO
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV,
GX_CA_A0,
GX_CA_A1,
GX_CA_A2,
GX_CA_TEXA,
GX_CA_RASA,
GX_CA_KONST,
GX_CA_ZERO
} GXTevAlphaArg;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ
} GXTevOp;
typedef enum _GXTevBias {
GX_TB_ZERO,
GX_TB_ADDHALF,
GX_TB_SUBHALF,
GX_MAX_TEVBIAS
} GXTevBias;
typedef enum _GXTevScale {
GX_CS_SCALE_1,
GX_CS_SCALE_2,
GX_CS_SCALE_4,
GX_CS_DIVIDE_2,
GX_MAX_TEVSCALE
} GXTevScale;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_8_8 = 0x00,
GX_TEV_KCSEL_7_8 = 0x01,
GX_TEV_KCSEL_6_8 = 0x02,
GX_TEV_KCSEL_5_8 = 0x03,
GX_TEV_KCSEL_4_8 = 0x04,
GX_TEV_KCSEL_3_8 = 0x05,
GX_TEV_KCSEL_2_8 = 0x06,
GX_TEV_KCSEL_1_8 = 0x07,
GX_TEV_KCSEL_1 = GX_TEV_KCSEL_8_8,
GX_TEV_KCSEL_3_4 = GX_TEV_KCSEL_6_8,
GX_TEV_KCSEL_1_2 = GX_TEV_KCSEL_4_8,
GX_TEV_KCSEL_1_4 = GX_TEV_KCSEL_2_8,
GX_TEV_KCSEL_K0 = 0x0C,
GX_TEV_KCSEL_K1 = 0x0D,
GX_TEV_KCSEL_K2 = 0x0E,
GX_TEV_KCSEL_K3 = 0x0F,
GX_TEV_KCSEL_K0_R = 0x10,
GX_TEV_KCSEL_K1_R = 0x11,
GX_TEV_KCSEL_K2_R = 0x12,
GX_TEV_KCSEL_K3_R = 0x13,
GX_TEV_KCSEL_K0_G = 0x14,
GX_TEV_KCSEL_K1_G = 0x15,
GX_TEV_KCSEL_K2_G = 0x16,
GX_TEV_KCSEL_K3_G = 0x17,
GX_TEV_KCSEL_K0_B = 0x18,
GX_TEV_KCSEL_K1_B = 0x19,
GX_TEV_KCSEL_K2_B = 0x1A,
GX_TEV_KCSEL_K3_B = 0x1B,
GX_TEV_KCSEL_K0_A = 0x1C,
GX_TEV_KCSEL_K1_A = 0x1D,
GX_TEV_KCSEL_K2_A = 0x1E,
GX_TEV_KCSEL_K3_A = 0x1F
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_8_8 = 0x00,
GX_TEV_KASEL_7_8 = 0x01,
GX_TEV_KASEL_6_8 = 0x02,
GX_TEV_KASEL_5_8 = 0x03,
GX_TEV_KASEL_4_8 = 0x04,
GX_TEV_KASEL_3_8 = 0x05,
GX_TEV_KASEL_2_8 = 0x06,
GX_TEV_KASEL_1_8 = 0x07,
GX_TEV_KASEL_1 = GX_TEV_KASEL_8_8,
GX_TEV_KASEL_3_4 = GX_TEV_KASEL_6_8,
GX_TEV_KASEL_1_2 = GX_TEV_KASEL_4_8,
GX_TEV_KASEL_1_4 = GX_TEV_KASEL_2_8,
GX_TEV_KASEL_K0_R = 0x10,
GX_TEV_KASEL_K1_R = 0x11,
GX_TEV_KASEL_K2_R = 0x12,
GX_TEV_KASEL_K3_R = 0x13,
GX_TEV_KASEL_K0_G = 0x14,
GX_TEV_KASEL_K1_G = 0x15,
GX_TEV_KASEL_K2_G = 0x16,
GX_TEV_KASEL_K3_G = 0x17,
GX_TEV_KASEL_K0_B = 0x18,
GX_TEV_KASEL_K1_B = 0x19,
GX_TEV_KASEL_K2_B = 0x1A,
GX_TEV_KASEL_K3_B = 0x1B,
GX_TEV_KASEL_K0_A = 0x1C,
GX_TEV_KASEL_K1_A = 0x1D,
GX_TEV_KASEL_K2_A = 0x1E,
GX_TEV_KASEL_K3_A = 0x1F
} GXTevKAlphaSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1,
GX_KCOLOR2,
GX_KCOLOR3,
GX_MAX_KCOLOR
} GXTevKColorID;
typedef enum _GXZTexOp {
GX_ZT_DISABLE,
GX_ZT_ADD,
GX_ZT_REPLACE,
GX_MAX_ZTEXO
} GXZTexOp;
typedef enum _GXIndTexFormat {
GX_ITF_8,
GX_ITF_5,
GX_ITF_4,
GX_ITF_3,
GX_MAX_ITFORMAT
} GXIndTexFormat;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE,
GX_ITB_S,
GX_ITB_T,
GX_ITB_ST,
GX_ITB_U,
GX_ITB_SU,
GX_ITB_TU,
GX_ITB_STU,
GX_MAX_ITBIAS
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF,
GX_ITBA_S,
GX_ITBA_T,
GX_ITBA_U,
GX_MAX_ITBALPHA
} GXIndTexAlphaSel;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF,
GX_ITM_0,
GX_ITM_1,
GX_ITM_2,
GX_ITM_S0 = 5,
GX_ITM_S1,
GX_ITM_S2,
GX_ITM_T0 = 9,
GX_ITM_T1,
GX_ITM_T2
} GXIndTexMtxID;
typedef enum _GXIndTexWrap {
GX_ITW_OFF,
GX_ITW_256,
GX_ITW_128,
GX_ITW_64,
GX_ITW_32,
GX_ITW_16,
GX_ITW_0,
GX_MAX_ITWRAP
} GXIndTexWrap;
typedef enum _GXIndTexStageID {
GX_INDTEXSTAGE0,
GX_INDTEXSTAGE1,
GX_INDTEXSTAGE2,
GX_INDTEXSTAGE3,
GX_MAX_INDTEXSTAGE
} GXIndTexStageID;
typedef enum _GXIndTexScale {
GX_ITS_1,
GX_ITS_2,
GX_ITS_4,
GX_ITS_8,
GX_ITS_16,
GX_ITS_32,
GX_ITS_64,
GX_ITS_128,
GX_ITS_256,
GX_MAX_ITSCALE
} GXIndTexScale;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1
} GXClipMode;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8,
GX_TL_RGB565,
GX_TL_RGB5A3,
GX_MAX_TLUTFMT
} GXTlutFmt;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3
} GXMiscToken;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K,
GX_TEXCACHE_128K,
GX_TEXCACHE_512K,
GX_TEXCACHE_NONE
} GXTexCacheSize;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES,
GX_PERF0_CLIP_VTX,
GX_PERF0_CLIP_CLKS,
GX_PERF0_XF_WAIT_IN,
GX_PERF0_XF_WAIT_OUT,
GX_PERF0_XF_XFRM_CLKS,
GX_PERF0_XF_LIT_CLKS,
GX_PERF0_XF_BOT_CLKS,
GX_PERF0_XF_REGLD_CLKS,
GX_PERF0_XF_REGRD_CLKS,
GX_PERF0_CLIP_RATIO,
GX_PERF0_TRIANGLES,
GX_PERF0_TRIANGLES_CULLED,
GX_PERF0_TRIANGLES_PASSED,
GX_PERF0_TRIANGLES_SCISSORED,
GX_PERF0_TRIANGLES_0TEX,
GX_PERF0_TRIANGLES_1TEX,
GX_PERF0_TRIANGLES_2TEX,
GX_PERF0_TRIANGLES_3TEX,
GX_PERF0_TRIANGLES_4TEX,
GX_PERF0_TRIANGLES_5TEX,
GX_PERF0_TRIANGLES_6TEX,
GX_PERF0_TRIANGLES_7TEX,
GX_PERF0_TRIANGLES_8TEX,
GX_PERF0_TRIANGLES_0CLR,
GX_PERF0_TRIANGLES_1CLR,
GX_PERF0_TRIANGLES_2CLR,
GX_PERF0_QUAD_0CVG,
GX_PERF0_QUAD_NON0CVG,
GX_PERF0_QUAD_1CVG,
GX_PERF0_QUAD_2CVG,
GX_PERF0_QUAD_3CVG,
GX_PERF0_QUAD_4CVG,
GX_PERF0_AVG_QUAD_CNT,
GX_PERF0_CLOCKS,
GX_PERF0_NONE
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS,
GX_PERF1_TX_IDLE,
GX_PERF1_TX_REGS,
GX_PERF1_TX_MEMSTALL,
GX_PERF1_TC_CHECK1_2,
GX_PERF1_TC_CHECK3_4,
GX_PERF1_TC_CHECK5_6,
GX_PERF1_TC_CHECK7_8,
GX_PERF1_TC_MISS,
GX_PERF1_VC_ELEMQ_FULL,
GX_PERF1_VC_MISSQ_FULL,
GX_PERF1_VC_MEMREQ_FULL,
GX_PERF1_VC_STATUS7,
GX_PERF1_VC_MISSREP_FULL,
GX_PERF1_VC_STREAMBUF_LOW,
GX_PERF1_VC_ALL_STALLS,
GX_PERF1_VERTICES,
GX_PERF1_FIFO_REQ,
GX_PERF1_CALL_REQ,
GX_PERF1_VC_MISS_REQ,
GX_PERF1_CP_ALL_REQ,
GX_PERF1_CLOCKS,
GX_PERF1_NONE
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS,
GX_VC_NRM,
GX_VC_CLR0,
GX_VC_CLR1,
GX_VC_TEX0,
GX_VC_TEX1,
GX_VC_TEX2,
GX_VC_TEX3,
GX_VC_TEX4,
GX_VC_TEX5,
GX_VC_TEX6,
GX_VC_TEX7,
GX_VC_ALL = 0xf
} GXVCachePerf;
typedef enum _GXFBClamp {
GX_CLAMP_NONE = 0,
GX_CLAMP_TOP = 1,
GX_CLAMP_BOTTOM = 2
} GXFBClamp;
typedef enum _GXCopyMode {
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3
} GXCopyMode;
typedef enum _GXAlphaReadMode {
GX_READ_00 = 0,
GX_READ_FF = 1,
GX_READ_NONE = 2
} GXAlphaReadMode;
typedef enum {
VI_TVMODE_NTSC_INT = (((0) << 2) + (0)) ,
VI_TVMODE_NTSC_DS = (((0) << 2) + (1)) ,
VI_TVMODE_NTSC_PROG = (((0) << 2) + (2)) ,
VI_TVMODE_NTSC_3D = (((0) << 2) + (3)) ,
VI_TVMODE_PAL_INT = (((1) << 2) + (0)) ,
VI_TVMODE_PAL_DS = (((1) << 2) + (1)) ,
VI_TVMODE_MPAL_INT = (((2) << 2) + (0)) ,
VI_TVMODE_MPAL_DS = (((2) << 2) + (1)) ,
VI_TVMODE_DEBUG_INT = (((3) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_INT = (((4) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_DS = (((4) << 2) + (1)) ,
VI_TVMODE_EURGB60_INT = (((5) << 2) + (0)) ,
VI_TVMODE_EURGB60_DS = (((5) << 2) + (1)) ,
VI_TVMODE_GCA_INT = (((6) << 2) + (0)) ,
VI_TVMODE_GCA_DS = (((6) << 2) + (1)) ,
VI_TVMODE_GCA_PROG = (((6) << 2) + (2))
} VITVMode;
typedef enum {
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF = 1
} VIXFBMode;
typedef void (*VIPositionCallback)(s16 x, s16 y);
typedef void (*VIRetraceCallback)(u32 retraceCount);
typedef struct VITimingInfo {
u8 equ;
u16 acv;
u16 prbOdd;
u16 prbEven;
u16 psbOdd;
u16 psbEven;
u8 bs1;
u8 bs2;
u8 bs3;
u8 bs4;
u16 be1;
u16 be2;
u16 be3;
u16 be4;
u16 numHalfLines;
u16 hlw;
u8 hsy;
u8 hcs;
u8 hce;
u8 hbe640;
u16 hbs640;
u8 hbeCCIR656;
u16 hbsCCIR656;
} VITimingInfo;
typedef struct VIPositionInfo {
u16 dispPosX;
u16 dispPosY;
u16 dispSizeX;
u16 dispSizeY;
u16 adjDispPosX;
u16 adjDispPosY;
u16 adjDispSizeY;
u16 adjPanPosY;
u16 adjPanSizeY;
u16 fbSizeX;
u16 fbSizeY;
u16 panPosX;
u16 panPosY;
u16 panSizeX;
u16 panSizeY;
VIXFBMode xfbMode;
u32 nonInter;
u32 tv;
u8 wordPerLine;
u8 std;
u8 wpl;
u32 bufAddr;
u32 tfbb;
u32 bfbb;
u8 xof;
BOOL isBlack;
BOOL is3D;
u32 rbufAddr;
u32 rtfbb;
u32 rbfbb;
VITimingInfo* timing;
} VIPositionInfo;
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXColor {
u8 r;
u8 g;
u8 b;
u8 a;
} GXColor;
typedef struct _GXTexObj {
u32 dummy[8];
} GXTexObj;
typedef struct _GXTlutObj {
u32 dummy[3];
} GXTlutObj;
typedef struct _GXLightObj {
u32 dummy[16];
} GXLightObj;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXColorS10 {
s16 r;
s16 g;
s16 b;
s16 a;
} GXColorS10;
typedef struct _GXTexRegion {
u32 dummy[4];
} GXTexRegion;
typedef struct _GXTlutRegion {
u32 dummy[4];
} GXTlutRegion;
typedef struct _GXFogAdjTable
{
u16 r[10];
} GXFogAdjTable;
typedef enum _GXTlutSize
{
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024
} GXTlutSize;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt cnt;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
void GXSetTevDirect(GXTevStageID tev_stage);
void GXSetNumIndStages(u8 nIndStages);
void GXSetIndTexMtx(GXIndTexMtxID mtx_sel, f32 offset[2][3], s8 scale_exp);
void GXSetIndTexOrder(GXIndTexStageID ind_stage, GXTexCoordID tex_coord, GXTexMapID tex_map);
void GXSetTevIndirect(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXIndTexFormat format,
GXIndTexBiasSel bias_sel, GXIndTexMtxID matrix_sel, GXIndTexWrap wrap_s,
GXIndTexWrap wrap_t, GXBool add_prev, GXBool ind_lod,
GXIndTexAlphaSel alpha_sel);
void GXSetTevIndTile (GXTevStageID tev_stage, GXIndTexStageID ind_stage,
u16 tilesize_s, u16 tilesize_t,
u16 tilespacing_s, u16 tilespacing_t,
GXIndTexFormat format, GXIndTexMtxID matrix_sel,
GXIndTexBiasSel bias_sel, GXIndTexAlphaSel alpha_sel);
void GXSetIndTexCoordScale(GXIndTexStageID ind_state, GXIndTexScale scale_s, GXIndTexScale scale_t);
void GXSetScissor(u32 left, u32 top, u32 wd, u32 ht);
void GXSetCullMode(GXCullMode mode);
void GXSetCoPlanar(GXBool enable);
void GXBeginDisplayList(void* list, u32 size);
u32 GXEndDisplayList(void);
void GXCallDisplayList(const void* list, u32 nbytes);
void GXDrawSphere(u8 numMajor, u8 numMinor);
typedef struct {
u8 pad[128];
} GXFifoObj;
typedef void (*GXBreakPtCallback)(void);
void GXInitFifoBase(GXFifoObj* fifo, void* base, u32 size);
void GXInitFifoPtrs(GXFifoObj* fifo, void* readPtr, void* writePtr);
void GXGetFifoPtrs(GXFifoObj* fifo, void** readPtr, void** writePtr);
GXFifoObj* GXGetCPUFifo(void);
GXFifoObj* GXGetGPFifo(void);
void GXSetCPUFifo(GXFifoObj* fifo);
void GXSetGPFifo(GXFifoObj* fifo);
void GXSaveCPUFifo(GXFifoObj* fifo);
void GXGetFifoStatus(GXFifoObj* fifo, GXBool* overhi, GXBool* underlow, u32* fifoCount,
GXBool* cpu_write, GXBool* gp_read, GXBool* fifowrap);
void GXGetGPStatus(GXBool* overhi, GXBool* underlow, GXBool* readIdle, GXBool* cmdIdle,
GXBool* brkpt);
void GXInitFifoLimits(GXFifoObj* fifo, u32 hiWaterMark, u32 loWaterMark);
GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback cb);
void GXEnableBreakPt(void* breakPt);
void GXDisableBreakPt(void);
extern GXRenderModeObj GXNtsc240Ds;
extern GXRenderModeObj GXNtsc240DsAa;
extern GXRenderModeObj GXNtsc240Int;
extern GXRenderModeObj GXNtsc240IntAa;
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXNtsc480IntAa;
extern GXRenderModeObj GXNtsc480Prog;
extern GXRenderModeObj GXNtsc480ProgAa;
extern GXRenderModeObj GXMpal240Ds;
extern GXRenderModeObj GXMpal240DsAa;
extern GXRenderModeObj GXMpal240Int;
extern GXRenderModeObj GXMpal240IntAa;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXMpal480Int;
extern GXRenderModeObj GXMpal480IntAa;
extern GXRenderModeObj GXPal264Ds;
extern GXRenderModeObj GXPal264DsAa;
extern GXRenderModeObj GXPal264Int;
extern GXRenderModeObj GXPal264IntAa;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXPal528Int;
extern GXRenderModeObj GXPal524IntAa;
extern GXRenderModeObj GXEurgb60Hz240Ds;
extern GXRenderModeObj GXEurgb60Hz240DsAa;
extern GXRenderModeObj GXEurgb60Hz240Int;
extern GXRenderModeObj GXEurgb60Hz240IntAa;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
extern GXRenderModeObj GXEurgb60Hz480Int;
extern GXRenderModeObj GXEurgb60Hz480IntAa;
void GXSetCopyClear(GXColor clear_clr, u32 clear_z);
void GXAdjustForOverscan(GXRenderModeObj* rmin, GXRenderModeObj* rmout, u16 hor, u16 ver);
void GXCopyDisp(void* dest, GXBool clear);
void GXSetDispCopyGamma(GXGamma gamma);
void GXSetDispCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetDispCopyDst(u16 wd, u16 ht);
f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
u32 GXSetDispCopyYScale(f32 vscale);
void GXSetCopyFilter(GXBool aa, u8 sample_pattern[12][2], GXBool vf, u8 vfilter[7]);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetTexCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetTexCopyDst(u16 wd, u16 ht, GXTexFmt fmt, GXBool mipmap);
void GXCopyTex(void* dest, GXBool clear);
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(GXVtxDescList* list);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetNumTexGens(u8 nTexGens);
void GXBegin(GXPrimitive type, GXVtxFmt vtxfmt, u16 nverts);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx,
GXBool normalize, u32 postmtx);
void GXSetLineWidth(u8 width, GXTexOffset texOffsets);
void GXSetPointSize(u8 pointSize, GXTexOffset texOffsets);
void GXEnableTexOffsets(GXTexCoordID coord, GXBool line_enable, GXBool point_enable);
void GXSetArray(GXAttr attr, const void* data, u8 stride);
void GXInvalidateVtxCache(void);
static inline void GXSetTexCoordGen(GXTexCoordID dst_coord, GXTexGenType func,
GXTexGenSrc src_param, u32 mtx) {
GXSetTexCoordGen2(dst_coord, func, src_param, mtx, ((GXBool)0) , GX_PTIDENTITY);
}
GXBool GXGetTexObjMipMap(const GXTexObj* obj);
GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
u16 GXGetTexObjHeight(const GXTexObj* obj);
u16 GXGetTexObjWidth(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapS(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapT(const GXTexObj* obj);
void* GXGetTexObjData(const GXTexObj* obj);
void GXGetProjectionv(f32* p);
void GXGetLightPos(const GXLightObj* lt_obj, f32* x, f32* y, f32* z);
void GXGetLightColor(const GXLightObj* lt_obj, GXColor* color);
void GXGetVtxAttrFmt(GXVtxFmt idx, GXAttr attr, GXCompCnt* compCnt, GXCompType* compType,
u8* shift);
void GXSetNumChans(u8 nChans);
void GXSetChanCtrl(GXChannelID chan, GXBool enable, GXColorSrc amb_src, GXColorSrc mat_src,
u32 light_mask, GXDiffuseFn diff_fn, GXAttnFn attn_fn);
void GXSetChanAmbColor(GXChannelID chan, GXColor amb_color);
void GXSetChanMatColor(GXChannelID chan, GXColor mat_color);
void GXInitLightSpot(GXLightObj* lt_obj, f32 cutoff, GXSpotFn spot_func);
void GXInitLightDistAttn(GXLightObj* lt_obj, f32 ref_distance, f32 ref_brightness,
GXDistAttnFn dist_func);
void GXInitLightPos(GXLightObj* lt_obj, f32 x, f32 y, f32 z);
void GXInitLightDir(GXLightObj* lt_obj, f32 nx, f32 ny, f32 nz);
void GXInitLightColor(GXLightObj* lt_obj, GXColor color);
void GXInitLightAttn(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
void GXInitLightAttnA(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2);
void GXInitLightAttnK(GXLightObj* lt_obj, f32 k0, f32 k1, f32 k2);
void GXLoadLightObjImm(GXLightObj* lt_obj, GXLightID light);
typedef void (*GXDrawDoneCallback)(void);
typedef void (*GXDrawSyncCallback)(u16 token);
GXFifoObj* GXInit(void* base, u32 size);
GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback cb);
void GXSetDrawSync(u16 token);
GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback callback);
void GXDrawDone(void);
void GXSetDrawDone(void);
void GXFlush(void);
void GXPixModeSync(void);
void GXSetMisc(GXMiscToken token, u32 val);
extern void GXSetGPMetric(GXPerf0 perf0, GXPerf1 perf1);
extern void GXClearGPMetric();
extern void GXReadXfRasMetric(u32* xfWaitIn, u32* xfWaitOut, u32* rasBusy, u32* clocks);
extern void GXReadGPMetric(u32* count0, u32* count1);
extern u32 GXReadGP0Metric();
extern u32 GXReadGP1Metric();
extern void GXReadMemMetric(u32* cpReq, u32* tcReq, u32* cpuReadReq, u32* cpuWriteReq, u32* dspReq, u32* ioReq, u32* viReq, u32* peReq,
u32* rfReq, u32* fiReq);
extern void GXClearMemMetric();
extern void GXReadPixMetric(u32* topIn, u32* topOut, u32* bottomIn, u32* bottomOut, u32* clearIn, u32* copyClocks);
extern void GXClearPixMetric();
extern void GXSetVCacheMetric(GXVCachePerf attr);
extern void GXReadVCacheMetric(u32* check, u32* miss, u32* stall);
extern void GXClearVCacheMetric();
extern void GXInitXfRasMetric();
extern u32 GXReadClksPerVtx();
void GXSetFog(GXFogType type, f32 startz, f32 endz, f32 nearz, f32 farz, GXColor color);
void GXSetFogColor(GXColor color);
void GXSetBlendMode(GXBlendMode type, GXBlendFactor src_factor, GXBlendFactor dst_factor,
GXLogicOp op);
void GXSetColorUpdate(GXBool update_enable);
void GXSetAlphaUpdate(GXBool update_enable);
void GXSetZMode(GXBool compare_enable, GXCompare func, GXBool update_enable);
void GXSetZCompLoc(GXBool before_tex);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetDither(GXBool dither);
void GXSetDstAlpha(GXBool enable, u8 alpha);
void GXSetFieldMode(u8 field_mode, u8 half_aspect_ratio);
void GXSetTevOp(GXTevStageID id, GXTevMode mode);
void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c,
GXTevColorArg d);
void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c,
GXTevAlphaArg d);
void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevColor(GXTevRegID id, GXColor color);
void GXSetTevColorS10(GXTevRegID id, GXColorS10 color);
void GXSetTevKColor(GXTevKColorID id, GXColor color);
void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel ras_sel, GXTevSwapSel tex_sel);
void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green,
GXTevColorChan blue, GXTevColorChan alpha);
void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
void GXSetZTexture(GXZTexOp op, GXTexFmt fmt, u32 bias);
void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
void GXSetNumTevStages(u8 nStages);
typedef GXTexRegion *(*GXTexRegionCallback)(GXTexObj *t_obj, GXTexMapID id);
typedef GXTlutRegion *(*GXTlutRegionCallback)(u32 idx);
u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, u8 mipmap, u8 max_lod);
void GXInitTexObj(GXTexObj *obj, void *image_ptr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode wrap_s, GXTexWrapMode wrap_t, u8 mipmap);
void GXInitTexObjCI(GXTexObj *obj, void *image_ptr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode wrap_s, GXTexWrapMode wrap_t, u8 mipmap, u32 tlut_name);
void GXInitTexObjLOD(GXTexObj *obj, GXTexFilter min_filt, GXTexFilter mag_filt,
f32 min_lod, f32 max_lod, f32 lod_bias, GXBool bias_clamp,
GXBool do_edge_lod, GXAnisotropy max_aniso);
void GXInitTexObjData(GXTexObj *obj, void *image_ptr);
void GXInitTexObjWrapMode(GXTexObj *obj, GXTexWrapMode s, GXTexWrapMode t);
void GXInitTexObjTlut(GXTexObj *obj, u32 tlut_name);
void GXInitTexObjUserData(GXTexObj *obj, void *user_data);
void *GXGetTexObjUserData(const GXTexObj *obj);
void GXLoadTexObjPreLoaded(GXTexObj *obj, GXTexRegion *region, GXTexMapID id);
void GXLoadTexObj(GXTexObj *obj, GXTexMapID id);
void GXInitTlutObj(GXTlutObj *tlut_obj, void *lut, GXTlutFmt fmt, u16 n_entries);
void GXLoadTlut(GXTlutObj *tlut_obj, u32 tlut_name);
void GXInitTexCacheRegion(GXTexRegion *region, u8 is_32b_mipmap, u32 tmem_even, GXTexCacheSize size_even, u32 tmem_odd, GXTexCacheSize size_odd);
void GXInitTexPreLoadRegion(GXTexRegion *region, u32 tmem_even, u32 size_even, u32 tmem_odd, u32 size_odd);
void GXInitTlutRegion(GXTlutRegion *region, u32 tmem_addr, GXTlutSize tlut_size);
void GXInvalidateTexRegion(GXTexRegion *region);
void GXInvalidateTexAll(void);
GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback f);
GXTlutRegionCallback GXSetTlutRegionCallback(GXTlutRegionCallback f);
void GXPreLoadEntireTexture(GXTexObj *tex_obj, GXTexRegion *region);
void GXSetTexCoordScaleManually(GXTexCoordID coord, u8 enable, u16 ss, u16 ts);
void GXSetTexCoordCylWrap(GXTexCoordID coord, u8 s_enable, u8 t_enable);
void GXSetTexCoordBias(GXTexCoordID coord, u8 s_enable, u8 t_enable);
void GXSetProjection(f32 mtx[4][4], GXProjectionType type);
void GXLoadPosMtxImm(f32 mtx[3][4], u32 id);
void GXLoadNrmMtxImm(f32 mtx[3][4], u32 id);
void GXLoadTexMtxImm(f32 mtx[][4], u32 id, GXTexMtxType type);
void GXProject(f32 x, f32 y, f32 z, const f32 mtx[3][4], const f32 *pm, const f32 *vp, f32 *sx, f32 *sy, f32 *sz);
void GXGetViewportv(f32 *vp);
void GXSetViewport(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz);
void GXSetCurrentMtx(u32 id);
void GXSetViewportJitter(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz, u32 field);
void GXSetScissorBoxOffset(s32 x_off, s32 y_off);
void GXSetClipMode(GXClipMode mode);
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
volatile PPCWGPipe GXWGFifo : 0xCC008000 ;
static inline void GXPosition2f32(const f32 x, const f32 y) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
}
static inline void GXPosition2u16(const u16 x, const u16 y) {
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
}
static inline void GXPosition2s16(const s16 x, const s16 y) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
}
static inline void GXPosition3s16(const s16 x, const s16 y, const s16 z) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXPosition3u8(const u8 x, const u8 y, const u8 z) {
GXWGFifo.u8 = x;
GXWGFifo.u8 = y;
GXWGFifo.u8 = z;
}
static inline void GXPosition3f32(const f32 x, const f32 y, const f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXNormal3s16(const s16 x, const s16 y, const s16 z) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXNormal3f32(const f32 x, const f32 y, const f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXColor1u32(const u32 v) {
GXWGFifo.u32 = v;
}
static inline void GXColor3u8(const u8 r, const u8 g, const u8 b) {
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
}
static inline void GXColor4u8(const u8 r, const u8 g, const u8 b, const u8 a) {
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
GXWGFifo.u8 = a;
}
static inline void GXTexCoord2s16(const s16 u, const s16 v) {
GXWGFifo.s16 = u;
GXWGFifo.s16 = v;
}
static inline void GXTexCoord2f32(const f32 u, const f32 v) {
GXWGFifo.f32 = u;
GXWGFifo.f32 = v;
}
static inline void GXPosition1x8(u8 index) {
GXWGFifo.u8 = index;
}
static inline void GXColor1x8(u8 index) {
GXWGFifo.u8 = index;
}
static inline void GXPosition1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXNormal1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXColor1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXTexCoord1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXUnknownu16(const u16 x) {
GXWGFifo.u16 = x;
}
static inline void GXEnd(void) {}
typedef s64 OSTime;
typedef u32 OSTick;
u32 __OSBusClock : ((0x8000 << 16) | 0x00F8) ;
u32 __OSCoreClock : ((0x8000 << 16) | 0x00FC) ;
void OSInit();
OSTime OSGetTime();
OSTick OSGetTick();
typedef struct OSCalendarTime {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime *td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime *td);
typedef struct OSStopwatch {
char *name;
OSTime total;
u32 hits;
OSTime min;
OSTime max;
OSTime last;
BOOL running;
} OSStopwatch;
void OSInitStopwatch(OSStopwatch *sw, char *name);
void OSStartStopwatch(OSStopwatch *sw);
void OSStopStopwatch(OSStopwatch *sw);
OSTime OSCheckStopwatch(OSStopwatch *sw);
void OSResetStopwatch(OSStopwatch *sw);
void OSDumpStopwatch(OSStopwatch *sw);
u32 OSGetConsoleType();
u32 OSGetSoundMode(void);
void OSSetSoundMode(u32 mode);
u32 OSGetProgressiveMode(void);
void OSSetProgressiveMode(u32 on);
u8 OSGetLanguage(void);
void OSSetLanguage(u8 language);
u32 OSGetEuRgb60Mode(void);
void OSSetEuRgb60Mode(u32 on);
void OSRegisterVersion(const char *id);
BOOL OSDisableInterrupts(void);
BOOL OSEnableInterrupts(void);
BOOL OSRestoreInterrupts(BOOL level);
void OSReport(const char *msg, ...);
void OSPanic(const char *file, int line, const char *msg, ...);
void OSFatal(GXColor fg, GXColor bg, const char *msg);
u32 OSGetPhysicalMemSize(void);
u32 OSGetConsoleSimulatedMemSize(void);
typedef struct OSContext {
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
u32 fpscr_pad;
u32 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
u32 psf_pad;
f64 psf[32];
} OSContext;
u32 OSGetStackPointer(void);
void OSDumpContext(OSContext *context);
u32 OSSaveContext(OSContext* context);
void OSLoadContext(OSContext* context);
void OSClearContext(OSContext* context);
OSContext* OSGetCurrentContext();
void OSSetCurrentContext(OSContext* context);
void OSSaveFPUContext(OSContext *fpuContext);
void OSInitContext(OSContext *context, u32 pc, u32 newsp);
typedef struct OSAlarm OSAlarm;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm {
OSAlarmHandler handler;
u32 tag;
OSTime fire;
OSAlarm* prev;
OSAlarm* next;
OSTime period;
OSTime start;
};
void OSInitAlarm(void);
void OSSetAlarm(OSAlarm* alarm, OSTime tick, OSAlarmHandler handler);
void OSSetAlarmTag(OSAlarm* alarm, u32 tag);
void OSSetAbsAlarm(OSAlarm* alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm* alarm, OSTime start, OSTime period, OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm* alarm);
void OSCancelAlarm(OSAlarm* alarm);
void OSCancelAlarms(u32 tag);
BOOL OSCheckAlarmQueue(void);
typedef int OSHeapHandle;
typedef void (*OSAllocVisitor)(void *obj, u32 size);
void *OSInitAlloc(void *arenaStart, void *arenaEnd, int maxHeaps);
OSHeapHandle OSCreateHeap(void *start, void *end);
void OSDestroyHeap(OSHeapHandle heap);
void OSAddToHeap(OSHeapHandle heap, void *start, void *end);
OSHeapHandle OSSetCurrentHeap(OSHeapHandle heap);
void *OSAllocFromHeap(OSHeapHandle heap, u32 size);
void *OSAllocFixed(void **rstart, void **rend);
void OSFreeToHeap(OSHeapHandle heap, void *ptr);
long OSCheckHeap(OSHeapHandle heap);
void OSDumpHeap(OSHeapHandle heap);
u32 OSReferentSize(void *ptr);
void OSVisitAllocated(OSAllocVisitor visitor);
extern volatile OSHeapHandle __OSCurrHeap;
void* OSGetArenaHi(void);
void* OSGetArenaLo(void);
void OSSetArenaHi(void* addr);
void OSSetArenaLo(void* addr);
void* OSAllocFromArenaLo(u32 size, u32 align);
void* OSAllocFromArenaLo(u32 size, u32 align);
void DCInvalidateRange(void* addr, u32 nBytes);
void DCFlushRange(void* addr, u32 nBytes);
void DCStoreRange(void* addr, u32 nBytes);
void DCFlushRangeNoSync(void* addr, u32 nBytes);
void DCStoreRangeNoSync(void* addr, u32 nBytes);
void DCZeroRange(void* addr, u32 nBytes);
void DCTouchRange(void* addr, u32 nBytes);
void ICInvalidateRange(void* addr, u32 nBytes);
void LCEnable();
void LCDisable(void);
void LCLoadBlocks(void* destTag, void* srcAddr, u32 numBlocks);
void LCStoreBlocks(void* destAddr, void* srcTag, u32 numBlocks);
u32 LCLoadData(void* destAddr, void* srcAddr, u32 nBytes);
u32 LCStoreData(void* destAddr, void* srcAddr, u32 nBytes);
u32 LCQueueLength(void);
void LCQueueWait(u32 len);
void LCFlushQueue(void);
typedef u16 OSError;
typedef void (*OSErrorHandler)( OSError error, OSContext* context, ... );
OSErrorHandler OSSetErrorHandler(OSError code, OSErrorHandler handler);
typedef u8 __OSException;
typedef void (*__OSExceptionHandler)(__OSException exception, OSContext* context);
BOOL EXIProbe(s32 chan);
s32 EXIProbeEx(s32 chan);
s32 EXIGetType(s32 chan, u32 dev, u32* type);
char* EXIGetTypeString(u32 type);
u32 EXIClearInterrupts(s32 chan, BOOL exi, BOOL tc, BOOL ext);
s32 EXIGetID(s32 chan, u32 dev, u32* id);
typedef void (*EXICallback)(s32 chan, OSContext* context);
static inline void OSInitFastCast(void) {
asm {li r3, 0x0004
oris r3, r3, 0x0004
mtspr 914 , r3
li r3, 0x0005
oris r3, r3, 0x0005
mtspr 915 , r3
li r3, 0x0006
oris r3, r3, 0x0006
mtspr 916 , r3
li r3, 0x0007
oris r3, r3, 0x0007
mtspr 917 , r3
}
}
static inline s16 __OSf32tos16(register f32 inF)
{
u32 tmp;
register u32* tmpPtr = &tmp;
register s16 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 5
lha out, 0(tmpPtr)
}
return out;
}
static inline void OSf32tos16(f32 *f, s16 *out) { *out = __OSf32tos16(*f); }
static inline u8 __OSf32tou8(register f32 inF)
{
u32 tmp;
register u32 *tmpPtr = &tmp;
register u8 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 2
lbz out, 0(tmpPtr)
}
return out;
}
static inline void OSf32tou8(f32 *f, u8 *out) { *out = __OSf32tou8(*f); }
static inline s8 __OSf32tos8(register f32 inF)
{
u32 tmp;
register u32 *tmpPtr = &tmp;
register s8 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 4
lbz out, 0(tmpPtr)
extsb out, out
}
return out;
}
static inline void OSf32tos8(f32 *f, s8 *out) { *out = __OSf32tos8(*f); }
static inline u16 __OSf32tou16(register f32 inF)
{
u32 tmp;
register u32 *tmpPtr = &tmp;
register u16 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 3
lbz out, 0(tmpPtr)
}
return out;
}
static inline void OSf32tou16(f32 *f, u16 *out) { *out = __OSf32tou16(*f); }
static inline float __OSs8tof32(register const s8* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 4
}
return ret;
}
static inline void OSs8tof32(const s8* in, float* out) { *out = __OSs8tof32(in); }
static inline float __OSs16tof32(register const s16* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 5
}
return ret;
}
static inline void OSs16tof32(const s16* in, float* out) { *out = __OSs16tof32(in); }
static inline float __OSu8tof32(register const u8* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 2
}
return ret;
}
static inline void OSu8tof32(const u8* in, float* out) { *out = __OSu8tof32(in); }
static inline float __OSu16tof32(register const u16* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 3
}
return ret;
}
static inline void OSu16tof32(const u16* in, float* out) { *out = __OSu16tof32(in); }
typedef struct OSFontHeader
{
u16 fontType;
u16 firstChar;
u16 lastChar;
u16 invalChar;
u16 ascent;
u16 descent;
u16 width;
u16 leading;
u16 cellWidth;
u16 cellHeight;
u32 sheetSize;
u16 sheetFormat;
u16 sheetColumn;
u16 sheetRow;
u16 sheetWidth;
u16 sheetHeight;
u16 widthTable;
u32 sheetImage;
u32 sheetFullSize;
u8 c0;
u8 c1;
u8 c2;
u8 c3;
} OSFontHeader;
u16 OSGetFontEncode(void);
BOOL OSInitFont(OSFontHeader *fontData);
u32 OSLoadFont(OSFontHeader *fontData, void *temp);
char *OSGetFontTexture(char *string, void **image, s32 *x, s32 *y, s32 *width);
char *OSGetFontWidth(char *string, s32 *width);
char *OSGetFontTexel(char *string, void *image, s32 pos, s32 stride, s32 *width);
void ICFlashInvalidate(void);
void ICEnable(void);
void ICDisable(void);
void ICFreeze(void);
void ICUnfreeze(void);
void ICBlockInvalidate(void *addr);
void ICSync(void);
typedef s16 __OSInterrupt;
typedef void (*__OSInterruptHandler)(__OSInterrupt interrupt, OSContext* context);
typedef u32 OSInterruptMask;
extern volatile __OSInterrupt __OSLastInterrupt;
extern volatile u32 __OSLastInterruptSrr0;
extern volatile OSTime __OSLastInterruptTime;
__OSInterruptHandler __OSSetInterruptHandler(__OSInterrupt interrupt, __OSInterruptHandler handler);
__OSInterruptHandler __OSGetInterruptHandler(__OSInterrupt interrupt);
void __OSDispatchInterrupt(__OSException exception, OSContext* context);
OSInterruptMask OSGetInterruptMask(void);
OSInterruptMask OSSetInterruptMask(OSInterruptMask mask);
OSInterruptMask __OSMaskInterrupts(OSInterruptMask mask);
OSInterruptMask __OSUnmaskInterrupts(OSInterruptMask mask);
void OSProtectRange(u32 chan, void* addr, u32 nBytes, u32 control);
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef s32 OSPriority;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef struct OSCond OSCond;
typedef void (*OSIdleFunction)(void* param);
typedef void (*OSSwitchThreadCallback)(OSThread* from, OSThread* to);
struct OSThreadQueue {
OSThread* head;
OSThread* tail;
};
struct OSThreadLink {
OSThread* next;
OSThread* prev;
};
struct OSMutexQueue {
OSMutex* head;
OSMutex* tail;
};
struct OSMutexLink {
OSMutex* next;
OSMutex* prev;
};
struct OSThread {
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void* val;
OSThreadQueue* queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex* mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8* stackBase;
u32* stackEnd;
};
enum OS_THREAD_STATE {
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8
};
void OSInitThreadQueue(OSThreadQueue* queue);
OSThread* OSGetCurrentThread(void);
BOOL OSIsThreadSuspended(OSThread* thread);
BOOL OSIsThreadTerminated(OSThread* thread);
s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);
void OSYieldThread(void);
BOOL OSCreateThread(OSThread* thread, void* (*func)(void*), void* param, void* stack, u32 stackSize,
OSPriority priority, u16 attr);
void OSExitThread(void* val);
void OSCancelThread(OSThread* thread);
BOOL OSJoinThread(OSThread* thread, void** val);
void OSDetachThread(OSThread* thread);
s32 OSResumeThread(OSThread* thread);
s32 OSSuspendThread(OSThread* thread);
BOOL OSSetThreadPriority(OSThread* thread, OSPriority priority);
OSPriority OSGetThreadPriority(OSThread* thread);
void OSSleepThread(OSThreadQueue* queue);
void OSWakeupThread(OSThreadQueue* queue);
OSThread* OSSetIdleFunction(OSIdleFunction idleFunction, void* param, void* stack, u32 stackSize);
OSThread* OSGetIdleFunction(void);
void OSClearStack(u8 val);
long OSCheckActiveThreads(void);
typedef struct OSMessageQueue OSMessageQueue;
typedef void* OSMessage;
struct OSMessageQueue {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
s32 msgCount;
s32 firstIndex;
s32 usedCount;
};
void OSInitMessageQueue(OSMessageQueue* mq, OSMessage* msgArray, s32 msgCount);
BOOL OSSendMessage(OSMessageQueue* mq, OSMessage msg, s32 flags);
BOOL OSJamMessage(OSMessageQueue* mq, OSMessage msg, s32 flags);
BOOL OSReceiveMessage(OSMessageQueue* mq, OSMessage* msg, s32 flags);
typedef struct OSModuleHeader OSModuleHeader;
typedef u32 OSModuleID;
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u8 bssSection;
u32 prolog;
u32 epilog;
u32 unresolved;
u32 align;
u32 bssAlign;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
void OSSetStringTable(const void* stringTable);
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* oldModule);
OSModuleInfo* OSSearchModule(void* ptr, u32* section, u32* offset);
void OSNotifyLink(void);
void OSNotifyUnlink(void);
struct OSMutex {
OSThreadQueue queue;
OSThread* thread;
s32 count;
OSMutexLink link;
};
struct OSCond {
OSThreadQueue queue;
};
void OSInitMutex(OSMutex* mutex);
void OSLockMutex(OSMutex* mutex);
void OSUnlockMutex(OSMutex* mutex);
BOOL OSTryLockMutex(OSMutex* mutex);
void OSInitCond(OSCond* cond);
void OSWaitCond(OSCond* cond, OSMutex* mutex);
void OSSignalCond(OSCond* cond);
typedef BOOL (*OSResetFunction)(BOOL final);
typedef struct OSResetFunctionInfo OSResetFunctionInfo;
struct OSResetFunctionInfo {
OSResetFunction func;
u32 priority;
OSResetFunctionInfo* next;
OSResetFunctionInfo* prev;
};
void OSRegisterResetFunction(OSResetFunctionInfo *info);
u32 OSGetResetCode(void);
typedef void (*OSResetCallback)(void);
BOOL OSGetResetButtonState(void);
BOOL OSGetResetSwitchState(void);
OSResetCallback OSSetResetCallback(OSResetCallback callback);
u32 SIProbe(s32 chan);
char* SIGetTypeString(u32 type);
void SIRefreshSamplingRate(void);
void SISetSamplingRate(u32 msec);
typedef struct DVDDiskID {
char gameName[4];
char company[2];
u8 diskNumber;
u8 gameVersion;
u8 streaming;
u8 streamingBufSize;
u8 padding[22];
} DVDDiskID;
typedef struct DVDCommandBlock DVDCommandBlock;
typedef void (*DVDCBCallback)(s32 result, DVDCommandBlock* block);
struct DVDCommandBlock {
DVDCommandBlock* next;
DVDCommandBlock* prev;
u32 command;
s32 state;
u32 offset;
u32 length;
void* addr;
u32 currTransferSize;
u32 transferredSize;
DVDDiskID* id;
DVDCBCallback callback;
void* userData;
};
typedef struct DVDFileInfo DVDFileInfo;
typedef void (*DVDCallback)(s32 result, DVDFileInfo* fileInfo);
struct DVDFileInfo {
DVDCommandBlock cb;
u32 startAddr;
u32 length;
DVDCallback callback;
};
typedef struct {
u32 entryNum;
u32 location;
u32 next;
} DVDDir;
typedef struct {
u32 entryNum;
BOOL isDir;
char* name;
} DVDDirEntry;
void DVDInit();
BOOL DVDClose(DVDFileInfo* f);
BOOL DVDSetAutoFatalMessaging(BOOL);
void DVDReset();
int DVDSetAutoInvalidation(int autoInval);
s32 DVDCancel(DVDCommandBlock* block);
BOOL DVDOpen(char* fileName, DVDFileInfo* fileInfo);
BOOL DVDFastOpen(s32 entrynum, DVDFileInfo* fileInfo);
s32 DVDGetCommandBlockStatus(const DVDCommandBlock* block);
BOOL DVDCancelAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancel(DVDCommandBlock* block);
BOOL DVDCancelAllAsync(DVDCBCallback callback);
s32 DVDCancelAll(void);
BOOL DVDPrepareStreamAsync(DVDFileInfo* fInfo, u32 length, u32 offset, DVDCallback callback);
s32 DVDPrepareStream(DVDFileInfo* fInfo, u32 length, u32 offset);
BOOL DVDCancelStreamAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancelStream(DVDCommandBlock* block);
BOOL DVDStopStreamAtEndAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDStopStreamAtEnd(DVDCommandBlock* block);
BOOL DVDGetStreamErrorStatusAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDGetStreamErrorStatus(DVDCommandBlock* block);
BOOL DVDGetStreamPlayAddrAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDGetStreamPlayAddr(DVDCommandBlock* block);
s32 DVDGetDriveStatus();
s32 DVDConvertPathToEntrynum(char* pathPtr);
BOOL DVDReadAsyncPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset,
DVDCallback callback, s32 prio);
BOOL DVDReadPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, s32 prio);
extern u32 __PADFixBits;
typedef void (*PADSamplingCallback)(void);
typedef struct PADStatus {
u16 button;
s8 stickX;
s8 stickY;
s8 substickX;
s8 substickY;
u8 triggerL;
u8 triggerR;
u8 analogA;
u8 analogB;
s8 err;
} PADStatus;
BOOL PADInit();
u32 PADRead(PADStatus* status);
BOOL PADReset(u32 mask);
BOOL PADRecalibrate(u32 mask);
void PADClamp(PADStatus* status);
void PADClampCircle(PADStatus* status);
void PADControlMotor(s32 chan, u32 cmd);
void PADSetSpec(u32 spec);
void PADControlAllMotors(const u32* cmdArr);
void PADSetAnalogMode(u32 mode);
PADSamplingCallback PADSetSamplingCallback(PADSamplingCallback);
typedef struct {
f32 x, y, z;
} Vec, *VecPtr, Point3d, *Point3dPtr;
typedef struct {
s16 x;
s16 y;
s16 z;
} S16Vec, *S16VecPtr;
typedef struct {
f32 x, y, z, w;
} Quaternion, *QuaternionPtr, Qtrn, *QtrnPtr;
typedef f32 Mtx[3][4];
typedef f32 (*MtxPtr)[4];
typedef f32 ROMtx[4][3];
typedef f32 (*ROMtxPtr)[3];
typedef f32 Mtx44[4][4];
typedef f32 (*Mtx44Ptr)[4];
typedef struct {
u32 numMtx;
MtxPtr stackBase;
MtxPtr stackPtr;
} MtxStack, *MtxStackPtr;
void C_MTXIdentity(Mtx m);
void C_MTXCopy(const Mtx src, Mtx dst);
void C_MTXConcat(const Mtx a, const Mtx b, Mtx ab);
void C_MTXConcatArray(const Mtx a, const Mtx* srcBase, Mtx* dstBase, u32 count);
void C_MTXTranspose(const Mtx src, Mtx xPose);
u32 C_MTXInverse(const Mtx src, Mtx inv);
u32 C_MTXInvXpose(const Mtx src, Mtx invX);
void PSMTXIdentity(Mtx m);
void PSMTXCopy(const Mtx src, Mtx dst);
void PSMTXConcat(const Mtx a, const Mtx b, Mtx ab);
void PSMTXConcatArray(const Mtx a, const Mtx* srcBase, Mtx* dstBase, u32 count);
void PSMTXTranspose(const Mtx src, Mtx xPose);
u32 PSMTXInverse(const Mtx src, Mtx inv);
u32 PSMTXInvXpose(const Mtx src, Mtx invX);
void C_MTXMultVec(const Mtx m, const Vec* src, Vec* dst);
void C_MTXMultVecArray(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void C_MTXMultVecSR(const Mtx m, const Vec* src, Vec* dst);
void C_MTXMultVecArraySR(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXMultVec(const Mtx m, const Vec* src, Vec* dst);
void PSMTXMultVecArray(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXMultVecSR(const Mtx m, const Vec* src, Vec* dst);
void PSMTXMultVecArraySR(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void C_MTXQuat(Mtx m, const Quaternion* q);
void C_MTXReflect(Mtx m, const Vec* p, const Vec* n);
void C_MTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void C_MTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void C_MTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void C_MTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void C_MTXRotRad(Mtx m, char axis, f32 rad);
void C_MTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void C_MTXRotAxisRad(Mtx m, const Vec* axis, f32 rad);
void PSMTXQuat(Mtx m, const Quaternion* q);
void PSMTXReflect(Mtx m, const Vec* p, const Vec* n);
void PSMTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void PSMTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void PSMTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void PSMTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void PSMTXRotRad(Mtx m, char axis, f32 rad);
void PSMTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void PSMTXRotAxisRad(register Mtx m, const Vec* axis, register f32 rad);
void C_MTXLookAt(Mtx m, const Point3d* camPos, const Vec* camUp, const Point3d* target);
void C_MTXFrustum(Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTXPerspective(Mtx44 m, f32 fovY, f32 aspect, f32 n, f32 f);
void C_MTXOrtho(Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTXLightFrustum(Mtx m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 scaleS, f32 scaleT, f32 transS,
f32 transT);
void C_MTXLightPerspective(Mtx m, f32 fovY, f32 aspect, f32 scaleS, f32 scaleT, f32 transS,
f32 transT);
void C_MTXLightOrtho(Mtx m, f32 t, f32 b, f32 l, f32 r, f32 scaleS, f32 scaleT, f32 transS,
f32 transT);
void C_VECAdd(const Vec* a, const Vec* b, Vec* ab);
void C_VECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void C_VECScale(const Vec* src, Vec* dst, f32 scale);
void C_VECNormalize(const Vec* src, Vec* unit);
f32 C_VECSquareMag(const Vec* v);
f32 C_VECMag(const Vec* v);
f32 C_VECDotProduct(const Vec* a, const Vec* b);
void C_VECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
f32 C_VECSquareDistance(const Vec* a, const Vec* b);
f32 C_VECDistance(const Vec* a, const Vec* b);
void C_VECReflect(const Vec* src, const Vec* normal, Vec* dst);
void C_VECHalfAngle(const Vec* a, const Vec* b, Vec* half);
void PSVECAdd(const Vec* a, const Vec* b, Vec* ab);
void PSVECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void PSVECScale(const Vec* src, Vec* dst, f32 scale);
void PSVECNormalize(const Vec* src, Vec* unit);
f32 PSVECSquareMag(const Vec* v);
f32 PSVECMag(const Vec* v);
f32 PSVECDotProduct(const Vec* a, const Vec* b);
void PSVECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
f32 PSVECSquareDistance(const Vec* a, const Vec* b);
f32 PSVECDistance(const Vec* a, const Vec* b);
void C_QUATAdd(const Quaternion* p, const Quaternion* q, Quaternion* r);
void C_QUATSubtract(const Quaternion* p, const Quaternion* q, Quaternion* r);
void C_QUATMultiply(const Quaternion* p, const Quaternion* q, Quaternion* pq);
void C_QUATDivide(const Quaternion* p, const Quaternion* q, Quaternion* r);
void C_QUATScale(const Quaternion* q, Quaternion* r, f32 scale);
f32 C_QUATDotProduct(const Quaternion* p, const Quaternion* q);
void C_QUATNormalize(const Quaternion* src, Quaternion* unit);
void C_QUATInverse(const Quaternion* src, Quaternion* inv);
void C_QUATExp(const Quaternion* q, Quaternion* r);
void C_QUATLogN(const Quaternion* q, Quaternion* r);
void C_QUATMakeClosest(const Quaternion* q, const Quaternion* qto, Quaternion* r);
void C_QUATRotAxisRad(Quaternion* r, const Vec* axis, f32 rad);
void C_QUATMtx(Quaternion* r, const Mtx m);
void C_QUATLerp(const Quaternion* p, const Quaternion* q, Quaternion* r, f32 t);
void C_QUATSlerp(const Quaternion* p, const Quaternion* q, Quaternion* r, f32 t);
void C_QUATSquad(const Quaternion* p, const Quaternion* a, const Quaternion* b, const Quaternion* q,
Quaternion* r, f32 t);
void C_QUATCompA(const Quaternion* qprev, const Quaternion* q, const Quaternion* qnext,
Quaternion* a);
void PSQUATAdd(const Quaternion* p, const Quaternion* q, Quaternion* r);
void PSQUATSubtract(const Quaternion* p, const Quaternion* q, Quaternion* r);
void PSQUATMultiply(const Quaternion* p, const Quaternion* q, Quaternion* pq);
void PSQUATDivide(const Quaternion* p, const Quaternion* q, Quaternion* r);
void PSQUATScale(const Quaternion* q, Quaternion* r, f32 scale);
f32 PSQUATDotProduct(const Quaternion* p, const Quaternion* q);
void PSQUATNormalize(const Quaternion* src, Quaternion* unit);
void PSQUATInverse(const Quaternion* src, Quaternion* inv);
void PSMTXReorder(const Mtx src, ROMtx dest);
void PSMTXROMultVecArray(const ROMtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXROSkin2VecArray(const ROMtx m0, const ROMtx m1, const f32* wtBase, const Vec* srcBase,
Vec* dstBase, u32 count);
void PSMTXMultS16VecArray(const Mtx m, const S16Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXROMultS16VecArray(const ROMtx m, const S16Vec* srcBase, Vec* dstBase, u32 count);
void MTXInitStack(MtxStack* sPtr, u32 numMtx);
MtxPtr MTXPush(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPushFwd(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPushInv(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPushInvXpose(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPop(MtxStack* sPtr);
MtxPtr MTXGetStackPtr(const MtxStack* sPtr);
u32 VIGetNextField(void);
u32 VIGetRetraceCount();
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void __VIGetCurrentPosition(s16* x, s16* y);
u32 VIGetDTVStatus(void);
void VIInit(void);
void VIConfigure(const GXRenderModeObj* rm);
void VIFlush(void);
u32 VIGetTvFormat(void);
void VISetNextFrameBuffer(void* fb);
void VIWaitForRetrace(void);
void VISetBlack(BOOL black);
void VIConfigurePan(u16 xOrg, u16 yOrg, u16 width, u16 height);
typedef void (*AISCallback)(u32 count);
typedef void (*AIDCallback)();
AIDCallback AIRegisterDMACallback(AIDCallback callback);
void AIInitDMA(u32 start_addr, u32 length);
BOOL AIGetDMAEnableFlag();
void AIStartDMA();
void AIStopDMA();
u32 AIGetDMABytesLeft();
u32 AIGetDMAStartAddr();
u32 AIGetDMALength();
u32 AIGetDSPSampleRate();
void AISetDSPSampleRate(u32 rate);
AISCallback AIRegisterStreamCallback(AISCallback callback);
u32 AIGetStreamSampleCount();
void AIResetStreamSampleCount();
void AISetStreamTrigger(u32 trigger);
u32 AIGetStreamTrigger();
void AISetStreamPlayState(u32 state);
u32 AIGetStreamPlayState();
void AISetStreamSampleRate(u32 rate);
u32 AIGetStreamSampleRate();
void AISetStreamVolLeft(u8 vol);
void AISetStreamVolRight(u8 vol);
u8 AIGetStreamVolLeft();
u8 AIGetStreamVolRight();
void AIInit(u8* stack);
BOOL AICheckInit();
void AIReset();
typedef void (*ARCallback)(void);
ARCallback ARRegisterDMACallback(ARCallback callback);
u32 ARGetDMAStatus(void);
void ARStartDMA(u32 type, u32 mainmem_addr, u32 aram_addr, u32 length);
u32 ARInit(u32* stack_index_addr, u32 num_entries);
u32 ARGetBaseAddress(void);
BOOL ARCheckInit(void);
void ARReset(void);
u32 ARAlloc(u32 length);
u32 ARFree(u32* length);
u32 ARGetSize(void);
u32 ARGetInternalSize(void);
void ARSetSize(void);
void ARClear(u32 flag);
void __ARClearInterrupt(void);
u16 __ARGetInterruptStatus(void);
typedef void (*ARQCallback)(u32 pointerToARQRequest);
typedef struct ARQRequest {
struct ARQRequest* next;
u32 owner;
u32 type;
u32 priority;
u32 source;
u32 dest;
u32 length;
ARQCallback callback;
} ARQRequest;
void ARQInit(void);
void ARQReset(void);
void ARQPostRequest(ARQRequest* task, u32 owner, u32 type, u32 priority, u32 source, u32 dest,
u32 length, ARQCallback callback);
void ARQRemoveRequest(ARQRequest* task);
void ARQRemoveOwnerRequest(u32 owner);
void ARQFlushQueue(void);
void ARQSetChunkSize(u32 size);
u32 ARQGetChunkSize(void);
BOOL ARQCheckInit(void);
typedef void (*DSPCallback)(void* task);
typedef struct STRUCT_DSP_TASK {
vu32 state;
vu32 priority;
vu32 flags;
u16* iram_mmem_addr;
u32 iram_length;
u32 iram_addr;
u16* dram_mmem_addr;
u32 dram_length;
u32 dram_addr;
u16 dsp_init_vector;
u16 dsp_resume_vector;
DSPCallback init_cb;
DSPCallback res_cb;
DSPCallback done_cb;
DSPCallback req_cb;
struct STRUCT_DSP_TASK* next;
struct STRUCT_DSP_TASK* prev;
OSTime t_context;
OSTime t_task;
} DSPTaskInfo;
void DSPInit();
void DSPReset();
void DSPHalt();
void DSPSendMailToDSP(u32 mail);
u32 DSPCheckMailToDSP();
u32 DSPCheckMailFromDSP();
u32 DSPGetDMAStatus();
DSPTaskInfo* DSPAddTask(DSPTaskInfo* task);
void __DSP_exec_task(DSPTaskInfo* curr, DSPTaskInfo* next);
void __DSP_boot_task(DSPTaskInfo* task);
void __DSP_insert_task(DSPTaskInfo* task);
void __DSP_remove_task(DSPTaskInfo* task);
void __DSP_add_task(DSPTaskInfo* task);
void __DSP_debug_printf(const char* fmt, ...);
typedef struct CARDFileInfo {
s32 chan;
s32 fileNo;
s32 offset;
s32 length;
u16 iBlock;
u16 __padding;
} CARDFileInfo;
typedef struct CARDStat {
char fileName[32 ];
u32 length;
u32 time;
u8 gameName[4];
u8 company[2];
u8 bannerFormat;
u8 __padding;
u32 iconAddr;
u16 iconFormat;
u16 iconSpeed;
u32 commentAddr;
u32 offsetBanner;
u32 offsetBannerTlut;
u32 offsetIcon[8 ];
u32 offsetIconTlut;
u32 offsetData;
} CARDStat;
typedef void (*CARDCallback)(s32 chan, s32 result);
void CARDInit(void);
BOOL CARDGetFastMode(void);
BOOL CARDSetFastMode(BOOL enable);
s32 CARDCheck(s32 chan);
s32 CARDCheckAsync(s32 chan, CARDCallback callback);
s32 CARDCheckEx(s32 chan, s32* xferBytes);
s32 CARDCheckExAsync(s32 chan, s32* xferBytes, CARDCallback callback);
s32 CARDCreate(s32 chan, const char* fileName, u32 size, CARDFileInfo* fileInfo);
s32 CARDCreateAsync(s32 chan, const char* fileName, u32 size, CARDFileInfo* fileInfo,
CARDCallback callback);
s32 CARDDelete(s32 chan, const char* fileName);
s32 CARDDeleteAsync(s32 chan, const char* fileName, CARDCallback callback);
s32 CARDFastDelete(s32 chan, s32 fileNo);
s32 CARDFastDeleteAsync(s32 chan, s32 fileNo, CARDCallback callback);
s32 CARDFastOpen(s32 chan, s32 fileNo, CARDFileInfo* fileInfo);
s32 CARDFormat(s32 chan);
s32 CARDFormatAsync(s32 chan, CARDCallback callback);
s32 CARDFreeBlocks(s32 chan, s32* byteNotUsed, s32* filesNotUsed);
s32 CARDGetAttributes(s32 chan, s32 fileNo, u8* attr);
s32 CARDGetEncoding(s32 chan, u16* encode);
s32 CARDGetMemSize(s32 chan, u16* size);
s32 CARDGetResultCode(s32 chan);
s32 CARDGetSectorSize(s32 chan, u32* size);
s32 CARDGetSerialNo(s32 chan, u64* serialNo);
s32 CARDGetStatus(s32 chan, s32 fileNo, CARDStat* stat);
s32 CARDGetXferredBytes(s32 chan);
s32 CARDMount(s32 chan, void* workArea, CARDCallback detachCallback);
s32 CARDMountAsync(s32 chan, void* workArea, CARDCallback detachCallback,
CARDCallback attachCallback);
s32 CARDOpen(s32 chan, const char* fileName, CARDFileInfo* fileInfo);
BOOL CARDProbe(s32 chan);
s32 CARDProbeEx(s32 chan, s32* memSize, s32* sectorSize);
s32 CARDRename(s32 chan, const char* oldName, const char* newName);
s32 CARDRenameAsync(s32 chan, const char* oldName, const char* newName, CARDCallback callback);
s32 CARDSetAttributesAsync(s32 chan, s32 fileNo, u8 attr, CARDCallback callback);
s32 CARDSetAttributes(s32 chan, s32 fileNo, u8 attr);
s32 CARDSetStatus(s32 chan, s32 fileNo, CARDStat* stat);
s32 CARDSetStatusAsync(s32 chan, s32 fileNo, CARDStat* stat, CARDCallback callback);
s32 CARDUnmount(s32 chan);
s32 CARDGetCurrentMode(s32 chan, u32* mode);
s32 CARDCancel(CARDFileInfo* fileInfo);
s32 CARDClose(CARDFileInfo* fileInfo);
s32 CARDRead(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset);
s32 CARDReadAsync(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset,
CARDCallback callback);
s32 CARDWrite(CARDFileInfo* fileInfo, const void* addr, s32 length, s32 offset);
s32 CARDWriteAsync(CARDFileInfo* fileInfo, const void* addr, s32 length, s32 offset,
CARDCallback callback);
s32 _CheckFlag(u32 flag);
void _SetFlag(u32 flag);
void _ClearFlag(u32 flag);
void _InitFlag(void);
extern void HuPadRumbleAllStop(void);
typedef struct player_config {
s16 character;
s16 pad_idx;
s16 diff;
s16 group;
s16 iscom;
} PlayerConfig;
typedef struct system_state {
struct {
u8 party : 1;
u8 team : 1;
};
u8 diff_story;
struct {
u16 bonus_star : 1;
u16 explain_mg : 1;
u16 show_com_mg : 1;
u16 mg_list : 2;
u16 mess_speed : 2;
u16 save_mode : 2;
};
u8 turn;
u8 max_turn;
u8 star_flag;
u8 star_total;
struct {
u8 star_pos : 3;
u8 board : 5;
};
s8 last5_effect;
s8 player_curr;
u8 storyCharBit;
s8 storyChar;
s16 block_pos;
u8 __attribute__((aligned(4))) board_data[32];
u8 mess_delay;
struct {
u8 bowser_loss : 4;
u8 bowser_event : 4;
};
s8 lucky_value;
u16 mg_next;
s16 mg_type;
u16 unk_38;
u8 flag[3][16];
u8 unk_6A[0x72];
} SystemState;
typedef struct player_state {
struct {
u16 diff : 2;
u16 com : 1;
u16 character : 4;
u16 auto_size : 2;
u16 draw_ticket : 1;
u16 ticket_player : 6;
};
struct {
u8 team : 1;
u8 spark : 1;
u8 player_idx : 2;
};
s8 handicap;
s8 port;
s8 items[3];
struct {
u16 color : 2;
u16 moving : 1;
u16 jump : 1;
u16 show_next : 1;
u16 size : 2;
u16 num_dice : 2;
u16 rank : 2;
u16 bowser_suit : 1;
u16 team_backup : 1;
};
s8 roll;
s16 space_curr;
s16 space_prev;
s16 space_next;
s16 space_shock;
s8 blue_count;
s8 red_count;
s8 question_count;
s8 fortune_count;
s8 bowser_count;
s8 battle_count;
s8 mushroom_count;
s8 warp_count;
s16 coins;
s16 coins_mg;
s16 coins_total;
s16 coins_max;
s16 coins_battle;
s16 coin_collect;
s16 coin_win;
s16 stars;
s16 stars_max;
char unk_2E[2];
} PlayerState;
typedef struct pause_backup_config {
u8 explain_mg : 1;
u8 show_com_mg : 1;
u8 mg_list : 2;
u8 mess_speed : 2;
u8 save_mode : 2;
} PauseBackupConfig;
typedef struct game_stat {
s16 unk_00;
u8 language;
u8 sound_mode;
s8 rumble;
u16 total_stars;
OSTime create_time;
u32 mg_custom[2];
u32 mg_avail[2];
u32 mg_record[15];
u8 board_win_count[9][8];
u8 board_play_count[9];
u16 board_max_stars[9];
u16 board_max_coins[9];
u8 present[60];
struct {
u8 story_continue : 1;
u8 party_continue : 1;
u8 open_w06 : 1;
u8 veryHardUnlock : 1;
u8 customPackEnable : 1;
u8 musicAllF : 1;
};
PauseBackupConfig story_pause;
PauseBackupConfig party_pause;
} GameStat;
extern s16 GwLanguage;
extern s16 GwLanguageSave;
extern PlayerConfig GWPlayerCfg[4];
extern PlayerState GWPlayer[4];
extern SystemState GWSystem;
extern GameStat GWGameStat;
static inline s32 GWPlayerCfgGroupGet(s32 player)
{
return GWPlayerCfg[player].group;
}
static inline s32 GWTeamGet(void)
{
return GWSystem.team;
}
static inline s32 GWMGTypeGet(void)
{
return GWSystem.mg_type;
}
static inline void GWMGTypeSet(s32 type)
{
GWSystem.mg_type = type;
}
static inline s32 GWPartyGet(void)
{
return GWSystem.party;
}
static inline void GWLanguageSet(s16 language)
{
GWGameStat.language = language;
}
static inline s32 GWLanguageGet(void)
{
return GWGameStat.language;
}
static inline s32 GWRumbleGet(void)
{
return GWGameStat.rumble;
}
static inline void GWRumbleSet(s32 value)
{
GWGameStat.rumble = value;
if(value == 0) {
HuPadRumbleAllStop();
}
}
static inline s32 GWBonusStarGet(void)
{
return GWSystem.bonus_star;
}
static inline s32 GWMGExplainGet(void)
{
return GWSystem.explain_mg;
}
static inline void GWMGExplainSet(s32 value)
{
GWSystem.explain_mg = value;
}
static inline s32 GWMGShowComGet(void)
{
return GWSystem.show_com_mg;
}
static inline void GWMGShowComSet(s32 value)
{
GWSystem.show_com_mg = value;
}
static inline s32 GWMGListGet(void)
{
if (GWSystem.mg_list == 3) {
GWSystem.mg_list = 0;
}
return GWSystem.mg_list;
}
static inline void GWMGListSet(s32 value)
{
GWSystem.mg_list = value;
}
static inline s32 GWMessSpeedGet(void)
{
if (GWSystem.mess_speed == 3) {
GWSystem.mess_speed = 1;
}
return GWSystem.mess_speed;
}
static inline void GWMessSpeedSet(s32 value)
{
GWSystem.mess_speed = value;
switch(value) {
case 0:
GWSystem.mess_delay = 16;
break;
case 2:
GWSystem.mess_delay = 48;
break;
default:
GWSystem.mess_delay = 32;
break;
}
}
static inline void GWSaveModeSet(s32 value)
{
GWSystem.save_mode = value;
}
static inline s32 GWSaveModeGet(void)
{
if (GWSystem.save_mode == 3) {
GWSaveModeSet(1);
}
return GWSystem.save_mode;
}
static inline s32 GWBoardGet(void)
{
return GWSystem.board;
}
static inline s32 GWPlayerCurrGet(void)
{
return GWSystem.player_curr;
}
static inline s32 GWStoryCharGet(void)
{
return GWSystem.storyChar;
}
static inline void GWStoryCharSet(s32 storyChar)
{
GWSystem.storyChar = storyChar;
}
static inline s32 GWPlayerTeamGet(s32 player)
{
return GWPlayer[player].team;
}
static inline s32 GWPlayerHandicapGet(s32 player)
{
return GWPlayer[player].handicap;
}
static inline s32 GWLuckyValueGet(void)
{
return GWSystem.lucky_value;
}
static inline void GWLuckyValueSet(s32 value)
{
GWSystem.lucky_value = value;
}
static inline s16 GWPlayerCoinBattleGet(s32 player)
{
return GWPlayer[player].coins_battle;
}
static inline s16 GWPlayerCoinCollectGet(s32 player)
{
return GWPlayer[player].coin_collect;
}
static inline void GWPlayerCoinCollectSet(s32 player, s16 value)
{
GWPlayer[player].coin_collect = value;
}
static inline s16 GWPlayerCoinWinGet(s32 player)
{
return GWPlayer[player].coin_win;
}
static inline void GWPlayerCoinWinSet(s32 player, s16 value)
{
if (_CheckFlag((((1) << 16)|(12)) ) == 0) {
GWPlayer[player].coin_win = value;
}
}
typedef enum {
HEAP_HEAP,
HEAP_SOUND,
HEAP_MODEL,
HEAP_DVD,
HEAP_SPACE,
HEAP_MAX
} HeapID;
void HuMemInitAll(void);
void *HuMemInit(void *ptr, s32 size);
void HuMemDCFlushAll();
void HuMemDCFlush(HeapID heap);
void *HuMemDirectMalloc(HeapID heap, s32 size);
void *HuMemDirectMallocNum(HeapID heap, s32 size, u32 num);
void HuMemDirectFree(void *ptr);
void HuMemDirectFreeNum(HeapID heap, u32 num);
s32 HuMemUsedMallocSizeGet(HeapID heap);
s32 HuMemUsedMallocBlockGet(HeapID heap);
u32 HuMemHeapSizeGet(HeapID heap);
void *HuMemHeapPtrGet(HeapID heap);
void *HuMemHeapInit(void *ptr, s32 size);
void *HuMemMemoryAlloc(void *heap_ptr, s32 size, u32 retaddr);
void *HuMemMemoryAllocNum(void *heap_ptr, s32 size, u32 num, u32 retaddr);
void HuMemMemoryFree(void *ptr, u32 retaddr);
void HuMemMemoryFreeNum(void *heap_ptr, u32 num, u32 retaddr);
s32 HuMemUsedMemorySizeGet(void *heap_ptr);
s32 HuMemUsedMemoryBlockGet(void *heap_ptr);
s32 HuMemMemorySizeGet(void *ptr);
s32 HuMemMemoryAllocSizeGet(s32 size);
void HuMemHeapDump(void *heap_ptr, s16 status);
typedef struct HuDataStat_s HUDATASTAT;
typedef struct file_list_entry {
char *name;
s32 entryNum;
} FileListEntry;
void *HuDvdDataRead(char *path);
void **HuDvdDataReadMulti(char **paths);
void *HuDvdDataReadDirect(char *path, HeapID heap);
void *HuDvdDataFastRead(s32 entrynum);
void *HuDvdDataFastReadNum(s32 entrynum, s32 num);
void *HuDvdDataFastReadAsync(s32 entrynum, HUDATASTAT *stat);
void HuDvdDataClose(void *ptr);
void HuDvdErrorWatch();
enum {
DATADIR_ID_E3SETUP,
DATADIR_ID_BBATTLE,
DATADIR_ID_BGUEST,
DATADIR_ID_BKOOPA,
DATADIR_ID_BKOOPASUIT,
DATADIR_ID_BKUJIYA,
DATADIR_ID_BLAST5,
DATADIR_ID_BOARD,
DATADIR_ID_BPAUSE,
DATADIR_ID_BYOKODORI,
DATADIR_ID_DAISY,
DATADIR_ID_DAISYMDL0,
DATADIR_ID_DAISYMDL1,
DATADIR_ID_DAISYMOT,
DATADIR_ID_DONKEY,
DATADIR_ID_DONKEYMDL0,
DATADIR_ID_DONKEYMDL1,
DATADIR_ID_DONKEYMOT,
DATADIR_ID_EFFECT,
DATADIR_ID_GAMEMES,
DATADIR_ID_INST,
DATADIR_ID_INSTFONT,
DATADIR_ID_INSTPIC,
DATADIR_ID_LUIGI,
DATADIR_ID_LUIGIMDL0,
DATADIR_ID_LUIGIMDL1,
DATADIR_ID_LUIGIMOT,
DATADIR_ID_M300,
DATADIR_ID_M302,
DATADIR_ID_M303,
DATADIR_ID_M330,
DATADIR_ID_M333,
DATADIR_ID_M401,
DATADIR_ID_M402,
DATADIR_ID_M403,
DATADIR_ID_M404,
DATADIR_ID_M405,
DATADIR_ID_M406,
DATADIR_ID_M407,
DATADIR_ID_M408,
DATADIR_ID_M409,
DATADIR_ID_M410,
DATADIR_ID_M411,
DATADIR_ID_M412,
DATADIR_ID_M413,
DATADIR_ID_M414,
DATADIR_ID_M415,
DATADIR_ID_M416,
DATADIR_ID_M417,
DATADIR_ID_M418,
DATADIR_ID_M419,
DATADIR_ID_M420,
DATADIR_ID_M421,
DATADIR_ID_M422,
DATADIR_ID_M423,
DATADIR_ID_M424,
DATADIR_ID_M425,
DATADIR_ID_M426,
DATADIR_ID_M427,
DATADIR_ID_M428,
DATADIR_ID_M429,
DATADIR_ID_M430,
DATADIR_ID_M431,
DATADIR_ID_M432,
DATADIR_ID_M433,
DATADIR_ID_M434,
DATADIR_ID_M435,
DATADIR_ID_M436,
DATADIR_ID_M437,
DATADIR_ID_M438,
DATADIR_ID_M439,
DATADIR_ID_M440,
DATADIR_ID_M441,
DATADIR_ID_M442,
DATADIR_ID_M443,
DATADIR_ID_M444,
DATADIR_ID_M445,
DATADIR_ID_M446,
DATADIR_ID_M447,
DATADIR_ID_M448,
DATADIR_ID_M449,
DATADIR_ID_M450,
DATADIR_ID_M451,
DATADIR_ID_M453,
DATADIR_ID_M455,
DATADIR_ID_M456,
DATADIR_ID_M457,
DATADIR_ID_M458,
DATADIR_ID_M459,
DATADIR_ID_M460,
DATADIR_ID_M461,
DATADIR_ID_M462,
DATADIR_ID_MARIO,
DATADIR_ID_MARIOMDL0,
DATADIR_ID_MARIOMDL1,
DATADIR_ID_MARIOMOT,
DATADIR_ID_MENT,
DATADIR_ID_MGCONST,
DATADIR_ID_MGMODE,
DATADIR_ID_MODESEL,
DATADIR_ID_MPEX,
DATADIR_ID_MSTORY,
DATADIR_ID_MSTORY2,
DATADIR_ID_MSTORY3,
DATADIR_ID_MSTORY4,
DATADIR_ID_OPTION,
DATADIR_ID_PEACH,
DATADIR_ID_PEACHMDL0,
DATADIR_ID_PEACHMDL1,
DATADIR_ID_PEACHMOT,
DATADIR_ID_PRESENT,
DATADIR_ID_RESULT,
DATADIR_ID_SAF,
DATADIR_ID_SELMENU,
DATADIR_ID_SETUP,
DATADIR_ID_STAFF,
DATADIR_ID_TITLE,
DATADIR_ID_W01,
DATADIR_ID_W02,
DATADIR_ID_W03,
DATADIR_ID_W04,
DATADIR_ID_W05,
DATADIR_ID_W06,
DATADIR_ID_W10,
DATADIR_ID_W20,
DATADIR_ID_W21,
DATADIR_ID_WALUIGI,
DATADIR_ID_WALUIGIMDL0,
DATADIR_ID_WALUIGIMDL1,
DATADIR_ID_WALUIGIMOT,
DATADIR_ID_WARIO,
DATADIR_ID_WARIOMDL0,
DATADIR_ID_WARIOMDL1,
DATADIR_ID_WARIOMOT,
DATADIR_ID_WIN,
DATADIR_ID_YOSHI,
DATADIR_ID_YOSHIMDL0,
DATADIR_ID_YOSHIMDL1,
DATADIR_ID_YOSHIMOT,
DATADIR_ID_ZTAR,
DATADIR_ID_MAX
};
enum {
DATADIR_E3SETUP = (DATADIR_ID_E3SETUP) << 16,
DATADIR_BBATTLE = (DATADIR_ID_BBATTLE) << 16,
DATADIR_BGUEST = (DATADIR_ID_BGUEST) << 16,
DATADIR_BKOOPA = (DATADIR_ID_BKOOPA) << 16,
DATADIR_BKOOPASUIT = (DATADIR_ID_BKOOPASUIT) << 16,
DATADIR_BKUJIYA = (DATADIR_ID_BKUJIYA) << 16,
DATADIR_BLAST5 = (DATADIR_ID_BLAST5) << 16,
DATADIR_BOARD = (DATADIR_ID_BOARD) << 16,
DATADIR_BPAUSE = (DATADIR_ID_BPAUSE) << 16,
DATADIR_BYOKODORI = (DATADIR_ID_BYOKODORI) << 16,
DATADIR_DAISY = (DATADIR_ID_DAISY) << 16,
DATADIR_DAISYMDL0 = (DATADIR_ID_DAISYMDL0) << 16,
DATADIR_DAISYMDL1 = (DATADIR_ID_DAISYMDL1) << 16,
DATADIR_DAISYMOT = (DATADIR_ID_DAISYMOT) << 16,
DATADIR_DONKEY = (DATADIR_ID_DONKEY) << 16,
DATADIR_DONKEYMDL0 = (DATADIR_ID_DONKEYMDL0) << 16,
DATADIR_DONKEYMDL1 = (DATADIR_ID_DONKEYMDL1) << 16,
DATADIR_DONKEYMOT = (DATADIR_ID_DONKEYMOT) << 16,
DATADIR_EFFECT = (DATADIR_ID_EFFECT) << 16,
DATADIR_GAMEMES = (DATADIR_ID_GAMEMES) << 16,
DATADIR_INST = (DATADIR_ID_INST) << 16,
DATADIR_INSTFONT = (DATADIR_ID_INSTFONT) << 16,
DATADIR_INSTPIC = (DATADIR_ID_INSTPIC) << 16,
DATADIR_LUIGI = (DATADIR_ID_LUIGI) << 16,
DATADIR_LUIGIMDL0 = (DATADIR_ID_LUIGIMDL0) << 16,
DATADIR_LUIGIMDL1 = (DATADIR_ID_LUIGIMDL1) << 16,
DATADIR_LUIGIMOT = (DATADIR_ID_LUIGIMOT) << 16,
DATADIR_M300 = (DATADIR_ID_M300) << 16,
DATADIR_M302 = (DATADIR_ID_M302) << 16,
DATADIR_M303 = (DATADIR_ID_M303) << 16,
DATADIR_M330 = (DATADIR_ID_M330) << 16,
DATADIR_M333 = (DATADIR_ID_M333) << 16,
DATADIR_M401 = (DATADIR_ID_M401) << 16,
DATADIR_M402 = (DATADIR_ID_M402) << 16,
DATADIR_M403 = (DATADIR_ID_M403) << 16,
DATADIR_M404 = (DATADIR_ID_M404) << 16,
DATADIR_M405 = (DATADIR_ID_M405) << 16,
DATADIR_M406 = (DATADIR_ID_M406) << 16,
DATADIR_M407 = (DATADIR_ID_M407) << 16,
DATADIR_M408 = (DATADIR_ID_M408) << 16,
DATADIR_M409 = (DATADIR_ID_M409) << 16,
DATADIR_M410 = (DATADIR_ID_M410) << 16,
DATADIR_M411 = (DATADIR_ID_M411) << 16,
DATADIR_M412 = (DATADIR_ID_M412) << 16,
DATADIR_M413 = (DATADIR_ID_M413) << 16,
DATADIR_M414 = (DATADIR_ID_M414) << 16,
DATADIR_M415 = (DATADIR_ID_M415) << 16,
DATADIR_M416 = (DATADIR_ID_M416) << 16,
DATADIR_M417 = (DATADIR_ID_M417) << 16,
DATADIR_M418 = (DATADIR_ID_M418) << 16,
DATADIR_M419 = (DATADIR_ID_M419) << 16,
DATADIR_M420 = (DATADIR_ID_M420) << 16,
DATADIR_M421 = (DATADIR_ID_M421) << 16,
DATADIR_M422 = (DATADIR_ID_M422) << 16,
DATADIR_M423 = (DATADIR_ID_M423) << 16,
DATADIR_M424 = (DATADIR_ID_M424) << 16,
DATADIR_M425 = (DATADIR_ID_M425) << 16,
DATADIR_M426 = (DATADIR_ID_M426) << 16,
DATADIR_M427 = (DATADIR_ID_M427) << 16,
DATADIR_M428 = (DATADIR_ID_M428) << 16,
DATADIR_M429 = (DATADIR_ID_M429) << 16,
DATADIR_M430 = (DATADIR_ID_M430) << 16,
DATADIR_M431 = (DATADIR_ID_M431) << 16,
DATADIR_M432 = (DATADIR_ID_M432) << 16,
DATADIR_M433 = (DATADIR_ID_M433) << 16,
DATADIR_M434 = (DATADIR_ID_M434) << 16,
DATADIR_M435 = (DATADIR_ID_M435) << 16,
DATADIR_M436 = (DATADIR_ID_M436) << 16,
DATADIR_M437 = (DATADIR_ID_M437) << 16,
DATADIR_M438 = (DATADIR_ID_M438) << 16,
DATADIR_M439 = (DATADIR_ID_M439) << 16,
DATADIR_M440 = (DATADIR_ID_M440) << 16,
DATADIR_M441 = (DATADIR_ID_M441) << 16,
DATADIR_M442 = (DATADIR_ID_M442) << 16,
DATADIR_M443 = (DATADIR_ID_M443) << 16,
DATADIR_M444 = (DATADIR_ID_M444) << 16,
DATADIR_M445 = (DATADIR_ID_M445) << 16,
DATADIR_M446 = (DATADIR_ID_M446) << 16,
DATADIR_M447 = (DATADIR_ID_M447) << 16,
DATADIR_M448 = (DATADIR_ID_M448) << 16,
DATADIR_M449 = (DATADIR_ID_M449) << 16,
DATADIR_M450 = (DATADIR_ID_M450) << 16,
DATADIR_M451 = (DATADIR_ID_M451) << 16,
DATADIR_M453 = (DATADIR_ID_M453) << 16,
DATADIR_M455 = (DATADIR_ID_M455) << 16,
DATADIR_M456 = (DATADIR_ID_M456) << 16,
DATADIR_M457 = (DATADIR_ID_M457) << 16,
DATADIR_M458 = (DATADIR_ID_M458) << 16,
DATADIR_M459 = (DATADIR_ID_M459) << 16,
DATADIR_M460 = (DATADIR_ID_M460) << 16,
DATADIR_M461 = (DATADIR_ID_M461) << 16,
DATADIR_M462 = (DATADIR_ID_M462) << 16,
DATADIR_MARIO = (DATADIR_ID_MARIO) << 16,
DATADIR_MARIOMDL0 = (DATADIR_ID_MARIOMDL0) << 16,
DATADIR_MARIOMDL1 = (DATADIR_ID_MARIOMDL1) << 16,
DATADIR_MARIOMOT = (DATADIR_ID_MARIOMOT) << 16,
DATADIR_MENT = (DATADIR_ID_MENT) << 16,
DATADIR_MGCONST = (DATADIR_ID_MGCONST) << 16,
DATADIR_MGMODE = (DATADIR_ID_MGMODE) << 16,
DATADIR_MODESEL = (DATADIR_ID_MODESEL) << 16,
DATADIR_MPEX = (DATADIR_ID_MPEX) << 16,
DATADIR_MSTORY = (DATADIR_ID_MSTORY) << 16,
DATADIR_MSTORY2 = (DATADIR_ID_MSTORY2) << 16,
DATADIR_MSTORY3 = (DATADIR_ID_MSTORY3) << 16,
DATADIR_MSTORY4 = (DATADIR_ID_MSTORY4) << 16,
DATADIR_OPTION = (DATADIR_ID_OPTION) << 16,
DATADIR_PEACH = (DATADIR_ID_PEACH) << 16,
DATADIR_PEACHMDL0 = (DATADIR_ID_PEACHMDL0) << 16,
DATADIR_PEACHMDL1 = (DATADIR_ID_PEACHMDL1) << 16,
DATADIR_PEACHMOT = (DATADIR_ID_PEACHMOT) << 16,
DATADIR_PRESENT = (DATADIR_ID_PRESENT) << 16,
DATADIR_RESULT = (DATADIR_ID_RESULT) << 16,
DATADIR_SAF = (DATADIR_ID_SAF) << 16,
DATADIR_SELMENU = (DATADIR_ID_SELMENU) << 16,
DATADIR_SETUP = (DATADIR_ID_SETUP) << 16,
DATADIR_STAFF = (DATADIR_ID_STAFF) << 16,
DATADIR_TITLE = (DATADIR_ID_TITLE) << 16,
DATADIR_W01 = (DATADIR_ID_W01) << 16,
DATADIR_W02 = (DATADIR_ID_W02) << 16,
DATADIR_W03 = (DATADIR_ID_W03) << 16,
DATADIR_W04 = (DATADIR_ID_W04) << 16,
DATADIR_W05 = (DATADIR_ID_W05) << 16,
DATADIR_W06 = (DATADIR_ID_W06) << 16,
DATADIR_W10 = (DATADIR_ID_W10) << 16,
DATADIR_W20 = (DATADIR_ID_W20) << 16,
DATADIR_W21 = (DATADIR_ID_W21) << 16,
DATADIR_WALUIGI = (DATADIR_ID_WALUIGI) << 16,
DATADIR_WALUIGIMDL0 = (DATADIR_ID_WALUIGIMDL0) << 16,
DATADIR_WALUIGIMDL1 = (DATADIR_ID_WALUIGIMDL1) << 16,
DATADIR_WALUIGIMOT = (DATADIR_ID_WALUIGIMOT) << 16,
DATADIR_WARIO = (DATADIR_ID_WARIO) << 16,
DATADIR_WARIOMDL0 = (DATADIR_ID_WARIOMDL0) << 16,
DATADIR_WARIOMDL1 = (DATADIR_ID_WARIOMDL1) << 16,
DATADIR_WARIOMOT = (DATADIR_ID_WARIOMOT) << 16,
DATADIR_WIN = (DATADIR_ID_WIN) << 16,
DATADIR_YOSHI = (DATADIR_ID_YOSHI) << 16,
DATADIR_YOSHIMDL0 = (DATADIR_ID_YOSHIMDL0) << 16,
DATADIR_YOSHIMDL1 = (DATADIR_ID_YOSHIMDL1) << 16,
DATADIR_YOSHIMOT = (DATADIR_ID_YOSHIMOT) << 16,
DATADIR_ZTAR = (DATADIR_ID_ZTAR) << 16,
};
struct HuDataStat_s {
s32 dirId;
void *dirP;
void *fileDataP;
u32 rawLen;
u32 decodeType;
BOOL used;
s32 num;
u32 status;
DVDFileInfo dvdFile;
};
void HuDataInit(void);
s32 HuDataReadChk(s32 dirNum);
HUDATASTAT *HuDataGetStatus(void *dirP);
void *HuDataGetDirPtr(s32 dirNum);
HUDATASTAT *HuDataDirRead(s32 dataNum);
HUDATASTAT *HuDataDirSet(void *dirP, s32 dataNum);
void HuDataDirReadAsyncCallBack(s32 result, DVDFileInfo* fileInfo);
s32 HuDataDirReadAsync(s32 dataNum);
s32 HuDataDirReadNumAsync(s32 dataNum, s32 num);
BOOL HuDataGetAsyncStat(s32 statId);
void *HuDataRead(s32 dataNum);
void *HuDataReadNum(s32 dataNum, s32 num);
void *HuDataSelHeapRead(s32 dataNum, HeapID heap);
void *HuDataSelHeapReadNum(s32 dataNum, s32 num, HeapID heap);
void **HuDataReadMulti(s32 *dataNum);
s32 HuDataGetSize(s32 dataNum);
void HuDataClose(void *ptr);
void HuDataCloseMulti(void **ptrs);
void HuDataDirClose(s32 dataNum);
void HuDataDirCloseNum(s32 num);
void *HuDataReadNumHeapShortForce(s32 dataNum, s32 num, HeapID heap);
void HuDecodeData(void *src, void *dst, u32 size, s32 decodeType);
extern u32 DirDataSize;
typedef u32 AMEM_PTR;
void HuARInit(void);
AMEM_PTR HuARMalloc(u32 size);
void HuARFree(AMEM_PTR amemptr);
void HuAMemDump(void);
AMEM_PTR HuAR_DVDtoARAM(u32 dir);
AMEM_PTR HuAR_MRAMtoARAM(s32 dir);
AMEM_PTR HuAR_MRAMtoARAM2(void *dir_ptr);
void HuAR_ARAMtoMRAM(AMEM_PTR amemptr);
void *HuAR_ARAMtoMRAMNum(AMEM_PTR amemptr, s32 num);
s32 HuARDMACheck(void);
AMEM_PTR HuARDirCheck(u32 dir);
void HuARDirFree(u32 dir);
void *HuAR_ARAMtoMRAMFileRead(u32 dir, u32 num, HeapID heap);
typedef struct sndGrpTbl_s {
s16 ovl;
s16 grpSet;
s32 auxANo;
s32 auxBNo;
s8 auxAVol;
s8 auxBVol;
} SNDGRPTBL;
void HuAudInit(void);
s32 HuAudStreamPlay(char *name, BOOL flag);
void HuAudStreamVolSet(s16 vol);
void HuAudStreamPauseOn(void);
void HuAudStreamPauseOff(void);
void HuAudStreamFadeOut(s32 streamNo);
void HuAudAllStop(void);
void HuAudFadeOut(s32 speed);
int HuAudFXPlay(int seId);
int HuAudFXPlayVol(int seId, s16 vol);
int HuAudFXPlayVolPan(int seId, s16 vol, s16 pan);
void HuAudFXStop(int seNo);
void HuAudFXAllStop(void);
void HuAudFXFadeOut(int seNo, s32 speed);
void HuAudFXPanning(int seNo, s16 pan);
void HuAudFXListnerSet(Vec *pos, Vec *heading, float sndDist, float sndSpeed);
void HuAudFXListnerSetEX(Vec *pos, Vec *heading, float sndDist, float sndSpeed, float startDis, float frontSurDis, float backSurDis);
void HuAudFXListnerUpdate(Vec *pos, Vec *heading);
int HuAudFXEmiterPlay(int seId, Vec *pos);
void HuAudFXEmiterUpDate(int seNo, Vec *pos);
void HuAudFXListnerKill(void);
void HuAudFXPauseAll(BOOL pauseF);
s32 HuAudFXStatusGet(int seNo);
s32 HuAudFXPitchSet(int seNo, s16 pitch);
s32 HuAudFXVolSet(int seNo, s16 vol);
s32 HuAudSeqPlay(s16 musId);
void HuAudSeqStop(s32 musNo);
void HuAudSeqFadeOut(s32 musNo, s32 speed);
void HuAudSeqAllFadeOut(s32 speed);
void HuAudSeqAllStop(void);
void HuAudSeqPauseAll(BOOL pause);
void HuAudSeqPause(s32 musNo, s32 pause, s32 speed);
s32 HuAudSeqMidiCtrlGet(s32 musNo, s8 channel, s8 ctrl);
s32 HuAudSStreamPlay(s16 streamId);
void HuAudSStreamStop(s32 seNo);
void HuAudSStreamFadeOut(s32 seNo, s32 speed);
void HuAudSStreamAllFadeOut(s32 speed);
void HuAudSStreamAllStop(void);
s32 HuAudSStreamStatGet(s32 seNo);
void HuAudDllSndGrpSet(u16 ovl);
void HuAudSndGrpSetSet(s16 grpSet);
void HuAudSndGrpSet(s16 grpId);
void HuAudSndCommonGrpSet(s16 grp, BOOL delGrpF);
void HuAudAUXSet(s32 auxA, s32 auxB);
void HuAudAUXVolSet(s8 volA, s8 volB);
void HuAudSndCharGrpSet(s16 ovl);
s32 PlayerFXPlay(s16 player, s16 seId);
s32 PlayerFXPlayPos(s16 player, s16 seId, Vec *pos);
void PlayerFXStop(s16 player, s16 seId);
s32 CharFXPlay(s16 charNo, s16 seId);
s32 CharFXPlayPos(s16 charNo, s16 seId, Vec *pos);
void CharFXStop(s16 charNo, s16 seId);
extern SNDGRPTBL sndGrpTable[];
extern float Snd3DBackSurDisOffset;
extern float Snd3DFrontSurDisOffset;
extern float Snd3DStartDisOffset;
extern float Snd3DSpeedOffset;
extern float Snd3DDistOffset;
extern BOOL musicOffF;
extern u8 fadeStat;
extern u16 HuPadBtn[4];
extern u16 HuPadBtnDown[4];
extern u16 HuPadBtnRep[4];
extern s8 HuPadStkX[4];
extern s8 HuPadStkY[4];
extern s8 HuPadSubStkX[4];
extern s8 HuPadSubStkY[4];
extern u8 HuPadTrigL[4];
extern u8 HuPadTrigR[4];
extern u8 HuPadDStk[4];
extern u8 HuPadDStkRep[4];
extern s8 HuPadErr[4];
extern u16 _PadBtn[4];
extern u16 _PadBtnDown[4];
extern s32 VCounter;
void HuPadInit(void);
void HuPadRead(void);
void HuPadRumbleSet(s16 pad, s16 duration, s16 off, s16 on);
void HuPadRumbleStop(s16 pad);
void HuPadRumbleAllStop(void);
s16 HuPadStatGet(s16 pad);
u32 HuPadRumbleGet(void);
typedef struct jump_buf {
u32 lr;
u32 cr;
u32 sp;
u32 r2;
u32 pad;
u32 regs[19];
double flt_regs[19];
} jmp_buf;
s32 gcsetjmp(jmp_buf *jump);
s32 gclongjmp(jmp_buf *jump, s32 status);
typedef struct Process_s HUPROCESS;
typedef struct Process_s {
HUPROCESS *next;
HUPROCESS *prev;
HUPROCESS *child;
HUPROCESS *parent;
HUPROCESS *next_child;
HUPROCESS *first_child;
void *heap;
u16 exec;
u16 stat;
u16 prio;
s32 sleep_time;
u32 base_sp;
jmp_buf jump;
void (*dtor)(void);
void *user_data;
} HUPROCESS;
void HuPrcInit(void);
void HuPrcEnd(void);
HUPROCESS *HuPrcCreate(void (*func)(void), u16 prio, u32 stack_size, s32 extra_size);
void HuPrcChildLink(HUPROCESS *parent, HUPROCESS *child);
void HuPrcChildUnlink(HUPROCESS *process);
HUPROCESS *HuPrcChildCreate(void (*func)(void), u16 prio, u32 stack_size, s32 extra_size, HUPROCESS *parent);
void HuPrcChildWatch(void);
HUPROCESS *HuPrcCurrentGet(void);
s32 HuPrcKill(HUPROCESS *process);
void HuPrcChildKill(HUPROCESS *process);
void HuPrcSleep(s32 time);
void HuPrcVSleep();
void HuPrcWakeup(HUPROCESS *process);
void HuPrcDestructorSet2(HUPROCESS *process, void (*func)(void));
void HuPrcDestructorSet(void (*func)(void));
void HuPrcCall(s32 tick);
void *HuPrcMemAlloc(s32 size);
void HuPrcMemFree(void *ptr);
void HuPrcSetStat(HUPROCESS *process, u16 value);
void HuPrcResetStat(HUPROCESS *process, u16 value);
void HuPrcAllPause(s32 flag);
void HuPrcAllUPause(s32 flag);
extern int __float_nan[];
extern int __float_huge[];
extern int __double_huge[];
extern inline double sqrt(double x)
{
if (x > 0.0) {
double guess = __frsqrte(x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
return x * guess;
}
else if (x == 0)
return 0;
else if (x)
return (*(float *)__float_nan) ;
return (*(float *)__float_huge) ;
}
extern inline float sqrtf(float x)
{
static const double _half = .5;
static const double _three = 3.0;
volatile float y;
if (x > 0.0f) {
double guess = __frsqrte((double)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (float)(x * guess);
return y;
}
return x;
}
double atan(double x);
double copysign(double x, double y);
double cos(double x);
double floor(double x);
double frexp(double x, int *exp);
double ldexp(double x, int exp);
double modf(double x, double *intpart);
double sin(double x);
double tan(double x);
double acos(double x);
double asin(double x);
double atan2(double y, double x);
double fmod(double x, double y);
double log(double x);
double pow(double x, double y);
float tanf(float x);
extern inline double fabs(double x)
{
return __fabs(x);
}
static inline float fabsf(float x)
{
return (float)fabs((double)x);
}
static inline float sinf(float x)
{
return (float)sin((double)x);
}
static inline float cosf(float x)
{
return (float)cos((double)x);
}
static inline float atan2f(float y, float x)
{
return (float)atan2((double)y, (double)x);
}
static inline float atanf(float x)
{
return (float)atan((double)x);
}
static inline float asinf(float x)
{
return (float)asin((double)x);
}
static inline float acosf(float x)
{
return (float)acos((double)x);
}
static inline float fmodf(float x, float m)
{
return (float)fmod((double)x, (double)m);
}
static inline float floorf(float x)
{
return floor(x);
}
static inline float powf(float __x, float __y)
{
return pow(__x, __y);
}
typedef Vec HuVecF;
typedef struct HuVec2f_s {
float x;
float y;
} HuVec2f;
typedef struct AnimTime_s {
s16 pat;
s16 time;
s16 shiftX;
s16 shiftY;
s16 flip;
s16 pad;
} ANIMFRAME;
typedef struct AnimBank_s {
s16 timeNum;
s16 unk;
ANIMFRAME *frame;
} ANIMBANK;
typedef struct AnimLayer_s {
u8 alpha;
u8 flip;
s16 bmpNo;
s16 startX;
s16 startY;
s16 sizeX;
s16 sizeY;
s16 shiftX;
s16 shiftY;
s16 vtx[8];
} ANIMLAYER;
typedef struct AnimPat_s {
s16 layerNum;
s16 centerX;
s16 centerY;
s16 sizeX;
s16 sizeY;
ANIMLAYER *layer;
} ANIMPAT;
typedef struct AnimBmp_s {
u8 pixSize;
u8 dataFmt;
s16 palNum;
s16 sizeX;
s16 sizeY;
u32 dataSize;
void *palData;
void *data;
} ANIMBMP;
typedef struct AnimData_s {
s16 bankNum;
s16 patNum;
s16 bmpNum;
s16 useNum;
ANIMBANK *bank;
ANIMPAT *pat;
ANIMBMP *bmp;
} ANIMDATA;
typedef struct HuSprite_s HUSPRITE;
typedef s16 HUSPRID;
typedef s16 HUSPRGRPID;
typedef void (*HUSPRFUNC)(HUSPRITE *);
typedef struct HuSprite_s {
u8 r;
u8 g;
u8 b;
u8 drawNo;
s16 animNo;
s16 bank;
s16 attr;
s16 dirty;
s16 prio;
float time;
HuVec2f pos;
float zRot;
HuVec2f scale;
float speed;
float a;
GXTexWrapMode wrapS;
GXTexWrapMode wrapT;
s16 uvScaleX;
s16 uvScaleY;
Mtx *groupMtx;
union {
ANIMDATA *data;
HUSPRFUNC func;
};
ANIMPAT *patP;
ANIMFRAME *frameP;
s16 work[4];
ANIMDATA *bg;
u16 bgBank;
s16 scissorX;
s16 scissorY;
s16 scissorW;
s16 scissorH;
};
typedef struct HuSprGrp_s {
s16 capacity;
HuVec2f pos;
float zRot;
HuVec2f scale;
HuVec2f center;
s16 *members;
Mtx mtx;
} HUSPRGRP;
extern HUSPRITE HuSprData[384 ];
extern HUSPRGRP HuSprGrpData[256 ];
void HuSprInit(void);
void HuSprClose(void);
void HuSprExec(s16 draw_no);
void HuSprBegin(void);
HUSPRITE *HuSprCall(void);
void HuSprFinish(void);
void HuSprPauseSet(BOOL value);
ANIMDATA *HuSprAnimRead(void *data);
void HuSprAnimLock(ANIMDATA *anim);
s16 HuSprCreate(ANIMDATA *anim, s16 prio, s16 bank);
s16 HuSprFuncCreate(HUSPRFUNC func, s16 prio);
s16 HuSprGrpCreate(s16 capacity);
s16 HuSprGrpCopy(s16 group);
void HuSprGrpMemberSet(s16 group, s16 member, s16 sprite);
void HuSprGrpMemberKill(s16 group, s16 member);
void HuSprGrpKill(s16 group);
void HuSprKill(s16 sprite);
void HuSprAnimKill(ANIMDATA *anim);
void HuSprAttrSet(s16 group, s16 member, s32 attr);
void HuSprAttrReset(s16 group, s16 member, s32 attr);
void HuSprPosSet(s16 group, s16 member, float x, float y);
void HuSprZRotSet(s16 group, s16 member, float z_rot);
void HuSprScaleSet(s16 group, s16 member, float x, float y);
void HuSprTPLvlSet(s16 group, s16 member, float tp_lvl);
void HuSprColorSet(s16 group, s16 member, u8 r, u8 g, u8 b);
void HuSprSpeedSet(s16 group, s16 member, float speed);
void HuSprBankSet(s16 group, s16 member, s16 bank);
void HuSprGrpPosSet(s16 group, float x, float y);
void HuSprGrpCenterSet(s16 group, float x, float y);
void HuSprGrpZRotSet(s16 group, float z_rot);
void HuSprGrpScaleSet(s16 group, float x, float y);
void HuSprGrpTPLvlSet(s16 group, float tp_lvl);
void HuSprGrpDrawNoSet(s16 group, s32 draw_no);
void HuSprDrawNoSet(s16 group, s16 member, s32 draw_no);
void HuSprPriSet(s16 group, s16 member, s16 prio);
void HuSprGrpScissorSet(s16 group, s16 x, s16 y, s16 w, s16 h);
void HuSprScissorSet(s16 group, s16 member, s16 x, s16 y, s16 w, s16 h);
ANIMDATA *HuSprAnimMake(s16 sizeX, s16 sizeY, s16 dataFmt);
void HuSprBGSet(s16 group, s16 member, ANIMDATA *bg, s16 bg_bank);
void HuSprSprBGSet(s16 sprite, ANIMDATA *bg, s16 bg_bank);
void AnimDebug(ANIMDATA *anim);
void HuSprDispInit(void);
void HuSprDisp(HUSPRITE *sprite);
void HuSprTexLoad(ANIMDATA *anim, s16 bmp, s16 slot, GXTexWrapMode wrap_s, GXTexWrapMode wrap_t, GXTexFilter filter);
void HuSprExecLayerSet(s16 draw_no, s16 layer);
typedef struct {
u8 color;
u8 fade;
s16 x;
s16 y;
s16 character;
} WinChar;
typedef struct {
u8 stat;
s16 x;
s16 y;
} WinChoice;
typedef struct {
u8 stat;
u8 active_pad;
u8 player_disable;
u8 color_key;
s16 group;
s16 sprite_id[30];
s16 speed;
s16 mess_time;
s16 advance_sprite;
s16 prio;
u32 attr;
ANIMDATA *frame;
s16 mess_rect_x;
s16 mess_rect_w;
s16 mess_rect_y;
s16 mess_rect_h;
s16 mess_x;
s16 mess_y;
s16 mess_color;
s16 mess_shadow_color;
s16 spacing_x;
s16 spacing_y;
s16 w;
s16 h;
float pos_x;
float pos_y;
float scale_x;
float scale_y;
float z_rot;
s16 num_chars;
s16 max_chars;
WinChar *char_data;
s16 mess_stackptr;
s32 unk8C;
u8 *mess;
u8 *mess_stack[8];
u8 *insert_mess[8];
s16 num_choices;
s16 choice;
s16 cursor_sprite;
u8 choice_disable[16];
WinChoice choice_data[16];
s16 scissor_x;
s16 scissor_y;
s16 scissor_w;
s16 scissor_h;
s16 tab_w;
s16 push_key;
s16 key_down;
s16 key_auto;
u8 __attribute__((aligned(32))) mess_pal[10][3];
} WindowData;
extern WindowData winData[32];
extern void *messDataPtr;
void HuWindowInit(void);
void HuWinInit(s32 mess_data_no);
s16 HuWinCreate(float x, float y, s16 w, s16 h, s16 frame);
void HuWinKill(s16 window);
void HuWinAllKill(void);
void HuWinHomeClear(s16 window);
void HuWinKeyWaitEntry(s16 window);
u32 HuWinActivePadGet(WindowData *window);
u32 HuWinActiveKeyGetX(WindowData *window);
void HuWinPosSet(s16 window, float x, float y);
void HuWinScaleSet(s16 window, float x, float y);
void HuWinZRotSet(s16 window, float z_rot);
void HuWinCenterPosSet(s16 window, float x, float y);
void HuWinDrawNoSet(s16 window, s16 draw_no);
void HuWinScissorSet(s16 window, s16 x, s16 y, s16 w, s16 h);
void HuWinPriSet(s16 window, s16 prio);
void HuWinAttrSet(s16 window, u32 attr);
void HuWinAttrReset(s16 window, u32 attr);
s16 HuWinStatGet(s16 window);
void HuWinMesColSet(s16 window, u8 color);
void HuWinMesPalSet(s16 window, u8 index, u8 r, u8 g, u8 b);
void HuWinBGTPLvlSet(s16 window, float tp_level);
void HuWinBGColSet(s16 window, GXColor *bg_color);
void HuWinMesSpeedSet(s16 window, s16 speed);
void HuWinMesRead(s32 mess_data_no);
void HuWinMesSet(s16 window, u32 mess);
void HuWinInsertMesSet(s16 window, u32 mess, s16 index);
s16 HuWinChoiceGet(s16 window, s16 start_choice);
s16 HuWinChoiceNumGet(s16 window);
void HuWinChoiceDisable(s16 window, s16 choice);
s16 HuWinChoiceNowGet(s16 window);
void HuWinMesWait(s16 window);
s16 HuWinAnimSet(s16 window, ANIMDATA *anim, s16 bank, float x, float y);
s16 HuWinSprSet(s16 window, s16 sprite, float x, float y);
void HuWinSprPosSet(s16 window, s16 index, float x, float y);
void HuWinSprPriSet(s16 window, s16 index, s16 prio);
s16 HuWinSprIDGet(s16 window, s16 index);
void HuWinSprKill(s16 window, s16 index);
void HuWinDispOff(s16 window);
void HuWinDispOn(s16 window);
void HuWinComKeyWait(s32 player_1, s32 player_2, s32 player_3, s32 player_4, s16 delay);
void HuWinComKeySet(s32 player_1, s32 player_2, s32 player_3, s32 player_4);
void _HuWinComKeySet(s32 player_1, s32 player_2, s32 player_3, s32 player_4, s16 delay);
void HuWinComKeyGet(s16 window, u32 *data);
void HuWinComKeyReset(void);
void HuWinMesMaxSizeGet(s16 mess_num, float *size, ...);
void HuWinInsertMesSizeGet(u32 mess, s16 index);
void HuWinMesSizeCancelCRSet(s32 cancel_cr);
void HuWinMesMaxSizeBetGet(float *size, u32 start, u32 end);
s16 HuWinKeyWaitNumGet(u32 mess);
void HuWinPushKeySet(s16 window, s16 push_key);
void HuWinDisablePlayerSet(s16 window, u8 player);
void HuWinDisablePlayerReset(s16 window, u8 player);
s16 HuWinExCreate(float x, float y, s16 w, s16 h, s16 portrait);
s16 HuWinExCreateStyled(float x, float y, s16 w, s16 h, s16 portrait, s16 frame);
void HuWinExAnimIn(s16 window);
void HuWinExAnimOut(s16 window);
void HuWinExCleanup(s16 window);
void HuWinExAnimPopIn(s16 window, s16 portrait);
void *MessData_MesPtrGet(void *data, u32 index);
extern void *messDataPtr;
typedef struct vec2f {
float x;
float y;
} Vec2f;
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, unsigned char type);
typedef unsigned long size_t;
void* memcpy(void* dst, const void* src, size_t n);
void* memset(void* dst, int val, size_t n);
char* strrchr(const char* str, int c);
char* strchr(const char* str, int c);
int strncmp(const char* str1, const char* str2, size_t n);
int strcmp(const char* str1, const char* str2);
char* strcat(char* dst, const char* src, size_t n);
char* strncpy(char* dst, const char* src, size_t n);
char* strcpy(char* dst, const char* src);
size_t strlen(const char* str);
enum {
WIN_FONTJ_ANM = ((DATADIR_WIN)+(0)) ,
WIN_FONTE_ANM = ((DATADIR_WIN)+(1)) ,
WIN_CURSOR_ANM = ((DATADIR_WIN)+(2)) ,
WIN_ICON_ANM = ((DATADIR_WIN)+(3)) ,
WIN_CARDA_ANM = ((DATADIR_WIN)+(4)) ,
WIN_CARDB_ANM = ((DATADIR_WIN)+(5)) ,
WIN_FRAME1_ANM = ((DATADIR_WIN)+(6)) ,
WIN_FRAME2_ANM = ((DATADIR_WIN)+(7)) ,
WIN_FRAME3_ANM = ((DATADIR_WIN)+(8)) ,
WIN_W01_HOST_TALK_ANM = ((DATADIR_WIN)+(9)) ,
WIN_W02_HOST_TALK_ANM = ((DATADIR_WIN)+(10)) ,
WIN_W03_HOST_TALK_ANM = ((DATADIR_WIN)+(11)) ,
WIN_W04_HOST_TALK_ANM = ((DATADIR_WIN)+(12)) ,
WIN_W05_HOST_TALK_ANM = ((DATADIR_WIN)+(13)) ,
WIN_W06_HOST_TALK_ANM = ((DATADIR_WIN)+(14)) ,
WIN_TOAD_TALK_ANM = ((DATADIR_WIN)+(15)) ,
WIN_BOBOMB_TALK_ANM = ((DATADIR_WIN)+(16)) ,
WIN_SHYGUY_TALK_ANM = ((DATADIR_WIN)+(17)) ,
WIN_BOO_TALK_ANM = ((DATADIR_WIN)+(18)) ,
WIN_GOOMBA_TALK_ANM = ((DATADIR_WIN)+(19)) ,
WIN_BOWSER_TALK_ANM = ((DATADIR_WIN)+(20)) ,
WIN_KKID_TALK_ANM = ((DATADIR_WIN)+(21)) ,
WIN_KOOPA_TALK_ANM = ((DATADIR_WIN)+(22)) ,
WIN_CONDOR_TALK_ANM = ((DATADIR_WIN)+(23)) ,
WIN_BOO_BLUE_TALK_ANM = ((DATADIR_WIN)+(24)) ,
WIN_DOLPHIN_TALK_ANM = ((DATADIR_WIN)+(25)) ,
WIN_BOO_RED_TALK_ANM = ((DATADIR_WIN)+(26)) ,
WIN_THWOMP_TALK_ANM = ((DATADIR_WIN)+(27)) ,
WIN_CARD_BOX1_ICON_ANM = ((DATADIR_WIN)+(28)) ,
WIN_CARD_BOX2_ICON_ANM = ((DATADIR_WIN)+(29)) ,
WIN_CARD_BOX3_ICON_ANM = ((DATADIR_WIN)+(30)) ,
WIN_CARD_BANNER_ANM = ((DATADIR_WIN)+(31)) ,
WIN_SAVE_BG_ANM = ((DATADIR_WIN)+(32))
};
typedef struct {
ANIMDATA **anim;
s16 bank;
s16 w;
s16 h;
s16 center_x;
s16 center_y;
} spcFontTblData;
typedef struct {
s16 time;
u32 player[4];
} keyBufData;
static void MesDispFunc(HUSPRITE *sprite);
static u8 winBGMake(ANIMDATA *bg, ANIMDATA *frame);
static void HuWinProc(void);
static void HuWinDrawMes(s16 window);
static s32 HuWinCR(WindowData *window);
static void _HuWinHomeClear(WindowData *window);
static void HuWinKeyWait(s16 window);
static s16 HuWinSpcFontEntry(WindowData *window, s16 entry, s16 x, s16 y);
static void HuWinSpcFontClear(WindowData *window);
static void HuWinChoice(WindowData *window);
static void GetMesMaxSizeSub(u32 mess);
static s32 GetMesMaxSizeSub2(WindowData *window, u8 *mess_data);
void mtxTransCat(Mtx, float, float, float);
WindowData __attribute__((aligned(32))) winData[32];
u32 winKey[4];
keyBufData winComKeyBuf[256];
static ANIMDATA *iconAnim;
static ANIMDATA *cursorAnim;
static ANIMDATA *cardAnimA;
static ANIMDATA *cardAnimB;
static HUPROCESS *winProc;
void *messDataPtr;
static s32 messDataNo;
static s16 winMaxWidth;
static s16 winMaxHeight;
static u8 mesWInsert[8];
static u8 winTabSize;
static u8 winInsertF;
static u32 winAMemP;
static u8 *fontWidthP;
static s32 cancelCRF;
static s16 mesCharCnt;
static s16 comKeyIdxNow;
static s16 comKeyIdx;
static u8 LanguageNo;
ANIMDATA *fontAnim;
static spcFontTblData spcFontTbl[] = { { &iconAnim, 0, 20, 24, 10, 12 }, { &iconAnim, 1, 20, 24, 10, 12 }, { &iconAnim, 2, 20, 24, 10, 12 },
{ &iconAnim, 3, 20, 24, 10, 12 }, { &iconAnim, 4, 20, 24, 10, 12 }, { &iconAnim, 5, 20, 24, 10, 12 }, { &iconAnim, 6, 20, 24, 10, 12 },
{ &iconAnim, 7, 20, 24, 10, 12 }, { &iconAnim, 8, 20, 24, 10, 12 }, { &iconAnim, 9, 20, 24, 10, 12 }, { &iconAnim, 10, 20, 24, 10, 12 },
{ &iconAnim, 11, 30, 24, 15, 12 }, { &iconAnim, 12, 20, 24, 10, 12 }, { &iconAnim, 13, 20, 24, 10, 12 }, { &iconAnim, 14, 20, 24, 10, 12 },
{ &iconAnim, 15, 20, 24, 10, 12 }, { &iconAnim, 16, 20, 24, 10, 12 }, { &iconAnim, 17, 20, 24, 10, 12 }, { &iconAnim, 18, 20, 24, 10, 12 },
{ &iconAnim, 19, 24, 24, 12, 12 }, { &cursorAnim, 0, 40, 32, -15, 18 }, { &cardAnimA, 0, 32, 32, 16, 16 }, { &cardAnimB, 0, 32, 32, 16, 16 } };
u8 charWETbl[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 18, 20, 12, 12, 11, 14, 8, 13, 12, 12, 12, 12, 12, 12, 12, 9, 11, 12, 11, 15, 12, 13, 12,
13, 12, 12, 11, 12, 11, 15, 12, 13, 11, 12, 6, 8, 8, 12, 20, 12, 11, 12, 11, 11, 9, 12, 11, 4, 8, 11, 4, 14, 11, 12, 11, 12, 9, 11, 9, 11, 11, 15,
11, 11, 11, 4, 13, 8, 14, 12, 9, 8, 8, 8, 20, 4, 12, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 12, 12, 12, 12, 12, 12, 12, 12, 8, 8, 12, 12, 12, 12,
16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 12, 12, 7, 14,
17, 13, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 16, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20 };
u8 charWJTbl[] = { 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 0, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 0, 0, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20 };
static u8 __attribute__((aligned(32))) charColPal[2 * 3 * 10] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0x00, 0xFF, 0x00, 0xFF, 0x00,
0x00, 0xFF, 0xFF, 0xFF, 0xA0, 0x00, 0xFF, 0xFF, 0xFF, 0x60, 0x60, 0x60, 0x90, 0x90, 0x90, 0x00, 0x00, 0x00, 0x60, 0xB0, 0xFF, 0xFF, 0x40, 0x80,
0xFF, 0x00, 0xFF, 0x00, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0xFF, 0xFF, 0xFF, 0x60, 0x60, 0x60, 0x90, 0x90, 0x90 };
static s32 frameFileTbl[] = { WIN_FRAME1_ANM, WIN_FRAME2_ANM, WIN_FRAME3_ANM, WIN_FRAME1_ANM };
static char *mesDataTbl[] = { "mess/mini.dat", "mess/board.dat", "mess/mini_e.dat", "mess/board_e.dat"};
static s32 winVoiceTbl[]
= { 0x37, 0x36, 0x38, 0x44, 0x43, 0x45, 0x41, 0x40, 0x42, 0x4C, 0x4B, 0x4D, 0x47, 0x46, 0x48, 0x3E, 0x3E, 0x3F, 0x49, 0x49, 0x49 };
static s16 winPrio = 1000;
void HuWindowInit(void)
{
s16 i;
winAMemP = HuAR_DVDtoARAM(DATADIR_WIN);
for (i = 0; i < 32; i++) {
winData[i].group = -1;
}
winProc = 0;
winPrio = 1000;
}
void HuWinInit(s32 mess_data_no)
{
s16 i;
void *anim_data;
if (!winProc) {
HuAR_ARAMtoMRAM(winAMemP);
winProc = HuPrcCreate(HuWinProc, 0x64, 0x1000, 0);
HuPrcSetStat(winProc, 0xC);
LanguageNo = GWLanguageGet();
messDataNo = mess_data_no;
fontWidthP = (LanguageNo == 0) ? charWJTbl : charWETbl;
HuWinMesRead(mess_data_no);
for (i = 0; i < 32; i++) {
winData[i].group = -1;
}
if (!fontAnim) {
if (LanguageNo == 0) {
anim_data = HuDataReadNum(WIN_FONTJ_ANM, 0x10000000 );
}
else {
anim_data = HuDataReadNum(WIN_FONTE_ANM, 0x10000000 );
}
fontAnim = HuSprAnimRead(anim_data);
}
if (!iconAnim) {
anim_data = HuDataReadNum(WIN_ICON_ANM, 0x10000000 );
iconAnim = HuSprAnimRead(anim_data);
HuSprAnimLock(iconAnim);
}
if (!cursorAnim) {
anim_data = HuDataReadNum(WIN_CURSOR_ANM, 0x10000000 );
cursorAnim = HuSprAnimRead(anim_data);
HuSprAnimLock(cursorAnim);
}
if (!cardAnimA) {
anim_data = HuDataReadNum(WIN_CARDA_ANM, 0x10000000 );
cardAnimA = HuSprAnimRead(anim_data);
HuSprAnimLock(cardAnimA);
}
if (!cardAnimB) {
anim_data = HuDataReadNum(WIN_CARDB_ANM, 0x10000000 );
cardAnimB = HuSprAnimRead(anim_data);
HuSprAnimLock(cardAnimB);
}
HuDataDirClose(DATADIR_WIN);
HuWinComKeyReset();
winPrio = 1000;
}
}
s16 HuWinCreate(float x, float y, s16 w, s16 h, s16 frame)
{
ANIMDATA *bg_anim;
WindowData *window;
HUSPRITE *sprite_ptr;
s16 group;
s16 sprite;
s16 window_id;
s16 i;
void *frame_data;
for (window_id = 0; window_id < 32; window_id++) {
if (winData[window_id].group == -1) {
break;
}
}
if (window_id == 32) {
return -1;
}
window = &winData[window_id];
window->group = group = HuSprGrpCreate(30);
if (frame < 0 || frame >= 4) {
frame = 0;
}
w = (w + 15) & 0xFFF0;
h = (h + 15) & 0xFFF0;
if (x == -10000.0f) {
window->pos_x = (((float)576) - w) / 2;
}
else {
window->pos_x = x;
}
if (y == -10000.0f) {
window->pos_y = (((float)480) - h) / 2;
}
else {
window->pos_y = y;
}
HuSprGrpCenterSet(group, w / 2, h / 2);
HuSprGrpPosSet(group, window->pos_x, window->pos_y);
frame_data = HuAR_ARAMtoMRAMFileRead(frameFileTbl[frame], 0x10000000 , HEAP_MODEL);
window->frame = HuSprAnimRead(frame_data);
sprite = window->sprite_id[0] = HuSprCreate(window->frame, winPrio, 0);
HuSprGrpMemberSet(group, 0, sprite);
HuSprTPLvlSet(group, 0, 0.9f);
bg_anim = HuSprAnimMake(w / 16, h / 16, 6);
HuSprBGSet(group, 0, bg_anim, 0);
window->color_key = winBGMake(bg_anim, window->frame);
sprite = window->sprite_id[1] = HuSprFuncCreate(MesDispFunc, winPrio);
sprite_ptr = &HuSprData[sprite];
sprite_ptr->work[0] = window_id;
HuSprGrpMemberSet(group, 1, sprite);
window->num_chars = 0;
window->max_chars = (w / 8) * (h / 24) * 4;
window->char_data = HuMemDirectMalloc(HEAP_HEAP, window->max_chars * sizeof(WinChar));
window->attr = 0;
window->stat = 0;
window->unk8C = 0;
window->mess_time = 0;
window->mess_x = window->mess_y = 0;
window->mess_rect_x = 8;
window->mess_rect_y = 8;
window->mess_rect_w = w - 8;
window->mess_rect_h = h - 8;
window->speed = 1;
window->mess_color = 7;
window->mess_shadow_color = 0;
window->active_pad = 0xF;
window->player_disable = 0;
window->mess_stackptr = 0;
window->mess = 0;
window->num_choices = 0;
window->prio = winPrio;
window->spacing_x = 1;
window->spacing_y = 2;
window->w = w;
window->h = h;
window->scissor_x = window->scissor_y = 0;
window->scissor_w = 0x280;
window->scissor_h = 0x1E0;
window->tab_w = 24;
window->push_key = 0x300;
window->key_auto = 0;
if (frame == 0 || frame == 2) {
memcpy(&window->mess_pal, &charColPal[30], 30);
}
else {
memcpy(&window->mess_pal, charColPal, 30);
window->mess_shadow_color = 9;
}
for (i = 0; i < 8; i++) {
window->insert_mess[i] = ((void *)0) ;
}
for (i = 2; i < 30; i++) {
window->sprite_id[i] = -1;
}
winPrio -= 3;
if (winPrio < 500) {
winPrio = 1000;
}
for (i = 0; i < 16; i++) {
window->choice_disable[i] = 0;
window->choice_data[i].stat = 0;
}
return window_id;
}
void HuWinKill(s16 window)
{
WindowData *window_ptr = &winData[window];
s16 i;
if (window_ptr->group != -1) {
HuMemDirectFree(window_ptr->char_data);
for (i = 2; i < 30; i++) {
if (window_ptr->sprite_id[i] != -1) {
HuSprGrpMemberKill(window_ptr->group, i);
}
}
HuSprGrpKill(window_ptr->group);
window_ptr->group = -1;
}
}
void HuWinAllKill(void)
{
s16 i;
for (i = 0; i < 32; i++) {
if (winData[i].group != -1) {
HuWinKill(i);
}
}
if (fontAnim != 0) {
HuSprAnimKill(fontAnim);
fontAnim = 0;
}
if (iconAnim != 0) {
HuSprAnimKill(iconAnim);
iconAnim = 0;
}
if (cursorAnim != 0) {
HuSprAnimKill(cursorAnim);
cursorAnim = 0;
}
if (cardAnimA != 0) {
HuSprAnimKill(cardAnimA);
cardAnimA = 0;
}
if (cardAnimB != 0) {
HuSprAnimKill(cardAnimB);
cardAnimB = 0;
}
if (winProc != 0) {
HuPrcKill(winProc);
winProc = 0;
}
if (messDataPtr != 0) {
HuMemDirectFree(messDataPtr);
messDataPtr = 0;
}
HuDataDirClose(DATADIR_WIN);
}
static void MesDispFunc(HUSPRITE *sprite)
{
WindowData *window = &winData[sprite->work[0]];
HUSPRGRP *group;
float uv_maxx;
float uv_maxy;
float uv_minx;
float uv_miny;
float char_w;
float char_x;
float char_y;
float char_uv_h;
s16 i;
u16 alpha;
s16 color;
Mtx scale;
Mtx modelview;
Mtx44 proj;
if (window->num_chars != 0) {
group = &HuSprGrpData[window->group];
GXInvalidateTexAll();
C_MTXOrtho(proj, 0.0f, ((float)480) , 0.0f, ((float)576) , 0.0f, 10.0f);
GXSetProjection(proj, GX_ORTHOGRAPHIC);
GXClearVtxDesc();
GXSetVtxDesc(GX_VA_POS, GX_DIRECT);
GXSetVtxDesc(GX_VA_TEX0, GX_DIRECT);
GXSetVtxDesc(GX_VA_CLR0, GX_DIRECT);
GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_RGBA6, 0);
GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_RGBA6, 0);
GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGB, GX_RGBA8, 0);
GXSetCullMode(GX_CULL_NONE);
GXSetNumTexGens(1);
GXSetTexCoordGen(GX_TEXCOORD0, GX_TG_MTX2x4, GX_TG_TEX0, GX_IDENTITY);
GXSetNumTevStages(1);
GXSetTevColorIn(GX_TEVSTAGE0, GX_CC_RASC, GX_CC_ZERO, GX_CC_ZERO, GX_CC_ZERO);
GXSetTevColorOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, 1, GX_TEVPREV);
GXSetTevAlphaIn(GX_TEVSTAGE0, GX_CA_ZERO, GX_CA_RASA, GX_CA_TEXA, GX_CA_ZERO);
GXSetTevAlphaOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, 1, GX_TEVPREV);
GXSetNumChans(1);
GXSetChanCtrl(GX_COLOR0A0, 0, GX_SRC_REG, GX_SRC_VTX, 1, GX_DF_CLAMP, GX_AF_SPOT);
GXSetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_NOOP);
GXSetAlphaCompare(GX_GEQUAL, 1, GX_AOP_AND, GX_GEQUAL, 1);
GXSetZCompLoc(0);
PSMTXRotRad (modelview, 'z', ((sprite->zRot)*0.017453292f) );
PSMTXScale (scale, sprite->scale.x, sprite->scale.y, 1.0f);
PSMTXConcat (modelview, scale, modelview);
mtxTransCat(modelview, sprite->pos.x, sprite->pos.y, 0.0f);
PSMTXConcat (*sprite->groupMtx, modelview, modelview);
GXLoadPosMtxImm(modelview, 0);
GXSetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);
HuSprTexLoad(fontAnim, 0, 0, GX_CLAMP, GX_CLAMP, (0 == 5) ? GX_NEAR : GX_LINEAR);
GXBegin(GX_QUADS, GX_VTXFMT0, window->num_chars * 4);
char_uv_h = (LanguageNo == 0) ? (24.0f / 408.0f) : (24.0f / 312.0f);
for (i = 0; i < window->num_chars; i++) {
char_w = fontWidthP[window->char_data[i].character + 48];
uv_minx = (20.0f / 320.0f) * (window->char_data[i].character % 16);
uv_miny = char_uv_h * (window->char_data[i].character / 16);
uv_maxx = uv_minx + (char_w / 320.0);
uv_maxy = uv_miny + char_uv_h;
char_x = window->char_data[i].x;
char_y = window->char_data[i].y;
color = window->char_data[i].color;
if (window->speed != 0) {
alpha = window->char_data[i].fade * 8;
}
else {
alpha = 255;
}
alpha = 255;
if (window->char_data[i].fade < 31) {
window->char_data[i].fade++;
}
GXPosition3f32(char_x + 1.0f, char_y, 0.0f);
GXColor4u8(window->mess_pal[color][0], window->mess_pal[color][1], window->mess_pal[color][2], alpha);
GXPosition2f32(uv_minx, uv_miny);
GXPosition3f32(char_x + char_w, char_y, 0.0f);
GXColor4u8(window->mess_pal[color][0], window->mess_pal[color][1], window->mess_pal[color][2], alpha);
GXPosition2f32(uv_maxx, uv_miny);
GXPosition3f32(char_x + char_w, char_y + 24.0f, 0.0f);
GXColor4u8(window->mess_pal[color][0], window->mess_pal[color][1], window->mess_pal[color][2], alpha);
GXPosition2f32(uv_maxx, uv_maxy);
GXPosition3f32(char_x + 1.0f, char_y + 24.0f, 0.0f);
GXColor4u8(window->mess_pal[color][0], window->mess_pal[color][1], window->mess_pal[color][2], alpha);
GXPosition2f32(uv_minx, uv_maxy);
}
GXEnd();
mesCharCnt++;
}
}
static u8 winBGMake(ANIMDATA *bg, ANIMDATA *frame)
{
ANIMBMP *bmp;
s16 block_h;
s16 h;
s16 block_w;
s16 w;
s16 i;
s16 j;
u8 *bmp_data;
u16 *palette;
w = bg->bmp->sizeX;
h = bg->bmp->sizeY;
block_w = (w + 7) & 0xF8;
block_h = (h + 3) & 0xFC;
bmp_data = bg->bmp->data = HuMemDirectMallocNum(HEAP_HEAP, block_w * block_h, 0x10000000 );
for (i = 0; i < h; i++) {
if (i == 0) {
for (j = 0; j < w; j++) {
if (j == 0) {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0;
}
else if (j == w - 1) {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x10;
}
else {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x70;
}
}
}
else if (i == h - 1) {
for (j = 0; j < w; j++) {
if (j == 0) {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x20;
}
else if (j == w - 1) {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x30;
}
else {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x60;
}
}
}
else {
for (j = 0; j < w; j++) {
if (j == 0) {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x40;
}
else if (j == w - 1) {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x50;
}
else {
bmp_data[(j & 7) + ((j >> 3) << 5) + (i >> 2) * (block_w * 4) + (i & 3) * 8] = 0x80;
}
}
}
}
DCStoreRangeNoSync(bg->bmp->data, block_w * block_h);
bmp = frame->bmp;
palette = bmp->palData;
for (w = 0; w < bmp->palNum; w++, palette++) {
if (*palette == 0xFC00) {
*palette = 0x6114;
break;
}
}
DCStoreRangeNoSync(bmp->palData, 0x200);
return w;
}
static void HuWinProc(void)
{
WindowData *window;
s16 i;
while (1) {
HuPrcVSleep();
window = winData;
for (i = 0; i < 32; i++, window++) {
if (window->group != -1 && !(window->attr & 8)) {
switch (window->stat) {
case 0:
break;
case 1:
HuWinDrawMes(i);
break;
case 2:
HuWinComKeyGet(i, winKey);
HuWinKeyWait(i);
break;
case 3:
if (!(window->attr & 0x40) || HuWinActiveKeyGetX(window) == 0) {
window->attr &= ~0x40;
HuWinComKeyGet(i, winKey);
HuWinChoice(window);
}
break;
}
}
}
}
}
static inline void charEntry(s16 window, s16 x, s16 y, s16 char_idx, s16 color)
{
WindowData *window_ptr = &winData[window];
WinChar *win_char = window_ptr->char_data;
win_char = &window_ptr->char_data[window_ptr->num_chars];
win_char->x = x - window_ptr->w / 2;
win_char->y = y - window_ptr->h / 2;
win_char->character = char_idx - 48;
win_char->color = color;
win_char->fade = 0;
window_ptr->num_chars++;
if (window_ptr->num_chars >= window_ptr->max_chars) {
window_ptr->num_chars = window_ptr->max_chars - 1;
}
}
static void HuWinDrawMes(s16 window)
{
WindowData *window_ptr = &winData[window];
HUSPRGRP *group = &HuSprGrpData[window_ptr->group];
s16 i;
s16 char_w;
s16 tab_w;
s16 insert_mess;
s16 mess_end;
s16 c;
s16 shadow_color;
s16 color;
s16 mess_w;
window_ptr->mess_time += (0 == 5) ? 1 : 3;
while (window_ptr->mess_time >= window_ptr->speed || (window_ptr->attr & 0x2000)) {
window_ptr->mess_time -= window_ptr->speed;
if (window_ptr->mess_time < 0) {
window_ptr->mess_time = 0;
}
char_w = window_ptr->spacing_x + fontWidthP[window_ptr->mess[0]];
mess_end = 0;
if (window_ptr->mess[0] != 0 && (window_ptr->attr & 4)) {
window_ptr->attr &= ~4;
_HuWinHomeClear(window_ptr);
}
while (window_ptr->mess[0] < 48 || window_ptr->mess[0] == 255) {
switch (window_ptr->mess[0]) {
case 0:
if (window_ptr->mess_stackptr == 0) {
for (i = 0; i < 16; i++) {
window_ptr->choice_disable[i] = 0;
}
window_ptr->stat = 0;
window_ptr->attr &= ~0x80;
return;
}
window_ptr->mess_stackptr--;
window_ptr->mess = window_ptr->mess_stack[window_ptr->mess_stackptr];
window_ptr->mess_time = 0;
break;
case 31:
window_ptr->mess++;
insert_mess = window_ptr->mess[0] - 1;
if (window_ptr->insert_mess[insert_mess] != 0) {
window_ptr->mess_stack[window_ptr->mess_stackptr] = window_ptr->mess;
window_ptr->mess = window_ptr->insert_mess[insert_mess];
window_ptr->mess_stackptr++;
if (window_ptr->mess[0] != 0xB) {
window_ptr->mess--;
}
}
break;
case 11:
window_ptr->attr &= ~0x2200;
_HuWinHomeClear(window_ptr);
if (window_ptr->attr & 0x800) {
mess_w = GetMesMaxSizeSub2(window_ptr, window_ptr->mess + 1);
window_ptr->mess_x = (window_ptr->mess_rect_w - mess_w) / 2;
}
else if (window_ptr->attr & 0x1000) {
mess_w = GetMesMaxSizeSub2(window_ptr, window_ptr->mess + 1);
window_ptr->mess_x = window_ptr->mess_rect_w - mess_w;
}
break;
case 30:
window_ptr->mess++;
if (!(window_ptr->attr & 0x80)) {
window_ptr->mess_color = window_ptr->mess[0] - 1;
}
break;
case 29:
window_ptr->attr ^= 1;
break;
case 10:
window_ptr->attr &= ~0x2020;
if (window_ptr->attr & 0x200) {
if (!(window_ptr->attr & 0x100)) {
if (HuWinCR(window_ptr) != 0) {
window_ptr->mess++;
HuWinKeyWaitEntry(window);
window_ptr->attr |= 2;
return;
}
if (window_ptr->attr & 0x800) {
mess_w = GetMesMaxSizeSub2(window_ptr, window_ptr->mess + 1);
window_ptr->mess_x = (window_ptr->mess_rect_w - mess_w) / 2;
}
else if (window_ptr->attr & 0x1000) {
mess_w = GetMesMaxSizeSub2(window_ptr, window_ptr->mess + 1);
window_ptr->mess_x = window_ptr->mess_rect_w - mess_w;
}
break;
}
char_w = fontWidthP[16] + window_ptr->spacing_x;
case 16:
case 32:
window_ptr->attr |= 0x200;
if (window_ptr->mess_x + char_w > window_ptr->mess_rect_w) {
if (HuWinCR(window_ptr) != 0) {
window_ptr->mess++;
HuWinKeyWaitEntry(window);
window_ptr->attr |= 2;
return;
}
break;
}
window_ptr->mess_x += char_w;
}
break;
case 14:
window_ptr->attr |= 0x200;
window_ptr->mess++;
tab_w = window_ptr->spacing_x + spcFontTbl[window_ptr->mess[0] - 1].w;
if (window_ptr->mess_x + tab_w > window_ptr->mess_rect_w && HuWinCR(window_ptr) != 0) {
window_ptr->mess--;
HuWinKeyWaitEntry(window);
window_ptr->attr |= 2;
return;
}
HuWinSpcFontEntry(window_ptr, window_ptr->mess[0] - 1, window_ptr->mess_rect_x + window_ptr->mess_x,
window_ptr->mess_rect_y + window_ptr->mess_y);
window_ptr->mess_x += tab_w;
mess_end = 1;
break;
case 28:
window_ptr->mess++;
HuAudFXPlay(winVoiceTbl[window_ptr->mess[0] - 1]);
break;
case 255:
window_ptr->mess++;
HuWinKeyWaitEntry(window);
window_ptr->attr |= 4;
window_ptr->attr &= ~0x200;
return;
case 15:
window_ptr->attr |= 0x2000;
if (window_ptr->choice_disable[window_ptr->num_choices] != 0) {
window_ptr->attr |= 0x20;
window_ptr->choice_data[window_ptr->num_choices].stat |= 1;
}
else {
window_ptr->choice_data[window_ptr->num_choices].stat &= ~1;
}
window_ptr->choice_data[window_ptr->num_choices].x = window_ptr->mess_x + window_ptr->mess_rect_y;
window_ptr->choice_data[window_ptr->num_choices].y = window_ptr->mess_y + window_ptr->mess_rect_x;
window_ptr->num_choices++;
break;
case 12:
window_ptr->attr |= 0x200;
tab_w = window_ptr->tab_w * ((window_ptr->mess_x + window_ptr->tab_w) / window_ptr->tab_w) - window_ptr->mess_x;
if (window_ptr->mess_x + tab_w > window_ptr->mess_rect_w) {
if (HuWinCR(window_ptr) != 0) {
window_ptr->mess++;
HuWinKeyWaitEntry(window);
window_ptr->attr |= 2;
return;
}
}
else {
window_ptr->mess_x += tab_w;
}
break;
}
window_ptr->mess++;
char_w = window_ptr->spacing_x + fontWidthP[window_ptr->mess[0]];
if (mess_end != 0) {
break;
}
}
if (mess_end == 0) {
if (window_ptr->mess_x + char_w > window_ptr->mess_rect_w && HuWinCR(window_ptr) != 0) {
HuWinKeyWaitEntry(window);
window_ptr->attr |= 2;
return;
}
c = window_ptr->mess[0];
window_ptr->attr |= 0x200;
if (window_ptr->mess[1] == 128) {
if (c >= 150 && c <= 164) {
c = c + 106;
}
else if (c >= 170 && c <= 174) {
c = c + 101;
}
else if (c >= 214 && c <= 228) {
c = c + 67;
}
else if (c >= 234 && c <= 238) {
c = c + 62;
}
window_ptr->mess++;
}
else if (window_ptr->mess[1] == 129) {
if (c >= 170 && c <= 174) {
c = c + 106;
}
else if (c >= 234 && c <= 238) {
c = c + 67;
}
window_ptr->mess++;
}
color = (window_ptr->attr & 0x20) ? 8 : window_ptr->mess_color;
if (window_ptr->attr & 1) {
shadow_color = 0;
if (window_ptr->mess_color == 0 || window_ptr->mess_color == 1) {
shadow_color = 8;
}
charEntry(window, window_ptr->mess_rect_x + window_ptr->mess_x + 2, window_ptr->mess_rect_y + window_ptr->mess_y, c, shadow_color);
charEntry(window, window_ptr->mess_rect_x + window_ptr->mess_x - 2, window_ptr->mess_rect_y + window_ptr->mess_y, c, shadow_color);
charEntry(window, window_ptr->mess_rect_x + window_ptr->mess_x, window_ptr->mess_rect_y + window_ptr->mess_y + 2, c, shadow_color);
charEntry(window, window_ptr->mess_rect_x + window_ptr->mess_x, window_ptr->mess_rect_y + window_ptr->mess_y - 2, c, shadow_color);
charEntry(window, window_ptr->mess_rect_x + window_ptr->mess_x, window_ptr->mess_rect_y + window_ptr->mess_y, c, color);
}
else {
charEntry(window, window_ptr->mess_rect_x + window_ptr->mess_x + 2, window_ptr->mess_rect_y + window_ptr->mess_y + 2, c,
window_ptr->mess_shadow_color);
charEntry(window, window_ptr->mess_rect_x + window_ptr->mess_x, window_ptr->mess_rect_y + window_ptr->mess_y, c, color);
}
window_ptr->mess_x += char_w;
window_ptr->mess++;
}
}
}
static s32 HuWinCR(WindowData *window)
{
if (window->mess_y + 48 > window->mess_rect_h) {
window->mess_y = 0;
window->mess_x = 0;
return 1;
}
else {
window->mess_y += window->spacing_y + 24;
window->mess_x = 0;
return 0;
}
}
static void _HuWinHomeClear(WindowData *window)
{
s16 i;
window->num_chars = 0;
window->mess_y = window->mess_x = 0;
window->num_choices = 0;
HuWinSpcFontClear(window);
window->attr &= ~0x2020;
for (i = 0; i < 16; i++) {
window->choice_data[i].stat = 0;
}
}
void HuWinHomeClear(s16 window)
{
WindowData *window_ptr = &winData[window];
_HuWinHomeClear(window_ptr);
}
void HuWinKeyWaitEntry(s16 window)
{
WindowData *window_ptr = &winData[window];
if (window_ptr->attr & 0x400) {
window_ptr->stat = 0;
}
else {
window_ptr->stat = 2;
window_ptr->advance_sprite = HuWinSpcFontEntry(window_ptr, 19, window_ptr->mess_rect_w - 20, window_ptr->mess_rect_h - 24);
}
}
static void HuWinKeyWait(s16 window)
{
WindowData *window_ptr = &winData[window];
if (window_ptr->push_key & HuWinActivePadGet(window_ptr)) {
window_ptr->key_down = HuWinActivePadGet(window_ptr);
window_ptr->stat = 1;
HuAudFXPlay(28);
HuWinSprKill(window, window_ptr->advance_sprite);
if (window_ptr->attr & 2) {
_HuWinHomeClear(window_ptr);
}
window_ptr->attr &= ~2;
}
}
static s16 HuWinSpcFontEntry(WindowData *window, s16 entry, s16 x, s16 y)
{
HUSPRGRP *group = &HuSprGrpData[window->group];
s16 sprite;
s16 i;
ANIMDATA *anim;
for (i = 10; i < 30; i++) {
if (window->sprite_id[i] == -1) {
anim = *spcFontTbl[entry].anim;
window->sprite_id[i] = sprite = HuSprCreate(anim, window->prio - 1, spcFontTbl[entry].bank);
HuSprGrpMemberSet(window->group, i, sprite);
HuSprPosSet(window->group, i, x + spcFontTbl[entry].center_x - window->w / 2, y + spcFontTbl[entry].center_y - window->h / 2);
break;
}
}
return i;
}
static void HuWinSpcFontPosSet(WindowData *window, s16 index, s16 x, s16 y)
{
HUSPRGRP *group = &HuSprGrpData[window->group];
HuSprPosSet(window->group, index, x - window->w / 2, y - window->h / 2);
}
static void HuWinSpcFontClear(WindowData *window)
{
s16 i;
for (i = 10; i < 30; i++) {
if (window->sprite_id[i] != -1) {
HuSprGrpMemberKill(window->group, i);
window->sprite_id[i] = -1;
}
}
}
static void HuWinChoice(WindowData *window)
{
WinChoice *choice;
float choice_dist;
float min_choice_dist_x;
s16 choice_dist_y;
s16 key;
s16 choice_curr_x;
s16 choice_curr_y;
s16 choice_curr;
s16 choice_max;
s16 choice_dist_x;
s16 dir;
s16 choice_y;
s16 choice_next;
s16 i;
choice_curr = window->choice;
choice_next = choice_curr;
dir = -1;
key = HuWinActivePadGet(window);
if (key & 1) {
dir = 0;
}
if (key & 2) {
dir = 2;
}
if (key & 8) {
dir = 1;
}
if (key & 4) {
dir = 3;
}
choice_curr_x = window->choice_data[choice_curr].x;
choice_curr_y = window->choice_data[choice_curr].y;
min_choice_dist_x = 100000.0f;
choice_dist = min_choice_dist_x;
choice_max = window->num_choices;
switch (dir) {
case 0:
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y == choice_curr_y && choice->x < choice_curr_x) {
break;
}
}
if (i != choice_max) {
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y == choice_curr_y && choice->x < choice_curr_x
&& choice_dist > choice_curr_x - choice->x) {
choice_dist = choice_curr_x - choice->x;
choice_next = i;
}
}
}
break;
case 1:
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y < choice_curr_y) {
break;
}
}
if (i != choice_max) {
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y < choice_curr_y) {
choice_dist_y = choice_curr_y - choice->y;
if (choice_dist_y <= choice_dist) {
if (choice_dist_y < choice_dist) {
min_choice_dist_x = 100000.0f;
}
choice_dist_x = choice_curr_x - choice->x;
choice_dist_x = choice_dist_x * choice_dist_x;
if (choice_dist_x < min_choice_dist_x) {
choice_dist = choice_dist_y;
min_choice_dist_x = choice_dist_x;
choice_next = i;
}
}
}
}
}
else {
choice_y = -1000;
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y > choice_y) {
choice_y = choice->y;
}
}
if (choice_y != choice_curr_y) {
min_choice_dist_x = 100000.0f;
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y == choice_y) {
choice_dist_x = choice_curr_x - choice->x;
choice_dist_x = choice_dist_x * choice_dist_x;
if (choice_dist_x < min_choice_dist_x) {
min_choice_dist_x = choice_dist_x;
choice_next = i;
}
}
}
}
}
break;
case 2:
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y == choice_curr_y && choice->x > choice_curr_x) {
break;
}
}
if (i != choice_max) {
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y == choice_curr_y && choice->x > choice_curr_x
&& choice_dist > choice->x - choice_curr_x) {
choice_dist = choice->x - choice_curr_x;
choice_next = i;
}
}
}
break;
case 3:
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y > choice_curr_y) {
break;
}
}
if (i != choice_max) {
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y > choice_curr_y) {
choice_dist_y = choice->y - choice_curr_y;
if (choice_dist_y <= choice_dist) {
if (choice_dist_y < choice_dist) {
min_choice_dist_x = 100000.0f;
}
choice_dist_x = choice_curr_x - choice->x;
choice_dist_x = choice_dist_x * choice_dist_x;
if (choice_dist_x < min_choice_dist_x) {
choice_dist = choice_dist_y;
min_choice_dist_x = choice_dist_x;
choice_next = i;
}
}
}
}
}
else {
choice_y = 1000;
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y < choice_y) {
choice_y = choice->y;
}
}
if (choice_y != choice_curr_y) {
min_choice_dist_x = 100000.0f;
for (i = 0, choice = window->choice_data; i < choice_max; i++, choice++) {
if (i != choice_curr && !(choice->stat & 1) && choice->y == choice_y) {
choice_dist_x = choice_curr_x - choice->x;
choice_dist_x = choice_dist_x * choice_dist_x;
if (choice_dist_x < min_choice_dist_x) {
min_choice_dist_x = choice_dist_x;
choice_next = i;
}
}
}
}
}
break;
}
if (window->choice != choice_next) {
window->choice = choice_next;
HuAudFXPlay(0);
}
else if (key & ((0 == 5) ? 0x0100 : (window->key_auto | 0x0100 ))) {
HuAudFXPlay(2);
window->key_down = key;
window->stat = 0;
}
else if ((key & 0x0200 ) && !(window->attr & 0x10)) {
HuAudFXPlay(3);
window->key_down = key;
window->choice = -1;
window->stat = 0;
}
HuWinSpcFontPosSet(window, window->cursor_sprite, window->choice_data[choice_next].x + spcFontTbl[20].center_x,
window->choice_data[choice_next].y + spcFontTbl[20].center_y);
}
u32 HuWinActivePadGet(WindowData *window)
{
s32 win_key;
u32 i;
win_key = 0;
for (i = 0; i < 4; i++) {
if (window->active_pad & (1 << i)) {
win_key |= winKey[i];
}
}
return win_key;
}
u32 HuWinActiveKeyGetX(WindowData *window)
{
u32 button;
u32 i;
u32 j;
u8 active_pad;
button = 0;
active_pad = (window->active_pad & ~window->player_disable);
for (i = 0; i < 4; i++) {
if (active_pad & (1 << i)) {
for (j = 0; j < 4; j++) {
if (i == GWPlayerCfg[j].pad_idx) {
break;
}
}
if (j != 4 && GWPlayerCfg[j].iscom == 0) {
button |= HuPadBtn[GWPlayerCfg[j].pad_idx];
}
}
}
return button;
}
void HuWinPosSet(s16 window, float x, float y)
{
WindowData *window_ptr = &winData[window];
window_ptr->pos_x = x;
window_ptr->pos_y = y;
HuSprGrpPosSet(window_ptr->group, x, y);
}
void HuWinScaleSet(s16 window, float x, float y)
{
WindowData *window_ptr = &winData[window];
window_ptr->scale_x = x;
window_ptr->scale_y = y;
HuSprGrpScaleSet(window_ptr->group, x, y);
}
void HuWinZRotSet(s16 window, float z_rot)
{
WindowData *window_ptr = &winData[window];
window_ptr->z_rot = z_rot;
HuSprGrpZRotSet(window_ptr->group, z_rot);
}
void HuWinCenterPosSet(s16 window, float x, float y)
{
WindowData *window_ptr = &winData[window];
HuSprGrpCenterSet(window_ptr->group, window_ptr->w / 2.0f - x, window_ptr->h / 2.0f - y);
}
void HuWinDrawNoSet(s16 window, s16 draw_no)
{
WindowData *window_ptr = &winData[window];
HuSprGrpDrawNoSet(window_ptr->group, draw_no);
}
void HuWinScissorSet(s16 window, s16 x, s16 y, s16 w, s16 h)
{
WindowData *window_ptr = &winData[window];
HuSprGrpScissorSet(window_ptr->group, x, y, w, h);
}
void HuWinPriSet(s16 window, s16 prio)
{
WindowData *window_ptr = &winData[window];
s16 i;
HuSprPriSet(window_ptr->group, 0, prio);
HuSprPriSet(window_ptr->group, 1, prio);
for (i = 2; i < 30; i++) {
if (window_ptr->sprite_id[i] != -1) {
HuSprPriSet(window_ptr->group, i, prio - 1);
}
}
window_ptr->prio = prio;
}
void HuWinAttrSet(s16 window, u32 attr)
{
WindowData *window_ptr = &winData[window];
window_ptr->attr |= attr;
}
void HuWinAttrReset(s16 window, u32 attr)
{
WindowData *window_ptr = &winData[window];
window_ptr->attr &= ~attr;
}
s16 HuWinStatGet(s16 window)
{
WindowData *window_ptr = &winData[window];
return window_ptr->stat;
}
void HuWinMesColSet(s16 window, u8 color)
{
WindowData *window_ptr = &winData[window];
window_ptr->mess_color = color;
window_ptr->attr |= 0x80;
}
void HuWinMesPalSet(s16 window, u8 index, u8 r, u8 g, u8 b)
{
WindowData *window_ptr = &winData[window];
window_ptr->mess_pal[index][0] = r;
window_ptr->mess_pal[index][1] = g;
window_ptr->mess_pal[index][2] = b;
}
void HuWinBGTPLvlSet(s16 window, float tp_level)
{
WindowData *window_ptr = &winData[window];
HuSprTPLvlSet(window_ptr->group, 0, tp_level);
}
void HuWinBGColSet(s16 window, GXColor *bg_color)
{
WindowData *window_ptr = &winData[window];
HuSprColorSet(window_ptr->group, 0, bg_color->r, bg_color->g, bg_color->b);
}
void HuWinMesSpeedSet(s16 window, s16 speed)
{
WindowData *window_ptr = &winData[window];
window_ptr->speed = speed;
}
void HuWinMesRead(s32 mess_data_no)
{
void *dvd_mess;
char *mess_path;
if (messDataPtr) {
HuMemDirectFree(messDataPtr);
}
messDataNo = mess_data_no;
if (LanguageNo == 0) {
mess_path = mesDataTbl[messDataNo];
}
else {
mess_path = mesDataTbl[messDataNo + 2];
}
dvd_mess = HuDvdDataRead(mess_path);
messDataPtr = HuMemDirectMalloc(HEAP_HEAP, DirDataSize);
memcpy(messDataPtr, dvd_mess, DirDataSize);
HuMemDirectFree(dvd_mess);
}
void HuWinMesSet(s16 window, u32 mess)
{
WindowData *window_ptr = &winData[window];
window_ptr->stat = 1;
if ((mess & 0x80000000) == 0) {
if (messDataPtr == 0) {
OSReport("Error: No Message\n");
return;
}
window_ptr->mess = MessData_MesPtrGet(messDataPtr, mess);
if (window_ptr->mess == 0) {
OSReport("Error: No Message data\n");
HuWinMesSet(window, 0);
return;
}
}
else {
window_ptr->mess = (u8 *)mess;
}
if (!(window_ptr->attr & 0x80)) {
window_ptr->mess_color = 7;
window_ptr->mess_time = 0;
}
}
void HuWinInsertMesSet(s16 window, u32 mess, s16 index)
{
WindowData *window_ptr = &winData[window];
if (!(mess & 0x80000000)) {
if (messDataPtr == 0) {
OSReport("Error: No Message\n");
return;
}
window_ptr->insert_mess[index] = MessData_MesPtrGet(messDataPtr, mess);
if (window_ptr->insert_mess[index] == 0) {
OSReport("Error: No Message data\n");
}
}
else {
window_ptr->insert_mess[index] = (u8 *)mess;
}
}
s16 HuWinChoiceGet(s16 window, s16 start_choice)
{
WindowData *window_ptr = &winData[window];
window_ptr->attr |= 0x40;
while (window_ptr->stat != 0) {
HuPrcVSleep();
}
for (; start_choice < window_ptr->num_choices; start_choice++) {
if (!(window_ptr->choice_data[start_choice].stat & 1)) {
break;
}
}
if (start_choice == window_ptr->num_choices) {
for (start_choice = 0; start_choice < window_ptr->num_choices; start_choice++) {
if (!(window_ptr->choice_data[start_choice].stat & 1)) {
break;
}
}
if (start_choice == window_ptr->num_choices) {
return -1;
}
}
window_ptr->cursor_sprite = HuWinSpcFontEntry(window_ptr, 0x14, window_ptr->choice_data[start_choice].x, window_ptr->choice_data[start_choice].y);
window_ptr->stat = 3;
window_ptr->choice = start_choice;
while (window_ptr->stat != 0) {
HuPrcVSleep();
}
return window_ptr->choice;
}
s16 HuWinChoiceNumGet(s16 window)
{
WindowData *window_ptr = &winData[window];
return window_ptr->num_choices;
}
void HuWinChoiceDisable(s16 window, s16 choice)
{
WindowData *window_ptr = &winData[window];
window_ptr->choice_disable[choice] = 1;
}
s16 HuWinChoiceNowGet(s16 window)
{
WindowData *window_ptr = &winData[window];
if (window_ptr->stat == 3) {
return window_ptr->choice;
}
else {
return -1;
}
}
void HuWinMesWait(s16 window)
{
WindowData *window_ptr = &winData[window];
while (window_ptr->stat != 0) {
HuPrcVSleep();
}
}
s16 HuWinAnimSet(s16 window, ANIMDATA *anim, s16 bank, float x, float y)
{
WindowData *window_ptr = &winData[window];
s16 sprite;
sprite = HuSprCreate(anim, window_ptr->prio - 1, bank);
return HuWinSprSet(window, sprite, x, y);
}
s16 HuWinSprSet(s16 window, s16 sprite, float x, float y)
{
WindowData *window_ptr = &winData[window];
HUSPRGRP *group = &HuSprGrpData[window_ptr->group];
s16 i;
for (i = 2; i <= 9; i++) {
if (window_ptr->sprite_id[i] == -1) {
window_ptr->sprite_id[i] = sprite;
HuSprGrpMemberSet(window_ptr->group, i, sprite);
HuSprPosSet(window_ptr->group, i, x - group->center.x, y - group->center.y);
break;
}
}
return i;
}
void HuWinSprPosSet(s16 window, s16 index, float x, float y)
{
WindowData *window_ptr = &winData[window];
HUSPRGRP *group = &HuSprGrpData[window_ptr->group];
HuSprPosSet(window_ptr->group, index, x - group->center.x, y - group->center.y);
}
void HuWinSprPriSet(s16 window, s16 index, s16 prio)
{
WindowData *window_ptr = &winData[window];
HUSPRGRP *group = &HuSprGrpData[window_ptr->group];
HuSprPriSet(window_ptr->group, index, prio);
}
s16 HuWinSprIDGet(s16 window, s16 index)
{
WindowData *window_ptr = &winData[window];
return window_ptr->sprite_id[index];
}
void HuWinSprKill(s16 window, s16 index)
{
WindowData *window_ptr = &winData[window];
HuSprGrpMemberKill(window_ptr->group, index);
window_ptr->sprite_id[index] = -1;
}
void HuWinDispOff(s16 window)
{
WindowData *window_ptr = &winData[window];
s16 i;
for (i = 0; i < 30; i++) {
if (window_ptr->sprite_id[i] != -1) {
HuSprAttrSet(window_ptr->group, i, 0x4 );
}
}
window_ptr->attr |= 8;
}
void HuWinDispOn(s16 window)
{
WindowData *window_ptr = &winData[window];
s16 i;
for (i = 0; i < 30; i++) {
if (window_ptr->sprite_id[i] != -1) {
HuSprAttrReset(window_ptr->group, i, 0x4 );
}
}
window_ptr->attr = window_ptr->attr & ~8;
}
void HuWinComKeyWait(s32 player_1, s32 player_2, s32 player_3, s32 player_4, s16 delay)
{
s32 wait_input_p4;
s32 wait_input_p3;
s32 wait_input_p2;
s32 wait_input_p1;
if (player_4 == -1) {
wait_input_p4 = -1;
}
else {
wait_input_p4 = 0;
}
if (player_3 == -1) {
wait_input_p3 = -1;
}
else {
wait_input_p3 = 0;
}
if (player_2 == -1) {
wait_input_p2 = -1;
}
else {
wait_input_p2 = 0;
}
if (player_1 == -1) {
wait_input_p1 = -1;
}
else {
wait_input_p1 = 0;
}
_HuWinComKeySet(wait_input_p1, wait_input_p2, wait_input_p3, wait_input_p4, delay);
_HuWinComKeySet(player_1, player_2, player_3, player_4, 1);
}
void HuWinComKeySet(s32 player_1, s32 player_2, s32 player_3, s32 player_4)
{
_HuWinComKeySet(player_1, player_2, player_3, player_4, 1);
}
void _HuWinComKeySet(s32 player_1, s32 player_2, s32 player_3, s32 player_4, s16 delay)
{
winComKeyBuf[comKeyIdx].player[0] = player_1;
winComKeyBuf[comKeyIdx].player[1] = player_2;
winComKeyBuf[comKeyIdx].player[2] = player_3;
winComKeyBuf[comKeyIdx].player[3] = player_4;
winComKeyBuf[comKeyIdx].time = delay;
comKeyIdx++;
comKeyIdx &= 0xFF;
}
void HuWinComKeyGet(s16 window, u32 *data)
{
WindowData *window_ptr = &winData[window];
s16 i;
if (comKeyIdx == comKeyIdxNow) {
for (i = 0; i < 4; i++) {
if (!(window_ptr->player_disable & (1 << i))) {
data[i] = HuPadDStkRep[i] | HuPadBtnDown[i];
}
else {
data[i] = 0;
}
}
}
else {
for (i = 0; i < 4; i++) {
data[i] = winComKeyBuf[comKeyIdxNow].player[i];
if (data[i] == 0xFFFFFFFF) {
if (!(window_ptr->player_disable & (1 << i))) {
data[i] = HuPadDStkRep[i] | HuPadBtnDown[i];
}
else {
data[i] = 0;
}
}
}
winComKeyBuf[comKeyIdxNow].time--;
if (winComKeyBuf[comKeyIdxNow].time <= 0) {
comKeyIdxNow++;
comKeyIdxNow &= 0xFF;
}
}
}
void HuWinComKeyReset(void)
{
comKeyIdx = comKeyIdxNow = 0;
}
