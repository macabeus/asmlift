
extern int __float_nan[];
extern int __float_huge[];
extern int __double_huge[];
extern inline double sqrt(double x)
{
if (x > 0.0) {
double guess = __frsqrte(x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
return x * guess;
}
else if (x == 0)
return 0;
else if (x)
return (*(float *)__float_nan) ;
return (*(float *)__float_huge) ;
}
extern inline float sqrtf(float x)
{
static const double _half = .5;
static const double _three = 3.0;
volatile float y;
if (x > 0.0f) {
double guess = __frsqrte((double)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (float)(x * guess);
return y;
}
return x;
}
double atan(double x);
double copysign(double x, double y);
double cos(double x);
double floor(double x);
double frexp(double x, int *exp);
double ldexp(double x, int exp);
double modf(double x, double *intpart);
double sin(double x);
double tan(double x);
double acos(double x);
double asin(double x);
double atan2(double y, double x);
double fmod(double x, double y);
double log(double x);
double pow(double x, double y);
float tanf(float x);
extern inline double fabs(double x)
{
return __fabs(x);
}
static inline float fabsf(float x)
{
return (float)fabs((double)x);
}
static inline float sinf(float x)
{
return (float)sin((double)x);
}
static inline float cosf(float x)
{
return (float)cos((double)x);
}
static inline float atan2f(float y, float x)
{
return (float)atan2((double)y, (double)x);
}
static inline float atanf(float x)
{
return (float)atan((double)x);
}
static inline float asinf(float x)
{
return (float)asin((double)x);
}
static inline float acosf(float x)
{
return (float)acos((double)x);
}
static inline float fmodf(float x, float m)
{
return (float)fmod((double)x, (double)m);
}
static inline float floorf(float x)
{
return floor(x);
}
static inline float powf(float __x, float __y)
{
return pow(__x, __y);
}
typedef signed char s8;
typedef signed short int s16;
typedef signed long s32;
typedef signed long long int s64;
typedef unsigned char u8;
typedef unsigned short int u16;
typedef unsigned long u32;
typedef unsigned long long int u64;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef struct {
f32 x, y, z;
} Vec, *VecPtr, Point3d, *Point3dPtr;
typedef struct {
s16 x;
s16 y;
s16 z;
} S16Vec, *S16VecPtr;
typedef struct {
f32 x, y, z, w;
} Quaternion, *QuaternionPtr, Qtrn, *QtrnPtr;
typedef f32 Mtx[3][4];
typedef f32 (*MtxPtr)[4];
typedef f32 ROMtx[4][3];
typedef f32 (*ROMtxPtr)[3];
typedef f32 Mtx44[4][4];
typedef f32 (*Mtx44Ptr)[4];
typedef struct {
u32 numMtx;
MtxPtr stackBase;
MtxPtr stackPtr;
} MtxStack, *MtxStackPtr;
void C_MTXIdentity(Mtx m);
void C_MTXCopy(const Mtx src, Mtx dst);
void C_MTXConcat(const Mtx a, const Mtx b, Mtx ab);
void C_MTXConcatArray(const Mtx a, const Mtx* srcBase, Mtx* dstBase, u32 count);
void C_MTXTranspose(const Mtx src, Mtx xPose);
u32 C_MTXInverse(const Mtx src, Mtx inv);
u32 C_MTXInvXpose(const Mtx src, Mtx invX);
void PSMTXIdentity(Mtx m);
void PSMTXCopy(const Mtx src, Mtx dst);
void PSMTXConcat(const Mtx a, const Mtx b, Mtx ab);
void PSMTXConcatArray(const Mtx a, const Mtx* srcBase, Mtx* dstBase, u32 count);
void PSMTXTranspose(const Mtx src, Mtx xPose);
u32 PSMTXInverse(const Mtx src, Mtx inv);
u32 PSMTXInvXpose(const Mtx src, Mtx invX);
void C_MTXMultVec(const Mtx m, const Vec* src, Vec* dst);
void C_MTXMultVecArray(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void C_MTXMultVecSR(const Mtx m, const Vec* src, Vec* dst);
void C_MTXMultVecArraySR(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXMultVec(const Mtx m, const Vec* src, Vec* dst);
void PSMTXMultVecArray(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXMultVecSR(const Mtx m, const Vec* src, Vec* dst);
void PSMTXMultVecArraySR(const Mtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void C_MTXQuat(Mtx m, const Quaternion* q);
void C_MTXReflect(Mtx m, const Vec* p, const Vec* n);
void C_MTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void C_MTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void C_MTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void C_MTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void C_MTXRotRad(Mtx m, char axis, f32 rad);
void C_MTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void C_MTXRotAxisRad(Mtx m, const Vec* axis, f32 rad);
void PSMTXQuat(Mtx m, const Quaternion* q);
void PSMTXReflect(Mtx m, const Vec* p, const Vec* n);
void PSMTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void PSMTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void PSMTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void PSMTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void PSMTXRotRad(Mtx m, char axis, f32 rad);
void PSMTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void PSMTXRotAxisRad(register Mtx m, const Vec* axis, register f32 rad);
void C_MTXLookAt(Mtx m, const Point3d* camPos, const Vec* camUp, const Point3d* target);
void C_MTXFrustum(Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTXPerspective(Mtx44 m, f32 fovY, f32 aspect, f32 n, f32 f);
void C_MTXOrtho(Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTXLightFrustum(Mtx m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 scaleS, f32 scaleT, f32 transS,
f32 transT);
void C_MTXLightPerspective(Mtx m, f32 fovY, f32 aspect, f32 scaleS, f32 scaleT, f32 transS,
f32 transT);
void C_MTXLightOrtho(Mtx m, f32 t, f32 b, f32 l, f32 r, f32 scaleS, f32 scaleT, f32 transS,
f32 transT);
void C_VECAdd(const Vec* a, const Vec* b, Vec* ab);
void C_VECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void C_VECScale(const Vec* src, Vec* dst, f32 scale);
void C_VECNormalize(const Vec* src, Vec* unit);
f32 C_VECSquareMag(const Vec* v);
f32 C_VECMag(const Vec* v);
f32 C_VECDotProduct(const Vec* a, const Vec* b);
void C_VECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
f32 C_VECSquareDistance(const Vec* a, const Vec* b);
f32 C_VECDistance(const Vec* a, const Vec* b);
void C_VECReflect(const Vec* src, const Vec* normal, Vec* dst);
void C_VECHalfAngle(const Vec* a, const Vec* b, Vec* half);
void PSVECAdd(const Vec* a, const Vec* b, Vec* ab);
void PSVECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void PSVECScale(const Vec* src, Vec* dst, f32 scale);
void PSVECNormalize(const Vec* src, Vec* unit);
f32 PSVECSquareMag(const Vec* v);
f32 PSVECMag(const Vec* v);
f32 PSVECDotProduct(const Vec* a, const Vec* b);
void PSVECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
f32 PSVECSquareDistance(const Vec* a, const Vec* b);
f32 PSVECDistance(const Vec* a, const Vec* b);
void C_QUATAdd(const Quaternion* p, const Quaternion* q, Quaternion* r);
void C_QUATSubtract(const Quaternion* p, const Quaternion* q, Quaternion* r);
void C_QUATMultiply(const Quaternion* p, const Quaternion* q, Quaternion* pq);
void C_QUATDivide(const Quaternion* p, const Quaternion* q, Quaternion* r);
void C_QUATScale(const Quaternion* q, Quaternion* r, f32 scale);
f32 C_QUATDotProduct(const Quaternion* p, const Quaternion* q);
void C_QUATNormalize(const Quaternion* src, Quaternion* unit);
void C_QUATInverse(const Quaternion* src, Quaternion* inv);
void C_QUATExp(const Quaternion* q, Quaternion* r);
void C_QUATLogN(const Quaternion* q, Quaternion* r);
void C_QUATMakeClosest(const Quaternion* q, const Quaternion* qto, Quaternion* r);
void C_QUATRotAxisRad(Quaternion* r, const Vec* axis, f32 rad);
void C_QUATMtx(Quaternion* r, const Mtx m);
void C_QUATLerp(const Quaternion* p, const Quaternion* q, Quaternion* r, f32 t);
void C_QUATSlerp(const Quaternion* p, const Quaternion* q, Quaternion* r, f32 t);
void C_QUATSquad(const Quaternion* p, const Quaternion* a, const Quaternion* b, const Quaternion* q,
Quaternion* r, f32 t);
void C_QUATCompA(const Quaternion* qprev, const Quaternion* q, const Quaternion* qnext,
Quaternion* a);
void PSQUATAdd(const Quaternion* p, const Quaternion* q, Quaternion* r);
void PSQUATSubtract(const Quaternion* p, const Quaternion* q, Quaternion* r);
void PSQUATMultiply(const Quaternion* p, const Quaternion* q, Quaternion* pq);
void PSQUATDivide(const Quaternion* p, const Quaternion* q, Quaternion* r);
void PSQUATScale(const Quaternion* q, Quaternion* r, f32 scale);
f32 PSQUATDotProduct(const Quaternion* p, const Quaternion* q);
void PSQUATNormalize(const Quaternion* src, Quaternion* unit);
void PSQUATInverse(const Quaternion* src, Quaternion* inv);
void PSMTXReorder(const Mtx src, ROMtx dest);
void PSMTXROMultVecArray(const ROMtx m, const Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXROSkin2VecArray(const ROMtx m0, const ROMtx m1, const f32* wtBase, const Vec* srcBase,
Vec* dstBase, u32 count);
void PSMTXMultS16VecArray(const Mtx m, const S16Vec* srcBase, Vec* dstBase, u32 count);
void PSMTXROMultS16VecArray(const ROMtx m, const S16Vec* srcBase, Vec* dstBase, u32 count);
void MTXInitStack(MtxStack* sPtr, u32 numMtx);
MtxPtr MTXPush(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPushFwd(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPushInv(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPushInvXpose(MtxStack* sPtr, const Mtx m);
MtxPtr MTXPop(MtxStack* sPtr);
MtxPtr MTXGetStackPtr(const MtxStack* sPtr);
typedef struct vec2f {
float x;
float y;
} Vec2f;
typedef struct
{
u32 _pad0 :2;
u32 loadScale :6;
u32 _pad1 :5;
u32 loadType :3;
u32 _pad2 :2;
u32 storeScale :6;
u32 _pad3 :5;
u32 storeType :3;
} PPC_GQR_t;
typedef union
{
u32 val;
PPC_GQR_t f;
} PPC_GQR_u;
typedef struct
{
u32 memAddr :27;
u32 dmaLenU :5;
} PPC_DMA_U_t;
typedef union
{
u32 val;
PPC_DMA_U_t f;
} PPC_DMA_U_u;
typedef struct
{
u32 lcAddr :27;
u32 dmaLd :1;
u32 dmaLenL :2;
u32 dmaTrigger :1;
u32 dmaFlush :1;
} PPC_DMA_L_t;
typedef union
{
u32 val;
PPC_DMA_L_t f;
} PPC_DMA_L_u;
u32 PPCMfmsr();
void PPCMtmsr(u32 newMSR);
u32 PPCOrMsr(u32 value);
u32 PPCMfhid0();
void PPCMthid0(u32 newHID0);
u32 PPCMfl2cr();
void PPCMtl2cr(u32 newL2cr);
void PPCMtdec(u32 newDec);
void PPCSync();
void PPCHalt();
u32 PPCMffpscr();
void PPCMtfpscr(u32 newFPSCR);
u32 PPCMfhid2();
void PPCMthid2(u32 newhid2);
u32 PPCMfwpar();
void PPCMtwpar(u32 newwpar);
void PPCEnableSpeculation();
void PPCDisableSpeculation();
void PPCSetFpIEEEMode();
void PPCSetFpNonIEEEMode();
typedef struct DBInterface
{
u32 bPresent;
u32 exceptionMask;
void (*ExceptionDestination) ( void );
void *exceptionReturn;
} DBInterface;
extern DBInterface* __DBInterface;
void DBInit(void);
void DBInitComm(int* inputFlagPtr, int* mtrCallback);
static void __DBExceptionDestination(void);
void DBPrintf(char* format, ...);
typedef u8 GXBool;
typedef enum _GXProjectionType {
GX_PERSPECTIVE,
GX_ORTHOGRAPHIC
} GXProjectionType;
typedef enum _GXCompare {
GX_NEVER,
GX_LESS,
GX_EQUAL,
GX_LEQUAL,
GX_GREATER,
GX_NEQUAL,
GX_GEQUAL,
GX_ALWAYS
} GXCompare;
typedef enum _GXAlphaOp {
GX_AOP_AND,
GX_AOP_OR,
GX_AOP_XOR,
GX_AOP_XNOR,
GX_MAX_ALPHAOP
} GXAlphaOp;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR,
GX_ZC_NEAR,
GX_ZC_MID,
GX_ZC_FAR
} GXZFmt16;
typedef enum _GXGamma {
GX_GM_1_0,
GX_GM_1_7,
GX_GM_2_2
} GXGamma;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24,
GX_PF_RGBA6_Z24,
GX_PF_RGB565_Z16,
GX_PF_Z24,
GX_PF_Y8,
GX_PF_U8,
GX_PF_V8,
GX_PF_YUV420
} GXPixelFmt;
typedef enum _GXPrimitive {
GX_QUADS = 0x80,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xA0,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_POINTS = 0xB8
} GXPrimitive;
typedef enum _GXVtxFmt {
GX_VTXFMT0,
GX_VTXFMT1,
GX_VTXFMT2,
GX_VTXFMT3,
GX_VTXFMT4,
GX_VTXFMT5,
GX_VTXFMT6,
GX_VTXFMT7,
GX_MAX_VTXFMT
} GXVtxFmt;
typedef enum _GXAttr {
GX_VA_PNMTXIDX,
GX_VA_TEX0MTXIDX,
GX_VA_TEX1MTXIDX,
GX_VA_TEX2MTXIDX,
GX_VA_TEX3MTXIDX,
GX_VA_TEX4MTXIDX,
GX_VA_TEX5MTXIDX,
GX_VA_TEX6MTXIDX,
GX_VA_TEX7MTXIDX,
GX_VA_POS,
GX_VA_NRM,
GX_VA_CLR0,
GX_VA_CLR1,
GX_VA_TEX0,
GX_VA_TEX1,
GX_VA_TEX2,
GX_VA_TEX3,
GX_VA_TEX4,
GX_VA_TEX5,
GX_VA_TEX6,
GX_VA_TEX7,
GX_POS_MTX_ARRAY,
GX_NRM_MTX_ARRAY,
GX_TEX_MTX_ARRAY,
GX_LIGHT_ARRAY,
GX_VA_NBT,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF
} GXAttr;
typedef enum _GXAttrType {
GX_NONE,
GX_DIRECT,
GX_INDEX8,
GX_INDEX16
} GXAttrType;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_CTF_R4 = 0x0 | 0x20 ,
GX_CTF_RA4 = 0x2 | 0x20 ,
GX_CTF_RA8 = 0x3 | 0x20 ,
GX_CTF_YUVA8 = 0x6 | 0x20 ,
GX_CTF_A8 = 0x7 | 0x20 ,
GX_CTF_R8 = 0x8 | 0x20 ,
GX_CTF_G8 = 0x9 | 0x20 ,
GX_CTF_B8 = 0xA | 0x20 ,
GX_CTF_RG8 = 0xB | 0x20 ,
GX_CTF_GB8 = 0xC | 0x20 ,
GX_TF_Z8 = 0x1 | 0x10 ,
GX_TF_Z16 = 0x3 | 0x10 ,
GX_TF_Z24X8 = 0x6 | 0x10 ,
GX_CTF_Z4 = 0x0 | 0x10 | 0x20 ,
GX_CTF_Z8M = 0x9 | 0x10 | 0x20 ,
GX_CTF_Z8L = 0xA | 0x10 | 0x20 ,
GX_CTF_Z16L = 0xC | 0x10 | 0x20 ,
GX_TF_A8 = GX_CTF_A8
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xa
} GXCITexFmt;
typedef enum _GXTexWrapMode {
GX_CLAMP,
GX_REPEAT,
GX_MIRROR,
GX_MAX_TEXWRAPMODE
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR,
GX_LINEAR,
GX_NEAR_MIP_NEAR,
GX_LIN_MIP_NEAR,
GX_NEAR_MIP_LIN,
GX_LIN_MIP_LIN
} GXTexFilter;
typedef enum _GXAnisotropy {
GX_ANISO_1,
GX_ANISO_2,
GX_ANISO_4,
GX_MAX_ANISOTROPY
} GXAnisotropy;
typedef enum _GXTexMapID {
GX_TEXMAP0,
GX_TEXMAP1,
GX_TEXMAP2,
GX_TEXMAP3,
GX_TEXMAP4,
GX_TEXMAP5,
GX_TEXMAP6,
GX_TEXMAP7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100
} GXTexMapID;
typedef enum _GXTexCoordID {
GX_TEXCOORD0,
GX_TEXCOORD1,
GX_TEXCOORD2,
GX_TEXCOORD3,
GX_TEXCOORD4,
GX_TEXCOORD5,
GX_TEXCOORD6,
GX_TEXCOORD7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF
} GXTexCoordID;
typedef enum _GXTevStageID {
GX_TEVSTAGE0,
GX_TEVSTAGE1,
GX_TEVSTAGE2,
GX_TEVSTAGE3,
GX_TEVSTAGE4,
GX_TEVSTAGE5,
GX_TEVSTAGE6,
GX_TEVSTAGE7,
GX_TEVSTAGE8,
GX_TEVSTAGE9,
GX_TEVSTAGE10,
GX_TEVSTAGE11,
GX_TEVSTAGE12,
GX_TEVSTAGE13,
GX_TEVSTAGE14,
GX_TEVSTAGE15,
GX_MAX_TEVSTAGE
} GXTevStageID;
typedef enum _GXTevMode {
GX_MODULATE,
GX_DECAL,
GX_BLEND,
GX_REPLACE,
GX_PASSCLR
} GXTevMode;
typedef enum _GXTexMtxType {
GX_MTX3x4,
GX_MTX2x4
} GXTexMtxType;
typedef enum _GXTexGenType {
GX_TG_MTX3x4,
GX_TG_MTX2x4,
GX_TG_BUMP0,
GX_TG_BUMP1,
GX_TG_BUMP2,
GX_TG_BUMP3,
GX_TG_BUMP4,
GX_TG_BUMP5,
GX_TG_BUMP6,
GX_TG_BUMP7,
GX_TG_SRTG
} GXTexGenType;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 0,
GX_PNMTX1 = 3,
GX_PNMTX2 = 6,
GX_PNMTX3 = 9,
GX_PNMTX4 = 12,
GX_PNMTX5 = 15,
GX_PNMTX6 = 18,
GX_PNMTX7 = 21,
GX_PNMTX8 = 24,
GX_PNMTX9 = 27
} GXPosNrmMtx;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30,
GX_TEXMTX1 = 33,
GX_TEXMTX2 = 36,
GX_TEXMTX3 = 39,
GX_TEXMTX4 = 42,
GX_TEXMTX5 = 45,
GX_TEXMTX6 = 48,
GX_TEXMTX7 = 51,
GX_TEXMTX8 = 54,
GX_TEXMTX9 = 57,
GX_IDENTITY = 60
} GXTexMtx;
typedef enum _GXChannelID {
GX_COLOR0,
GX_COLOR1,
GX_ALPHA0,
GX_ALPHA1,
GX_COLOR0A0,
GX_COLOR1A1,
GX_COLOR_ZERO,
GX_ALPHA_BUMP,
GX_ALPHA_BUMPN,
GX_COLOR_NULL = 0xFF
} GXChannelID;
typedef enum _GXTexGenSrc {
GX_TG_POS,
GX_TG_NRM,
GX_TG_BINRM,
GX_TG_TANGENT,
GX_TG_TEX0,
GX_TG_TEX1,
GX_TG_TEX2,
GX_TG_TEX3,
GX_TG_TEX4,
GX_TG_TEX5,
GX_TG_TEX6,
GX_TG_TEX7,
GX_TG_TEXCOORD0,
GX_TG_TEXCOORD1,
GX_TG_TEXCOORD2,
GX_TG_TEXCOORD3,
GX_TG_TEXCOORD4,
GX_TG_TEXCOORD5,
GX_TG_TEXCOORD6,
GX_TG_COLOR0,
GX_TG_COLOR1,
GX_MAX_TEXGENSRC
} GXTexGenSrc;
typedef enum _GXBlendMode {
GX_BM_NONE,
GX_BM_BLEND,
GX_BM_LOGIC,
GX_BM_SUBTRACT,
GX_MAX_BLENDMODE
} GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO,
GX_BL_ONE,
GX_BL_SRCCLR,
GX_BL_INVSRCCLR,
GX_BL_SRCALPHA,
GX_BL_INVSRCALPHA,
GX_BL_DSTALPHA,
GX_BL_INVDSTALPHA,
GX_BL_DSTCLR = GX_BL_SRCCLR,
GX_BL_INVDSTCLR = GX_BL_INVSRCCLR
} GXBlendFactor;
typedef enum _GXLogicOp {
GX_LO_CLEAR,
GX_LO_AND,
GX_LO_REVAND,
GX_LO_COPY,
GX_LO_INVAND,
GX_LO_NOOP,
GX_LO_XOR,
GX_LO_OR,
GX_LO_NOR,
GX_LO_EQUIV,
GX_LO_INV,
GX_LO_REVOR,
GX_LO_INVCOPY,
GX_LO_INVOR,
GX_LO_NAND,
GX_LO_SET
} GXLogicOp;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5
} GXCompType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64,
GX_PTTEXMTX1 = 67,
GX_PTTEXMTX2 = 70,
GX_PTTEXMTX3 = 73,
GX_PTTEXMTX4 = 76,
GX_PTTEXMTX5 = 79,
GX_PTTEXMTX6 = 82,
GX_PTTEXMTX7 = 85,
GX_PTTEXMTX8 = 88,
GX_PTTEXMTX9 = 91,
GX_PTTEXMTX10 = 94,
GX_PTTEXMTX11 = 97,
GX_PTTEXMTX12 = 100,
GX_PTTEXMTX13 = 103,
GX_PTTEXMTX14 = 106,
GX_PTTEXMTX15 = 109,
GX_PTTEXMTX16 = 112,
GX_PTTEXMTX17 = 115,
GX_PTTEXMTX18 = 118,
GX_PTTEXMTX19 = 121,
GX_PTIDENTITY = 125
} GXPTTexMtx;
typedef enum _GXTevRegID {
GX_TEVPREV,
GX_TEVREG0,
GX_TEVREG1,
GX_TEVREG2,
GX_MAX_TEVREG
} GXTevRegID;
typedef enum _GXDiffuseFn {
GX_DF_NONE,
GX_DF_SIGN,
GX_DF_CLAMP
} GXDiffuseFn;
typedef enum _GXColorSrc {
GX_SRC_REG,
GX_SRC_VTX
} GXColorSrc;
typedef enum _GXAttnFn {
GX_AF_SPEC,
GX_AF_SPOT,
GX_AF_NONE
} GXAttnFn;
typedef enum _GXLightID {
GX_LIGHT0 = 0x001,
GX_LIGHT1 = 0x002,
GX_LIGHT2 = 0x004,
GX_LIGHT3 = 0x008,
GX_LIGHT4 = 0x010,
GX_LIGHT5 = 0x020,
GX_LIGHT6 = 0x040,
GX_LIGHT7 = 0x080,
GX_MAX_LIGHT = 0x100,
GX_LIGHT_NULL = 0
} GXLightID;
typedef enum _GXTexOffset {
GX_TO_ZERO,
GX_TO_SIXTEENTH,
GX_TO_EIGHTH,
GX_TO_FOURTH,
GX_TO_HALF,
GX_TO_ONE,
GX_MAX_TEXOFFSET
} GXTexOffset;
typedef enum _GXSpotFn {
GX_SP_OFF,
GX_SP_FLAT,
GX_SP_COS,
GX_SP_COS2,
GX_SP_SHARP,
GX_SP_RING1,
GX_SP_RING2
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF,
GX_DA_GENTLE,
GX_DA_MEDIUM,
GX_DA_STEEP
} GXDistAttnFn;
typedef enum _GXCullMode {
GX_CULL_NONE,
GX_CULL_FRONT,
GX_CULL_BACK,
GX_CULL_ALL
} GXCullMode;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1,
GX_TEV_SWAP2,
GX_TEV_SWAP3,
GX_MAX_TEVSWAP
} GXTevSwapSel;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN,
GX_CH_BLUE,
GX_CH_ALPHA
} GXTevColorChan;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_PERSP_LIN = 2,
GX_FOG_PERSP_EXP = 4,
GX_FOG_PERSP_EXP2 = 5,
GX_FOG_PERSP_REVEXP = 6,
GX_FOG_PERSP_REVEXP2 = 7,
GX_FOG_ORTHO_LIN = 10,
GX_FOG_ORTHO_EXP = 12,
GX_FOG_ORTHO_EXP2 = 13,
GX_FOG_ORTHO_REVEXP = 14,
GX_FOG_ORTHO_REVEXP2 = 15,
GX_FOG_LIN = GX_FOG_PERSP_LIN,
GX_FOG_EXP = GX_FOG_PERSP_EXP,
GX_FOG_EXP2 = GX_FOG_PERSP_EXP2,
GX_FOG_REVEXP = GX_FOG_PERSP_REVEXP,
GX_FOG_REVEXP2 = GX_FOG_PERSP_REVEXP2
} GXFogType;
typedef enum _GXTevColorArg {
GX_CC_CPREV,
GX_CC_APREV,
GX_CC_C0,
GX_CC_A0,
GX_CC_C1,
GX_CC_A1,
GX_CC_C2,
GX_CC_A2,
GX_CC_TEXC,
GX_CC_TEXA,
GX_CC_RASC,
GX_CC_RASA,
GX_CC_ONE,
GX_CC_HALF,
GX_CC_KONST,
GX_CC_ZERO
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV,
GX_CA_A0,
GX_CA_A1,
GX_CA_A2,
GX_CA_TEXA,
GX_CA_RASA,
GX_CA_KONST,
GX_CA_ZERO
} GXTevAlphaArg;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ
} GXTevOp;
typedef enum _GXTevBias {
GX_TB_ZERO,
GX_TB_ADDHALF,
GX_TB_SUBHALF,
GX_MAX_TEVBIAS
} GXTevBias;
typedef enum _GXTevScale {
GX_CS_SCALE_1,
GX_CS_SCALE_2,
GX_CS_SCALE_4,
GX_CS_DIVIDE_2,
GX_MAX_TEVSCALE
} GXTevScale;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_8_8 = 0x00,
GX_TEV_KCSEL_7_8 = 0x01,
GX_TEV_KCSEL_6_8 = 0x02,
GX_TEV_KCSEL_5_8 = 0x03,
GX_TEV_KCSEL_4_8 = 0x04,
GX_TEV_KCSEL_3_8 = 0x05,
GX_TEV_KCSEL_2_8 = 0x06,
GX_TEV_KCSEL_1_8 = 0x07,
GX_TEV_KCSEL_1 = GX_TEV_KCSEL_8_8,
GX_TEV_KCSEL_3_4 = GX_TEV_KCSEL_6_8,
GX_TEV_KCSEL_1_2 = GX_TEV_KCSEL_4_8,
GX_TEV_KCSEL_1_4 = GX_TEV_KCSEL_2_8,
GX_TEV_KCSEL_K0 = 0x0C,
GX_TEV_KCSEL_K1 = 0x0D,
GX_TEV_KCSEL_K2 = 0x0E,
GX_TEV_KCSEL_K3 = 0x0F,
GX_TEV_KCSEL_K0_R = 0x10,
GX_TEV_KCSEL_K1_R = 0x11,
GX_TEV_KCSEL_K2_R = 0x12,
GX_TEV_KCSEL_K3_R = 0x13,
GX_TEV_KCSEL_K0_G = 0x14,
GX_TEV_KCSEL_K1_G = 0x15,
GX_TEV_KCSEL_K2_G = 0x16,
GX_TEV_KCSEL_K3_G = 0x17,
GX_TEV_KCSEL_K0_B = 0x18,
GX_TEV_KCSEL_K1_B = 0x19,
GX_TEV_KCSEL_K2_B = 0x1A,
GX_TEV_KCSEL_K3_B = 0x1B,
GX_TEV_KCSEL_K0_A = 0x1C,
GX_TEV_KCSEL_K1_A = 0x1D,
GX_TEV_KCSEL_K2_A = 0x1E,
GX_TEV_KCSEL_K3_A = 0x1F
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_8_8 = 0x00,
GX_TEV_KASEL_7_8 = 0x01,
GX_TEV_KASEL_6_8 = 0x02,
GX_TEV_KASEL_5_8 = 0x03,
GX_TEV_KASEL_4_8 = 0x04,
GX_TEV_KASEL_3_8 = 0x05,
GX_TEV_KASEL_2_8 = 0x06,
GX_TEV_KASEL_1_8 = 0x07,
GX_TEV_KASEL_1 = GX_TEV_KASEL_8_8,
GX_TEV_KASEL_3_4 = GX_TEV_KASEL_6_8,
GX_TEV_KASEL_1_2 = GX_TEV_KASEL_4_8,
GX_TEV_KASEL_1_4 = GX_TEV_KASEL_2_8,
GX_TEV_KASEL_K0_R = 0x10,
GX_TEV_KASEL_K1_R = 0x11,
GX_TEV_KASEL_K2_R = 0x12,
GX_TEV_KASEL_K3_R = 0x13,
GX_TEV_KASEL_K0_G = 0x14,
GX_TEV_KASEL_K1_G = 0x15,
GX_TEV_KASEL_K2_G = 0x16,
GX_TEV_KASEL_K3_G = 0x17,
GX_TEV_KASEL_K0_B = 0x18,
GX_TEV_KASEL_K1_B = 0x19,
GX_TEV_KASEL_K2_B = 0x1A,
GX_TEV_KASEL_K3_B = 0x1B,
GX_TEV_KASEL_K0_A = 0x1C,
GX_TEV_KASEL_K1_A = 0x1D,
GX_TEV_KASEL_K2_A = 0x1E,
GX_TEV_KASEL_K3_A = 0x1F
} GXTevKAlphaSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1,
GX_KCOLOR2,
GX_KCOLOR3,
GX_MAX_KCOLOR
} GXTevKColorID;
typedef enum _GXZTexOp {
GX_ZT_DISABLE,
GX_ZT_ADD,
GX_ZT_REPLACE,
GX_MAX_ZTEXO
} GXZTexOp;
typedef enum _GXIndTexFormat {
GX_ITF_8,
GX_ITF_5,
GX_ITF_4,
GX_ITF_3,
GX_MAX_ITFORMAT
} GXIndTexFormat;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE,
GX_ITB_S,
GX_ITB_T,
GX_ITB_ST,
GX_ITB_U,
GX_ITB_SU,
GX_ITB_TU,
GX_ITB_STU,
GX_MAX_ITBIAS
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF,
GX_ITBA_S,
GX_ITBA_T,
GX_ITBA_U,
GX_MAX_ITBALPHA
} GXIndTexAlphaSel;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF,
GX_ITM_0,
GX_ITM_1,
GX_ITM_2,
GX_ITM_S0 = 5,
GX_ITM_S1,
GX_ITM_S2,
GX_ITM_T0 = 9,
GX_ITM_T1,
GX_ITM_T2
} GXIndTexMtxID;
typedef enum _GXIndTexWrap {
GX_ITW_OFF,
GX_ITW_256,
GX_ITW_128,
GX_ITW_64,
GX_ITW_32,
GX_ITW_16,
GX_ITW_0,
GX_MAX_ITWRAP
} GXIndTexWrap;
typedef enum _GXIndTexStageID {
GX_INDTEXSTAGE0,
GX_INDTEXSTAGE1,
GX_INDTEXSTAGE2,
GX_INDTEXSTAGE3,
GX_MAX_INDTEXSTAGE
} GXIndTexStageID;
typedef enum _GXIndTexScale {
GX_ITS_1,
GX_ITS_2,
GX_ITS_4,
GX_ITS_8,
GX_ITS_16,
GX_ITS_32,
GX_ITS_64,
GX_ITS_128,
GX_ITS_256,
GX_MAX_ITSCALE
} GXIndTexScale;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1
} GXClipMode;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8,
GX_TL_RGB565,
GX_TL_RGB5A3,
GX_MAX_TLUTFMT
} GXTlutFmt;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3
} GXMiscToken;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K,
GX_TEXCACHE_128K,
GX_TEXCACHE_512K,
GX_TEXCACHE_NONE
} GXTexCacheSize;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES,
GX_PERF0_CLIP_VTX,
GX_PERF0_CLIP_CLKS,
GX_PERF0_XF_WAIT_IN,
GX_PERF0_XF_WAIT_OUT,
GX_PERF0_XF_XFRM_CLKS,
GX_PERF0_XF_LIT_CLKS,
GX_PERF0_XF_BOT_CLKS,
GX_PERF0_XF_REGLD_CLKS,
GX_PERF0_XF_REGRD_CLKS,
GX_PERF0_CLIP_RATIO,
GX_PERF0_TRIANGLES,
GX_PERF0_TRIANGLES_CULLED,
GX_PERF0_TRIANGLES_PASSED,
GX_PERF0_TRIANGLES_SCISSORED,
GX_PERF0_TRIANGLES_0TEX,
GX_PERF0_TRIANGLES_1TEX,
GX_PERF0_TRIANGLES_2TEX,
GX_PERF0_TRIANGLES_3TEX,
GX_PERF0_TRIANGLES_4TEX,
GX_PERF0_TRIANGLES_5TEX,
GX_PERF0_TRIANGLES_6TEX,
GX_PERF0_TRIANGLES_7TEX,
GX_PERF0_TRIANGLES_8TEX,
GX_PERF0_TRIANGLES_0CLR,
GX_PERF0_TRIANGLES_1CLR,
GX_PERF0_TRIANGLES_2CLR,
GX_PERF0_QUAD_0CVG,
GX_PERF0_QUAD_NON0CVG,
GX_PERF0_QUAD_1CVG,
GX_PERF0_QUAD_2CVG,
GX_PERF0_QUAD_3CVG,
GX_PERF0_QUAD_4CVG,
GX_PERF0_AVG_QUAD_CNT,
GX_PERF0_CLOCKS,
GX_PERF0_NONE
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS,
GX_PERF1_TX_IDLE,
GX_PERF1_TX_REGS,
GX_PERF1_TX_MEMSTALL,
GX_PERF1_TC_CHECK1_2,
GX_PERF1_TC_CHECK3_4,
GX_PERF1_TC_CHECK5_6,
GX_PERF1_TC_CHECK7_8,
GX_PERF1_TC_MISS,
GX_PERF1_VC_ELEMQ_FULL,
GX_PERF1_VC_MISSQ_FULL,
GX_PERF1_VC_MEMREQ_FULL,
GX_PERF1_VC_STATUS7,
GX_PERF1_VC_MISSREP_FULL,
GX_PERF1_VC_STREAMBUF_LOW,
GX_PERF1_VC_ALL_STALLS,
GX_PERF1_VERTICES,
GX_PERF1_FIFO_REQ,
GX_PERF1_CALL_REQ,
GX_PERF1_VC_MISS_REQ,
GX_PERF1_CP_ALL_REQ,
GX_PERF1_CLOCKS,
GX_PERF1_NONE
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS,
GX_VC_NRM,
GX_VC_CLR0,
GX_VC_CLR1,
GX_VC_TEX0,
GX_VC_TEX1,
GX_VC_TEX2,
GX_VC_TEX3,
GX_VC_TEX4,
GX_VC_TEX5,
GX_VC_TEX6,
GX_VC_TEX7,
GX_VC_ALL = 0xf
} GXVCachePerf;
typedef enum _GXFBClamp {
GX_CLAMP_NONE = 0,
GX_CLAMP_TOP = 1,
GX_CLAMP_BOTTOM = 2
} GXFBClamp;
typedef enum _GXCopyMode {
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3
} GXCopyMode;
typedef enum _GXAlphaReadMode {
GX_READ_00 = 0,
GX_READ_FF = 1,
GX_READ_NONE = 2
} GXAlphaReadMode;
typedef enum {
VI_TVMODE_NTSC_INT = (((0) << 2) + (0)) ,
VI_TVMODE_NTSC_DS = (((0) << 2) + (1)) ,
VI_TVMODE_NTSC_PROG = (((0) << 2) + (2)) ,
VI_TVMODE_NTSC_3D = (((0) << 2) + (3)) ,
VI_TVMODE_PAL_INT = (((1) << 2) + (0)) ,
VI_TVMODE_PAL_DS = (((1) << 2) + (1)) ,
VI_TVMODE_MPAL_INT = (((2) << 2) + (0)) ,
VI_TVMODE_MPAL_DS = (((2) << 2) + (1)) ,
VI_TVMODE_DEBUG_INT = (((3) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_INT = (((4) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_DS = (((4) << 2) + (1)) ,
VI_TVMODE_EURGB60_INT = (((5) << 2) + (0)) ,
VI_TVMODE_EURGB60_DS = (((5) << 2) + (1)) ,
VI_TVMODE_GCA_INT = (((6) << 2) + (0)) ,
VI_TVMODE_GCA_DS = (((6) << 2) + (1)) ,
VI_TVMODE_GCA_PROG = (((6) << 2) + (2))
} VITVMode;
typedef enum {
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF = 1
} VIXFBMode;
typedef void (*VIPositionCallback)(s16 x, s16 y);
typedef void (*VIRetraceCallback)(u32 retraceCount);
typedef struct VITimingInfo {
u8 equ;
u16 acv;
u16 prbOdd;
u16 prbEven;
u16 psbOdd;
u16 psbEven;
u8 bs1;
u8 bs2;
u8 bs3;
u8 bs4;
u16 be1;
u16 be2;
u16 be3;
u16 be4;
u16 numHalfLines;
u16 hlw;
u8 hsy;
u8 hcs;
u8 hce;
u8 hbe640;
u16 hbs640;
u8 hbeCCIR656;
u16 hbsCCIR656;
} VITimingInfo;
typedef struct VIPositionInfo {
u16 dispPosX;
u16 dispPosY;
u16 dispSizeX;
u16 dispSizeY;
u16 adjDispPosX;
u16 adjDispPosY;
u16 adjDispSizeY;
u16 adjPanPosY;
u16 adjPanSizeY;
u16 fbSizeX;
u16 fbSizeY;
u16 panPosX;
u16 panPosY;
u16 panSizeX;
u16 panSizeY;
VIXFBMode xfbMode;
u32 nonInter;
u32 tv;
u8 wordPerLine;
u8 std;
u8 wpl;
u32 bufAddr;
u32 tfbb;
u32 bfbb;
u8 xof;
BOOL isBlack;
BOOL is3D;
u32 rbufAddr;
u32 rtfbb;
u32 rbfbb;
VITimingInfo* timing;
} VIPositionInfo;
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXColor {
u8 r;
u8 g;
u8 b;
u8 a;
} GXColor;
typedef struct _GXTexObj {
u32 dummy[8];
} GXTexObj;
typedef struct _GXTlutObj {
u32 dummy[3];
} GXTlutObj;
typedef struct _GXLightObj {
u32 dummy[16];
} GXLightObj;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXColorS10 {
s16 r;
s16 g;
s16 b;
s16 a;
} GXColorS10;
typedef struct _GXTexRegion {
u32 dummy[4];
} GXTexRegion;
typedef struct _GXTlutRegion {
u32 dummy[4];
} GXTlutRegion;
typedef struct _GXFogAdjTable
{
u16 r[10];
} GXFogAdjTable;
typedef enum _GXTlutSize
{
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024
} GXTlutSize;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt cnt;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
void GXSetTevDirect(GXTevStageID tev_stage);
void GXSetNumIndStages(u8 nIndStages);
void GXSetIndTexMtx(GXIndTexMtxID mtx_sel, f32 offset[2][3], s8 scale_exp);
void GXSetIndTexOrder(GXIndTexStageID ind_stage, GXTexCoordID tex_coord, GXTexMapID tex_map);
void GXSetTevIndirect(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXIndTexFormat format,
GXIndTexBiasSel bias_sel, GXIndTexMtxID matrix_sel, GXIndTexWrap wrap_s,
GXIndTexWrap wrap_t, GXBool add_prev, GXBool ind_lod,
GXIndTexAlphaSel alpha_sel);
void GXSetTevIndTile (GXTevStageID tev_stage, GXIndTexStageID ind_stage,
u16 tilesize_s, u16 tilesize_t,
u16 tilespacing_s, u16 tilespacing_t,
GXIndTexFormat format, GXIndTexMtxID matrix_sel,
GXIndTexBiasSel bias_sel, GXIndTexAlphaSel alpha_sel);
void GXSetIndTexCoordScale(GXIndTexStageID ind_state, GXIndTexScale scale_s, GXIndTexScale scale_t);
void GXSetScissor(u32 left, u32 top, u32 wd, u32 ht);
void GXSetCullMode(GXCullMode mode);
void GXSetCoPlanar(GXBool enable);
void GXBeginDisplayList(void* list, u32 size);
u32 GXEndDisplayList(void);
void GXCallDisplayList(const void* list, u32 nbytes);
void GXDrawSphere(u8 numMajor, u8 numMinor);
typedef struct {
u8 pad[128];
} GXFifoObj;
typedef void (*GXBreakPtCallback)(void);
void GXInitFifoBase(GXFifoObj* fifo, void* base, u32 size);
void GXInitFifoPtrs(GXFifoObj* fifo, void* readPtr, void* writePtr);
void GXGetFifoPtrs(GXFifoObj* fifo, void** readPtr, void** writePtr);
GXFifoObj* GXGetCPUFifo(void);
GXFifoObj* GXGetGPFifo(void);
void GXSetCPUFifo(GXFifoObj* fifo);
void GXSetGPFifo(GXFifoObj* fifo);
void GXSaveCPUFifo(GXFifoObj* fifo);
void GXGetFifoStatus(GXFifoObj* fifo, GXBool* overhi, GXBool* underlow, u32* fifoCount,
GXBool* cpu_write, GXBool* gp_read, GXBool* fifowrap);
void GXGetGPStatus(GXBool* overhi, GXBool* underlow, GXBool* readIdle, GXBool* cmdIdle,
GXBool* brkpt);
void GXInitFifoLimits(GXFifoObj* fifo, u32 hiWaterMark, u32 loWaterMark);
GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback cb);
void GXEnableBreakPt(void* breakPt);
void GXDisableBreakPt(void);
extern GXRenderModeObj GXNtsc240Ds;
extern GXRenderModeObj GXNtsc240DsAa;
extern GXRenderModeObj GXNtsc240Int;
extern GXRenderModeObj GXNtsc240IntAa;
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXNtsc480IntAa;
extern GXRenderModeObj GXNtsc480Prog;
extern GXRenderModeObj GXNtsc480ProgAa;
extern GXRenderModeObj GXMpal240Ds;
extern GXRenderModeObj GXMpal240DsAa;
extern GXRenderModeObj GXMpal240Int;
extern GXRenderModeObj GXMpal240IntAa;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXMpal480Int;
extern GXRenderModeObj GXMpal480IntAa;
extern GXRenderModeObj GXPal264Ds;
extern GXRenderModeObj GXPal264DsAa;
extern GXRenderModeObj GXPal264Int;
extern GXRenderModeObj GXPal264IntAa;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXPal528Int;
extern GXRenderModeObj GXPal524IntAa;
extern GXRenderModeObj GXEurgb60Hz240Ds;
extern GXRenderModeObj GXEurgb60Hz240DsAa;
extern GXRenderModeObj GXEurgb60Hz240Int;
extern GXRenderModeObj GXEurgb60Hz240IntAa;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
extern GXRenderModeObj GXEurgb60Hz480Int;
extern GXRenderModeObj GXEurgb60Hz480IntAa;
void GXSetCopyClear(GXColor clear_clr, u32 clear_z);
void GXAdjustForOverscan(GXRenderModeObj* rmin, GXRenderModeObj* rmout, u16 hor, u16 ver);
void GXCopyDisp(void* dest, GXBool clear);
void GXSetDispCopyGamma(GXGamma gamma);
void GXSetDispCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetDispCopyDst(u16 wd, u16 ht);
f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
u32 GXSetDispCopyYScale(f32 vscale);
void GXSetCopyFilter(GXBool aa, u8 sample_pattern[12][2], GXBool vf, u8 vfilter[7]);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetTexCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetTexCopyDst(u16 wd, u16 ht, GXTexFmt fmt, GXBool mipmap);
void GXCopyTex(void* dest, GXBool clear);
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(GXVtxDescList* list);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetNumTexGens(u8 nTexGens);
void GXBegin(GXPrimitive type, GXVtxFmt vtxfmt, u16 nverts);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx,
GXBool normalize, u32 postmtx);
void GXSetLineWidth(u8 width, GXTexOffset texOffsets);
void GXSetPointSize(u8 pointSize, GXTexOffset texOffsets);
void GXEnableTexOffsets(GXTexCoordID coord, GXBool line_enable, GXBool point_enable);
void GXSetArray(GXAttr attr, const void* data, u8 stride);
void GXInvalidateVtxCache(void);
static inline void GXSetTexCoordGen(GXTexCoordID dst_coord, GXTexGenType func,
GXTexGenSrc src_param, u32 mtx) {
GXSetTexCoordGen2(dst_coord, func, src_param, mtx, ((GXBool)0) , GX_PTIDENTITY);
}
GXBool GXGetTexObjMipMap(const GXTexObj* obj);
GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
u16 GXGetTexObjHeight(const GXTexObj* obj);
u16 GXGetTexObjWidth(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapS(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapT(const GXTexObj* obj);
void* GXGetTexObjData(const GXTexObj* obj);
void GXGetProjectionv(f32* p);
void GXGetLightPos(const GXLightObj* lt_obj, f32* x, f32* y, f32* z);
void GXGetLightColor(const GXLightObj* lt_obj, GXColor* color);
void GXGetVtxAttrFmt(GXVtxFmt idx, GXAttr attr, GXCompCnt* compCnt, GXCompType* compType,
u8* shift);
void GXSetNumChans(u8 nChans);
void GXSetChanCtrl(GXChannelID chan, GXBool enable, GXColorSrc amb_src, GXColorSrc mat_src,
u32 light_mask, GXDiffuseFn diff_fn, GXAttnFn attn_fn);
void GXSetChanAmbColor(GXChannelID chan, GXColor amb_color);
void GXSetChanMatColor(GXChannelID chan, GXColor mat_color);
void GXInitLightSpot(GXLightObj* lt_obj, f32 cutoff, GXSpotFn spot_func);
void GXInitLightDistAttn(GXLightObj* lt_obj, f32 ref_distance, f32 ref_brightness,
GXDistAttnFn dist_func);
void GXInitLightPos(GXLightObj* lt_obj, f32 x, f32 y, f32 z);
void GXInitLightDir(GXLightObj* lt_obj, f32 nx, f32 ny, f32 nz);
void GXInitLightColor(GXLightObj* lt_obj, GXColor color);
void GXInitLightAttn(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
void GXInitLightAttnA(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2);
void GXInitLightAttnK(GXLightObj* lt_obj, f32 k0, f32 k1, f32 k2);
void GXLoadLightObjImm(GXLightObj* lt_obj, GXLightID light);
typedef void (*GXDrawDoneCallback)(void);
typedef void (*GXDrawSyncCallback)(u16 token);
GXFifoObj* GXInit(void* base, u32 size);
GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback cb);
void GXSetDrawSync(u16 token);
GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback callback);
void GXDrawDone(void);
void GXSetDrawDone(void);
void GXFlush(void);
void GXPixModeSync(void);
void GXSetMisc(GXMiscToken token, u32 val);
extern void GXSetGPMetric(GXPerf0 perf0, GXPerf1 perf1);
extern void GXClearGPMetric();
extern void GXReadXfRasMetric(u32* xfWaitIn, u32* xfWaitOut, u32* rasBusy, u32* clocks);
extern void GXReadGPMetric(u32* count0, u32* count1);
extern u32 GXReadGP0Metric();
extern u32 GXReadGP1Metric();
extern void GXReadMemMetric(u32* cpReq, u32* tcReq, u32* cpuReadReq, u32* cpuWriteReq, u32* dspReq, u32* ioReq, u32* viReq, u32* peReq,
u32* rfReq, u32* fiReq);
extern void GXClearMemMetric();
extern void GXReadPixMetric(u32* topIn, u32* topOut, u32* bottomIn, u32* bottomOut, u32* clearIn, u32* copyClocks);
extern void GXClearPixMetric();
extern void GXSetVCacheMetric(GXVCachePerf attr);
extern void GXReadVCacheMetric(u32* check, u32* miss, u32* stall);
extern void GXClearVCacheMetric();
extern void GXInitXfRasMetric();
extern u32 GXReadClksPerVtx();
void GXSetFog(GXFogType type, f32 startz, f32 endz, f32 nearz, f32 farz, GXColor color);
void GXSetFogColor(GXColor color);
void GXSetBlendMode(GXBlendMode type, GXBlendFactor src_factor, GXBlendFactor dst_factor,
GXLogicOp op);
void GXSetColorUpdate(GXBool update_enable);
void GXSetAlphaUpdate(GXBool update_enable);
void GXSetZMode(GXBool compare_enable, GXCompare func, GXBool update_enable);
void GXSetZCompLoc(GXBool before_tex);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetDither(GXBool dither);
void GXSetDstAlpha(GXBool enable, u8 alpha);
void GXSetFieldMode(u8 field_mode, u8 half_aspect_ratio);
void GXSetTevOp(GXTevStageID id, GXTevMode mode);
void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c,
GXTevColorArg d);
void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c,
GXTevAlphaArg d);
void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevColor(GXTevRegID id, GXColor color);
void GXSetTevColorS10(GXTevRegID id, GXColorS10 color);
void GXSetTevKColor(GXTevKColorID id, GXColor color);
void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel ras_sel, GXTevSwapSel tex_sel);
void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green,
GXTevColorChan blue, GXTevColorChan alpha);
void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
void GXSetZTexture(GXZTexOp op, GXTexFmt fmt, u32 bias);
void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
void GXSetNumTevStages(u8 nStages);
typedef GXTexRegion *(*GXTexRegionCallback)(GXTexObj *t_obj, GXTexMapID id);
typedef GXTlutRegion *(*GXTlutRegionCallback)(u32 idx);
u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, u8 mipmap, u8 max_lod);
void GXInitTexObj(GXTexObj *obj, void *image_ptr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode wrap_s, GXTexWrapMode wrap_t, u8 mipmap);
void GXInitTexObjCI(GXTexObj *obj, void *image_ptr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode wrap_s, GXTexWrapMode wrap_t, u8 mipmap, u32 tlut_name);
void GXInitTexObjLOD(GXTexObj *obj, GXTexFilter min_filt, GXTexFilter mag_filt,
f32 min_lod, f32 max_lod, f32 lod_bias, GXBool bias_clamp,
GXBool do_edge_lod, GXAnisotropy max_aniso);
void GXInitTexObjData(GXTexObj *obj, void *image_ptr);
void GXInitTexObjWrapMode(GXTexObj *obj, GXTexWrapMode s, GXTexWrapMode t);
void GXInitTexObjTlut(GXTexObj *obj, u32 tlut_name);
void GXInitTexObjUserData(GXTexObj *obj, void *user_data);
void *GXGetTexObjUserData(const GXTexObj *obj);
void GXLoadTexObjPreLoaded(GXTexObj *obj, GXTexRegion *region, GXTexMapID id);
void GXLoadTexObj(GXTexObj *obj, GXTexMapID id);
void GXInitTlutObj(GXTlutObj *tlut_obj, void *lut, GXTlutFmt fmt, u16 n_entries);
void GXLoadTlut(GXTlutObj *tlut_obj, u32 tlut_name);
void GXInitTexCacheRegion(GXTexRegion *region, u8 is_32b_mipmap, u32 tmem_even, GXTexCacheSize size_even, u32 tmem_odd, GXTexCacheSize size_odd);
void GXInitTexPreLoadRegion(GXTexRegion *region, u32 tmem_even, u32 size_even, u32 tmem_odd, u32 size_odd);
void GXInitTlutRegion(GXTlutRegion *region, u32 tmem_addr, GXTlutSize tlut_size);
void GXInvalidateTexRegion(GXTexRegion *region);
void GXInvalidateTexAll(void);
GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback f);
GXTlutRegionCallback GXSetTlutRegionCallback(GXTlutRegionCallback f);
void GXPreLoadEntireTexture(GXTexObj *tex_obj, GXTexRegion *region);
void GXSetTexCoordScaleManually(GXTexCoordID coord, u8 enable, u16 ss, u16 ts);
void GXSetTexCoordCylWrap(GXTexCoordID coord, u8 s_enable, u8 t_enable);
void GXSetTexCoordBias(GXTexCoordID coord, u8 s_enable, u8 t_enable);
void GXSetProjection(f32 mtx[4][4], GXProjectionType type);
void GXLoadPosMtxImm(f32 mtx[3][4], u32 id);
void GXLoadNrmMtxImm(f32 mtx[3][4], u32 id);
void GXLoadTexMtxImm(f32 mtx[][4], u32 id, GXTexMtxType type);
void GXProject(f32 x, f32 y, f32 z, const f32 mtx[3][4], const f32 *pm, const f32 *vp, f32 *sx, f32 *sy, f32 *sz);
void GXGetViewportv(f32 *vp);
void GXSetViewport(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz);
void GXSetCurrentMtx(u32 id);
void GXSetViewportJitter(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz, u32 field);
void GXSetScissorBoxOffset(s32 x_off, s32 y_off);
void GXSetClipMode(GXClipMode mode);
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
volatile PPCWGPipe GXWGFifo : 0xCC008000 ;
static inline void GXPosition2f32(const f32 x, const f32 y) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
}
static inline void GXPosition2u16(const u16 x, const u16 y) {
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
}
static inline void GXPosition2s16(const s16 x, const s16 y) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
}
static inline void GXPosition3s16(const s16 x, const s16 y, const s16 z) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXPosition3u8(const u8 x, const u8 y, const u8 z) {
GXWGFifo.u8 = x;
GXWGFifo.u8 = y;
GXWGFifo.u8 = z;
}
static inline void GXPosition3f32(const f32 x, const f32 y, const f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXNormal3s16(const s16 x, const s16 y, const s16 z) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXNormal3f32(const f32 x, const f32 y, const f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXColor1u32(const u32 v) {
GXWGFifo.u32 = v;
}
static inline void GXColor3u8(const u8 r, const u8 g, const u8 b) {
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
}
static inline void GXColor4u8(const u8 r, const u8 g, const u8 b, const u8 a) {
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
GXWGFifo.u8 = a;
}
static inline void GXTexCoord2s16(const s16 u, const s16 v) {
GXWGFifo.s16 = u;
GXWGFifo.s16 = v;
}
static inline void GXTexCoord2f32(const f32 u, const f32 v) {
GXWGFifo.f32 = u;
GXWGFifo.f32 = v;
}
static inline void GXPosition1x8(u8 index) {
GXWGFifo.u8 = index;
}
static inline void GXColor1x8(u8 index) {
GXWGFifo.u8 = index;
}
static inline void GXPosition1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXNormal1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXColor1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXTexCoord1x16(u16 index) {
GXWGFifo.u16 = index;
}
static inline void GXUnknownu16(const u16 x) {
GXWGFifo.u16 = x;
}
static inline void GXEnd(void) {}
typedef s64 OSTime;
typedef u32 OSTick;
u32 __OSBusClock : ((0x8000 << 16) | 0x00F8) ;
u32 __OSCoreClock : ((0x8000 << 16) | 0x00FC) ;
void OSInit();
OSTime OSGetTime();
OSTick OSGetTick();
typedef struct OSCalendarTime {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime *td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime *td);
typedef struct OSStopwatch {
char *name;
OSTime total;
u32 hits;
OSTime min;
OSTime max;
OSTime last;
BOOL running;
} OSStopwatch;
void OSInitStopwatch(OSStopwatch *sw, char *name);
void OSStartStopwatch(OSStopwatch *sw);
void OSStopStopwatch(OSStopwatch *sw);
OSTime OSCheckStopwatch(OSStopwatch *sw);
void OSResetStopwatch(OSStopwatch *sw);
void OSDumpStopwatch(OSStopwatch *sw);
u32 OSGetConsoleType();
u32 OSGetSoundMode(void);
void OSSetSoundMode(u32 mode);
u32 OSGetProgressiveMode(void);
void OSSetProgressiveMode(u32 on);
u8 OSGetLanguage(void);
void OSSetLanguage(u8 language);
u32 OSGetEuRgb60Mode(void);
void OSSetEuRgb60Mode(u32 on);
void OSRegisterVersion(const char *id);
BOOL OSDisableInterrupts(void);
BOOL OSEnableInterrupts(void);
BOOL OSRestoreInterrupts(BOOL level);
void OSReport(const char *msg, ...);
void OSPanic(const char *file, int line, const char *msg, ...);
void OSFatal(GXColor fg, GXColor bg, const char *msg);
u32 OSGetPhysicalMemSize(void);
u32 OSGetConsoleSimulatedMemSize(void);
typedef struct OSContext {
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
u32 fpscr_pad;
u32 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
u32 psf_pad;
f64 psf[32];
} OSContext;
u32 OSGetStackPointer(void);
void OSDumpContext(OSContext *context);
u32 OSSaveContext(OSContext* context);
void OSLoadContext(OSContext* context);
void OSClearContext(OSContext* context);
OSContext* OSGetCurrentContext();
void OSSetCurrentContext(OSContext* context);
void OSSaveFPUContext(OSContext *fpuContext);
void OSInitContext(OSContext *context, u32 pc, u32 newsp);
typedef struct OSAlarm OSAlarm;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm {
OSAlarmHandler handler;
u32 tag;
OSTime fire;
OSAlarm* prev;
OSAlarm* next;
OSTime period;
OSTime start;
};
void OSInitAlarm(void);
void OSSetAlarm(OSAlarm* alarm, OSTime tick, OSAlarmHandler handler);
void OSSetAlarmTag(OSAlarm* alarm, u32 tag);
void OSSetAbsAlarm(OSAlarm* alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm* alarm, OSTime start, OSTime period, OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm* alarm);
void OSCancelAlarm(OSAlarm* alarm);
void OSCancelAlarms(u32 tag);
BOOL OSCheckAlarmQueue(void);
typedef int OSHeapHandle;
typedef void (*OSAllocVisitor)(void *obj, u32 size);
void *OSInitAlloc(void *arenaStart, void *arenaEnd, int maxHeaps);
OSHeapHandle OSCreateHeap(void *start, void *end);
void OSDestroyHeap(OSHeapHandle heap);
void OSAddToHeap(OSHeapHandle heap, void *start, void *end);
OSHeapHandle OSSetCurrentHeap(OSHeapHandle heap);
void *OSAllocFromHeap(OSHeapHandle heap, u32 size);
void *OSAllocFixed(void **rstart, void **rend);
void OSFreeToHeap(OSHeapHandle heap, void *ptr);
long OSCheckHeap(OSHeapHandle heap);
void OSDumpHeap(OSHeapHandle heap);
u32 OSReferentSize(void *ptr);
void OSVisitAllocated(OSAllocVisitor visitor);
extern volatile OSHeapHandle __OSCurrHeap;
void* OSGetArenaHi(void);
void* OSGetArenaLo(void);
void OSSetArenaHi(void* addr);
void OSSetArenaLo(void* addr);
void* OSAllocFromArenaLo(u32 size, u32 align);
void* OSAllocFromArenaLo(u32 size, u32 align);
void DCInvalidateRange(void* addr, u32 nBytes);
void DCFlushRange(void* addr, u32 nBytes);
void DCStoreRange(void* addr, u32 nBytes);
void DCFlushRangeNoSync(void* addr, u32 nBytes);
void DCStoreRangeNoSync(void* addr, u32 nBytes);
void DCZeroRange(void* addr, u32 nBytes);
void DCTouchRange(void* addr, u32 nBytes);
void ICInvalidateRange(void* addr, u32 nBytes);
void LCEnable();
void LCDisable(void);
void LCLoadBlocks(void* destTag, void* srcAddr, u32 numBlocks);
void LCStoreBlocks(void* destAddr, void* srcTag, u32 numBlocks);
u32 LCLoadData(void* destAddr, void* srcAddr, u32 nBytes);
u32 LCStoreData(void* destAddr, void* srcAddr, u32 nBytes);
u32 LCQueueLength(void);
void LCQueueWait(u32 len);
void LCFlushQueue(void);
typedef u16 OSError;
typedef void (*OSErrorHandler)( OSError error, OSContext* context, ... );
OSErrorHandler OSSetErrorHandler(OSError code, OSErrorHandler handler);
typedef u8 __OSException;
typedef void (*__OSExceptionHandler)(__OSException exception, OSContext* context);
BOOL EXIProbe(s32 chan);
s32 EXIProbeEx(s32 chan);
s32 EXIGetType(s32 chan, u32 dev, u32* type);
char* EXIGetTypeString(u32 type);
u32 EXIClearInterrupts(s32 chan, BOOL exi, BOOL tc, BOOL ext);
s32 EXIGetID(s32 chan, u32 dev, u32* id);
typedef void (*EXICallback)(s32 chan, OSContext* context);
static inline void OSInitFastCast(void) {
asm {li r3, 0x0004
oris r3, r3, 0x0004
mtspr 914 , r3
li r3, 0x0005
oris r3, r3, 0x0005
mtspr 915 , r3
li r3, 0x0006
oris r3, r3, 0x0006
mtspr 916 , r3
li r3, 0x0007
oris r3, r3, 0x0007
mtspr 917 , r3
}
}
static inline s16 __OSf32tos16(register f32 inF)
{
u32 tmp;
register u32* tmpPtr = &tmp;
register s16 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 5
lha out, 0(tmpPtr)
}
return out;
}
static inline void OSf32tos16(f32 *f, s16 *out) { *out = __OSf32tos16(*f); }
static inline u8 __OSf32tou8(register f32 inF)
{
u32 tmp;
register u32 *tmpPtr = &tmp;
register u8 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 2
lbz out, 0(tmpPtr)
}
return out;
}
static inline void OSf32tou8(f32 *f, u8 *out) { *out = __OSf32tou8(*f); }
static inline s8 __OSf32tos8(register f32 inF)
{
u32 tmp;
register u32 *tmpPtr = &tmp;
register s8 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 4
lbz out, 0(tmpPtr)
extsb out, out
}
return out;
}
static inline void OSf32tos8(f32 *f, s8 *out) { *out = __OSf32tos8(*f); }
static inline u16 __OSf32tou16(register f32 inF)
{
u32 tmp;
register u32 *tmpPtr = &tmp;
register u16 out;
asm {psq_st inF, 0(tmpPtr), 0x1, 3
lbz out, 0(tmpPtr)
}
return out;
}
static inline void OSf32tou16(f32 *f, u16 *out) { *out = __OSf32tou16(*f); }
static inline float __OSs8tof32(register const s8* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 4
}
return ret;
}
static inline void OSs8tof32(const s8* in, float* out) { *out = __OSs8tof32(in); }
static inline float __OSs16tof32(register const s16* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 5
}
return ret;
}
static inline void OSs16tof32(const s16* in, float* out) { *out = __OSs16tof32(in); }
static inline float __OSu8tof32(register const u8* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 2
}
return ret;
}
static inline void OSu8tof32(const u8* in, float* out) { *out = __OSu8tof32(in); }
static inline float __OSu16tof32(register const u16* arg) {
register float ret;
asm {psq_l ret, 0(arg), 1, 3
}
return ret;
}
static inline void OSu16tof32(const u16* in, float* out) { *out = __OSu16tof32(in); }
typedef struct OSFontHeader
{
u16 fontType;
u16 firstChar;
u16 lastChar;
u16 invalChar;
u16 ascent;
u16 descent;
u16 width;
u16 leading;
u16 cellWidth;
u16 cellHeight;
u32 sheetSize;
u16 sheetFormat;
u16 sheetColumn;
u16 sheetRow;
u16 sheetWidth;
u16 sheetHeight;
u16 widthTable;
u32 sheetImage;
u32 sheetFullSize;
u8 c0;
u8 c1;
u8 c2;
u8 c3;
} OSFontHeader;
u16 OSGetFontEncode(void);
BOOL OSInitFont(OSFontHeader *fontData);
u32 OSLoadFont(OSFontHeader *fontData, void *temp);
char *OSGetFontTexture(char *string, void **image, s32 *x, s32 *y, s32 *width);
char *OSGetFontWidth(char *string, s32 *width);
char *OSGetFontTexel(char *string, void *image, s32 pos, s32 stride, s32 *width);
void ICFlashInvalidate(void);
void ICEnable(void);
void ICDisable(void);
void ICFreeze(void);
void ICUnfreeze(void);
void ICBlockInvalidate(void *addr);
void ICSync(void);
typedef s16 __OSInterrupt;
typedef void (*__OSInterruptHandler)(__OSInterrupt interrupt, OSContext* context);
typedef u32 OSInterruptMask;
extern volatile __OSInterrupt __OSLastInterrupt;
extern volatile u32 __OSLastInterruptSrr0;
extern volatile OSTime __OSLastInterruptTime;
__OSInterruptHandler __OSSetInterruptHandler(__OSInterrupt interrupt, __OSInterruptHandler handler);
__OSInterruptHandler __OSGetInterruptHandler(__OSInterrupt interrupt);
void __OSDispatchInterrupt(__OSException exception, OSContext* context);
OSInterruptMask OSGetInterruptMask(void);
OSInterruptMask OSSetInterruptMask(OSInterruptMask mask);
OSInterruptMask __OSMaskInterrupts(OSInterruptMask mask);
OSInterruptMask __OSUnmaskInterrupts(OSInterruptMask mask);
void OSProtectRange(u32 chan, void* addr, u32 nBytes, u32 control);
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef s32 OSPriority;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef struct OSCond OSCond;
typedef void (*OSIdleFunction)(void* param);
typedef void (*OSSwitchThreadCallback)(OSThread* from, OSThread* to);
struct OSThreadQueue {
OSThread* head;
OSThread* tail;
};
struct OSThreadLink {
OSThread* next;
OSThread* prev;
};
struct OSMutexQueue {
OSMutex* head;
OSMutex* tail;
};
struct OSMutexLink {
OSMutex* next;
OSMutex* prev;
};
struct OSThread {
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void* val;
OSThreadQueue* queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex* mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8* stackBase;
u32* stackEnd;
};
enum OS_THREAD_STATE {
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8
};
void OSInitThreadQueue(OSThreadQueue* queue);
OSThread* OSGetCurrentThread(void);
BOOL OSIsThreadSuspended(OSThread* thread);
BOOL OSIsThreadTerminated(OSThread* thread);
s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);
void OSYieldThread(void);
BOOL OSCreateThread(OSThread* thread, void* (*func)(void*), void* param, void* stack, u32 stackSize,
OSPriority priority, u16 attr);
void OSExitThread(void* val);
void OSCancelThread(OSThread* thread);
BOOL OSJoinThread(OSThread* thread, void** val);
void OSDetachThread(OSThread* thread);
s32 OSResumeThread(OSThread* thread);
s32 OSSuspendThread(OSThread* thread);
BOOL OSSetThreadPriority(OSThread* thread, OSPriority priority);
OSPriority OSGetThreadPriority(OSThread* thread);
void OSSleepThread(OSThreadQueue* queue);
void OSWakeupThread(OSThreadQueue* queue);
OSThread* OSSetIdleFunction(OSIdleFunction idleFunction, void* param, void* stack, u32 stackSize);
OSThread* OSGetIdleFunction(void);
void OSClearStack(u8 val);
long OSCheckActiveThreads(void);
typedef struct OSMessageQueue OSMessageQueue;
typedef void* OSMessage;
struct OSMessageQueue {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
s32 msgCount;
s32 firstIndex;
s32 usedCount;
};
void OSInitMessageQueue(OSMessageQueue* mq, OSMessage* msgArray, s32 msgCount);
BOOL OSSendMessage(OSMessageQueue* mq, OSMessage msg, s32 flags);
BOOL OSJamMessage(OSMessageQueue* mq, OSMessage msg, s32 flags);
BOOL OSReceiveMessage(OSMessageQueue* mq, OSMessage* msg, s32 flags);
typedef struct OSModuleHeader OSModuleHeader;
typedef u32 OSModuleID;
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u8 bssSection;
u32 prolog;
u32 epilog;
u32 unresolved;
u32 align;
u32 bssAlign;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
void OSSetStringTable(const void* stringTable);
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* oldModule);
OSModuleInfo* OSSearchModule(void* ptr, u32* section, u32* offset);
void OSNotifyLink(void);
void OSNotifyUnlink(void);
struct OSMutex {
OSThreadQueue queue;
OSThread* thread;
s32 count;
OSMutexLink link;
};
struct OSCond {
OSThreadQueue queue;
};
void OSInitMutex(OSMutex* mutex);
void OSLockMutex(OSMutex* mutex);
void OSUnlockMutex(OSMutex* mutex);
BOOL OSTryLockMutex(OSMutex* mutex);
void OSInitCond(OSCond* cond);
void OSWaitCond(OSCond* cond, OSMutex* mutex);
void OSSignalCond(OSCond* cond);
typedef BOOL (*OSResetFunction)(BOOL final);
typedef struct OSResetFunctionInfo OSResetFunctionInfo;
struct OSResetFunctionInfo {
OSResetFunction func;
u32 priority;
OSResetFunctionInfo* next;
OSResetFunctionInfo* prev;
};
void OSRegisterResetFunction(OSResetFunctionInfo *info);
u32 OSGetResetCode(void);
typedef void (*OSResetCallback)(void);
BOOL OSGetResetButtonState(void);
BOOL OSGetResetSwitchState(void);
OSResetCallback OSSetResetCallback(OSResetCallback callback);
u32 SIProbe(s32 chan);
char* SIGetTypeString(u32 type);
void SIRefreshSamplingRate(void);
void SISetSamplingRate(u32 msec);
typedef struct DVDDiskID {
char gameName[4];
char company[2];
u8 diskNumber;
u8 gameVersion;
u8 streaming;
u8 streamingBufSize;
u8 padding[22];
} DVDDiskID;
typedef struct DVDCommandBlock DVDCommandBlock;
typedef void (*DVDCBCallback)(s32 result, DVDCommandBlock* block);
struct DVDCommandBlock {
DVDCommandBlock* next;
DVDCommandBlock* prev;
u32 command;
s32 state;
u32 offset;
u32 length;
void* addr;
u32 currTransferSize;
u32 transferredSize;
DVDDiskID* id;
DVDCBCallback callback;
void* userData;
};
typedef struct DVDFileInfo DVDFileInfo;
typedef void (*DVDCallback)(s32 result, DVDFileInfo* fileInfo);
struct DVDFileInfo {
DVDCommandBlock cb;
u32 startAddr;
u32 length;
DVDCallback callback;
};
typedef struct {
u32 entryNum;
u32 location;
u32 next;
} DVDDir;
typedef struct {
u32 entryNum;
BOOL isDir;
char* name;
} DVDDirEntry;
void DVDInit();
BOOL DVDClose(DVDFileInfo* f);
BOOL DVDSetAutoFatalMessaging(BOOL);
void DVDReset();
int DVDSetAutoInvalidation(int autoInval);
s32 DVDCancel(DVDCommandBlock* block);
BOOL DVDOpen(char* fileName, DVDFileInfo* fileInfo);
BOOL DVDFastOpen(s32 entrynum, DVDFileInfo* fileInfo);
s32 DVDGetCommandBlockStatus(const DVDCommandBlock* block);
BOOL DVDCancelAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancel(DVDCommandBlock* block);
BOOL DVDCancelAllAsync(DVDCBCallback callback);
s32 DVDCancelAll(void);
BOOL DVDPrepareStreamAsync(DVDFileInfo* fInfo, u32 length, u32 offset, DVDCallback callback);
s32 DVDPrepareStream(DVDFileInfo* fInfo, u32 length, u32 offset);
BOOL DVDCancelStreamAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancelStream(DVDCommandBlock* block);
BOOL DVDStopStreamAtEndAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDStopStreamAtEnd(DVDCommandBlock* block);
BOOL DVDGetStreamErrorStatusAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDGetStreamErrorStatus(DVDCommandBlock* block);
BOOL DVDGetStreamPlayAddrAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDGetStreamPlayAddr(DVDCommandBlock* block);
s32 DVDGetDriveStatus();
s32 DVDConvertPathToEntrynum(char* pathPtr);
BOOL DVDReadAsyncPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset,
DVDCallback callback, s32 prio);
BOOL DVDReadPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, s32 prio);
extern u32 __PADFixBits;
typedef void (*PADSamplingCallback)(void);
typedef struct PADStatus {
u16 button;
s8 stickX;
s8 stickY;
s8 substickX;
s8 substickY;
u8 triggerL;
u8 triggerR;
u8 analogA;
u8 analogB;
s8 err;
} PADStatus;
BOOL PADInit();
u32 PADRead(PADStatus* status);
BOOL PADReset(u32 mask);
BOOL PADRecalibrate(u32 mask);
void PADClamp(PADStatus* status);
void PADClampCircle(PADStatus* status);
void PADControlMotor(s32 chan, u32 cmd);
void PADSetSpec(u32 spec);
void PADControlAllMotors(const u32* cmdArr);
void PADSetAnalogMode(u32 mode);
PADSamplingCallback PADSetSamplingCallback(PADSamplingCallback);
u32 VIGetNextField(void);
u32 VIGetRetraceCount();
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void __VIGetCurrentPosition(s16* x, s16* y);
u32 VIGetDTVStatus(void);
void VIInit(void);
void VIConfigure(const GXRenderModeObj* rm);
void VIFlush(void);
u32 VIGetTvFormat(void);
void VISetNextFrameBuffer(void* fb);
void VIWaitForRetrace(void);
void VISetBlack(BOOL black);
void VIConfigurePan(u16 xOrg, u16 yOrg, u16 width, u16 height);
typedef void (*AISCallback)(u32 count);
typedef void (*AIDCallback)();
AIDCallback AIRegisterDMACallback(AIDCallback callback);
void AIInitDMA(u32 start_addr, u32 length);
BOOL AIGetDMAEnableFlag();
void AIStartDMA();
void AIStopDMA();
u32 AIGetDMABytesLeft();
u32 AIGetDMAStartAddr();
u32 AIGetDMALength();
u32 AIGetDSPSampleRate();
void AISetDSPSampleRate(u32 rate);
AISCallback AIRegisterStreamCallback(AISCallback callback);
u32 AIGetStreamSampleCount();
void AIResetStreamSampleCount();
void AISetStreamTrigger(u32 trigger);
u32 AIGetStreamTrigger();
void AISetStreamPlayState(u32 state);
u32 AIGetStreamPlayState();
void AISetStreamSampleRate(u32 rate);
u32 AIGetStreamSampleRate();
void AISetStreamVolLeft(u8 vol);
void AISetStreamVolRight(u8 vol);
u8 AIGetStreamVolLeft();
u8 AIGetStreamVolRight();
void AIInit(u8* stack);
BOOL AICheckInit();
void AIReset();
typedef void (*ARCallback)(void);
ARCallback ARRegisterDMACallback(ARCallback callback);
u32 ARGetDMAStatus(void);
void ARStartDMA(u32 type, u32 mainmem_addr, u32 aram_addr, u32 length);
u32 ARInit(u32* stack_index_addr, u32 num_entries);
u32 ARGetBaseAddress(void);
BOOL ARCheckInit(void);
void ARReset(void);
u32 ARAlloc(u32 length);
u32 ARFree(u32* length);
u32 ARGetSize(void);
u32 ARGetInternalSize(void);
void ARSetSize(void);
void ARClear(u32 flag);
void __ARClearInterrupt(void);
u16 __ARGetInterruptStatus(void);
typedef void (*ARQCallback)(u32 pointerToARQRequest);
typedef struct ARQRequest {
struct ARQRequest* next;
u32 owner;
u32 type;
u32 priority;
u32 source;
u32 dest;
u32 length;
ARQCallback callback;
} ARQRequest;
void ARQInit(void);
void ARQReset(void);
void ARQPostRequest(ARQRequest* task, u32 owner, u32 type, u32 priority, u32 source, u32 dest,
u32 length, ARQCallback callback);
void ARQRemoveRequest(ARQRequest* task);
void ARQRemoveOwnerRequest(u32 owner);
void ARQFlushQueue(void);
void ARQSetChunkSize(u32 size);
u32 ARQGetChunkSize(void);
BOOL ARQCheckInit(void);
typedef void (*DSPCallback)(void* task);
typedef struct STRUCT_DSP_TASK {
vu32 state;
vu32 priority;
vu32 flags;
u16* iram_mmem_addr;
u32 iram_length;
u32 iram_addr;
u16* dram_mmem_addr;
u32 dram_length;
u32 dram_addr;
u16 dsp_init_vector;
u16 dsp_resume_vector;
DSPCallback init_cb;
DSPCallback res_cb;
DSPCallback done_cb;
DSPCallback req_cb;
struct STRUCT_DSP_TASK* next;
struct STRUCT_DSP_TASK* prev;
OSTime t_context;
OSTime t_task;
} DSPTaskInfo;
void DSPInit();
void DSPReset();
void DSPHalt();
void DSPSendMailToDSP(u32 mail);
u32 DSPCheckMailToDSP();
u32 DSPCheckMailFromDSP();
u32 DSPGetDMAStatus();
DSPTaskInfo* DSPAddTask(DSPTaskInfo* task);
void __DSP_exec_task(DSPTaskInfo* curr, DSPTaskInfo* next);
void __DSP_boot_task(DSPTaskInfo* task);
void __DSP_insert_task(DSPTaskInfo* task);
void __DSP_remove_task(DSPTaskInfo* task);
void __DSP_add_task(DSPTaskInfo* task);
void __DSP_debug_printf(const char* fmt, ...);
typedef struct CARDFileInfo {
s32 chan;
s32 fileNo;
s32 offset;
s32 length;
u16 iBlock;
u16 __padding;
} CARDFileInfo;
typedef struct CARDStat {
char fileName[32 ];
u32 length;
u32 time;
u8 gameName[4];
u8 company[2];
u8 bannerFormat;
u8 __padding;
u32 iconAddr;
u16 iconFormat;
u16 iconSpeed;
u32 commentAddr;
u32 offsetBanner;
u32 offsetBannerTlut;
u32 offsetIcon[8 ];
u32 offsetIconTlut;
u32 offsetData;
} CARDStat;
typedef void (*CARDCallback)(s32 chan, s32 result);
void CARDInit(void);
BOOL CARDGetFastMode(void);
BOOL CARDSetFastMode(BOOL enable);
s32 CARDCheck(s32 chan);
s32 CARDCheckAsync(s32 chan, CARDCallback callback);
s32 CARDCheckEx(s32 chan, s32* xferBytes);
s32 CARDCheckExAsync(s32 chan, s32* xferBytes, CARDCallback callback);
s32 CARDCreate(s32 chan, const char* fileName, u32 size, CARDFileInfo* fileInfo);
s32 CARDCreateAsync(s32 chan, const char* fileName, u32 size, CARDFileInfo* fileInfo,
CARDCallback callback);
s32 CARDDelete(s32 chan, const char* fileName);
s32 CARDDeleteAsync(s32 chan, const char* fileName, CARDCallback callback);
s32 CARDFastDelete(s32 chan, s32 fileNo);
s32 CARDFastDeleteAsync(s32 chan, s32 fileNo, CARDCallback callback);
s32 CARDFastOpen(s32 chan, s32 fileNo, CARDFileInfo* fileInfo);
s32 CARDFormat(s32 chan);
s32 CARDFormatAsync(s32 chan, CARDCallback callback);
s32 CARDFreeBlocks(s32 chan, s32* byteNotUsed, s32* filesNotUsed);
s32 CARDGetAttributes(s32 chan, s32 fileNo, u8* attr);
s32 CARDGetEncoding(s32 chan, u16* encode);
s32 CARDGetMemSize(s32 chan, u16* size);
s32 CARDGetResultCode(s32 chan);
s32 CARDGetSectorSize(s32 chan, u32* size);
s32 CARDGetSerialNo(s32 chan, u64* serialNo);
s32 CARDGetStatus(s32 chan, s32 fileNo, CARDStat* stat);
s32 CARDGetXferredBytes(s32 chan);
s32 CARDMount(s32 chan, void* workArea, CARDCallback detachCallback);
s32 CARDMountAsync(s32 chan, void* workArea, CARDCallback detachCallback,
CARDCallback attachCallback);
s32 CARDOpen(s32 chan, const char* fileName, CARDFileInfo* fileInfo);
BOOL CARDProbe(s32 chan);
s32 CARDProbeEx(s32 chan, s32* memSize, s32* sectorSize);
s32 CARDRename(s32 chan, const char* oldName, const char* newName);
s32 CARDRenameAsync(s32 chan, const char* oldName, const char* newName, CARDCallback callback);
s32 CARDSetAttributesAsync(s32 chan, s32 fileNo, u8 attr, CARDCallback callback);
s32 CARDSetAttributes(s32 chan, s32 fileNo, u8 attr);
s32 CARDSetStatus(s32 chan, s32 fileNo, CARDStat* stat);
s32 CARDSetStatusAsync(s32 chan, s32 fileNo, CARDStat* stat, CARDCallback callback);
s32 CARDUnmount(s32 chan);
s32 CARDGetCurrentMode(s32 chan, u32* mode);
s32 CARDCancel(CARDFileInfo* fileInfo);
s32 CARDClose(CARDFileInfo* fileInfo);
s32 CARDRead(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset);
s32 CARDReadAsync(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset,
CARDCallback callback);
s32 CARDWrite(CARDFileInfo* fileInfo, const void* addr, s32 length, s32 offset);
s32 CARDWriteAsync(CARDFileInfo* fileInfo, const void* addr, s32 length, s32 offset,
CARDCallback callback);
typedef enum {
HEAP_HEAP,
HEAP_SOUND,
HEAP_MODEL,
HEAP_DVD,
HEAP_SPACE,
HEAP_MAX
} HeapID;
void HuMemInitAll(void);
void *HuMemInit(void *ptr, s32 size);
void HuMemDCFlushAll();
void HuMemDCFlush(HeapID heap);
void *HuMemDirectMalloc(HeapID heap, s32 size);
void *HuMemDirectMallocNum(HeapID heap, s32 size, u32 num);
void HuMemDirectFree(void *ptr);
void HuMemDirectFreeNum(HeapID heap, u32 num);
s32 HuMemUsedMallocSizeGet(HeapID heap);
s32 HuMemUsedMallocBlockGet(HeapID heap);
u32 HuMemHeapSizeGet(HeapID heap);
void *HuMemHeapPtrGet(HeapID heap);
void *HuMemHeapInit(void *ptr, s32 size);
void *HuMemMemoryAlloc(void *heap_ptr, s32 size, u32 retaddr);
void *HuMemMemoryAllocNum(void *heap_ptr, s32 size, u32 num, u32 retaddr);
void HuMemMemoryFree(void *ptr, u32 retaddr);
void HuMemMemoryFreeNum(void *heap_ptr, u32 num, u32 retaddr);
s32 HuMemUsedMemorySizeGet(void *heap_ptr);
s32 HuMemUsedMemoryBlockGet(void *heap_ptr);
s32 HuMemMemorySizeGet(void *ptr);
s32 HuMemMemoryAllocSizeGet(s32 size);
void HuMemHeapDump(void *heap_ptr, s16 status);
typedef struct HuDataStat_s HUDATASTAT;
typedef struct file_list_entry {
char *name;
s32 entryNum;
} FileListEntry;
void *HuDvdDataRead(char *path);
void **HuDvdDataReadMulti(char **paths);
void *HuDvdDataReadDirect(char *path, HeapID heap);
void *HuDvdDataFastRead(s32 entrynum);
void *HuDvdDataFastReadNum(s32 entrynum, s32 num);
void *HuDvdDataFastReadAsync(s32 entrynum, HUDATASTAT *stat);
void HuDvdDataClose(void *ptr);
void HuDvdErrorWatch();
enum {
DATADIR_ID_E3SETUP,
DATADIR_ID_BBATTLE,
DATADIR_ID_BGUEST,
DATADIR_ID_BKOOPA,
DATADIR_ID_BKOOPASUIT,
DATADIR_ID_BKUJIYA,
DATADIR_ID_BLAST5,
DATADIR_ID_BOARD,
DATADIR_ID_BPAUSE,
DATADIR_ID_BYOKODORI,
DATADIR_ID_DAISY,
DATADIR_ID_DAISYMDL0,
DATADIR_ID_DAISYMDL1,
DATADIR_ID_DAISYMOT,
DATADIR_ID_DONKEY,
DATADIR_ID_DONKEYMDL0,
DATADIR_ID_DONKEYMDL1,
DATADIR_ID_DONKEYMOT,
DATADIR_ID_EFFECT,
DATADIR_ID_GAMEMES,
DATADIR_ID_INST,
DATADIR_ID_INSTFONT,
DATADIR_ID_INSTPIC,
DATADIR_ID_LUIGI,
DATADIR_ID_LUIGIMDL0,
DATADIR_ID_LUIGIMDL1,
DATADIR_ID_LUIGIMOT,
DATADIR_ID_M300,
DATADIR_ID_M302,
DATADIR_ID_M303,
DATADIR_ID_M330,
DATADIR_ID_M333,
DATADIR_ID_M401,
DATADIR_ID_M402,
DATADIR_ID_M403,
DATADIR_ID_M404,
DATADIR_ID_M405,
DATADIR_ID_M406,
DATADIR_ID_M407,
DATADIR_ID_M408,
DATADIR_ID_M409,
DATADIR_ID_M410,
DATADIR_ID_M411,
DATADIR_ID_M412,
DATADIR_ID_M413,
DATADIR_ID_M414,
DATADIR_ID_M415,
DATADIR_ID_M416,
DATADIR_ID_M417,
DATADIR_ID_M418,
DATADIR_ID_M419,
DATADIR_ID_M420,
DATADIR_ID_M421,
DATADIR_ID_M422,
DATADIR_ID_M423,
DATADIR_ID_M424,
DATADIR_ID_M425,
DATADIR_ID_M426,
DATADIR_ID_M427,
DATADIR_ID_M428,
DATADIR_ID_M429,
DATADIR_ID_M430,
DATADIR_ID_M431,
DATADIR_ID_M432,
DATADIR_ID_M433,
DATADIR_ID_M434,
DATADIR_ID_M435,
DATADIR_ID_M436,
DATADIR_ID_M437,
DATADIR_ID_M438,
DATADIR_ID_M439,
DATADIR_ID_M440,
DATADIR_ID_M441,
DATADIR_ID_M442,
DATADIR_ID_M443,
DATADIR_ID_M444,
DATADIR_ID_M445,
DATADIR_ID_M446,
DATADIR_ID_M447,
DATADIR_ID_M448,
DATADIR_ID_M449,
DATADIR_ID_M450,
DATADIR_ID_M451,
DATADIR_ID_M453,
DATADIR_ID_M455,
DATADIR_ID_M456,
DATADIR_ID_M457,
DATADIR_ID_M458,
DATADIR_ID_M459,
DATADIR_ID_M460,
DATADIR_ID_M461,
DATADIR_ID_M462,
DATADIR_ID_MARIO,
DATADIR_ID_MARIOMDL0,
DATADIR_ID_MARIOMDL1,
DATADIR_ID_MARIOMOT,
DATADIR_ID_MENT,
DATADIR_ID_MGCONST,
DATADIR_ID_MGMODE,
DATADIR_ID_MODESEL,
DATADIR_ID_MPEX,
DATADIR_ID_MSTORY,
DATADIR_ID_MSTORY2,
DATADIR_ID_MSTORY3,
DATADIR_ID_MSTORY4,
DATADIR_ID_OPTION,
DATADIR_ID_PEACH,
DATADIR_ID_PEACHMDL0,
DATADIR_ID_PEACHMDL1,
DATADIR_ID_PEACHMOT,
DATADIR_ID_PRESENT,
DATADIR_ID_RESULT,
DATADIR_ID_SAF,
DATADIR_ID_SELMENU,
DATADIR_ID_SETUP,
DATADIR_ID_STAFF,
DATADIR_ID_TITLE,
DATADIR_ID_W01,
DATADIR_ID_W02,
DATADIR_ID_W03,
DATADIR_ID_W04,
DATADIR_ID_W05,
DATADIR_ID_W06,
DATADIR_ID_W10,
DATADIR_ID_W20,
DATADIR_ID_W21,
DATADIR_ID_WALUIGI,
DATADIR_ID_WALUIGIMDL0,
DATADIR_ID_WALUIGIMDL1,
DATADIR_ID_WALUIGIMOT,
DATADIR_ID_WARIO,
DATADIR_ID_WARIOMDL0,
DATADIR_ID_WARIOMDL1,
DATADIR_ID_WARIOMOT,
DATADIR_ID_WIN,
DATADIR_ID_YOSHI,
DATADIR_ID_YOSHIMDL0,
DATADIR_ID_YOSHIMDL1,
DATADIR_ID_YOSHIMOT,
DATADIR_ID_ZTAR,
DATADIR_ID_MAX
};
enum {
DATADIR_E3SETUP = (DATADIR_ID_E3SETUP) << 16,
DATADIR_BBATTLE = (DATADIR_ID_BBATTLE) << 16,
DATADIR_BGUEST = (DATADIR_ID_BGUEST) << 16,
DATADIR_BKOOPA = (DATADIR_ID_BKOOPA) << 16,
DATADIR_BKOOPASUIT = (DATADIR_ID_BKOOPASUIT) << 16,
DATADIR_BKUJIYA = (DATADIR_ID_BKUJIYA) << 16,
DATADIR_BLAST5 = (DATADIR_ID_BLAST5) << 16,
DATADIR_BOARD = (DATADIR_ID_BOARD) << 16,
DATADIR_BPAUSE = (DATADIR_ID_BPAUSE) << 16,
DATADIR_BYOKODORI = (DATADIR_ID_BYOKODORI) << 16,
DATADIR_DAISY = (DATADIR_ID_DAISY) << 16,
DATADIR_DAISYMDL0 = (DATADIR_ID_DAISYMDL0) << 16,
DATADIR_DAISYMDL1 = (DATADIR_ID_DAISYMDL1) << 16,
DATADIR_DAISYMOT = (DATADIR_ID_DAISYMOT) << 16,
DATADIR_DONKEY = (DATADIR_ID_DONKEY) << 16,
DATADIR_DONKEYMDL0 = (DATADIR_ID_DONKEYMDL0) << 16,
DATADIR_DONKEYMDL1 = (DATADIR_ID_DONKEYMDL1) << 16,
DATADIR_DONKEYMOT = (DATADIR_ID_DONKEYMOT) << 16,
DATADIR_EFFECT = (DATADIR_ID_EFFECT) << 16,
DATADIR_GAMEMES = (DATADIR_ID_GAMEMES) << 16,
DATADIR_INST = (DATADIR_ID_INST) << 16,
DATADIR_INSTFONT = (DATADIR_ID_INSTFONT) << 16,
DATADIR_INSTPIC = (DATADIR_ID_INSTPIC) << 16,
DATADIR_LUIGI = (DATADIR_ID_LUIGI) << 16,
DATADIR_LUIGIMDL0 = (DATADIR_ID_LUIGIMDL0) << 16,
DATADIR_LUIGIMDL1 = (DATADIR_ID_LUIGIMDL1) << 16,
DATADIR_LUIGIMOT = (DATADIR_ID_LUIGIMOT) << 16,
DATADIR_M300 = (DATADIR_ID_M300) << 16,
DATADIR_M302 = (DATADIR_ID_M302) << 16,
DATADIR_M303 = (DATADIR_ID_M303) << 16,
DATADIR_M330 = (DATADIR_ID_M330) << 16,
DATADIR_M333 = (DATADIR_ID_M333) << 16,
DATADIR_M401 = (DATADIR_ID_M401) << 16,
DATADIR_M402 = (DATADIR_ID_M402) << 16,
DATADIR_M403 = (DATADIR_ID_M403) << 16,
DATADIR_M404 = (DATADIR_ID_M404) << 16,
DATADIR_M405 = (DATADIR_ID_M405) << 16,
DATADIR_M406 = (DATADIR_ID_M406) << 16,
DATADIR_M407 = (DATADIR_ID_M407) << 16,
DATADIR_M408 = (DATADIR_ID_M408) << 16,
DATADIR_M409 = (DATADIR_ID_M409) << 16,
DATADIR_M410 = (DATADIR_ID_M410) << 16,
DATADIR_M411 = (DATADIR_ID_M411) << 16,
DATADIR_M412 = (DATADIR_ID_M412) << 16,
DATADIR_M413 = (DATADIR_ID_M413) << 16,
DATADIR_M414 = (DATADIR_ID_M414) << 16,
DATADIR_M415 = (DATADIR_ID_M415) << 16,
DATADIR_M416 = (DATADIR_ID_M416) << 16,
DATADIR_M417 = (DATADIR_ID_M417) << 16,
DATADIR_M418 = (DATADIR_ID_M418) << 16,
DATADIR_M419 = (DATADIR_ID_M419) << 16,
DATADIR_M420 = (DATADIR_ID_M420) << 16,
DATADIR_M421 = (DATADIR_ID_M421) << 16,
DATADIR_M422 = (DATADIR_ID_M422) << 16,
DATADIR_M423 = (DATADIR_ID_M423) << 16,
DATADIR_M424 = (DATADIR_ID_M424) << 16,
DATADIR_M425 = (DATADIR_ID_M425) << 16,
DATADIR_M426 = (DATADIR_ID_M426) << 16,
DATADIR_M427 = (DATADIR_ID_M427) << 16,
DATADIR_M428 = (DATADIR_ID_M428) << 16,
DATADIR_M429 = (DATADIR_ID_M429) << 16,
DATADIR_M430 = (DATADIR_ID_M430) << 16,
DATADIR_M431 = (DATADIR_ID_M431) << 16,
DATADIR_M432 = (DATADIR_ID_M432) << 16,
DATADIR_M433 = (DATADIR_ID_M433) << 16,
DATADIR_M434 = (DATADIR_ID_M434) << 16,
DATADIR_M435 = (DATADIR_ID_M435) << 16,
DATADIR_M436 = (DATADIR_ID_M436) << 16,
DATADIR_M437 = (DATADIR_ID_M437) << 16,
DATADIR_M438 = (DATADIR_ID_M438) << 16,
DATADIR_M439 = (DATADIR_ID_M439) << 16,
DATADIR_M440 = (DATADIR_ID_M440) << 16,
DATADIR_M441 = (DATADIR_ID_M441) << 16,
DATADIR_M442 = (DATADIR_ID_M442) << 16,
DATADIR_M443 = (DATADIR_ID_M443) << 16,
DATADIR_M444 = (DATADIR_ID_M444) << 16,
DATADIR_M445 = (DATADIR_ID_M445) << 16,
DATADIR_M446 = (DATADIR_ID_M446) << 16,
DATADIR_M447 = (DATADIR_ID_M447) << 16,
DATADIR_M448 = (DATADIR_ID_M448) << 16,
DATADIR_M449 = (DATADIR_ID_M449) << 16,
DATADIR_M450 = (DATADIR_ID_M450) << 16,
DATADIR_M451 = (DATADIR_ID_M451) << 16,
DATADIR_M453 = (DATADIR_ID_M453) << 16,
DATADIR_M455 = (DATADIR_ID_M455) << 16,
DATADIR_M456 = (DATADIR_ID_M456) << 16,
DATADIR_M457 = (DATADIR_ID_M457) << 16,
DATADIR_M458 = (DATADIR_ID_M458) << 16,
DATADIR_M459 = (DATADIR_ID_M459) << 16,
DATADIR_M460 = (DATADIR_ID_M460) << 16,
DATADIR_M461 = (DATADIR_ID_M461) << 16,
DATADIR_M462 = (DATADIR_ID_M462) << 16,
DATADIR_MARIO = (DATADIR_ID_MARIO) << 16,
DATADIR_MARIOMDL0 = (DATADIR_ID_MARIOMDL0) << 16,
DATADIR_MARIOMDL1 = (DATADIR_ID_MARIOMDL1) << 16,
DATADIR_MARIOMOT = (DATADIR_ID_MARIOMOT) << 16,
DATADIR_MENT = (DATADIR_ID_MENT) << 16,
DATADIR_MGCONST = (DATADIR_ID_MGCONST) << 16,
DATADIR_MGMODE = (DATADIR_ID_MGMODE) << 16,
DATADIR_MODESEL = (DATADIR_ID_MODESEL) << 16,
DATADIR_MPEX = (DATADIR_ID_MPEX) << 16,
DATADIR_MSTORY = (DATADIR_ID_MSTORY) << 16,
DATADIR_MSTORY2 = (DATADIR_ID_MSTORY2) << 16,
DATADIR_MSTORY3 = (DATADIR_ID_MSTORY3) << 16,
DATADIR_MSTORY4 = (DATADIR_ID_MSTORY4) << 16,
DATADIR_OPTION = (DATADIR_ID_OPTION) << 16,
DATADIR_PEACH = (DATADIR_ID_PEACH) << 16,
DATADIR_PEACHMDL0 = (DATADIR_ID_PEACHMDL0) << 16,
DATADIR_PEACHMDL1 = (DATADIR_ID_PEACHMDL1) << 16,
DATADIR_PEACHMOT = (DATADIR_ID_PEACHMOT) << 16,
DATADIR_PRESENT = (DATADIR_ID_PRESENT) << 16,
DATADIR_RESULT = (DATADIR_ID_RESULT) << 16,
DATADIR_SAF = (DATADIR_ID_SAF) << 16,
DATADIR_SELMENU = (DATADIR_ID_SELMENU) << 16,
DATADIR_SETUP = (DATADIR_ID_SETUP) << 16,
DATADIR_STAFF = (DATADIR_ID_STAFF) << 16,
DATADIR_TITLE = (DATADIR_ID_TITLE) << 16,
DATADIR_W01 = (DATADIR_ID_W01) << 16,
DATADIR_W02 = (DATADIR_ID_W02) << 16,
DATADIR_W03 = (DATADIR_ID_W03) << 16,
DATADIR_W04 = (DATADIR_ID_W04) << 16,
DATADIR_W05 = (DATADIR_ID_W05) << 16,
DATADIR_W06 = (DATADIR_ID_W06) << 16,
DATADIR_W10 = (DATADIR_ID_W10) << 16,
DATADIR_W20 = (DATADIR_ID_W20) << 16,
DATADIR_W21 = (DATADIR_ID_W21) << 16,
DATADIR_WALUIGI = (DATADIR_ID_WALUIGI) << 16,
DATADIR_WALUIGIMDL0 = (DATADIR_ID_WALUIGIMDL0) << 16,
DATADIR_WALUIGIMDL1 = (DATADIR_ID_WALUIGIMDL1) << 16,
DATADIR_WALUIGIMOT = (DATADIR_ID_WALUIGIMOT) << 16,
DATADIR_WARIO = (DATADIR_ID_WARIO) << 16,
DATADIR_WARIOMDL0 = (DATADIR_ID_WARIOMDL0) << 16,
DATADIR_WARIOMDL1 = (DATADIR_ID_WARIOMDL1) << 16,
DATADIR_WARIOMOT = (DATADIR_ID_WARIOMOT) << 16,
DATADIR_WIN = (DATADIR_ID_WIN) << 16,
DATADIR_YOSHI = (DATADIR_ID_YOSHI) << 16,
DATADIR_YOSHIMDL0 = (DATADIR_ID_YOSHIMDL0) << 16,
DATADIR_YOSHIMDL1 = (DATADIR_ID_YOSHIMDL1) << 16,
DATADIR_YOSHIMOT = (DATADIR_ID_YOSHIMOT) << 16,
DATADIR_ZTAR = (DATADIR_ID_ZTAR) << 16,
};
struct HuDataStat_s {
s32 dirId;
void *dirP;
void *fileDataP;
u32 rawLen;
u32 decodeType;
BOOL used;
s32 num;
u32 status;
DVDFileInfo dvdFile;
};
void HuDataInit(void);
s32 HuDataReadChk(s32 dirNum);
HUDATASTAT *HuDataGetStatus(void *dirP);
void *HuDataGetDirPtr(s32 dirNum);
HUDATASTAT *HuDataDirRead(s32 dataNum);
HUDATASTAT *HuDataDirSet(void *dirP, s32 dataNum);
void HuDataDirReadAsyncCallBack(s32 result, DVDFileInfo* fileInfo);
s32 HuDataDirReadAsync(s32 dataNum);
s32 HuDataDirReadNumAsync(s32 dataNum, s32 num);
BOOL HuDataGetAsyncStat(s32 statId);
void *HuDataRead(s32 dataNum);
void *HuDataReadNum(s32 dataNum, s32 num);
void *HuDataSelHeapRead(s32 dataNum, HeapID heap);
void *HuDataSelHeapReadNum(s32 dataNum, s32 num, HeapID heap);
void **HuDataReadMulti(s32 *dataNum);
s32 HuDataGetSize(s32 dataNum);
void HuDataClose(void *ptr);
void HuDataCloseMulti(void **ptrs);
void HuDataDirClose(s32 dataNum);
void HuDataDirCloseNum(s32 num);
void *HuDataReadNumHeapShortForce(s32 dataNum, s32 num, HeapID heap);
void HuDecodeData(void *src, void *dst, u32 size, s32 decodeType);
extern u32 DirDataSize;
typedef struct AnimTime_s {
s16 pat;
s16 time;
s16 shiftX;
s16 shiftY;
s16 flip;
s16 pad;
} ANIMFRAME;
typedef struct AnimBank_s {
s16 timeNum;
s16 unk;
ANIMFRAME *frame;
} ANIMBANK;
typedef struct AnimLayer_s {
u8 alpha;
u8 flip;
s16 bmpNo;
s16 startX;
s16 startY;
s16 sizeX;
s16 sizeY;
s16 shiftX;
s16 shiftY;
s16 vtx[8];
} ANIMLAYER;
typedef struct AnimPat_s {
s16 layerNum;
s16 centerX;
s16 centerY;
s16 sizeX;
s16 sizeY;
ANIMLAYER *layer;
} ANIMPAT;
typedef struct AnimBmp_s {
u8 pixSize;
u8 dataFmt;
s16 palNum;
s16 sizeX;
s16 sizeY;
u32 dataSize;
void *palData;
void *data;
} ANIMBMP;
typedef struct AnimData_s {
s16 bankNum;
s16 patNum;
s16 bmpNum;
s16 useNum;
ANIMBANK *bank;
ANIMPAT *pat;
ANIMBMP *bmp;
} ANIMDATA;
typedef Vec HuVecF;
typedef struct HuVec2f_s {
float x;
float y;
} HuVec2f;
typedef struct HsfS8Vec_s {
s8 x;
s8 y;
s8 z;
} HSFS8VEC;
typedef struct HsfObject_s HSFOBJECT;
typedef struct HsfSection_s {
s32 ofs;
s32 count;
} HSFSECTION;
typedef struct hsf_header {
char magic[8];
HSFSECTION scene;
HSFSECTION color;
HSFSECTION material;
HSFSECTION attribute;
HSFSECTION vertex;
HSFSECTION normal;
HSFSECTION st;
HSFSECTION face;
HSFSECTION object;
HSFSECTION bitmap;
HSFSECTION palette;
HSFSECTION motion;
HSFSECTION cenv;
HSFSECTION skeleton;
HSFSECTION part;
HSFSECTION cluster;
HSFSECTION shape;
HSFSECTION mapAttr;
HSFSECTION matrix;
HSFSECTION symbol;
HSFSECTION string;
} HSFHEADER;
typedef struct HsfScene_s {
GXFogType fogType;
float fogStart;
float fogEnd;
GXColor color;
} HSFSCENE;
typedef struct HsfBitmap_s {
char *name;
u32 maxLod;
u8 dataFmt;
u8 pixSize;
s16 sizeX;
s16 sizeY;
s16 palSize;
GXColor tint;
u16 *palData;
u32 unk;
void *data;
} HSFBITMAP;
typedef struct HsfPalette_s {
char *name;
s32 unk;
u32 palSize;
u16 *data;
} HSFPALETTE;
typedef struct HsfAttribute_s {
char *name;
void *animWorkP;
u8 unk8[4];
float kColor;
u8 unk10[4];
float nbtTpLvl;
u8 unk18[8];
float unk20;
u8 unk24[4];
HuVec2f scale;
HuVec2f trans;
u8 unk38[44];
u32 wrapS;
u32 wrapT;
u8 unk6C[12];
u32 maxLod;
u32 flag;
HSFBITMAP *bitmap;
} HSFATTRIBUTE;
typedef struct HsfMaterial_s {
char *name;
u8 unk4[4];
u16 pass;
u8 vtxMode;
u8 litColor[3];
u8 color[3];
u8 shadowColor[3];
float hiliteScale;
float unk18;
float invAlpha;
float unk20[2];
float refAlpha;
float unk2C;
u32 flags;
u32 attrNum;
s32 *attr;
} HSFMATERIAL;
typedef struct HsfBuffer_s {
char *name;
s32 count;
void *data;
} HSFBUFFER;
typedef struct HsfFace_s {
s16 type;
s16 mat;
union {
struct {
s16 indices[3][4];
u32 count;
s16 *data;
} strip;
s16 indices[4][4];
};
Vec nbt;
} HSFFACE;
typedef struct HsfTransform_s {
HuVecF pos;
HuVecF rot;
HuVecF scale;
} HSFTRANSFORM;
typedef struct HsfCenvSingle_s {
u32 target;
u16 pos;
u16 posNum;
u16 normal;
u16 normalNum;
} HSFCENVSINGLE;
typedef struct HsfCenvDualWeight_s {
float weight;
u16 pos;
u16 posNum;
u16 normal;
u16 normalNum;
} HSFCENVDUALWEIGHT;
typedef struct HsfCenvDual_s {
u32 target1;
u32 target2;
u32 weightNum;
HSFCENVDUALWEIGHT *weight;
} HSFCENVDUAL;
typedef struct HsfCenvMultiWeight_s {
u32 target;
float value;
} HSFCENVMULTIWEIGHT;
typedef struct HsfCenvMulti_s {
u32 weightNum;
u16 pos;
u16 posNum;
u16 normal;
u16 normalNum;
HSFCENVMULTIWEIGHT *weight;
} HSFCENVMULTI;
typedef struct HsfCenv_s {
char *name;
HSFCENVSINGLE *singleData;
HSFCENVDUAL *dualData;
HSFCENVMULTI *multiData;
u32 singleCount;
u32 dualCount;
u32 multiCount;
u32 vtxCount;
u32 copyCount;
} HSFCENV;
typedef struct HsfPart_s {
char *name;
u32 num;
u16 *vertex;
} HSFPART;
typedef struct HsfCluster_s {
char *name[2];
union {
char *targetName;
s32 target;
};
HSFPART *part;
float index;
float weight[32];
u8 adjusted;
u8 unk95;
u16 type;
u32 vertexNum;
HSFBUFFER **vertex;
} HSFCLUSTER;
typedef struct HsfShape_s {
char *name;
union {
u16 num16[2];
u32 vertexNum;
};
HSFBUFFER **vertex;
} HSFSHAPE;
typedef struct HsfMesh_s {
HSFOBJECT *parent;
u32 childrenCount;
HSFOBJECT **children;
HSFTRANSFORM base;
HSFTRANSFORM curr;
union {
struct {
HuVecF min;
HuVecF max;
float baseMorph;
float morphWeight[33];
} mesh;
HSFOBJECT *replica;
};
HSFBUFFER *face;
HSFBUFFER *vertex;
HSFBUFFER *normal;
HSFBUFFER *color;
HSFBUFFER *st;
HSFMATERIAL *material;
HSFATTRIBUTE *attribute;
u8 writeNum;
u8 unk121;
u8 shapeType;
u8 matPass;
u32 shapeNum;
HSFBUFFER **shape;
u32 clusterNum;
HSFCLUSTER **cluster;
u32 cenvNum;
HSFCENV *cenv;
void *file[2];
} HSFMESH;
typedef struct hsf_camera {
HuVecF pos;
HuVecF target;
float upRot;
float fov;
float near;
float far;
} HSFCAMERA;
typedef struct hsf_light {
HuVecF pos;
HuVecF target;
u8 type;
u8 r;
u8 g;
u8 b;
float unk2C;
float ref_distance;
float ref_brightness;
float cutoff;
} HSFLIGHT;
struct HsfObject_s {
char *name;
u32 type;
void *constData;
u32 flags;
union {
HSFMESH mesh;
HSFCAMERA camera;
HSFLIGHT light;
};
};
typedef struct HsfSkeleton_s {
char *name;
HSFTRANSFORM transform;
} HSFSKELETON;
typedef struct HsfBitmapKey_s {
float time;
HSFBITMAP *data;
} HSFBITMAPKEY;
typedef struct HsfTrack_s {
u8 type;
u8 start;
union {
u16 target;
s16 cluster;
};
union {
s32 clusterWeight;
struct {
union {
s16 attrIdx;
u16 index;
};
union {
u16 channel;
s16 morphWeight;
};
};
};
u16 curveType;
union {
u16 numKeyframes;
s16 dataNum;
};
union {
float value;
void *data;
};
} HSFTRACK;
typedef struct HsfMotion_s {
char *name;
s32 numTracks;
HSFTRACK *track;
float maxTime;
} HSFMOTION;
typedef struct HsfMapAttr_s {
float minX;
float minZ;
float maxX;
float maxZ;
u16 *data;
u32 dataLen;
} HSFMAPATTR;
typedef struct HsfMatrix_s {
u32 base_idx;
u32 count;
Mtx *data;
} HSFMATRIX;
typedef struct HsfData_s {
u8 magic[8];
HSFSCENE *scene;
HSFATTRIBUTE *attribute;
HSFMATERIAL *material;
HSFBUFFER *vertex;
HSFBUFFER *normal;
HSFBUFFER *st;
HSFBUFFER *color;
HSFBUFFER *face;
HSFBITMAP *bitmap;
HSFPALETTE *palette;
HSFOBJECT *root;
HSFCENV *cenv;
HSFSKELETON *skeleton;
HSFCLUSTER *cluster;
HSFPART *part;
HSFSHAPE *shape;
HSFMOTION *motion;
HSFOBJECT *object;
HSFMAPATTR *mapAttr;
HSFMATRIX *matrix;
s16 sceneNum;
s16 attributeNum;
s16 materialNum;
s16 vertexNum;
s16 normalNum;
s16 stNum;
s16 colorNum;
s16 faceNum;
s16 bitmapNum;
s16 paletteNum;
s16 objectNum;
s16 cenvNum;
s16 skeletonNum;
s16 clusterNum;
s16 partNum;
s16 shapeNum;
s16 mapAttrNum;
s16 motionNum;
s16 matrixNum;
} HSFDATA;
typedef s16 HU3DMODELID;
typedef s16 HU3DMOTID;
typedef s16 HU3DPROJID;
typedef s16 HU3DLIGHTID;
typedef s16 HU3DLLIGHTID;
typedef s16 HU3DPARMANID;
typedef s16 HU3DANIMID;
typedef s16 HU3DTEXSCRID;
typedef struct Hu3DModel_s HU3DMODEL;
typedef struct Hu3DDrawObj_s HU3DDRAWOBJ;
typedef struct Hu3DParticle_s HU3DPARTICLE;
typedef void (*HU3DLAYERHOOK)(s16 layerNo);
typedef void (*HU3DMODELHOOK)(HU3DMODEL *modelP, Mtx mtx);
typedef void (*HU3DTIMINGHOOK)(HU3DMODELID modelId, HU3DMOTID motId, BOOL lagF);
typedef void (*HU3DMATHOOK)(HU3DDRAWOBJ *drawObj, HSFMATERIAL *material);
typedef void (*HU3DPARTICLEHOOK)(HU3DMODEL *modelP, HU3DPARTICLE *particleP, Mtx mtx);
struct Hu3DDrawObj_s {
HU3DMODEL *model;
HSFOBJECT *object;
float z;
Mtx matrix;
Vec scale;
};
typedef struct Hu3DAttrAnim_s {
u16 attr;
s16 animId;
HU3DTEXSCRID texScrId;
HuVecF trans3D;
HuVecF rot;
HuVecF scale3D;
HuVec2f scale;
HuVec2f trans;
HSFBITMAP *bitMapPtr;
u32 unk40;
} HU3DATTRANIM;
typedef struct HsfDrawData_s {
s32 dlOfs;
s32 dlSize;
u16 polyCnt;
u32 flags;
} HSFDRAWDATA;
typedef struct HsfConstData_s {
u32 attr;
HU3DMODELID hookMdlId;
HSFDRAWDATA *drawData;
void *dlBuf;
Mtx matrix;
ANIMDATA *hiliteMap;
} HSFCONSTDATA;
typedef struct Hu3DMotWork_s {
float time;
float speed;
float start;
float end;
} HU3DMOTWORK;
struct Hu3DModel_s {
u8 tick;
u8 camInfoBit;
u8 projBit;
u8 hiliteIdx;
s8 reflectType;
s16 layerNo;
HU3DMOTID motId;
HU3DMOTID motIdOvl;
HU3DMOTID motIdShift;
HU3DMOTID motIdShape;
s16 motIdCluster[4 ];
s16 clusterAttr[4 ];
HU3DMODELID motIdSrc;
u16 cameraBit;
HU3DMODELID linkMdlId;
u16 lightNum;
u16 lightId[8 ];
HU3DLIGHTID lLightId[8 ];
u32 mallocNo;
u32 mallocNoLink;
u32 attr;
u32 motAttr;
float ambR;
float ambB;
float ambG;
HU3DMOTWORK motWork;
HU3DMOTWORK motOvlWork;
HU3DMOTWORK motShiftWork;
HU3DMOTWORK motShapeWork;
float clusterTime[4 ];
float clusterSpeed[4 ];
union {
HSFDATA *hsf;
HU3DMODELHOOK hookFunc;
};
HSFDATA *hsfLink;
HuVecF pos;
HuVecF rot;
HuVecF scale;
Mtx mtx;
void *hookData;
};
typedef struct Hu3DCamera_s {
float fov;
float near;
float far;
float aspect;
float upRot;
HuVecF pos;
HuVecF up;
HuVecF target;
s16 scissorX;
s16 scissorY;
s16 scissorW;
s16 scissorH;
float viewportX;
float viewportY;
float viewportW;
float viewportH;
float viewportNear;
float viewportFar;
} HU3DCAMERA;
typedef struct Hu3DProjection_s {
u8 alpha;
ANIMDATA *anim;
float fov;
float nnear;
float ffar;
HuVecF camPos;
HuVecF camTarget;
HuVecF camUp;
Mtx lookAtMtx;
Mtx projMtx;
} HU3DPROJECTION;
typedef struct Hu3DShadow_s {
u8 alpha;
u16 size;
void *buf;
float fov;
float nnear;
float ffar;
HuVecF camPos;
HuVecF camTarget;
HuVecF camUp;
Mtx lookAtMtx;
Mtx projMtx;
} HU3DSHADOW;
typedef struct Hu3DLight_s {
s16 type;
s16 func;
float cutoff;
float brightness;
char unk_0C[16];
HuVecF pos;
HuVecF dir;
HuVecF offset;
GXColor color;
} HU3DLIGHT;
typedef struct Hu3DMotion_s {
u16 attr;
HU3DMODELID modelId;
HSFDATA *hsf;
} HU3DMOTION;
typedef struct Hu3DParticleData_s {
s16 time;
HU3DPARMANID parManId;
s16 unk04;
s16 cameraBit;
HuVecF vel;
HuVecF accel;
float speedDecay;
float colorIdx;
float scaleBase;
float scale;
float zRot;
HuVecF pos;
GXColor color;
} HU3DPARTICLEDATA;
struct Hu3DParticle_s {
s16 dataCnt;
s16 emitCnt;
HuVecF pos;
HuVecF unk_10;
void *work;
s16 animBank;
s16 animNo;
float animSpeed;
float animTime;
u8 blendMode;
u8 attr;
s16 unk_2E;
s16 maxCnt;
u32 count;
s32 prevCounter;
u32 prevCount;
u32 dlSize;
ANIMDATA *anim;
HU3DPARTICLEDATA *data;
HuVecF *vtxBuf;
void *dlBuf;
HU3DPARTICLEHOOK hook;
};
typedef struct Hu3DParmanParam_s {
s16 maxTime;
char unk02[2];
float accelRange;
float scaleRange;
float angleRange;
HuVecF gravity;
float speedBase;
float speedDecay;
float scaleBase;
float scaleDecay;
s16 colorNum;
GXColor colorStart[4];
GXColor colorEnd[4];
} HU3DPARMANPARAM;
typedef struct Hu3DTexAnim_s {
u16 attr;
s16 bank;
s16 anmNo;
HU3DMODELID modelId;
float time;
float speed;
ANIMDATA *anim;
} HU3DTEXANIM;
typedef struct Hu3DTexScroll_s {
u16 attr;
HU3DMODELID modelId;
HuVecF pos;
HuVecF scale;
HuVecF posMove;
HuVecF scaleMove;
float rot;
float rotMove;
Mtx texMtx;
} HU3DTEXSCROLL;
typedef struct Hu3DParMan_s {
HU3DMODELID modelId;
s16 attr;
s16 timeLimit;
HU3DPARMANID parManId;
s16 color;
Vec pos;
Vec vec;
Vec vacuum;
float vacuumSpeed;
float accel;
s32 jitterNo;
HU3DPARMANPARAM *param;
} HU3DPARMAN;
extern void GXWaitDrawDone();
extern void GXInitSpecularDir(GXLightObj *, float, float, float);
void Hu3DDrawPreInit(void);
void Hu3DDraw(HU3DMODEL *modelP, Mtx mtx, Vec *scale);
BOOL ObjCullCheck(HSFDATA *hsf, HSFOBJECT *objPtr, Mtx mtx);
void Hu3DDrawPost(void);
void MakeDisplayList(HU3DMODELID modelId, u32 no);
HSFCONSTDATA *ObjConstantMake(HSFOBJECT *object, u32 no);
void mtxTransCat(Mtx mtx, float x, float y, float z);
void mtxRotCat(Mtx mtx, float x, float y, float z);
void mtxRot(Mtx mtx, float x, float y, float z);
void mtxScaleCat(Mtx mtx, float x, float y, float z);
s16 HmfInverseMtxF3X3(Mtx src, Mtx dst);
void SetDefLight(Vec *pos, Vec *dir, u8 colorR, u8 colorG, u8 colorB, u8 ambR, u8 ambG, u8 ambB, u8 matR, u8 matG, u8 matB);
void Hu3DModelObjPosGet(HU3DMODELID modelId, char *objName, Vec *pos);
void Hu3DModelObjMtxGet(HU3DMODELID modelId, char *objName, Mtx mtx);
void PGObjCall(HU3DMODEL *model, HSFOBJECT *object);
void PGObjCalc(HU3DMODEL *model, HSFOBJECT *object);
void PGObjReplica(HU3DMODEL *model, HSFOBJECT *object);
HSFOBJECT *Hu3DObjDuplicate(HSFDATA *hsf, u32 mallocNo);
void Hu3DModelObjDrawInit(void);
void Hu3DModelObjDraw(HU3DMODELID modelId, char *objName, Mtx mtx);
void Hu3DInit(void);
void Hu3DPreProc(void);
void Hu3DExec(void);
void Hu3DAllKill(void);
void Hu3DBGColorSet(u8 r, u8 g, u8 b);
void Hu3DLayerHookSet(s16 layerNo, HU3DLAYERHOOK hookFunc);
void Hu3DPauseSet(BOOL pauseF);
void Hu3DNoSyncSet(BOOL noSync);
s16 Hu3DModelCreate(void *);
s16 Hu3DModelLink(s16);
s16 Hu3DHookFuncCreate(HU3DMODELHOOK);
void Hu3DModelKill(s16);
void Hu3DModelAllKill(void);
void Hu3DModelPosSet(s16, float, float, float);
void Hu3DModelPosSetV(s16, HuVecF *);
void Hu3DModelRotSet(s16, float, float, float);
void Hu3DModelRotSetV(s16, HuVecF *);
void Hu3DModelScaleSet(s16, float, float, float);
void Hu3DModelScaleSetV(s16, HuVecF *);
void Hu3DModelAttrSet(s16, u32);
void Hu3DModelAttrReset(s16, u32);
u32 Hu3DModelAttrGet(s16);
u32 Hu3DModelMotionAttrGet(s16);
void Hu3DModelClusterAttrSet(s16, s16, s32);
void Hu3DModelClusterAttrReset(s16, s16, s32);
void Hu3DModelCameraSet(s16, u16);
void Hu3DModelLayerSet(s16, s16);
HSFOBJECT *Hu3DModelObjPtrGet(s16, char *);
void Hu3DModelTPLvlSet(s16, float);
void Hu3DModelHiliteMapSet(s16, ANIMDATA *);
void Hu3DModelShadowSet(s16);
void Hu3DModelShadowReset(s16);
void Hu3DModelShadowDispOn(s16);
void Hu3DModelShadowDispOff(s16);
void Hu3DModelShadowMapSet(s16);
void Hu3DModelShadowMapObjSet(s16, char *);
void Hu3DModelAmbSet(s16, float, float, float);
void Hu3DModelHookSet(s16, char *, s16);
void Hu3DModelHookReset(s16);
void Hu3DModelHookObjReset(s16, char *);
void Hu3DModelProjectionSet(s16, s16);
void Hu3DModelProjectionReset(s16, s16);
void Hu3DModelHiliteTypeSet(s16, s16);
void Hu3DModelReflectTypeSet(s16, s16);
void Hu3DCameraCreate(s32);
void Hu3DCameraPerspectiveSet(s32, float, float, float, float);
void Hu3DCameraViewportSet(s32, float, float, float, float, float, float);
void Hu3DCameraScissorSet(s32, u32, u32, u32, u32);
void Hu3DCameraPosSet(s32, float, float, float, float, float, float, float, float, float);
void Hu3DCameraPosSetV(s32 cam, HuVecF *pos, HuVecF *up, HuVecF *target);
void Hu3DCameraKill(s32);
void Hu3DCameraAllKill(void);
void Hu3DCameraSet(s32, Mtx);
BOOL Hu3DModelCameraInfoSet(s16, u16);
s16 Hu3DModelCameraCreate(s16, u16);
void Hu3DCameraMotionOn(s16, s8);
void Hu3DCameraMotionStart(s16, u16);
void Hu3DCameraMotionOff(s16);
void Hu3DLighInit(void);
s16 Hu3DGLightCreate(float, float, float, float, float, float, u8, u8, u8);
s16 Hu3DGLightCreateV(HuVecF *, HuVecF *, GXColor *);
s16 Hu3DLLightCreate(s16, float, float, float, float, float, float, u8, u8, u8);
s16 Hu3DLLightCreateV(s16, HuVecF *, HuVecF *, GXColor *);
void Hu3DGLightSpotSet(s16, float, u16);
void Hu3DLLightSpotSet(s16, s16, float, u16);
void Hu3DGLightInfinitytSet(s16);
void Hu3DLLightInfinitytSet(s16, s16);
void Hu3DGLightPointSet(s16, float, float, u16);
void Hu3DLLightPointSet(s16, s16, float, float, u16);
void Hu3DGLightKill(s16);
void Hu3DLLightKill(s16, s16);
void Hu3DLightAllKill(void);
void Hu3DGLightColorSet(s16, u8, u8, u8, u8);
void Hu3DLLightColorSet(s16, s16, u8, u8, u8, u8);
void Hu3DGLightPosSetV(s16, HuVecF *, HuVecF *);
void Hu3DLLightPosSetV(s16, s16, HuVecF *, HuVecF *);
void Hu3DGLightPosSet(s16, float, float, float, float, float, float);
void Hu3DLLightPosSet(s16, s16, float, float, float, float, float, float);
void Hu3DGLightPosAimSetV(s16, HuVecF *, HuVecF *);
void Hu3DLLightPosAimSetV(s16, s16, HuVecF *, HuVecF *);
void Hu3DGLightPosAimSet(s16, float, float, float, float, float, float);
void Hu3DLLightPosAimSet(s16, s16, float, float, float, float, float, float);
void Hu3DGLightStaticSet(s16, s32);
void Hu3DLLightStaticSet(s16, s16, s32);
s32 Hu3DModelLightInfoSet(s16, s16);
s16 Hu3DLightSet(HU3DMODEL *, Mtx *, Mtx *, float);
void lightSet(HU3DLIGHT *arg0, s16 arg1, Mtx *arg2, Mtx *arg3, float arg8);
void Hu3DReflectNoSet(s16 arg0);
void Hu3DFogSet(float, float, u8, u8, u8);
void Hu3DFogClear(void);
void Hu3DShadowCreate(float, float, float);
void Hu3DShadowPosSet(HuVecF *, HuVecF *, HuVecF *);
void Hu3DShadowTPLvlSet(float);
void Hu3DShadowSizeSet(u16);
void Hu3DShadowExec(void);
s16 Hu3DProjectionCreate(void *, float, float, float);
void Hu3DProjectionKill(s16);
void Hu3DProjectionPosSet(s16, HuVecF *, HuVecF *, HuVecF *);
void Hu3DProjectionTPLvlSet(s16, float);
void Hu3DMipMapSet(char *, s16, char *, float);
void Hu3DMotionInit(void);
s16 Hu3DMotionCreate(void *arg0);
s16 Hu3DMotionModelCreate(s16 arg0);
s32 Hu3DMotionKill(s16 arg0);
void Hu3DMotionAllKill(void);
void Hu3DMotionSet(s16 arg0, s16 arg1);
void Hu3DMotionOverlaySet(s16 arg0, s16 arg1);
void Hu3DMotionOverlayReset(s16 arg0);
float Hu3DMotionOverlayTimeGet(s16 arg0);
void Hu3DMotionOverlayTimeSet(s16 arg0, float arg1);
void Hu3DMotionOverlaySpeedSet(s16 arg0, float arg1);
void Hu3DMotionShiftSet(s16 arg0, s16 arg1, float arg2, float arg3, u32 arg4);
void Hu3DMotionShapeSet(s16 arg0, s16 arg1);
s16 Hu3DMotionShapeIDGet(s16 arg0);
void Hu3DMotionShapeSpeedSet(s16 arg0, float arg1);
void Hu3DMotionShapeTimeSet(s16 arg0, float arg1);
float Hu3DMotionShapeMaxTimeGet(s16 arg0);
void Hu3DMotionShapeStartEndSet(s16 arg0, float arg1, float arg2);
s16 Hu3DMotionClusterSet(s16 arg0, s16 arg1);
s16 Hu3DMotionClusterNoSet(s16 arg0, s16 arg1, s16 arg2);
void Hu3DMotionShapeReset(s16 arg0);
void Hu3DMotionClusterReset(s16 arg0, s16 arg1);
s16 Hu3DMotionIDGet(s16 arg0);
s16 Hu3DMotionShiftIDGet(s16 arg0);
void Hu3DMotionTimeSet(s16 arg0, float arg1);
float Hu3DMotionTimeGet(s16 arg0);
float Hu3DMotionShiftTimeGet(s16 arg0);
float Hu3DMotionMaxTimeGet(s16 arg0);
float Hu3DMotionShiftMaxTimeGet(s16 arg0);
void Hu3DMotionShiftStartEndSet(s16 arg0, float arg1, float arg2);
float Hu3DMotionMotionMaxTimeGet(s16 arg0);
void Hu3DMotionStartEndSet(s16 arg0, float arg1, float arg2);
s32 Hu3DMotionEndCheck(s16 arg0);
void Hu3DMotionSpeedSet(s16 arg0, float arg1);
void Hu3DMotionShiftSpeedSet(s16 arg0, float arg1);
void Hu3DMotionNoMotSet(s16 arg0, char *arg1, u32 arg2);
void Hu3DMotionNoMotReset(s16 arg0, char *arg1, u32 arg2);
void Hu3DMotionForceSet(s16 arg0, char *arg1, u32 arg2, float arg3);
void Hu3DMotionNext(s16 arg0);
void Hu3DMotionExec(s16 arg0, s16 arg1, float arg2, s32 arg3);
void Hu3DCameraMotionExec(s16 arg0);
void Hu3DSubMotionExec(s16 arg0);
float *GetObjTRXPtr(HSFOBJECT *arg0, u16 arg1);
void SetObjMatMotion(s16 arg0, HSFTRACK *arg1, float arg2);
void SetObjAttrMotion(s16 arg0, HSFTRACK *arg1, float arg2);
void SetObjCameraMotion(s16 arg0, HSFTRACK *arg1, float arg2);
void SetObjLightMotion(s16 arg0, HSFTRACK *arg1, float arg2);
float GetCurve(HSFTRACK *arg0, float arg1);
float GetConstant(s32 arg0, float *arg1, float arg2);
float GetLinear(s32 arg0, float arg1[][2], float arg2);
float GetBezier(s32 arg0, HSFTRACK *arg1, float arg2);
HSFBITMAP *GetBitMap(s32 arg0, HSFBITMAPKEY *arg1, float arg2);
s16 Hu3DJointMotion(s16 arg0, void *arg1);
void JointModel_Motion(s16 arg0, s16 arg1);
void Hu3DMotionCalc(s16 arg0);
void Hu3DAnimInit(void);
HU3DANIMID Hu3DAnimCreate(void *dataP, HU3DMODELID modelId, char *bmpName);
HU3DANIMID Hu3DAnimLink(HU3DANIMID linkAnimId, HU3DMODELID modelId, char *bmpName);
void Hu3DAnimKill(HU3DANIMID animId);
void Hu3DAnimModelKill(HU3DMODELID modelId);
void Hu3DAnimAllKill(void);
void Hu3DAnimAttrSet(HU3DANIMID animId, u16 attr);
void Hu3DAnimAttrReset(HU3DANIMID animId, s32 attr);
void Hu3DAnimSpeedSet(HU3DANIMID animId, float speed);
void Hu3DAnimBankSet(HU3DANIMID animId, s32 bank);
void Hu3DAnmNoSet(HU3DANIMID animId, u16 anmNo);
s32 Hu3DAnimSet(HU3DMODEL *modelP, HSFATTRIBUTE *attrP, s16 texSlotNo);
void Hu3DAnimExec(void);
HU3DTEXSCRID Hu3DTexScrollCreate(HU3DMODELID modelId, char *bmpName);
void Hu3DTexScrollKill(HU3DTEXSCRID texSrcId);
void Hu3DTexScrollAllKill(void);
void Hu3DTexScrollPosSet(HU3DTEXSCRID texScrId, float posX, float posY, float posZ);
void Hu3DTexScrollPosMoveSet(HU3DTEXSCRID texScrId, float posX, float posY, float posZ);
void Hu3DTexScrollRotSet(HU3DTEXSCRID texScrId, float rot);
void Hu3DTexScrollRotMoveSet(HU3DTEXSCRID texScrId, float rot);
void Hu3DTexScrollPauseDisableSet(HU3DTEXSCRID texScrId, BOOL pauseDisableF);
HU3DMODELID Hu3DParticleCreate(ANIMDATA *anim, s16 maxCnt);
void Hu3DParticleScaleSet(HU3DMODELID modelId, float scale);
void Hu3DParticleZRotSet(HU3DMODELID modelId, float zRot);
void Hu3DParticleColSet(HU3DMODELID modelId, u8 r, u8 g, u8 b);
void Hu3DParticleTPLvlSet(HU3DMODELID modelId, float tpLvl);
void Hu3DParticleBlendModeSet(HU3DMODELID modelId, u8 blendMode);
void Hu3DParticleHookSet(HU3DMODELID modelId, HU3DPARTICLEHOOK hook);
void Hu3DParticleAttrSet(HU3DMODELID modelId, u8 attr);
void Hu3DParticleAttrReset(HU3DMODELID modelId, u8 attr);
void Hu3DParticleCntSet(HU3DMODELID modelId, s16 count);
void Hu3DParticleAnimModeSet(HU3DMODELID modelId, s16 animBank);
void Hu3DParManInit(void);
HU3DPARMANID Hu3DParManCreate(ANIMDATA *anim, s16 maxCnt, HU3DPARMANPARAM *param);
HU3DPARMANID Hu3DParManLink(HU3DPARMANID linkParManId, HU3DPARMANPARAM *param);
void Hu3DParManKill(HU3DPARMANID parManId);
void Hu3DParManAllKill(void);
HU3DPARMAN *Hu3DParManPtrGet(HU3DPARMANID parManId);
void Hu3DParManPosSet(HU3DPARMANID parManId, float posX, float posY, float posZ);
void Hu3DParManVecSet(HU3DPARMANID parManId, float x, float y, float z);
void Hu3DParManRotSet(HU3DPARMANID parManId, float rotX, float rotY, float rotZ);
void Hu3DParManAttrSet(HU3DPARMANID parManId, s32 attr);
void Hu3DParManAttrReset(HU3DPARMANID parManId, s32 attr);
s16 Hu3DParManModelIDGet(HU3DPARMANID parManId);
void Hu3DParManTimeLimitSet(HU3DPARMANID parManId, s32 timeLimit);
void Hu3DParManVacumeSet(HU3DPARMANID parManId, float x, float y, float z, float speed);
void Hu3DParManColorSet(HU3DPARMANID parManId, s16 color);
extern Vec PGMaxPos;
extern Vec PGMinPos;
extern u32 totalPolyCnt;
extern u32 totalPolyCnted;
extern u32 totalMatCnt;
extern u32 totalMatCnted;
extern u32 totalTexCnt;
extern u32 totalTexCnted;
extern u32 totalTexCacheCnt;
extern u32 totalTexCacheCnted;
extern HU3DMODEL Hu3DData[0x200];
extern HU3DCAMERA Hu3DCamera[0x10];
extern ANIMDATA *reflectAnim[5];
extern ANIMDATA *hiliteAnim[4];
extern HU3DPROJECTION Hu3DProjection[4];
extern HU3DSHADOW Hu3DShadowData;
extern Mtx Hu3DCameraMtx;
extern Mtx Hu3DCameraMtxXPose;
extern HU3DLIGHT Hu3DGlobalLight[0x8];
extern s16 reflectMapNo;
extern ANIMDATA *toonAnim;
extern s16 Hu3DShadowCamBit;
extern s32 Hu3DShadowF;
extern s32 shadowModelDrawF;
extern s16 Hu3DCameraNo;
extern s16 Hu3DCameraBit;
extern s16 Hu3DPauseF;
extern GXColor BGColor;
extern HU3DMOTION Hu3DMotion[256];
extern HU3DTEXANIM Hu3DTexAnimData[256 ];
extern HU3DTEXSCROLL Hu3DTexScrData[16 ];
typedef struct jump_buf {
u32 lr;
u32 cr;
u32 sp;
u32 r2;
u32 pad;
u32 regs[19];
double flt_regs[19];
} jmp_buf;
s32 gcsetjmp(jmp_buf *jump);
s32 gclongjmp(jmp_buf *jump, s32 status);
typedef struct Process_s HUPROCESS;
typedef struct Process_s {
HUPROCESS *next;
HUPROCESS *prev;
HUPROCESS *child;
HUPROCESS *parent;
HUPROCESS *next_child;
HUPROCESS *first_child;
void *heap;
u16 exec;
u16 stat;
u16 prio;
s32 sleep_time;
u32 base_sp;
jmp_buf jump;
void (*dtor)(void);
void *user_data;
} HUPROCESS;
void HuPrcInit(void);
void HuPrcEnd(void);
HUPROCESS *HuPrcCreate(void (*func)(void), u16 prio, u32 stack_size, s32 extra_size);
void HuPrcChildLink(HUPROCESS *parent, HUPROCESS *child);
void HuPrcChildUnlink(HUPROCESS *process);
HUPROCESS *HuPrcChildCreate(void (*func)(void), u16 prio, u32 stack_size, s32 extra_size, HUPROCESS *parent);
void HuPrcChildWatch(void);
HUPROCESS *HuPrcCurrentGet(void);
s32 HuPrcKill(HUPROCESS *process);
void HuPrcChildKill(HUPROCESS *process);
void HuPrcSleep(s32 time);
void HuPrcVSleep();
void HuPrcWakeup(HUPROCESS *process);
void HuPrcDestructorSet2(HUPROCESS *process, void (*func)(void));
void HuPrcDestructorSet(void (*func)(void));
void HuPrcCall(s32 tick);
void *HuPrcMemAlloc(s32 size);
void HuPrcMemFree(void *ptr);
void HuPrcSetStat(HUPROCESS *process, u16 value);
void HuPrcResetStat(HUPROCESS *process, u16 value);
void HuPrcAllPause(s32 flag);
void HuPrcAllUPause(s32 flag);
typedef enum omOvl_e {
DLL_NONE = -1,
DLL__minigameDLL,
DLL_bootdll,
DLL_e3setupDLL,
DLL_instdll,
DLL_m300dll,
DLL_m302dll,
DLL_m303dll,
DLL_m330dll,
DLL_m333dll,
DLL_m401dll,
DLL_m402dll,
DLL_m403dll,
DLL_m404dll,
DLL_m405dll,
DLL_m406dll,
DLL_m407dll,
DLL_m408dll,
DLL_m409dll,
DLL_m410dll,
DLL_m411dll,
DLL_m412dll,
DLL_m413dll,
DLL_m414dll,
DLL_m415dll,
DLL_m416dll,
DLL_m417dll,
DLL_m418dll,
DLL_m419dll,
DLL_m420dll,
DLL_m421dll,
DLL_m422dll,
DLL_m423dll,
DLL_m424dll,
DLL_m425dll,
DLL_m426dll,
DLL_m427dll,
DLL_m428dll,
DLL_m429dll,
DLL_m430dll,
DLL_m431dll,
DLL_m432dll,
DLL_m433dll,
DLL_m434dll,
DLL_m435dll,
DLL_m436dll,
DLL_m437dll,
DLL_m438dll,
DLL_m439dll,
DLL_m440dll,
DLL_m441dll,
DLL_m442dll,
DLL_m443dll,
DLL_m444dll,
DLL_m445dll,
DLL_m446dll,
DLL_m447dll,
DLL_m448dll,
DLL_m449dll,
DLL_m450dll,
DLL_m451dll,
DLL_m453dll,
DLL_m455dll,
DLL_m456dll,
DLL_m457dll,
DLL_m458dll,
DLL_m459dll,
DLL_m460dll,
DLL_m461dll,
DLL_m462dll,
DLL_m463dll,
DLL_mentdll,
DLL_messdll,
DLL_mgmodedll,
DLL_modeltestdll,
DLL_modeseldll,
DLL_mpexdll,
DLL_msetupdll,
DLL_mstory2dll,
DLL_mstory3dll,
DLL_mstory4dll,
DLL_mstorydll,
DLL_nisdll,
DLL_option,
DLL_present,
DLL_resultdll,
DLL_safdll,
DLL_selmenuDLL,
DLL_staffdll,
DLL_subchrseldll,
DLL_w01dll,
DLL_w02dll,
DLL_w03dll,
DLL_w04dll,
DLL_w05dll,
DLL_w06dll,
DLL_w10dll,
DLL_w20dll,
DLL_w21dll,
DLL_ztardll,
DLL_MAX
} OMOVL;
typedef struct omObj_s OMOBJ;
typedef void (*OMOBJFUNC)(OMOBJ *obj);
typedef struct omOvlHis_s {
OMOVL ovl;
s32 evtno;
s32 stat;
} OMOVLHIS;
struct omObj_s {
u16 stat;
s16 objNext;
s16 prio;
s16 prev;
s16 next;
s16 nextNo;
s16 grpNo;
u16 memberNo;
u32 mode;
OMOBJFUNC objFunc;
Vec trans;
Vec rot;
Vec scale;
u16 mdlcnt;
s16 *mdlId;
u16 mtncnt;
s16 *mtnId;
u32 work[4];
void *data;
};
typedef struct om_dll_data {
char *name;
OSModuleHeader *module;
void *bss;
s32 ret;
} omDllData;
void omMasterInit(s32 prio, FileListEntry *ovl_list, s32 ovl_count, OMOVL start_ovl);
void omOvlCallEx(OMOVL overlay, s16 arg2, s32 event, s32 stat);
void omOvlGotoEx(OMOVL overlay, s16 arg2, s32 event, s32 stat);
void omOvlReturnEx(s16 level, s16 arg2);
void omOvlKill(s16 arg);
void omOvlHisChg(s32 level, OMOVL overlay, s32 event, s32 stat);
OMOVLHIS *omOvlHisGet(s32 level);
HUPROCESS *omInitObjMan(s16 max_objs, s32 prio);
void omDestroyObjMan(void);
OMOBJ *omAddObjEx(HUPROCESS *objman_process, s16 prio, u16 mdlcnt, u16 mtncnt, s16 group, OMOBJFUNC func);
void omAddMember(HUPROCESS *objman_process, u16 group, OMOBJ *object);
void omDelObjEx(HUPROCESS *objman_process, OMOBJ *object);
void omDelMember(HUPROCESS *objman_process, OMOBJ *object);
void omMakeGroupEx(HUPROCESS *objman_process, u16 group, u16 max_objs);
OMOBJ **omGetGroupMemberListEx(HUPROCESS *objman_process, s16 group);
void omSetStatBit(OMOBJ *obj, u16 stat);
void omResetStatBit(OMOBJ *obj, u16 stat);
void omSetTra(OMOBJ *obj, float x, float y, float z);
void omSetRot(OMOBJ *obj, float x, float y, float z);
void omSetSca(OMOBJ *obj, float x, float y, float z);
void omMain(void);
void omAllPause(BOOL pause);
char omPauseChk(void);
OMOVL omCurrentOvlGet(void);
void omDLLDBGOut(void);
void omDLLInit(FileListEntry *ovl_list);
s32 omDLLStart(s16 overlay, s16 flag);
void omDLLNumEnd(s16 overlay, s16 flag);
void omDLLEnd(s16 dllno, s16 flag);
omDllData *omDLLLink(omDllData **dll_ptr, s16 overlay, s16 flag);
void omDLLUnlink(omDllData *dll_ptr, s16 flag);
s32 omDLLSearch(s16 overlay);
void omDLLInfoDump(OSModuleInfo *module);
void omDLLHeaderDump(OSModuleHeader *module);
void omOutView(OMOBJ *object);
void omOutViewMulti(OMOBJ *object);
void omSystemKeyCheckSetup(HUPROCESS *objman);
void omSystemKeyCheck(OMOBJ *object);
void omSysPauseEnable(u8 flag);
void omSysPauseCtrl(s16 flag);
extern OMOBJ *omDBGSysKeyObj;
extern HUPROCESS *omwatchproc;
extern OMOVL omnextovl;
extern OMOVL omcurovl;
extern s32 omcurdll;
extern s32 omovlhisidx;
extern s32 omovlevtno;
extern s32 omnextovlevtno;
extern u32 omovlstat;
extern char omUPauseFlag;
extern s16 omSysExitReq;
extern s16 omdispinfo;
extern u8 omSysPauseEnableFlag;
extern OMOVL omprevovl;
extern omDllData *omDLLinfoTbl[20 ];
extern Vec CRot;
extern Vec Center;
extern float CZoom;
extern Vec CRotM[16];
extern Vec CenterM[16];
extern float CZoomM[16];
extern s16 omDBGMenuButton;
typedef struct M420DllUnkStruct {
Vec unk_00;
Vec unk_0C;
float unk_18;
} M420DllUnkStruct;
typedef struct M420DllPlayerStruct {
struct {
s8 unk_00_field0 : 1;
s8 unk_00_field1 : 1;
s8 unk_00_field2 : 1;
};
s32 unk_04;
u8 unk_08;
s16 unk_0A;
u8 unk_0C;
Vec unk_10;
Vec unk_1C;
Vec unk_28;
Vec unk_34;
HUPROCESS *unk_40;
char unk44[4];
s32 unk_48;
s32 unk_4C;
s16 unk_50;
char unk52[6];
s32 unk_58;
s32 unk_5C[0xA];
s32 unk_84[0xA];
s16 unk_AC;
s16 unk_AE[0xB];
s16 unk_C4[0xA];
s16 unk_D8;
float unk_DC;
float unk_E0;
s32 unk_E4;
struct M420DllPlayerStruct *unk_E8;
} M420DllPlayerStruct;
void fn_1_1184(void);
s32 fn_1_4964(void);
void fn_1_596C(void);
s32 fn_1_59F4(s32);
s32 fn_1_5AA8(s32 arg0, float arg1);
s32 fn_1_60F0(void);
void fn_1_6268(void);
void fn_1_636C(void);
void fn_1_63EC(void);
void fn_1_6554(void);
s16 fn_1_6660(void);
void fn_1_669C(s32 arg0);
void fn_1_6728(void);
s32 fn_1_67E8(s32);
s32 fn_1_6810(void);
void fn_1_8934(void);
s32 fn_1_8944(void);
M420DllPlayerStruct *fn_1_1B8C(s32, s32);
void fn_1_1E14(M420DllPlayerStruct *);
extern HUPROCESS *lbl_1_bss_4;
typedef struct M420DllUnkMapStruct2 {
struct {
s8 unk_00_field0 : 1;
s8 unk_00_field1 : 1;
s8 unk_00_field2 : 1;
s8 unk_00_field3 : 1;
s8 unk_00_field4 : 1;
s8 unk_00_field5 : 1;
s8 unk_00_field6 : 1;
s8 unk_00_field7 : 1;
};
s16 unk_02;
Vec unk_04;
Vec unk_10;
Vec unk_1C;
Vec unk_28;
Vec unk_34;
Vec unk_40;
Vec unk_4C;
Vec unk_58;
Vec unk_64;
float unk_70;
float unk_74;
s32 unk_78;
float unk_7C;
float unk_80;
s32 unk_84;
float unk_88;
float unk_8C;
s32 unk_90;
} M420DllUnkMapStruct2;
typedef struct M420DllUnkMapStruct {
M420DllUnkMapStruct2 *unk_00;
M420DllUnkMapStruct2 *unk_04;
M420DllUnkMapStruct2 *unk_08;
M420DllUnkMapStruct2 *unk_0C;
M420DllUnkMapStruct2 *unk_10;
s32 unk_14;
char pad_18[4];
float unk_1C;
float unk_20;
float unk_24;
float unk_28;
float unk_2C;
s32 unk_30;
s32 unk_34;
s32 unk_38;
s32 unk_3C;
} M420DllUnkMapStruct;
typedef struct M420DllUnkMapStruct3 {
Vec unk_00;
Vec unk_0C;
GXColor unk_18;
} M420DllUnkMapStruct3;
s32 fn_1_5A7C(s32 arg0);
void fn_1_6820(void);
void fn_1_6884(void);
void fn_1_6950(void);
void fn_1_6D0C(void);
void fn_1_6D5C(void);
void fn_1_6DF0(M420DllUnkMapStruct2 *arg0);
void fn_1_7230(M420DllUnkMapStruct2 *arg0, Vec *arg1, s32 arg2, s32 arg3);
void fn_1_7704(void);
void fn_1_7E24(void);
void fn_1_8240(void);
void fn_1_8414(void);
M420DllUnkMapStruct3 lbl_1_data_138 = {
{ 1000.0f, 2000.0f, 0.0f },
{ -0.5f, -0.5f, -0.5f },
{ 0xFF, 0xFF, 0xFF, 0xFF },
};
void (*lbl_1_data_154[4])() = { fn_1_7704, fn_1_7E24, fn_1_8240, fn_1_8414 };
static const s32 lbl_1_rodata_360[0x1B] = {
((DATADIR_M420)+(0x00)) ,
((DATADIR_M420)+(0x14)) ,
((DATADIR_M420)+(0x07)) ,
((DATADIR_M420)+(0x08)) ,
((DATADIR_M420)+(0x01)) ,
((DATADIR_M420)+(0x02)) ,
((DATADIR_M420)+(0x03)) ,
((DATADIR_M420)+(0x04)) ,
((DATADIR_M420)+(0x05)) ,
((DATADIR_M420)+(0x06)) ,
((DATADIR_M420)+(0x15)) ,
((DATADIR_M420)+(0x16)) ,
((DATADIR_M420)+(0x17)) ,
((DATADIR_M420)+(0x09)) ,
((DATADIR_M420)+(0x09)) ,
((DATADIR_M420)+(0x0A)) ,
((DATADIR_M420)+(0x0B)) ,
((DATADIR_M420)+(0x0E)) ,
((DATADIR_M420)+(0x0F)) ,
((DATADIR_M420)+(0x0C)) ,
((DATADIR_M420)+(0x0D)) ,
((DATADIR_M420)+(0x12)) ,
((DATADIR_M420)+(0x11)) ,
((DATADIR_M420)+(0x10)) ,
((DATADIR_M420)+(0x10)) ,
((DATADIR_M420)+(0x13)) ,
((DATADIR_M420)+(0x13)) ,
};
HUPROCESS *lbl_1_bss_A40;
HUPROCESS *lbl_1_bss_A3C;
HUPROCESS *lbl_1_bss_A2C[4];
s32 lbl_1_bss_A28;
s16 lbl_1_bss_9F0[0x1C];
s16 lbl_1_bss_9EE;
s16 lbl_1_bss_9EC;
M420DllUnkMapStruct2 lbl_1_bss_140[15];
struct M420DllUnkMapStruct lbl_1_bss_C0[2];
s32 lbl_1_bss_BC;
s32 lbl_1_bss_B8;
s32 lbl_1_bss_B4;
s32 lbl_1_bss_B0;
s32 fn_1_4964(void)
{
M420DllUnkMapStruct2 *var_r31;
M420DllUnkMapStruct *var_r30;
s32 var_r29;
lbl_1_bss_A40 = HuPrcChildCreate(fn_1_6820, 0x3E9, 0x4000, 0, lbl_1_bss_4);
lbl_1_bss_A3C = HuPrcChildCreate(fn_1_6884, 0x3EA, 0x4000, 0, lbl_1_bss_4);
for (var_r29 = 0; var_r29 < 4; var_r29++) {
lbl_1_bss_A2C[var_r29] = ((void *)0) ;
}
lbl_1_bss_A28 = 0;
fn_1_6D5C();
fn_1_6950();
var_r31 = lbl_1_bss_140;
var_r31->unk_02 = lbl_1_bss_9F0[1];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 1000.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[1];
var_r31->unk_02 = lbl_1_bss_9F0[0xA];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[2];
var_r31->unk_02 = lbl_1_bss_9F0[0xC];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[3];
var_r31->unk_02 = lbl_1_bss_9F0[0xB];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[4];
var_r31->unk_02 = lbl_1_bss_9F0[0xD];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = -220.0f;
var_r31->unk_04.y = -60.0f;
var_r31->unk_04.z = 170.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[9];
var_r31->unk_02 = lbl_1_bss_9F0[0x17];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = -170.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 170.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[11];
var_r31->unk_02 = lbl_1_bss_9F0[0x19];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = -160.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 220.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[6];
var_r31->unk_02 = lbl_1_bss_9F0[0x11];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = -65.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[5];
var_r31->unk_02 = lbl_1_bss_9F0[0xE];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 220.0f;
var_r31->unk_04.y = -60.0f;
var_r31->unk_04.z = 170.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[10];
var_r31->unk_02 = lbl_1_bss_9F0[0x18];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 190.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 170.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[12];
var_r31->unk_02 = lbl_1_bss_9F0[0x1A];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 185.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 220.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[7];
var_r31->unk_02 = lbl_1_bss_9F0[0x12];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = -65.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[8];
var_r31->unk_02 = lbl_1_bss_9F0[0x13];
var_r31->unk_00_field3 = 1;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 300.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[13];
var_r31->unk_02 = lbl_1_bss_9F0[3];
var_r31->unk_00_field3 = 0;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
var_r31 = &lbl_1_bss_140[14];
var_r31->unk_02 = lbl_1_bss_9F0[2];
var_r31->unk_00_field3 = 0;
var_r31->unk_00_field0 = 0;
var_r31->unk_00_field1 = 0;
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 0.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
var_r31->unk_4C.x = 1.0f;
var_r31->unk_4C.y = 1.0f;
var_r31->unk_4C.z = 1.0f;
fn_1_6DF0(var_r31);
for (var_r29 = 0; var_r29 < 2; var_r29++) {
var_r30 = &lbl_1_bss_C0[var_r29];
var_r30->unk_14 = var_r29;
var_r30->unk_1C = 20.0f;
var_r30->unk_20 = 0.0f;
var_r30->unk_2C = 0.0f;
var_r30->unk_24 = 0.2f;
var_r30->unk_28 = 0.1f;
var_r30->unk_38 = 0;
var_r30->unk_3C = 0;
var_r30->unk_30 = 1;
var_r30->unk_00 = &lbl_1_bss_140[var_r29 + 13];
var_r30->unk_04 = &lbl_1_bss_140[var_r29 + 4];
var_r30->unk_08 = &lbl_1_bss_140[var_r29 + 6];
var_r30->unk_0C = &lbl_1_bss_140[var_r29 + 9];
var_r30->unk_10 = &lbl_1_bss_140[var_r29 + 11];
}
lbl_1_bss_B8 = 0;
lbl_1_bss_B4 = 0;
lbl_1_bss_B0 = 0;
fn_1_6728();
{
Vec sp14 = { 0.0f, 0.0f, 0.0f };
Vec sp8 = { 0.0f, 0.0f, -1.0f };
HuAudFXListnerSetEX(&sp14, &sp8, 3000.0, 1000.0, 100.0, 300.0, 300.0);
HuAudFXPlay(0x5F0);
}
return 1;
}
void fn_1_596C(void)
{
HUPROCESS *var_r30;
s32 var_r31;
for (var_r31 = 0; var_r31 < 4; var_r31++) {
var_r30 = lbl_1_bss_A2C[var_r31];
if (var_r30) {
HuPrcKill(var_r30);
}
}
fn_1_6D0C();
HuPrcKill(lbl_1_bss_A3C);
HuPrcKill(lbl_1_bss_A40);
}
s32 fn_1_59F4(s32 arg0)
{
if (fn_1_5A7C(arg0) != 0) {
return 0;
}
lbl_1_bss_A2C[arg0] = HuPrcChildCreate(lbl_1_data_154[arg0], 0x3ED, 0x5000, 0, lbl_1_bss_4);
return 1;
}
s32 fn_1_5A7C(s32 arg0)
{
return lbl_1_bss_A2C[arg0] != ((void *)0) ;
}
s32 fn_1_5AA8(s32 arg0, float arg1)
{
M420DllUnkMapStruct *var_r31;
s32 var_r29;
s32 var_r30;
var_r31 = &lbl_1_bss_C0[arg0];
if ((var_r31->unk_1C += arg1) >= 200.0f) {
var_r31->unk_1C = 200.0f;
}
var_r31->unk_38 = 1;
var_r31->unk_30 = (s32)(200.0f - var_r31->unk_1C) / 10.0f;
switch (arg0) {
case 0:
var_r29 = 3;
var_r30 = 0x15;
break;
case 1:
var_r29 = 2;
var_r30 = 0x16;
break;
}
if (var_r31->unk_1C >= 200.0f) {
if (lbl_1_bss_B0 == 0) {
var_r31->unk_3C = 1;
Hu3DMotionTimeSet(lbl_1_bss_9F0[var_r30], 0.0f);
Hu3DModelAttrReset(lbl_1_bss_9F0[var_r30], 0x1 );
Hu3DModelAttrSet(lbl_1_bss_9F0[var_r30], 0x40000001 );
Hu3DModelAttrSet(lbl_1_bss_9F0[var_r29], 0x1 );
}
return 1;
}
return 0;
}
void fn_1_5C8C(M420DllUnkMapStruct *arg0)
{
Vec sp8;
if (arg0->unk_38 != 0) {
if (arg0->unk_30 > 0) {
arg0->unk_30--;
}
if (arg0->unk_30 <= 0) {
sp8 = arg0->unk_04->unk_04;
sp8.y = -60.0f + arg0->unk_1C;
fn_1_7230(arg0->unk_04, &sp8, 0x1E, 0);
sp8 = arg0->unk_08->unk_04;
sp8.y = -65.0f + arg0->unk_1C;
fn_1_7230(arg0->unk_08, &sp8, 0x1E, 0);
sp8 = arg0->unk_0C->unk_04;
sp8.y = 40.0f + arg0->unk_1C;
fn_1_7230(arg0->unk_0C, &sp8, 0x1E, 1);
Hu3DMotionTimeSet(arg0->unk_0C->unk_02, 0.0f);
Hu3DModelAttrReset(arg0->unk_0C->unk_02, 0x1 );
sp8 = arg0->unk_10->unk_04;
sp8.y = -50.0f + arg0->unk_1C;
fn_1_7230(arg0->unk_10, &sp8, 0x1E, 1);
Hu3DMotionTimeSet(arg0->unk_10->unk_02, 0.0f);
Hu3DModelAttrReset(arg0->unk_10->unk_02, 0x1 );
Hu3DMotionStartEndSet(arg0->unk_00->unk_02, 0.0f, 30.0f);
Hu3DMotionTimeSet(arg0->unk_00->unk_02, 0.0f);
Hu3DModelAttrReset(arg0->unk_00->unk_02, 0x40000002 );
Hu3DModelAttrReset(arg0->unk_00->unk_02, 0x40000001 );
arg0->unk_34 = 3;
arg0->unk_38 = 0;
arg0->unk_24 = 0.8f;
arg0->unk_28 = 0.3f;
arg0->unk_2C = 0.0f;
if (arg0->unk_14 == 0) {
HuAudFXPlay(0x5F7);
}
else {
HuAudFXPlay(0x5F8);
}
}
}
if ((Hu3DMotionEndCheck(arg0->unk_00->unk_02) != 0) && (arg0->unk_34 > 0)) {
if (--arg0->unk_34 > 0) {
Hu3DMotionTimeSet(arg0->unk_00->unk_02, 0.0f);
}
else {
Hu3DMotionStartEndSet(arg0->unk_00->unk_02, 0.0f, 1.0f);
Hu3DMotionTimeSet(arg0->unk_00->unk_02, 0.0f);
Hu3DModelAttrSet(arg0->unk_00->unk_02, 0x40000002 );
}
}
if (arg0->unk_24 > 0.2f) {
if ((arg0->unk_24 -= 0.005f) <= 0.2f) {
arg0->unk_24 = 0.2f;
}
}
arg0->unk_04->unk_28.y += arg0->unk_24;
if (arg0->unk_28 > 0.05f) {
if ((arg0->unk_28 -= 0.003f) <= 0.05f) {
arg0->unk_28 = 0.05f;
}
}
arg0->unk_04->unk_4C.y = 1.0 + (arg0->unk_28 * sin(3.141592653589793*((90.0f * arg0->unk_2C))/180.0) );
arg0->unk_2C += 0.02f;
}
s32 fn_1_60F0(void)
{
float var_f31;
float var_f30;
s32 var_r31;
if (lbl_1_bss_BC >= 6) {
return 1;
}
var_f31 = 5.0f * (6 - lbl_1_bss_BC);
var_f30 = var_f31 - 5.0f;
Hu3DMotionStartEndSet(lbl_1_bss_9F0[0xF], var_f30, var_f31);
Hu3DMotionTimeSet(lbl_1_bss_9F0[0xF], var_f31);
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000002 );
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000001 );
Hu3DModelAttrSet(lbl_1_bss_9F0[0xF], 0x40000004 );
lbl_1_bss_B8 = 5;
lbl_1_bss_BC += 1;
if (lbl_1_bss_BC == 6) {
var_r31 = 1;
}
else {
var_r31 = 0;
}
return var_r31;
}
void fn_1_6268(void)
{
float var_f31 = 0.0f;
float var_f30 = 30.0f;
Hu3DMotionStartEndSet(lbl_1_bss_9F0[0xF], var_f31, var_f30);
Hu3DMotionTimeSet(lbl_1_bss_9F0[0xF], var_f31);
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000002 );
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000001 );
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000004 );
Hu3DMotionStartEndSet(lbl_1_bss_9F0[0x10], var_f31, var_f30);
Hu3DMotionTimeSet(lbl_1_bss_9F0[0x10], var_f31);
lbl_1_bss_BC = 0;
}
void fn_1_636C(void)
{
float var_f31 = 0.0f;
float var_f30 = 30.0f;
Hu3DMotionStartEndSet(lbl_1_bss_9F0[0x14], var_f31, var_f30);
Hu3DMotionTimeSet(lbl_1_bss_9F0[0x14], var_f31);
}
void fn_1_63EC(void)
{
float var_f31 = 5.0f * (6 - lbl_1_bss_BC);
float var_f30 = 30.0f;
Hu3DMotionStartEndSet(lbl_1_bss_9F0[0xF], var_f31, var_f30);
Hu3DMotionTimeSet(lbl_1_bss_9F0[0xF], var_f31);
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000002 );
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000001 );
Hu3DModelAttrReset(lbl_1_bss_9F0[0xF], 0x40000004 );
lbl_1_bss_BC = 0;
lbl_1_bss_B8 = 0;
}
s32 fn_1_650C(void)
{
s32 var_r31 = 0;
if ((lbl_1_bss_BC == 6) && (lbl_1_bss_B8 == 0)) {
var_r31 = 1;
}
return var_r31;
}
void fn_1_6554(void)
{
Vec sp8;
M420DllUnkMapStruct2 *var_r31;
var_r31 = &lbl_1_bss_140[8];
var_r31->unk_04.x = 480.0f;
var_r31->unk_04.y = 800.0f;
var_r31->unk_04.z = -314.0f;
var_r31->unk_28.x = 0.0f;
var_r31->unk_28.y = 0.0f;
var_r31->unk_28.z = 0.0f;
fn_1_6DF0(var_r31);
sp8.x = 480.0f;
sp8.y = 370.0f;
sp8.z = -314.0f;
Hu3DModelAttrReset(var_r31->unk_02, 0x1 );
fn_1_7230(var_r31, &sp8, 0x14, 0);
Hu3DMotionTimeSet(fn_1_6660(), 0.0f);
Hu3DModelAttrSet(fn_1_6660(), 0x40000002 );
}
s16 fn_1_6660(void)
{
return lbl_1_bss_140[8].unk_02;
}
s32 fn_1_6670(void)
{
M420DllUnkMapStruct2 *var_r31 = &lbl_1_bss_140[8];
return var_r31->unk_00_field0;
}
void fn_1_669C(s32 arg0)
{
M420DllUnkMapStruct2 *var_r31 = &lbl_1_bss_140[8];
if (arg0 == 0) {
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 0.0f;
var_r31->unk_04.z = 0.0f;
fn_1_6DF0(var_r31);
}
var_r31->unk_00_field3 = arg0;
}
void fn_1_6728(void)
{
M420DllUnkMapStruct2 *var_r31 = &lbl_1_bss_140[8];
var_r31->unk_04.x = 0.0f;
var_r31->unk_04.y = 1000.0f;
var_r31->unk_04.z = 0.0f;
fn_1_6DF0(var_r31);
Hu3DModelAttrSet(lbl_1_bss_9F0[0x13], 0x1 );
}
