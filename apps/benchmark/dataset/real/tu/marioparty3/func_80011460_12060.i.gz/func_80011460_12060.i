typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef volatile unsigned char vu8;
typedef volatile unsigned short vu16;
typedef volatile unsigned long vu32;
typedef volatile unsigned long long vu64;
typedef volatile signed char vs8;
typedef volatile short vs16;
typedef volatile long vs32;
typedef volatile long long vs64;
typedef float f32;
typedef double f64;
typedef unsigned int size_t;
typedef s32 OSPri;
typedef s32 OSId;
typedef union { struct { f32 f_odd; f32 f_even; } f; f64 d; } __OSfp;
typedef struct {
 u64 at, v0, v1, a0, a1, a2, a3;
 u64 t0, t1, t2, t3, t4, t5, t6, t7;
 u64 s0, s1, s2, s3, s4, s5, s6, s7;
 u64 t8, t9, gp, sp, s8, ra;
 u64 lo, hi;
 u32 sr, pc, cause, badvaddr, rcp;
 u32 fpcsr;
 __OSfp fp0, fp2, fp4, fp6, fp8, fp10, fp12, fp14;
 __OSfp fp16, fp18, fp20, fp22, fp24, fp26, fp28, fp30;
} __OSThreadContext;
typedef struct OSThread_s {
 struct OSThread_s *next;
 OSPri priority;
 struct OSThread_s **queue;
 struct OSThread_s *tlnext;
 u16 state;
 u16 flags;
 OSId id;
 int fp;
 __OSThreadContext context;
} OSThread;
typedef u32 OSEvent;
typedef u32 OSIntMask;
typedef u32 OSPageMask;
typedef u32 OSHWIntr;
typedef void * OSMesg;
typedef struct OSMesgQueue_s {
 OSThread *mtqueue;
 OSThread *fullqueue;
 s32 validCount;
 s32 first;
 s32 msgCount;
 OSMesg *msg;
} OSMesgQueue;
typedef struct {
 u32 errStatus;
        void *dramAddr;
 void *C2Addr;
 u32 sectorSize;
 u32 C1ErrNum;
 u32 C1ErrSector[4];
} __OSBlockInfo;
typedef struct {
 u32 cmdType;
 u16 transferMode;
 u16 blockNum;
 s32 sectorNum;
 u32 devAddr;
 u32 bmCtlShadow;
 u32 seqCtlShadow;
 __OSBlockInfo block[2];
} __OSTranxInfo;
typedef struct OSPiHandle_s {
        struct OSPiHandle_s *next;
        u8 type;
        u8 latency;
        u8 pageSize;
        u8 relDuration;
        u8 pulse;
 u8 domain;
        u32 baseAddress;
        u32 speed;
        __OSTranxInfo transferInfo;
} OSPiHandle;
typedef struct {
        u8 type;
        u32 address;
} OSPiInfo;
typedef struct {
        u16 type;
        u8 pri;
        u8 status;
 OSMesgQueue *retQueue;
} OSIoMesgHdr;
typedef struct {
 OSIoMesgHdr hdr;
 void * dramAddr;
 u32 devAddr;
 u32 size;
 OSPiHandle *piHandle;
} OSIoMesg;
typedef struct {
        s32 active;
 OSThread *thread;
        OSMesgQueue *cmdQueue;
        OSMesgQueue *evtQueue;
        OSMesgQueue *acsQueue;
        s32 (*dma)(s32, u32, void *, u32);
        s32 (*edma)(OSPiHandle *, s32, u32, void *, u32);
} OSDevMgr;
typedef struct {
    u32 ctrl;
    u32 width;
    u32 burst;
    u32 vSync;
    u32 hSync;
    u32 leap;
    u32 hStart;
    u32 xScale;
    u32 vCurrent;
} OSViCommonRegs;
typedef struct {
    u32 origin;
    u32 yScale;
    u32 vStart;
    u32 vBurst;
    u32 vIntr;
} OSViFieldRegs;
typedef struct {
    u8 type;
    OSViCommonRegs comRegs;
    OSViFieldRegs fldRegs[2];
} OSViMode;
typedef u64 OSTime;
typedef struct OSTimer_s {
 struct OSTimer_s *next;
 struct OSTimer_s *prev;
 OSTime interval;
 OSTime value;
 OSMesgQueue *mq;
 OSMesg msg;
} OSTimer;
typedef struct {
 u16 type;
 u8 status;
 u8 errno;
}OSContStatus;
typedef struct {
 u16 button;
 s8 stick_x;
 s8 stick_y;
 u8 errno;
} OSContPad;
typedef struct {
 void *address;
 u8 databuffer[32];
        u8 addressCrc;
 u8 dataCrc;
 u8 errno;
} OSContRamIo;
typedef struct {
 int status;
 OSMesgQueue *queue;
 int channel;
 u8 id[32];
 u8 label[32];
 int version;
 int dir_size;
 int inode_table;
 int minode_table;
 int dir_table;
 int inode_start_page;
 u8 banks;
 u8 activebank;
} OSPfs;
typedef struct {
 u32 file_size;
   u32 game_code;
   u16 company_code;
   char ext_name[4];
   char game_name[16];
} OSPfsState;
typedef struct {
 u16 *histo_base;
 u32 histo_size;
 u32 *text_start;
 u32 *text_end;
} OSProf;
extern u64 osClockRate;
extern OSViMode osViModeTable[];
extern OSViMode osViModeNtscLpn1;
extern OSViMode osViModeNtscLpf1;
extern OSViMode osViModeNtscLan1;
extern OSViMode osViModeNtscLaf1;
extern OSViMode osViModeNtscLpn2;
extern OSViMode osViModeNtscLpf2;
extern OSViMode osViModeNtscLan2;
extern OSViMode osViModeNtscLaf2;
extern OSViMode osViModeNtscHpn1;
extern OSViMode osViModeNtscHpf1;
extern OSViMode osViModeNtscHan1;
extern OSViMode osViModeNtscHaf1;
extern OSViMode osViModeNtscHpn2;
extern OSViMode osViModeNtscHpf2;
extern OSViMode osViModePalLpn1;
extern OSViMode osViModePalLpf1;
extern OSViMode osViModePalLan1;
extern OSViMode osViModePalLaf1;
extern OSViMode osViModePalLpn2;
extern OSViMode osViModePalLpf2;
extern OSViMode osViModePalLan2;
extern OSViMode osViModePalLaf2;
extern OSViMode osViModePalHpn1;
extern OSViMode osViModePalHpf1;
extern OSViMode osViModePalHan1;
extern OSViMode osViModePalHaf1;
extern OSViMode osViModePalHpn2;
extern OSViMode osViModePalHpf2;
extern OSViMode osViModeMpalLpn1;
extern OSViMode osViModeMpalLpf1;
extern OSViMode osViModeMpalLan1;
extern OSViMode osViModeMpalLaf1;
extern OSViMode osViModeMpalLpn2;
extern OSViMode osViModeMpalLpf2;
extern OSViMode osViModeMpalLan2;
extern OSViMode osViModeMpalLaf2;
extern OSViMode osViModeMpalHpn1;
extern OSViMode osViModeMpalHpf1;
extern OSViMode osViModeMpalHan1;
extern OSViMode osViModeMpalHaf1;
extern OSViMode osViModeMpalHpn2;
extern OSViMode osViModeMpalHpf2;
extern s32 osRomType;
extern void *osRomBase;
extern s32 osTvType;
extern s32 osResetType;
extern s32 osCicId;
extern s32 osVersion;
extern u32 osMemSize;
extern s32 osAppNMIBuffer[];
extern OSIntMask __OSGlobalIntMask;
extern OSPiHandle *__osPiTable;
extern OSPiHandle *__osDiskHandle;
extern void osCreateThread(OSThread *, OSId, void (*)(void *),
           void *, void *, OSPri);
extern void osDestroyThread(OSThread *);
extern void osYieldThread(void);
extern void osStartThread(OSThread *);
extern void osStopThread(OSThread *);
extern OSId osGetThreadId(OSThread *);
extern void osSetThreadPri(OSThread *, OSPri);
extern OSPri osGetThreadPri(OSThread *);
extern void osCreateMesgQueue(OSMesgQueue *, OSMesg *, s32);
extern s32 osSendMesg(OSMesgQueue *, OSMesg, s32);
extern s32 osJamMesg(OSMesgQueue *, OSMesg, s32);
extern s32 osRecvMesg(OSMesgQueue *, OSMesg *, s32);
extern void osSetEventMesg(OSEvent, OSMesgQueue *, OSMesg);
extern OSIntMask osGetIntMask(void);
extern OSIntMask osSetIntMask(OSIntMask);
extern void osInitRdb(u8 *sendBuf, u32 sendSize);
extern void osInvalDCache(void *, s32);
extern void osInvalICache(void *, s32);
extern void osWritebackDCache(void *, s32);
extern void osWritebackDCacheAll(void);
extern void osMapTLB(s32, OSPageMask, void *, u32, u32, s32);
extern void osMapTLBRdb(void);
extern void osUnmapTLB(s32);
extern void osUnmapTLBAll(void);
extern void osSetTLBASID(s32);
extern u32 osVirtualToPhysical(void *);
extern void * osPhysicalToVirtual(u32);
extern u32 osAiGetStatus(void);
extern u32 osAiGetLength(void);
extern s32 osAiSetFrequency(u32);
extern s32 osAiSetNextBuffer(void *, u32);
extern u32 osDpGetStatus(void);
extern void osDpSetStatus(u32);
extern void osDpGetCounters(u32 *);
extern s32 osDpSetNextBuffer(void *, u64);
extern u32 osPiGetStatus(void);
extern s32 osPiGetDeviceType(void);
extern s32 osPiRawWriteIo(u32, u32);
extern s32 osPiRawReadIo(u32, u32 *);
extern s32 osPiRawStartDma(s32, u32, void *, u32);
extern s32 osPiWriteIo(u32, u32);
extern s32 osPiReadIo(u32, u32 *);
extern s32 osPiStartDma(OSIoMesg *, s32, s32, u32, void *, u32,
         OSMesgQueue *);
extern void osCreatePiManager(OSPri, OSMesgQueue *, OSMesg *, s32);
extern u32 osViGetStatus(void);
extern u32 osViGetCurrentMode(void);
extern u32 osViGetCurrentLine(void);
extern u32 osViGetCurrentField(void);
extern void *osViGetCurrentFramebuffer(void);
extern void *osViGetNextFramebuffer(void);
extern void osViSetXScale(f32);
extern void osViSetYScale(f32);
extern void osViSetSpecialFeatures(u32);
extern void osViSetMode(OSViMode *);
extern void osViSetEvent(OSMesgQueue *, OSMesg, u32);
extern void osViSwapBuffer(void *);
extern void osViBlack(u8);
extern void osViFade(u8, u16);
extern void osViRepeatLine(u8);
extern void osCreateViManager(OSPri);
extern OSTime osGetTime(void);
extern void osSetTime(OSTime);
extern int osSetTimer(OSTimer *, OSTime, OSTime,
       OSMesgQueue *, OSMesg);
extern int osStopTimer(OSTimer *);
extern s32 osContInit(OSMesgQueue *, u8 *, OSContStatus *);
extern s32 osContReset(OSMesgQueue *, OSContStatus *);
extern s32 osContStartQuery(OSMesgQueue *);
extern s32 osContStartReadData(OSMesgQueue *);
extern s32 osContSetCh(u8);
extern void osContGetQuery(OSContStatus *);
extern void osContGetReadData(OSContPad *);
extern s32 osPfsInitPak(OSMesgQueue *, OSPfs *, int);
extern s32 osPfsRepairId(OSPfs *);
extern s32 osPfsInit(OSMesgQueue *, OSPfs *, int);
extern s32 osPfsReFormat(OSPfs *, OSMesgQueue *, int);
extern s32 osPfsChecker(OSPfs *);
extern s32 osPfsAllocateFile(OSPfs *, u16, u32, u8 *, u8 *, int, s32 *);
extern s32 osPfsFindFile(OSPfs *, u16, u32, u8 *, u8 *, s32 *);
extern s32 osPfsDeleteFile(OSPfs *, u16, u32, u8 *, u8 *);
extern s32 osPfsReadWriteFile(OSPfs *, s32, u8, int, int, u8 *);
extern s32 osPfsFileState(OSPfs *, s32, OSPfsState *);
extern s32 osPfsGetLabel(OSPfs *, u8 *, int *);
extern s32 osPfsSetLabel(OSPfs *, u8 *);
extern s32 osPfsIsPlug(OSMesgQueue *, u8 *);
extern s32 osPfsFreeBlocks(OSPfs *, s32 *);
extern s32 osPfsNumFiles(OSPfs *, s32 *, s32 *);
extern s32 osEepromProbe(OSMesgQueue *);
extern s32 osEepromRead(OSMesgQueue *, u8, u8 *);
extern s32 osEepromWrite(OSMesgQueue *, u8, u8 *);
extern s32 osEepromLongRead(OSMesgQueue *, u8, u8 *, int);
extern s32 osEepromLongWrite(OSMesgQueue *, u8, u8 *, int);
extern s32 osMotorInit(OSMesgQueue *, OSPfs *, int);
extern s32 osMotorStop(OSPfs *);
extern s32 osMotorStart(OSPfs *);
extern OSPiHandle *osCartRomInit(void);
extern OSPiHandle *osLeoDiskInit(void);
extern OSPiHandle *osDriveRomInit(void);
extern s32 osEPiDeviceType(OSPiHandle *, OSPiInfo *);
extern s32 osEPiRawWriteIo(OSPiHandle *, u32 , u32);
extern s32 osEPiRawReadIo(OSPiHandle *, u32 , u32 *);
extern s32 osEPiRawStartDma(OSPiHandle *, s32 , u32 , void *, u32 );
extern s32 osEPiWriteIo(OSPiHandle *, u32 , u32 );
extern s32 osEPiReadIo(OSPiHandle *, u32 , u32 *);
extern s32 osEPiStartDma(OSPiHandle *, OSIoMesg *, s32);
extern s32 osEPiLinkHandle(OSPiHandle *);
extern void osProfileInit(OSProf *, u32 profcnt);
extern void osProfileStart(u32);
extern void osProfileFlush(void);
extern void osProfileStop(void);
extern s32 osTestHost(void);
extern void osReadHost(void *, u32);
extern void osWriteHost(void *, u32);
extern void osAckRamromRead(void);
extern void osAckRamromWrite(void);
extern void bcopy(const void *, void *, int);
extern int bcmp(const void *, const void *, int);
extern void bzero(void *, int);
extern void __osInitialize_common(void);
extern u32 osGetCount(void);
extern void osExit(void);
extern u32 osGetMemSize(void);
extern int sprintf(char *s, const char *fmt, ...);
extern void osSyncPrintf(const char *fmt, ...);
extern void osAsyncPrintf(const char *fmt, ...);
extern int osSyncGetChars(char *buf);
extern int osAsyncGetChars(char *buf);
typedef struct _Region_s {
 u8 *r_startBufferAddress;
 u8 *r_endAddress;
 s32 r_bufferSize;
 s32 r_bufferCount;
 u16 r_freeList;
 u16 r_alignSize;
} OSRegion;
extern void *osCreateRegion(void *, u32, u32, u32);
extern void *osMalloc(void *);
extern void osFree(void *, void *);
extern s32 osGetRegionBufCount(void *);
extern s32 osGetRegionBufSize(void *);
extern void rmonMain( void * );
extern void rmonPrintf( const char *, ... );
typedef struct {
 u32 type;
 u32 flags;
 u64 *ucode_boot;
 u32 ucode_boot_size;
 u64 *ucode;
 u32 ucode_size;
 u64 *ucode_data;
 u32 ucode_data_size;
 u64 *dram_stack;
 u32 dram_stack_size;
 u64 *output_buff;
 u64 *output_buff_size;
 u64 *data_ptr;
 u32 data_size;
 u64 *yield_data_ptr;
 u32 yield_data_size;
} OSTask_t;
typedef union {
    OSTask_t t;
    long long int force_structure_alignment;
} OSTask;
typedef u32 OSYieldResult;
extern void osSpTaskLoad(OSTask *tp);
extern void osSpTaskStartGo(OSTask *tp);
extern void osSpTaskYield(void);
extern OSYieldResult osSpTaskYielded(OSTask *tp);
typedef struct {
 short ob[3];
 unsigned short flag;
 short tc[2];
 unsigned char cn[4];
} Vtx_t;
typedef struct {
 short ob[3];
 unsigned short flag;
 short tc[2];
 signed char n[3];
 unsigned char a;
} Vtx_tn;
typedef union {
    Vtx_t v;
    Vtx_tn n;
    long long int force_structure_alignment;
} Vtx;
typedef struct {
  void *SourceImagePointer;
  void *TlutPointer;
  short Stride;
  short SubImageWidth;
  short SubImageHeight;
  char SourceImageType;
  char SourceImageBitSize;
  short SourceImageOffsetS;
  short SourceImageOffsetT;
  char dummy[4];
} uSprite_t;
typedef union {
  uSprite_t s;
  long long int force_structure_allignment[3];
} uSprite;
typedef struct {
 unsigned char flag;
 unsigned char v[3];
} Tri;
typedef long Mtx_t[4][4];
typedef union {
    Mtx_t m;
    long long int force_structure_alignment;
} Mtx;
typedef struct {
 short vscale[4];
 short vtrans[4];
} Vp_t;
typedef union {
    Vp_t vp;
    long long int force_structure_alignment;
} Vp;
typedef struct {
  unsigned char col[3];
  char pad1;
  unsigned char colc[3];
  char pad2;
  signed char dir[3];
  char pad3;
} Light_t;
typedef struct {
  unsigned char col[3];
  char pad1;
  unsigned char colc[3];
  char pad2;
} Ambient_t;
typedef struct {
  int x1,y1,x2,y2;
} Hilite_t;
typedef union {
    Light_t l;
    long long int force_structure_alignment[2];
} Light;
typedef union {
    Ambient_t l;
    long long int force_structure_alignment[1];
} Ambient;
typedef struct {
    Ambient a;
    Light l[7];
} Lightsn;
typedef struct {
    Ambient a;
    Light l[1];
} Lights0;
typedef struct {
    Ambient a;
    Light l[1];
} Lights1;
typedef struct {
    Ambient a;
    Light l[2];
} Lights2;
typedef struct {
    Ambient a;
    Light l[3];
} Lights3;
typedef struct {
    Ambient a;
    Light l[4];
} Lights4;
typedef struct {
    Ambient a;
    Light l[5];
} Lights5;
typedef struct {
    Ambient a;
    Light l[6];
} Lights6;
typedef struct {
    Ambient a;
    Light l[7];
} Lights7;
typedef struct {
    Light l[2];
} LookAt;
typedef union {
    Hilite_t h;
    long int force_structure_alignment[4];
} Hilite;
typedef struct {
 int cmd:8;
 unsigned int par:8;
 unsigned int len:16;
 unsigned int addr;
} Gdma;
typedef struct {
  int cmd:8;
  int pad:24;
  Tri tri;
} Gtri;
typedef struct {
  int cmd:8;
  int pad1:24;
  int pad2:24;
  unsigned char param:8;
} Gpopmtx;
typedef struct {
  int cmd:8;
  int pad0:8;
  int mw_index:8;
  int number:8;
  int pad1:8;
  int base:24;
} Gsegment;
typedef struct {
  int cmd:8;
  int pad0:8;
  int sft:8;
  int len:8;
  unsigned int data:32;
} GsetothermodeL;
typedef struct {
  int cmd:8;
  int pad0:8;
  int sft:8;
  int len:8;
  unsigned int data:32;
} GsetothermodeH;
typedef struct {
  unsigned char cmd;
  unsigned char lodscale;
  unsigned char tile;
  unsigned char on;
  unsigned short s;
  unsigned short t;
} Gtexture;
typedef struct {
  int cmd:8;
  int pad:24;
  Tri line;
} Gline3D;
typedef struct {
  int cmd:8;
  int pad1:24;
  short int pad2;
  short int scale;
} Gperspnorm;
typedef struct {
                int cmd:8;
                unsigned int fmt:3;
                unsigned int siz:2;
                unsigned int pad:7;
                unsigned int wd:12;
                unsigned int dram;
} Gsetimg;
typedef struct {
  int cmd:8;
  unsigned int muxs0:24;
  unsigned int muxs1:32;
} Gsetcombine;
typedef struct {
  int cmd:8;
  unsigned char pad;
  unsigned char prim_min_level;
  unsigned char prim_level;
  unsigned long color;
} Gsetcolor;
typedef struct {
  int cmd:8;
  int x0:10;
  int x0frac:2;
  int y0:10;
  int y0frac:2;
  unsigned int pad:8;
  int x1:10;
  int x1frac:2;
  int y1:10;
  int y1frac:2;
} Gfillrect;
typedef struct {
  int cmd:8;
  unsigned int fmt:3;
  unsigned int siz:2;
  unsigned int pad0:1;
  unsigned int line:9;
  unsigned int tmem:9;
  unsigned int pad1:5;
  unsigned int tile:3;
  unsigned int palette:4;
  unsigned int ct:1;
  unsigned int mt:1;
  unsigned int maskt:4;
  unsigned int shiftt:4;
  unsigned int cs:1;
  unsigned int ms:1;
  unsigned int masks:4;
  unsigned int shifts:4;
} Gsettile;
typedef struct {
  int cmd:8;
  unsigned int sl:12;
  unsigned int tl:12;
  int pad:5;
  unsigned int tile:3;
  unsigned int sh:12;
  unsigned int th:12;
} Gloadtile;
typedef Gloadtile Gloadblock;
typedef Gloadtile Gsettilesize;
typedef Gloadtile Gloadtlut;
typedef struct {
  unsigned int cmd:8;
  unsigned int xl:12;
  unsigned int yl:12;
  unsigned int pad1:5;
  unsigned int tile:3;
  unsigned int xh:12;
  unsigned int yh:12;
  unsigned int s:16;
  unsigned int t:16;
  unsigned int dsdx:16;
  unsigned int dtdy:16;
} Gtexrect;
typedef struct {
    unsigned long w0;
    unsigned long w1;
    unsigned long w2;
    unsigned long w3;
} TexRect;
typedef struct {
 unsigned int w0;
 unsigned int w1;
} Gwords;
typedef union {
 Gwords words;
 Gdma dma;
 Gtri tri;
 Gline3D line;
 Gpopmtx popmtx;
 Gsegment segment;
 GsetothermodeH setothermodeH;
 GsetothermodeL setothermodeL;
 Gtexture texture;
 Gperspnorm perspnorm;
 Gsetimg setimg;
 Gsetcombine setcombine;
 Gsetcolor setcolor;
 Gfillrect fillrect;
 Gsettile settile;
 Gloadtile loadtile;
 Gsettilesize settilesize;
 Gloadtlut loadtlut;
        long long int force_structure_alignment;
} Gfx;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int gain:16;
 unsigned int addr;
} Aadpcm;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int gain:16;
 unsigned int addr;
} Apolef;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pad1:16;
 unsigned int addr;
} Aenvelope;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:8;
 unsigned int dmem:16;
 unsigned int pad2:16;
 unsigned int count:16;
} Aclearbuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:8;
 unsigned int pad2:16;
 unsigned int inL:16;
        unsigned int inR:16;
} Ainterleave;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:24;
 unsigned int addr;
} Aloadbuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pad1:16;
 unsigned int addr;
} Aenvmixer;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int gain:16;
 unsigned int dmemi:16;
 unsigned int dmemo:16;
} Amixer;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int dmem2:16;
 unsigned int addr;
} Apan;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pitch:16;
 unsigned int addr;
} Aresample;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pad1:16;
 unsigned int addr;
} Areverb;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:24;
 unsigned int addr;
} Asavebuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:24;
 unsigned int pad2:2;
 unsigned int number:4;
 unsigned int base:24;
} Asegment;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int dmemin:16;
 unsigned int dmemout:16;
 unsigned int count:16;
} Asetbuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int vol:16;
 unsigned int voltgt:16;
 unsigned int volrate:16;
} Asetvol;
typedef struct {
    unsigned int cmd:8;
    unsigned int pad1:8;
    unsigned int dmemin:16;
    unsigned int dmemout:16;
    unsigned int count:16;
} Admemmove;
typedef struct {
    unsigned int cmd:8;
    unsigned int pad1:8;
    unsigned int count:16;
    unsigned int addr;
} Aloadadpcm;
typedef struct {
    unsigned int cmd:8;
    unsigned int pad1:8;
    unsigned int pad2:16;
    unsigned int addr;
} Asetloop;
typedef struct {
 unsigned int w0;
 unsigned int w1;
} Awords;
typedef union {
 Awords words;
 Aadpcm adpcm;
        Apolef polef;
 Aclearbuff clearbuff;
 Aenvelope envelope;
        Ainterleave interleave;
 Aloadbuff loadbuff;
        Aenvmixer envmixer;
 Aresample resample;
 Areverb reverb;
 Asavebuff savebuff;
 Asegment segment;
 Asetbuff setbuff;
 Asetvol setvol;
        Admemmove dmemmove;
        Aloadadpcm loadadpcm;
        Amixer mixer;
        Asetloop setloop;
        long long int force_union_align;
} Acmd;
typedef short ADPCM_STATE[16];
typedef short POLEF_STATE[4];
typedef short RESAMPLE_STATE[16];
typedef short ENVMIX_STATE[40];
typedef s32 ALMicroTime;
typedef u8 ALPan;
typedef struct ALLink_s {
    struct ALLink_s *next;
    struct ALLink_s *prev;
} ALLink;
void alUnlink(ALLink *element);
void alLink(ALLink *element, ALLink *after);
typedef s32 (*ALDMAproc)(s32 addr, s32 len, void *state);
typedef ALDMAproc (*ALDMANew)(void *state);
void alCopy(void *src, void *dest, s32 len);
typedef struct {
    u8 *base;
    u8 *cur;
    s32 len;
    s32 count;
} ALHeap;
void alHeapInit(ALHeap *hp, u8 *base, s32 len);
void *alHeapDBAlloc(u8 *file, s32 line, ALHeap *hp, s32 num, s32 size);
s32 alHeapCheck(ALHeap *hp);
typedef u8 ALFxId;
typedef void *ALFxRef;
enum {AL_ADPCM_WAVE = 0,
         AL_RAW16_WAVE};
typedef struct {
    s32 order;
    s32 npredictors;
    s16 book[1];
} ALADPCMBook;
typedef struct {
    u32 start;
    u32 end;
    u32 count;
    ADPCM_STATE state;
} ALADPCMloop;
typedef struct {
    u32 start;
    u32 end;
    u32 count;
} ALRawLoop;
typedef struct {
    ALMicroTime attackTime;
    ALMicroTime decayTime;
    ALMicroTime releaseTime;
    u8 attackVolume;
    u8 decayVolume;
} ALEnvelope;
typedef struct {
    u8 velocityMin;
    u8 velocityMax;
    u8 keyMin;
    u8 keyMax;
    u8 keyBase;
    s8 detune;
} ALKeyMap;
typedef struct {
    ALADPCMloop *loop;
    ALADPCMBook *book;
} ALADPCMWaveInfo;
typedef struct {
    ALRawLoop *loop;
} ALRAWWaveInfo;
typedef struct ALWaveTable_s {
    u8 *base;
    s32 len;
    u8 type;
    u8 flags;
    union {
        ALADPCMWaveInfo adpcmWave;
        ALRAWWaveInfo rawWave;
    } waveInfo;
} ALWaveTable;
typedef struct ALSound_s {
    ALEnvelope *envelope;
    ALKeyMap *keyMap;
    ALWaveTable *wavetable;
    ALPan samplePan;
    u8 sampleVolume;
    u8 flags;
} ALSound;
typedef struct {
    u8 volume;
    ALPan pan;
    u8 priority;
    u8 flags;
    u8 tremType;
    u8 tremRate;
    u8 tremDepth;
    u8 tremDelay;
    u8 vibType;
    u8 vibRate;
    u8 vibDepth;
    u8 vibDelay;
    s16 bendRange;
    s16 soundCount;
    ALSound *soundArray[1];
} ALInstrument;
typedef struct ALBank_s {
    s16 instCount;
    u8 flags;
    u8 pad;
    s32 sampleRate;
    ALInstrument *percussion;
    ALInstrument *instArray[1];
} ALBank;
typedef struct {
    s16 revision;
    s16 bankCount;
    ALBank *bankArray[1];
} ALBankFile;
void alBnkfNew(ALBankFile *f, u8 *table);
typedef struct {
    u8 *offset;
    s32 len;
} ALSeqData;
typedef struct {
    s16 revision;
    s16 seqCount;
    ALSeqData seqArray[1];
} ALSeqFile;
void alSeqFileNew(ALSeqFile *f, u8 *base);
typedef ALMicroTime (*ALVoiceHandler)(void *);
typedef struct {
    s32 maxVVoices;
    s32 maxPVoices;
    s32 maxUpdates;
    s32 maxFXbusses;
    void *dmaproc;
    ALHeap *heap;
    s32 outputRate;
    ALFxId fxType;
    s32 *params;
} ALSynConfig;
typedef struct ALPlayer_s {
    struct ALPlayer_s *next;
    void *clientData;
    ALVoiceHandler handler;
    ALMicroTime callTime;
    s32 samplesLeft;
} ALPlayer;
typedef struct ALVoice_s {
    ALLink node;
    struct PVoice_s *pvoice;
    ALWaveTable *table;
    void *clientPrivate;
    s16 state;
    s16 priority;
    s16 fxBus;
    s16 unityPitch;
} ALVoice;
typedef struct ALVoiceConfig_s {
    s16 priority;
    s16 fxBus;
    u8 unityPitch;
} ALVoiceConfig;
typedef struct {
    ALPlayer *head;
    ALLink pFreeList;
    ALLink pAllocList;
    ALLink pLameList;
    s32 paramSamples;
    s32 curSamples;
    ALDMANew dma;
    ALHeap *heap;
    struct ALParam_s *paramList;
    struct ALMainBus_s *mainBus;
    struct ALAuxBus_s *auxBus;
    struct ALFilter_s *outputFilter;
    s32 numPVoices;
    s32 maxAuxBusses;
    s32 outputRate;
    s32 maxOutSamples;
} ALSynth;
void alSynNew(ALSynth *s, ALSynConfig *config);
void alSynDelete(ALSynth *s);
void alSynAddPlayer(ALSynth *s, ALPlayer *client);
void alSynRemovePlayer(ALSynth *s);
s32 alSynAllocVoice(ALSynth *s, ALVoice *v, ALVoiceConfig *vc);
void alSynFreeVoice(ALSynth *s, ALVoice *voice);
void alSynStartVoice(ALSynth *s, ALVoice *voice, ALWaveTable *w);
void alSynStartVoiceParams(ALSynth *s, ALVoice *voice, ALWaveTable *w,
                              f32 pitch, s16 vol, ALPan pan, u8 fxmix,
                              ALMicroTime t);
void alSynStopVoice(ALSynth *s, ALVoice *voice);
void alSynSetVol(ALSynth *s, ALVoice *v, s16 vol, ALMicroTime delta);
void alSynSetPitch(ALSynth *s, ALVoice *voice, f32 ratio);
void alSynSetPan(ALSynth *s, ALVoice *voice, ALPan pan);
void alSynSetFXMix(ALSynth *s, ALVoice *voice, u8 fxmix);
void alSynSetPriority(ALSynth *s, ALVoice *voice, s16 priority);
s16 alSynGetPriority(ALSynth *s, ALVoice *voice);
ALFxRef *alSynAllocFX(ALSynth *s, s16 bus, ALSynConfig *c, ALHeap *hp);
ALFxRef alSynGetFXRef(ALSynth *s, s16 bus, s16 index);
void alSynFreeFX(ALSynth *s, ALFxRef *fx);
void alSynSetFXParam(ALSynth *s, ALFxRef fx, s16 paramID, void *param);
typedef struct {
    ALSynth drvr;
} ALGlobals;
extern ALGlobals *alGlobals;
void alInit(ALGlobals *glob, ALSynConfig *c);
void alClose(ALGlobals *glob);
Acmd *alAudioFrame(Acmd *cmdList, s32 *cmdLen, s16 *outBuf, s32 outLen);
enum ALMsg {
    AL_SEQ_REF_EVT,
    AL_SEQ_MIDI_EVT,
    AL_SEQP_MIDI_EVT,
    AL_TEMPO_EVT,
    AL_SEQ_END_EVT,
    AL_NOTE_END_EVT,
    AL_SEQP_ENV_EVT,
    AL_SEQP_META_EVT,
    AL_SEQP_PROG_EVT,
    AL_SEQP_API_EVT,
    AL_SEQP_VOL_EVT,
    AL_SEQP_LOOP_EVT,
    AL_SEQP_PRIORITY_EVT,
    AL_SEQP_SEQ_EVT,
    AL_SEQP_BANK_EVT,
    AL_SEQP_PLAY_EVT,
    AL_SEQP_STOP_EVT,
    AL_SEQP_STOPPING_EVT,
    AL_TRACK_END,
    AL_CSP_LOOPSTART,
    AL_CSP_LOOPEND,
    AL_CSP_NOTEOFF_EVT,
    AL_TREM_OSC_EVT,
    AL_VIB_OSC_EVT
};
enum AL_MIDIstatus {
    AL_MIDI_ChannelMask = 0x0F,
    AL_MIDI_StatusMask = 0xF0,
    AL_MIDI_ChannelVoice = 0x80,
    AL_MIDI_NoteOff = 0x80,
    AL_MIDI_NoteOn = 0x90,
    AL_MIDI_PolyKeyPressure = 0xA0,
    AL_MIDI_ControlChange = 0xB0,
    AL_MIDI_ChannelModeSelect = 0xB0,
    AL_MIDI_ProgramChange = 0xC0,
    AL_MIDI_ChannelPressure = 0xD0,
    AL_MIDI_PitchBendChange = 0xE0,
    AL_MIDI_SysEx = 0xF0,
    AL_MIDI_SystemCommon = 0xF1,
    AL_MIDI_TimeCodeQuarterFrame = 0xF1,
    AL_MIDI_SongPositionPointer = 0xF2,
    AL_MIDI_SongSelect = 0xF3,
    AL_MIDI_Undefined1 = 0xF4,
    AL_MIDI_Undefined2 = 0xF5,
    AL_MIDI_TuneRequest = 0xF6,
    AL_MIDI_EOX = 0xF7,
    AL_MIDI_SystemRealTime = 0xF8,
    AL_MIDI_TimingClock = 0xF8,
    AL_MIDI_Undefined3 = 0xF9,
    AL_MIDI_Start = 0xFA,
    AL_MIDI_Continue = 0xFB,
    AL_MIDI_Stop = 0xFC,
    AL_MIDI_Undefined4 = 0xFD,
    AL_MIDI_ActiveSensing = 0xFE,
    AL_MIDI_SystemReset = 0xFF,
    AL_MIDI_Meta = 0xFF
};
enum AL_MIDIctrl {
    AL_MIDI_VOLUME_CTRL = 0x07,
    AL_MIDI_PAN_CTRL = 0x0A,
    AL_MIDI_PRIORITY_CTRL = 0x10,
    AL_MIDI_FX_CTRL_0 = 0x14,
    AL_MIDI_FX_CTRL_1 = 0x15,
    AL_MIDI_FX_CTRL_2 = 0x16,
    AL_MIDI_FX_CTRL_3 = 0x17,
    AL_MIDI_FX_CTRL_4 = 0x18,
    AL_MIDI_FX_CTRL_5 = 0x19,
    AL_MIDI_FX_CTRL_6 = 0x1A,
    AL_MIDI_FX_CTRL_7 = 0x1B,
    AL_MIDI_FX_CTRL_8 = 0x1C,
    AL_MIDI_FX_CTRL_9 = 0x1D,
    AL_MIDI_SUSTAIN_CTRL = 0x40,
    AL_MIDI_FX1_CTRL = 0x5B,
    AL_MIDI_FX3_CTRL = 0x5D
};
enum AL_MIDImeta {
    AL_MIDI_META_TEMPO = 0x51,
    AL_MIDI_META_EOT = 0x2f
};
typedef struct {
    u8 *curPtr;
    s32 lastTicks;
    s32 curTicks;
    s16 lastStatus;
} ALSeqMarker;
typedef struct {
    s32 ticks;
    u8 status;
    u8 byte1;
    u8 byte2;
    u32 duration;
} ALMIDIEvent;
typedef struct {
    s32 ticks;
    u8 status;
    u8 type;
    u8 len;
    u8 byte1;
    u8 byte2;
    u8 byte3;
} ALTempoEvent;
typedef struct {
    s32 ticks;
    u8 status;
    u8 type;
    u8 len;
} ALEndEvent;
typedef struct {
    struct ALVoice_s *voice;
} ALNoteEvent;
typedef struct {
    struct ALVoice_s *voice;
    ALMicroTime delta;
    u8 vol;
} ALVolumeEvent;
typedef struct {
    s16 vol;
} ALSeqpVolEvent;
typedef struct {
    ALSeqMarker *start;
    ALSeqMarker *end;
    s32 count;
} ALSeqpLoopEvent;
typedef struct {
    u8 chan;
    u8 priority;
} ALSeqpPriorityEvent;
typedef struct {
    void *seq;
} ALSeqpSeqEvent;
typedef struct {
    ALBank *bank;
} ALSeqpBankEvent;
typedef struct {
    struct ALVoiceState_s *vs;
    void *oscState;
    u8 chan;
} ALOscEvent;
typedef struct {
    s16 type;
    union {
        ALMIDIEvent midi;
        ALTempoEvent tempo;
        ALEndEvent end;
        ALNoteEvent note;
        ALVolumeEvent vol;
        ALSeqpLoopEvent loop;
        ALSeqpVolEvent spvol;
 ALSeqpPriorityEvent sppriority;
 ALSeqpSeqEvent spseq;
 ALSeqpBankEvent spbank;
        ALOscEvent osc;
    } msg;
} ALEvent;
typedef struct {
    ALLink node;
    ALMicroTime delta;
    ALEvent evt;
} ALEventListItem;
typedef struct {
    ALLink freeList;
    ALLink allocList;
    s32 eventCount;
} ALEventQueue;
void alEvtqNew(ALEventQueue *evtq, ALEventListItem *items,
                          s32 itemCount);
ALMicroTime alEvtqNextEvent(ALEventQueue *evtq, ALEvent *evt);
void alEvtqPostEvent(ALEventQueue *evtq, ALEvent *evt,
                                ALMicroTime delta);
void alEvtqFlush(ALEventQueue *evtq);
void alEvtqFlushType(ALEventQueue *evtq, s16 type);
typedef struct ALVoiceState_s {
    struct ALVoiceState_s *next;
    ALVoice voice;
    ALSound *sound;
    ALMicroTime envEndTime;
    f32 pitch;
    f32 vibrato;
    u8 envGain;
    u8 channel;
    u8 key;
    u8 velocity;
    u8 envPhase;
    u8 phase;
    u8 tremelo;
    u8 flags;
} ALVoiceState;
typedef struct {
    ALInstrument *instrument;
    s16 bendRange;
    ALFxId fxId;
    ALPan pan;
    u8 priority;
    u8 vol;
    u8 fxmix;
    u8 sustain;
    f32 pitchBend;
} ALChanState;
typedef struct ALSeq_s {
    u8 *base;
    u8 *trackStart;
    u8 *curPtr;
    s32 lastTicks;
    s32 len;
    f32 qnpt;
    s16 division;
    s16 lastStatus;
} ALSeq;
typedef struct {
    u32 trackOffset[16];
    u32 division;
} ALCMidiHdr;
typedef struct ALCSeq_s {
    ALCMidiHdr *base;
    u32 validTracks;
    f32 qnpt;
    u32 lastTicks;
    u32 lastDeltaTicks;
    u32 deltaFlag;
    u8 *curLoc[16];
    u8 *curBUPtr[16];
    u8 curBULen[16];
    u8 lastStatus[16];
    u32 evtDeltaTicks[16];
} ALCSeq;
typedef struct {
    u32 validTracks;
    s32 lastTicks;
    u32 lastDeltaTicks;
    u8 *curLoc[16];
    u8 *curBUPtr[16];
    u8 curBULen[16];
    u8 lastStatus[16];
    u32 evtDeltaTicks[16];
} ALCSeqMarker;
typedef struct {
    s32 maxVoices;
    s32 maxEvents;
    u8 maxChannels;
    u8 debugFlags;
    ALHeap *heap;
    void *initOsc;
    void *updateOsc;
    void *stopOsc;
} ALSeqpConfig;
typedef ALMicroTime (*ALOscInit)(void **oscState,f32 *initVal, u8 oscType,
                                   u8 oscRate, u8 oscDepth, u8 oscDelay);
typedef ALMicroTime (*ALOscUpdate)(void *oscState, f32 *updateVal);
typedef void (*ALOscStop)(void *oscState);
typedef struct {
    ALPlayer node;
    ALSynth *drvr;
    ALSeq *target;
    ALMicroTime curTime;
    ALBank *bank;
    s32 uspt;
    s32 nextDelta;
    s32 state;
    u16 chanMask;
    s16 vol;
    u8 maxChannels;
    u8 debugFlags;
    ALEvent nextEvent;
    ALEventQueue evtq;
    ALMicroTime frameTime;
    ALChanState *chanState;
    ALVoiceState *vAllocHead;
    ALVoiceState *vAllocTail;
    ALVoiceState *vFreeList;
    ALOscInit initOsc;
    ALOscUpdate updateOsc;
    ALOscStop stopOsc;
    ALSeqMarker *loopStart;
    ALSeqMarker *loopEnd;
    s32 loopCount;
} ALSeqPlayer;
typedef struct {
    ALPlayer node;
    ALSynth *drvr;
    ALCSeq *target;
    ALMicroTime curTime;
    ALBank *bank;
    s32 uspt;
    s32 nextDelta;
    s32 state;
    u16 chanMask;
    s16 vol;
    u8 maxChannels;
    u8 debugFlags;
    ALEvent nextEvent;
    ALEventQueue evtq;
    ALMicroTime frameTime;
    ALChanState *chanState;
    ALVoiceState *vAllocHead;
    ALVoiceState *vAllocTail;
    ALVoiceState *vFreeList;
    ALOscInit initOsc;
    ALOscUpdate updateOsc;
    ALOscStop stopOsc;
} ALCSPlayer;
void alSeqNew(ALSeq *seq, u8 *ptr, s32 len);
void alSeqNextEvent(ALSeq *seq, ALEvent *event);
s32 alSeqGetTicks(ALSeq *seq);
f32 alSeqTicksToSec(ALSeq *seq, s32 ticks, u32 tempo);
u32 alSeqSecToTicks(ALSeq *seq, f32 sec, u32 tempo);
void alSeqNewMarker(ALSeq *seq, ALSeqMarker *m, u32 ticks);
void alSeqSetLoc(ALSeq *seq, ALSeqMarker *marker);
void alSeqGetLoc(ALSeq *seq, ALSeqMarker *marker);
void alCSeqNew(ALCSeq *seq, u8 *ptr);
void alCSeqNextEvent(ALCSeq *seq,ALEvent *evt);
s32 alCSeqGetTicks(ALCSeq *seq);
f32 alCSeqTicksToSec(ALCSeq *seq, s32 ticks, u32 tempo);
u32 alCSeqSecToTicks(ALCSeq *seq, f32 sec, u32 tempo);
void alCSeqNewMarker(ALCSeq *seq, ALCSeqMarker *m, u32 ticks);
void alCSeqSetLoc(ALCSeq *seq, ALCSeqMarker *marker);
void alCSeqGetLoc(ALCSeq *seq, ALCSeqMarker *marker);
f32 alCents2Ratio(s32 cents);
void alSeqpNew(ALSeqPlayer *seqp, ALSeqpConfig *config);
void alSeqpDelete(ALSeqPlayer *seqp);
void alSeqpSetSeq(ALSeqPlayer *seqp, ALSeq *seq);
ALSeq *alSeqpGetSeq(ALSeqPlayer *seqp);
void alSeqpPlay(ALSeqPlayer *seqp);
void alSeqpStop(ALSeqPlayer *seqp);
s32 alSeqpGetState(ALSeqPlayer *seqp);
void alSeqpSetBank(ALSeqPlayer *seqp, ALBank *b);
void alSeqpSetTempo(ALSeqPlayer *seqp, s32 tempo);
s32 alSeqpGetTempo(ALSeqPlayer *seqp);
s16 alSeqpGetVol(ALSeqPlayer *seqp);
void alSeqpSetVol(ALSeqPlayer *seqp, s16 vol);
void alSeqpLoop(ALSeqPlayer *seqp, ALSeqMarker *start, ALSeqMarker *end, s32 count);
void alSeqpSetChlProgram(ALSeqPlayer *seqp, u8 chan, u8 prog);
s32 alSeqpGetChlProgram(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlFXMix(ALSeqPlayer *seqp, u8 chan, u8 fxmix);
u8 alSeqpGetChlFXMix(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlVol(ALSeqPlayer *seqp, u8 chan, u8 vol);
u8 alSeqpGetChlVol(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlPan(ALSeqPlayer *seqp, u8 chan, ALPan pan);
ALPan alSeqpGetChlPan(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlPriority(ALSeqPlayer *seqp, u8 chan, u8 priority);
u8 alSeqpGetChlPriority(ALSeqPlayer *seqp, u8 chan);
void alSeqpSendMidi(ALSeqPlayer *seqp, s32 ticks, u8 status, u8 byte1, u8 byte2);
void alCSPNew(ALCSPlayer *seqp, ALSeqpConfig *config);
void alCSPDelete(ALCSPlayer *seqp);
void alCSPSetSeq(ALCSPlayer *seqp, ALCSeq *seq);
ALCSeq *alCSPGetSeq(ALCSPlayer *seqp);
void alCSPPlay(ALCSPlayer *seqp);
void alCSPStop(ALCSPlayer *seqp);
s32 alCSPGetState(ALCSPlayer *seqp);
void alCSPSetBank(ALCSPlayer *seqp, ALBank *b);
void alCSPSetTempo(ALCSPlayer *seqp, s32 tempo);
s32 alCSPGetTempo(ALCSPlayer *seqp);
s16 alCSPGetVol(ALCSPlayer *seqp);
void alCSPSetVol(ALCSPlayer *seqp, s16 vol);
void alCSPSetChlProgram(ALCSPlayer *seqp, u8 chan, u8 prog);
s32 alCSPGetChlProgram(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlFXMix(ALCSPlayer *seqp, u8 chan, u8 fxmix);
u8 alCSPGetChlFXMix(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlPan(ALCSPlayer *seqp, u8 chan, ALPan pan);
ALPan alCSPGetChlPan(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlVol(ALCSPlayer *seqp, u8 chan, u8 vol);
u8 alCSPGetChlVol(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlPriority(ALCSPlayer *seqp, u8 chan, u8 priority);
u8 alCSPGetChlPriority(ALCSPlayer *seqp, u8 chan);
void alCSPSendMidi(ALCSPlayer *seqp, s32 ticks, u8 status,
                       u8 byte1, u8 byte2);
typedef struct {
    s32 maxSounds;
    s32 maxEvents;
    ALHeap *heap;
} ALSndpConfig;
typedef struct {
    ALPlayer node;
    ALEventQueue evtq;
    ALEvent nextEvent;
    ALSynth *drvr;
    s32 target;
    void *sndState;
    s32 maxSounds;
    ALMicroTime frameTime;
    ALMicroTime nextDelta;
    ALMicroTime curTime;
} ALSndPlayer;
typedef s16 ALSndId;
void alSndpNew(ALSndPlayer *sndp, ALSndpConfig *c);
void alSndpDelete(ALSndPlayer *sndp);
ALSndId alSndpAllocate(ALSound *sound);
void alSndpDeallocate(ALSndId id);
void alSndpSetSound(ALSndPlayer *sndp, ALSndId id);
ALSndId alSndpGetSound(ALSndPlayer *sndp);
void alSndpPlay(ALSndPlayer *sndp);
void alSndpPlayAt(ALSndPlayer *sndp, ALMicroTime delta);
void alSndpStop(ALSndPlayer *sndp);
void alSndpSetVol(ALSndPlayer *sndp, s16 vol);
void alSndpSetPitch(ALSndPlayer *sndp, f32 pitch);
void alSndpSetPan(ALSndPlayer *sndp, ALPan pan);
void alSndpSetPriority(ALSndPlayer *sndp, ALSndId id, u8 priority);
void alSndpSetFXMix(ALSndPlayer *sndp, u8 mix);
s32 alSndpGetState(ALSndPlayer *sndp);
void alParseAbiCL(Acmd *cmdList, u32 nbytes);
typedef struct {
 unsigned char *base;
 int fmt, siz;
 int xsize, ysize;
 int lsize;
 int addr;
 int w, h;
 int s, t;
} Image;
typedef struct {
 float col[3];
 float pos[3];
 float a1, a2;
} PositionalLight;
extern int guLoadTextureBlockMipMap(Gfx **glist, unsigned char *tbuf, Image *im,
  unsigned char startTile, unsigned char pal, unsigned char cms,
  unsigned char cmt, unsigned char masks, unsigned char maskt,
  unsigned char shifts, unsigned char shiftt, unsigned char cfs,
  unsigned char cft);
extern int guGetDPLoadTextureTileSz (int ult, int lrt);
extern void guDPLoadTextureTile (Gfx *glistp, void *timg,
   int texl_fmt, int texl_size,
   int img_width, int img_height,
   int uls, int ult, int lrs, int lrt,
   int palette,
   int cms, int cmt,
   int masks, int maskt,
   int shifts, int shiftt);
extern void guMtxIdent(Mtx *m);
extern void guMtxIdentF(float mf[4][4]);
extern void guOrtho(Mtx *m, float l, float r, float b, float t,
      float n, float f, float scale);
extern void guOrthoF(float mf[4][4], float l, float r, float b, float t,
       float n, float f, float scale);
extern void guFrustum(Mtx *m, float l, float r, float b, float t,
        float n, float f, float scale);
extern void guFrustumF(float mf[4][4], float l, float r, float b, float t,
         float n, float f, float scale);
extern void guPerspective(Mtx *m, u16 *perspNorm, float fovy,
     float aspect, float near, float far, float scale);
extern void guPerspectiveF(float mf[4][4], u16 *perspNorm, float fovy,
      float aspect, float near, float far, float scale);
extern void guLookAt(Mtx *m,
   float xEye, float yEye, float zEye,
   float xAt, float yAt, float zAt,
   float xUp, float yUp, float zUp);
extern void guLookAtF(float mf[4][4], float xEye, float yEye, float zEye,
        float xAt, float yAt, float zAt,
        float xUp, float yUp, float zUp);
extern void guLookAtReflect(Mtx *m, LookAt *l,
   float xEye, float yEye, float zEye,
   float xAt, float yAt, float zAt,
   float xUp, float yUp, float zUp);
extern void guLookAtReflectF(float mf[4][4], LookAt *l,
        float xEye, float yEye, float zEye,
        float xAt, float yAt, float zAt,
        float xUp, float yUp, float zUp);
extern void guLookAtHilite(Mtx *m, LookAt *l, Hilite *h,
                float xEye, float yEye, float zEye,
                float xAt, float yAt, float zAt,
                float xUp, float yUp, float zUp,
                float xl1, float yl1, float zl1,
                float xl2, float yl2, float zl2,
  int twidth, int theight);
extern void guLookAtHiliteF(float mf[4][4], LookAt *l, Hilite *h,
  float xEye, float yEye, float zEye,
  float xAt, float yAt, float zAt,
  float xUp, float yUp, float zUp,
  float xl1, float yl1, float zl1,
  float xl2, float yl2, float zl2,
  int twidth, int theight);
extern void guLookAtStereo(Mtx *m,
   float xEye, float yEye, float zEye,
   float xAt, float yAt, float zAt,
   float xUp, float yUp, float zUp,
   float eyedist);
extern void guLookAtStereoF(float mf[4][4],
         float xEye, float yEye, float zEye,
         float xAt, float yAt, float zAt,
         float xUp, float yUp, float zUp,
   float eyedist);
extern void guRotate(Mtx *m, float a, float x, float y, float z);
extern void guRotateF(float mf[4][4], float a, float x, float y, float z);
extern void guRotateRPY(Mtx *m, float r, float p, float y);
extern void guRotateRPYF(float mf[4][4], float r, float p, float h);
extern void guAlign(Mtx *m, float a, float x, float y, float z);
extern void guAlignF(float mf[4][4], float a, float x, float y, float z);
extern void guScale(Mtx *m, float x, float y, float z);
extern void guScaleF(float mf[4][4], float x, float y, float z);
extern void guTranslate(Mtx *m, float x, float y, float z);
extern void guTranslateF(float mf[4][4], float x, float y, float z);
extern void guPosition(Mtx *m, float r, float p, float h, float s,
         float x, float y, float z);
extern void guPositionF(float mf[4][4], float r, float p, float h, float s,
   float x, float y, float z);
extern void guMtxF2L(float mf[4][4], Mtx *m);
extern void guMtxL2F(float mf[4][4], Mtx *m);
extern void guMtxCatF(float m[4][4], float n[4][4], float r[4][4]);
extern void guMtxCatL(Mtx *m, Mtx *n, Mtx *res);
extern void guMtxXFMF(float mf[4][4], float x, float y, float z,
        float *ox, float *oy, float *oz);
extern void guMtxXFML(Mtx *m, float x, float y, float z,
        float *ox, float *oy, float *oz);
extern void guNormalize(float *x, float *y, float *z);
void guPosLight(PositionalLight *pl, Light *l,
                float xOb, float yOb, float zOb);
void guPosLightHilite(PositionalLight *pl1, PositionalLight *pl2,
                Light *l1, Light *l2,
                LookAt *l, Hilite *h,
                float xEye, float yEye, float zEye,
                float xOb, float yOb, float zOb,
                float xUp, float yUp, float zUp,
                int twidth, int theight);
extern int guRandom(void);
extern float _sinf(float angle);
extern float _cosf(float angle);
extern signed short sins (unsigned short angle);
extern signed short coss (unsigned short angle);
extern float sqrtf(float value);
extern void guParseRdpDL(u64 *rdp_dl, u64 nbytes, u8 flags);
extern void guParseString(char *StringPointer, u64 nbytes);
extern void
guBlinkRdpDL(u64 *rdp_dl_in, u64 nbytes_in,
             u64 *rdp_dl_out, u64 *nbytes_out,
             u32 x, u32 y, u32 radius,
             u8 red, u8 green, u8 blue,
             u8 flags);
extern void guParseGbiDL(u64 *gbi_dl, u32 nbytes, u8 flags);
extern void guDumpGbiDL(OSTask *tp,u8 flags);
typedef struct {
    int dataSize;
    int dlType;
    int flags;
    u32 paddr;
} guDLPrintCB;
void guSprite2DInit(uSprite *SpritePointer,
      void *SourceImagePointer,
      void *TlutPointer,
      int Stride,
      int SubImageWidth,
      int SubImageHeight,
      int SourceImageType,
      int SourceImageBitSize,
      int SourceImageOffsetS,
      int SourceImageOffsetT);
typedef struct {
    long type;
    long length;
    long magic;
    char userdata[(((4096)*6)-(3*sizeof(long)))];
} RamRomBuffer;
struct bitmap {
 s16 width;
 s16 width_img;
 s16 s;
 s16 t;
 void *buf;
 s16 actualHeight;
 s16 LUToffset;
};
typedef struct bitmap Bitmap;
struct sprite {
 s16 x,y;
 s16 width, height;
 f32 scalex, scaley;
 s16 expx, expy;
 u16 attr;
 s16 zdepth;
 u8 red;
 u8 green;
 u8 blue;
 u8 alpha;
 s16 startTLUT;
 s16 nTLUT;
 int *LUT;
 s16 istart;
 s16 istep;
 s16 nbitmaps;
 s16 ndisplist;
 s16 bmheight;
 s16 bmHreal;
 u8 bmfmt;
 u8 bmsiz;
 Bitmap *bitmap;
 Gfx *rsp_dl;
 Gfx *rsp_dl_next;
 s16 frac_s,
  frac_t;
};
typedef struct sprite Sprite;
void spSetAttribute (Sprite *sp, s32 attr);
void spClearAttribute (Sprite *sp, s32 attr);
void spMove (Sprite *sp, s32 x, s32 y);
void spScale (Sprite *sp, f32 sx, f32 sy);
void spSetZ (Sprite *sp, s32 z );
void spColor (Sprite *sp, u8 red, u8 green, u8 blue, u8 alpha);
Gfx *spDraw (Sprite *sp);
void spInit( Gfx **glistp );
void spScissor( s32 xmin, s32 xmax, s32 ymin, s32 ymax );
void spFinish( Gfx **glistp );
extern long long int rspbootTextStart[], rspbootTextEnd[];
extern long long int gspFast3DTextStart[], gspFast3DTextEnd[];
extern long long int gspFast3DDataStart[], gspFast3DDataEnd[];
extern long long int gspFast3D_dramTextStart[], gspFast3D_dramTextEnd[];
extern long long int gspFast3D_dramDataStart[], gspFast3D_dramDataEnd[];
extern long long int gspFast3D_fifoTextStart[], gspFast3D_fifoTextEnd[];
extern long long int gspFast3D_fifoDataStart[], gspFast3D_fifoDataEnd[];
extern long long int gspF3DNoNTextStart[], gspF3DNoNTextEnd[];
extern long long int gspF3DNoNDataStart[], gspF3DNoNDataEnd[];
extern long long int gspF3DNoN_dramTextStart[];
extern long long int gspF3DNoN_dramTextEnd[];
extern long long int gspF3DNoN_dramDataStart[];
extern long long int gspF3DNoN_dramDataEnd[];
extern long long int gspF3DNoN_fifoTextStart[];
extern long long int gspF3DNoN_fifoTextEnd[];
extern long long int gspF3DNoN_fifoDataStart[];
extern long long int gspF3DNoN_fifoDataEnd[];
extern long long int gspLine3DTextStart[], gspLine3DTextEnd[];
extern long long int gspLine3DDataStart[], gspLine3DDataEnd[];
extern long long int gspLine3D_dramTextStart[], gspLine3D_dramTextEnd[];
extern long long int gspLine3D_dramDataStart[], gspLine3D_dramDataEnd[];
extern long long int gspLine3D_fifoTextStart[], gspLine3D_fifoTextEnd[];
extern long long int gspLine3D_fifoDataStart[], gspLine3D_fifoDataEnd[];
extern long long int gspSprite2DTextStart[], gspSprite2DTextEnd[];
extern long long int gspSprite2DDataStart[], gspSprite2DDataEnd[];
extern long long int gspSprite2D_dramTextStart[], gspSprite2D_dramTextEnd[];
extern long long int gspSprite2D_dramDataStart[], gspSprite2D_dramDataEnd[];
extern long long int gspSprite2D_fifoTextStart[], gspSprite2D_fifoTextEnd[];
extern long long int gspSprite2D_fifoDataStart[], gspSprite2D_fifoDataEnd[];
extern long long int aspMainTextStart[], aspMainTextEnd[];
extern long long int aspMainDataStart[], aspMainDataEnd[];
extern long long int gspF3DEX_fifoTextStart[], gspF3DEX_fifoTextEnd[];
extern long long int gspF3DEX_fifoDataStart[], gspF3DEX_fifoDataEnd[];
extern long long int gspF3DEX_NoN_fifoTextStart[], gspF3DEX_NoN_fifoTextEnd[];
extern long long int gspF3DEX_NoN_fifoDataStart[], gspF3DEX_NoN_fifoDataEnd[];
extern long long int gspF3DLX_fifoTextStart[], gspF3DLX_fifoTextEnd[];
extern long long int gspF3DLX_fifoDataStart[], gspF3DLX_fifoDataEnd[];
extern long long int gspF3DLX_NoN_fifoTextStart[], gspF3DLX_NoN_fifoTextEnd[];
extern long long int gspF3DLX_NoN_fifoDataStart[], gspF3DLX_NoN_fifoDataEnd[];
extern long long int gspF3DLX_Rej_fifoTextStart[], gspF3DLX_Rej_fifoTextEnd[];
extern long long int gspF3DLX_Rej_fifoDataStart[], gspF3DLX_Rej_fifoDataEnd[];
extern long long int gspF3DLP_Rej_fifoTextStart[], gspF3DLP_Rej_fifoTextEnd[];
extern long long int gspF3DLP_Rej_fifoDataStart[], gspF3DLP_Rej_fifoDataEnd[];
extern long long int gspL3DEX_fifoTextStart[], gspL3DEX_fifoTextEnd[];
extern long long int gspL3DEX_fifoDataStart[], gspL3DEX_fifoDataEnd[];
extern long long int gspF3DEX2_fifoTextStart[], gspF3DEX2_fifoTextEnd[];
extern long long int gspF3DEX2_fifoDataStart[], gspF3DEX2_fifoDataEnd[];
extern long long int gspF3DEX2_NoN_fifoTextStart[],gspF3DEX2_NoN_fifoTextEnd[];
extern long long int gspF3DEX2_NoN_fifoDataStart[],gspF3DEX2_NoN_fifoDataEnd[];
extern long long int gspF3DEX2_Rej_fifoTextStart[],gspF3DEX2_Rej_fifoTextEnd[];
extern long long int gspF3DEX2_Rej_fifoDataStart[],gspF3DEX2_Rej_fifoDataEnd[];
extern long long int gspF3DLX2_Rej_fifoTextStart[],gspF3DLX2_Rej_fifoTextEnd[];
extern long long int gspF3DLX2_Rej_fifoDataStart[],gspF3DLX2_Rej_fifoDataEnd[];
extern long long int gspL3DEX2_fifoTextStart[], gspL3DEX2_fifoTextEnd[];
extern long long int gspL3DEX2_fifoDataStart[], gspL3DEX2_fifoDataEnd[];
extern long long int gspF3DEX2_xbusTextStart[], gspF3DEX2_xbusTextEnd[];
extern long long int gspF3DEX2_xbusDataStart[], gspF3DEX2_xbusDataEnd[];
extern long long int gspF3DEX2_NoN_xbusTextStart[],gspF3DEX2_NoN_xbusTextEnd[];
extern long long int gspF3DEX2_NoN_xbusDataStart[],gspF3DEX2_NoN_xbusDataEnd[];
extern long long int gspF3DEX2_Rej_xbusTextStart[],gspF3DEX2_Rej_xbusTextEnd[];
extern long long int gspF3DEX2_Rej_xbusDataStart[],gspF3DEX2_Rej_xbusDataEnd[];
extern long long int gspF3DLX2_Rej_xbusTextStart[],gspF3DLX2_Rej_xbusTextEnd[];
extern long long int gspF3DLX2_Rej_xbusDataStart[],gspF3DLX2_Rej_xbusDataEnd[];
extern long long int gspL3DEX2_xbusTextStart[], gspL3DEX2_xbusTextEnd[];
extern long long int gspL3DEX2_xbusDataStart[], gspL3DEX2_xbusDataEnd[];
typedef void (*OSErrorHandler)(s16, s16, ...);
OSErrorHandler osSetErrorHandler(OSErrorHandler);
typedef struct {
    u32 magic;
    u32 len;
    u32 *base;
    s32 startCount;
    s32 writeOffset;
} OSLog;
typedef struct {
    u32 magic;
    u32 timeStamp;
    u16 argCount;
    u16 eventID;
} OSLogItem;
typedef struct {
    u32 magic;
    u32 version;
} OSLogFileHdr;
void osCreateLog(OSLog *log, u32 *base, s32 len);
void osLogEvent(OSLog *log, s16 code, s16 numArgs, ...);
void osFlushLog(OSLog *log);
u32 osLogFloat(f32);
extern void osDelay(int count);
typedef u8 Addr[];
typedef f32 HuMtx4F[4][4];
s16 HuAudSeqPlay(s16 musId);
s16 func_8004A5C4_4B1C4(s32);
void HuAudSeqFadeOut(s16 speed);
s16 HuAudFXPlay(s16 seId);
void func_8004AAD0_4B6D0(s16, s8);
void func_8004AB0C_4B70C(s32);
void HuAudFXPitchSet(s32 seNo, s32 pitch);
s16 CharFXPlay(s16 seId, u8 charNo);
s32 func_8004AC5C_4B85C(s16 arg0, s16 arg1);
s16 func_8004AC98_4B898(s16, s16);
void func_8004ACE0_4B8E0(s32, s16);
void HuAudFXStop(s32 seNo);
void func_8004AEF0_4BAF0(s16, s32);
void omVibrate(s16 arg0, s32 arg1, s32 arg2, s32 arg3);
typedef struct {
    f32 x;
    f32 y;
    f32 z;
} Vec;
typedef struct {
    s32 x;
    s32 y;
    s32 z;
} HuVec3I;
float sinf(float);
float cosf(float);
float sqrtf(float);
float HuSqrtf(float x);
void HuVecCopyXYZ(Vec * out, f32 x, f32 y, f32 z);
void HuVecCopy3F(Vec * out, Vec * a);
f32 HuVecGetLengthSqr3F(Vec * vec);
f32 HuVecGetLength3F(Vec * vec);
typedef struct {
    Gfx* unk00[4];
    void* unk10;
    void* unk14;
} HmfModelData_Unk64_Unk3C_Struct;
typedef struct {
    u8 unk00;
    char unk01[0x33];
} HmfModelData_Unk64_Unk60_Unk54_Struct;
typedef struct {
    char unk00[0x22];
    s16 unk22;
    char unk24[4];
    s16 unk28;
    s16 unk2A;
    char unk2C[0x24];
    s32 unk50;
    HmfModelData_Unk64_Unk60_Unk54_Struct* unk54;
    char unk58[0x10];
} HmfModelData_Unk64_Unk60_Struct;
typedef struct {
    char unk00[0x18];
} HmfModelData_Unk64_Unk8C_Struct;
typedef struct {
    char unk00[2];
    s16 unk02;
    char unk04[4];
    s32 unk08;
} HmfModelData_Unk64_Unk98_Struct;
typedef struct {
    char unk_00[0x30];
    s32 unk_30;
} HmfData_Unk84_Entry2;
typedef struct {
    u8 unk0[3];
    u8 unk3;
    u8 unk4;
    u8 unk5[4];
    u8 unk9;
    u8 unkA[2];
    HmfData_Unk84_Entry2* unkC;
} HmfData_Unk84_Entry;
typedef struct {
               s8 unk00;
               s8 unk01;
               s8 unk02;
               s8 unk03;
               s8 unk04;
               s8 unk05;
               s8 unk06;
               char unk07[1];
               Light unk08[1];
} HmfData_UnkD0;
typedef struct {
               u8 unk00;
               s8 unk01;
               char unk02[8];
               u8 unk0A;
               s8 unk0B;
               s8 unk0C;
               s16 unk0E;
               s16 unk10;
               s16 unk12;
               s16 unk14;
               char unk16[0xA];
               s16 unk20;
               char unk22[0x16];
               s32 unk38;
               HmfModelData_Unk64_Unk3C_Struct* unk3C;
               void* unk40;
               Vtx* unk44[3];
               void* unk50;
               char unk54[0xC];
               HmfModelData_Unk64_Unk60_Struct* unk60;
               char unk64[0x20];
               HmfData_Unk84_Entry* unk84;
               char unk88[4];
               HmfModelData_Unk64_Unk8C_Struct* unk8C;
               HmfModelData_Unk64_Unk8C_Struct* unk90;
               HmfModelData_Unk64_Unk8C_Struct* unk94;
               HmfModelData_Unk64_Unk98_Struct* unk98;
               char unk9C[4];
               s32 unkA0;
               f32 unkA4;
               f32 unkA8;
               f32 unkAC;
               char unkB0[4];
               s32 unkB4;
               char unkB8[8];
               void* unkC0;
               char unkC4[4];
               s32 unkC8;
               char unkCC[4];
               s32 unkD0;
               char unkD4[8];
} HmfData;
typedef struct {
               s16 unk00;
               char unk02[2];
               u16 unk04;
               char unk08[0x10];
               void (*unk18)(s16);
} HmfModelData_UnkBC_Struct;
typedef struct HmfModel {
               s8 unk00;
               u8 unk01;
               u8 unk02;
               u8 unk03;
               u8 unk04;
               u8 unk05;
               u8 unk06;
               s8 unk07;
               u8 unk08;
               u8 unk09;
               u8 unk0A;
               s16 unk0C;
               s16 unk0E;
               s16 unk10;
               char unk12[6];
               s32 unk18;
               Vec pos;
               Vec rot;
               Vec scale;
               f32 unk40;
               f32 unk44;
               f32 unk48;
               f32 unk4C;
               f32 unk50;
               f32 unk54;
               f32 unk58;
               f32 unk5C;
               f32 unk60;
               HmfData* hmf;
               char unk68[8];
               void (*unk70)(Gfx**, s32, s32);
               f32 mtx[16];
               struct HmfModel* unkB4;
               char unkB8[4];
               HmfModelData_UnkBC_Struct* unkBC;
} HmfModel;
void func_8001A070_1AC70(void* arg0, void* arg1, u16 arg2, u16 arg3, u16 arg4, u8 arg5);
s16 Hu3DModelCreate(u8*, u32);
s16 Hu3DModelLink(s16 linkMdlId);
s32 func_8001A894_1B494(s32, void*, s32);
s16 func_8001AC8C_1B88C(s32 arg0, void (*arg1)(Gfx**, s32, s32), u8 arg2);
void func_8001ACDC_1B8DC(s16);
void func_8001B0B4_1BCB4(void** arg0, u32 arg1);
void func_8001BF90_1CB90(u32 arg0, u32 arg1);
void Hu3DModelPosSet(s16 arg0, f32 x, f32 y, f32 z);
void Hu3DModelRotSet(s16 arg0, f32 x, f32 y, f32 z);
void Hu3DModelScaleSet(s16 arg0, f32 x, f32 y, f32 z);
void func_8001C258_1CE58(s16 arg0, s32 arg1, s32 arg2);
void func_8001C2FC_1CEFC(s16 arg0, s32 arg1, s32 arg2);
void func_8001C448_1D048(s16);
s32 func_8001C514_1D114(s32);
void func_8001C5B4_1D1B4(s16, s16);
void func_8001C624_1D224(s16, s16, s16, s16, s16);
void func_8001C6A8_1D2A8(s32, f32);
f32 func_8001C7D0_1D3D0(s16 arg0);
void func_8001C814_1D414(s16, s16, s16);
void func_8001C8A8_1D4A8(s16, s16);
void func_8001C8E4_1D4E4(s16, u32);
void func_8001C92C_1D52C(s16, f32);
s32 func_8001C954_1D554(s32);
void func_8001EF24_1FB24(s32, s32, s32, s32, s32);
s32 func_8001F1FC_1FDFC(void*, s32);
void func_8001F304_1FF04(s16, s16);
void func_8001F38C_1FF8C(s32, s32, s32);
void func_8001FDE8_209E8(s16);
extern HmfModel* HmfModelData;
struct HmfModel;
typedef struct {
    Mtx perspMtx;
    Mtx lookAtMtx;
} HuCamMtxs;
typedef struct HuCamera {
                u16 perspNorm;
                s16 unk2;
                s16 unk4;
                f32 unk8;
                f32 unkC;
                Vec pos;
                Vec at;
                Vec up;
                Vec screenScale;
                Vec screenPos;
                s32 unk4C;
                f32 fov[3];
                f32 unk5C;
                Vp viewports[3];
                f32 screenLeft;
                f32 screenTop;
                f32 screenRight;
                f32 screenBottom;
                void (*unkA0)(void*, struct HmfModel*);
                void* unkA4;
                void (*unkA8)(s32);
                void (*unkAC)(s32);
                HuCamMtxs mtxs[3];
} HuCamera;
typedef struct RectF {
           f32 x1;
           f32 y1;
           f32 x2;
           f32 y2;
} RectF;
void Hu3DCamInit(u32 arg0);
void Hu3DCamSetPositionOrientation(s16 camIndex, Vec* pos, Vec* at, Vec* up);
void Hu3DCamSetPerspective(s16 camIndex, f32 fov, f32 near, f32 far);
void CameraScissorSet(s16 camIndex, RectF* arg1);
void CameraViewportSet(s16 camIndex, Vec* arg1, Vec* arg2);
void Hu3DCamUpdateMtx(s16 camIndex);
void func_80012640_13240(s16 camIndex, Gfx** dispList);
void func_800127C4_133C4(s16 camIndex, Gfx** dispList);
void func_80012888_13488(s16 camIndex, void (*arg1)(void*, struct HmfModel*), void* arg2);
extern HuCamera* gCameraList;
typedef enum
{
    DECODE_NONE = 0,
    DECODE_LZ,
    DECODE_SLIDE,
    DECODE_FSLIDE,
    DECODE_FSLIDE_2,
    DECODE_RLE
} EDecodeType;
typedef struct DecodeStruct {
           u16 chunkLen;
           s16 pad;
           u8* src;
           u8* dest;
           u32 len;
} DecodeStruct;
void HuDecodeNone(DecodeStruct* decode);
void HuDecodeLZ(DecodeStruct* decode);
void HuDecodeSlide(DecodeStruct* decode);
void HuDecodeFslide(DecodeStruct* decode);
void HuDecodeRLE(DecodeStruct* decode);
void DecodeData(void * src, void * dest, s32 len, EDecodeType decodeType);
typedef enum
{
    ARCHIVE_CACHED = 0x2E,
    ARCHIVE_DIRECT,
} EArchiveType;
typedef enum
{
    DIR_COMMON = 0,
    DIR_ACT_TEST,
    DIR_MARIO,
    DIR_LUIGI,
    DIR_YOSHI,
    DIR_WARIO,
    DIR_DK,
    DIR_PEACH,
    DIR_WALUIGI,
    DIR_DAISY,
    DIR_MISC_MODELS,
    DIR_START_MENU = 16,
    DIR_BOOT,
    DIR_BOARD_DEFS = 19,
    DIR_BOARD_SEL,
    DIR_CREDITS = 22,
    DIR_STUBBED = 26,
} EDataDirs;
typedef struct {
    s32 count;
    s32 offsets[3];
} HuArchive;
typedef struct {
    u8* bytes;
    s32 size;
    EDecodeType compType;
} HuFileInfo;
typedef struct
{
    s16 compType;
    u32 size;
    u8* block;
    s16 unkC;
    s16 unkE;
    void* bytes;
    void* bytesCopy;
} HuFileInfoD;
extern u8* DataRomAddr;
extern u32 DataDirMax;
extern s32* DataDirTbl;
extern u8* DataFileRomAddr;
extern u32 DataFileMax;
extern s32* DataFileTbl;
extern HuArchive gArchive;
void DataInit(u8* fsRomPtr);
void DataInfoRead(EArchiveType type, s32 index, HuFileInfo* info);
void* DataRead(s32 dirAndFile);
void* DataReadTemp(s32 dirAndFile);
void* DataReadNum(s32 dirAndFile, s32 tag);
void* DataDecode(EArchiveType type, s32 index);
void* DataDecodeTemp(EArchiveType type, s32 index);
void* DataDecodeNum(EArchiveType type, s32 index, s32 tag);
void DataClose(void* data);
void DataCloseTemp(void* data);
void DataDirInit(EArchiveType type, s32 dir);
s16 func_8000B838_C438(s32 arg0);
void func_8000BB54_C754(u16 arg0);
void func_8000BB94_C794(u16 arg0);
void func_8000BA30_C630(void);
void func_8000BBD4_C7D4(u16 spriteId, s16 x, s16 y);
void func_8000BCC8_C8C8(u16, s32);
s16 InitEspriteSlot(s16 arg0, u16 arg1, u16 arg2);
void func_8000C184_CD84(u16);
s16 GMesCreate(s16 mesNo, ...);
s32 GMesStatGet(void);
void GMesClose(void);
void func_80037258_37E58(void);
void func_8003F578_40178(s16);
void func_8003F5C0_401C0(void);
void func_80045010_45C10(const s16*, s32);
typedef struct jump_buf
{
    u32* sp;
    void *func;
    u32 regs[21];
} jmp_buf;
extern s32 setjmp(jmp_buf *jump_buf);
extern s32 longjmp(jmp_buf *jump_buf, s32 val);
typedef void (*process_func)();
typedef struct Process {
           struct Process *next;
           struct Process *youngest_child;
           struct Process *oldest_child;
           struct Process *relative;
           struct Process *parent_oldest_child;
           struct Process *new_process;
           void *heap;
           u16 exec_mode;
           u16 stat;
           u16 priority;
           s16 dtor_idx;
           s32 sleep_time;
           void *base_sp;
           jmp_buf prc_jump;
           process_func destructor;
           void *user_data;
} Process;
void HuPrcSysInit();
Process* HuPrcCreate(process_func func, u16 priority, s32 stack_size, s32 extra_data_size);
void HuPrcChildLink(Process*process, Process*child);
void HuPrcChildUnlink(Process*process);
Process* HuPrcCreateChild(process_func func, u16 priority, s32 stack_size, s32 extra_data_size, Process* parent);
void HuPrcChildWait();
Process* HuPrcCurrentGet();
s32 HuPrcChildGet(Process*process);
s32 HuPrcStatKill(Process*process);
s32 HuPrcKill(Process*process);
void HuPrcChildKill(Process*process);
void HuPrcTerminate(Process*process);
void HuPrcExit();
void HuPrcSleep(s32 time);
void HuPrcVSleep();
void HuPrcAwake(Process*process);
void HuPrcDtor(Process*process, process_func destructor);
void HuPrcCurrentDtor(process_func destructor);
void* HuPrcAllocMem(s32 size);
void HuPrcFreeMem(void *ptr);
struct om_obj_data;
typedef void (*omObjFunc)(struct om_obj_data *);
typedef struct om_obj_data {
           u16 stat;
           s16 next_idx_alloc;
           s16 prio;
           s16 prev;
           s16 next;
           s16 next_idx;
           s16 group;
           u16 group_idx;
           u32 unk10;
           omObjFunc func;
           Vec trans;
           Vec rot;
           Vec scale;
           u16 mdlcnt;
           s16* model;
           u16 mtncnt;
           s16* motion;
           u32 work[4];
           void* data;
} omObjData;
typedef struct Object_s {
           struct Object_s *prev;
           struct Object_s *next;
           u8 unk8;
           s8 unk9;
           u16 flags;
           Vec coords;
           Vec unk18;
           Vec scale;
           Vec velocity;
           omObjData* omObj1;
           omObjData* omObj2;
           s16 unk44;
           s16 unk46;
} Object;
void omInitObjMan(s16 numOfObjs, s32 numOfPrcs);
void omSetStatBit(omObjData *obj, u16 stat);
s32 omOvlReturnEx(s16 level);
omObjData* omAddObj(s16 prio, u16 mdlcnt, u16 mtncnt, s16 group, omObjFunc func);
Process* omAddPrcObj(process_func func, u16 priority, s32 stackSize, s32 extDataSize);
s32 omDelPrcObj(Process*);
s32 omOvlCallEx(s32 ovlID, s16 event, u16 stat);
void omMain(void);
u16 func_80049F98_4AB98(void);
void func_8004A208_4AE08(void);
void omPrcSetStatBit(Process* prc, s32 stat);
void omOvlGotoEx(s32 ovlID, s16 event, u16 stat);
void omOvlHisChg(s16 level, s32 overlay, s16 event, s16 stat);
void omOvlKill(void);
void omDestroyObjMan(void);
void omPrcSetDestructor(s32, void*);
void omPrcResetStatBit(Process* prc, s32 stat);
void omSetTra(omObjData* obj, f32 x, f32 y, f32 z);
void omSetRot(omObjData* obj, f32 x, f32 y, f32 z);
void omSetSca(omObjData* obj, f32 x, f32 y, f32 z);
void omDelObj(omObjData*);
void omOutView(omObjData* object);
void omOutViewMulti(omObjData* object);
extern f32 CZoomM[];
extern f32 CZoom;
extern Vec CRot;
extern Vec CenterM[];
extern Vec Center;
extern Vec CRotM[];
typedef struct GwCommon_s {
           u8 unk_00;
           u8 languageIndex;
           u16 mgRecord[8];
           char unk_12[4];
           u8 mgUnlock[7];
           char unk_1D[0x6E];
           u8 flag[0xC];
           char pad97[7];
           s8 unk9E;
           s8 unk9F;
           s8 unkA0;
           s8 unkA1;
           s8 unkA2;
           char padA3[1];
} GW_COMMON;
typedef struct GW_STORY {
               u8 unk0;
               u8 unk1;
               u8 unk2;
               u8 unk3[12];
               u8 unkF;
               u8 unk10[6][12];
               u8 unk58[6];
               u8 unk5E[6];
               char unk_64[0x10];
} GW_STORY;
typedef struct GW_SYSTEM {
                          s8 playMode;
                          s8 current_board_index;
                          s8 total_turns;
                          s8 current_turn;
                          s8 current_game_length;
                          s8 current_star_spawn;
                          s8 star_spawn_indices[7];
                          s8 unk_0D;
                          s8 unk_0E;
                          s8 current_player_index;
                          s8 minigame_index;
                          s8 current_space_index;
                          s8 save_mode;
                          s8 show_minigame_explanations;
                          s8 message_speed;
                          s8 walk_speed;
                          s8 show_com_minigames;
                          char unk_17[0x27];
    union {
                              s16 halfWordBytes[9];
                              s8 bytes[18];
    } boardData;
                          u16 cur_player_used_item;
                          s16 unk_52;
                          s16 forceShopHost;
                          s16 slow_dice_flags;
                          s16 unk_58;
                          s16 playerIndexVisitingBowser;
                          u16 bank_coins;
                          u8 data_flags[8];
                          u8 unk_66[0x3E];
} GW_SYSTEM;
enum PlayerFlags {
    PLAYER_IS_CPU = 1,
};
typedef struct PartnerStats {
           s8 frontPoweredUp;
           s8 backPoweredUp;
           s8 frontHp;
           s8 backHp;
           s8 frontCost;
           s8 backCost;
           s8 frontPower;
           s8 backPower;
           s8 frontID;
           s8 backID;
} PartnerStats;
typedef struct {
           s8 hatenaPrize;
           s8 redPrize;
           s8 bluePrize;
           s8 eventPrize;
           s8 kupaPrize;
           s8 battlePrize;
           s8 itemPrize;
           s8 bankPrize;
           s8 gamblePrize;
           s8 duelNo;
} PrizeStats;
typedef struct GwPlayer_s {
           u8 group;
           u8 cpu_difficulty;
           u8 pad;
           u8 chr;
           u8 stat;
           char unk_05;
           s16 gameCoin;
           s16 bonusCoin;
           s16 coin;
           s16 checkCoin;
           s8 star;
           s8 clink;
           s8 cidx;
           s8 nlink;
           s8 nidx;
           s8 nnlink;
           s8 nnidx;
           s8 blink;
           s8 bidx;
           u8 rev;
           s8 itemNo[3];
           s8 itemTurn;
           u8 color;
           u8 turn;
           char unk_1E[2];
           void* unk_20;
           Object* player_obj;
           s16 gamePrize;
           s16 coinPrize;
           union {
    PrizeStats prize;
    PartnerStats partners;
} stats;
           char unk_36[2];
} GW_PLAYER __attribute__((aligned(4)));
extern GW_COMMON GwCommon;
extern GW_STORY GwStory;
extern GW_SYSTEM GwSystem;
extern GW_PLAYER GwPlayer[5];
void HmfLightExec(s16);
void HmfLightMaxSet(s16);
void HmfLightColorSet(s16, u8, u8, u8);
void HmfLightDirSet(s16, f32, f32, f32);
void func_80019968_1A568(s16);
typedef struct {
               void* unk00;
               u16 unk04;
               u16 unk06;
               s16 unk08;
               s16 unk0A;
} HuSprite_Unk84_Unk00_Struct;
typedef struct HuSprCelFrame {
               u16 unk00;
               u16 unk02;
               u8 unk04;
               u8 unk05;
               u8 unk06;
               u8 unk07;
} HuSprCelFrame;
typedef struct HuSprCelAnm {
               u16 unk00;
               u16 unk02;
               HuSprCelFrame* unk04;
} HuSprCelAnm;
typedef struct {
               HuSprite_Unk84_Unk00_Struct* unk00;
               HuSprCelAnm** unk04;
               void* unk08;
               void* unk0C;
               u16 unk10;
               u16 unk12;
               s16 unk14;
               s16 unk16;
               u16 unk18;
               u16 unk1A;
} HuSprite_Unk84_Struct;
typedef struct HuSprAnm {
               HuSprite_Unk84_Struct* unk00;
               u8 unk04;
               s16 unk06;
               s16 unk08;
               s16 unk0A;
               f32 unk0C;
               f32 unk10;
               s16 unk14;
               u8 unk16;
               u8 unk17;
               u8 unk18;
} HuSprAnm;
typedef struct HuSprAnmEntry {
               u16 unk00;
               u16 unk02;
               struct HuSprAnmEntry **unk04;
} HuSprAnmEntry;
typedef struct HuSprAnmDesc {
               u16 unk00;
               u16 unk02;
               HuSprAnmEntry **unk04;
               u16 unk08;
               void *unk0C;
} HuSprAnmDesc;
typedef struct HuSprite {
               char unk_00[0xC];
               s16 unk_0C;
               s16 unk_0E;
               f32 unk_10;
               u16 prio;
               f32 unk_18;
               f32 unk_1C;
               char unk_20[0x4];
               s32 unk_24;
               char unk_28[4];
               u16 unk_2C;
               s16 unk_2E;
               s32 unk_30;
               s32 unk_34;
               u16 unk_38;
               u16 unk_3A;
               u16 unk_3C;
               u16 unk_3E;
               u16 unk_40;
               u16 unk_42;
               s32 unk_44;
               f32 unk_48;
               f32 unk_4C;
               f32 unk_50;
               f32 unk_54;
               f32 unk_58;
               s32 unk_5C;
               f32 unk_60;
               f32 unk_64;
               HuSprAnm unk_68;
               HuSprite_Unk84_Struct* unk_84;
               s8 unk_88;
               s16 unk_8A;
               f32 unk_8C;
               s16 unk_90;
               s8 unk_92;
               u8 unk_93;
               u8 unk_94;
               char unk_95_pad[0x3];
               HuSprAnmDesc* unk_98;
               u16 unk_9C[0x10];
               s32 unk_BC[0x10];
               union {
        f32 f;
        s32 i;
    } unk_FC;
                char unk_100_pad[0x4];
                s32 unk_104;
                void* unk_108[3];
                s16 unk_114;
                s16 unk_116;
                void* unk_118;
                void* unk_11C;
                void* unk_120;
                void* unk_124;
                void* unk_128[3];
                void* unk_134[3];
                char unk_140_pad[0xC4];
                u16 unk_204;
                u16 unk_206;
                u16 unk_208;
                u16 unk_20A;
                char unk_20C_pad[0x4];
} HuSprite;
typedef struct HuSprGrp {
    struct HuSprGrp* next;
    struct HuSprGrp* prev;
    s16 unk_08;
    u16 unk_0A;
    s32 unk_0C;
    HuSprite* members[4];
} HuSprGrp;
extern HuSprGrp* HuSprGrpData[256];
void func_80052330_52F30(void);
void HuSprGrpKill(s16);
s16 HuSprGrpCreate(u16 arg0, u16 arg1);
void func_80054904_55504(s16 group, s16 member, s16 arg2, s16 arg3);
void func_80054FF8_55BF8(s16 group, s16 member, s32 arg2);
void func_80055024_55C24(s16 group, s16 member, s16 arg2, s32 arg3);
void func_800550B4_55CB4(s16 group, s16 member, f32 arg2);
void func_800550F4_55CF4(s16, s16, s32);
void func_80055140_55D40(s16, s16, u16, s32);
u8 func_800551AC_55DAC(s16 group, s16 member);
HuSprite_Unk84_Struct* func_80055194_55D94(s16 arg0);
void HuSprScaleSet(s16 group, s16 member, f32 x, f32 y);
void HuSprPriSet(s16 group, s16 member, u16 prio);
void func_800552DC_55EDC(s16, s16, f32);
void HuSprAttrReset(s16 group, s16 member, s32 attr);
void HuSprAttrSet(s16 group, s16 member, s32 attr);
void func_80055420_56020(s16, s16, u8, u8, u8);
void func_80055458_56058(s16, s16, u16);
void func_800554C4_560C4(s16 group, s16 member, u16 arg2);
HuSprite* HuSprGet(s16 group, s16 member);
void HuSprKill(s16);
s16 func_80055810_56410(void*);
void func_80056BAC_577AC(void);
u16 func_8000B108_BD08(s32 arg0, s32 arg1);
u8 rand8(void);
void ScissorSet(u8 camIndex, f32 arg1, f32 arg2, f32 arg3, f32 arg4);
void ViewportSet(u8 camIndex, f32 arg1, f32 arg2, f32 arg3, f32 arg4, f32 arg5, f32 arg6);
void func_8000B460_C060(omObjData*, u16, s32);
typedef struct TextWindow {
                u8 unk_00;
                char pad1[3];
                s8 unk_04;
                u8 unk_05;
                char pad6[0xA];
                u8 unk_10;
                char pad11[7];
                s16 unk_18;
                s16 unk_1A;
                char pad1C[4];
                s8 unk20;
                char pad21[8];
                s8 unk_29;
                s8 unk_2A;
                char pad2B[1];
                s16 unk_2C;
                s16 unk_2E;
                s8 unk_30;
                s8 unk_31;
                s16 unk_32;
                s16 unk_34;
                char pad36[2];
                u32 unk_38;
                u16 unk3C;
                u16 unk3E;
                char pad40[8];
                u16 unk48;
                u16 unk4A;
                s16 unk4C;
                char pad4E[6];
                s16 unk54;
                char pad56[8];
                s16 unk5E;
                char pad60[2];
                s16 unk62;
                s16 unk64;
                char pad66[6];
                s16 unk_6C;
                s16 unk_6E[0xC];
                char pad86[0x27];
                s8 usingStringIDBool[5];
                s8 unk_B2[6];
                void *unk_B8[4];
                char padC8[0x1AC];
                s16 unk274;
                s16 unk276;
                char pad278[4];
} TextWindow;
void func_8005A6B0_5B2B0(void);
s16 func_8005A968_5B568(s16, s16, s16, s16, s32, s16);
void func_8005B43C_5C03C(s16, s32, s32, s32);
void func_8005B6BC_5C2BC(s16 win_id, u32 arg1, s8 arg2);
void func_8005BDFC_5C9FC(s16, s32);
void func_8005BE30_5CA30(s16, s32);
void func_8005BEE0_5CAE0(s16, s16);
void func_8005C02C_5CC2C(s16, s32);
void func_8005C060_5CC60(s16, s32, s32, s32, s32);
void func_8005D294_5DE94(s16);
void func_8005E1A8_5EDA8(s16, s16);
void func_8005F364_5FF64(s16);
void func_8005F524_60124(void);
void func_8005FBF8_607F8(s16, s32, s32, s32);
void func_8005FE90_60A90(s16);
void func_8005FFA8_60BA8(s16);
void func_8006022C_60E2C(u32 mesg, s16);
void func_80060394_60F94(s32, s16*, s32);
void func_80061388_61F88(s16);
void func_80060144_60D44(s16 obj);
void *func_800364DC_370DC(void *arg0);
void func_800365E8_371E8(void *ptr);
s16 func_8005B7B8_5C3B8(s16 win_id, u32 spriteMainFsPair, s16 arg2, s16 arg3, u16 arg4);
void func_8005BA90_5C690(s16, s16, s16);
void func_8005BCA4_5C8A4(s16, s16, s16);
void func_8005DDDC_5E9DC(void);
void func_8005F904_60504(void);
void func_800605A4_611A4(u32);
extern TextWindow* D_800CC69C_CD29C;
void WipeInit(void);
void WipeCreateIn(s32, s32);
s32 WipeCreateOut(s32, s32);
s32 WipeStatGet(void);
void WipeColorSet(u8, u8, u8);
typedef struct Vec2f {
           f32 x;
           f32 y;
} Vec2f;
typedef struct objectIndirect3t {
           struct objectt *unk0;
           f32 unk4;
} objectIndirect3;
typedef struct DiceInstance {
    char unk_00[0x4C];
    s32 unk_4C;
} DiceInstance;
typedef struct UnkDiceRelatedInner {
               char pad0[2];
               s8 unk2;
               s8 unk3;
               s8 unk4;
               s8 unk5;
               s8 unk6;
               s8 unk7;
               s8 unk8;
               s8 unk9;
               s8 unkA;
               s8 unkB;
               s8 unkC;
               s8 unkD;
               s16 unk_0E;
               s16 unk_10;
               s16 unk_12;
               s16 unk_14;
               s16 unk16;
               char pad18[0x10];
               s16 unk_28;
               char pad2A[0xA];
               DiceInstance* dice;
               char pad38[0xC];
} UnkDiceRelatedInner;
typedef struct UnkDiceRelated {
               s16 unk_00;
               char unk_02[6];
               UnkDiceRelatedInner UnkDiceInner;
} UnkDiceRelated;
typedef struct SpaceData {
           s8 unk_00;
           u8 space_type;
           u16 unk_02;
           s32 unk_04;
           Vec coords;
           Vec rot;
           void* event_list;
} SpaceData;
typedef struct omOvlHisData {
           s32 overlayID;
           s16 event;
           s16 stat;
} omOvlHisData;
typedef struct MinigameTable {
               u8 minigameType;
               char unk_01[5];
               s16 unk_06;
               s16 unk_08;
               s16 unk_0A;
               s16 unk_0C;
               char unk_0E[6];
} MinigameTable;
typedef struct OvlEntrypoint {
           s16 index;
           void (*fn)(void);
} OvlEntrypoint;
typedef struct RGB {
           u8 r;
           u8 g;
           u8 b;
} RGB;
typedef struct str800D5298 {
    s32 unk0;
    s32 unk4;
    void *unk8;
    void *unkC;
    void *unk10;
    void *unk14;
    s32 unk18;
    s32 unks1C24[3];
    s32 unk28;
    s32 unk2C;
    s32 unks3040[5];
    s32 unk44;
    s32 unks4858[5];
    s32 unk5C;
    s32 unk60;
    s32 unk64;
    s32 unk68;
} str800D5298;
typedef struct HeapNode {
           s32 size;
           u8 heap_constant;
           u8 active;
           struct HeapNode* prev;
           struct HeapNode* next;
} HeapNode;
typedef struct UnkOvl81 {
           void* unk0;
           void* unk4;
           void* unk8;
           char unk_0C[0x14];
           s16 unk_20;
           char unk_22[2];
} UnkOvl81;
typedef struct UnkOvl81_1 {
    s32 unk_00;
    char unk_04[0xC];
} UnkOvl81_1;
typedef struct Unk800D6B48 {
    void* unk_00;
    void* unk_04;
    s32 unk_08;
    s32 unk_0C;
    s32 unk_10;
    s32 unk_14;
    s16 unk_18;
} Unk800D6B48;
typedef struct Unk3 {
    u8 unk_00;
    u8 unk_01;
    s16 unk_02;
    omObjData* unk_04;
    s16 winID;
    char unk_0A[2];
    char* unk_0C;
} Unk3;
typedef struct {
               char unk00[2];
               s16 unk02;
               char unk04[0x14];
} D_800CCF58_CDB58_Struct;
void MBDBackKill(void);
void MBDBackClose(void);
void func_800F64FC_DE2CC_name_81(void);
void func_80106850_4F10A0_mgresultduel(omObjData*, s32);
void ovlEventCall(OvlEntrypoint*, s16);
void HuMemMemoryFreePerm(void *ptr);
s32 HmfSprModelCreate(void*, s32, u8);
s32 HmfAnimCreate(s32, void*, s32, s32);
void pfClsScr(void);
s32 GWBoardFlagCheck(s32);
GW_PLAYER* MBGetPlayerStruct(s32 playerIndex);
s16 func_80017790_18390(s16 model, s32 arg1, s16 arg2, s32 arg3);
void AdjustPlayerCoins(s32 arg0, s32 arg1);
s32 MBRand(f32);
void FixUpPlayerItemSlots(s32 arg0);
void func_800007FC_13FC(str800D5298* arg0);
void func_80000EA8_1AA8(str800D5298* arg0);
void func_80000F30_1B30(u32 arg0);
void func_800143F0_14FF0(void);
void func_80014A3C_1563C(u32 arg0);
void func_800224BC_230BC(void);
void GWInit(void);
void GWMgRecordSet(s16 arg0, s16 arg1);
void func_80036380_36F80(Addr stringsRomPtr);
void pfInit(void);
void func_8004F290_4FE90(void);
s32 func_8004FDC0_509C0(void);
void func_80050800_51400(void);
void SLCurBoxNoSet(u32 arg0);
void* memset(void *dest, int ch, unsigned int n);
void func_80050974_51574(void);
s32 print8(u16 x, u16 y, char* src);
void func_8005035C_50F5C(s32);
void func_80050ABC_516BC(void);
void GWBoardFlagClear(s32 flag);
void GWBoardFlagSet(s32 flag);
void MBMasuTypeSet(s16, s32);
SpaceData* MBMasuGet(s16 arg0);
void func_800698E8_6A4E8(u8**, u8*, s32, s32);
void func_80069E68_6AA68(s32);
void func_8006A370_6AF70(s32);
void func_8000B690_C290(s32);
void func_800142A0_14EA0(s32);
f32 HuMathCos(f32);
f32 HuMathSin(f32);
void* HuMemMemoryAlloc(HeapNode* heap, s32 size);
void func_8004CF30_4DB30(void);
void func_80036414_37014(Addr);
void func_80033354_33F54(s16);
void HuVecSubtract(Vec * dest, Vec * a, Vec * b);
void HuVecAdd(Vec* out, Vec* a, Vec* b);
s32 CheckControllerRead(s16 padNum);
s32 GWContErrorGet(void);
void GWContErrorSet(void);
void Hu3DAnimInit(s32);
s16 GWMgUnlockCheck(s16 arg0);
s32 _CheckFlag(s32);
void GWMgUnlockSet(s16 bitPos);
void _ClearFlag(s32 flag);
void func_8000B5F0_C1F0(u8 arg0);
void _SetFlag(s32 flag);
void func_8008A430_8B030(f32(*)[], f32);
void func_8005B63C_5C23C(s16, s32, s32);
s32 func_8005E1D8_5EDD8(s16, s16, s32);
void func_8005F698_60298(s16, s16, s16, s16, u8);
void func_8005F744_60344(s16, s16, s16, s16);
void func_8005FE54_60A54(s16, u8);
void func_8006010C_60D0C(s16, s16);
void Hu3DCam3DToScreen(s16 camIndex, Vec * worldPos, Vec * outPos);
s32 func_80017BB8_187B8(s16, s16);
void func_800039A4_45A4(s16, s16);
void func_8005FBA4_607A4(u8*, s32);
s32 func_80061188_61D88(s16 arg0, s32 arg1, s32 arg2, s32 arg3, s32 arg4, u16 arg5);
void func_8005D294_5DE94(s16);
void func_8005FBF8_607F8(s16, s32, s32, s32);
void func_80060388_60F88(s8);
void func_800604A8_610A8(s16*, s16, s16);
void func_80061934_62534(s16, s16);
void func_80061A5C_6265C(s16, s16);
void func_8002D4B8_2E0B8(s16);
s32 func_8001F1FC_1FDFC(void*, s32);
void func_8001F9E4_205E4(s16, u8);
void func_8001FA68_20668(s16);
void func_8004A7C4_4B3C4(s32);
void func_8004A72C_4B32C(s32);
void HuVecDirectionSafe3F(Vec*, Vec*, Vec*);
void HuVecMulScalar(Vec*, f32, Vec*);
extern s16 omovlevtno;
extern UnkDiceRelated D_800CDBC8_CE7C8[4];
extern s32 D_800A12D4_A1ED4;
extern s32 D_800A12D8_A1ED8;
extern s16 D_800CDD58_CE958;
extern s16 D_800D037C_D0F7C;
extern s16 D_800D51F8_D5DF8;
extern UnkOvl81 D_800D1360;
extern u8 D_800CD280_CDE80;
extern char D_800D5218_D5E18[];
extern u16 D_800D5558_D6158[4];
extern u16 D_800D530C_D5F0C;
extern s8 D_800D6A58_D7658;
extern MinigameTable D_800A6D44_A7944[];
extern s16 omovlhisidx;
extern omOvlHisData omovlhis[12];
extern omOvlHisData mbovlhis[5];
extern s32 D_800D1240_D1E40;
extern s16 D_800CC0B8_CCCB8;
extern s16 mbovlhisidx;
extern u8 D_800CB99C_CC59C;
extern D_800CCF58_CDB58_Struct* D_800CCF58_CDB58;
enum SPACE_TYPES {
    SPACE_NONE = 0,
    SPACE_BLUE = 1,
    SPACE_RED = 2,
    SPACE_UNK = 3,
    SPACE_HAPPENING = 4,
    SPACE_GREEN = SPACE_HAPPENING,
    SPACE_CHANCE_TIME = 5,
    SPACE_ITEM = 6,
    SPACE_BANK = 7,
    SPACE_START = 8,
    SPACE_BATTLE = 9,
    SPACE_UNK2 = 10,
    SPACE_UNK3 = 11,
    SPACE_BOWSER = 12,
    SPACE_ARROW = 13,
    SPACE_STAR = 14,
    SPACE_GAME_GUY = 15,
    SPACE_TYPES_TOTAL
};
enum LANGUAGE {
    LANGUAGE_NONE = 0,
    LANGUAGE_JAPANESE = 1,
    LANGUAGE_ENGLISH = 2,
    LANGUAGE_FRENCH = 3,
    LANGUAGE_GERMAN = 4,
    LANGUAGE_SPANISH = 5,
    LANGUAGE_ITALIAN = 6,
    LANGUAGE_MAX
};
enum ITEMS {
    ITEM_NONE = -1,
    ITEM_MUSHROOM = 0,
    ITEM_SKELETON_KEY = 1,
    ITEM_POISON_MUSHROOM = 2,
    ITEM_REVERSE_MUSHROOM = 3,
    ITEM_CELLULAR_SHOPPER = 4,
    ITEM_WARP_BLOCK = 5,
    ITEM_PLUNDER_CHEST = 6,
    ITEM_BOWSER_PHONE = 7,
    ITEM_DUEL_GLOVE = 8,
    ITEM_LUCKY_LAMP = 9,
    ITEM_GOLDEN_MUSHROOM = 10,
    ITEM_BOO_BELL = 11,
    ITEM_BOO_REPELLENT = 12,
    ITEM_BOWSER_SUIT = 13,
    ITEM_MAGIC_LAMP = 14,
    ITEM_KOOPA_KARD = 15,
    ITEM_BARTER_BOX = 16,
    ITEM_LUCKY_CHARM = 17,
    ITEM_WACKY_WATCH = 18,
    ITEMS_END
};
enum ITEM_FUNCTIONS {
    IFUNC_BOO = 0,
    IFUNC_MAGIC_LAMP = 1,
    IFUNC_WARP_BLOCK = 2,
    IFUNC_PLUNDER_CHEST = 3,
    IFUNC_BOWSER_SUIT_BEGIN = 4,
    IFUNC_BOWSER_SUIT_END = 5,
    IFUNC_MUSHROOM = 6,
};
enum PARTNERS {
    PARTNER_NONE = -1,
    PARTNER_KOOPA = 0,
    PARTNER_GOOMBA = 1,
    PARTNER_TOAD = 2,
    PARTNER_BOB_OMB = 3,
    PARTNER_BOO = 4,
    PARTNER_WHOMP = 5,
    PARTNER_SNIFIT = 6,
    PARTNER_PIRANHA_PLANT = 7,
    PARTNER_CHOMP = 8,
    PARTNER_THWOMP = 9,
    PARTNER_MR_BLIZZARD = 10,
    PARTNER_BABY_BOWSER = 11,
};
enum TURN_TIER {
    TURN_TIER_EARLY_GAME,
    TURN_TIER_MID_GAME,
    TURN_TIER_LATE_GAME,
    TURN_TIER_MAX
};
enum MINIGAME_TYPE {
    MINIGAME_4P,
    MINIGAME_1V3,
    MINIGAME_2V2,
    MINIGAME_ITEM,
    MINIGAME_BATTLE,
    MINIGAME_1V1,
    MINIGAME_TYPE_END
};
enum CHARCTERS {
    CHAR_MARIO = 0,
    CHAR_LUIGI = 1,
    CHAR_PEACH = 2,
    CHAR_YOSHI = 3,
    CHAR_WARIO = 4,
    CHAR_DK = 5,
    CHAR_WALUIGI = 6,
    CHAR_DAISY = 7
};
enum SHOP_HOST {
    SHOP_TOAD = 0,
    SHOP_BABY_BOWSER = 1
};
enum CHARACTER_IMAGES {
    CHAR_NONE = -1,
    CHAR_NONE2 = 0,
    CHAR_RED_KOOPA = 1,
    CHAR_GREEN_KOOPA = 2,
    CHAR_TOAD = 3,
    CHAR_BOWSER = 4,
    CHAR_BABY_BOWSER = 5,
    CHAR_GOOMBA = 6,
    CHAR_BOO = 7,
    CHAR_THWOMP = 8,
    CHAR_SNUFIT = 9,
    CHAR_GAME_GUY = 10,
    CHAR_RED_BOB_OMB = 11,
    CHAR_WHOMP = 12,
    CHAR_TOAD_1 = 13,
    CHAR_BLUE_PIPE = 14,
    CHAR_PIPE_UNK = 15,
    CHAR_PIPE_UNK2 = 16,
    CHAR_PIPE_UNK3 = 17,
    CHAR_PIPE_UNK4 = 18,
    CHAR_GREEN_THING = 19,
    CHAR_YELLOW_THING = 20,
    CHAR_TUMBLE = 21,
    CHAR_MILLENIUM_STAR = 22,
    CHAR_KOOPA_GREEN = 23,
    CHAR_GOOMBA_2 = 24,
    CHAR_TOAD_2 = 25,
    CHAR_BOB_OMB = 26,
    CHAR_BOO_2 = 27,
    CHAR_WHOMP_2 = 28,
    CHAR_SNIFIT = 29,
    CHAR_PIRANHA_PLANT = 30,
    CHAR_CHAIN_CHOMP = 31,
    CHAR_THWOMP_2 = 32,
    CHAR_MR_BLIZZARD = 33,
    CHAR_BOWSER_JR = 34,
    CHAR_MUSHROM = 35,
    CHAR_SKELETON_KEY = 36,
    CHAR_POISON_MUSHROOM = 37,
    CHAR_REVERSE_MUSHROOM = 38,
    CHAR_CELLULAR_SHOPPER = 39,
    CHAR_WARP_BLOCK = 40,
    CHAR_PLUNDER_CHEST = 41,
    CHAR_BOWSER_PHONE = 42,
    CHAR_DUELING_GLOVE = 43,
    CHAR_LUCKY_LAMP = 44,
    CHAR_GOLDEN_MUSHROOM = 45,
    CHAR_BOO_BELL = 46,
    CHAR_BOO_REPELLENT = 47,
    CHAR_BOWSER_SUIT = 48,
    CHAR_MAGIC_LAMP = 49,
    CHAR_ITEM_BAG = 50,
    CHAR_KOOPA_KARD = 51,
    CHAR_BARTER_BOX = 52,
    CHAR_GAME_GUY_COIN = 53,
    CHAR_WACKY_WATCH = 54,
    CHAR_MR_BLIZZARD_GIANT = 55,
    CHAR_SKELETON_KEY_2 = 56,
    CHAR_ANGLER_FISH = 57,
    CHAR_BLOOPER = 58,
    CHAR_SUSHI = 59,
    CHAR_JEANIE = 60,
    CHAR_MONTY_MOLE = 61,
    CHAR_WOODY = 62,
    CHAR_WARUKIO = 63
};
enum REV_FLAGS {
    FLAG_REV = 1,
    FLAG_UNK_80 = 0x80
};
typedef struct OverlayTable {
           u8* romStart;
           u8* romEnd;
           u8* vramStart;
           u8* textVramStart;
           u8* textVramEnd;
           u8* dataVramStart;
           u8* dataVramEnd;
           u8* bssVramStart;
           u8* bssVramEnd;
} OverlayTable;
typedef enum {
selmenu2,
hand_line_sinker,
coconut_conk,
spotlight_swim,
boulder_ball,
crazy_cogs,
hide_and_sneak,
ridiculous_relay,
thwomp_pull,
river_raiders,
tidal_toss,
eatsa_pizza,
baby_bowser_broadside,
pump_pump_away,
hyper_hydrants,
picking_panic,
cosmic_coaster,
puddle_paddle,
etch_n_catch,
log_jam,
slot_synch,
treadmill_grill,
toadstool_titan,
aces_high,
bounce_n_trounce,
ice_rink_risk,
locked_out,
chip_shot_challenge,
parasol_plummet,
messy_memory,
picture_imperfect,
marios_puzzle_party,
the_beat_goes_on,
mpiq,
curtain_call,
water_whirled,
fridged_bridges,
awful_tower,
cheep_cheep_chase,
pipe_cleaners,
snowball_summit,
all_fired_up,
stacked_deck,
three_door_monty,
rockin_raceway,
merry_go_chomp,
slapdown,
storm_chasers,
eye_sore,
vine_with_me,
popgun_pickoff,
end_of_the_line,
bowser_toss,
baby_bowser_bonkers,
motor_rooter,
silly_screws,
crowd_cover,
tick_tock_hop,
fowl_play,
winners_wheel,
hey_batter_batter,
bobbing_bow_loons,
dorrie_dip,
swinging_with_sharks,
swing_n_swipe,
stardust_battle,
game_guys_roulette,
game_guys_lucky_7,
game_guys_magic_boxes,
game_guys_sweet_surprise,
dizzy_dinghies,
boardcall,
ChillyWaters,
w02,
w03,
w04,
w05,
w06,
w10,
boardresult,
koopa,
last5,
majinlamp,
opboard,
opboardtutorial,
boardresult2,
mchar,
mchar2,
ovl_boot,
sldebug,
duelcall,
duel01,
duel02,
duel03,
duel04,
duel05,
duel06,
duel10,
duelresult,
duelresult2,
opduel,
opdueltutorial,
storydebug,
slerror,
mgenter,
mgmode,
chancetime,
mstory1,
mstory2,
mstory3,
mstory4,
mstory5,
inst,
mgresultboard,
mgresultdealer,
mgresultduel,
mgresultbattle,
storycall,
meschk,
modesel,
msetup,
filesel,
opening,
option,
staff,
storyresult,
name_7E,
selmenu,
    OVL_COUNT
} OverlayID;
typedef enum {
shared_board,
name_81,
minigame,
    MODE_OVL_COUNT
} ModeOverlayID;
extern OverlayTable _ovltbl[OVL_COUNT];
extern OverlayTable _modeovltbl[MODE_OVL_COUNT];
extern u16 D_800C9520_CA120[];
extern s16 D_800D0590_D1190[];
extern s16 D_800D10F8_D1CF8[];
extern u16 D_800D1350_D1F50[];
extern u16 D_800D5546_D6146[];
extern s8 D_800CBB6E_CC76E[];
extern s16 D_800CDA7C_CE67C[];
extern s8 D_800D20A1_D2CA1[];
void ContDataInit(void);
void ContDataUpdate(void);
extern Addr ChillyWaters_BSS_END;
extern Addr ChillyWaters_BSS_SIZE;
extern Addr ChillyWaters_BSS_START;
extern Addr ChillyWaters_DATA_END;
extern Addr ChillyWaters_DATA_SIZE;
extern Addr ChillyWaters_DATA_START;
extern Addr ChillyWaters_RODATA_END;
extern Addr ChillyWaters_RODATA_SIZE;
extern Addr ChillyWaters_RODATA_START;
extern Addr ChillyWaters_ROM_END;
extern Addr ChillyWaters_ROM_START;
extern Addr ChillyWaters_TEXT_END;
extern Addr ChillyWaters_TEXT_SIZE;
extern Addr ChillyWaters_TEXT_START;
extern Addr ChillyWaters_VRAM;
extern Addr ChillyWaters_VRAM_END;
extern Addr ChillyWaters_bss_VRAM;
extern Addr aces_high_BSS_END;
extern Addr aces_high_BSS_SIZE;
extern Addr aces_high_BSS_START;
extern Addr aces_high_DATA_END;
extern Addr aces_high_DATA_SIZE;
extern Addr aces_high_DATA_START;
extern Addr aces_high_RODATA_END;
extern Addr aces_high_RODATA_SIZE;
extern Addr aces_high_RODATA_START;
extern Addr aces_high_ROM_END;
extern Addr aces_high_ROM_START;
extern Addr aces_high_TEXT_END;
extern Addr aces_high_TEXT_SIZE;
extern Addr aces_high_TEXT_START;
extern Addr aces_high_VRAM;
extern Addr aces_high_VRAM_END;
extern Addr aces_high_bss_VRAM;
extern Addr all_fired_up_BSS_END;
extern Addr all_fired_up_BSS_SIZE;
extern Addr all_fired_up_BSS_START;
extern Addr all_fired_up_DATA_END;
extern Addr all_fired_up_DATA_SIZE;
extern Addr all_fired_up_DATA_START;
extern Addr all_fired_up_RODATA_END;
extern Addr all_fired_up_RODATA_SIZE;
extern Addr all_fired_up_RODATA_START;
extern Addr all_fired_up_ROM_END;
extern Addr all_fired_up_ROM_START;
extern Addr all_fired_up_TEXT_END;
extern Addr all_fired_up_TEXT_SIZE;
extern Addr all_fired_up_TEXT_START;
extern Addr all_fired_up_VRAM;
extern Addr all_fired_up_VRAM_END;
extern Addr all_fired_up_bss_VRAM;
extern Addr audio_fxd0_DATA_END;
extern Addr audio_fxd0_DATA_SIZE;
extern Addr audio_fxd0_DATA_START;
extern Addr audio_fxd0_ROM_END;
extern Addr audio_fxd0_ROM_START;
extern Addr audio_fxd0_VRAM;
extern Addr audio_fxd0_VRAM_END;
extern Addr audio_mbf0_DATA_END;
extern Addr audio_mbf0_DATA_SIZE;
extern Addr audio_mbf0_DATA_START;
extern Addr audio_mbf0_ROM_END;
extern Addr audio_mbf0_ROM_START;
extern Addr audio_mbf0_VRAM;
extern Addr audio_mbf0_VRAM_END;
extern Addr audio_sbf0_DATA_END;
extern Addr audio_sbf0_DATA_SIZE;
extern Addr audio_sbf0_DATA_START;
extern Addr audio_sbf0_ROM_END;
extern Addr audio_sbf0_ROM_START;
extern Addr audio_sbf0_VRAM;
extern Addr audio_sbf0_VRAM_END;
extern Addr awful_tower_BSS_END;
extern Addr awful_tower_BSS_SIZE;
extern Addr awful_tower_BSS_START;
extern Addr awful_tower_DATA_END;
extern Addr awful_tower_DATA_SIZE;
extern Addr awful_tower_DATA_START;
extern Addr awful_tower_RODATA_END;
extern Addr awful_tower_RODATA_SIZE;
extern Addr awful_tower_RODATA_START;
extern Addr awful_tower_ROM_END;
extern Addr awful_tower_ROM_START;
extern Addr awful_tower_TEXT_END;
extern Addr awful_tower_TEXT_SIZE;
extern Addr awful_tower_TEXT_START;
extern Addr awful_tower_VRAM;
extern Addr awful_tower_VRAM_END;
extern Addr awful_tower_bss_VRAM;
extern Addr baby_bowser_bonkers_BSS_END;
extern Addr baby_bowser_bonkers_BSS_SIZE;
extern Addr baby_bowser_bonkers_BSS_START;
extern Addr baby_bowser_bonkers_DATA_END;
extern Addr baby_bowser_bonkers_DATA_SIZE;
extern Addr baby_bowser_bonkers_DATA_START;
extern Addr baby_bowser_bonkers_RODATA_END;
extern Addr baby_bowser_bonkers_RODATA_SIZE;
extern Addr baby_bowser_bonkers_RODATA_START;
extern Addr baby_bowser_bonkers_ROM_END;
extern Addr baby_bowser_bonkers_ROM_START;
extern Addr baby_bowser_bonkers_TEXT_END;
extern Addr baby_bowser_bonkers_TEXT_SIZE;
extern Addr baby_bowser_bonkers_TEXT_START;
extern Addr baby_bowser_bonkers_VRAM;
extern Addr baby_bowser_bonkers_VRAM_END;
extern Addr baby_bowser_bonkers_bss_VRAM;
extern Addr baby_bowser_broadside_BSS_END;
extern Addr baby_bowser_broadside_BSS_SIZE;
extern Addr baby_bowser_broadside_BSS_START;
extern Addr baby_bowser_broadside_DATA_END;
extern Addr baby_bowser_broadside_DATA_SIZE;
extern Addr baby_bowser_broadside_DATA_START;
extern Addr baby_bowser_broadside_RODATA_END;
extern Addr baby_bowser_broadside_RODATA_SIZE;
extern Addr baby_bowser_broadside_RODATA_START;
extern Addr baby_bowser_broadside_ROM_END;
extern Addr baby_bowser_broadside_ROM_START;
extern Addr baby_bowser_broadside_TEXT_END;
extern Addr baby_bowser_broadside_TEXT_SIZE;
extern Addr baby_bowser_broadside_TEXT_START;
extern Addr baby_bowser_broadside_VRAM;
extern Addr baby_bowser_broadside_VRAM_END;
extern Addr baby_bowser_broadside_bss_VRAM;
extern Addr boardcall_BSS_END;
extern Addr boardcall_BSS_SIZE;
extern Addr boardcall_BSS_START;
extern Addr boardcall_DATA_END;
extern Addr boardcall_DATA_SIZE;
extern Addr boardcall_DATA_START;
extern Addr boardcall_RODATA_END;
extern Addr boardcall_RODATA_SIZE;
extern Addr boardcall_RODATA_START;
extern Addr boardcall_ROM_END;
extern Addr boardcall_ROM_START;
extern Addr boardcall_TEXT_END;
extern Addr boardcall_TEXT_SIZE;
extern Addr boardcall_TEXT_START;
extern Addr boardcall_VRAM;
extern Addr boardcall_VRAM_END;
extern Addr boardcall_bss_VRAM;
extern Addr boardresult2_BSS_END;
extern Addr boardresult2_BSS_SIZE;
extern Addr boardresult2_BSS_START;
extern Addr boardresult2_DATA_END;
extern Addr boardresult2_DATA_SIZE;
extern Addr boardresult2_DATA_START;
extern Addr boardresult2_RODATA_END;
extern Addr boardresult2_RODATA_SIZE;
extern Addr boardresult2_RODATA_START;
extern Addr boardresult2_ROM_END;
extern Addr boardresult2_ROM_START;
extern Addr boardresult2_TEXT_END;
extern Addr boardresult2_TEXT_SIZE;
extern Addr boardresult2_TEXT_START;
extern Addr boardresult2_VRAM;
extern Addr boardresult2_VRAM_END;
extern Addr boardresult2_bss_VRAM;
extern Addr boardresult_BSS_END;
extern Addr boardresult_BSS_SIZE;
extern Addr boardresult_BSS_START;
extern Addr boardresult_DATA_END;
extern Addr boardresult_DATA_SIZE;
extern Addr boardresult_DATA_START;
extern Addr boardresult_RODATA_END;
extern Addr boardresult_RODATA_SIZE;
extern Addr boardresult_RODATA_START;
extern Addr boardresult_ROM_END;
extern Addr boardresult_ROM_START;
extern Addr boardresult_TEXT_END;
extern Addr boardresult_TEXT_SIZE;
extern Addr boardresult_TEXT_START;
extern Addr boardresult_VRAM;
extern Addr boardresult_VRAM_END;
extern Addr boardresult_bss_VRAM;
extern Addr bobbing_bow_loons_BSS_END;
extern Addr bobbing_bow_loons_BSS_SIZE;
extern Addr bobbing_bow_loons_BSS_START;
extern Addr bobbing_bow_loons_DATA_END;
extern Addr bobbing_bow_loons_DATA_SIZE;
extern Addr bobbing_bow_loons_DATA_START;
extern Addr bobbing_bow_loons_RODATA_END;
extern Addr bobbing_bow_loons_RODATA_SIZE;
extern Addr bobbing_bow_loons_RODATA_START;
extern Addr bobbing_bow_loons_ROM_END;
extern Addr bobbing_bow_loons_ROM_START;
extern Addr bobbing_bow_loons_TEXT_END;
extern Addr bobbing_bow_loons_TEXT_SIZE;
extern Addr bobbing_bow_loons_TEXT_START;
extern Addr bobbing_bow_loons_VRAM;
extern Addr bobbing_bow_loons_VRAM_END;
extern Addr bobbing_bow_loons_bss_VRAM;
extern Addr boot_DATA_END;
extern Addr boot_DATA_SIZE;
extern Addr boot_DATA_START;
extern Addr boot_ROM_END;
extern Addr boot_ROM_START;
extern Addr boot_VRAM;
extern Addr boot_VRAM_END;
extern Addr boulder_ball_BSS_END;
extern Addr boulder_ball_BSS_SIZE;
extern Addr boulder_ball_BSS_START;
extern Addr boulder_ball_DATA_END;
extern Addr boulder_ball_DATA_SIZE;
extern Addr boulder_ball_DATA_START;
extern Addr boulder_ball_RODATA_END;
extern Addr boulder_ball_RODATA_SIZE;
extern Addr boulder_ball_RODATA_START;
extern Addr boulder_ball_ROM_END;
extern Addr boulder_ball_ROM_START;
extern Addr boulder_ball_TEXT_END;
extern Addr boulder_ball_TEXT_SIZE;
extern Addr boulder_ball_TEXT_START;
extern Addr boulder_ball_VRAM;
extern Addr boulder_ball_VRAM_END;
extern Addr boulder_ball_bss_VRAM;
extern Addr bounce_n_trounce_BSS_END;
extern Addr bounce_n_trounce_BSS_SIZE;
extern Addr bounce_n_trounce_BSS_START;
extern Addr bounce_n_trounce_DATA_END;
extern Addr bounce_n_trounce_DATA_SIZE;
extern Addr bounce_n_trounce_DATA_START;
extern Addr bounce_n_trounce_RODATA_END;
extern Addr bounce_n_trounce_RODATA_SIZE;
extern Addr bounce_n_trounce_RODATA_START;
extern Addr bounce_n_trounce_ROM_END;
extern Addr bounce_n_trounce_ROM_START;
extern Addr bounce_n_trounce_TEXT_END;
extern Addr bounce_n_trounce_TEXT_SIZE;
extern Addr bounce_n_trounce_TEXT_START;
extern Addr bounce_n_trounce_VRAM;
extern Addr bounce_n_trounce_VRAM_END;
extern Addr bounce_n_trounce_bss_VRAM;
extern Addr bowser_toss_BSS_END;
extern Addr bowser_toss_BSS_SIZE;
extern Addr bowser_toss_BSS_START;
extern Addr bowser_toss_DATA_END;
extern Addr bowser_toss_DATA_SIZE;
extern Addr bowser_toss_DATA_START;
extern Addr bowser_toss_RODATA_END;
extern Addr bowser_toss_RODATA_SIZE;
extern Addr bowser_toss_RODATA_START;
extern Addr bowser_toss_ROM_END;
extern Addr bowser_toss_ROM_START;
extern Addr bowser_toss_TEXT_END;
extern Addr bowser_toss_TEXT_SIZE;
extern Addr bowser_toss_TEXT_START;
extern Addr bowser_toss_VRAM;
extern Addr bowser_toss_VRAM_END;
extern Addr bowser_toss_bss_VRAM;
extern Addr chancetime_BSS_END;
extern Addr chancetime_BSS_SIZE;
extern Addr chancetime_BSS_START;
extern Addr chancetime_DATA_END;
extern Addr chancetime_DATA_SIZE;
extern Addr chancetime_DATA_START;
extern Addr chancetime_RODATA_END;
extern Addr chancetime_RODATA_SIZE;
extern Addr chancetime_RODATA_START;
extern Addr chancetime_ROM_END;
extern Addr chancetime_ROM_START;
extern Addr chancetime_TEXT_END;
extern Addr chancetime_TEXT_SIZE;
extern Addr chancetime_TEXT_START;
extern Addr chancetime_VRAM;
extern Addr chancetime_VRAM_END;
extern Addr chancetime_bss_VRAM;
extern Addr cheep_cheep_chase_BSS_END;
extern Addr cheep_cheep_chase_BSS_SIZE;
extern Addr cheep_cheep_chase_BSS_START;
extern Addr cheep_cheep_chase_DATA_END;
extern Addr cheep_cheep_chase_DATA_SIZE;
extern Addr cheep_cheep_chase_DATA_START;
extern Addr cheep_cheep_chase_RODATA_END;
extern Addr cheep_cheep_chase_RODATA_SIZE;
extern Addr cheep_cheep_chase_RODATA_START;
extern Addr cheep_cheep_chase_ROM_END;
extern Addr cheep_cheep_chase_ROM_START;
extern Addr cheep_cheep_chase_TEXT_END;
extern Addr cheep_cheep_chase_TEXT_SIZE;
extern Addr cheep_cheep_chase_TEXT_START;
extern Addr cheep_cheep_chase_VRAM;
extern Addr cheep_cheep_chase_VRAM_END;
extern Addr cheep_cheep_chase_bss_VRAM;
extern Addr chip_shot_challenge_BSS_END;
extern Addr chip_shot_challenge_BSS_SIZE;
extern Addr chip_shot_challenge_BSS_START;
extern Addr chip_shot_challenge_DATA_END;
extern Addr chip_shot_challenge_DATA_SIZE;
extern Addr chip_shot_challenge_DATA_START;
extern Addr chip_shot_challenge_RODATA_END;
extern Addr chip_shot_challenge_RODATA_SIZE;
extern Addr chip_shot_challenge_RODATA_START;
extern Addr chip_shot_challenge_ROM_END;
extern Addr chip_shot_challenge_ROM_START;
extern Addr chip_shot_challenge_TEXT_END;
extern Addr chip_shot_challenge_TEXT_SIZE;
extern Addr chip_shot_challenge_TEXT_START;
extern Addr chip_shot_challenge_VRAM;
extern Addr chip_shot_challenge_VRAM_END;
extern Addr chip_shot_challenge_bss_VRAM;
extern Addr coconut_conk_BSS_END;
extern Addr coconut_conk_BSS_SIZE;
extern Addr coconut_conk_BSS_START;
extern Addr coconut_conk_DATA_END;
extern Addr coconut_conk_DATA_SIZE;
extern Addr coconut_conk_DATA_START;
extern Addr coconut_conk_RODATA_END;
extern Addr coconut_conk_RODATA_SIZE;
extern Addr coconut_conk_RODATA_START;
extern Addr coconut_conk_ROM_END;
extern Addr coconut_conk_ROM_START;
extern Addr coconut_conk_TEXT_END;
extern Addr coconut_conk_TEXT_SIZE;
extern Addr coconut_conk_TEXT_START;
extern Addr coconut_conk_VRAM;
extern Addr coconut_conk_VRAM_END;
extern Addr coconut_conk_bss_VRAM;
extern Addr cosmic_coaster_BSS_END;
extern Addr cosmic_coaster_BSS_SIZE;
extern Addr cosmic_coaster_BSS_START;
extern Addr cosmic_coaster_DATA_END;
extern Addr cosmic_coaster_DATA_SIZE;
extern Addr cosmic_coaster_DATA_START;
extern Addr cosmic_coaster_RODATA_END;
extern Addr cosmic_coaster_RODATA_SIZE;
extern Addr cosmic_coaster_RODATA_START;
extern Addr cosmic_coaster_ROM_END;
extern Addr cosmic_coaster_ROM_START;
extern Addr cosmic_coaster_TEXT_END;
extern Addr cosmic_coaster_TEXT_SIZE;
extern Addr cosmic_coaster_TEXT_START;
extern Addr cosmic_coaster_VRAM;
extern Addr cosmic_coaster_VRAM_END;
extern Addr cosmic_coaster_bss_VRAM;
extern Addr crazy_cogs_BSS_END;
extern Addr crazy_cogs_BSS_SIZE;
extern Addr crazy_cogs_BSS_START;
extern Addr crazy_cogs_DATA_END;
extern Addr crazy_cogs_DATA_SIZE;
extern Addr crazy_cogs_DATA_START;
extern Addr crazy_cogs_RODATA_END;
extern Addr crazy_cogs_RODATA_SIZE;
extern Addr crazy_cogs_RODATA_START;
extern Addr crazy_cogs_ROM_END;
extern Addr crazy_cogs_ROM_START;
extern Addr crazy_cogs_TEXT_END;
extern Addr crazy_cogs_TEXT_SIZE;
extern Addr crazy_cogs_TEXT_START;
extern Addr crazy_cogs_VRAM;
extern Addr crazy_cogs_VRAM_END;
extern Addr crazy_cogs_bss_VRAM;
extern Addr crowd_cover_BSS_END;
extern Addr crowd_cover_BSS_SIZE;
extern Addr crowd_cover_BSS_START;
extern Addr crowd_cover_DATA_END;
extern Addr crowd_cover_DATA_SIZE;
extern Addr crowd_cover_DATA_START;
extern Addr crowd_cover_RODATA_END;
extern Addr crowd_cover_RODATA_SIZE;
extern Addr crowd_cover_RODATA_START;
extern Addr crowd_cover_ROM_END;
extern Addr crowd_cover_ROM_START;
extern Addr crowd_cover_TEXT_END;
extern Addr crowd_cover_TEXT_SIZE;
extern Addr crowd_cover_TEXT_START;
extern Addr crowd_cover_VRAM;
extern Addr crowd_cover_VRAM_END;
extern Addr crowd_cover_bss_VRAM;
extern Addr curtain_call_BSS_END;
extern Addr curtain_call_BSS_SIZE;
extern Addr curtain_call_BSS_START;
extern Addr curtain_call_DATA_END;
extern Addr curtain_call_DATA_SIZE;
extern Addr curtain_call_DATA_START;
extern Addr curtain_call_RODATA_END;
extern Addr curtain_call_RODATA_SIZE;
extern Addr curtain_call_RODATA_START;
extern Addr curtain_call_ROM_END;
extern Addr curtain_call_ROM_START;
extern Addr curtain_call_TEXT_END;
extern Addr curtain_call_TEXT_SIZE;
extern Addr curtain_call_TEXT_START;
extern Addr curtain_call_VRAM;
extern Addr curtain_call_VRAM_END;
extern Addr curtain_call_bss_VRAM;
extern Addr dizzy_dinghies_BSS_END;
extern Addr dizzy_dinghies_BSS_SIZE;
extern Addr dizzy_dinghies_BSS_START;
extern Addr dizzy_dinghies_DATA_END;
extern Addr dizzy_dinghies_DATA_SIZE;
extern Addr dizzy_dinghies_DATA_START;
extern Addr dizzy_dinghies_RODATA_END;
extern Addr dizzy_dinghies_RODATA_SIZE;
extern Addr dizzy_dinghies_RODATA_START;
extern Addr dizzy_dinghies_ROM_END;
extern Addr dizzy_dinghies_ROM_START;
extern Addr dizzy_dinghies_TEXT_END;
extern Addr dizzy_dinghies_TEXT_SIZE;
extern Addr dizzy_dinghies_TEXT_START;
extern Addr dizzy_dinghies_VRAM;
extern Addr dizzy_dinghies_VRAM_END;
extern Addr dizzy_dinghies_bss_VRAM;
extern Addr dorrie_dip_BSS_END;
extern Addr dorrie_dip_BSS_SIZE;
extern Addr dorrie_dip_BSS_START;
extern Addr dorrie_dip_DATA_END;
extern Addr dorrie_dip_DATA_SIZE;
extern Addr dorrie_dip_DATA_START;
extern Addr dorrie_dip_RODATA_END;
extern Addr dorrie_dip_RODATA_SIZE;
extern Addr dorrie_dip_RODATA_START;
extern Addr dorrie_dip_ROM_END;
extern Addr dorrie_dip_ROM_START;
extern Addr dorrie_dip_TEXT_END;
extern Addr dorrie_dip_TEXT_SIZE;
extern Addr dorrie_dip_TEXT_START;
extern Addr dorrie_dip_VRAM;
extern Addr dorrie_dip_VRAM_END;
extern Addr dorrie_dip_bss_VRAM;
extern Addr duel01_BSS_END;
extern Addr duel01_BSS_SIZE;
extern Addr duel01_BSS_START;
extern Addr duel01_DATA_END;
extern Addr duel01_DATA_SIZE;
extern Addr duel01_DATA_START;
extern Addr duel01_RODATA_END;
extern Addr duel01_RODATA_SIZE;
extern Addr duel01_RODATA_START;
extern Addr duel01_ROM_END;
extern Addr duel01_ROM_START;
extern Addr duel01_TEXT_END;
extern Addr duel01_TEXT_SIZE;
extern Addr duel01_TEXT_START;
extern Addr duel01_VRAM;
extern Addr duel01_VRAM_END;
extern Addr duel01_bss_VRAM;
extern Addr duel02_BSS_END;
extern Addr duel02_BSS_SIZE;
extern Addr duel02_BSS_START;
extern Addr duel02_DATA_END;
extern Addr duel02_DATA_SIZE;
extern Addr duel02_DATA_START;
extern Addr duel02_RODATA_END;
extern Addr duel02_RODATA_SIZE;
extern Addr duel02_RODATA_START;
extern Addr duel02_ROM_END;
extern Addr duel02_ROM_START;
extern Addr duel02_TEXT_END;
extern Addr duel02_TEXT_SIZE;
extern Addr duel02_TEXT_START;
extern Addr duel02_VRAM;
extern Addr duel02_VRAM_END;
extern Addr duel02_bss_VRAM;
extern Addr duel03_BSS_END;
extern Addr duel03_BSS_SIZE;
extern Addr duel03_BSS_START;
extern Addr duel03_DATA_END;
extern Addr duel03_DATA_SIZE;
extern Addr duel03_DATA_START;
extern Addr duel03_RODATA_END;
extern Addr duel03_RODATA_SIZE;
extern Addr duel03_RODATA_START;
extern Addr duel03_ROM_END;
extern Addr duel03_ROM_START;
extern Addr duel03_TEXT_END;
extern Addr duel03_TEXT_SIZE;
extern Addr duel03_TEXT_START;
extern Addr duel03_VRAM;
extern Addr duel03_VRAM_END;
extern Addr duel03_bss_VRAM;
extern Addr duel04_BSS_END;
extern Addr duel04_BSS_SIZE;
extern Addr duel04_BSS_START;
extern Addr duel04_DATA_END;
extern Addr duel04_DATA_SIZE;
extern Addr duel04_DATA_START;
extern Addr duel04_RODATA_END;
extern Addr duel04_RODATA_SIZE;
extern Addr duel04_RODATA_START;
extern Addr duel04_ROM_END;
extern Addr duel04_ROM_START;
extern Addr duel04_TEXT_END;
extern Addr duel04_TEXT_SIZE;
extern Addr duel04_TEXT_START;
extern Addr duel04_VRAM;
extern Addr duel04_VRAM_END;
extern Addr duel04_bss_VRAM;
extern Addr duel05_BSS_END;
extern Addr duel05_BSS_SIZE;
extern Addr duel05_BSS_START;
extern Addr duel05_DATA_END;
extern Addr duel05_DATA_SIZE;
extern Addr duel05_DATA_START;
extern Addr duel05_RODATA_END;
extern Addr duel05_RODATA_SIZE;
extern Addr duel05_RODATA_START;
extern Addr duel05_ROM_END;
extern Addr duel05_ROM_START;
extern Addr duel05_TEXT_END;
extern Addr duel05_TEXT_SIZE;
extern Addr duel05_TEXT_START;
extern Addr duel05_VRAM;
extern Addr duel05_VRAM_END;
extern Addr duel05_bss_VRAM;
extern Addr duel06_BSS_END;
extern Addr duel06_BSS_SIZE;
extern Addr duel06_BSS_START;
extern Addr duel06_DATA_END;
extern Addr duel06_DATA_SIZE;
extern Addr duel06_DATA_START;
extern Addr duel06_RODATA_END;
extern Addr duel06_RODATA_SIZE;
extern Addr duel06_RODATA_START;
extern Addr duel06_ROM_END;
extern Addr duel06_ROM_START;
extern Addr duel06_TEXT_END;
extern Addr duel06_TEXT_SIZE;
extern Addr duel06_TEXT_START;
extern Addr duel06_VRAM;
extern Addr duel06_VRAM_END;
extern Addr duel06_bss_VRAM;
extern Addr duel10_BSS_END;
extern Addr duel10_BSS_SIZE;
extern Addr duel10_BSS_START;
extern Addr duel10_DATA_END;
extern Addr duel10_DATA_SIZE;
extern Addr duel10_DATA_START;
extern Addr duel10_RODATA_END;
extern Addr duel10_RODATA_SIZE;
extern Addr duel10_RODATA_START;
extern Addr duel10_ROM_END;
extern Addr duel10_ROM_START;
extern Addr duel10_TEXT_END;
extern Addr duel10_TEXT_SIZE;
extern Addr duel10_TEXT_START;
extern Addr duel10_VRAM;
extern Addr duel10_VRAM_END;
extern Addr duel10_bss_VRAM;
extern Addr duelcall_BSS_END;
extern Addr duelcall_BSS_SIZE;
extern Addr duelcall_BSS_START;
extern Addr duelcall_DATA_END;
extern Addr duelcall_DATA_SIZE;
extern Addr duelcall_DATA_START;
extern Addr duelcall_RODATA_END;
extern Addr duelcall_RODATA_SIZE;
extern Addr duelcall_RODATA_START;
extern Addr duelcall_ROM_END;
extern Addr duelcall_ROM_START;
extern Addr duelcall_TEXT_END;
extern Addr duelcall_TEXT_SIZE;
extern Addr duelcall_TEXT_START;
extern Addr duelcall_VRAM;
extern Addr duelcall_VRAM_END;
extern Addr duelcall_bss_VRAM;
extern Addr duelresult2_BSS_END;
extern Addr duelresult2_BSS_SIZE;
extern Addr duelresult2_BSS_START;
extern Addr duelresult2_DATA_END;
extern Addr duelresult2_DATA_SIZE;
extern Addr duelresult2_DATA_START;
extern Addr duelresult2_RODATA_END;
extern Addr duelresult2_RODATA_SIZE;
extern Addr duelresult2_RODATA_START;
extern Addr duelresult2_ROM_END;
extern Addr duelresult2_ROM_START;
extern Addr duelresult2_TEXT_END;
extern Addr duelresult2_TEXT_SIZE;
extern Addr duelresult2_TEXT_START;
extern Addr duelresult2_VRAM;
extern Addr duelresult2_VRAM_END;
extern Addr duelresult2_bss_VRAM;
extern Addr duelresult_BSS_END;
extern Addr duelresult_BSS_SIZE;
extern Addr duelresult_BSS_START;
extern Addr duelresult_DATA_END;
extern Addr duelresult_DATA_SIZE;
extern Addr duelresult_DATA_START;
extern Addr duelresult_RODATA_END;
extern Addr duelresult_RODATA_SIZE;
extern Addr duelresult_RODATA_START;
extern Addr duelresult_ROM_END;
extern Addr duelresult_ROM_START;
extern Addr duelresult_TEXT_END;
extern Addr duelresult_TEXT_SIZE;
extern Addr duelresult_TEXT_START;
extern Addr duelresult_VRAM;
extern Addr duelresult_VRAM_END;
extern Addr duelresult_bss_VRAM;
extern Addr eatsa_pizza_BSS_END;
extern Addr eatsa_pizza_BSS_SIZE;
extern Addr eatsa_pizza_BSS_START;
extern Addr eatsa_pizza_DATA_END;
extern Addr eatsa_pizza_DATA_SIZE;
extern Addr eatsa_pizza_DATA_START;
extern Addr eatsa_pizza_RODATA_END;
extern Addr eatsa_pizza_RODATA_SIZE;
extern Addr eatsa_pizza_RODATA_START;
extern Addr eatsa_pizza_ROM_END;
extern Addr eatsa_pizza_ROM_START;
extern Addr eatsa_pizza_TEXT_END;
extern Addr eatsa_pizza_TEXT_SIZE;
extern Addr eatsa_pizza_TEXT_START;
extern Addr eatsa_pizza_VRAM;
extern Addr eatsa_pizza_VRAM_END;
extern Addr eatsa_pizza_bss_VRAM;
extern Addr end_of_the_line_BSS_END;
extern Addr end_of_the_line_BSS_SIZE;
extern Addr end_of_the_line_BSS_START;
extern Addr end_of_the_line_DATA_END;
extern Addr end_of_the_line_DATA_SIZE;
extern Addr end_of_the_line_DATA_START;
extern Addr end_of_the_line_RODATA_END;
extern Addr end_of_the_line_RODATA_SIZE;
extern Addr end_of_the_line_RODATA_START;
extern Addr end_of_the_line_ROM_END;
extern Addr end_of_the_line_ROM_START;
extern Addr end_of_the_line_TEXT_END;
extern Addr end_of_the_line_TEXT_SIZE;
extern Addr end_of_the_line_TEXT_START;
extern Addr end_of_the_line_VRAM;
extern Addr end_of_the_line_VRAM_END;
extern Addr end_of_the_line_bss_VRAM;
extern Addr entry_BSS_END;
extern Addr entry_BSS_SIZE;
extern Addr entry_BSS_START;
extern Addr entry_DATA_END;
extern Addr entry_DATA_SIZE;
extern Addr entry_DATA_START;
extern Addr entry_RODATA_END;
extern Addr entry_RODATA_SIZE;
extern Addr entry_RODATA_START;
extern Addr entry_ROM_END;
extern Addr entry_ROM_START;
extern Addr entry_TEXT_END;
extern Addr entry_TEXT_SIZE;
extern Addr entry_TEXT_START;
extern Addr entry_VRAM;
extern Addr entry_VRAM_END;
extern Addr entry_bss_VRAM;
extern Addr etch_n_catch_BSS_END;
extern Addr etch_n_catch_BSS_SIZE;
extern Addr etch_n_catch_BSS_START;
extern Addr etch_n_catch_DATA_END;
extern Addr etch_n_catch_DATA_SIZE;
extern Addr etch_n_catch_DATA_START;
extern Addr etch_n_catch_RODATA_END;
extern Addr etch_n_catch_RODATA_SIZE;
extern Addr etch_n_catch_RODATA_START;
extern Addr etch_n_catch_ROM_END;
extern Addr etch_n_catch_ROM_START;
extern Addr etch_n_catch_TEXT_END;
extern Addr etch_n_catch_TEXT_SIZE;
extern Addr etch_n_catch_TEXT_START;
extern Addr etch_n_catch_VRAM;
extern Addr etch_n_catch_VRAM_END;
extern Addr etch_n_catch_bss_VRAM;
extern Addr eye_sore_BSS_END;
extern Addr eye_sore_BSS_SIZE;
extern Addr eye_sore_BSS_START;
extern Addr eye_sore_DATA_END;
extern Addr eye_sore_DATA_SIZE;
extern Addr eye_sore_DATA_START;
extern Addr eye_sore_RODATA_END;
extern Addr eye_sore_RODATA_SIZE;
extern Addr eye_sore_RODATA_START;
extern Addr eye_sore_ROM_END;
extern Addr eye_sore_ROM_START;
extern Addr eye_sore_TEXT_END;
extern Addr eye_sore_TEXT_SIZE;
extern Addr eye_sore_TEXT_START;
extern Addr eye_sore_VRAM;
extern Addr eye_sore_VRAM_END;
extern Addr eye_sore_bss_VRAM;
extern Addr filesel_BSS_END;
extern Addr filesel_BSS_SIZE;
extern Addr filesel_BSS_START;
extern Addr filesel_DATA_END;
extern Addr filesel_DATA_SIZE;
extern Addr filesel_DATA_START;
extern Addr filesel_RODATA_END;
extern Addr filesel_RODATA_SIZE;
extern Addr filesel_RODATA_START;
extern Addr filesel_ROM_END;
extern Addr filesel_ROM_START;
extern Addr filesel_TEXT_END;
extern Addr filesel_TEXT_SIZE;
extern Addr filesel_TEXT_START;
extern Addr filesel_VRAM;
extern Addr filesel_VRAM_END;
extern Addr filesel_bss_VRAM;
extern Addr fowl_play_BSS_END;
extern Addr fowl_play_BSS_SIZE;
extern Addr fowl_play_BSS_START;
extern Addr fowl_play_DATA_END;
extern Addr fowl_play_DATA_SIZE;
extern Addr fowl_play_DATA_START;
extern Addr fowl_play_RODATA_END;
extern Addr fowl_play_RODATA_SIZE;
extern Addr fowl_play_RODATA_START;
extern Addr fowl_play_ROM_END;
extern Addr fowl_play_ROM_START;
extern Addr fowl_play_TEXT_END;
extern Addr fowl_play_TEXT_SIZE;
extern Addr fowl_play_TEXT_START;
extern Addr fowl_play_VRAM;
extern Addr fowl_play_VRAM_END;
extern Addr fowl_play_bss_VRAM;
extern Addr fridged_bridges_BSS_END;
extern Addr fridged_bridges_BSS_SIZE;
extern Addr fridged_bridges_BSS_START;
extern Addr fridged_bridges_DATA_END;
extern Addr fridged_bridges_DATA_SIZE;
extern Addr fridged_bridges_DATA_START;
extern Addr fridged_bridges_RODATA_END;
extern Addr fridged_bridges_RODATA_SIZE;
extern Addr fridged_bridges_RODATA_START;
extern Addr fridged_bridges_ROM_END;
extern Addr fridged_bridges_ROM_START;
extern Addr fridged_bridges_TEXT_END;
extern Addr fridged_bridges_TEXT_SIZE;
extern Addr fridged_bridges_TEXT_START;
extern Addr fridged_bridges_VRAM;
extern Addr fridged_bridges_VRAM_END;
extern Addr fridged_bridges_bss_VRAM;
extern Addr game_guys_lucky_7_BSS_END;
extern Addr game_guys_lucky_7_BSS_SIZE;
extern Addr game_guys_lucky_7_BSS_START;
extern Addr game_guys_lucky_7_DATA_END;
extern Addr game_guys_lucky_7_DATA_SIZE;
extern Addr game_guys_lucky_7_DATA_START;
extern Addr game_guys_lucky_7_RODATA_END;
extern Addr game_guys_lucky_7_RODATA_SIZE;
extern Addr game_guys_lucky_7_RODATA_START;
extern Addr game_guys_lucky_7_ROM_END;
extern Addr game_guys_lucky_7_ROM_START;
extern Addr game_guys_lucky_7_TEXT_END;
extern Addr game_guys_lucky_7_TEXT_SIZE;
extern Addr game_guys_lucky_7_TEXT_START;
extern Addr game_guys_lucky_7_VRAM;
extern Addr game_guys_lucky_7_VRAM_END;
extern Addr game_guys_lucky_7_bss_VRAM;
extern Addr game_guys_magic_boxes_BSS_END;
extern Addr game_guys_magic_boxes_BSS_SIZE;
extern Addr game_guys_magic_boxes_BSS_START;
extern Addr game_guys_magic_boxes_DATA_END;
extern Addr game_guys_magic_boxes_DATA_SIZE;
extern Addr game_guys_magic_boxes_DATA_START;
extern Addr game_guys_magic_boxes_RODATA_END;
extern Addr game_guys_magic_boxes_RODATA_SIZE;
extern Addr game_guys_magic_boxes_RODATA_START;
extern Addr game_guys_magic_boxes_ROM_END;
extern Addr game_guys_magic_boxes_ROM_START;
extern Addr game_guys_magic_boxes_TEXT_END;
extern Addr game_guys_magic_boxes_TEXT_SIZE;
extern Addr game_guys_magic_boxes_TEXT_START;
extern Addr game_guys_magic_boxes_VRAM;
extern Addr game_guys_magic_boxes_VRAM_END;
extern Addr game_guys_magic_boxes_bss_VRAM;
extern Addr game_guys_roulette_BSS_END;
extern Addr game_guys_roulette_BSS_SIZE;
extern Addr game_guys_roulette_BSS_START;
extern Addr game_guys_roulette_DATA_END;
extern Addr game_guys_roulette_DATA_SIZE;
extern Addr game_guys_roulette_DATA_START;
extern Addr game_guys_roulette_RODATA_END;
extern Addr game_guys_roulette_RODATA_SIZE;
extern Addr game_guys_roulette_RODATA_START;
extern Addr game_guys_roulette_ROM_END;
extern Addr game_guys_roulette_ROM_START;
extern Addr game_guys_roulette_TEXT_END;
extern Addr game_guys_roulette_TEXT_SIZE;
extern Addr game_guys_roulette_TEXT_START;
extern Addr game_guys_roulette_VRAM;
extern Addr game_guys_roulette_VRAM_END;
extern Addr game_guys_roulette_bss_VRAM;
extern Addr game_guys_sweet_surprise_BSS_END;
extern Addr game_guys_sweet_surprise_BSS_SIZE;
extern Addr game_guys_sweet_surprise_BSS_START;
extern Addr game_guys_sweet_surprise_DATA_END;
extern Addr game_guys_sweet_surprise_DATA_SIZE;
extern Addr game_guys_sweet_surprise_DATA_START;
extern Addr game_guys_sweet_surprise_RODATA_END;
extern Addr game_guys_sweet_surprise_RODATA_SIZE;
extern Addr game_guys_sweet_surprise_RODATA_START;
extern Addr game_guys_sweet_surprise_ROM_END;
extern Addr game_guys_sweet_surprise_ROM_START;
extern Addr game_guys_sweet_surprise_TEXT_END;
extern Addr game_guys_sweet_surprise_TEXT_SIZE;
extern Addr game_guys_sweet_surprise_TEXT_START;
extern Addr game_guys_sweet_surprise_VRAM;
extern Addr game_guys_sweet_surprise_VRAM_END;
extern Addr game_guys_sweet_surprise_bss_VRAM;
extern Addr hand_line_sinker_BSS_END;
extern Addr hand_line_sinker_BSS_SIZE;
extern Addr hand_line_sinker_BSS_START;
extern Addr hand_line_sinker_DATA_END;
extern Addr hand_line_sinker_DATA_SIZE;
extern Addr hand_line_sinker_DATA_START;
extern Addr hand_line_sinker_RODATA_END;
extern Addr hand_line_sinker_RODATA_SIZE;
extern Addr hand_line_sinker_RODATA_START;
extern Addr hand_line_sinker_ROM_END;
extern Addr hand_line_sinker_ROM_START;
extern Addr hand_line_sinker_TEXT_END;
extern Addr hand_line_sinker_TEXT_SIZE;
extern Addr hand_line_sinker_TEXT_START;
extern Addr hand_line_sinker_VRAM;
extern Addr hand_line_sinker_VRAM_END;
extern Addr hand_line_sinker_bss_VRAM;
extern Addr header_DATA_END;
extern Addr header_DATA_SIZE;
extern Addr header_DATA_START;
extern Addr header_ROM_END;
extern Addr header_ROM_START;
extern Addr header_VRAM;
extern Addr header_VRAM_END;
extern Addr hey_batter_batter_BSS_END;
extern Addr hey_batter_batter_BSS_SIZE;
extern Addr hey_batter_batter_BSS_START;
extern Addr hey_batter_batter_DATA_END;
extern Addr hey_batter_batter_DATA_SIZE;
extern Addr hey_batter_batter_DATA_START;
extern Addr hey_batter_batter_RODATA_END;
extern Addr hey_batter_batter_RODATA_SIZE;
extern Addr hey_batter_batter_RODATA_START;
extern Addr hey_batter_batter_ROM_END;
extern Addr hey_batter_batter_ROM_START;
extern Addr hey_batter_batter_TEXT_END;
extern Addr hey_batter_batter_TEXT_SIZE;
extern Addr hey_batter_batter_TEXT_START;
extern Addr hey_batter_batter_VRAM;
extern Addr hey_batter_batter_VRAM_END;
extern Addr hey_batter_batter_bss_VRAM;
extern Addr hide_and_sneak_BSS_END;
extern Addr hide_and_sneak_BSS_SIZE;
extern Addr hide_and_sneak_BSS_START;
extern Addr hide_and_sneak_DATA_END;
extern Addr hide_and_sneak_DATA_SIZE;
extern Addr hide_and_sneak_DATA_START;
extern Addr hide_and_sneak_RODATA_END;
extern Addr hide_and_sneak_RODATA_SIZE;
extern Addr hide_and_sneak_RODATA_START;
extern Addr hide_and_sneak_ROM_END;
extern Addr hide_and_sneak_ROM_START;
extern Addr hide_and_sneak_TEXT_END;
extern Addr hide_and_sneak_TEXT_SIZE;
extern Addr hide_and_sneak_TEXT_START;
extern Addr hide_and_sneak_VRAM;
extern Addr hide_and_sneak_VRAM_END;
extern Addr hide_and_sneak_bss_VRAM;
extern Addr hvq_data_DATA_END;
extern Addr hvq_data_DATA_SIZE;
extern Addr hvq_data_DATA_START;
extern Addr hvq_data_ROM_END;
extern Addr hvq_data_ROM_START;
extern Addr hvq_data_VRAM;
extern Addr hvq_data_VRAM_END;
extern Addr hyper_hydrants_BSS_END;
extern Addr hyper_hydrants_BSS_SIZE;
extern Addr hyper_hydrants_BSS_START;
extern Addr hyper_hydrants_DATA_END;
extern Addr hyper_hydrants_DATA_SIZE;
extern Addr hyper_hydrants_DATA_START;
extern Addr hyper_hydrants_RODATA_END;
extern Addr hyper_hydrants_RODATA_SIZE;
extern Addr hyper_hydrants_RODATA_START;
extern Addr hyper_hydrants_ROM_END;
extern Addr hyper_hydrants_ROM_START;
extern Addr hyper_hydrants_TEXT_END;
extern Addr hyper_hydrants_TEXT_SIZE;
extern Addr hyper_hydrants_TEXT_START;
extern Addr hyper_hydrants_VRAM;
extern Addr hyper_hydrants_VRAM_END;
extern Addr hyper_hydrants_bss_VRAM;
extern Addr ice_rink_risk_BSS_END;
extern Addr ice_rink_risk_BSS_SIZE;
extern Addr ice_rink_risk_BSS_START;
extern Addr ice_rink_risk_DATA_END;
extern Addr ice_rink_risk_DATA_SIZE;
extern Addr ice_rink_risk_DATA_START;
extern Addr ice_rink_risk_RODATA_END;
extern Addr ice_rink_risk_RODATA_SIZE;
extern Addr ice_rink_risk_RODATA_START;
extern Addr ice_rink_risk_ROM_END;
extern Addr ice_rink_risk_ROM_START;
extern Addr ice_rink_risk_TEXT_END;
extern Addr ice_rink_risk_TEXT_SIZE;
extern Addr ice_rink_risk_TEXT_START;
extern Addr ice_rink_risk_VRAM;
extern Addr ice_rink_risk_VRAM_END;
extern Addr ice_rink_risk_bss_VRAM;
extern Addr inst_BSS_END;
extern Addr inst_BSS_SIZE;
extern Addr inst_BSS_START;
extern Addr inst_DATA_END;
extern Addr inst_DATA_SIZE;
extern Addr inst_DATA_START;
extern Addr inst_RODATA_END;
extern Addr inst_RODATA_SIZE;
extern Addr inst_RODATA_START;
extern Addr inst_ROM_END;
extern Addr inst_ROM_START;
extern Addr inst_TEXT_END;
extern Addr inst_TEXT_SIZE;
extern Addr inst_TEXT_START;
extern Addr inst_VRAM;
extern Addr inst_VRAM_END;
extern Addr inst_bss_VRAM;
extern Addr koopa_BSS_END;
extern Addr koopa_BSS_SIZE;
extern Addr koopa_BSS_START;
extern Addr koopa_DATA_END;
extern Addr koopa_DATA_SIZE;
extern Addr koopa_DATA_START;
extern Addr koopa_RODATA_END;
extern Addr koopa_RODATA_SIZE;
extern Addr koopa_RODATA_START;
extern Addr koopa_ROM_END;
extern Addr koopa_ROM_START;
extern Addr koopa_TEXT_END;
extern Addr koopa_TEXT_SIZE;
extern Addr koopa_TEXT_START;
extern Addr koopa_VRAM;
extern Addr koopa_VRAM_END;
extern Addr koopa_bss_VRAM;
extern Addr last5_BSS_END;
extern Addr last5_BSS_SIZE;
extern Addr last5_BSS_START;
extern Addr last5_DATA_END;
extern Addr last5_DATA_SIZE;
extern Addr last5_DATA_START;
extern Addr last5_RODATA_END;
extern Addr last5_RODATA_SIZE;
extern Addr last5_RODATA_START;
extern Addr last5_ROM_END;
extern Addr last5_ROM_START;
extern Addr last5_TEXT_END;
extern Addr last5_TEXT_SIZE;
extern Addr last5_TEXT_START;
extern Addr last5_VRAM;
extern Addr last5_VRAM_END;
extern Addr last5_bss_VRAM;
extern Addr locked_out_BSS_END;
extern Addr locked_out_BSS_SIZE;
extern Addr locked_out_BSS_START;
extern Addr locked_out_DATA_END;
extern Addr locked_out_DATA_SIZE;
extern Addr locked_out_DATA_START;
extern Addr locked_out_RODATA_END;
extern Addr locked_out_RODATA_SIZE;
extern Addr locked_out_RODATA_START;
extern Addr locked_out_ROM_END;
extern Addr locked_out_ROM_START;
extern Addr locked_out_TEXT_END;
extern Addr locked_out_TEXT_SIZE;
extern Addr locked_out_TEXT_START;
extern Addr locked_out_VRAM;
extern Addr locked_out_VRAM_END;
extern Addr locked_out_bss_VRAM;
extern Addr log_jam_BSS_END;
extern Addr log_jam_BSS_SIZE;
extern Addr log_jam_BSS_START;
extern Addr log_jam_DATA_END;
extern Addr log_jam_DATA_SIZE;
extern Addr log_jam_DATA_START;
extern Addr log_jam_RODATA_END;
extern Addr log_jam_RODATA_SIZE;
extern Addr log_jam_RODATA_START;
extern Addr log_jam_ROM_END;
extern Addr log_jam_ROM_START;
extern Addr log_jam_TEXT_END;
extern Addr log_jam_TEXT_SIZE;
extern Addr log_jam_TEXT_START;
extern Addr log_jam_VRAM;
extern Addr log_jam_VRAM_END;
extern Addr log_jam_bss_VRAM;
extern Addr main_BSS_END;
extern Addr main_BSS_SIZE;
extern Addr main_BSS_START;
extern Addr main_DATA_END;
extern Addr main_DATA_SIZE;
extern Addr main_DATA_START;
extern Addr main_RODATA_END;
extern Addr main_RODATA_SIZE;
extern Addr main_RODATA_START;
extern Addr main_ROM_END;
extern Addr main_ROM_START;
extern Addr main_TEXT_END;
extern Addr main_TEXT_SIZE;
extern Addr main_TEXT_START;
extern Addr main_VRAM;
extern Addr main_VRAM_END;
extern Addr main_bss_VRAM;
extern Addr mainfs_DATA_END;
extern Addr mainfs_DATA_SIZE;
extern Addr mainfs_DATA_START;
extern Addr mainfs_ROM_END;
extern Addr mainfs_ROM_START;
extern Addr mainfs_VRAM;
extern Addr mainfs_VRAM_END;
extern Addr majinlamp_BSS_END;
extern Addr majinlamp_BSS_SIZE;
extern Addr majinlamp_BSS_START;
extern Addr majinlamp_DATA_END;
extern Addr majinlamp_DATA_SIZE;
extern Addr majinlamp_DATA_START;
extern Addr majinlamp_RODATA_END;
extern Addr majinlamp_RODATA_SIZE;
extern Addr majinlamp_RODATA_START;
extern Addr majinlamp_ROM_END;
extern Addr majinlamp_ROM_START;
extern Addr majinlamp_TEXT_END;
extern Addr majinlamp_TEXT_SIZE;
extern Addr majinlamp_TEXT_START;
extern Addr majinlamp_VRAM;
extern Addr majinlamp_VRAM_END;
extern Addr majinlamp_bss_VRAM;
extern Addr marios_puzzle_party_BSS_END;
extern Addr marios_puzzle_party_BSS_SIZE;
extern Addr marios_puzzle_party_BSS_START;
extern Addr marios_puzzle_party_DATA_END;
extern Addr marios_puzzle_party_DATA_SIZE;
extern Addr marios_puzzle_party_DATA_START;
extern Addr marios_puzzle_party_RODATA_END;
extern Addr marios_puzzle_party_RODATA_SIZE;
extern Addr marios_puzzle_party_RODATA_START;
extern Addr marios_puzzle_party_ROM_END;
extern Addr marios_puzzle_party_ROM_START;
extern Addr marios_puzzle_party_TEXT_END;
extern Addr marios_puzzle_party_TEXT_SIZE;
extern Addr marios_puzzle_party_TEXT_START;
extern Addr marios_puzzle_party_VRAM;
extern Addr marios_puzzle_party_VRAM_END;
extern Addr marios_puzzle_party_bss_VRAM;
extern Addr mchar2_BSS_END;
extern Addr mchar2_BSS_SIZE;
extern Addr mchar2_BSS_START;
extern Addr mchar2_DATA_END;
extern Addr mchar2_DATA_SIZE;
extern Addr mchar2_DATA_START;
extern Addr mchar2_RODATA_END;
extern Addr mchar2_RODATA_SIZE;
extern Addr mchar2_RODATA_START;
extern Addr mchar2_ROM_END;
extern Addr mchar2_ROM_START;
extern Addr mchar2_TEXT_END;
extern Addr mchar2_TEXT_SIZE;
extern Addr mchar2_TEXT_START;
extern Addr mchar2_VRAM;
extern Addr mchar2_VRAM_END;
extern Addr mchar2_bss_VRAM;
extern Addr mchar_BSS_END;
extern Addr mchar_BSS_SIZE;
extern Addr mchar_BSS_START;
extern Addr mchar_DATA_END;
extern Addr mchar_DATA_SIZE;
extern Addr mchar_DATA_START;
extern Addr mchar_RODATA_END;
extern Addr mchar_RODATA_SIZE;
extern Addr mchar_RODATA_START;
extern Addr mchar_ROM_END;
extern Addr mchar_ROM_START;
extern Addr mchar_TEXT_END;
extern Addr mchar_TEXT_SIZE;
extern Addr mchar_TEXT_START;
extern Addr mchar_VRAM;
extern Addr mchar_VRAM_END;
extern Addr mchar_bss_VRAM;
extern Addr merry_go_chomp_BSS_END;
extern Addr merry_go_chomp_BSS_SIZE;
extern Addr merry_go_chomp_BSS_START;
extern Addr merry_go_chomp_DATA_END;
extern Addr merry_go_chomp_DATA_SIZE;
extern Addr merry_go_chomp_DATA_START;
extern Addr merry_go_chomp_RODATA_END;
extern Addr merry_go_chomp_RODATA_SIZE;
extern Addr merry_go_chomp_RODATA_START;
extern Addr merry_go_chomp_ROM_END;
extern Addr merry_go_chomp_ROM_START;
extern Addr merry_go_chomp_TEXT_END;
extern Addr merry_go_chomp_TEXT_SIZE;
extern Addr merry_go_chomp_TEXT_START;
extern Addr merry_go_chomp_VRAM;
extern Addr merry_go_chomp_VRAM_END;
extern Addr merry_go_chomp_bss_VRAM;
extern Addr meschk_BSS_END;
extern Addr meschk_BSS_SIZE;
extern Addr meschk_BSS_START;
extern Addr meschk_DATA_END;
extern Addr meschk_DATA_SIZE;
extern Addr meschk_DATA_START;
extern Addr meschk_RODATA_END;
extern Addr meschk_RODATA_SIZE;
extern Addr meschk_RODATA_START;
extern Addr meschk_ROM_END;
extern Addr meschk_ROM_START;
extern Addr meschk_TEXT_END;
extern Addr meschk_TEXT_SIZE;
extern Addr meschk_TEXT_START;
extern Addr meschk_VRAM;
extern Addr meschk_VRAM_END;
extern Addr meschk_bss_VRAM;
extern Addr messy_memory_BSS_END;
extern Addr messy_memory_BSS_SIZE;
extern Addr messy_memory_BSS_START;
extern Addr messy_memory_DATA_END;
extern Addr messy_memory_DATA_SIZE;
extern Addr messy_memory_DATA_START;
extern Addr messy_memory_RODATA_END;
extern Addr messy_memory_RODATA_SIZE;
extern Addr messy_memory_RODATA_START;
extern Addr messy_memory_ROM_END;
extern Addr messy_memory_ROM_START;
extern Addr messy_memory_TEXT_END;
extern Addr messy_memory_TEXT_SIZE;
extern Addr messy_memory_TEXT_START;
extern Addr messy_memory_VRAM;
extern Addr messy_memory_VRAM_END;
extern Addr messy_memory_bss_VRAM;
extern Addr mgenter_BSS_END;
extern Addr mgenter_BSS_SIZE;
extern Addr mgenter_BSS_START;
extern Addr mgenter_DATA_END;
extern Addr mgenter_DATA_SIZE;
extern Addr mgenter_DATA_START;
extern Addr mgenter_RODATA_END;
extern Addr mgenter_RODATA_SIZE;
extern Addr mgenter_RODATA_START;
extern Addr mgenter_ROM_END;
extern Addr mgenter_ROM_START;
extern Addr mgenter_TEXT_END;
extern Addr mgenter_TEXT_SIZE;
extern Addr mgenter_TEXT_START;
extern Addr mgenter_VRAM;
extern Addr mgenter_VRAM_END;
extern Addr mgenter_bss_VRAM;
extern Addr mgmode_BSS_END;
extern Addr mgmode_BSS_SIZE;
extern Addr mgmode_BSS_START;
extern Addr mgmode_DATA_END;
extern Addr mgmode_DATA_SIZE;
extern Addr mgmode_DATA_START;
extern Addr mgmode_RODATA_END;
extern Addr mgmode_RODATA_SIZE;
extern Addr mgmode_RODATA_START;
extern Addr mgmode_ROM_END;
extern Addr mgmode_ROM_START;
extern Addr mgmode_TEXT_END;
extern Addr mgmode_TEXT_SIZE;
extern Addr mgmode_TEXT_START;
extern Addr mgmode_VRAM;
extern Addr mgmode_VRAM_END;
extern Addr mgmode_bss_VRAM;
extern Addr mgresultbattle_BSS_END;
extern Addr mgresultbattle_BSS_SIZE;
extern Addr mgresultbattle_BSS_START;
extern Addr mgresultbattle_DATA_END;
extern Addr mgresultbattle_DATA_SIZE;
extern Addr mgresultbattle_DATA_START;
extern Addr mgresultbattle_RODATA_END;
extern Addr mgresultbattle_RODATA_SIZE;
extern Addr mgresultbattle_RODATA_START;
extern Addr mgresultbattle_ROM_END;
extern Addr mgresultbattle_ROM_START;
extern Addr mgresultbattle_TEXT_END;
extern Addr mgresultbattle_TEXT_SIZE;
extern Addr mgresultbattle_TEXT_START;
extern Addr mgresultbattle_VRAM;
extern Addr mgresultbattle_VRAM_END;
extern Addr mgresultbattle_bss_VRAM;
extern Addr mgresultboard_BSS_END;
extern Addr mgresultboard_BSS_SIZE;
extern Addr mgresultboard_BSS_START;
extern Addr mgresultboard_DATA_END;
extern Addr mgresultboard_DATA_SIZE;
extern Addr mgresultboard_DATA_START;
extern Addr mgresultboard_RODATA_END;
extern Addr mgresultboard_RODATA_SIZE;
extern Addr mgresultboard_RODATA_START;
extern Addr mgresultboard_ROM_END;
extern Addr mgresultboard_ROM_START;
extern Addr mgresultboard_TEXT_END;
extern Addr mgresultboard_TEXT_SIZE;
extern Addr mgresultboard_TEXT_START;
extern Addr mgresultboard_VRAM;
extern Addr mgresultboard_VRAM_END;
extern Addr mgresultboard_bss_VRAM;
extern Addr mgresultdealer_BSS_END;
extern Addr mgresultdealer_BSS_SIZE;
extern Addr mgresultdealer_BSS_START;
extern Addr mgresultdealer_DATA_END;
extern Addr mgresultdealer_DATA_SIZE;
extern Addr mgresultdealer_DATA_START;
extern Addr mgresultdealer_RODATA_END;
extern Addr mgresultdealer_RODATA_SIZE;
extern Addr mgresultdealer_RODATA_START;
extern Addr mgresultdealer_ROM_END;
extern Addr mgresultdealer_ROM_START;
extern Addr mgresultdealer_TEXT_END;
extern Addr mgresultdealer_TEXT_SIZE;
extern Addr mgresultdealer_TEXT_START;
extern Addr mgresultdealer_VRAM;
extern Addr mgresultdealer_VRAM_END;
extern Addr mgresultdealer_bss_VRAM;
extern Addr mgresultduel_BSS_END;
extern Addr mgresultduel_BSS_SIZE;
extern Addr mgresultduel_BSS_START;
extern Addr mgresultduel_DATA_END;
extern Addr mgresultduel_DATA_SIZE;
extern Addr mgresultduel_DATA_START;
extern Addr mgresultduel_RODATA_END;
extern Addr mgresultduel_RODATA_SIZE;
extern Addr mgresultduel_RODATA_START;
extern Addr mgresultduel_ROM_END;
extern Addr mgresultduel_ROM_START;
extern Addr mgresultduel_TEXT_END;
extern Addr mgresultduel_TEXT_SIZE;
extern Addr mgresultduel_TEXT_START;
extern Addr mgresultduel_VRAM;
extern Addr mgresultduel_VRAM_END;
extern Addr mgresultduel_bss_VRAM;
extern Addr minigame_BSS_END;
extern Addr minigame_BSS_SIZE;
extern Addr minigame_BSS_START;
extern Addr minigame_DATA_END;
extern Addr minigame_DATA_SIZE;
extern Addr minigame_DATA_START;
extern Addr minigame_RODATA_END;
extern Addr minigame_RODATA_SIZE;
extern Addr minigame_RODATA_START;
extern Addr minigame_ROM_END;
extern Addr minigame_ROM_START;
extern Addr minigame_TEXT_END;
extern Addr minigame_TEXT_SIZE;
extern Addr minigame_TEXT_START;
extern Addr minigame_VRAM;
extern Addr minigame_VRAM_END;
extern Addr minigame_bss_VRAM;
extern Addr modesel_BSS_END;
extern Addr modesel_BSS_SIZE;
extern Addr modesel_BSS_START;
extern Addr modesel_DATA_END;
extern Addr modesel_DATA_SIZE;
extern Addr modesel_DATA_START;
extern Addr modesel_RODATA_END;
extern Addr modesel_RODATA_SIZE;
extern Addr modesel_RODATA_START;
extern Addr modesel_ROM_END;
extern Addr modesel_ROM_START;
extern Addr modesel_TEXT_END;
extern Addr modesel_TEXT_SIZE;
extern Addr modesel_TEXT_START;
extern Addr modesel_VRAM;
extern Addr modesel_VRAM_END;
extern Addr modesel_bss_VRAM;
extern Addr motor_rooter_BSS_END;
extern Addr motor_rooter_BSS_SIZE;
extern Addr motor_rooter_BSS_START;
extern Addr motor_rooter_DATA_END;
extern Addr motor_rooter_DATA_SIZE;
extern Addr motor_rooter_DATA_START;
extern Addr motor_rooter_RODATA_END;
extern Addr motor_rooter_RODATA_SIZE;
extern Addr motor_rooter_RODATA_START;
extern Addr motor_rooter_ROM_END;
extern Addr motor_rooter_ROM_START;
extern Addr motor_rooter_TEXT_END;
extern Addr motor_rooter_TEXT_SIZE;
extern Addr motor_rooter_TEXT_START;
extern Addr motor_rooter_VRAM;
extern Addr motor_rooter_VRAM_END;
extern Addr motor_rooter_bss_VRAM;
extern Addr mpiq_BSS_END;
extern Addr mpiq_BSS_SIZE;
extern Addr mpiq_BSS_START;
extern Addr mpiq_DATA_END;
extern Addr mpiq_DATA_SIZE;
extern Addr mpiq_DATA_START;
extern Addr mpiq_RODATA_END;
extern Addr mpiq_RODATA_SIZE;
extern Addr mpiq_RODATA_START;
extern Addr mpiq_ROM_END;
extern Addr mpiq_ROM_START;
extern Addr mpiq_TEXT_END;
extern Addr mpiq_TEXT_SIZE;
extern Addr mpiq_TEXT_START;
extern Addr mpiq_VRAM;
extern Addr mpiq_VRAM_END;
extern Addr mpiq_bss_VRAM;
extern Addr msetup_BSS_END;
extern Addr msetup_BSS_SIZE;
extern Addr msetup_BSS_START;
extern Addr msetup_DATA_END;
extern Addr msetup_DATA_SIZE;
extern Addr msetup_DATA_START;
extern Addr msetup_RODATA_END;
extern Addr msetup_RODATA_SIZE;
extern Addr msetup_RODATA_START;
extern Addr msetup_ROM_END;
extern Addr msetup_ROM_START;
extern Addr msetup_TEXT_END;
extern Addr msetup_TEXT_SIZE;
extern Addr msetup_TEXT_START;
extern Addr msetup_VRAM;
extern Addr msetup_VRAM_END;
extern Addr msetup_bss_VRAM;
extern Addr mstory1_BSS_END;
extern Addr mstory1_BSS_SIZE;
extern Addr mstory1_BSS_START;
extern Addr mstory1_DATA_END;
extern Addr mstory1_DATA_SIZE;
extern Addr mstory1_DATA_START;
extern Addr mstory1_RODATA_END;
extern Addr mstory1_RODATA_SIZE;
extern Addr mstory1_RODATA_START;
extern Addr mstory1_ROM_END;
extern Addr mstory1_ROM_START;
extern Addr mstory1_TEXT_END;
extern Addr mstory1_TEXT_SIZE;
extern Addr mstory1_TEXT_START;
extern Addr mstory1_VRAM;
extern Addr mstory1_VRAM_END;
extern Addr mstory1_bss_VRAM;
extern Addr mstory2_BSS_END;
extern Addr mstory2_BSS_SIZE;
extern Addr mstory2_BSS_START;
extern Addr mstory2_DATA_END;
extern Addr mstory2_DATA_SIZE;
extern Addr mstory2_DATA_START;
extern Addr mstory2_RODATA_END;
extern Addr mstory2_RODATA_SIZE;
extern Addr mstory2_RODATA_START;
extern Addr mstory2_ROM_END;
extern Addr mstory2_ROM_START;
extern Addr mstory2_TEXT_END;
extern Addr mstory2_TEXT_SIZE;
extern Addr mstory2_TEXT_START;
extern Addr mstory2_VRAM;
extern Addr mstory2_VRAM_END;
extern Addr mstory2_bss_VRAM;
extern Addr mstory3_BSS_END;
extern Addr mstory3_BSS_SIZE;
extern Addr mstory3_BSS_START;
extern Addr mstory3_DATA_END;
extern Addr mstory3_DATA_SIZE;
extern Addr mstory3_DATA_START;
extern Addr mstory3_RODATA_END;
extern Addr mstory3_RODATA_SIZE;
extern Addr mstory3_RODATA_START;
extern Addr mstory3_ROM_END;
extern Addr mstory3_ROM_START;
extern Addr mstory3_TEXT_END;
extern Addr mstory3_TEXT_SIZE;
extern Addr mstory3_TEXT_START;
extern Addr mstory3_VRAM;
extern Addr mstory3_VRAM_END;
extern Addr mstory3_bss_VRAM;
extern Addr mstory4_BSS_END;
extern Addr mstory4_BSS_SIZE;
extern Addr mstory4_BSS_START;
extern Addr mstory4_DATA_END;
extern Addr mstory4_DATA_SIZE;
extern Addr mstory4_DATA_START;
extern Addr mstory4_RODATA_END;
extern Addr mstory4_RODATA_SIZE;
extern Addr mstory4_RODATA_START;
extern Addr mstory4_ROM_END;
extern Addr mstory4_ROM_START;
extern Addr mstory4_TEXT_END;
extern Addr mstory4_TEXT_SIZE;
extern Addr mstory4_TEXT_START;
extern Addr mstory4_VRAM;
extern Addr mstory4_VRAM_END;
extern Addr mstory4_bss_VRAM;
extern Addr mstory5_BSS_END;
extern Addr mstory5_BSS_SIZE;
extern Addr mstory5_BSS_START;
extern Addr mstory5_DATA_END;
extern Addr mstory5_DATA_SIZE;
extern Addr mstory5_DATA_START;
extern Addr mstory5_RODATA_END;
extern Addr mstory5_RODATA_SIZE;
extern Addr mstory5_RODATA_START;
extern Addr mstory5_ROM_END;
extern Addr mstory5_ROM_START;
extern Addr mstory5_TEXT_END;
extern Addr mstory5_TEXT_SIZE;
extern Addr mstory5_TEXT_START;
extern Addr mstory5_VRAM;
extern Addr mstory5_VRAM_END;
extern Addr mstory5_bss_VRAM;
extern Addr name_7E_BSS_END;
extern Addr name_7E_BSS_SIZE;
extern Addr name_7E_BSS_START;
extern Addr name_7E_DATA_END;
extern Addr name_7E_DATA_SIZE;
extern Addr name_7E_DATA_START;
extern Addr name_7E_RODATA_END;
extern Addr name_7E_RODATA_SIZE;
extern Addr name_7E_RODATA_START;
extern Addr name_7E_ROM_END;
extern Addr name_7E_ROM_START;
extern Addr name_7E_TEXT_END;
extern Addr name_7E_TEXT_SIZE;
extern Addr name_7E_TEXT_START;
extern Addr name_7E_VRAM;
extern Addr name_7E_VRAM_END;
extern Addr name_7E_bss_VRAM;
extern Addr name_81_BSS_END;
extern Addr name_81_BSS_SIZE;
extern Addr name_81_BSS_START;
extern Addr name_81_DATA_END;
extern Addr name_81_DATA_SIZE;
extern Addr name_81_DATA_START;
extern Addr name_81_RODATA_END;
extern Addr name_81_RODATA_SIZE;
extern Addr name_81_RODATA_START;
extern Addr name_81_ROM_END;
extern Addr name_81_ROM_START;
extern Addr name_81_TEXT_END;
extern Addr name_81_TEXT_SIZE;
extern Addr name_81_TEXT_START;
extern Addr name_81_VRAM;
extern Addr name_81_VRAM_END;
extern Addr name_81_bss_VRAM;
extern Addr opboard_BSS_END;
extern Addr opboard_BSS_SIZE;
extern Addr opboard_BSS_START;
extern Addr opboard_DATA_END;
extern Addr opboard_DATA_SIZE;
extern Addr opboard_DATA_START;
extern Addr opboard_RODATA_END;
extern Addr opboard_RODATA_SIZE;
extern Addr opboard_RODATA_START;
extern Addr opboard_ROM_END;
extern Addr opboard_ROM_START;
extern Addr opboard_TEXT_END;
extern Addr opboard_TEXT_SIZE;
extern Addr opboard_TEXT_START;
extern Addr opboard_VRAM;
extern Addr opboard_VRAM_END;
extern Addr opboard_bss_VRAM;
extern Addr opboardtutorial_BSS_END;
extern Addr opboardtutorial_BSS_SIZE;
extern Addr opboardtutorial_BSS_START;
extern Addr opboardtutorial_DATA_END;
extern Addr opboardtutorial_DATA_SIZE;
extern Addr opboardtutorial_DATA_START;
extern Addr opboardtutorial_RODATA_END;
extern Addr opboardtutorial_RODATA_SIZE;
extern Addr opboardtutorial_RODATA_START;
extern Addr opboardtutorial_ROM_END;
extern Addr opboardtutorial_ROM_START;
extern Addr opboardtutorial_TEXT_END;
extern Addr opboardtutorial_TEXT_SIZE;
extern Addr opboardtutorial_TEXT_START;
extern Addr opboardtutorial_VRAM;
extern Addr opboardtutorial_VRAM_END;
extern Addr opboardtutorial_bss_VRAM;
extern Addr opduel_BSS_END;
extern Addr opduel_BSS_SIZE;
extern Addr opduel_BSS_START;
extern Addr opduel_DATA_END;
extern Addr opduel_DATA_SIZE;
extern Addr opduel_DATA_START;
extern Addr opduel_RODATA_END;
extern Addr opduel_RODATA_SIZE;
extern Addr opduel_RODATA_START;
extern Addr opduel_ROM_END;
extern Addr opduel_ROM_START;
extern Addr opduel_TEXT_END;
extern Addr opduel_TEXT_SIZE;
extern Addr opduel_TEXT_START;
extern Addr opduel_VRAM;
extern Addr opduel_VRAM_END;
extern Addr opduel_bss_VRAM;
extern Addr opdueltutorial_BSS_END;
extern Addr opdueltutorial_BSS_SIZE;
extern Addr opdueltutorial_BSS_START;
extern Addr opdueltutorial_DATA_END;
extern Addr opdueltutorial_DATA_SIZE;
extern Addr opdueltutorial_DATA_START;
extern Addr opdueltutorial_RODATA_END;
extern Addr opdueltutorial_RODATA_SIZE;
extern Addr opdueltutorial_RODATA_START;
extern Addr opdueltutorial_ROM_END;
extern Addr opdueltutorial_ROM_START;
extern Addr opdueltutorial_TEXT_END;
extern Addr opdueltutorial_TEXT_SIZE;
extern Addr opdueltutorial_TEXT_START;
extern Addr opdueltutorial_VRAM;
extern Addr opdueltutorial_VRAM_END;
extern Addr opdueltutorial_bss_VRAM;
extern Addr opening_BSS_END;
extern Addr opening_BSS_SIZE;
extern Addr opening_BSS_START;
extern Addr opening_DATA_END;
extern Addr opening_DATA_SIZE;
extern Addr opening_DATA_START;
extern Addr opening_RODATA_END;
extern Addr opening_RODATA_SIZE;
extern Addr opening_RODATA_START;
extern Addr opening_ROM_END;
extern Addr opening_ROM_START;
extern Addr opening_TEXT_END;
extern Addr opening_TEXT_SIZE;
extern Addr opening_TEXT_START;
extern Addr opening_VRAM;
extern Addr opening_VRAM_END;
extern Addr opening_bss_VRAM;
extern Addr option_BSS_END;
extern Addr option_BSS_SIZE;
extern Addr option_BSS_START;
extern Addr option_DATA_END;
extern Addr option_DATA_SIZE;
extern Addr option_DATA_START;
extern Addr option_RODATA_END;
extern Addr option_RODATA_SIZE;
extern Addr option_RODATA_START;
extern Addr option_ROM_END;
extern Addr option_ROM_START;
extern Addr option_TEXT_END;
extern Addr option_TEXT_SIZE;
extern Addr option_TEXT_START;
extern Addr option_VRAM;
extern Addr option_VRAM_END;
extern Addr option_bss_VRAM;
extern Addr ovl_boot_BSS_END;
extern Addr ovl_boot_BSS_SIZE;
extern Addr ovl_boot_BSS_START;
extern Addr ovl_boot_DATA_END;
extern Addr ovl_boot_DATA_SIZE;
extern Addr ovl_boot_DATA_START;
extern Addr ovl_boot_RODATA_END;
extern Addr ovl_boot_RODATA_SIZE;
extern Addr ovl_boot_RODATA_START;
extern Addr ovl_boot_ROM_END;
extern Addr ovl_boot_ROM_START;
extern Addr ovl_boot_TEXT_END;
extern Addr ovl_boot_TEXT_SIZE;
extern Addr ovl_boot_TEXT_START;
extern Addr ovl_boot_VRAM;
extern Addr ovl_boot_VRAM_END;
extern Addr ovl_boot_bss_VRAM;
extern Addr parasol_plummet_BSS_END;
extern Addr parasol_plummet_BSS_SIZE;
extern Addr parasol_plummet_BSS_START;
extern Addr parasol_plummet_DATA_END;
extern Addr parasol_plummet_DATA_SIZE;
extern Addr parasol_plummet_DATA_START;
extern Addr parasol_plummet_RODATA_END;
extern Addr parasol_plummet_RODATA_SIZE;
extern Addr parasol_plummet_RODATA_START;
extern Addr parasol_plummet_ROM_END;
extern Addr parasol_plummet_ROM_START;
extern Addr parasol_plummet_TEXT_END;
extern Addr parasol_plummet_TEXT_SIZE;
extern Addr parasol_plummet_TEXT_START;
extern Addr parasol_plummet_VRAM;
extern Addr parasol_plummet_VRAM_END;
extern Addr parasol_plummet_bss_VRAM;
extern Addr picking_panic_BSS_END;
extern Addr picking_panic_BSS_SIZE;
extern Addr picking_panic_BSS_START;
extern Addr picking_panic_DATA_END;
extern Addr picking_panic_DATA_SIZE;
extern Addr picking_panic_DATA_START;
extern Addr picking_panic_RODATA_END;
extern Addr picking_panic_RODATA_SIZE;
extern Addr picking_panic_RODATA_START;
extern Addr picking_panic_ROM_END;
extern Addr picking_panic_ROM_START;
extern Addr picking_panic_TEXT_END;
extern Addr picking_panic_TEXT_SIZE;
extern Addr picking_panic_TEXT_START;
extern Addr picking_panic_VRAM;
extern Addr picking_panic_VRAM_END;
extern Addr picking_panic_bss_VRAM;
extern Addr picture_imperfect_BSS_END;
extern Addr picture_imperfect_BSS_SIZE;
extern Addr picture_imperfect_BSS_START;
extern Addr picture_imperfect_DATA_END;
extern Addr picture_imperfect_DATA_SIZE;
extern Addr picture_imperfect_DATA_START;
extern Addr picture_imperfect_RODATA_END;
extern Addr picture_imperfect_RODATA_SIZE;
extern Addr picture_imperfect_RODATA_START;
extern Addr picture_imperfect_ROM_END;
extern Addr picture_imperfect_ROM_START;
extern Addr picture_imperfect_TEXT_END;
extern Addr picture_imperfect_TEXT_SIZE;
extern Addr picture_imperfect_TEXT_START;
extern Addr picture_imperfect_VRAM;
extern Addr picture_imperfect_VRAM_END;
extern Addr picture_imperfect_bss_VRAM;
extern Addr pipe_cleaners_BSS_END;
extern Addr pipe_cleaners_BSS_SIZE;
extern Addr pipe_cleaners_BSS_START;
extern Addr pipe_cleaners_DATA_END;
extern Addr pipe_cleaners_DATA_SIZE;
extern Addr pipe_cleaners_DATA_START;
extern Addr pipe_cleaners_RODATA_END;
extern Addr pipe_cleaners_RODATA_SIZE;
extern Addr pipe_cleaners_RODATA_START;
extern Addr pipe_cleaners_ROM_END;
extern Addr pipe_cleaners_ROM_START;
extern Addr pipe_cleaners_TEXT_END;
extern Addr pipe_cleaners_TEXT_SIZE;
extern Addr pipe_cleaners_TEXT_START;
extern Addr pipe_cleaners_VRAM;
extern Addr pipe_cleaners_VRAM_END;
extern Addr pipe_cleaners_bss_VRAM;
extern Addr popgun_pickoff_BSS_END;
extern Addr popgun_pickoff_BSS_SIZE;
extern Addr popgun_pickoff_BSS_START;
extern Addr popgun_pickoff_DATA_END;
extern Addr popgun_pickoff_DATA_SIZE;
extern Addr popgun_pickoff_DATA_START;
extern Addr popgun_pickoff_RODATA_END;
extern Addr popgun_pickoff_RODATA_SIZE;
extern Addr popgun_pickoff_RODATA_START;
extern Addr popgun_pickoff_ROM_END;
extern Addr popgun_pickoff_ROM_START;
extern Addr popgun_pickoff_TEXT_END;
extern Addr popgun_pickoff_TEXT_SIZE;
extern Addr popgun_pickoff_TEXT_START;
extern Addr popgun_pickoff_VRAM;
extern Addr popgun_pickoff_VRAM_END;
extern Addr popgun_pickoff_bss_VRAM;
extern Addr puddle_paddle_BSS_END;
extern Addr puddle_paddle_BSS_SIZE;
extern Addr puddle_paddle_BSS_START;
extern Addr puddle_paddle_DATA_END;
extern Addr puddle_paddle_DATA_SIZE;
extern Addr puddle_paddle_DATA_START;
extern Addr puddle_paddle_RODATA_END;
extern Addr puddle_paddle_RODATA_SIZE;
extern Addr puddle_paddle_RODATA_START;
extern Addr puddle_paddle_ROM_END;
extern Addr puddle_paddle_ROM_START;
extern Addr puddle_paddle_TEXT_END;
extern Addr puddle_paddle_TEXT_SIZE;
extern Addr puddle_paddle_TEXT_START;
extern Addr puddle_paddle_VRAM;
extern Addr puddle_paddle_VRAM_END;
extern Addr puddle_paddle_bss_VRAM;
extern Addr pump_pump_away_BSS_END;
extern Addr pump_pump_away_BSS_SIZE;
extern Addr pump_pump_away_BSS_START;
extern Addr pump_pump_away_DATA_END;
extern Addr pump_pump_away_DATA_SIZE;
extern Addr pump_pump_away_DATA_START;
extern Addr pump_pump_away_RODATA_END;
extern Addr pump_pump_away_RODATA_SIZE;
extern Addr pump_pump_away_RODATA_START;
extern Addr pump_pump_away_ROM_END;
extern Addr pump_pump_away_ROM_START;
extern Addr pump_pump_away_TEXT_END;
extern Addr pump_pump_away_TEXT_SIZE;
extern Addr pump_pump_away_TEXT_START;
extern Addr pump_pump_away_VRAM;
extern Addr pump_pump_away_VRAM_END;
extern Addr pump_pump_away_bss_VRAM;
extern Addr ridiculous_relay_BSS_END;
extern Addr ridiculous_relay_BSS_SIZE;
extern Addr ridiculous_relay_BSS_START;
extern Addr ridiculous_relay_DATA_END;
extern Addr ridiculous_relay_DATA_SIZE;
extern Addr ridiculous_relay_DATA_START;
extern Addr ridiculous_relay_RODATA_END;
extern Addr ridiculous_relay_RODATA_SIZE;
extern Addr ridiculous_relay_RODATA_START;
extern Addr ridiculous_relay_ROM_END;
extern Addr ridiculous_relay_ROM_START;
extern Addr ridiculous_relay_TEXT_END;
extern Addr ridiculous_relay_TEXT_SIZE;
extern Addr ridiculous_relay_TEXT_START;
extern Addr ridiculous_relay_VRAM;
extern Addr ridiculous_relay_VRAM_END;
extern Addr ridiculous_relay_bss_VRAM;
extern Addr river_raiders_BSS_END;
extern Addr river_raiders_BSS_SIZE;
extern Addr river_raiders_BSS_START;
extern Addr river_raiders_DATA_END;
extern Addr river_raiders_DATA_SIZE;
extern Addr river_raiders_DATA_START;
extern Addr river_raiders_RODATA_END;
extern Addr river_raiders_RODATA_SIZE;
extern Addr river_raiders_RODATA_START;
extern Addr river_raiders_ROM_END;
extern Addr river_raiders_ROM_START;
extern Addr river_raiders_TEXT_END;
extern Addr river_raiders_TEXT_SIZE;
extern Addr river_raiders_TEXT_START;
extern Addr river_raiders_VRAM;
extern Addr river_raiders_VRAM_END;
extern Addr river_raiders_bss_VRAM;
extern Addr rockin_raceway_BSS_END;
extern Addr rockin_raceway_BSS_SIZE;
extern Addr rockin_raceway_BSS_START;
extern Addr rockin_raceway_DATA_END;
extern Addr rockin_raceway_DATA_SIZE;
extern Addr rockin_raceway_DATA_START;
extern Addr rockin_raceway_RODATA_END;
extern Addr rockin_raceway_RODATA_SIZE;
extern Addr rockin_raceway_RODATA_START;
extern Addr rockin_raceway_ROM_END;
extern Addr rockin_raceway_ROM_START;
extern Addr rockin_raceway_TEXT_END;
extern Addr rockin_raceway_TEXT_SIZE;
extern Addr rockin_raceway_TEXT_START;
extern Addr rockin_raceway_VRAM;
extern Addr rockin_raceway_VRAM_END;
extern Addr rockin_raceway_bss_VRAM;
extern Addr selmenu2_BSS_END;
extern Addr selmenu2_BSS_SIZE;
extern Addr selmenu2_BSS_START;
extern Addr selmenu2_DATA_END;
extern Addr selmenu2_DATA_SIZE;
extern Addr selmenu2_DATA_START;
extern Addr selmenu2_RODATA_END;
extern Addr selmenu2_RODATA_SIZE;
extern Addr selmenu2_RODATA_START;
extern Addr selmenu2_ROM_END;
extern Addr selmenu2_ROM_START;
extern Addr selmenu2_TEXT_END;
extern Addr selmenu2_TEXT_SIZE;
extern Addr selmenu2_TEXT_START;
extern Addr selmenu2_VRAM;
extern Addr selmenu2_VRAM_END;
extern Addr selmenu2_bss_VRAM;
extern Addr selmenu_BSS_END;
extern Addr selmenu_BSS_SIZE;
extern Addr selmenu_BSS_START;
extern Addr selmenu_DATA_END;
extern Addr selmenu_DATA_SIZE;
extern Addr selmenu_DATA_START;
extern Addr selmenu_RODATA_END;
extern Addr selmenu_RODATA_SIZE;
extern Addr selmenu_RODATA_START;
extern Addr selmenu_ROM_END;
extern Addr selmenu_ROM_START;
extern Addr selmenu_TEXT_END;
extern Addr selmenu_TEXT_SIZE;
extern Addr selmenu_TEXT_START;
extern Addr selmenu_VRAM;
extern Addr selmenu_VRAM_END;
extern Addr selmenu_bss_VRAM;
extern Addr shared_board_BSS_END;
extern Addr shared_board_BSS_SIZE;
extern Addr shared_board_BSS_START;
extern Addr shared_board_DATA_END;
extern Addr shared_board_DATA_SIZE;
extern Addr shared_board_DATA_START;
extern Addr shared_board_RODATA_END;
extern Addr shared_board_RODATA_SIZE;
extern Addr shared_board_RODATA_START;
extern Addr shared_board_ROM_END;
extern Addr shared_board_ROM_START;
extern Addr shared_board_TEXT_END;
extern Addr shared_board_TEXT_SIZE;
extern Addr shared_board_TEXT_START;
extern Addr shared_board_VRAM;
extern Addr shared_board_VRAM_END;
extern Addr shared_board_bss_VRAM;
extern Addr silly_screws_BSS_END;
extern Addr silly_screws_BSS_SIZE;
extern Addr silly_screws_BSS_START;
extern Addr silly_screws_DATA_END;
extern Addr silly_screws_DATA_SIZE;
extern Addr silly_screws_DATA_START;
extern Addr silly_screws_RODATA_END;
extern Addr silly_screws_RODATA_SIZE;
extern Addr silly_screws_RODATA_START;
extern Addr silly_screws_ROM_END;
extern Addr silly_screws_ROM_START;
extern Addr silly_screws_TEXT_END;
extern Addr silly_screws_TEXT_SIZE;
extern Addr silly_screws_TEXT_START;
extern Addr silly_screws_VRAM;
extern Addr silly_screws_VRAM_END;
extern Addr silly_screws_bss_VRAM;
extern Addr slapdown_BSS_END;
extern Addr slapdown_BSS_SIZE;
extern Addr slapdown_BSS_START;
extern Addr slapdown_DATA_END;
extern Addr slapdown_DATA_SIZE;
extern Addr slapdown_DATA_START;
extern Addr slapdown_RODATA_END;
extern Addr slapdown_RODATA_SIZE;
extern Addr slapdown_RODATA_START;
extern Addr slapdown_ROM_END;
extern Addr slapdown_ROM_START;
extern Addr slapdown_TEXT_END;
extern Addr slapdown_TEXT_SIZE;
extern Addr slapdown_TEXT_START;
extern Addr slapdown_VRAM;
extern Addr slapdown_VRAM_END;
extern Addr slapdown_bss_VRAM;
extern Addr sldebug_BSS_END;
extern Addr sldebug_BSS_SIZE;
extern Addr sldebug_BSS_START;
extern Addr sldebug_DATA_END;
extern Addr sldebug_DATA_SIZE;
extern Addr sldebug_DATA_START;
extern Addr sldebug_RODATA_END;
extern Addr sldebug_RODATA_SIZE;
extern Addr sldebug_RODATA_START;
extern Addr sldebug_ROM_END;
extern Addr sldebug_ROM_START;
extern Addr sldebug_TEXT_END;
extern Addr sldebug_TEXT_SIZE;
extern Addr sldebug_TEXT_START;
extern Addr sldebug_VRAM;
extern Addr sldebug_VRAM_END;
extern Addr sldebug_bss_VRAM;
extern Addr slerror_BSS_END;
extern Addr slerror_BSS_SIZE;
extern Addr slerror_BSS_START;
extern Addr slerror_DATA_END;
extern Addr slerror_DATA_SIZE;
extern Addr slerror_DATA_START;
extern Addr slerror_RODATA_END;
extern Addr slerror_RODATA_SIZE;
extern Addr slerror_RODATA_START;
extern Addr slerror_ROM_END;
extern Addr slerror_ROM_START;
extern Addr slerror_TEXT_END;
extern Addr slerror_TEXT_SIZE;
extern Addr slerror_TEXT_START;
extern Addr slerror_VRAM;
extern Addr slerror_VRAM_END;
extern Addr slerror_bss_VRAM;
extern Addr slot_synch_BSS_END;
extern Addr slot_synch_BSS_SIZE;
extern Addr slot_synch_BSS_START;
extern Addr slot_synch_DATA_END;
extern Addr slot_synch_DATA_SIZE;
extern Addr slot_synch_DATA_START;
extern Addr slot_synch_RODATA_END;
extern Addr slot_synch_RODATA_SIZE;
extern Addr slot_synch_RODATA_START;
extern Addr slot_synch_ROM_END;
extern Addr slot_synch_ROM_START;
extern Addr slot_synch_TEXT_END;
extern Addr slot_synch_TEXT_SIZE;
extern Addr slot_synch_TEXT_START;
extern Addr slot_synch_VRAM;
extern Addr slot_synch_VRAM_END;
extern Addr slot_synch_bss_VRAM;
extern Addr snowball_summit_BSS_END;
extern Addr snowball_summit_BSS_SIZE;
extern Addr snowball_summit_BSS_START;
extern Addr snowball_summit_DATA_END;
extern Addr snowball_summit_DATA_SIZE;
extern Addr snowball_summit_DATA_START;
extern Addr snowball_summit_RODATA_END;
extern Addr snowball_summit_RODATA_SIZE;
extern Addr snowball_summit_RODATA_START;
extern Addr snowball_summit_ROM_END;
extern Addr snowball_summit_ROM_START;
extern Addr snowball_summit_TEXT_END;
extern Addr snowball_summit_TEXT_SIZE;
extern Addr snowball_summit_TEXT_START;
extern Addr snowball_summit_VRAM;
extern Addr snowball_summit_VRAM_END;
extern Addr snowball_summit_bss_VRAM;
extern Addr spotlight_swim_BSS_END;
extern Addr spotlight_swim_BSS_SIZE;
extern Addr spotlight_swim_BSS_START;
extern Addr spotlight_swim_DATA_END;
extern Addr spotlight_swim_DATA_SIZE;
extern Addr spotlight_swim_DATA_START;
extern Addr spotlight_swim_RODATA_END;
extern Addr spotlight_swim_RODATA_SIZE;
extern Addr spotlight_swim_RODATA_START;
extern Addr spotlight_swim_ROM_END;
extern Addr spotlight_swim_ROM_START;
extern Addr spotlight_swim_TEXT_END;
extern Addr spotlight_swim_TEXT_SIZE;
extern Addr spotlight_swim_TEXT_START;
extern Addr spotlight_swim_VRAM;
extern Addr spotlight_swim_VRAM_END;
extern Addr spotlight_swim_bss_VRAM;
extern Addr stacked_deck_BSS_END;
extern Addr stacked_deck_BSS_SIZE;
extern Addr stacked_deck_BSS_START;
extern Addr stacked_deck_DATA_END;
extern Addr stacked_deck_DATA_SIZE;
extern Addr stacked_deck_DATA_START;
extern Addr stacked_deck_RODATA_END;
extern Addr stacked_deck_RODATA_SIZE;
extern Addr stacked_deck_RODATA_START;
extern Addr stacked_deck_ROM_END;
extern Addr stacked_deck_ROM_START;
extern Addr stacked_deck_TEXT_END;
extern Addr stacked_deck_TEXT_SIZE;
extern Addr stacked_deck_TEXT_START;
extern Addr stacked_deck_VRAM;
extern Addr stacked_deck_VRAM_END;
extern Addr stacked_deck_bss_VRAM;
extern Addr staff_BSS_END;
extern Addr staff_BSS_SIZE;
extern Addr staff_BSS_START;
extern Addr staff_DATA_END;
extern Addr staff_DATA_SIZE;
extern Addr staff_DATA_START;
extern Addr staff_RODATA_END;
extern Addr staff_RODATA_SIZE;
extern Addr staff_RODATA_START;
extern Addr staff_ROM_END;
extern Addr staff_ROM_START;
extern Addr staff_TEXT_END;
extern Addr staff_TEXT_SIZE;
extern Addr staff_TEXT_START;
extern Addr staff_VRAM;
extern Addr staff_VRAM_END;
extern Addr staff_bss_VRAM;
extern Addr stardust_battle_BSS_END;
extern Addr stardust_battle_BSS_SIZE;
extern Addr stardust_battle_BSS_START;
extern Addr stardust_battle_DATA_END;
extern Addr stardust_battle_DATA_SIZE;
extern Addr stardust_battle_DATA_START;
extern Addr stardust_battle_RODATA_END;
extern Addr stardust_battle_RODATA_SIZE;
extern Addr stardust_battle_RODATA_START;
extern Addr stardust_battle_ROM_END;
extern Addr stardust_battle_ROM_START;
extern Addr stardust_battle_TEXT_END;
extern Addr stardust_battle_TEXT_SIZE;
extern Addr stardust_battle_TEXT_START;
extern Addr stardust_battle_VRAM;
extern Addr stardust_battle_VRAM_END;
extern Addr stardust_battle_bss_VRAM;
extern Addr storm_chasers_BSS_END;
extern Addr storm_chasers_BSS_SIZE;
extern Addr storm_chasers_BSS_START;
extern Addr storm_chasers_DATA_END;
extern Addr storm_chasers_DATA_SIZE;
extern Addr storm_chasers_DATA_START;
extern Addr storm_chasers_RODATA_END;
extern Addr storm_chasers_RODATA_SIZE;
extern Addr storm_chasers_RODATA_START;
extern Addr storm_chasers_ROM_END;
extern Addr storm_chasers_ROM_START;
extern Addr storm_chasers_TEXT_END;
extern Addr storm_chasers_TEXT_SIZE;
extern Addr storm_chasers_TEXT_START;
extern Addr storm_chasers_VRAM;
extern Addr storm_chasers_VRAM_END;
extern Addr storm_chasers_bss_VRAM;
extern Addr storycall_BSS_END;
extern Addr storycall_BSS_SIZE;
extern Addr storycall_BSS_START;
extern Addr storycall_DATA_END;
extern Addr storycall_DATA_SIZE;
extern Addr storycall_DATA_START;
extern Addr storycall_RODATA_END;
extern Addr storycall_RODATA_SIZE;
extern Addr storycall_RODATA_START;
extern Addr storycall_ROM_END;
extern Addr storycall_ROM_START;
extern Addr storycall_TEXT_END;
extern Addr storycall_TEXT_SIZE;
extern Addr storycall_TEXT_START;
extern Addr storycall_VRAM;
extern Addr storycall_VRAM_END;
extern Addr storycall_bss_VRAM;
extern Addr storydebug_BSS_END;
extern Addr storydebug_BSS_SIZE;
extern Addr storydebug_BSS_START;
extern Addr storydebug_DATA_END;
extern Addr storydebug_DATA_SIZE;
extern Addr storydebug_DATA_START;
extern Addr storydebug_RODATA_END;
extern Addr storydebug_RODATA_SIZE;
extern Addr storydebug_RODATA_START;
extern Addr storydebug_ROM_END;
extern Addr storydebug_ROM_START;
extern Addr storydebug_TEXT_END;
extern Addr storydebug_TEXT_SIZE;
extern Addr storydebug_TEXT_START;
extern Addr storydebug_VRAM;
extern Addr storydebug_VRAM_END;
extern Addr storydebug_bss_VRAM;
extern Addr storyresult_BSS_END;
extern Addr storyresult_BSS_SIZE;
extern Addr storyresult_BSS_START;
extern Addr storyresult_DATA_END;
extern Addr storyresult_DATA_SIZE;
extern Addr storyresult_DATA_START;
extern Addr storyresult_RODATA_END;
extern Addr storyresult_RODATA_SIZE;
extern Addr storyresult_RODATA_START;
extern Addr storyresult_ROM_END;
extern Addr storyresult_ROM_START;
extern Addr storyresult_TEXT_END;
extern Addr storyresult_TEXT_SIZE;
extern Addr storyresult_TEXT_START;
extern Addr storyresult_VRAM;
extern Addr storyresult_VRAM_END;
extern Addr storyresult_bss_VRAM;
extern Addr strings_english_DATA_END;
extern Addr strings_english_DATA_SIZE;
extern Addr strings_english_DATA_START;
extern Addr strings_english_ROM_END;
extern Addr strings_english_ROM_START;
extern Addr strings_english_VRAM;
extern Addr strings_english_VRAM_END;
extern Addr strings_french_DATA_END;
extern Addr strings_french_DATA_SIZE;
extern Addr strings_french_DATA_START;
extern Addr strings_french_ROM_END;
extern Addr strings_french_ROM_START;
extern Addr strings_french_VRAM;
extern Addr strings_french_VRAM_END;
extern Addr strings_german_DATA_END;
extern Addr strings_german_DATA_SIZE;
extern Addr strings_german_DATA_START;
extern Addr strings_german_ROM_END;
extern Addr strings_german_ROM_START;
extern Addr strings_german_VRAM;
extern Addr strings_german_VRAM_END;
extern Addr strings_italian_DATA_END;
extern Addr strings_italian_DATA_SIZE;
extern Addr strings_italian_DATA_START;
extern Addr strings_italian_ROM_END;
extern Addr strings_italian_ROM_START;
extern Addr strings_italian_VRAM;
extern Addr strings_italian_VRAM_END;
extern Addr strings_japanese_DATA_END;
extern Addr strings_japanese_DATA_SIZE;
extern Addr strings_japanese_DATA_START;
extern Addr strings_japanese_ROM_END;
extern Addr strings_japanese_ROM_START;
extern Addr strings_japanese_VRAM;
extern Addr strings_japanese_VRAM_END;
extern Addr strings_spanish_DATA_END;
extern Addr strings_spanish_DATA_SIZE;
extern Addr strings_spanish_DATA_START;
extern Addr strings_spanish_ROM_END;
extern Addr strings_spanish_ROM_START;
extern Addr strings_spanish_VRAM;
extern Addr strings_spanish_VRAM_END;
extern Addr swing_n_swipe_BSS_END;
extern Addr swing_n_swipe_BSS_SIZE;
extern Addr swing_n_swipe_BSS_START;
extern Addr swing_n_swipe_DATA_END;
extern Addr swing_n_swipe_DATA_SIZE;
extern Addr swing_n_swipe_DATA_START;
extern Addr swing_n_swipe_RODATA_END;
extern Addr swing_n_swipe_RODATA_SIZE;
extern Addr swing_n_swipe_RODATA_START;
extern Addr swing_n_swipe_ROM_END;
extern Addr swing_n_swipe_ROM_START;
extern Addr swing_n_swipe_TEXT_END;
extern Addr swing_n_swipe_TEXT_SIZE;
extern Addr swing_n_swipe_TEXT_START;
extern Addr swing_n_swipe_VRAM;
extern Addr swing_n_swipe_VRAM_END;
extern Addr swing_n_swipe_bss_VRAM;
extern Addr swinging_with_sharks_BSS_END;
extern Addr swinging_with_sharks_BSS_SIZE;
extern Addr swinging_with_sharks_BSS_START;
extern Addr swinging_with_sharks_DATA_END;
extern Addr swinging_with_sharks_DATA_SIZE;
extern Addr swinging_with_sharks_DATA_START;
extern Addr swinging_with_sharks_RODATA_END;
extern Addr swinging_with_sharks_RODATA_SIZE;
extern Addr swinging_with_sharks_RODATA_START;
extern Addr swinging_with_sharks_ROM_END;
extern Addr swinging_with_sharks_ROM_START;
extern Addr swinging_with_sharks_TEXT_END;
extern Addr swinging_with_sharks_TEXT_SIZE;
extern Addr swinging_with_sharks_TEXT_START;
extern Addr swinging_with_sharks_VRAM;
extern Addr swinging_with_sharks_VRAM_END;
extern Addr swinging_with_sharks_bss_VRAM;
extern Addr the_beat_goes_on_BSS_END;
extern Addr the_beat_goes_on_BSS_SIZE;
extern Addr the_beat_goes_on_BSS_START;
extern Addr the_beat_goes_on_DATA_END;
extern Addr the_beat_goes_on_DATA_SIZE;
extern Addr the_beat_goes_on_DATA_START;
extern Addr the_beat_goes_on_RODATA_END;
extern Addr the_beat_goes_on_RODATA_SIZE;
extern Addr the_beat_goes_on_RODATA_START;
extern Addr the_beat_goes_on_ROM_END;
extern Addr the_beat_goes_on_ROM_START;
extern Addr the_beat_goes_on_TEXT_END;
extern Addr the_beat_goes_on_TEXT_SIZE;
extern Addr the_beat_goes_on_TEXT_START;
extern Addr the_beat_goes_on_VRAM;
extern Addr the_beat_goes_on_VRAM_END;
extern Addr the_beat_goes_on_bss_VRAM;
extern Addr three_door_monty_BSS_END;
extern Addr three_door_monty_BSS_SIZE;
extern Addr three_door_monty_BSS_START;
extern Addr three_door_monty_DATA_END;
extern Addr three_door_monty_DATA_SIZE;
extern Addr three_door_monty_DATA_START;
extern Addr three_door_monty_RODATA_END;
extern Addr three_door_monty_RODATA_SIZE;
extern Addr three_door_monty_RODATA_START;
extern Addr three_door_monty_ROM_END;
extern Addr three_door_monty_ROM_START;
extern Addr three_door_monty_TEXT_END;
extern Addr three_door_monty_TEXT_SIZE;
extern Addr three_door_monty_TEXT_START;
extern Addr three_door_monty_VRAM;
extern Addr three_door_monty_VRAM_END;
extern Addr three_door_monty_bss_VRAM;
extern Addr thwomp_pull_BSS_END;
extern Addr thwomp_pull_BSS_SIZE;
extern Addr thwomp_pull_BSS_START;
extern Addr thwomp_pull_DATA_END;
extern Addr thwomp_pull_DATA_SIZE;
extern Addr thwomp_pull_DATA_START;
extern Addr thwomp_pull_RODATA_END;
extern Addr thwomp_pull_RODATA_SIZE;
extern Addr thwomp_pull_RODATA_START;
extern Addr thwomp_pull_ROM_END;
extern Addr thwomp_pull_ROM_START;
extern Addr thwomp_pull_TEXT_END;
extern Addr thwomp_pull_TEXT_SIZE;
extern Addr thwomp_pull_TEXT_START;
extern Addr thwomp_pull_VRAM;
extern Addr thwomp_pull_VRAM_END;
extern Addr thwomp_pull_bss_VRAM;
extern Addr tick_tock_hop_BSS_END;
extern Addr tick_tock_hop_BSS_SIZE;
extern Addr tick_tock_hop_BSS_START;
extern Addr tick_tock_hop_DATA_END;
extern Addr tick_tock_hop_DATA_SIZE;
extern Addr tick_tock_hop_DATA_START;
extern Addr tick_tock_hop_RODATA_END;
extern Addr tick_tock_hop_RODATA_SIZE;
extern Addr tick_tock_hop_RODATA_START;
extern Addr tick_tock_hop_ROM_END;
extern Addr tick_tock_hop_ROM_START;
extern Addr tick_tock_hop_TEXT_END;
extern Addr tick_tock_hop_TEXT_SIZE;
extern Addr tick_tock_hop_TEXT_START;
extern Addr tick_tock_hop_VRAM;
extern Addr tick_tock_hop_VRAM_END;
extern Addr tick_tock_hop_bss_VRAM;
extern Addr tidal_toss_BSS_END;
extern Addr tidal_toss_BSS_SIZE;
extern Addr tidal_toss_BSS_START;
extern Addr tidal_toss_DATA_END;
extern Addr tidal_toss_DATA_SIZE;
extern Addr tidal_toss_DATA_START;
extern Addr tidal_toss_RODATA_END;
extern Addr tidal_toss_RODATA_SIZE;
extern Addr tidal_toss_RODATA_START;
extern Addr tidal_toss_ROM_END;
extern Addr tidal_toss_ROM_START;
extern Addr tidal_toss_TEXT_END;
extern Addr tidal_toss_TEXT_SIZE;
extern Addr tidal_toss_TEXT_START;
extern Addr tidal_toss_VRAM;
extern Addr tidal_toss_VRAM_END;
extern Addr tidal_toss_bss_VRAM;
extern Addr toadstool_titan_BSS_END;
extern Addr toadstool_titan_BSS_SIZE;
extern Addr toadstool_titan_BSS_START;
extern Addr toadstool_titan_DATA_END;
extern Addr toadstool_titan_DATA_SIZE;
extern Addr toadstool_titan_DATA_START;
extern Addr toadstool_titan_RODATA_END;
extern Addr toadstool_titan_RODATA_SIZE;
extern Addr toadstool_titan_RODATA_START;
extern Addr toadstool_titan_ROM_END;
extern Addr toadstool_titan_ROM_START;
extern Addr toadstool_titan_TEXT_END;
extern Addr toadstool_titan_TEXT_SIZE;
extern Addr toadstool_titan_TEXT_START;
extern Addr toadstool_titan_VRAM;
extern Addr toadstool_titan_VRAM_END;
extern Addr toadstool_titan_bss_VRAM;
extern Addr treadmill_grill_BSS_END;
extern Addr treadmill_grill_BSS_SIZE;
extern Addr treadmill_grill_BSS_START;
extern Addr treadmill_grill_DATA_END;
extern Addr treadmill_grill_DATA_SIZE;
extern Addr treadmill_grill_DATA_START;
extern Addr treadmill_grill_RODATA_END;
extern Addr treadmill_grill_RODATA_SIZE;
extern Addr treadmill_grill_RODATA_START;
extern Addr treadmill_grill_ROM_END;
extern Addr treadmill_grill_ROM_START;
extern Addr treadmill_grill_TEXT_END;
extern Addr treadmill_grill_TEXT_SIZE;
extern Addr treadmill_grill_TEXT_START;
extern Addr treadmill_grill_VRAM;
extern Addr treadmill_grill_VRAM_END;
extern Addr treadmill_grill_bss_VRAM;
extern Addr unk_557620_DATA_END;
extern Addr unk_557620_DATA_SIZE;
extern Addr unk_557620_DATA_START;
extern Addr unk_557620_ROM_END;
extern Addr unk_557620_ROM_START;
extern Addr unk_557620_VRAM;
extern Addr unk_557620_VRAM_END;
extern Addr vine_with_me_BSS_END;
extern Addr vine_with_me_BSS_SIZE;
extern Addr vine_with_me_BSS_START;
extern Addr vine_with_me_DATA_END;
extern Addr vine_with_me_DATA_SIZE;
extern Addr vine_with_me_DATA_START;
extern Addr vine_with_me_RODATA_END;
extern Addr vine_with_me_RODATA_SIZE;
extern Addr vine_with_me_RODATA_START;
extern Addr vine_with_me_ROM_END;
extern Addr vine_with_me_ROM_START;
extern Addr vine_with_me_TEXT_END;
extern Addr vine_with_me_TEXT_SIZE;
extern Addr vine_with_me_TEXT_START;
extern Addr vine_with_me_VRAM;
extern Addr vine_with_me_VRAM_END;
extern Addr vine_with_me_bss_VRAM;
extern Addr w02_BSS_END;
extern Addr w02_BSS_SIZE;
extern Addr w02_BSS_START;
extern Addr w02_DATA_END;
extern Addr w02_DATA_SIZE;
extern Addr w02_DATA_START;
extern Addr w02_RODATA_END;
extern Addr w02_RODATA_SIZE;
extern Addr w02_RODATA_START;
extern Addr w02_ROM_END;
extern Addr w02_ROM_START;
extern Addr w02_TEXT_END;
extern Addr w02_TEXT_SIZE;
extern Addr w02_TEXT_START;
extern Addr w02_VRAM;
extern Addr w02_VRAM_END;
extern Addr w02_bss_VRAM;
extern Addr w03_BSS_END;
extern Addr w03_BSS_SIZE;
extern Addr w03_BSS_START;
extern Addr w03_DATA_END;
extern Addr w03_DATA_SIZE;
extern Addr w03_DATA_START;
extern Addr w03_RODATA_END;
extern Addr w03_RODATA_SIZE;
extern Addr w03_RODATA_START;
extern Addr w03_ROM_END;
extern Addr w03_ROM_START;
extern Addr w03_TEXT_END;
extern Addr w03_TEXT_SIZE;
extern Addr w03_TEXT_START;
extern Addr w03_VRAM;
extern Addr w03_VRAM_END;
extern Addr w03_bss_VRAM;
extern Addr w04_BSS_END;
extern Addr w04_BSS_SIZE;
extern Addr w04_BSS_START;
extern Addr w04_DATA_END;
extern Addr w04_DATA_SIZE;
extern Addr w04_DATA_START;
extern Addr w04_RODATA_END;
extern Addr w04_RODATA_SIZE;
extern Addr w04_RODATA_START;
extern Addr w04_ROM_END;
extern Addr w04_ROM_START;
extern Addr w04_TEXT_END;
extern Addr w04_TEXT_SIZE;
extern Addr w04_TEXT_START;
extern Addr w04_VRAM;
extern Addr w04_VRAM_END;
extern Addr w04_bss_VRAM;
extern Addr w05_BSS_END;
extern Addr w05_BSS_SIZE;
extern Addr w05_BSS_START;
extern Addr w05_DATA_END;
extern Addr w05_DATA_SIZE;
extern Addr w05_DATA_START;
extern Addr w05_RODATA_END;
extern Addr w05_RODATA_SIZE;
extern Addr w05_RODATA_START;
extern Addr w05_ROM_END;
extern Addr w05_ROM_START;
extern Addr w05_TEXT_END;
extern Addr w05_TEXT_SIZE;
extern Addr w05_TEXT_START;
extern Addr w05_VRAM;
extern Addr w05_VRAM_END;
extern Addr w05_bss_VRAM;
extern Addr w06_BSS_END;
extern Addr w06_BSS_SIZE;
extern Addr w06_BSS_START;
extern Addr w06_DATA_END;
extern Addr w06_DATA_SIZE;
extern Addr w06_DATA_START;
extern Addr w06_RODATA_END;
extern Addr w06_RODATA_SIZE;
extern Addr w06_RODATA_START;
extern Addr w06_ROM_END;
extern Addr w06_ROM_START;
extern Addr w06_TEXT_END;
extern Addr w06_TEXT_SIZE;
extern Addr w06_TEXT_START;
extern Addr w06_VRAM;
extern Addr w06_VRAM_END;
extern Addr w06_bss_VRAM;
extern Addr w10_BSS_END;
extern Addr w10_BSS_SIZE;
extern Addr w10_BSS_START;
extern Addr w10_DATA_END;
extern Addr w10_DATA_SIZE;
extern Addr w10_DATA_START;
extern Addr w10_RODATA_END;
extern Addr w10_RODATA_SIZE;
extern Addr w10_RODATA_START;
extern Addr w10_ROM_END;
extern Addr w10_ROM_START;
extern Addr w10_TEXT_END;
extern Addr w10_TEXT_SIZE;
extern Addr w10_TEXT_START;
extern Addr w10_VRAM;
extern Addr w10_VRAM_END;
extern Addr w10_bss_VRAM;
extern Addr water_whirled_BSS_END;
extern Addr water_whirled_BSS_SIZE;
extern Addr water_whirled_BSS_START;
extern Addr water_whirled_DATA_END;
extern Addr water_whirled_DATA_SIZE;
extern Addr water_whirled_DATA_START;
extern Addr water_whirled_RODATA_END;
extern Addr water_whirled_RODATA_SIZE;
extern Addr water_whirled_RODATA_START;
extern Addr water_whirled_ROM_END;
extern Addr water_whirled_ROM_START;
extern Addr water_whirled_TEXT_END;
extern Addr water_whirled_TEXT_SIZE;
extern Addr water_whirled_TEXT_START;
extern Addr water_whirled_VRAM;
extern Addr water_whirled_VRAM_END;
extern Addr water_whirled_bss_VRAM;
extern Addr winners_wheel_BSS_END;
extern Addr winners_wheel_BSS_SIZE;
extern Addr winners_wheel_BSS_START;
extern Addr winners_wheel_DATA_END;
extern Addr winners_wheel_DATA_SIZE;
extern Addr winners_wheel_DATA_START;
extern Addr winners_wheel_RODATA_END;
extern Addr winners_wheel_RODATA_SIZE;
extern Addr winners_wheel_RODATA_START;
extern Addr winners_wheel_ROM_END;
extern Addr winners_wheel_ROM_START;
extern Addr winners_wheel_TEXT_END;
extern Addr winners_wheel_TEXT_SIZE;
extern Addr winners_wheel_TEXT_START;
extern Addr winners_wheel_VRAM;
extern Addr winners_wheel_VRAM_END;
extern Addr winners_wheel_bss_VRAM;
s16 func_80011460_12060(u8 *arg0) {
    s32 sum = 0;
    s16 i = 1;
    u8 c = arg0[0];
    while (c != 0 && i < 28) {
        sum += i * c;
        arg0++;
        i++;
        c = arg0[0];
    }
    return sum;
}
