typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long int ptrdiff_t;
typedef unsigned long int size_t;
typedef int wchar_t;
void * memchr (const void *, int, size_t);
int memcmp (const void *, const void *, size_t);
void * memcpy (void *, const void *, size_t);
void * memmove (void *, const void *, size_t);
void * memset (void *, int, size_t);
char *strcat (char *, const char *);
char *strchr (const char *, int);
int strcmp (const char *, const char *);
int strcoll (const char *, const char *);
char *strcpy (char *, const char *);
size_t strcspn (const char *, const char *);
char *strerror (int);
size_t strlen (const char *);
char *strncat (char *, const char *, size_t);
int strncmp (const char *, const char *, size_t);
char *strncpy (char *, const char *, size_t);
char *strpbrk (const char *, const char *);
char *strrchr (const char *, int);
size_t strspn (const char *, const char *);
char *strstr (const char *, const char *);
char *strtok (char *, const char *);
size_t strxfrm (char *, const char *, size_t);
char *strtok_r (char *, const char *, char **);
int bcmp (const char *, const char *, size_t);
void bcopy (const char *, char *, size_t);
void bzero (char *, size_t);
int ffs (int);
char *index (const char *, int);
void * memccpy (void *, const void *, int, size_t);
char *rindex (const char *, int);
int strcasecmp (const char *, const char *);
char *strdup (const char *);
int strncasecmp (const char *, const char *, size_t);
char *strsep (char **, const char *);
char *strlwr (char *);
char *strupr (char *);
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef int int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef u8 bool8;
typedef u16 bool16;
typedef u32 bool32;
struct BgCnt
{
    u16 priority:2;
    u16 charBaseBlock:2;
    u16 dummy:2;
    u16 mosaic:1;
    u16 palettes:1;
    u16 screenBaseBlock:5;
    u16 areaOverflowMode:1;
    u16 screenSize:2;
};
typedef volatile struct BgCnt vBgCnt;
struct PlttData
{
    u16 r:5;
    u16 g:5;
    u16 b:5;
    u16 unused_15:1;
};
typedef union {
    struct {
             u32 y:8;
             u32 affineMode:2;
             u32 objMode:2;
             u32 mosaic:1;
             u32 bpp:1;
             u32 shape:2;
             u32 x:9;
             u32 matrixNum:5;
             u32 size:2;
             u16 tileNum:10;
             u16 priority:2;
             u16 paletteNum:4;
             u16 fractional:8;
             u16 integer:7;
             u16 sign:1;
    } split;
    struct {
        u16 attr0;
        u16 attr1;
        u16 attr2;
        u16 affineParam;
    } all;
} OamData;
struct BgAffineSrcData
{
    s32 texX;
    s32 texY;
    s16 scrX;
    s16 scrY;
    s16 sx;
    s16 sy;
    u16 alpha;
};
struct BgAffineDstData
{
    s16 pa;
    s16 pb;
    s16 pc;
    s16 pd;
    s32 dx;
    s32 dy;
};
struct ObjAffineSrcData
{
    s16 xScale;
    s16 yScale;
    u16 rotation;
};
struct SioNormalCnt
{
    u16 sck_I_O:1;
    u16 sck:1;
    u16 ackRecv:1;
    u16 ackSend:1;
    u16 unused_6_4:3;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct SioMultiCnt
{
    u16 baudRate:2;
    u16 si:1;
    u16 sd:1;
    u16 id:2;
    u16 error:1;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u16 data;
};
struct SioUartCnt
{
    u16 baudRate:2;
    u16 ctsEnable:1;
    u16 paritySelect:1;
    u16 transDataFull:1;
    u16 recvDataEmpty:1;
    u16 error:1;
    u16 length:1;
    u16 fifoEnable:1;
    u16 parityEnable:1;
    u16 transEnable:1;
    u16 recvEnable:1;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct JoyCnt
{
    u8 ifReset:1;
    u8 ifRecv:1;
    u8 ifSend:1;
    u8 unused_5_3:3;
    u8 ifEnable:1;
    u8 unused_7:1;
};
struct JoyStat
{
    u8 unused_0:1;
    u8 recv:1;
    u8 unused_2:1;
    u8 send:1;
    u8 flags:2;
    u8 unused_7_6:2;
};
struct RCnt
{
    u8 sc:1;
    u8 sd:1;
    u8 si:1;
    u8 so:1;
    u8 sc_i_o:1;
    u8 sd_i_o:1;
    u8 si_i_o:1;
    u8 so_i_o:1;
    u8 ifEnable:1;
    u8 unused_13_9:5;
    u8 sioModeMaster:2;
};
void CpuSet(const void *src, void *dest, u32 control);
void HuffUnComp(const void *src, void *dest);
void LZ77UnCompWram(const void *src, void *dest);
u16 Sqrt(u32 num);
void VBlankIntrWait(void);
void SoftResetRom(u32 resetFlags);
typedef s32 fixed8_24;
struct MP2KTrack;
struct MP2KPlayerState;
typedef void (*MP2KEventNoteFunc)(u8, struct MP2KPlayerState *, struct MP2KTrack *);
typedef void (*MP2KEventFunc)(struct MP2KPlayerState *, struct MP2KTrack *);
typedef void (*CgbSoundFunc)(void);
typedef void (*CgbOscOffFunc)(u8);
typedef u32 (*MidiKeyToCgbFreqFunc)(u8, u8, u8);
typedef void (*ExtVolPitFunc)(void);
typedef void (*MPlayMainFunc)(struct MP2KPlayerState *);
struct MixerSource {
    u8 status;
    u8 type;
    u8 rightVol;
    u8 leftVol;
    union {
        struct {
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
            u8 key;
            u8 envelopeVol;
            u8 envelopeGoal;
            u8 envelopeCtr;
            u8 echoVol;
            u8 echoLen;
            u8 padding1;
            u8 padding2;
            u8 gateTime;
            u8 untransposedKey;
            u8 velocity;
            u8 priority;
            u8 rhythmPan;
            u8 padding3;
            u8 padding4;
            u8 padding5;
            u8 padding6;
            u8 sustainGoal;
            u8 nrx4;
            u8 pan;
            u8 panMask;
            u8 cgbStatus;
            u8 length;
            u8 sweep;
            u32 freq;
        } cgb;
        struct {
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
            u8 key;
            u8 envelopeVol;
            u8 envelopeVolR;
            u8 envelopeVolL;
            u8 echoVol;
            u8 echoLen;
            u8 padding1;
            u8 padding2;
            u8 gateTime;
            u8 untransposedKey;
            u8 velocity;
            u8 priority;
            u8 rhythmPan;
            u8 padding3;
            u8 padding4;
            u8 padding5;
            u32 ct;
            fixed8_24 fw;
            u32 freq;
        } sound;
    } data;
    void *wav;
    void *current;
    struct MP2KTrack *track;
    struct MixerSource *prev;
    struct MixerSource *next;
    u32 padding7;
    u32 blockCount;
};
struct SoundMixerState {
    u32 lockStatus;
    vu8 dmaCounter;
    u8 reverb;
    u8 numChans;
    u8 masterVol;
    u8 freqOption;
    u8 extensionFlags;
    u8 cgbCounter15;
    u8 framesPerDmaCycle;
    u8 maxScanlines;
    u8 gap[3];
    s32 samplesPerFrame;
    s32 sampleRate;
    s32 sampleRateReciprocal;
    struct MixerSource *cgbChans;
    MPlayMainFunc MPlayMainHead;
    struct MP2KPlayerState *musicPlayerHead;
    CgbSoundFunc CgbSound;
    CgbOscOffFunc CgbOscOff;
    MidiKeyToCgbFreqFunc MidiKeyToCgbFreq;
    void **MPlayJumpTable;
    MP2KEventNoteFunc plynote;
    ExtVolPitFunc ExtVolPit;
    void *reserved2;
    void *reserved3;
    void *reversed4;
    void *reserved5;
    struct MixerSource chans[12];
    s8 pcmBuffer[1584 * 2];
};
struct MP2KVoiceGroup {
    u8 type;
    u8 drumKey;
    u8 cgbLength;
    u8 pan_sweep;
    union {
        struct {
            struct WaveData *wav;
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
        } sound;
        struct {
            struct MP2KVoiceGroup *group;
            u8 *keySplitTable;
        } keySplit;
    } data;
};
struct WaveData {
    u16 type;
    u16 status;
    u32 freq;
    u32 loopStart;
    u32 size;
    s8 data[1];
};
struct MP2KSongHeader {
    u8 trackCount;
    u8 blockCount;
    u8 priority;
    u8 reverb;
    struct MP2KVoiceGroup *voicegroup;
    u8 *part[1];
};
struct MP2KTrack {
    u8 status;
    u8 wait;
    u8 patternLevel;
    u8 repeatCount;
    u8 gateTime;
    u8 key;
    u8 velocity;
    u8 runningStatus;
    s8 keyShiftCalculated;
    u8 pitchCalculated;
    s8 keyShift;
    s8 keyShiftPublic;
    s8 tune;
    u8 pitchPublic;
    s8 bend;
    u8 bendRange;
    u8 volRightCalculated;
    u8 volLeftCalculated;
    u8 vol;
    u8 volPublic;
    s8 pan;
    s8 panPublic;
    s8 modCalculated;
    u8 modDepth;
    u8 modType;
    u8 lfoSpeed;
    u8 lfoSpeedCounter;
    u8 lfoDelay;
    u8 lfoDelayCounter;
    u8 priority;
    u8 echoVolume;
    u8 echoLength;
    struct MixerSource *chan;
    struct MP2KVoiceGroup voicegroup;
    u8 gap[10];
    u16 unk_3A;
    u32 unk_3C;
    u8 *cmdPtr;
    u8 *patternStack[3];
};
struct MP2KPlayerState {
    struct MP2KSongHeader *songHeader;
    u32 status;
    u8 trackCount;
    u8 priority;
    u8 cmd;
    bool8 checkSongPriority;
    u32 clock;
    u8 padding[8];
    u8 *memAccArea;
    u16 tempoRawBPM;
    u16 tempoScale;
    u16 tempoInterval;
    u16 tempoCounter;
    u16 fadeInterval;
    u16 fadeCounter;
    u16 fadeOV;
    struct MP2KTrack *tracks;
    struct MP2KVoiceGroup *voicegroup;
    u32 lockStatus;
    MPlayMainFunc nextPlayerFunc;
    struct MP2KPlayerState *nextPlayer;
};
struct MusicPlayer {
    struct MP2KPlayerState *info;
    struct MP2KTrack *track;
    u8 numTracks;
    u16 unk_A;
};
struct Song {
    struct MP2KSongHeader *header;
    u16 ms;
    u16 me;
};
typedef void (*XcmdFunc)(struct MP2KPlayerState *, struct MP2KTrack *);
extern char SoundMainRAM[];
extern u8 gMPlayMemAccArea[];
extern void *gMPlayJumpTable[];
extern struct MixerSource gCgbChans[];
extern const struct MusicPlayer gMPlayTable[4];
extern const struct Song gSongTable[];
extern const XcmdFunc gXcmdTable[];
extern const u8 gClockTable[];
extern const u8 gScaleTable[];
extern const u32 gFreqTable[];
extern const u16 gPcmSamplesPerVBlankTable[];
extern void *const gMPlayJumpTableTemplate[];
extern const u8 gCgbScaleTable[];
extern const s16 gCgbFreqTable[];
extern const u8 gNoiseTable[];
extern const u8 gCgb3Vol[];
extern char gNumMusicPlayers[];
extern char gMaxLines[];
u32 MidiKeyToFreq(struct WaveData *wav, u8 key, u8 fineAdjust);
u32 umul3232H32(u32 multiplier, u32 multiplicand);
void SoundMain(void);
void SoundMainBTM(void *ptr);
void TrackStop(struct MP2KPlayerState *player, struct MP2KTrack *track);
void MP2KPlayerMain(struct MP2KPlayerState *);
void ClearChain(struct MixerSource *chan);
void MP2KClearChain(struct MixerSource *chan);
void MPlayContinue(struct MP2KPlayerState *mplayInfo);
void MPlayStart(struct MP2KPlayerState *mplayInfo, struct MP2KSongHeader *songHeader);
void MPlayStop(struct MP2KPlayerState *mplayInfo);
void FadeOutBody(struct MP2KPlayerState *mplayInfo);
void TrkVolPitSet(struct MP2KPlayerState *mplayInfo, struct MP2KTrack *track);
void MPlayFadeOut(struct MP2KPlayerState *mplayInfo, u16 speed);
void Clear64byte(void *addr);
void SoundInit(struct SoundMixerState *soundInfo);
void MPlayExtender(struct MixerSource *cgbChans);
void m4aSoundMode(u32 mode);
void MPlayOpen(struct MP2KPlayerState *mplayInfo, struct MP2KTrack *tracks, u8 trackCount);
void CgbSound(void);
void CgbOscOff(u8);
void CgbModVol(struct MixerSource *chan);
u32 MidiKeyToCgbFreq(u8, u8, u8);
void MPlayJumpTableCopy(void **mplayJumpTable);
void SampleFreqSet(u32 freq);
void m4aSoundVSyncOn(void);
void m4aSoundVSyncOff(void);
void m4aMPlayTempoControl(struct MP2KPlayerState *mplayInfo, u16 tempo);
void m4aMPlayVolumeControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, u16 volume);
void m4aMPlayPitchControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s16 pitch);
void m4aMPlayPanpotControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s8 pan);
void ClearModM(struct MP2KTrack *track);
void m4aMPlayModDepthSet(struct MP2KPlayerState *mplayInfo, u16 trackBits, u8 modDepth);
void m4aMPlayLFOSpeedSet(struct MP2KPlayerState *mplayInfo, u16 trackBits, u8 lfoSpeed);
void MP2K_event_fine(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_goto(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_patt(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_pend(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_rept(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_memacc(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_prio(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_tempo(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_keysh(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_voice(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_vol(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_pan(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_bend(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_bendr(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_lfos(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_lfodl(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_mod(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_modt(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_tune(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_port(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_endtie(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_nxx(u8 clock, struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xxx(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xwave(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xtype(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xatta(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xdeca(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xsust(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xrele(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xiecv(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xiecl(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xleng(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xswee(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd_0C(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd_0D(struct MP2KPlayerState *, struct MP2KTrack *);
extern struct SoundMixerState gSoundInfo;
extern struct MP2KPlayerState gMPlayInfo_0;
extern struct MP2KPlayerState gMPlayInfo_1;
extern struct MP2KPlayerState gMPlayInfo_2;
extern struct MP2KPlayerState gMPlayInfo_3;
void m4aSoundVSync(void);
void m4aSoundInit(void);
void m4aSoundMain(void);
void m4aSongNumStart(u16);
void m4aSongNumStartOrChange(u16);
void m4aSongNumStartOrContinue(u16);
void m4aSongNumStop(u16 n);
void m4aSongNumContinue(u16 n);
void m4aMPlayAllStop(void);
void m4aMPlayAllContinue(void);
void m4aMPlayContinue(struct MP2KPlayerState *mplayInfo);
void m4aMPlayFadeOut(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayFadeOutTemporarily(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayFadeIn(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayImmInit(struct MP2KPlayerState *mplayInfo);
void m4aMPlayTempoControl(struct MP2KPlayerState *mplayInfo, u16 tempo);
void m4aMPlayVolumeControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, u16 volume);
void m4aMPlayPitchControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s16 pitch);
void m4aMPlayPanpotControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s8 pan);
void sub_08001158(void);
enum ScrollFlags {
    SCROLL_NONE = 0x0,
    SCROLL_RIGHT = 0x10,
    SCROLL_LEFT = 0x20,
    SCROLL_HORIZONTAL = SCROLL_LEFT | SCROLL_RIGHT,
    SCROLL_UP = 0x40,
    SCROLL_DOWN = 0x80,
    SCROLL_VERTICAL = SCROLL_DOWN | SCROLL_UP
};
struct ScrollOffset {
    u16 x;
    u16 y;
};
void ScrollBg2LevelData(u8 scrollFlags, struct ScrollOffset scrollOffset);
void PuzzleStageScrollUpdate(void);
void AthleticChallengeScrollUpdate(void);
void HoverBoardScrollUpdate(void);
void sub_08002AC4(void);
void sub_08002FD0(void);
void sub_0800343C(u8 arg0);
void ClearedAllVisionsScreenInit(void);
void ClearedAllVisionsScreenHandler(void);
void sub_08003904(void);
void sub_08003D58(void);
void sub_08003D80(void);
void sub_08003DA0(void);
void sub_08003DC0(s32 slot, u8 arg1, u16 x, u16 y, u8 arg4, u8 priority, u8 arg6, u8 arg7, u8 id);
void sub_08005CF4(void);
void sub_080070A0(void);
void sub_080098C8(void);
void sub_0800A468(void);
void sub_0800A49C(void);
void sub_0800A5B8(u8 arg0, s8 arg1, s8 arg2);
void sub_0800A71C(s8 arg0, s8 arg1);
void sub_0800A804(void);
void sub_0800AC34(void);
void sub_0800B3C0(void);
struct Unk_0800BEF0 {
    u16 unk0;
    u16 unk2;
    u16 unk4;
    u16 unk6;
    s8 unk8;
    s8 unk9;
};
struct Unk_0800BEF0_2 {
    u16 unk0;
    u16 unk2;
};
struct Unk_0800BEF0_2 sub_0800BEF0(struct Unk_0800BEF0 arg0);
void CommonWaitForNextFrame(void);
void BossWaitForNextFrame(void);
void VisionSelectWaitForNextFrame(void);
void CutsceneWaitForNextFrame(void);
void GameOverScreenWaitForNextFrame(void);
void ClearedAllVisionsScreenWaitForNextFrame(void);
void sub_0800CA0C(u32 arg0);
void TitleScreenWaitForNextFrame(void);
void sub_0800D188(void);
struct Unk_08014184 {
    u16 unk0;
    u8 unk2;
    u8 pad3[0x4 - 0x3];
};
struct Unk_08014184 sub_08014184(u16 arg1, u16 arg2, u8 arg3);
struct Unk_08014184 sub_08014230(u16 arg1, u16 arg2, u8 arg3);
void sub_08014318(void);
void sub_080144C4(void);
void sub_080145A8(s32 arg0);
void sub_08014624(s32 arg0);
void sub_08014760(u8 arg0);
void sub_08016EEC(u8 arg0);
void sub_0801B044(u8 arg0);
void sub_0801B688(u8 arg0);
void sub_0801BB6C(u8 arg0);
void sub_0801BCC0(u8 arg0);
void sub_0801BD48(u8 arg0);
void sub_0801C150(u8 arg0);
void sub_0801C6EC(u8 arg0);
void sub_0801CE38(u8 arg0);
void sub_0801D0D8(u8 arg0);
void sub_0801D4AC(u8 arg0);
void sub_0801D6B0(u8 arg0);
void sub_0801DE44(u8 arg0);
void sub_0801DFC4(u8 arg0);
void sub_0801E1A8(u8 arg0);
void sub_0801E354(u8 arg0);
void sub_0801E3FC(void);
void sub_0801E664(u16 arg0, u16 arg1, u8 arg2, u8 arg3);
void sub_0801EAA4(u8 arg0);
void sub_0801EF5C(u8 arg0);
void sub_0801F02C(u8 arg0);
void sub_0801F128(u8 arg0);
void sub_0801F648(u8 arg0);
void sub_0801FADC(u8 arg0);
void sub_0801FFF0(u8 arg0);
void sub_080202D4(u8 arg0);
void sub_08020FB8(u8 arg0);
void sub_08021194(u8 arg0);
void sub_0802192C(u8 arg0);
void sub_08021AD4(u8 arg0);
void sub_08022CA0(u8 arg0);
void sub_08023988(u8 arg0);
void sub_08023BC0(u8 arg0);
void sub_080240F4(void);
void sub_080241EC(void);
void TransitionToVisionSelectOrLevelGameplay_FadeIn(void);
void TransitionFromTitleScreenToFileSelect_FadeOut(void);
void TransitionFromDemoToTitleScreen_FadeOut(void);
void TransitionFromRoomToRoom_FadeOut(void);
void TransitionFromTitleScreenToFileSelect_FadeIn(void);
void sub_08024A78(void);
void sub_08024B54(void);
void TransitionFromVisionSelectToLevel_FadeOut(void);
void TransitionFromLevelToDeath_FadeOut(void);
void TransitionFromDeathToLevel_FadeOut(void);
void TransitionFromWorldMapToVisionSelect_FadeOut(void);
void TransitionFromFileSelectToLevel_FadeOut(void);
void TransitionFromWorldMapToLevel_FadeOut(void);
void TransitionFromVisionSelectToWorldMap_FadeIn(void);
void TransitionFromVisionSelectToWorldMap_FadeOut(void);
void TransitionFromVisionSelectToBootScreen_FadeOut(void);
void TransitionFromLevelToClearedAllVisionsScreen_FadeIn(void);
void TransitionFromLevelToClearedAllVisionsScreen_FadeOut(void);
void SetEntityAnimationInfoState(s32 slot, u8 state);
void UpdateEntityAnimationInfoEntries(void);
void DrawLevelHud_Hearts(void);
s32 DrawLevelHud_DreamStones(void);
void DrawLevelHud_Lives(void);
void DrawVisionSelectHud_Lives(void);
void DrawLevelTimer(void);
void DrawVisionStart(void);
void DrawVisionEnd(void);
void LoadObjects_World1Select(void);
void LoadObjects_World2Select(void);
void LoadObjects_World3Select(void);
void LoadObjects_World4Select(void);
void LoadObjects_World5Select(void);
void sub_08028104(void);
void LoadObjects_World1Level1(void);
void LoadObjects_World1Level2(void);
void LoadObjects_World1Level3(void);
void LoadObjects_World1Level4(void);
void LoadObjects_World1Level5(void);
void LoadObjects_World1Level6(void);
void LoadObjects_World1Level7(void);
void LoadObjects_World1Boss(void);
void LoadObjects_World2Level1(void);
void LoadObjects_World2Level2(void);
void LoadObjects_World2Level3(void);
void LoadObjects_World2Level4(void);
void LoadObjects_World2Level5(void);
void LoadObjects_World2Level6(void);
void LoadObjects_World2Level7(void);
void LoadObjects_World2Boss(void);
void LoadObjects_World3Level1(void);
void LoadObjects_World3Level2(void);
void LoadObjects_World3Level3(void);
void LoadObjects_World3Level4(void);
void LoadObjects_World3Level5(void);
void LoadObjects_World3Level6(void);
void LoadObjects_World3Level7(void);
void LoadObjects_World3Boss(void);
void LoadObjects_World4Level1(void);
void LoadObjects_World4Level2(void);
void LoadObjects_World4Level3(void);
void LoadObjects_World4Level4(void);
void LoadObjects_World4Level5(void);
void LoadObjects_World4Level6(void);
void LoadObjects_World4Level7(void);
void LoadObjects_World4Boss(void);
void LoadObjects_World5Level1(void);
void LoadObjects_World5Level2(void);
void LoadObjects_World5Level3(void);
void LoadObjects_World5Level4(void);
void LoadObjects_World5Level5(void);
void LoadObjects_World5Level6(void);
void LoadObjects_World5Level7(void);
void LoadObjects_World5Boss(void);
void sub_080375A0(void);
void sub_08037DD4(void);
void sub_0803881C(void);
void sub_080392A4(void);
void LoadObjects_Common(void);
typedef void (*IntrFunc)(void);
struct IntrTable {
               IntrFunc vBlank;
               IntrFunc hBlank;
               IntrFunc vCount;
               IntrFunc timer0;
               IntrFunc timer1;
               IntrFunc timer2;
               IntrFunc timer3;
               IntrFunc serial;
               IntrFunc dma0;
               IntrFunc dma1;
               IntrFunc dma2;
               IntrFunc dma3;
               IntrFunc keypad;
               IntrFunc gamePak;
};
extern struct IntrTable gIntrTable;
struct CallbackQueue {
               void (*current[10])(void);
               void (*next[10])(void);
               void (*previous[10])(void);
               u8 currentCount;
               u8 nextCount;
               u8 previousCount;
               u8 pad7B[0x7C - 0x7B];
};
extern struct CallbackQueue gCallbackQueue;
struct Unk_03003410 {
    u32 unk0;
    u8 unk4;
    u8 unk5;
    u8 unk6;
    u8 unk7;
    u8 unk8;
    u8 unk9;
    u8 unkA;
    u8 unkB;
    u8 unkC;
};
extern struct Unk_03003410 gUnk_03003410;
extern u16 *gUnk_030034FC;
enum FileSelectStage {
    FILE_SELECT_STAGE_SELECT,
    FILE_SELECT_STAGE_CONFIRM
};
struct Unk_03004658 {
    u8 pad0[0xC - 0x0];
    u8 cursorIndex;
    u8 selectedSaveFile;
    u8 padE[0xF - 0xE];
    s8 fileSelectStage;
};
extern struct Unk_03004658 *gUnk_03004658;
struct Unk_03004670 {
               u8 unk0;
               u8 bestEx1TimeMinutes;
               u8 bestEx1TimeSeconds;
               u8 bestEx1TimeCentiseconds;
               u8 bestEx3TimeMinutes;
               u8 bestEx3TimeSeconds;
               u8 bestEx3TimeCentiseconds;
               u8 pad7[0x8 - 0x7];
               u8 levelInfo[6][8];
               s32 unk38;
               u8 addChecksum;
               u8 xorChecksum;
               u8 pad3E[0x40 - 0x3E];
};
extern struct Unk_03004670 *gUnk_03004670;
enum SceneType {
    SCENE_TYPE_LEVEL_SELECT,
    SCENE_TYPE_LEVEL,
    SCENE_TYPE_CUTSCENE,
    SCENE_TYPE_WORLD_MAP = 7
};
struct SaveData {
    u8 saveFileString[9];
    u8 pad9[0x10 - 0x9];
    u8 currentSaveFile;
    u8 currentSaveFileAddress;
    u8 lastLoadedSaveFile;
    u8 pad13[0x14 - 0x13];
    u8 lives[3];
    u8 world[3];
    u8 level[3];
    u8 sceneType[3];
    u8 unk20[3];
    u8 unk23[3];
    u8 startedFile[3];
    u8 completedFile[3];
};
extern struct SaveData *gSaveData;
struct Unk_03005284 {
               u8 unk0;
               u8 unk1;
               u8 unk2;
               u8 unk3;
               u8 unk4;
               u8 unk5;
               u8 unk6;
               u8 unk7;
                 u8 unk8_0:2;
                 u8 unk8_2:3;
                 u8 unk8_5:7;
                 u8 unk9_4:3;
                 u8 unk9_7:8;
                 u8 unkA_7:6;
                 u8 unkB_5:1;
                 u8 unkB_6:1;
               u32 unkC;
               u32 unk10;
               u16 unk14;
               u16 unk16;
               u32 unk18;
               u8 shootButtonConfig;
               u8 jumpButtonConfig;
               u8 unk1E;
               u8 pad1F[0x20 - 0x1F];
               u8 addChecksum;
               u8 xorChecksum;
               u8 pad22[0x24 - 0x22];
};
extern struct Unk_03005284 *gUnk_03005284;
extern s8 gUnk_03004784;
extern u16 gSoundVolume;
extern u8 gUnk_0300548C;
extern u8 gBlendValue;
extern u8 gMosaicSize;
extern u16 gUnk_030034F0;
extern u16 gNewKeys;
extern u16 gHeldKeys;
extern u16 gHeldKeysAttract;
extern u16 gNewKeysAttract;
extern u8 gUnk_030034E4;
struct BgDataPtrs {
               void *pBufBg0Tiles;
               u16 *pBufBg0Tilemap;
               void *pBufBg1Tiles;
               u16 *pBufBg1Tilemap;
               void *pBufBg2Tiles;
               u8 *pBufBg2Tilemap;
               void *pBufBg3Tiles;
               u16 *pBufBg3Tilemap;
};
extern struct BgDataPtrs gBgDataPtrs;
extern void *gUnk_03005290;
extern u8 gUnk_03003420;
extern u8 gUnk_03005428;
extern u16 gBgTilemapBufs[4][0x400];
extern u8 gUnk_03004DB0[];
extern u8 gUnk_03003650[][0x40];
extern u16 gUnk_03004C40[];
extern u16 gUnk_030052C0[];
extern u32 gUnk_03005488;
enum EntityId {
               ENTITY_ID_NONE,
               ENTITY_ID_CIRCLE_KEY,
               ENTITY_ID_TRIANGLE_KEY,
               ENTITY_ID_STAR,
               ENTITY_ID_HEART_KEY,
               ENTITY_ID_KEY_DOOR,
               ENTITY_ID_SPIKER_HORIZONTAL,
               ENTITY_ID_HEART,
               ENTITY_ID_SPIKER_VERTICAL,
               ENTITY_ID_LEAF_1,
               ENTITY_ID_LEAF_2,
               ENTITY_ID_MOO_BOARDER,
               ENTITY_ID_17,
               ENTITY_ID_BOSS,
               ENTITY_ID_MAGNET_BLOCK = 0x25,
               ENTITY_ID_MAGNET_BLOCK_HAND,
               ENTITY_ID_MOVING_PLATFORM_VERTICAL,
               ENTITY_ID_FOUNTAIN_FOOTHOLD,
               ENTITY_ID_MOVING_PLATFORM_HORIZONTAL,
               ENTITY_ID_GRATED_PLATFORM,
               ENTITY_ID_BLUE_DISAPPEARING_PLATFORM,
               ENTITY_ID_SMALL_DREAM_STONE,
               ENTITY_ID_LARGE_DREAM_STONE,
               ENTITY_ID_1_UP,
               ENTITY_ID_GOOMI,
               ENTITY_ID_GOOMI_HORIZONTAL,
               ENTITY_ID_GOOMI_VERTICAL,
               ENTITY_ID_GOOMI_DIAGONAL_1,
               ENTITY_ID_GOOMI_DIAGONAL_2,
               ENTITY_ID_34,
               ENTITY_ID_GROWN_BLOCK,
               ENTITY_ID_RED_ARROW,
               ENTITY_ID_PRESSURE_SWITCH,
               ENTITY_ID_WATER,
               ENTITY_ID_WATERFALL,
               ENTITY_ID_GEYSER,
               ENTITY_ID_ONE_WAY_GATE,
               ENTITY_ID_GATE,
               ENTITY_ID_SCALE_1,
               ENTITY_ID_SCALE_2,
               ENTITY_ID_SPRING,
               ENTITY_ID_HOVER_BOARD_SPRING,
               ENTITY_ID_MOON_DOOR,
               ENTITY_ID_CANNON_GOAL,
               ENTITY_ID_GLIBZ_QUAD_CANNON_BULLET,
               ENTITY_ID_51 = 0x51,
               ENTITY_ID_52 = 0x52,
               ENTITY_ID_KLONOA = 0x6E,
               ENTITY_ID_BOX,
               ENTITY_ID_EXPLODABLE_BLOCK,
               ENTITY_ID_WATER_SWITCH,
               ENTITY_ID_GATE_SWITCH,
               ENTITY_ID_ROTATION_SWITCH,
               ENTITY_ID_GROWING_SHRINKING_BLOCK_SWITCH,
               ENTITY_ID_BLUE_ARROW,
               ENTITY_ID_MOO,
               ENTITY_ID_FLYING_MOO_HORIZONTAL,
               ENTITY_ID_FLYING_MOO_VERTICAL,
               ENTITY_ID_GLIBZ_QUAD_CANNON,
               ENTITY_ID_TETON,
               ENTITY_ID_BOOMIE,
               ENTITY_ID_FLYING_BOOMIE_HORIZONTAL,
               ENTITY_ID_FLYING_BOOMIE_VERTICAL,
};
union __attribute__((packed)) EntityInfo_8 {
    struct __attribute__((packed)) {
        u8 unk8;
        u8 unk9;
    } split;
    u16 all;
};
struct EntityInfo {
               u16 xPosBg2;
               u16 yPosBg2;
               u16 xPosScreen;
               u16 yPosScreen;
               union EntityInfo_8 unk8;
               u8 unkA;
                 s32 unkB_0:4;
                 s32 unkB_4:4;
                 u32 priority:2;
                 u32 unkC_2:2;
                 u32 unkC_4:4;
                 u32 objMode:2;
                 u32 affineHFlip_matrixNum:4;
                 u32 unkD_6:2;
                 u32 affineEnable:1;
                 u32 affineDouble:1;
               u8 unkF;
               u8 visible;
               u8 id;
               u8 unk12;
               u8 pad13[0x14 - 0x13];
               u16 unk14;
               u8 unk16;
               u8 unk17;
               u8 unk18;
               u8 pad19[0x1C - 0x19];
};
extern struct EntityInfo gEntityInfo[];
struct BgInfo {
               void *pTiles;
               void *pTilemap;
               u16 hOfs;
               u16 vOfs;
               u16 tileCol;
               u16 tileRow;
               u16 hLength;
               u16 vLength;
               u16 unk14;
               u16 nbrTiles;
               u8 tileSize;
               u8 pad19[0x1C - 0x19];
};
extern struct BgInfo gBgInfo[4];
enum WIN01 {
    WIN_0,
    WIN_1,
    WIN01_COUNT
};
enum WINHV {
    WIN_H,
    WIN_V,
    WINHV_COUNT
};
struct Unk_030034A0 {
                 u32 unk0_0:2;
                 u8 unk0_2:4;
                 u32 unk0_6:2;
                 u32 unk1_0:1;
                 u8 unk1_1:5;
                 u32 unk1_6:1;
                 u32 unk1_7:2;
                 u32 unk2_1:2;
               u8 unk3[1];
               u8 pad4[0x5 - 0x4];
               u8 unk5;
               u8 unk6;
               u8 pad7[0x8 - 0x7];
               s16 winX1Y1[WIN01_COUNT][WINHV_COUNT];
               s16 winX2Y2[WIN01_COUNT][WINHV_COUNT];
               s16 unk18;
               s16 unkA;
                 u8 unk1C_0:2;
                 u8 unk1C_2:1;
                 u8 unk1C_3:1;
                 u8 unk1C_4:1;
                 u8 unk1C_5:1;
                 u8 unk1C_6:1;
};
extern struct Unk_030034A0 *gUnk_030034A0;
struct Unk_03004C20 {
               u32 sceneFrameCounter;
               u32 globalFrameCounter;
               u16 roomsRotationBits;
               u8 unkA;
               u8 isHoverBoardLevel;
               u8 level;
               u8 world;
               u8 room;
               u8 unkF;
               u8 levelHasTimer;
               u8 levelHasWarpDoors;
               u8 demoNumber;
               u8 demoInputIndex;
               u8 demoNextInputTimer;
};
extern struct Unk_03004C20 gUnk_03004C20;
extern s32 gBg2X;
extern s16 gBg2AlphaSin;
extern s16 gBg2AlphaCos;
extern s32 gBg2Y;
extern s16 gUnk_030034F8;
extern s16 gBg2PD;
extern u8 gBg2Alpha;
extern u16 gBg2XMag;
extern u8 gUnk_03004660;
extern s16 gBg2PA;
extern s16 gBg2PC;
extern u8 gUnk_030052A0;
extern u16 gBg2YMag;
extern s16 gBg2PB;
struct CurrentRoomBg2Bounds {
              u16 left;
              u16 top;
              u16 right;
              u16 bottom;
};
extern struct CurrentRoomBg2Bounds gCurrentRoomBg2Bounds;
struct Unk_0300542C {
              u16 unk0;
              u16 unk2;
              u16 unk4;
              u16 unk6;
              s8 unk8;
              s8 unk9;
              u8 padA[0xC - 0xA];
};
extern struct Unk_0300542C *gUnk_0300542C;
struct Unk_03005220 {
                 u32 hearts:2;
                 u32 stars:3;
                 u32 dreamStones:7;
                 u32 keys:3;
                 u32 unk1_7:8;
                 u32 unk2_7:6;
                 u32 unk3_5:1;
                 u32 unk3_6:1;
                 u32 unk3_7:1;
               u32 unk4;
               u32 unk8;
               u32 unkC;
               u32 unk10;
               u16 unk14;
               u16 unk16;
               u16 unk18;
               u16 unk1A;
               u16 klonoaIdleTimer;
               u16 unk1E;
               u16 unk20;
               u16 unk22;
               u16 unk24;
               s16 unk26;
               s16 unk28;
               s16 unk2A;
               s16 unk2C;
               u8 unk2E;
               s8 unk2F;
               u8 unk30;
               u8 unk31;
               u8 windBulletDirection;
               u8 windBulletDisableTimer;
               u8 unk34;
               u8 unk35;
               u8 unk36;
               u8 unk37;
               u8 unk38;
               u8 unk39;
               u8 unk3A;
               u8 unk3B;
               u8 unk3C;
               u8 unk3D;
               u8 klonoaInvincibilityTimer;
               u8 unk3F;
               u8 unk40;
               u8 unk41;
               u8 unk42;
               u8 unk43;
               u8 unk44;
               u8 unk45;
               u8 unk46;
               u8 unk47;
               u8 unk48;
               u8 unk49;
               u8 unk4A;
               u8 unk4B;
               u8 lives;
               u8 levelTimeMinutes;
               u8 levelTimeSeconds;
               u8 levelTimeCentiseconds;
               u8 unk50;
               u8 unk51;
               u8 unk52;
               u8 unk53;
               s8 unk54;
               s8 unk55;
               s8 unk56;
               s8 unk57;
               u8 unk58;
               u8 unk59;
               u8 unk5A;
               u8 unk5B;
               u8 unk5C;
               u8 allStarsCollected;
               u8 klonoaPrevIdleAnimation;
               u8 unk5F;
               u16 unk60;
               u8 pad62[0x64 - 0x62];
};
extern struct Unk_03005220 gUnk_03005220;
extern u16 gUnk_030008E8;
extern u16 gUnk_0300358C;
extern u16 gPreviousBg2VOfs;
extern s32 gAthleticChallengeAutoScrollYVelocity;
struct AthleticChallengeAutoScrollBaseVelocity {
              s32 x;
              s32 y;
};
extern struct AthleticChallengeAutoScrollBaseVelocity gAthleticChallengeAutoScrollBaseVelocity;
extern u8 gAthleticChallengeScrollFlags;
extern s32 gAthleticChallengeAutoScrollXVelocity;
struct Unk_030007E0 {
              s16 unk0;
              s16 unk2;
              u16 unk4;
              s16 unk6;
              s16 unk8;
              u16 unkA;
                u8 unkC_0:4;
                u8 unkC_4:4;
              u8 padD[0x10 - 0xD];
};
extern struct Unk_030007E0 gUnk_030007E0;
struct Unk_03005400 {
               u16 unk0;
               u16 unk2;
               u16 unk4;
               u16 unk6;
                u8 unk8_0:1;
                u8 unk8_1:1;
                u8 unk8_2:1;
                u8 unk8_3:1;
                u8 unk8_4:1;
                u8 unk8_5:1;
                u8 unk8_6:1;
                u8 unk8_7:1;
               u8 unk9;
               u8 unkA;
               u8 unkB;
               u8 unkC;
               u8 unkD;
                 u8 unkE_0:1;
                 u8 unkE_1:1;
                 u8 unkE_2:1;
                 u8 unkE_3:1;
                 u8 unkE_4:1;
                 u8 unkE_5:2;
                 u8 unkE_7:1;
               s8 unkF;
               s8 unk10;
               u8 unk11;
               u8 unk12;
               u8 unk13;
               u8 unk14;
               s8 unk15;
               s8 unk16;
               u8 pad17[0x18 - 0x17];
};
extern struct Unk_03005400 gUnk_03005400;
struct Unk_03005440 {
               u16 unk0;
               u16 unk2;
               u16 unk4;
               u16 unk6;
               u8 pad8[0xC - 0x8];
               u16 unkC;
               u16 unkE;
               u16 unk10;
               u16 unk12;
               u8 pad14[0x18 - 0x14];
               u16 unk18;
               u16 unk1A;
               u16 unk1C;
               u16 unk1E;
};
extern struct Unk_03005440 gUnk_03005440;
extern u8 gUnk_03000800;
struct Unk_03004654 {
    u8 unk0;
    u8 unk1;
    u8 pad2[0x14 - 0x2];
    u8 unk14;
    u8 unk15;
    u8 unk16;
    u8 unk17;
    u8 unk18;
    u8 unk19;
    u8 unk1A;
    u8 unk1B;
};
extern struct Unk_03004654 *gUnk_03004654;
extern u8 gUnk_030051C8;
struct Unk_030051CC {
              u16 unk0;
              u16 unk2;
};
extern struct Unk_030051CC gUnk_030051CC;
extern u8 gUnk_030007C4;
extern void * volatile gObjPalRamPtr;
struct EntityAnimationInfo {
              u8 state;
              u8 timer;
              volatile u8 frame;
              u8 pad3[0x4 - 0x3];
};
extern struct EntityAnimationInfo gEntityAnimationInfo[];
extern u8 gUnk_0300363C;
struct Unk_0300466C_4 {
    u16 tileNum;
    u8 bpp_paletteNum;
    s8 unk3;
    u8 unk4;
    u8 shape_size;
};
struct Unk_0300466C {
    u8 unk0;
    u8 pad1[0x4 - 0x1];
    struct Unk_0300466C_4 *unk4;
};
extern struct Unk_0300466C *gUnk_0300466C;
extern struct Unk_0300466C *gUnk_030051DC;
struct EntityAnimationFrameData {
    u32 src;
    u8 timer;
    s32 unk5_0:4;
    s32 unk5_4:4;
};
struct EntityAnimationData {
    struct EntityAnimationFrameData **pFrames;
    void *dest;
    u16 size;
    u8 entityInfoEntry;
    u8 padB[0xC - 0xB];
};
extern struct EntityAnimationData *gUnk_03005294;
extern struct EntityAnimationData *gUnk_03005418;
extern void * volatile gObjVramPtr;
struct Unk_03000790 {
              u16 unk0;
              u16 unk2;
              u16 unk4;
              u16 unk6;
              u16 unk8;
              u8 padA[0x10 - 0xA];
};
extern struct Unk_03000790 gUnk_03000790[];
struct Unk_03003610 {
              u8 unk0;
              u8 unk1;
              u8 unk2;
              u8 unk3;
};
extern struct Unk_03003610 gUnk_03003610[];
struct Unk_03004680 {
              u16 pa;
              u16 pb;
              u16 pc;
              u16 pd;
};
extern struct Unk_03004680 gOamAffineBuffer[];
extern u32 gUnk_030007D4;
extern s32 gUnk_030007F0;
extern s32 gUnk_030007F4;
extern s32 gUnk_03000804;
extern u8 gUnk_03000818;
extern s32 gUnk_03000824;
extern s32 gUnk_0300082C;
extern u8 gUnk_030008EC;
extern s32 gUnk_030008F0;
extern s32 gUnk_030008F4;
extern s32 gUnk_030008FC;
extern s32 gUnk_03002904;
extern s32 gUnk_03002908;
extern s32 gUnk_0300290C;
extern s32 gUnk_030034A4;
extern s32 gUnk_030034C8;
extern s32 gUnk_030034CC;
extern s32 gUnk_030034D8;
extern s32 gUnk_03003500;
extern s32 gUnk_03003504;
extern s32 gUnk_03003630;
extern s32 gUnk_03003634;
extern s32 gUnk_03003638;
extern s32 gUnk_03003640;
extern s32 gUnk_03004650;
extern u32 gUnk_03004664;
extern s32 gUnk_03004674;
extern s32 gUnk_03004788;
extern s32 gUnk_030047B4;
extern u8 gUnk_030047B8;
extern s32 gUnk_030047BC;
extern s32 gUnk_030047F8;
extern u8 gUnk_03004C00;
extern s32 gUnk_03004C04;
extern u8 gUnk_03004C38;
extern u8 gUnk_030051B4;
extern s32 gUnk_030051C4;
extern s32 gUnk_030051D4;
extern s32 gUnk_030051D8;
extern u8 gOamAffineMatrixNum;
extern u8 gUnk_0300528C;
extern u8 gUnk_03005298;
extern s32 gUnk_0300529C;
extern u8 gUnk_030052A8;
extern s32 gUnk_030052B0;
extern s32 gUnk_030052B4;
extern s32 gUnk_0300541C;
extern s32 gUnk_03005424;
extern s32 gUnk_03005430;
extern u8 gUnk_03005470;
extern u8 gUnk_0300547C;
extern s32 gUnk_03005484;
union Unk_03000820 {
    struct {
                    u32 y:8;
                    u32 affineMode:2;
                    u32 objMode:2;
                    u32 mosaic:1;
                    u32 bpp:1;
                    u8 shape:2;
                    u16 x:9;
                    u8 matrixNum:3;
                    u32 hFlip:1;
                    u32 vFlip:1;
                    u32 size:2;
                    u16 tileNum:10;
                    u8 priority:2;
                    u16 paletteNum:4;
                    u8 pad6[0x8 - 0x6];
    } split;
    struct {
                  u32 attr01;
                  u16 attr2;
                  u16 affineParam;
    } all;
};
extern union Unk_03000820 *gOamBufferPtr;
extern union Unk_03000820 gOamBuffer[];
extern u8 gUnk_030034BC;
struct Unk_03003590 {
              u16 unk0;
              u16 unk2;
              u8 unk4;
                u8 unk5_0:1;
              u8 pad6[0x8 - 0x6];
};
extern struct Unk_03003590 gUnk_03003590[];
extern void (*gUnk_030034A8)(u8);
extern u8 gUnk_030034E0;
extern void *gUnk_03004C10;
extern u16 gUnk_030034DC;
struct DisplayBackup {
    s32 sceneFrameCounter;
    u16 bldCnt;
    u16 bg0Cnt;
    u16 bg1Cnt;
    u16 bg2Cnt;
    u16 bg3Cnt;
    u8 blendValue;
};
extern struct DisplayBackup gDisplayBackup;
extern u8 gUnk_03000810;
extern u8 gUnk_030034C4;
extern u16 gUnk_03003508;
struct Unk_080D821C_4 {
    u16 unk0;
    u16 unk2;
    u16 unk4;
    u16 unk6;
    u8 unk8;
};
struct Unk_080D821C {
    u16 unk0;
    u16 unk2;
    struct Unk_080D821C_4 *unk4;
    u8 unk8;
    u8 unk9;
    u8 padA[0xC - 0xA];
};
extern struct Unk_080D821C *gUnk_03004D80;
extern u16 gUnk_030051E0;
enum TextBoxInfoStage {
    TEXT_BOX_INFO_STAGE_DISPLAYING,
    TEXT_BOX_INFO_STAGE_REQUESTED,
    TEXT_BOX_INFO_STAGE_CLOSING
};
struct TextBoxInfo {
    u8 pad0[0x4 - 0x0];
    u16 win1H;
    u16 win1V;
    u8 stage;
    u8 visionSelectTextBoxIdOffset;
};
extern struct TextBoxInfo gTextBoxInfo;
extern u8 gUnk_03005200;
extern void *gUnk_030034F4;
extern void *gUnk_030052AC;
extern u16 gUnk_030052B8;
enum TitleScreenStage {
    TITLE_SCREEN_STAGE_INTRO_LOGO_ANIMATION,
    TITLE_SCREEN_STAGE_PRESS_START,
    TITLE_SCREEN_STAGE_NEW_GAME_OR_CONTINUE = 5,
    TITLE_SCREEN_STAGE_GO_TO_DEMO,
    TITLE_SCREEN_STAGE_GO_TO_FILE_SELECT
};
extern u8 gTitleScreenStage;
struct Unk_030034B0 {
    u8 unk0_0:1;
    u8 unk0_1:3;
    u8 unk0_4:1;
    u8 unk1;
    u8 unk2;
    u8 unk3;
    u8 unk4;
    u8 unk5;
    u8 unk6_0:4;
    u8 unk6_4:4;
    u8 unk7_0:4;
    u8 unk7_4:4;
    u8 unk8_0:4;
    u8 unk8_4:4;
};
extern struct Unk_030034B0 gUnk_030034B0;
enum PauseMenuType {
    PAUSE_MENU_TYPE_NORMAL_LEVEL,
    PAUSE_MENU_TYPE_LEVEL_SELECT,
    PAUSE_MENU_TYPE_EX_LEVEL,
    PAUSE_MENU_TYPE_BOSS
};
extern u8 gPauseMenuType;
struct WorldMapInfo {
    u8 beatenIndex:4;
    u8 currentIndex:4;
    s8 nextIndexOffset;
    u8 unlockTimer;
    u8 pad3[0x4 - 0x3];
};
extern struct WorldMapInfo gWorldMapInfo;
extern u8 gUnk_030007CC;
struct Unk_0803D4AC {
    u8 unk0;
    u8 unk1;
    u8 unk2;
    s8 unk3;
    s8 unk4;
    u8 unk5;
    u8 unk6;
};
extern struct Unk_0803D4AC gUnk_03003620;
extern u8 gUnk_03003D16[][8];
extern u8 gUnk_03003DD6[][8];
extern u8 gUnk_03003E96[][8];
extern u8 gUnk_03003F56[][8];
extern u8 gUnk_03003790[][0x40];
enum GameOverScreenStage {
    GAME_OVER_SCREEN_STAGE_TRANSITION_ANIMATION,
    GAME_OVER_SCREEN_STAGE_SELECT_OPTION,
    GAME_OVER_SCREEN_STAGE_CONTINUE_PLAYING,
    GAME_OVER_SCREEN_STAGE_GOOD_NIGHT,
    GAME_OVER_SCREEN_STAGE_EXIT_TO_TITLE_SCREEN
};
extern u8 gGameOverScreenStage;
struct Unk_030034D4 {
    u16 unk0;
    u16 unk2;
};
extern struct Unk_030034D4 *gUnk_030034D4;
extern u16 gDma3CntHBackup;
extern u16 gDma2CntHBackup;
extern u16 gDma1CntHBackup;
extern u16 gDma0CntHBackup;
enum DeleteAllSaveDataScreenStage {
    DELETE_ALL_SAVE_DATA_SCREEN_STAGE_FIRST_YES_NO,
    DELETE_ALL_SAVE_DATA_SCREEN_STAGE_SECOND_YES_NO,
    DELETE_ALL_SAVE_DATA_SCREEN_STAGE_DELETE_DATA,
    DELETE_ALL_SAVE_DATA_SCREEN_STAGE_DATA_DELETED,
    DELETE_ALL_SAVE_DATA_SCREEN_STAGE_DATA_NOT_DELETED,
    DELETE_ALL_SAVE_DATA_SCREEN_STAGE_EXIT
};
extern u8 gDeleteAllSaveDataScreenStage;
enum DeleteAllSaveDataScreenCursor {
    DELETE_ALL_SAVE_DATA_SCREEN_CURSOR_YES,
    DELETE_ALL_SAVE_DATA_SCREEN_CURSOR_NO
};
extern u8 gDeleteAllSaveDataScreenCursor;
extern u8 gDeleteAllSaveDataMinigameUnlocked;
extern u8 gSaveFilesStarted;
extern u8 gFileSelectScreenTransitionDelay;
extern void *gUnk_030007D0;
extern u8 *gUnk_03004D84;
struct Unk_030052A4 {
    u32 unk0_0:3;
    u32 unk0_3:8;
    u32 unk1_3:4;
    u32 unk1_7:7;
    u8 unk2_6:5;
    u32 unk3_3:4;
    u32 unk3_7:1;
    s16 unk4;
    s16 unk6;
    s16 unk8;
    s16 unkA;
    s16 unkC;
    s16 unkE;
    u8 unk10[0x14 - 0x10];
    s16 unk14;
    s16 unk16;
    s16 unk18;
    s16 unk1A;
    s16 unk1C;
    u8 unk1E;
    u8 unk1F;
    s32 (*unk20)(s32);
};
extern struct Unk_030052A4 *gUnk_030052A4;
extern u32 gUnk_03000814;
struct Unk_030007C8 {
    void *unk0;
    u16 unk4;
    u16 unk6;
};
extern struct Unk_030007C8 *gUnk_030007C8;
struct Unk_0300081C {
    void *unk0;
    s8 unk4;
    u8 unk5;
    u8 pad6[0x8 - 0x6];
    s8 unk8;
    s8 unk9;
    s8 unkA;
    s8 unkB;
    u8 padC[0xD - 0xC];
    u8 unkD;
    u8 unkE;
    u8 padF[0x10 - 0xF];
    u16 unk10;
    u16 unk12;
    s16 unk14;
    u8 unk16_0:4;
    u16 unk16_4:3;
    u8 unk16_7:1;
    u8 unk17_0:1;
    u8 unk17_1:1;
    u16 unk18;
    u16 unk1A;
    void *unk1C;
    void *unk20;
    void (*unk24)(void);
};
extern struct Unk_0300081C *gUnk_0300081C;
void PauseMenuScreenInit(void);
void PauseMenuScreenRestoreGfx(void);
void PauseMenuScreenHandler(void);
void ButtonConfigurationScreenInit(void);
void ButtonConfigurationScreenHandler(void);
u8 WorldMapScreenIsValidPath(u8 mapIndex);
void WorldMapScreenDrawWorld(u8 mapIndex);
void WorldMapScreenSetPalette(u8 mapIndex, u8 palNbr);
void WorldMapScreenDrawPath(u8 mapIndex);
void WorldMapScreenDrawUnlockedWorlds(void);
void WorldMapScreenCheckNewWorldUnlocked(void);
void WorldMapScreenUnlockNewWorld(void);
void WorldMapScreenInit(void);
void WorldMapScreenHandler(void);
void sub_0803C808(void);
void sub_0803CE14(u8 arg0);
void sub_0803CF08(u8 arg0);
void sub_0803D140(u8 arg0);
void sub_0803D15C(void);
void sub_0803D4AC(u8 arg0, struct Unk_0803D4AC arg1);
void sub_0803D90C(u8 arg0);
void sub_0803E6D8(u8 arg0);
void sub_0803E8CC(void);
void sub_0803E904(u8 arg0);
void sub_0803F68C(u8 arg0, u8 arg1, u8 arg2);
void sub_0803F950(u8 arg0);
void sub_0803F9EC(u8 arg0);
void sub_08040B50(u8 arg0);
void sub_08040D68(void);
void sub_08040F1C(u8 arg0);
void sub_08041E94(u8 arg0, u8 arg1);
void sub_08041F34(u8 arg0);
void sub_08042024(u8 arg0);
void sub_08042BEC(void);
void sub_08042E64(u8 arg0);
void GameOverScreenInit(void);
void GameOverScreenStageSetup(s32 gameOverScreenStage);
void GameOverScreenHandler(void);
void sub_08044BB8(void);
void sub_08044F6C(u8 arg0);
void sub_0804517C(u8 arg0);
void sub_080452E8(void);
void sub_08045398(void);
void sub_080453F0(void);
void sub_08045734(void);
void sub_0804575C(void);
void sub_08045874(void);
void sub_08045F68(void);
void sub_08046288(void);
void sub_080467F4(void);
void sub_080468B0(void);
u8 sub_080469FC(void);
void sub_08046A64(u8 arg0);
u8 HeldUp(void);
void DeleteAllSaveDataScreenInit(void);
void DeleteAllSaveDataMinigameHandler(void);
void DeleteAllSaveDataScreenHandler(void);
void sub_08047ABC(void);
void TextBoxInit(void);
void TextBoxHandler(void);
void TextBoxRestoreGameplay(void);
void sub_08048028(void);
void BootScreenInit(void);
void NamcoScreenInit(void);
void BootScreenHandler(void);
void NamcoScreenHandler(void);
void TitleScreenInit(void);
void TitleScreenLogoAnimationUpdate(void);
void TitleScreenStageSetup(u8 titleScreenStage);
void TitleScreenHandler(void);
void FileSelectScreenInit(void);
void FileSelectScreenUpdateCursor(u8 fileSelectStage);
void FileSelectScreenDrawInfo(u8 arg0);
void FileSelectScreenHandler(void);
void LoadAllSaveData(void);
u16 WriteSaveFile(u32 arg0, u8 arg1);
u16 LoadSaveFile(s32 arg0);
u16 DeleteAllSaveData(void);
void WriteCurrentSaveFile(void);
void Decompress(void *dest, void *src);
void DecompressDma(void *src, void *dest, u16 size);
void *DecompressAlloc(void *src);
void HeapInit(void);
void *HeapAlloc(s32 count, s32 size_shift);
void HeapFree(void* heapPtr);
void thunk_HeapInit(void);
void *thunk_HeapAlloc(s32 count, s32 size_shift);
void thunk_HeapFree(void* heapPtr);
void VBlankIntr_Common(void);
void VBlankIntr_CutsceneTransition(void);
void sub_08000AC8(void);
void VBlankIntr_TitleScreenAndWorldMap(void);
void VBlankIntr_Boss(void);
void VBlankIntr_ClearedAllVisionsScreen(void);
void sub_08000E14(void);
void VBlankIntr_Cutscene(void);
void HBlankIntr_DeleteAllSaveDataScreen(void);
void HBlankIntr_WavyBackground(void);
void HBlankIntr_VisionSelect(void);
void HBlankIntr_GameOverCircleShrinkEffect(void);
void sub_0800107C(void);
void VCountIntr_DeathScreen(void);
void GenericIntr(void);
void AgbMain(void);
void InputHandler_Normal(void);
void InputHandler_AttractMode(void);
void sub_0800087C(u8 arg0, u8 arg1);
void sub_080008DC(void);
s16 MultiplyQ8(s16 num1, s16 num2);
s16 DivideQ8(s16 num1, s16 num2);
s16 ReciprocalQ8(s16 num1);
s16 MultiplyQ4(s16 num1, s16 num2);
s16 DivideQ4(s16 num1, s16 num2);
s16 ReciprocalQ4(s16 num1);
void UpdateRng();
u8 GetRandomValue();
u8 GetRandomValueEx();
void thunk_UpdateRng();
u8 thunk_GetRandomValue();
u8 thunk_GetRandomValueEx();
s32 Abs(s32 n);
s32 StringCompare(u8 *s1, u8 *s2);
void StringCopy(u8 *dest, u8 *src);
extern const s16 gSineTable[];
enum Songs {
               MUS_TITLE,
               MUS_GOOD_NIGHT,
               MUS_FILE_SELECT,
               MUS_WORLD_MAP,
               MUS_VISION_OF_GHAZZALAND,
               MUS_VISION_OF_PRIAMILL,
               MUS_VISION_OF_JIOBOB,
               MUS_VISION_OF_SANTAL,
               MUS_VISION_OF_LELJIMBA,
               MUS_EX_VISION,
               MUS_BOSS,
               MUS_FINAL_BOSS,
               MUS_STAFF_ROLL,
               MUS_OPENING_DREAMING,
               MUS_OPENING_UNDER_ARREST,
               MUS_OPENING_THE_CRIME,
               MUS_INTRO_FIGHTING_CITY_GHAZZALAND,
               MUS_INTRO_OPERA_TOWN_PRIAMILL,
               MUS_ENDING_OPERA_TOWN_PRIAMILL,
               MUS_FOOD_LAND_JIOBOB,
               MUS_FOREST_VILLAGE_SANTAL,
               MUS_INTRO_IMPERIAL_CITY_LELJIMBA,
               MUS_KING_OF_DESPAIR_BAGOO_EVIL_SCHEME,
               MUS_THERES_THE_MONSTER,
               MUS_ENDING_A_BAD_DREAM,
               MUS_ENDING_WAKING_UP,
               MUS_ENDING_A_KING_MISTAKE,
               MUS_ENDING_DREAM_FOR_ALL,
               MUS_VISION_SELECT,
               MUS_OPENING_STICKY_SITUATION,
               MUS_SURFBOARDING,
               MUS_VISION_CLEAR,
               MUS_OPENING_ADVENTURE_START,
               MUS_NAMCO,
               MUS_AUTO_SCROLL_VISION,
               MUS_DUMMY,
               SE_DUMMY,
               SE_KLONOA_HURT,
               SE_KLONOA_WAHOO,
               SE_KLONOA_DEATH,
               SE_KLONOA_WIND_BULLET,
               SE_41,
               SE_KLONOA_THROWS_OBJECT,
               SE_ENEMY_DEATH,
               SE_GOOMI_GRAB,
               SE_KLONOA_JUMPING,
               SE_KLONOA_LANDING,
               SE_KLONOA_HOVERING,
               SE_VISION_OVER,
               SE_SMALL_DREAM_STONE_COLLECTED,
               SE_KEY_COLLECT,
               SE_STAR_COLLECT_TEXT_BOX_OPEN,
               SE_KEY_DOOR_OPEN,
               SE_MOON_DOOR_OPEN,
               SE_OPENING_KNOCKING_ON_DOOR,
               SE_OPENING_DOOR_OPENED,
               SE_OPENING_DOOR_CLOSED,
               SE_OPENING_CASTLE_DOOR_CLOSING,
               SE_OPENING_CASTLE_DOOR_CLOSED,
               SE_CURSOR_MOVE = 81,
               SE_CURSOR_CONFIRM,
               SE_83,
               SE_EXIT_MENU,
               SE_PAUSE_MENU,
               SE_BOOMIE_COUNTDOWN,
               SE_BOOMIE_EXPLOSION,
               SE_GLIBZ_QUAD_CANNON_SHOT,
               SE_SPRING,
               SE_GATE_OPEN_CLOSE,
               SE_GROWING_SHRINKING_BLOCK_SWITCH_HIT,
               SE_WATER_SWITCH_HIT,
               SE_WATERFALL_HITTING_OBJECT = 93,
               SE_BLUE_ARROW_HIT,
               SE_MAGNET_BLOCK_HAND_GRAB,
               SE_WARP_DOOR,
               SE_ROTATE_ROOM,
               SE_HEART_COLLECTED,
               SE_LIFE_LOST = 120,
               SE_LARGE_DREAM_STONE_COLLECTED = 123,
               SE_ONE_WAY_GATE_OPEN = 125,
               SE_1UP_COLLECTED = 135,
               SE_WORLD_UNLOCKED_DOT = 137,
               SE_WORLD_UNLOCKED,
               SE_LEVEL_UNLOCKED,
               SE_KLONOA_SNORING,
               SE_SILENCE_0,
               SE_SILENCE_1,
               SE_SILENCE_2,
               SE_SILENCE_3,
               SE_ALL_DREAM_STONES_COLLECTED,
               SE_ALL_STARS_COLLECTED,
               SE_GLIBZ_QUAD_CANNON_BULLET_HIT,
               SE_FALLING_DOWN_ROPE,
               SE_WIND_GUST_1,
               SE_WIND_GUST_2,
               SE_WIND_GUST_3,
               SE_KLONOA_ENTERS_CANNON_GOAL,
               SE_CANNON_GOAL_ROTATING,
               SE_CANNON_GOAL_REVVING_UP,
               SE_CANNON_GOAL_SHOOTING,
               SE_OBJECT_LANDS = 157,
               SE_TETON_RISING,
               SE_HOVERBOARD_JUMPING = 159,
               SE_HOVERBOARD_LANDING,
               SE_ARROW_BOUNCE,
               SE_MULTI_SWITCH_HIT,
               SE_MULTI_SWITCH_RESET,
};
typedef struct EepromConfig {
    u32 size;
    u16 nbrAddresses;
    u16 waitcnt;
    u8 addressWidth;
} EepromConfig;
u16 IdentifyEeprom(u16 sizeInKbit);
void EepromTimerIntr(void);
u16 SetEepromTimerIntr(u8 timerNo, u32 *timerPtr);
void StartEepromTimer(const u16* timerConfig);
void StopEepromTimer(void);
void Dma3Transmit(void *src, void *dest, u16 size);
u16 ReadEepromDword(u16 address, u16 *dest);
u16 ProgramEepromDword(u16 address, u16 *src);
u16 VerifyEepromDword(u16 address, u16 *src);
u16 ProgramEepromDwordEx(u16 address, u16 *src);
void *DecompressAlloc(void *src)
{
    void *heapPtr;
    heapPtr = thunk_HeapAlloc(((u32*)src)[0] & 0x7FFFFFFF, 0);
    Decompress(heapPtr, src);
    return heapPtr;
}
