
typedef unsigned int uint;
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef long double f128;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef volatile f128 vf128;
typedef int BOOL;
inline void padStack(void)
{
int pad = 0;
}
class AgeServer;
class ANode {
public:
virtual int getAgeNodeType() { return 0; }
};
extern "C"{
typedef unsigned long size_t;
}
extern "C"{
__declspec(section ".init") void* memcpy(void*, const void*, size_t);
__declspec(section ".init") void __fill_mem(void*, int, size_t);
__declspec(section ".init") void* memset(void*, int, size_t);
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, u8 type);
}
extern "C"{
int memcmp(const void*, const void*, size_t);
void* memchr(u8*, int, size_t);
void* memmove(void*, const void*, size_t);
void* memcpy(void* dest, const void* src, size_t n);
void* memset(void* dest, int val, size_t count);
}
extern "C"{
int stricmp(const char*, const char*);
}
extern "C"{
char* strcpy(char* dst, const char* src);
char* strncpy(char* dst, const char* src, size_t n);
char* strcat(char* dst, const char* src);
char* strncat(char* dst, const char* src, size_t n);
int strcmp(const char* lhs, const char* rhs);
int strncmp(const char* lhs, const char* rhs, size_t n);
char* strchr(const char* str, int ch);
char* strstr(const char* str, const char* substr);
char* strrchr(const char* str, int chr);
size_t strlen(const char* str);
}
class String;
class Stream {
public:
Stream() { }
char* mPath;
virtual int readInt();
virtual u8 readByte();
virtual short readShort();
virtual f32 readFloat();
virtual void readString(char*, int);
virtual void readString(String&);
virtual char* readString();
virtual void writeInt(int);
virtual void writeByte(u8);
virtual void writeShort(short);
virtual void writeFloat(f32);
virtual void writeString( char*);
virtual void writeString( String&);
virtual void read(void*, int);
virtual void write( void*, int);
virtual int getPending();
virtual int getAvailable();
virtual void close();
virtual bool getClosing() { return false; }
virtual void flush() { }
void print( char*, ...);
void vPrintf( char*, va_list);
};
class RandomAccessStream : public Stream {
public:
virtual int getPosition() { return 0; }
virtual int getPending() { return getLength() - getPosition(); }
virtual void setPosition(int) { }
virtual int getLength() { return getAvailable(); }
void skipPadding(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
readByte();
}
}
void padFile(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
void padFileTo(u32 paddingAmount, u32 offset)
{
int position = getPosition();
int count = paddingAmount - position - offset;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
inline BOOL checkInput()
{
if (readByte() == 0) {
return false;
}
return true;
}
void writeTo(int, void*, int);
void readFrom(int, void*, int);
void writeIntTo(int, int);
int readIntFrom(int);
};
class AlignedStream : public RandomAccessStream {
public:
virtual void read(void*, int);
virtual void write( void*, int);
virtual void alignedWrite( void*, int) = 0;
virtual void alignedRead(void*, int) = 0;
int mAlignment;
};
class BufferedInputStream : public RandomAccessStream {
public:
BufferedInputStream()
{
mBuffer = 0 ;
mStream = 0 ;
}
BufferedInputStream(Stream*, u8*, int);
virtual void read(void*, int);
virtual int getPending() { return mStream->getPending() - mPosition; }
virtual void close() { mStream->close(); }
virtual int getPosition() { return mPosition; }
void init(Stream*, u8*, int);
void fillBuffer();
u8* mBuffer;
int mBufferSize;
int mRemainingBytes;
int mCurrentBufferPos;
int mPosition;
Stream* mStream;
};
class RamStream : public RandomAccessStream {
public:
inline RamStream(void* buffer, int size)
{
mBufferAddr = buffer;
mPosition = 0;
mLength = size;
}
virtual int getPending() { return mLength - mPosition; }
virtual void setPosition(int pos) { mPosition = pos; }
virtual int getPosition() { return mPosition; }
virtual int getLength() { return mLength; }
virtual void setLength(int len) { mLength = len; }
virtual void read(void* dest, int size)
{
memcpy(dest, (char*)mBufferAddr + mPosition, size);
mPosition += size;
}
virtual void write( void* src, int size)
{
memcpy((char*)mBufferAddr + mPosition, src, size);
mPosition += size;
}
void* mBufferAddr;
int mPosition;
int mLength;
};
extern Stream* sysCon;
extern Stream* errCon;
typedef u32 HWND;
class BaseApp;
class AtxStream : public Stream {
public:
AtxStream() { init(); }
virtual void read(void* buffer, int size);
virtual void write( void* buffer, int size);
virtual int getPending();
virtual void close();
virtual void flush();
bool open( char* name, int unused);
void init() { _0C = 0; }
Stream* mStream;
int _0C;
};
class AtxCommandStream : public AtxStream {
public:
AtxCommandStream(BaseApp* app)
: mParentApp(app)
{
}
BOOL checkCommands();
BaseApp* mParentApp;
};
class AtxFileStream : public RandomAccessStream {
public:
virtual void read(void*, int);
virtual void write( void*, int);
virtual int getPending();
virtual void close();
virtual int getPosition();
virtual void setPosition(int);
virtual int getLength();
virtual void setLength(int);
bool open( char*, u32);
int mPosition;
int mLength;
AtxStream mAtxStream;
};
extern "C"{
}
extern "C"{
typedef u32 __file_handle;
typedef u32 fpos_t;
typedef struct _IO_FILE _IO_FILE, *P_IO_FILE;
enum __file_kinds { __closed_file, __disk_file, __console_file, __unavailable_file };
enum __file_orientation { __unoriented, __char_oriented, __wide_oriented };
typedef struct __file_modes {
u32 open_mode : 2;
u32 io_mode : 3;
u32 buffer_mode : 2;
u32 file_kind : 3;
u32 binary_io : 1;
u32 unk12 : 1;
u32 unk13 : 1;
} file_modes;
enum __io_states { __neutral, __writing, __reading, __rereading };
typedef struct __file_states {
u32 io_state : 3;
u32 free_buffer : 1;
u8 eof;
u8 error;
} file_states;
typedef void* __ref_con;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc ref_con);
typedef int (*__io_proc)(__file_handle file, char* buff, size_t* count, __idle_proc ref_con);
typedef int (*__close_proc)(__file_handle file);
struct _IO_FILE {
__file_handle mHandle;
file_modes mMode;
file_states mState;
u8 mIsDynamicallyAllocated;
u8 mCharBuffer;
u8 mCharBufferOverflow;
u8 mUngetcBuffer[2 ];
u32 mPosition;
char* mBuffer;
u32 mBufferSize;
char* mBufferPtr;
u32 mBufferLength;
u32 mBufferAlignment;
u32 mBufferLength2;
u32 mBufferPosition;
__pos_proc positionFunc;
__io_proc readFunc;
__io_proc writeFunc;
__close_proc closeFunc;
__ref_con ref_con;
};
typedef struct _IO_FILE FILE;
typedef struct {
char* CharStr;
size_t MaxCharCount;
size_t CharsWritten;
} __OutStrCtrl;
typedef struct {
const char* NextChar;
int NullCharDetected;
} __InStrCtrl;
typedef struct {
wchar_t* wCharStr;
size_t MaxCharCount;
size_t CharsWritten;
} __wOutStrCtrl;
typedef struct {
const wchar_t* wNextChar;
int wNullCharDetected;
} __wInStrCtrl;
int puts(const char* s);
int printf(const char*, ...);
int vprintf(const char* format, va_list arg);
int vsnprintf(char* s, size_t n, const char* format, va_list arg);
int vsprintf(char* s, const char* format, va_list arg);
int snprintf(char* s, size_t n, const char* format, ...);
int sprintf(char* s, const char* format, ...);
int sscanf(const char* s, const char* format, ...);
extern FILE __files[3];
}
class Stream;
class String {
public:
String() { init(64); }
String(int length) { init(length); }
String(char* str, int length) { init(str, length); }
void init(char* str)
{
mString = str;
}
void init(int length)
{
mString = length ? new char[length + 1] : 0 ;
mLength = length;
}
void init(char* str, int length)
{
mString = str;
mLength = length;
}
static bool equals( char* lhs, char* rhs) { return isSame(lhs, rhs); }
static bool isSame( char*, char*);
bool isSame( char*) ;
bool isSame( String* other) { return isSame(other->mString); }
static bool contains( char*, char*);
static bool contains( char* str, char c)
{
char substr[] = { c, '\0' };
return contains(str, substr);
}
bool contains( char* substr) { return contains(mString, substr); }
static char* dup( char*);
char* dup() { return dup(mString); }
static bool isWhiteSpace(char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c < ' '; }
float toFloat() ;
static int toInt( char*);
int toInt() ;
static int getLength( char*);
int getLength() ;
static u32 calcHash( char*);
u32 calcHash() ;
static char* copy(char*, char*);
static bool copyUntil(char*, char*, char, char**);
static void concat(char*, char*);
int mLength;
char* mString;
};
struct StringArray {
void read(Stream&);
void write(Stream&);
int mSize;
String* mElems;
};
class IDelegate {
public:
virtual void invoke() = 0;
};
template <typename A>
class IDelegate1 {
public:
virtual void invoke(A) = 0;
};
template <typename A, typename B>
class IDelegate2 {
public:
virtual void invoke(A, B) = 0;
};
template <typename T>
struct Delegate : public IDelegate {
typedef void (T::*CallbackFunc)();
inline Delegate(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke() { (mTarget->*mCallback)(); }
T* mTarget;
CallbackFunc mCallback;
};
template <typename T, typename A>
struct Delegate1 : public IDelegate1<A> {
typedef void (T::*CallbackFunc)(A);
inline Delegate1(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke(A arg) { (mTarget->*mCallback)(arg); }
T* mTarget;
CallbackFunc mCallback;
};
template <typename T, typename A, typename B>
struct Delegate2 : public IDelegate2<A, B> {
typedef void (T::*CallbackFunc)(A, B);
inline Delegate2(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke(A argA, B argB) { (mTarget->*mCallback)(argA, argB); }
T* mTarget;
CallbackFunc mCallback;
};
class AyuImage;
class Colour;
enum PROP_TYPE {
CHAR_PROP = 0,
SHORT_PROP,
INT_PROP,
FLOAT_PROP,
COLOUR_PROP,
IMAGE_PROP,
STRING_PROP,
UNK7,
CHAR_PTR_PROP,
UNK9
};
class AgeServer : public AtxStream {
public:
AgeServer() { }
virtual void close();
bool Open();
void readPropValue(PROP_TYPE type, void* val);
void writeProp(PROP_TYPE type, void* data);
void writePropValue(PROP_TYPE type, void* data);
int update();
void setSectionRefresh(IDelegate1<AgeServer&>* cmd);
void setOnChange(IDelegate1<AgeServer&>* cmd);
void setOnChange(IDelegate* cmd);
void NewNodeWindow(char* name);
void NewPropWindow(char* name, u32 a);
void RefreshSection();
void RefreshNode();
bool getOpenFilename(String& path, char* option);
bool getSaveFilename(String& path, char* option);
void NewNode(char* name, ANode* node);
void EndNode();
void Done();
void StartSection(char* name, bool unk);
void EndSection();
void StartGroup(char* name);
void EndGroup();
void NewEditor(char* name, int* val, int min, int max, int step);
void NewEditor(char* name, short* val, int min, int max, int step);
void NewEditor(char* name, char* val, int min, int max, int step);
void NewEditor(char* name, float* val, float min, float max, int step);
void NewEditor(char* name, Colour* col);
void NewEditor(char* name, char* val, int len);
void NewEditor(char* name, AyuImage* img, bool a);
void NewViewer(char* name, int* val);
void NewViewer(char* name, float* val);
void StartBitGroup(char* name, u32* val, int a);
void StartBitGroup(char* name, u8* val, int a);
void NewBit(char* name, u32 a1, u32 a2);
void EndBitGroup();
void StartOptionBox(char* name, int* val, int a);
void StartOptionBox(char* name, u8* val, int a);
void StartOptionBox(char* name, u16* val, int a);
void NewOption(char* name, int a);
void NewLabel(char* lbl);
void EndOptionBox();
void NewButton(char* name, IDelegate1<AgeServer&>* cmd, int a);
void NewButton(char* name, IDelegate* cmd, int a);
private:
bool mIsActive;
};
class Colour {
public:
Colour() { }
Colour(u8 _r, u8 _g, u8 _b, u8 _a) { set(_r, _g, _b, _a); }
void set(u8 _r, u8 _g, u8 _b, u8 _a)
{
r = _r;
g = _g;
b = _b;
a = _a;
}
void set(f32 _r, f32 _g, f32 _b)
{
r = _r;
g = _g;
b = _b;
a = 255;
}
void write(Stream&);
void lerpTo( Colour& target, f32 ratio, Colour& outColour)
{
outColour.r = (f32(target.r) - f32(r)) * ratio + f32(r);
outColour.g = (f32(target.g) - f32(g)) * ratio + f32(g);
outColour.b = (f32(target.b) - f32(b)) * ratio + f32(b);
outColour.a = (f32(target.a) - f32(a)) * ratio + f32(a);
}
void read(Stream& input)
{
r = input.readByte();
g = input.readByte();
b = input.readByte();
a = input.readByte();
}
bool operator==(u32 other)
{
u32 color = a | ((b << 8) | ((g << 16) | (r << 24)));
if (color == other) {
return true;
}
return false;
}
bool operator!=(u32 other) { return !(*this == other); }
u8 r, g, b, a;
};
class ShortColour {
public:
void read(RandomAccessStream& input)
{
r = input.readShort();
g = input.readShort();
b = input.readShort();
a = input.readShort();
}
s16 r, g, b, a;
};
class LShortColour {
public:
s16 r, g, b, a;
};
extern "C"{
typedef struct OSContext {
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
f64 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
void OSLoadContext(OSContext* context);
void OSClearContext(OSContext* context);
void OSInitContext(OSContext* context, u32 pc, u32 stackPtr);
void OSDumpContext(OSContext* context);
u32 OSSaveContext(OSContext* context);
u32 OSGetStackPointer();
OSContext* OSGetCurrentContext();
void OSSetCurrentContext(OSContext* context);
void OSSaveFPUContext(OSContext* context);
void OSFillFPUContext(OSContext* context);
u32 OSSwitchStack(u32 newStackPtr);
int OSSwitchFiber(u32 pc, u32 newStackPtr);
void OSLoadFPUContext(OSContext* context);
}
extern "C"{
}
extern "C"{
typedef u8 __OSException;
typedef void (*__OSExceptionHandler)(__OSException exception, OSContext* context);
__OSExceptionHandler __OSSetExceptionHandler(__OSException exception, __OSExceptionHandler handler);
__OSExceptionHandler __OSGetExceptionHandler(__OSException exception);
}
extern "C"{
typedef u16 OSError;
typedef void (*OSErrorHandler)(OSError error, OSContext* context, ...);
OSErrorHandler OSSetErrorHandler(OSError error, OSErrorHandler handler);
void __OSUnhandledException(__OSException exception, OSContext* context, u32 dsisr, u32 dar);
void OSReport(const char* message, ...);
void OSPanic(const char* file, int line, const char* message, ...);
extern OSErrorHandler __OSErrorTable[((15) + 1) ];
}
class MemHead {
public:
u32 mTagAndSize;
MemHead* mNext;
MemHead* mPrev;
u32 mGuardValue;
};
class AyuCache {
public:
AyuCache(u32);
void init(u32 bufferStart, u32 bufferEnd);
void* mallocL(u32 sizeBytes);
void cacheFree(void* ptr);
bool isEmpty();
u32 largestBlockFree();
int getIndex();
void releaseIndex(int);
void deleteIdAll(u32);
u32 amountFree();
MemHead mFreeBlockHead;
MemHead mAllocatedBlockHead;
u32 mCurrentAllocationTag;
u32 mTotalAllocatedUnits;
u32 mTotalCacheSizeBytes;
u8 mPageIndexPool[256];
u32 mNextPageSlot;
};
class AyuStack {
public:
AyuStack() { mIsActive = false; }
void reset(int resetFlags);
void* push(int requestedSizeBytes);
void pop();
void create( char* name, int allocFlags, void* stackBase, int stackSizeBytes, bool enableOverflowGuard);
void reset();
void checkStack();
int setAllocType(int type)
{
int old = mAllocType;
mAllocType = type;
return old;
}
int getFree() { return mSize - mTotalSize; }
int getTopUsed() { return mInitialStackLimit - mStackLimit; }
int getMaxFree() { return (mSize - mTotalSize - 8 > 0) ? mSize - mTotalSize - 8 : 0; }
void inactivate() { mIsActive = false; }
s32 mAllocType;
int mSize;
int mTotalSize;
u32 mInitialStackTop;
u32 mInitialStackLimit;
u32 mStackTop;
u32 mStackLimit;
bool mProtectOverflow;
bool mIsActive;
char* mName;
};
class AyuHeap : public AyuStack {
public:
AyuHeap() { }
void init( char* name, int allocFlags, void* stackBase, int stackSizeBytes);
u8 _24;
};
class RandomAccessStream;
class CoreNode : public ANode {
public:
CoreNode( char* name = "CoreNode") { initCore(name); }
virtual void read(RandomAccessStream& stream) { }
void initCore( char* name)
{
mParent = mNext = mChild = 0 ;
setName(name);
}
CoreNode* Child() { return mChild; }
CoreNode* Next() { return mNext; }
CoreNode* Parent() { return mParent; }
void Child(CoreNode* child) { mChild = child; }
void Next(CoreNode* next) { mNext = next; }
char* Name() { return mName; }
int getChildCount();
void add(class CoreNode* child);
void del();
void setName( char* name) { mName = name; }
void load( char* dirPath, char* fileName, u32);
void genRead(AgeServer&) { }
void genWrite(AgeServer&) { }
char* mName;
CoreNode* mParent;
CoreNode* mNext;
CoreNode* mChild;
};
extern "C"{
typedef struct Vec {
f32 x;
f32 y;
f32 z;
} Vec;
typedef struct SVec {
s16 x;
s16 y;
s16 z;
} SVec;
void C_VECAdd(const Vec* a, const Vec* b, Vec* ab);
void PSVECAdd(const Vec* a, const Vec* b, Vec* ab);
void C_VECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void PSVECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void C_VECScale(const Vec* src, Vec* dst, f32 scale);
void PSVECScale(const Vec* src, Vec* dst, f32 scale);
void C_VECNormalize(const Vec* src, Vec* unit);
void PSVECNormalize(const Vec* src, Vec* unit);
f32 C_VECSquareMag(const Vec* v);
f32 PSVECSquareMag(const Vec* v);
f32 VECMag (const Vec* v);
f32 PSVECMag(const Vec* v);
f32 C_VECDotProduct(const Vec* a, const Vec* b);
f32 PSVECDotProduct(const Vec* a, const Vec* b);
void C_VECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void PSVECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void VECHalfAngle (const Vec* a, const Vec* b, Vec* half);
void VECReflect (const Vec* src, const Vec* normal, Vec* dst);
f32 C_VECSquareDistance(const Vec* a, const Vec* b);
f32 PSVECSquareDistance(const Vec* a, const Vec* b);
f32 VECDistanc (const Vec* a, const Vec* b);
f32 PSVECDistance(const Vec* a, const Vec* b);
}
extern "C"{
typedef f32 Mtx[3][4];
typedef f32 Mtx23[2][3];
typedef f32 Mtx33[3][3];
typedef f32 Mtx44[4][4];
typedef f32 (*MtxPtr)[4];
typedef f32 (*Mtx23Ptr)[2];
typedef f32 (*Mtx33Ptr)[3];
typedef f32 (*Mtx44Ptr)[4];
typedef f32 PSQuaternion[4];
typedef struct Quaternion {
f32 x, y, z, w;
} Quaternion;
void C_MTXIdentity(Mtx m);
void PSMTXIdentity(Mtx m);
void C_MTXCopy(const Mtx src, Mtx dst);
void PSMTXCopy(const Mtx src, Mtx dst);
void C_MTXConcat(const Mtx a, const Mtx b, Mtx dst);
void PSMTXConcat(const Mtx a, const Mtx b, Mtx dst);
void C_MTXTranspose(const Mtx src, Mtx xPose);
void PSMTXTranspose(const Mtx src, Mtx xPose);
u32 C_MTXInverse(const Mtx src, Mtx inv);
u32 PSMTXInverse(const Mtx src, Mtx inv);
u32 C_MTXInvXpose(const Mtx src, Mtx inv);
u32 PSMTXInvXpose(const Mtx src, Mtx inv);
void MTXRotRad (Mtx m, char axis, f32 rad);
void PSMTXRotRad(Mtx m, char axis, f32 rad);
void MTXRotTrig (Mtx m, char axis, f32 sinA, f32 cosA);
void PSMTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void MTXRotAxisRad (Mtx m, const Vec* axis, f32 rad);
void PSMTXRotAxisRad(Mtx m, const Vec* axis, f32 rad);
void MTXTrans (Mtx m, f32 xT, f32 yT, f32 zT);
void PSMTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void MTXTransApply (const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void PSMTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void MTXScale (Mtx m, f32 xS, f32 yS, f32 zS);
void PSMTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void MTXScaleApply (const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void PSMTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void MTXQuat (Mtx m, const Quaternion* quat);
void PSMTXQuat(Mtx m, const Quaternion* quat);
void MTXReflect (Mtx m, const Vec* p, const Vec* n);
void PSMTXReflect(Mtx m, const Vec* p, const Vec* n);
void MTXLookAt (Mtx m, const Vec* camPos, const Vec* camUp, const Vec* target);
void MTXLightFrustum (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightPerspective (Mtx m, f32 fovY, f32 aspect, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightOrtho (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXFrustum (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void MTXPerspective (Mtx44 m, f32 fovY, f32 aspect, f32 n, f32 f);
void MTXOrtho (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTX44Identity(Mtx44 m);
void PSMTX44Identity(Mtx44 m);
void C_MTX44Copy(const Mtx44 src, Mtx44 dst);
void PSMTX44Copy(const Mtx44 src, Mtx44 dst);
void C_MTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void PSMTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void C_MTX44Transpose(const Mtx44 src, Mtx44 xPose);
void PSMTX44Transpose(const Mtx44 src, Mtx44 xPose);
u32 C_MTX44Inverse(const Mtx44 src, Mtx44 inv);
void C_MTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void PSMTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void C_MTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void PSMTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void C_MTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void PSMTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void C_MTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void PSMTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void C_MTX44RotRad(Mtx44 m, char axis, f32 rad);
void PSMTX44RotRad(Mtx44 m, char axis, f32 rad);
void C_MTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void PSMTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void C_MTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
void PSMTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
static inline void MTXSetPosition(Mtx mtx, const Vec* pos)
{
mtx[0][3] = pos->x;
mtx[1][3] = pos->y;
mtx[2][3] = pos->z;
}
}
extern "C"{
extern const f32 __float_huge[];
extern const f32 __float_nan[];
extern const f64 __double_huge[];
extern const f64 __double_nan[];
f64 cos(f64);
f32 cosf(f32);
f64 sin(f64);
f32 sinf(f32);
f64 tan(f64);
f32 tanf(f32);
f64 acos(f64);
f32 acosf(f32);
f64 asin(f64);
f64 atan(f64);
f32 atanf(f32);
f64 atan2(f64, f64);
f32 atan2f(f32, f32);
f64 ceil(f64);
f64 floor(f64);
f64 frexp(f64, int*);
f64 ldexp(f64, int);
f64 sqrt(f64);
f64 pow(f64, f64);
f64 log(f64);
f64 log10(f64);
f64 fmod(f64, f64);
f64 scalbn(f64, int);
inline f128 fabsl(f128 x)
{
return __fabs((f64)x);
}
inline f32 sqrtf(f32 x)
{
static const f64 _half = .5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
}
namespace std {
inline f32 sqrtf(f32 x)
{
static const f64 _half = 0.5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
inline f32 fmodf(f32 x, f32 m)
{
f32 b, a;
a = __fabsf(m) ;
b = __fabsf(x) ;
if (a > b) {
return x;
}
long long c = (long long)(x / m);
return x - m * c;
}
}
inline f32 fmod(f32 x, f32 m)
{
return std::fmodf(x, m);
}
class Vector3f;
class BoundBox;
class KTri;
class KRect;
class KSegment;
static inline f32 quickABS(f32 x)
{
*reinterpret_cast<u32*>(&x) &= ~0x80000000;
return x;
}
static inline f32 u32ToFloat(u32 a)
{
union {
u32 w;
f32 f;
} tmp;
tmp.w = a;
return tmp.f;
}
inline f32 absF(f32 val)
{
return (f32)__fabsf(val) ;
}
inline f32 absVal(f32 val)
{
if (val > 0.0f) {
return val;
}
return -val;
}
f32 roundAng(f32 angle);
f32 angDist(f32 x, f32 z);
f32 qdist2(f32 x0, f32 z0, f32 x1, f32 z1);
f32 triRectDistance( Vector3f*, Vector3f*, Vector3f*, BoundBox&, bool);
f32 distanceTriRect(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KTri&, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KSegment&, f32*, f32*);
f32 sqrDistance(KSegment&, KRect&, f32*, f32*, f32*);
f32 sqrDistance(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance( Vector3f&, KTri&, f32*, f32*);
f32 qdist3(f32 x0, f32 y0, f32 z0, f32 x1, f32 y1, f32 z1);
inline f32 speedy_sqrtf(f32 x)
{
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte(x) ;
y = (f32)(x * guess);
return y;
}
return x;
}
class AgeServer;
class Matrix3f;
class Matrix4f;
class Quat;
class Vector3f {
public:
Vector3f() { x = y = z = 0.0f; }
Vector3f(const f32& _x, const f32& _y, const f32& _z)
: x(_x)
, y(_y)
, z(_z)
{
}
Vector3f(const Vector3f& other)
{
x = other.x;
y = other.y;
z = other.z;
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
z = stream.readFloat();
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
stream.writeFloat(z);
}
void set(const f32& pX, const f32& pY, const f32& pZ)
{
x = pX;
y = pY;
z = pZ;
}
void set(const Vector3f& other) { set(other.x, other.y, other.z); }
void input( Vector3f& other) { set(other.x, other.y, other.z); }
void output(Vector3f& outVec) { outVec.set(x, y, z); }
f32 length() { return std::sqrtf((x * x) + (y * y) + (z * z) ); }
f32 squaredLength() { return (x * x) + (y * y) + (z * z) ; }
f32 DP( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 dot( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 distance( Vector3f& to)
{
Vector3f result;
result.sub2(to, *this);
return result.length();
}
f32 normalise()
{
f32 norm = length();
if (norm != 0.0f) {
div(norm);
}
return norm;
}
void CP( Vector3f& other)
{
Vector3f tmp;
tmp.x = y * other.z - z * other.y;
tmp.y = z * other.x - x * other.z;
tmp.z = x * other.y - y * other.x;
x = tmp.x;
y = tmp.y;
z = tmp.z;
}
void cross( Vector3f& vec1, Vector3f& vec2)
{
set(vec1.y * vec2.z - vec1.z * vec2.y, vec1.z * vec2.x - vec1.x * vec2.z, vec1.x * vec2.y - vec1.y * vec2.x);
}
void add( Vector3f& other)
{
x += other.x;
y += other.y;
z += other.z;
}
void add2( Vector3f& a, Vector3f& b) { set(a.x + b.x, a.y + b.y, a.z + b.z); }
void sub( Vector3f& other)
{
x -= other.x;
y -= other.y;
z -= other.z;
}
void sub( Vector3f& a, Vector3f& b)
{
x = a.x - b.x;
y = a.y - b.y;
z = a.z - b.z;
}
void sub2( Vector3f& a, Vector3f& b) { set(a.x - b.x, a.y - b.y, a.z - b.z); }
void div(f32 divisor)
{
x /= divisor;
y /= divisor;
z /= divisor;
}
void multiply(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale2(f32 scale, Vector3f& vec)
{
x = scale * vec.x;
y = scale * vec.y;
z = scale * vec.z;
}
void negate()
{
x = -x;
y = -y;
z = -z;
}
void bounce( Vector3f& surface, f32 elasticity)
{
f32 dp = -DP(surface) * elasticity;
if (dp > 0.0f) {
x = surface.x * dp + x;
y = surface.y * dp + y;
z = surface.z * dp + z;
}
}
void lerpTo( Vector3f& other, f32 t, Vector3f& outVec)
{
outVec.x = (other.x - x) * t + x;
outVec.y = (other.y - y) * t + y;
outVec.z = (other.z - z) * t + z;
}
void rotate( Matrix4f&);
void rotateTo( Matrix4f&, Vector3f&);
void multMatrix( Matrix4f&);
void multMatrixTo( Matrix4f&, Vector3f&);
void rotateTranspose( Matrix4f&);
void rotate( Quat&);
void rotateInverse( Quat&);
void normalize() { normalise(); }
void project( Vector3f& dirToRemove)
{
f32 projAmt = DP(dirToRemove);
x = -(projAmt * dirToRemove.x - x);
y = -(projAmt * dirToRemove.y - y);
z = -(projAmt * dirToRemove.z - z);
}
void middle( Vector3f& a, Vector3f& b)
{
add2(a, b);
scale(0.5f);
}
bool isSame( Vector3f& other)
{
return __fabsf(x - other.x) < 0.0001f && __fabsf(y - other.y) < 0.0001f && __fabsf(z - other.z) < 0.0001f;
}
void add( Vector3f& a, Vector3f& b)
{
x = a.x + b.x;
y = a.y + b.y;
z = a.z + b.z;
}
void add(f32 _x, f32 _y, f32 _z)
{
x += _x;
y += _y;
z += _z;
}
f32 x;
f32 y;
f32 z;
};
class Vector2f {
public:
Vector2f() { }
Vector2f(const f32& _x, const f32& _y)
{
x = _x;
y = _y;
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
}
void set(f32 _x, f32 _y)
{
x = _x;
y = _y;
}
f32 x, y;
};
class Vector2i {
public:
void read(Stream& stream)
{
x = stream.readInt();
y = stream.readInt();
}
void write(Stream& stream)
{
stream.writeInt(x);
stream.writeInt(y);
}
void set(int _x, int _y)
{
x = _x;
y = _y;
}
int x, y;
};
class Quat {
public:
Quat() { }
Quat(f32 _x, f32 _y, f32 _z, f32 _s) { set(_x, _y, _z, _s); }
void fromMat3f( Matrix3f&);
void rotate( Vector3f&, f32);
void multiply( Quat&);
void normalise();
void genVectorX(Vector3f&) ;
void genVectorY(Vector3f&) ;
void genVectorZ(Vector3f&) ;
void slerp( Quat&, f32, int);
void fromEuler( Vector3f&);
void multiplyTo( Quat&, Quat&);
void set(f32 _x, f32 _y, f32 _z, f32 _s)
{
v.x = _x;
v.y = _y;
v.z = _z;
s = _s;
}
Vector3f v;
f32 s;
};
inline Vector3f operator*(const Vector3f& a, const f32& b)
{
return Vector3f(a.x * b, a.y * b, a.z * b);
}
inline Vector3f operator*(const f32& a, const Vector3f& b)
{
return b * a;
}
inline Vector3f operator+(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x + b.x, a.y + b.y, a.z + b.z);
}
inline Vector3f operator-(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x - b.x, a.y - b.y, a.z - b.z);
}
inline Vector3f operator-(const Vector3f& a)
{
return Vector3f(-a.x, -a.y, -a.z);
}
inline Vector3f operator/(const Vector3f& a, const f32& b)
{
return a * (1.0f / b);
}
inline Vector3f CP(const Vector3f& a, const Vector3f& b)
{
f32 x = a.y * b.z - a.z * b.y;
f32 y = a.z * b.x - a.x * b.z;
f32 z = a.x * b.y - a.y * b.x;
return Vector3f(x, y, z);
}
class SRT {
public:
SRT() { }
SRT(const SRT& other)
: s(other.s)
, r(other.r)
, t(other.t)
{
}
Vector3f s;
Vector3f r;
Vector3f t;
};
class Plane;
class Matrix4f {
public:
Matrix4f() { }
Matrix4f( Mtx44);
void makeIdentity();
void makeRotate( Vector3f&, f32, f32);
void makeRotate( Vector3f&, f32);
void multiply( Matrix4f&);
void multiplyTo( Matrix4f&, Matrix4f&) ;
void makeSRT( Vector3f&, Vector3f&, Vector3f&);
void makeConcatSRT( Matrix4f*, Matrix4f&, SRT&);
void inverse(Matrix4f*);
void scale( Vector3f&);
void makeLookat( Vector3f& cameraPos, Vector3f& targetPos, Vector3f* optionalUp);
void makeLookat( Vector3f& cameraPos, Vector3f& rightDir, Vector3f& upDir, Vector3f& backDir);
void transposeTo(Matrix4f&);
void makeVQS( Vector3f&, Quat&, Vector3f&);
void blend( Matrix4f&, f32);
void makeOrtho(f32, f32, f32, f32, f32, f32, f32);
void makePerspective(f32 fovY, f32 aspectRatio, f32 nearZ, f32 farZ);
void makeBallRotate(Vector3f&);
void rotate(Vector3f&, f32);
void rotate(Vector3f&);
void rotate(f32, f32, f32);
void makeAligned(Vector3f&, f32);
void rotateX(f32);
void rotateY(f32);
void rotateZ(f32);
void translate(f32, f32, f32);
void makeLookfrom( Vector3f&, Vector3f&);
void makeProjection(Vector3f&, Plane&);
void makeReflection(Plane&);
void makeBillVector(Vector3f&, Matrix4f&, Vector3f&);
void makeSRT(SRT srt) { makeSRT(srt.s, srt.r, srt.t); }
inline void set( Matrix4f& other)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = other.mMtx[i][j];
}
}
}
inline void set(f32 value)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = value;
}
}
}
void getRow(int rowNum, Vector3f& row) { row.set(mMtx[rowNum][0], mMtx[rowNum][1], mMtx[rowNum][2]); }
void getColumn(int colNum, Vector3f& col) { col.set(mMtx[0][colNum], mMtx[1][colNum], mMtx[2][colNum]); }
void setRow(int rowNum, const Vector3f& row)
{
mMtx[rowNum][0] = row.x;
mMtx[rowNum][1] = row.y;
mMtx[rowNum][2] = row.z;
}
void setColumn(int colNum, const Vector3f& col)
{
mMtx[0][colNum] = col.x;
mMtx[1][colNum] = col.y;
mMtx[2][colNum] = col.z;
}
void setTranslation( Vector3f& trans)
{
mMtx[0][3] = trans.x;
mMtx[1][3] = trans.y;
mMtx[2][3] = trans.z;
}
void setTranslation(f32 x, f32 y, f32 z)
{
mMtx[0][3] = x;
mMtx[1][3] = y;
mMtx[2][3] = z;
}
static Matrix4f ident;
Mtx44 mMtx;
};
extern f32 sintable[0x1000];
extern f32 costable[0x1000];
static inline f32 sinShort(u16 x)
{
return sintable[(x >> 4) & 0xFFF];
}
static inline f32 cosShort(u16 x)
{
return costable[(x >> 4) & 0xFFF];
}
class Graphics;
class Vector3f;
class VQS;
class Node : public CoreNode {
public:
Node( char* name = "<Node>")
: CoreNode(name)
{
init(name);
}
virtual void update();
virtual void draw(Graphics&);
virtual void render(Graphics&);
virtual void concat() { }
virtual void concat(VQS&) { concat(); }
virtual void concat(SRT&) { concat(); }
virtual void concat(Matrix4f&) { concat(); }
virtual Matrix4f* getModelMatrix() { return 0 ; }
void init( char*);
bool getFlag(int);
int getFlags();
int getType();
void clearFlag(int);
void setFlag(int);
void setFlag(int, bool);
void setFlags(int);
void setType(int);
void togFlag(int);
static int currID;
s32 mType;
s32 mFlags;
s32 _1C;
};
class FaceNode : public CoreNode {
public:
FaceNode()
: CoreNode("face")
{
}
FaceNode(int faceCount)
: CoreNode("face")
{
mFaceCount = faceCount;
mMtxIdx = 0 ;
mVtxIdx = 0 ;
mColIdx = 0 ;
mNrmIdx = 0 ;
mTexCoords[0] = 0 ;
}
int mFaceCount;
int* mMtxIdx;
int* mVtxIdx;
int* mColIdx;
int* mNrmIdx;
int* mTexCoords[8];
};
class SRTNode : public Node {
public:
SRTNode( char* name);
virtual void update();
virtual void concat(Matrix4f&) { }
virtual void concat() { }
virtual Matrix4f* getModelMatrix() { return &mWorldMtx; }
Vector3f& getPosition() { return mSRT.t; }
Vector3f& getRotation() { return mSRT.r; }
Vector3f& getScale() { return mSRT.s; }
Vector3f& getWorldPosition() { return reinterpret_cast<Vector3f&>(mWorldMtx.mMtx[3]); }
void setPosition( Vector3f& pos) { mSRT.t = pos; }
void setRotation( Vector3f& rot) { mSRT.r = rot; }
void setScale( Vector3f& scale) { mSRT.s = scale; }
Matrix4f mWorldMtx;
SRT mSRT;
};
class NodeMgr {
public:
NodeMgr();
~NodeMgr();
inline CoreNode* firstNode() { return &mRootNode; }
CoreNode* findNode( char*, CoreNode*);
void recFindNode(CoreNode*, char*);
void Del(Node*);
bool mDelHappened;
CoreNode mRootNode;
};
extern NodeMgr* nodeMgr;
enum KeyboardButtons {
KBBTN_CSTICK_LEFT = 1 << 0,
KBBTN_CSTICK_RIGHT = 1 << 1,
KBBTN_CSTICK_UP = 1 << 2,
KBBTN_CSTICK_DOWN = 1 << 3,
KBBTN_DPAD_LEFT = 1 << 8,
KBBTN_DPAD_RIGHT = 1 << 9,
KBBTN_DPAD_UP = 1 << 10,
KBBTN_DPAD_DOWN = 1 << 11,
KBBTN_A = 1 << 12,
KBBTN_B = 1 << 13,
KBBTN_X = 1 << 14,
KBBTN_Y = 1 << 15,
KBBTN_Z = 1 << 16,
KBBTN_L = 1 << 17,
KBBTN_R = 1 << 18,
KBBTN_MSTICK_UP = 1 << 19,
KBBTN_MSTICK_RIGHT = 1 << 20,
KBBTN_MSTICK_DOWN = 1 << 21,
KBBTN_MSTICK_LEFT = 1 << 22,
KBBTN_START = 1 << 24,
KBBTN_NONE = 0x0,
KBBTN_ANY = 0xffffffff,
KBBTN_ANY_BUTTON = KBBTN_A | KBBTN_B | KBBTN_X | KBBTN_Y | KBBTN_Z | KBBTN_L | KBBTN_R | KBBTN_START,
};
class Controller : public Node {
public:
Controller(int playerNum)
: Node("<Controller>")
{
initialise(playerNum);
}
virtual void update();
void reset(u32 playerNum);
void updateCont(u32 keyStatus);
f32 getMainStickX();
f32 getMainStickY();
f32 getSubStickX();
f32 getSubStickY();
void initialise(u32 playerNum) { reset(playerNum); }
bool keyDown(u32 button) { return (mCurrentInput & button) != 0; }
bool keyUp(u32 button) { return (mCurrentInput & button) == 0; }
bool keyClick(u32 button) { return (mInputPressed & button) != 0; }
bool keyDoubleClick(u32 button) { return (mInputDoublePressed & button) != 0; }
bool keyUnClick(u32 button) { return (mInputReleased & button) != 0; }
u32 mCurrentInput;
u32 mPrevInput;
u32 mInputPressed;
u32 mInputReleased;
u32 mInputDoublePressed;
u32 mDoublePressMask;
u32 mPlayerNum;
u32 _3C;
u32 mInputDelay;
bool mIsControllerFrozen;
s8 mMainStickX;
s8 mMainStickY;
s8 mSubStickX;
s8 mSubStickY;
u8 mAnalogA;
u8 mAnalogB;
u8 mTriggerL;
u8 mTriggerR;
};
class ControllerMgr {
public:
virtual bool keyDown(int);
void update();
void init();
void updateController(Controller*);
};
extern "C"{
typedef struct ARQRequest ARQRequest;
typedef void (*ARCallback)(void);
typedef void (*ARQCallback)(u32 ptrToRequest);
struct ARQRequest {
ARQRequest* next;
u32 owner;
u32 type;
u32 priority;
u32 source;
u32 dest;
u32 length;
ARQCallback callback;
};
void __ARQServiceQueueLo();
void __ARQCallbackHack();
void __ARQInterruptServiceRoutine();
void ARQInit();
void ARQPostRequest(ARQRequest* task, u32 owner, u32 type, u32 priority, u32 source, u32 dest, u32 length, ARQCallback callback);
ARCallback ARRegisterDMACallback(ARCallback callback);
void ARStartDMA(u32 type, u32 mainmem_addr, u32 aram_addr, u32 length);
u32 ARInit(u32* stack_index_addr, u32 num_entries);
u32 ARGetBaseAddress();
u16 __ARGetInterruptStatus();
}
extern "C"{
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef s32 OSPriority;
typedef void (*OSIdleFunction)(void* param);
typedef void* (*OSThreadStartFunction)(void*);
typedef void (*OSSwitchThreadCallback)(OSThread* from, OSThread* to);
struct OSThreadQueue {
OSThread* head;
OSThread* tail;
};
struct OSThreadLink {
OSThread* next;
OSThread* prev;
};
struct OSMutexQueue {
OSMutex* head;
OSMutex* tail;
};
struct OSMutexLink {
OSMutex* next;
OSMutex* prev;
};
struct OSThread {
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void* val;
OSThreadQueue* queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex* mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8* stackBase;
u32* stackEnd;
s32 error;
};
extern volatile OSContext* __OSCurrentContext : ((u32)((void*)((u32)(0x00D4) + (0x80000000)))) ;
extern volatile OSContext* __OSFPUContext : ((u32)((void*)((u32)(0x00D8) + (0x80000000)))) ;
extern OSThreadQueue __OSActiveThreadQueue : ((u32)((void*)((u32)(0x00DC) + (0x80000000)))) ;
extern OSThread* __OSCurrentThread : ((u32)((void*)((u32)(0x00E4) + (0x80000000)))) ;
void OSInitThreadQueue(OSThreadQueue* queue);
OSThread* OSGetCurrentThread();
BOOL OSIsThreadTerminated(OSThread* thread);
s32 OSDisableScheduler();
s32 OSEnableScheduler();
void OSYieldThread();
BOOL OSCreateThread(OSThread* thread, OSThreadStartFunction func, void* param, void* stack, u32 stackSize, OSPriority priority, u16 attr);
void OSExitThread(void* val);
void OSCancelThread(OSThread* thread);
void OSDetachThread(OSThread* thread);
s32 OSResumeThread(OSThread* thread);
s32 OSSuspendThread(OSThread* thread);
void OSSleepThread(OSThreadQueue* queue);
void OSWakeupThread(OSThreadQueue* queue);
void OSClearStack(u8 val);
OSPriority OSGetThreadPriority(OSThread* thread);
BOOL OSIsThreadSuspended(OSThread* thread);
BOOL OSJoinThread(OSThread* thread, void** val);
BOOL OSSetThreadPriority(OSThread* thread, OSPriority prio);
OSThread* OSSetIdleFunction(OSIdleFunction idleFunc, void* param, void* stack, u32 stackSize);
OSThread* OSGetIdleFunction();
s32 OSCheckActiveThreads();
void __OSReschedule(void);
OSPriority __OSGetEffectivePriority(OSThread* thread);
void __OSPromoteThread(OSThread* thread, OSPriority priority);
enum OS_THREAD_STATE {
OS_THREAD_STATE_NULL = 0,
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8,
};
}
extern "C"{
typedef struct DVDCommandBlock DVDCommandBlock;
typedef struct DVDFileInfo DVDFileInfo;
typedef void (*DVDCallback)(s32 result, DVDFileInfo* fileInfo);
typedef void (*DVDCBCallback)(s32 result, DVDCommandBlock* block);
typedef void (*DVDLowCallback)(u32 intType);
typedef void (*DVDDoneReadCallback)(s32, DVDFileInfo*);
typedef void (*DVDOptionalCommandChecker)(DVDCommandBlock* block, DVDLowCallback callback);
typedef struct DVDDriveInfo {
u16 revisionLevel;
u16 deviceCode;
u32 releaseDate;
u8 padding[24];
} DVDDriveInfo;
typedef struct DVDDiskID {
char gameName[4];
char company[2];
u8 diskNumber;
u8 gameVersion;
u8 streaming;
u8 streamBufSize;
u8 padding[22];
} DVDDiskID;
struct DVDCommandBlock {
DVDCommandBlock* next;
DVDCommandBlock* prev;
u32 command;
s32 state;
u32 offset;
u32 length;
void* addr;
u32 currTransferSize;
u32 transferredSize;
DVDDiskID* id;
DVDCBCallback callback;
void* userData;
};
struct DVDFileInfo {
DVDCommandBlock cBlock;
u32 startAddr;
u32 length;
DVDCallback callback;
};
typedef struct DVDDir {
u32 entryNum;
u32 location;
u32 next;
} DVDDir;
typedef struct DVDDirEntry {
u32 entryNum;
BOOL isDir;
const char* name;
} DVDDirEntry;
typedef struct DVDQueue DVDQueue;
struct DVDQueue {
DVDQueue* mHead;
DVDQueue* mTail;
};
typedef struct DVDBB1 {
u32 appLoaderLength;
void* appLoaderFunc1;
void* appLoaderFunc2;
void* appLoaderFunc3;
} DVDBB1;
typedef struct DVDBB2 {
u32 bootFilePosition;
u32 FSTPosition;
u32 FSTLength;
u32 FSTMaxLength;
void* FSTAddress;
u32 userPosition;
u32 userLength;
u32 reserved_1C;
} DVDBB2;
void DVDInit();
BOOL DVDOpen(const char* filename, DVDFileInfo* fileInfo);
BOOL DVDFastOpen(s32 entryNum, DVDFileInfo* fileInfo);
s32 DVDReadPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, s32 prio);
BOOL DVDReadAsyncPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, DVDCallback callback, s32 prio);
BOOL DVDReadAbsAsyncPrio(DVDCommandBlock* block, void* addr, s32 length, s32 offset, DVDCBCallback callback, s32 prio);
BOOL DVDClose(DVDFileInfo* fileInfo);
BOOL DVDPrepareStreamAsync(DVDFileInfo* fileInfo, u32 length, u32 offset, DVDCallback callback);
void DVDResume();
void DVDReset();
BOOL DVDCancelAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancel(DVDCommandBlock* block);
s32 DVDChangeDisk(DVDCommandBlock* block, DVDDiskID* id);
BOOL DVDChangeDiskAsync(DVDCommandBlock* block, DVDDiskID* id, DVDCBCallback callback);
s32 DVDGetCommandBlockStatus(const DVDCommandBlock* block);
s32 DVDGetDriveStatus();
BOOL DVDSetAutoInvalidation(BOOL doAutoInval);
void* DVDGetFSTLocation();
BOOL DVDOpenDir(const char* dirName, DVDDir* dir);
BOOL DVDReadDir(DVDDir* dir, DVDDirEntry* dirEntry);
BOOL DVDCloseDir(DVDDir* dir);
BOOL DVDGetCurrentDir(char* path, u32 maxLength);
BOOL DVDChangeDir(const char* dirName);
s32 DVDConvertPathToEntrynum(const char* path);
void __DVDLowSetWAType(u32 type, u32 location);
s32 DVDGetTransferredSize(DVDFileInfo* fileInfo);
DVDDiskID* DVDGetCurrentDiskID();
BOOL DVDCompareDiskID(DVDDiskID* id1, DVDDiskID* id2);
DVDLowCallback DVDLowClearCallback();
BOOL DVDCancelStreamAsync(DVDCommandBlock* block, DVDCBCallback callback);
BOOL DVDCancelStream(DVDCommandBlock* block);
BOOL DVDCheckDisk();
void DVDPause();
s32 DVDSeekPrio(DVDFileInfo* fileInfo, s32 offset, s32 prio);
BOOL DVDSeekAsyncPrio(DVDFileInfo* fileInfo, s32 offset, DVDCallback callback, s32 prio);
s32 DVDGetFileInfoStatus(DVDFileInfo* fileInfo);
BOOL DVDFastOpenDir(s32 entryNum, DVDDir* dir);
BOOL DVDCancelAllAsync(DVDCBCallback callback);
s32 DVDCancelAll();
void DVDDumpWaitingQueue();
void __DVDFSInit();
void __DVDClearWaitingQueue();
void __DVDInitWA(void);
void __fstLoad(void);
BOOL DVDLowRead(void* addr, u32 length, u32 offset, DVDLowCallback callback);
void __DVDStoreErrorCode(u32 error);
BOOL DVDLowStopMotor(DVDLowCallback callback);
BOOL DVDLowRequestError(DVDLowCallback callback);
BOOL DVDLowSeek(u32 offset, DVDLowCallback callback);
BOOL DVDLowAudioBufferConfig(BOOL enable, u32 size, DVDLowCallback callback);
BOOL DVDLowReadDiskID(DVDDiskID* diskID, DVDLowCallback callback);
BOOL DVDLowWaitCoverClose(DVDLowCallback callback);
BOOL __DVDCheckWaitingQueue();
BOOL DVDLowRequestAudioStatus(u32 subcmd, DVDLowCallback callback);
BOOL DVDLowAudioStream(u32 subcmd, u32 length, u32 offset, DVDLowCallback callback);
BOOL DVDLowInquiry(DVDDriveInfo* info, DVDLowCallback callback);
BOOL __DVDPushWaitingQueue(int idx, struct DVDQueue* newTail);
void DVDLowReset();
BOOL DVDLowBreak();
BOOL __DVDDequeueWaitingQueue(DVDQueue* queue);
BOOL DVDReadDiskID(DVDCommandBlock* block, DVDDiskID* diskID, DVDCBCallback callback);
void DVDSeekAbsAsyncPrio(DVDCommandBlock* block, void* addr, DVDCBCallback callback, s32 prio);
BOOL DVDPrepareStreamAbsAsync(DVDCommandBlock* block, u32 length, u32 offset, DVDCBCallback callback);
BOOL DVDReadAbsAsyncForBS(DVDCommandBlock* block, void* addr, s32 length, s32 offset, DVDCBCallback callback);
void __DVDPrepareResetAsync(DVDCBCallback callback);
extern OSThreadQueue __DVDThreadQueue;
}
extern "C"{
typedef s64 OSTime;
typedef u32 OSTick;
extern u32 __OSBusClock : ((0x80000000) | 0x00F8) ;
extern u32 __OSCoreClock : ((0x80000000) | 0x00FC) ;
OSTime __OSGetSystemTime();
OSTick OSGetTick();
OSTime OSGetTime();
typedef struct OSCalendarTime {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* timeDate);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* timeDate);
}
extern "C"{
typedef struct OSAlarm OSAlarm;
typedef struct OSAlarmQueue OSAlarmQueue;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm {
OSAlarmHandler handler;
u32 tag;
OSTime fire;
OSAlarm* prev;
OSAlarm* next;
OSTime period;
OSTime start;
};
struct OSAlarmQueue {
OSAlarm* head;
OSAlarm* tail;
};
void OSInitAlarm();
void OSSetAlarm(OSAlarm* alarm, OSTime tick, OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm* alarm);
void OSCancelAlarm(OSAlarm* alarm);
BOOL OSCheckAlarmQueue();
void OSSetAbsAlarm(OSAlarm* alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm* alarm, OSTime start, OSTime period, OSAlarmHandler handler);
void OSSetAlarmTag(OSAlarm* alarm, u32 tag);
void OSCancelAlarms(u32 tag);
}
extern "C"{
typedef int OSHeapHandle;
typedef void (*OSAllocVisitor)(void* obj, u32 size);
extern volatile OSHeapHandle __OSCurrHeap;
void* OSInitAlloc(void* arenaStart, void* arenaEnd, int maxHeaps);
OSHeapHandle OSCreateHeap(void* start, void* end);
OSHeapHandle OSSetCurrentHeap(OSHeapHandle heap);
void OSFreeToHeap(OSHeapHandle heap, void* ptr);
void* OSAllocFromHeap(OSHeapHandle heap, u32 size);
}
extern "C"{
void* OSGetArenaHi(void);
void* OSGetArenaLo(void);
void OSSetArenaHi(void* addr);
void OSSetArenaLo(void* addr);
}
extern "C"{
typedef struct OSBootInfo {
DVDDiskID DVDDiskID;
u32 magic;
u32 version;
u32 memorySize;
u32 consoleType;
void* arenaLo;
void* arenaHi;
void* FSTLocation;
u32 FSTMaxLength;
} OSBootInfo;
typedef struct BI2Debug {
int debugMonSize;
int simMemSize;
u32 argOffset;
u32 debugFlag;
int trackLocation;
int trackSize;
u32 countryCode;
u8 _1C[0x4];
u32 dvdLongFileNameFlag;
u32 padSpec;
} BI2Debug;
extern void* OS_BOOT_REGION_START : (0x812FDFF0) ;
extern void* OS_BOOT_REGION_END : (0x812FDFEC) ;
}
extern "C"{
void DCInvalidateRange(void* addr, u32 numBytes);
void DCFlushRange(void* addr, u32 numBytes);
void DCStoreRange(void* addr, u32 numBytes);
void DCFlushRangeNoSync(void* addr, u32 numBytes);
void DCStoreRangeNoSync(void* addr, u32 numBytes);
void DCZeroRange(void* addr, u32 numBytes);
void ICInvalidateRange(void* addr, u32 numBytes);
void ICFlashInvalidate();
void ICEnable();
void LCEnable();
void LCDisable();
void LCStoreBlocks(void* destAddr, void* srcTag, u32 numBlocks);
u32 LCStoreData(void* destAddr, void* srcAddr, u32 numBytes);
void LCQueueWait(u32 length);
void L2GlobalInvalidate();
void DCTouchRange(void* addr, u32 numBytes);
void ICSync();
void ICDisable();
void ICFreeze();
void ICUnfreeze();
void ICBlockInvalidate(void* addr);
void LCLoadBlocks(void* destTag, void* srcAddr, u32 numBlocks);
u32 LCLoadData(void* destAddr, void* srcAddr, u32 numBytes);
u32 LCQueueLength();
void LCFlushQueue();
void L2Enable();
void L2Disable();
void L2SetDataOnly(BOOL doDataOnly);
void L2SetWriteThrough(BOOL doWriteThrough);
}
extern "C"{
typedef void (*EXICallback)(s32 channel, OSContext* context);
BOOL EXIProbe(s32 channel);
s32 EXIProbeEx(s32 channel);
s32 EXIGetType(s32 channel, u32 dev, u32* type);
char* EXIGetTypeString(u32 type);
u32 __OSGetDIConfig(void);
void __OSEnableBarnacle(s32 chan, u32 dev);
}
extern "C"{
void PPCSync(void);
void PPCEieio(void);
void PPCHalt(void);
u32 PPCMfmsr(void);
void PPCMtmsr(u32 value);
void PPCOrMsr(void);
void PPCAndMsr(void);
void PPCAndCMsr(void);
u32 PPCMfhid0(void);
void PPCMthid0(u32 value);
u32 PPCMfhid1(void);
u32 PPCMfhid2(void);
void PPCMthid2(u32 value);
u32 PPCMfl2cr(void);
void PPCMtl2cr(u32 value);
u32 PPCMfdec(void);
void PPCMtdec(u32 value);
u32 PPCMfmmcr0(void);
void PPCMtmmcr0(u32 value);
u32 PPCMfmmcr1(void);
void PPCMtmmcr1(u32 value);
u32 PPCMfpmc1(void);
void PPCMtpmc1(u32 value);
u32 PPCMfpmc2(void);
void PPCMtpmc2(u32 value);
u32 PPCMfpmc3(void);
void PPCMtpmc3(u32 value);
u32 PPCMfpmc4(void);
void PPCMtpmc4(u32 value);
u32 PPCMfsia(void);
void PPCMtsia(u32 value);
u32 PPCMfwpar(void);
void PPCMtwpar(u32 value);
u32 PPCMfdmaU(void);
void PPCMtdmaU(u32 value);
u32 PPCMfdmaL(void);
void PPCMtdmaL(u32 value);
u32 PPCMfpvr(void);
}
extern "C"{
static inline void OSInitFastCast(void)
{
asm {
li r3, (0x0004)
oris r3, r3, (0x0004)
mtspr 914 , r3
li r3, (0x0005)
oris r3, r3, (0x0005)
mtspr 915 , r3
li r3, (0x0006)
oris r3, r3, (0x0006)
mtspr 916 , r3
li r3, (0x0007)
oris r3, r3, (0x0007)
mtspr 917 , r3
}
}
static inline void OSf32tou8(register f32* in, register u8* out)
{
asm {
lfs f1, 0 (in)
psq_st f1, 0 (out), 1, (2)
}
}
static inline void OSf32tou16(register f32* in, register u16* out)
{
asm {
lfs f1, 0 (in)
psq_st f1, 0 (out), 1, (3)
}
}
static inline void OSf32tos8(register f32* in, register s8* out)
{
asm {
lfs fp1, 0 (in)
psq_st fp1, 0 (out), 1, (4)
}
}
static inline void OSf32tos16(register f32* in, register s16* out)
{
asm {
lfs fp1, 0 (in)
psq_st fp1, 0 (out), 1, (5)
}
}
static inline void OSu8tof32(register u8* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (2)
stfs fp1, 0 (out)
}
}
static inline void OSu16tof32(register u16* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (3)
stfs fp1, 0 (out)
}
}
static inline void OSs8tof32(register s8* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (4)
stfs fp1, 0 (out)
}
}
static inline void OSs16tof32(register s16* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (5)
stfs fp1, 0 (out)
}
}
}
extern "C"{
typedef struct OSFontHeader {
u16 fontType;
u16 firstChar;
u16 lastChar;
u16 invalChar;
u16 ascent;
u16 descent;
u16 width;
u16 leading;
u16 cellWidth;
u16 cellHeight;
u32 sheetSize;
u16 sheetFormat;
u16 sheetColumn;
u16 sheetRow;
u16 sheetWidth;
u16 sheetHeight;
u16 widthTable;
u32 sheetImage;
u32 sheetFullSize;
u8 c0;
u8 c1;
u8 c2;
u8 c3;
} OSFontHeader;
u16 OSGetFontEncode();
char* OSGetFontWidth(const char* string, s32* width);
BOOL OSInitFont(OSFontHeader* fontInfo);
char* OSGetFontTexture(const char* string, void** image, s32* x, s32* y, s32* width);
u32 OSLoadFont(OSFontHeader* fontInfo, void* temp);
char* OSGetFontTexel(const char* string, void* image, s32 pos, s32 stride, s32* width);
typedef enum {
OS_FONT_ENCODE_ANSI,
OS_FONT_ENCODE_SJIS,
OS_FONT_ENCODE_2,
OS_FONT_ENCODE_UTF8,
OS_FONT_ENCODE_UTF16,
OS_FONT_ENCODE_UTF32,
OS_FONT_ENCODE_MAX,
} OSFontEncode;
}
extern "C"{
typedef s16 __OSInterrupt;
typedef void (*__OSInterruptHandler)(__OSInterrupt interrupt, OSContext* context);
typedef u32 OSInterruptMask;
extern volatile __OSInterrupt __OSLastInterrupt;
extern vu32 __OSLastInterruptSrr0;
extern volatile OSTime __OSLastInterruptTime;
extern volatile OSInterruptMask __OSPriorInterruptMask : ((u32)((void*)((u32)(0x00C4) + (0x80000000)))) ;
extern volatile OSInterruptMask __OSCurrentInterruptMask : ((u32)((void*)((u32)(0x00C8) + (0x80000000)))) ;
__OSInterruptHandler __OSSetInterruptHandler(__OSInterrupt interrupt, __OSInterruptHandler handler);
__OSInterruptHandler __OSGetInterruptHandler(__OSInterrupt interrupt);
void __OSDispatchInterrupt(__OSException exception, OSContext* context);
BOOL OSEnableInterrupts();
BOOL OSDisableInterrupts();
BOOL OSRestoreInterrupts(BOOL enabled);
OSInterruptMask __OSMaskInterrupts(OSInterruptMask mask);
OSInterruptMask __OSUnmaskInterrupts(OSInterruptMask mask);
OSInterruptMask OSGetInterruptMask();
OSInterruptMask OSSetInterruptMask(OSInterruptMask mask);
void __RAS_OSDisableInterrupts_begin();
void __RAS_OSDisableInterrupts_end();
}
extern "C"{
void OSProtectRange(u32 channel, void* addr, u32 numBytes, u32 control);
}
extern "C"{
typedef struct OSMesgQueue_s OSMesgQueue_s;
typedef struct OSMesgQueue_s OSMessageQueue;
typedef void* OSMessage;
struct OSMesgQueue_s {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
s32 msgCount;
s32 firstIndex;
s32 usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, s32 msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, s32 flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, s32 flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, s32 flags);
}
extern "C"{
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSModuleHeader OSModuleHeader;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
typedef u32 OSModuleID;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u32 prolog;
u32 epilog;
u32 unresolved;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
void OSSetStringTable(void* stringTable);
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* oldModule);
OSModuleInfo* OSSearchModule(void* ptr, u32* section, u32* offset);
}
extern "C"{
struct OSMutex {
OSThreadQueue queue;
OSThread* thread;
int count;
OSMutexLink link;
};
typedef struct OSCond {
OSThreadQueue queue;
} OSCond;
void OSInitMutex(OSMutex* mutex);
void OSLockMutex(OSMutex* mutex);
void OSUnlockMutex(OSMutex* mutex);
BOOL OSTryLockMutex(OSMutex* mutex);
void __OSUnlockAllMutex(OSThread* thread);
BOOL __OSCheckMutex(OSMutex* mutex);
BOOL __OSCheckDeadLock(OSThread* thread);
BOOL __OSCheckMutexes(OSThread* thread);
void OSInitCond(OSCond* cond);
void OSWaitCond(OSCond* cond, OSMutex* mutex);
void OSSignalCond(OSCond* cond);
}
extern "C"{
typedef struct OSResetFunctionInfo OSResetFunctionInfo;
typedef BOOL (*OSResetFunction)(BOOL final);
typedef void (*OSResetCallback)(void);
struct OSResetFunctionInfo {
OSResetFunction func;
u32 priority;
OSResetFunctionInfo* next;
OSResetFunctionInfo* prev;
};
typedef struct OSResetQueue {
OSResetFunctionInfo* head;
OSResetFunctionInfo* tail;
} OSResetQueue;
void OSRegisterResetFunction(OSResetFunctionInfo* info);
void OSResetSystem(int reset, u32 code, BOOL doForceMenu);
u32 OSGetResetCode();
void OSGetSaveRegion(void** start, void** end);
void OSSetSaveRegion(void* start, void* end);
BOOL OSGetResetButtonState();
BOOL OSGetResetSwitchState();
void __OSReboot(u32 resetCode, u32 bootDol);
void __OSDoHotReset(s32 code);
void OSSetSaveRegion(void* start, void* end);
void OSGetSaveRegion(void** start, void** end);
void OSGetSavedRegion(void** start, void** end);
void OSUnregisterResetFunction(OSResetFunctionInfo* info);
OSResetCallback OSSetResetCallback(OSResetCallback callback);
extern BOOL __OSIsGcam;
extern u32 OS_RESET_CODE : (0x800030F0) ;
extern volatile u8 OS_REBOOT_BOOL : (0x800030E2) ;
}
extern "C"{
typedef void (*SramCallback)(void);
typedef struct OSSram {
u16 checkSum;
u16 checkSumInv;
u32 ead0;
u32 ead1;
u32 counterBias;
s8 displayOffsetH;
u8 ntd;
u8 language;
u8 flags;
} OSSram;
typedef struct OSSramEx {
u8 flashID[2][12];
u32 wirelessKeyboardID;
u16 wirelessPadID[4];
u8 dvdErrorCode;
u8 reserved_25;
u8 flashIDCheckSum[2];
u16 gbs;
u8 reserved_2A[2];
} OSSramEx;
typedef struct SramControlBlock {
u8 sram[0x40];
u32 offset;
BOOL enabled;
BOOL locked;
BOOL sync;
SramCallback callback;
} SramControlBlock;
void __OSInitSram();
OSSram* __OSLockSram();
OSSramEx* __OSLockSramEx();
BOOL __OSUnlockSram(BOOL commit);
BOOL __OSUnlockSramEx(BOOL commit);
BOOL __OSSyncSram(void);
u32 OSGetSoundMode();
void OSSetSoundMode(u32 mode);
u32 OSGetProgressiveMode();
void OSSetProgressiveMode(u32 on);
u8 OSGetLanguage();
void OSSetLanguage(u8 language);
u32 OSGetEuRgb60Mode();
void OSSetEuRgb60Mode(u32 on);
void OSSetWirelessID(s32 channel, u16 id);
u16 OSGetWirelessID(s32 channel);
}
extern "C"{
extern void __OSPSInit();
extern void __OSFPRInit();
extern void __OSCacheInit();
extern void __OSContextInit();
extern void __OSInterruptInit();
extern void __OSThreadInit();
extern void __OSInitSystemCall();
extern void __OSModuleInit();
extern void __OSInitAudioSystem();
extern void __OSStopAudioSystem();
extern void __OSInitMemoryProtection();
void OSInit(void);
u32 OSGetConsoleType();
extern BOOL __OSInIPL;
extern OSTime __OSStartTime;
}
class AgeServer;
class RandomAccessStream;
class ID32 {
public:
ID32();
ID32(u32 id);
void operator=(u32 id);
bool operator==(u32 id) ;
bool operator!=(u32 id) ;
bool match(u32 id, char wild = '*') ;
void print() ;
void read(RandomAccessStream& stream);
void setID(u32 id);
void sprint(char* str) ;
void updateID();
void updateString();
void write(RandomAccessStream& stream) ;
void genAge(AgeServer&, char*);
void ageChangeID() { updateID(); }
u32 mId;
char mStringID[5];
};
class AnimData;
class Shape;
class TexImg;
class Texture;
class GfxobjInfo {
public:
GfxobjInfo()
{
mPrev = mNext = 0 ;
mString = "";
mId.setID('none');
mAttached = 0;
}
void insertAfter(GfxobjInfo* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
GfxobjInfo* mPrev;
GfxobjInfo* mNext;
char* mString;
ID32 mId;
u32 mAttached;
virtual void attach() { }
virtual void detach() { }
};
class GfxObject {
public:
virtual void attach() { }
virtual void detach() { }
};
class ShpobjInfo : public GfxobjInfo {
public:
ShpobjInfo()
: mTarget(0 )
{
}
Shape* mTarget;
};
void free(void*);
extern "C"{
typedef struct {
int quot;
int rem;
} div_t;
s32 abs(s32 __x);
s32 labs(s32 __x);
div_t div(s32 __numer, s32 __denom);
inline int _abs(int __x)
{
return __x > 0 ? __x : -__x;
}
}
extern "C"{
int __mbtowc_noconv(wchar_t*, const char*, size_t);
int __wctomb_noconv(char*, wchar_t);
size_t wcstombs(char* s, const wchar_t* pwcs, size_t n);
int mbstowcs(wchar_t* pwc, const char* s, size_t n);
int wctomb(char* s, wchar_t wchar);
static int unicode_to_UTF8(char* s, wchar_t wchar);
int mbtowc(wchar_t* pwc, const char* s, size_t n);
static int is_utf8_complete(const char* s, size_t n);
}
extern "C"{
int rand();
void srand(u32 seed);
}
extern "C"{
f128 __strtold(int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* overflow);
s32 strtol(const char* str, char** end, int base);
f64 atof(const char* str);
}
extern "C"{
u32 __strtoul(int base, int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* negative,
int* overflow);
u64 __strtoull(int base, int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* negative,
int* overflow);
int atoi(const char* str);
u32 strtoul(const char* str, char** end, int base);
}
extern "C"{
void abort(void);
void atexit(void);
void exit(int);
}
struct DGXGraphics;
class BaseApp;
class CacheTexture;
class TextureCacher;
class LoadIdler;
class Timers;
class Font;
class BaseShape;
class CoreNode;
class LFInfo;
class LightFlare;
class LFlareGroup;
class Matrix4f;
class AtxRouter;
class ControllerMgr;
struct OSContext;
struct OSThread;
class Shape;
class AnimData;
class AnimFrameCacher;
class MemInfo;
class CacheInfo;
enum SystemHeapType {
SYSHEAP_NULL = -1,
SYSHEAP_Sys = 0,
SYSHEAP_Ovl = 1,
SYSHEAP_App = 2,
SYSHEAP_Load = 3,
SYSHEAP_Teki = 4,
SYSHEAP_Movie = 5,
SYSHEAP_Message = 6,
SYSHEAP_Lang = 7,
SYSHEAP_COUNT,
};
enum TimerState {
TS_Off = 0,
TS_On,
TS_Full
};
enum LanguageID {
LANG_FORCE_CHANGE = -1,
LANG_Adult = 0,
LANG_Child = 1,
LANG_CAPACITY = 8,
};
struct AddressNode : public CoreNode {
AddressNode()
: CoreNode("")
{
}
};
struct DirEntry : public CoreNode {
DirEntry()
: CoreNode("")
{
}
int mPending;
u32 mAddress;
};
class BinobjInfo : public GfxobjInfo {
public:
BinobjInfo()
: mData(0 )
{
}
u8* mData;
};
struct SystemCache : public ARQRequest {
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
void insertAfter(SystemCache* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
SystemCache* mNext;
SystemCache* mPrev;
};
struct SystemFlags { typedef
enum {
Active = 0x00200000,
Shutdown = 0x80000000,
} Type; } ;
class StdSystem {
public:
StdSystem();
void onceInit();
AyuHeap* getHeap(int heapIdx);
void resetHeap(int heapIdx, int flag);
int setHeap(int);
GfxobjInfo* findGfxObject( char*, u32);
Texture* loadTexture( char* path, bool isRelativePath);
Shape* loadShape( char* modelPath, bool checkCache);
AnimData* findAnimation( char*);
int findAnyIndex( char*, char*);
AnimData* loadAnimation(Shape* model, char* dataPath, bool isRelativePath);
void addAnimation(AnimData*, char*);
void addGfxObject(GfxobjInfo*);
void attachObjs();
void detachObjs();
void invalidateObjs(u32, u32);
void addTexture(Texture*, char*);
Shape* getShape( char*, char*, char*, bool);
void initLFlares(int);
void resetLFlares();
LFInfo* getLFlareInfo();
LFlareGroup* registerLFlare(Texture*);
void flushLFlares(Graphics&);
void loadBundle( char* pPath, bool loadWithCache);
void getAppMemory(char*);
GfxobjInfo* findAnyGfxObject( char*, u32);
GfxobjInfo* findTexture(Texture*);
AnimData* findAnyAnimation( char*);
AnimData* findIndexAnimation( char*, int);
static char* stringDup( char*);
f32 getRand(f32 max) { return max * (rand() / f32((0x7fff) )); }
f32 getHalfRand(f32 max) { return max * (rand() / f32((0x7fff) ) - 0.5f); }
f32 getFade() { return mCurrentFade; }
void setFade(f32 target, f32 rate = 3.0f)
{
mTargetFade = target;
mFadeRate = rate;
}
void set2DRoot( char* bloDir, char* texDir)
{
mBloDir = bloDir;
mTexDir = texDir;
}
void setTextureBase( char* base1, char* base2)
{
mTextureBase1 = base1;
mTextureBase2 = base2;
}
void setDataRoot( char* dir) { mDataRoot = dir; }
void softReset() { mSoftResetPending = true; }
void Shutdown() { mSystemFlags = SystemFlags::Shutdown; }
bool isShutdown() { return mSystemFlags == SystemFlags::Shutdown; }
bool resetPending() { return mSoftResetPending; }
void setFrameClamp(int frameRate) { mFrameRate = frameRate; }
int getHeapNum() { return mActiveHeapIdx; }
void setActive(bool set)
{
u32 unused;
if (set) {
mSystemFlags |= SystemFlags::Active;
unused = mSystemFlags;
} else {
mSystemFlags &= ~SystemFlags::Active;
unused = mSystemFlags;
}
Activate(set);
}
bool isActive(void) { return (mSystemFlags & SystemFlags::Active) == SystemFlags::Active; }
bool mSoftResetPending;
f32 mCurrentFade;
f32 mTargetFade;
f32 mFadeRate;
Font* mConsFont;
s32 mFrameRate;
u32 mTimerState;
u32 mTogglePrint;
u32 mToggleDebugInfo;
u32 mToggleDebugExtra;
u32 mToggleBlur;
u32 mToggleFileInfo;
u32 mToggleColls;
Timers* mTimer;
TextureCacher* mCacher;
u32 mMatrixCount;
Matrix4f* mMatrices;
char* mBloDir;
char* mTexDir;
char* mActiveDir;
char* mDataRoot;
AyuHeap mHeaps[SYSHEAP_COUNT];
int mActiveHeapIdx;
BOOL mToggleHeapAllocPrint;
MemInfo* mCurrMemInfo;
virtual void initSoftReset();
virtual RandomAccessStream* openFile( char* path, bool isRelativePath = true, bool = true) { return 0 ; }
virtual u32 copyRamToCache(u32, u32, u32) { return 0; }
virtual void copyCacheToRam(u32, u32, u32) { }
virtual void copyWaitUntilDone() { }
virtual void copyCacheToTexture(CacheTexture*) { }
virtual void Activate(bool) { }
virtual void parseArchiveDirectory( char* arcPath, char* dirPath) { }
virtual void sndPlaySe(u32) = 0;
virtual void startLoading(LoadIdler*, bool, u32) { }
virtual void endLoading() { }
int mPolygonCount;
u32 mMaterialCount;
u32 mDispCount;
u32 mLightCount;
s32 mActiveLightCount;
u32 mAnimatedPolygons;
u32 mLightingSkips;
u32 mLightingSets;
u32 mLightSetNum;
u32 mSystemFlags;
Graphics* mGraphics;
GfxobjInfo mGfxobjInfo;
bool mHasGfxObjects;
char* mTextureBase1;
char* mTextureBase2;
Shape* mCurrentShape;
CoreNode mDvdRoot;
CoreNode mAramRoot;
DirEntry* mFileList;
int mFlareCount;
int mLfInfoCount;
LFInfo* mFlareInfoList;
LFlareGroup* mFlareGroupList;
int mDvdOpenFiles;
u32 mDvdBytesRead;
void ageAnyAnimations(AgeServer&, char*);
};
struct AramAllocator {
void init(u32 start, u32 size)
{
mStartAddress = start;
mTotalSize = size;
reset();
}
void reset() { mNextFreeAddress = mStartAddress; }
u32 alloc(u32 numBytes)
{
u32 allocAddr = 0;
u32 nextFree = mNextFreeAddress;
if (nextFree + numBytes <= mStartAddress + mTotalSize) {
allocAddr = nextFree;
mNextFreeAddress = nextFree + numBytes;
}
return allocAddr;
}
u32 getFreeSize() { return mStartAddress + mTotalSize - mNextFreeAddress; }
u32 mStartAddress;
u32 mNextFreeAddress;
u32 mTotalSize;
};
struct DvdError { typedef
enum {
None = -1,
ReadingDisc = 0,
FatalError = 1,
RetryError = 2,
NoDisc = 3,
CoverOpen = 4,
WrongDisc = 5
} Type; } ;
struct SystemClass250 {
virtual void method(Graphics& gfx) = 0;
};
struct SymbolInfo {
SymbolInfo* mNext;
u32 mVirtualAddress;
char mDemangledName[];
};
class System : public StdSystem {
public:
System();
virtual void initSoftReset();
virtual RandomAccessStream* openFile( char* path, bool isRelativePath = true, bool = true);
virtual u32 copyRamToCache(u32, u32, u32);
virtual void copyCacheToRam(u32, u32, u32);
virtual void copyWaitUntilDone();
virtual void copyCacheToTexture(CacheTexture*);
virtual void parseArchiveDirectory( char* arcPath, char* dirPath);
virtual void sndPlaySe(u32);
virtual void startLoading(LoadIdler* idler, bool useLoadScreen, u32 loadDelay);
virtual void endLoading();
~System();
void run(BaseApp* app);
void beginRender();
void doneRender();
void waitRetrace();
f32 getTime();
void updateSysClock();
void hardReset();
void showDvdError(Graphics&);
void nudgeLoading();
void nudgeDvdThread();
void startDvdThread();
void Initialise();
RandomAccessStream* createFile( char*, BOOL);
char* findAddress(u32);
bool hasDebugInfo();
static void halt( char* file, int line, char* message);
void sleep(f32 seconds);
static void* alloc(size_t);
AtxRouter* getAtxRouter() { return mAtxRouter; }
void setAtxRouter(AtxRouter* router) { mAtxRouter = router; }
f32 getFrameTime() { return mDeltaTime; }
f32 getFrameRate() { return mFPS; }
int setStreamType(int);
void setActiveAramAllocator(AramAllocator* allocator) { mActiveAramAllocator = allocator; }
u32 mHeapStart;
u32 mHeapEnd;
Graphics* mDGXGfx;
SystemClass250* mHaltCallback;
Delegate1<System, Graphics&>* mDvdErrorCallback;
int mDvdErrorCode;
u32 mDvdBufferSize;
u32 mIsLoadingActive;
u32 mLoadTimeBeforeIdling;
u32 mIsLoadScreenActive;
vu32 mIsRendering;
u32 mIsCardSaving;
OSThread* mCurrentThread;
AtxRouter* mAtxRouter;
ControllerMgr mControllerMgr;
u32 mPrevTick;
u32 mFpsSampleStart;
int mFrameTicks;
f32 mDeltaTime;
f32 mFPS;
u32 mEngineFrames;
u32 mFramesAtSampleStart;
u32 mTotalFrames;
u32 mRetraceCount;
BOOL mPrevAllocType;
AddressNode _2A8;
SymbolInfo* mBuildMapFuncList;
SystemCache mActiveCacheList;
SystemCache mFreeCacheList;
AramAllocator mShapeAramAllocator;
AramAllocator mBaseAramAllocator;
AramAllocator* mActiveAramAllocator;
vu32 mDmaComplete;
vu32 mTexComplete;
};
extern System* gsys;
struct LogStream : public Stream {
LogStream()
{
mBufPosition = 0;
_UNUSED0C = 0;
}
virtual void flush()
{
mBuffer[mBufPosition] = 0;
if (gsys->mTogglePrint) {
OSReport("%s\n", mBuffer);
}
mBufPosition = 0;
}
virtual void write( void* data, int size)
{
for (int i = 0; i < size; i++) {
char c = (( char*)data)[i];
if (c == 0xA) {
flush();
continue;
}
if (c == 0x9) {
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = ' ';
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = ' ';
continue;
}
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = c;
}
}
int mBufPosition;
u32 _UNUSED0C;
char mBuffer[0x100];
};
struct AramStream : public RandomAccessStream {
virtual int getPending() { return mPending; }
virtual void read(void* data, int size)
{
int readSize = (((u32)(size) + 0x1F) & ~(0x1F)) ;
gsys->copyCacheToRam((u32)data, mBaseAddress + mOffset, readSize);
gsys->copyWaitUntilDone();
mOffset += readSize;
}
void init( char* path, u32 address, int pending)
{
mPath = path;
mPending = pending;
mBaseAddress = address;
mOffset = 0;
}
u32 mBaseAddress;
u32 mOffset;
int mPending;
};
extern int glnWidth;
extern int glnHeight;
extern BOOL _nsPrint;
extern BOOL _cPrint;
extern BOOL _kPrint;
extern BOOL _nPrint;
extern BOOL _yPrint;
extern "C"{
typedef u8 GXBool;
typedef enum _GXCompare {
GX_NEVER = 0,
GX_LESS = 1,
GX_EQUAL = 2,
GX_LEQUAL = 3,
GX_GREATER = 4,
GX_NEQUAL = 5,
GX_GEQUAL = 6,
GX_ALWAYS = 7,
} GXCompare;
typedef GXCompare _SDK_GXCompare;
typedef enum _GXLogicOp {
GX_LO_CLEAR = 0,
GX_LO_AND = 1,
GX_LO_REVAND = 2,
GX_LO_COPY = 3,
GX_LO_INVAND = 4,
GX_LO_NOOP = 5,
GX_LO_XOR = 6,
GX_LO_OR = 7,
GX_LO_NOR = 8,
GX_LO_EQUIV = 9,
GX_LO_INV = 10,
GX_LO_REVOR = 11,
GX_LO_INVCOPY = 12,
GX_LO_INVOR = 13,
GX_LO_NAND = 14,
GX_LO_SET = 15,
} GXLogicOp;
typedef GXLogicOp _SDK_GXLogicOp;
typedef enum _GXPrimitive {
GX_POINTS = 0xB8,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xa0,
GX_QUADS = 0x80,
} GXPrimitive;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 3 * 0,
GX_PNMTX1 = 3 * 1,
GX_PNMTX2 = 3 * 2,
GX_PNMTX3 = 3 * 3,
GX_PNMTX4 = 3 * 4,
GX_PNMTX5 = 3 * 5,
GX_PNMTX6 = 3 * 6,
GX_PNMTX7 = 3 * 7,
GX_PNMTX8 = 3 * 8,
GX_PNMTX9 = 3 * 9,
} GXPosNrmMtx;
typedef enum _GXCommand {
GX_CMD_LOAD_INDX_A = 0x20,
GX_CMD_LOAD_INDX_B = 0x28,
GX_CMD_LOAD_INDX_C = 0x30,
GX_CMD_LOAD_INDX_D = 0x38,
GX_CMD_LOAD_BP_REG = 0x61,
GX_CMD_LOAD_CP_REG = 0x08,
GX_CMD_LOAD_XF_REG = 0x10,
GX_CMD_CALL_DL = 0x40,
GX_CMD_INVL_VC = 0x48,
GX_CMD_NOP = 0x00,
GX_CMD_DRAW_QUADS = 0x80,
GX_CMD_DRAW_TRIANGLES = 0x90,
GX_CMD_DRAW_TRIANGLE_STRIP = 0x98,
GX_CMD_DRAW_TRIANGLE_FAN = 0xA0,
GX_CMD_DRAW_LINES = 0xA8,
GX_CMD_DRAW_LINE_STRIP = 0xB0,
GX_CMD_DRAW_POINTS = 0xB8,
} GXCommand;
typedef enum _GXAttr {
GX_VA_PNMTXIDX = 0,
GX_VA_TEX0MTXIDX = 1,
GX_VA_TEX1MTXIDX = 2,
GX_VA_TEX2MTXIDX = 3,
GX_VA_TEX3MTXIDX = 4,
GX_VA_TEX4MTXIDX = 5,
GX_VA_TEX5MTXIDX = 6,
GX_VA_TEX6MTXIDX = 7,
GX_VA_TEX7MTXIDX = 8,
GX_VA_POS = 9,
GX_VA_NRM = 10,
GX_VA_CLR0 = 11,
GX_VA_CLR1 = 12,
GX_VA_TEX0 = 13,
GX_VA_TEX1 = 14,
GX_VA_TEX2 = 15,
GX_VA_TEX3 = 16,
GX_VA_TEX4 = 17,
GX_VA_TEX5 = 18,
GX_VA_TEX6 = 19,
GX_VA_TEX7 = 20,
GX_POS_MTX_ARRAY = 21,
GX_NRM_MTX_ARRAY = 22,
GX_TEX_MTX_ARRAY = 23,
GX_LIGHT_ARRAY = 24,
GX_VA_NBT = 25,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF,
} GXAttr;
typedef enum _GXAttrType {
GX_NONE = 0,
GX_DIRECT = 1,
GX_INDEX8 = 2,
GX_INDEX16 = 3,
} GXAttrType;
typedef enum _GXVtxFmt {
GX_VTXFMT0 = 0,
GX_VTXFMT1 = 1,
GX_VTXFMT2 = 2,
GX_VTXFMT3 = 3,
GX_VTXFMT4 = 4,
GX_VTXFMT5 = 5,
GX_VTXFMT6 = 6,
GX_VTXFMT7 = 7,
GX_MAX_VTXFMT,
} GXVtxFmt;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1,
GX_COMPCNT_NULL = 0,
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5,
GX_COMP_NULL = 0,
} GXCompType;
typedef enum _GXAnisotropy {
GX_ANISO_1 = 0,
GX_ANISO_2 = 1,
GX_ANISO_4 = 2,
GX_MAX_ANISOTROPY,
} GXAnisotropy;
typedef enum _GXLightID {
GX_LIGHT_NULL = 0x0,
GX_LIGHT0 = 0x1,
GX_LIGHT1 = 0x2,
GX_LIGHT2 = 0x4,
GX_LIGHT3 = 0x8,
GX_LIGHT4 = 0x10,
GX_LIGHT5 = 0x20,
GX_LIGHT6 = 0x40,
GX_LIGHT7 = 0x80,
GX_MAX_LIGHT = 0x100,
} GXLightID;
typedef enum _GXDiffuseFn {
GX_DF_NONE = 0,
GX_DF_SIGN = 1,
GX_DF_CLAMP = 2,
} GXDiffuseFn;
typedef enum _GXAttnFn {
GX_AF_SPEC = 0,
GX_AF_SPOT = 1,
GX_AF_NONE = 2,
} GXAttnFn;
typedef enum _GXSpotFn {
GX_SP_OFF = 0,
GX_SP_FLAT = 1,
GX_SP_COS = 2,
GX_SP_COS2 = 3,
GX_SP_SHARP = 4,
GX_SP_RING1 = 5,
GX_SP_RING2 = 6,
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF = 0,
GX_DA_GENTLE = 1,
GX_DA_MEDIUM = 2,
GX_DA_STEEP = 3,
} GXDistAttnFn;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_LINEAR = 2,
GX_FOG_EXPONENT = 4,
GX_FOG_EXPONENT2 = 5,
GX_FOG_REVERSEEXP = 6,
GX_FOG_REVERSEXP2 = 7
} GXFogType;
typedef GXFogType _SDK_GXFogType;
typedef enum _GXBlendMode {
GX_BM_NONE = 0,
GX_BM_BLEND = 1,
GX_BM_LOGIC = 2,
GX_BM_SUBTRACT = 3,
GX_MAX_BLENDMODE,
} GXBlendMode;
typedef GXBlendMode _SDK_GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO = 0,
GX_BL_ONE = 1,
GX_BL_SRCCOL = 2,
GX_BL_DSTCOL = GX_BL_SRCCOL,
GX_BL_INVSRCCOL = 3,
GX_BL_INVDSTCOL = GX_BL_INVSRCCOL,
GX_BL_SRCALPHA = 4,
GX_BL_INVSRCALPHA = 5,
GX_BL_DSTALPHA = 6,
GX_BL_INVDSTALPHA = 7,
} GXBlendFactor;
typedef GXBlendFactor _SDK_GXBlendFactor;
typedef enum _GXCullMode {
GX_CULL_NONE = 0,
GX_CULL_FRONT = 1,
GX_CULL_BACK = 2,
GX_CULL_ALL = 3,
GX_CULL_INVALID = 0xFF,
} GXCullMode;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1,
} GXClipMode;
typedef enum _GXCopyMode {
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3,
} GXCopyMode;
typedef enum _GXChannelID {
GX_COLOR0 = 0,
GX_COLOR1 = 1,
GX_ALPHA0 = 2,
GX_ALPHA1 = 3,
GX_COLOR0A0 = 4,
GX_COLOR1A1 = 5,
GX_COLOR_ZERO = 6,
GX_ALPHA_BUMP = 7,
GX_ALPHA_BUMPN = 8,
GX_COLOR_NULL = 0xFF,
} GXChannelID;
typedef enum _GXColorSrc {
GX_SRC_REG = 0,
GX_SRC_VTX = 1,
} GXColorSrc;
typedef enum _GXAlphaOp {
GX_AOP_AND = 0,
GX_AOP_OR = 1,
GX_AOP_XOR = 2,
GX_AOP_XNOR = 3,
GX_MAX_ALPHAOP,
} GXAlphaOp;
typedef enum _GXAlphaReadMode {
GX_READ_00 = 0,
GX_READ_FF = 1,
GX_READ_NONE = 2,
} GXAlphaReadMode;
typedef enum _GXGamma {
GX_GM_1_0 = 0,
GX_GM_1_7 = 1,
GX_GM_2_2 = 2,
} GXGamma;
typedef enum _GXTexCoordID {
GX_TEXCOORD0 = 0,
GX_TEXCOORD1 = 1,
GX_TEXCOORD2 = 2,
GX_TEXCOORD3 = 3,
GX_TEXCOORD4 = 4,
GX_TEXCOORD5 = 5,
GX_TEXCOORD6 = 6,
GX_TEXCOORD7 = 7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF,
} GXTexCoordID;
typedef enum _GXTexGenType {
GX_TG_MTX2X4 = 0,
GX_TG_MTX3X4 = 1,
GX_TG_BUMP0 = 2,
GX_TG_BUMP1 = 3,
GX_TG_BUMP2 = 4,
GX_TG_BUMP3 = 5,
GX_TG_BUMP4 = 6,
GX_TG_BUMP5 = 7,
GX_TG_BUMP6 = 8,
GX_TG_BUMP7 = 9,
GX_TG_SRTG = 10,
} GXTexGenType;
typedef enum _GXTexGenSrc {
GX_TG_POS = 0,
GX_TG_NRM = 1,
GX_TG_BINRM = 2,
GX_TG_TANGENT = 3,
GX_TG_TEX0 = 4,
GX_TG_TEX1 = 5,
GX_TG_TEX2 = 6,
GX_TG_TEX3 = 7,
GX_TG_TEX4 = 8,
GX_TG_TEX5 = 9,
GX_TG_TEX6 = 10,
GX_TG_TEX7 = 11,
GX_TG_TEXCOORD0 = 12,
GX_TG_TEXCOORD1 = 13,
GX_TG_TEXCOORD2 = 14,
GX_TG_TEXCOORD3 = 15,
GX_TG_TEXCOORD4 = 16,
GX_TG_TEXCOORD5 = 17,
GX_TG_TEXCOORD6 = 18,
GX_TG_COLOR0 = 19,
GX_TG_COLOR1 = 20,
} GXTexGenSrc;
typedef enum _GXTexMapID {
GX_TEXMAP0 = 0,
GX_TEXMAP1 = 1,
GX_TEXMAP2 = 2,
GX_TEXMAP3 = 3,
GX_TEXMAP4 = 4,
GX_TEXMAP5 = 5,
GX_TEXMAP6 = 6,
GX_TEXMAP7 = 7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100,
} GXTexMapID;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_TF_Z8 = 0x11,
GX_TF_Z16 = 0x13,
GX_TF_Z24X8 = 0x16,
GX_CTF_R4 = 0x20,
GX_CTF_RA4 = 0x22,
GX_CTF_RA8 = 0x23,
GX_CTF_YUVA8 = 0x26,
GX_CTF_A8 = 0x26,
GX_CTF_R8 = 0x27,
GX_CTF_G8 = 0x28,
GX_CTF_B8 = 0x29,
GX_CTF_RG8 = 0x2A,
GX_CTF_GB8 = 0x2B,
GX_CTF_Z4 = 0x30,
GX_CTF_Z8M = 0x39,
GX_CTF_Z8L = 0x3A,
GX_CTF_Z16L = 0x3C,
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xA,
} GXCITexFmt;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30 + 0 * 3,
GX_TEXMTX1 = 30 + 1 * 3,
GX_TEXMTX2 = 30 + 2 * 3,
GX_TEXMTX3 = 30 + 3 * 3,
GX_TEXMTX4 = 30 + 4 * 3,
GX_TEXMTX5 = 30 + 5 * 3,
GX_TEXMTX6 = 30 + 6 * 3,
GX_TEXMTX7 = 30 + 7 * 3,
GX_TEXMTX8 = 30 + 8 * 3,
GX_TEXMTX9 = 30 + 9 * 3,
GX_IDENTITY = 60,
GX_TEXMTX_NULL = 0,
} GXTexMtx;
typedef enum _GXTexMtxType {
GX_MTX3x4 = 0,
GX_MTX2x4 = 1,
} GXTexMtxType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64 + 0 * 3,
GX_PTTEXMTX1 = 64 + 1 * 3,
GX_PTTEXMTX2 = 64 + 2 * 3,
GX_PTTEXMTX3 = 64 + 3 * 3,
GX_PTTEXMTX4 = 64 + 4 * 3,
GX_PTTEXMTX5 = 64 + 5 * 3,
GX_PTTEXMTX6 = 64 + 6 * 3,
GX_PTTEXMTX7 = 64 + 7 * 3,
GX_PTTEXMTX8 = 64 + 8 * 3,
GX_PTTEXMTX9 = 64 + 9 * 3,
GX_PTTEXMTX10 = 64 + 10 * 3,
GX_PTTEXMTX11 = 64 + 11 * 3,
GX_PTTEXMTX12 = 64 + 12 * 3,
GX_PTTEXMTX13 = 64 + 13 * 3,
GX_PTTEXMTX14 = 64 + 14 * 3,
GX_PTTEXMTX15 = 64 + 15 * 3,
GX_PTTEXMTX16 = 64 + 16 * 3,
GX_PTTEXMTX17 = 64 + 17 * 3,
GX_PTTEXMTX18 = 64 + 18 * 3,
GX_PTTEXMTX19 = 64 + 19 * 3,
GX_PTIDENTITY = 125,
} GXPTTexMtx;
typedef enum _GXTexOffset {
GX_TO_ZERO = 0,
GX_TO_SIXTEENTH = 1,
GX_TO_EIGHTH = 2,
GX_TO_FOURTH = 3,
GX_TO_HALF = 4,
GX_TO_ONE = 5,
GX_MAX_TEXOFFSET,
} GXTexOffset;
typedef enum _GXTexWrapMode {
GX_CLAMP = 0,
GX_REPEAT = 1,
GX_MIRROR = 2,
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR = 0,
GX_LINEAR = 1,
GX_NEAR_MIP_NEAR = 2,
GX_LIN_MIP_NEAR = 3,
GX_NEAR_MIP_LIN = 4,
GX_LIN_MIP_LIN = 5,
} GXTexFilter;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K = 0,
GX_TEXCACHE_128K = 1,
GX_TEXCACHE_512K = 2,
GX_TEXCACHE_NONE = 3,
} GXTexCacheSize;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_MAX_TLUT = 16,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19,
GX_MAX_BIGTLUT = 4,
GX_MAX_TLUT_ALL = GX_MAX_TLUT + GX_MAX_BIGTLUT,
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8 = 0,
GX_TL_RGB565 = 1,
GX_TL_RGB5A3 = 2,
GX_MAX_TLUTFMT,
} GXTlutFmt;
typedef enum _GXTlutSize {
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024,
} GXTlutSize;
typedef enum _GXIndTexFormat {
GX_ITF_8 = 0,
GX_ITF_5 = 1,
GX_ITF_4 = 2,
GX_ITF_3 = 3,
GX_MAX_ITFORMAT,
} GXIndTexFormat;
typedef enum _GXIndTexStageID {
GX_IND_TEX_STAGE_0 = 0,
GX_IND_TEX_STAGE_1 = 1,
GX_IND_TEX_STAGE_2 = 2,
GX_IND_TEX_STAGE_3 = 3,
GX_IND_MAX_TEX_STAGE_ID,
} GXIndTexStageID;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF = 0,
GX_ITM_0 = 1,
GX_ITM_1 = 2,
GX_ITM_2 = 3,
GX_ITM_S0 = 5,
GX_ITM_S1 = 6,
GX_ITM_S2 = 7,
GX_ITM_T0 = 9,
GX_ITM_T1 = 10,
GX_ITM_T2 = 11,
} GXIndTexMtxID;
typedef enum _GXIndTexScale {
GX_ITS_1 = 0,
GX_ITS_2 = 1,
GX_ITS_4 = 2,
GX_ITS_8 = 3,
GX_ITS_16 = 4,
GX_ITS_32 = 5,
GX_ITS_64 = 6,
GX_ITS_128 = 7,
GX_ITS_256 = 8,
GX_MAX_ITSCALE,
} GXIndTexScale;
typedef enum _GXIndTexWrap {
GX_ITW_OFF = 0,
GX_ITW_256 = 1,
GX_ITW_128 = 2,
GX_ITW_64 = 3,
GX_ITW_32 = 4,
GX_ITW_16 = 5,
GX_ITW_0 = 6,
GX_MAX_ITWRAP,
} GXIndTexWrap;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE = 0,
GX_ITB_S = 1,
GX_ITB_T = 2,
GX_ITB_ST = 3,
GX_ITB_U = 4,
GX_ITB_SU = 5,
GX_ITB_TU = 6,
GX_ITB_STU = 7,
GX_MAX_ITBIAS,
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF = 0,
GX_ITBA_S = 1,
GX_ITBA_T = 2,
GX_ITBA_U = 3,
GX_MAX_ITBALPHA,
} GXIndTexAlphaSel;
typedef enum _GXTevStageID {
GX_TEVSTAGE0 = 0,
GX_TEVSTAGE1 = 1,
GX_TEVSTAGE2 = 2,
GX_TEVSTAGE3 = 3,
GX_TEVSTAGE4 = 4,
GX_TEVSTAGE5 = 5,
GX_TEVSTAGE6 = 6,
GX_TEVSTAGE7 = 7,
GX_TEVSTAGE8 = 8,
GX_TEVSTAGE9 = 9,
GX_TEVSTAGE10 = 10,
GX_TEVSTAGE11 = 11,
GX_TEVSTAGE12 = 12,
GX_TEVSTAGE13 = 13,
GX_TEVSTAGE14 = 14,
GX_TEVSTAGE15 = 15,
GX_MAXTEVSTAGE,
} GXTevStageID;
typedef enum _GXTevRegID {
GX_TEVPREV = 0,
GX_TEVREG0 = 1,
GX_TEVREG1 = 2,
GX_TEVREG2 = 3,
GX_MAX_TEVREG,
} GXTevRegID;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ
} GXTevOp;
typedef enum _GXTevMode {
GX_MODULATE = 0,
GX_DECAL = 1,
GX_BLEND = 2,
GX_REPLACE = 3,
GX_PASSCLR = 4,
} GXTevMode;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN = 1,
GX_CH_BLUE = 2,
GX_CH_ALPHA = 3,
} GXTevColorChan;
typedef enum _GXTevColorArg {
GX_CC_CPREV = 0,
GX_CC_APREV = 1,
GX_CC_C0 = 2,
GX_CC_C1 = 3,
GX_CC_C2 = 4,
GX_CC_A0 = 5,
GX_CC_A1 = 6,
GX_CC_A2 = 7,
GX_CC_TEXC = 8,
GX_CC_TEXA = 9,
GX_CC_RASC = 10,
GX_CC_RASA = 11,
GX_CC_ONE = 12,
GX_CC_HALF = 13,
GX_CC_KONST = 14,
GX_CC_ZERO = 15,
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV = 0,
GX_CA_A0 = 1,
GX_CA_A1 = 2,
GX_CA_A2 = 3,
GX_CA_TEXA = 4,
GX_CA_RASA = 5,
GX_CA_KONST = 6,
GX_CA_ZERO = 7,
} GXTevAlphaArg;
typedef enum _GXTevBias {
GX_TB_ZERO = 0,
GX_TB_ADDHALF = 1,
GX_TB_SUBHALF = 2,
GX_MAX_TEVBIAS,
} GXTevBias;
typedef enum _GXTevClampMode {
GX_TC_LINEAR = 0,
GX_TC_GE = 1,
GX_TC_EQ = 2,
GX_TC_LE = 3,
GX_MAX_TEVCLAMPMODE,
} GXTevClampMode;
typedef enum _GXTevScale {
GX_CS_SCALE_1 = 0,
GX_CS_SCALE_2 = 1,
GX_CS_SCALE_4 = 2,
GX_CS_DIVIDE_2 = 3,
GX_MAX_TEVSCALE,
} GXTevScale;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1 = 1,
GX_TEV_SWAP2 = 2,
GX_TEV_SWAP3 = 3,
GX_MAX_TEVSWAP,
} GXTevSwapSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1 = 1,
GX_KCOLOR2 = 2,
GX_KCOLOR3 = 3,
GX_MAX_KCOLOR,
} GXTevKColorID;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_1 = 0,
GX_TEV_KCSEL_7_8 = 1,
GX_TEV_KCSEL_3_4 = 2,
GX_TEV_KCSEL_5_8 = 3,
GX_TEV_KCSEL_1_2 = 4,
GX_TEV_KCSEL_3_8 = 5,
GX_TEV_KCSEL_1_4 = 6,
GX_TEV_KCSEL_1_8 = 7,
GX_TEV_KCSEL_K0 = 12,
GX_TEV_KCSEL_K1 = 13,
GX_TEV_KCSEL_K2 = 14,
GX_TEV_KCSEL_K3 = 15,
GX_TEV_KCSEL_K0_R = 16,
GX_TEV_KCSEL_K1_R = 17,
GX_TEV_KCSEL_K2_R = 18,
GX_TEV_KCSEL_K3_R = 19,
GX_TEV_KCSEL_K0_G = 20,
GX_TEV_KCSEL_K1_G = 21,
GX_TEV_KCSEL_K2_G = 22,
GX_TEV_KCSEL_K3_G = 23,
GX_TEV_KCSEL_K0_B = 24,
GX_TEV_KCSEL_K1_B = 25,
GX_TEV_KCSEL_K2_B = 26,
GX_TEV_KCSEL_K3_B = 27,
GX_TEV_KCSEL_K0_A = 28,
GX_TEV_KCSEL_K1_A = 29,
GX_TEV_KCSEL_K2_A = 30,
GX_TEV_KCSEL_K3_A = 31,
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_1 = 0,
GX_TEV_KASEL_7_8 = 1,
GX_TEV_KASEL_3_4 = 2,
GX_TEV_KASEL_5_8 = 3,
GX_TEV_KASEL_1_2 = 4,
GX_TEV_KASEL_3_8 = 5,
GX_TEV_KASEL_1_4 = 6,
GX_TEV_KASEL_1_8 = 7,
GX_TEV_KASEL_K0_R = 16,
GX_TEV_KASEL_K1_R = 17,
GX_TEV_KASEL_K2_R = 18,
GX_TEV_KASEL_K3_R = 19,
GX_TEV_KASEL_K0_G = 20,
GX_TEV_KASEL_K1_G = 21,
GX_TEV_KASEL_K2_G = 22,
GX_TEV_KASEL_K3_G = 23,
GX_TEV_KASEL_K0_B = 24,
GX_TEV_KASEL_K1_B = 25,
GX_TEV_KASEL_K2_B = 26,
GX_TEV_KASEL_K3_B = 27,
GX_TEV_KASEL_K0_A = 28,
GX_TEV_KASEL_K1_A = 29,
GX_TEV_KASEL_K2_A = 30,
GX_TEV_KASEL_K3_A = 31,
} GXTevKAlphaSel;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24 = 0,
GX_PF_RGBA6_Z24 = 1,
GX_PF_RGB565_Z16 = 2,
GX_PF_Z24 = 3,
GX_PF_Y8 = 4,
GX_PF_U8 = 5,
GX_PF_V8 = 6,
GX_PF_YUV420 = 7,
GX_MAX_PIXELFMT,
} GXPixelFmt;
typedef GXPixelFmt _SDK_GXPixelFmt;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR = 0,
GX_ZC_NEAR = 1,
GX_ZC_MID = 2,
GX_ZC_FAR = 3,
} GXZFmt16;
typedef GXZFmt16 _SDK_GXZFmt16;
typedef enum _GXProjectionType {
GX_PERSPECTIVE = 0,
GX_ORTHOGRAPHIC = 1,
} GXProjectionType;
typedef enum _GXFBClamp {
GX_CLAMP_NONE = 0,
GX_CLAMP_TOP = 1,
GX_CLAMP_BOTTOM = 2,
GX_CLAMP_BOTH = GX_CLAMP_TOP | GX_CLAMP_BOTTOM,
} GXFBClamp;
typedef enum _GXZTexOp {
GX_ZT_DISABLE = 0,
GX_ZT_ADD = 1,
GX_ZT_REPLACE = 2,
GX_MAX_ZTEXOP,
} GXZTexOp;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES = 0,
GX_PERF0_CLIP_VTX = 1,
GX_PERF0_CLIP_CLKS = 2,
GX_PERF0_XF_WAIT_IN = 3,
GX_PERF0_XF_WAIT_OUT = 4,
GX_PERF0_XF_XFRM_CLKS = 5,
GX_PERF0_XF_LIT_CLKS = 6,
GX_PERF0_XF_BOT_CLKS = 7,
GX_PERF0_XF_REGLD_CLKS = 8,
GX_PERF0_XF_REGRD_CLKS = 9,
GX_PERF0_CLIP_RATIO = 10,
GX_PERF0_TRIANGLES = 11,
GX_PERF0_TRIANGLES_CULLED = 12,
GX_PERF0_TRIANGLES_PASSED = 13,
GX_PERF0_TRIANGLES_SCISSORED = 14,
GX_PERF0_TRIANGLES_0TEX = 15,
GX_PERF0_TRIANGLES_1TEX = 16,
GX_PERF0_TRIANGLES_2TEX = 17,
GX_PERF0_TRIANGLES_3TEX = 18,
GX_PERF0_TRIANGLES_4TEX = 19,
GX_PERF0_TRIANGLES_5TEX = 20,
GX_PERF0_TRIANGLES_6TEX = 21,
GX_PERF0_TRIANGLES_7TEX = 22,
GX_PERF0_TRIANGLES_8TEX = 23,
GX_PERF0_TRIANGLES_0CLR = 24,
GX_PERF0_TRIANGLES_1CLR = 25,
GX_PERF0_TRIANGLES_2CLR = 26,
GX_PERF0_QUAD_0CVG = 27,
GX_PERF0_QUAD_NON0CVG = 28,
GX_PERF0_QUAD_1CVG = 29,
GX_PERF0_QUAD_2CVG = 30,
GX_PERF0_QUAD_3CVG = 31,
GX_PERF0_QUAD_4CVG = 32,
GX_PERF0_AVG_QUAD_CNT = 33,
GX_PERF0_CLOCKS = 34,
GX_PERF0_NONE = 35,
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS = 0,
GX_PERF1_TX_IDLE = 1,
GX_PERF1_TX_REGS = 2,
GX_PERF1_TX_MEMSTALL = 3,
GX_PERF1_TC_CHECK1_2 = 4,
GX_PERF1_TC_CHECK3_4 = 5,
GX_PERF1_TC_CHECK5_6 = 6,
GX_PERF1_TC_CHECK7_8 = 7,
GX_PERF1_TC_MISS = 8,
GX_PERF1_VC_ELEMQ_FULL = 9,
GX_PERF1_VC_MISSQ_FULL = 10,
GX_PERF1_VC_MEMREQ_FULL = 11,
GX_PERF1_VC_STATUS7 = 12,
GX_PERF1_VC_MISSREP_FULL = 13,
GX_PERF1_VC_STREAMBUF_LOW = 14,
GX_PERF1_VC_ALL_STALLS = 15,
GX_PERF1_VERTICES = 16,
GX_PERF1_FIFO_REQ = 17,
GX_PERF1_CALL_REQ = 18,
GX_PERF1_VC_MISS_REQ = 19,
GX_PERF1_CP_ALL_REQ = 20,
GX_PERF1_CLOCKS = 21,
GX_PERF1_NONE = 22,
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS = 0,
GX_VC_NRM = 1,
GX_VC_CLR0 = 2,
GX_VC_CLR1 = 3,
GX_VC_TEX0 = 4,
GX_VC_TEX1 = 5,
GX_VC_TEX2 = 6,
GX_VC_TEX3 = 7,
GX_VC_TEX4 = 8,
GX_VC_TEX5 = 9,
GX_VC_TEX6 = 10,
GX_VC_TEX7 = 11,
GX_VC_ALL = 15
} GXVCachePerf;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3,
} GXMiscToken;
typedef enum _GXDirtyFlag {
GX_DIRTY_SU_TEX = (1 << 0),
GX_DIRTY_BP_MASK = (1 << 1),
GX_DIRTY_GEN_MODE = (1 << 2),
GX_DIRTY_VCD = (1 << 3),
GX_DIRTY_VAT = (1 << 4),
GX_DIRTY_AMB_COLOR0 = (1 << 8),
GX_DIRTY_AMB_COLOR1 = (1 << 9),
GX_DIRTY_MAT_COLOR0 = (1 << 10),
GX_DIRTY_MAT_COLOR1 = (1 << 11),
GX_DIRTY_CHAN_COLOR0 = (1 << 12),
GX_DIRTY_CHAN_COLOR1 = (1 << 13),
GX_DIRTY_CHAN_ALPHA0 = (1 << 14),
GX_DIRTY_CHAN_ALPHA1 = (1 << 15),
GX_DIRTY_TEX0 = (1 << 16),
GX_DIRTY_TEX1 = (1 << 17),
GX_DIRTY_TEX2 = (1 << 18),
GX_DIRTY_TEX3 = (1 << 19),
GX_DIRTY_TEX4 = (1 << 20),
GX_DIRTY_TEX5 = (1 << 21),
GX_DIRTY_TEX6 = (1 << 22),
GX_DIRTY_TEX7 = (1 << 23),
GX_DIRTY_NUM_COLORS = (1 << 24),
GX_DIRTY_NUM_TEX = (1 << 25),
GX_DIRTY_MTX_IDX = (1 << 26),
GX_DIRTY_PROJECTION = (1 << 27),
GX_DIRTY_VIEWPORT = (1 << 28),
GX_AMB_MAT_MASK = GX_DIRTY_AMB_COLOR0 | GX_DIRTY_AMB_COLOR1 | GX_DIRTY_MAT_COLOR0 | GX_DIRTY_MAT_COLOR1,
GX_LIGHT_CHAN_MASK
= GX_DIRTY_CHAN_COLOR0 | GX_DIRTY_CHAN_COLOR1 | GX_DIRTY_CHAN_ALPHA0 | GX_DIRTY_CHAN_ALPHA1 | GX_DIRTY_NUM_COLORS,
GX_TEX_GEN_MASK = 0x2FF0000,
} GXDirtyFlag;
typedef enum _GXFifoCmd {
GX_FIFO_CMD_NOOP = 0x00,
GX_FIFO_CMD_LOAD_BP_REG = 0x61,
GX_FIFO_CMD_LOAD_CP_REG = 0x08,
GX_FIFO_CMD_LOAD_XF_REG = 0x10,
GX_FIFO_CMD_LOAD_INDX_A = 0x20,
GX_FIFO_CMD_LOAD_INDX_B = 0x28,
GX_FIFO_CMD_LOAD_INDX_C = 0x30,
GX_FIFO_CMD_LOAD_INDX_D = 0x38,
GX_FIFO_CMD_CALL_DL = 0x40,
GX_FIFO_CMD_INVAL_VTX = 0x48,
} GXFifoCmd;
typedef enum _GXXfTexReg {
GX_XF_TEX_PROJ_ST = 0,
GX_XF_TEX_PROJ_STQ = 1,
GX_XF_TEX_FORM_AB11 = 0,
GX_XF_TEX_FORM_ABC1 = 1,
} GXXfTexReg;
typedef enum _GXXfTexGen {
GX_XF_TG_REGULAR = 0,
GX_XF_TG_BUMP = 1,
GX_XF_TG_CLR0 = 2,
GX_XF_TG_CLR1 = 3,
} GXXfTexGen;
typedef enum _GXXfMem {
GX_XF_MEM_POSMTX = 0x000,
GX_XF_MEM_NRMMTX = 0x400,
GX_XF_MEM_DUALTEXMTX = 0x500,
GX_XF_MEM_LIGHTOBJ = 0x600,
} GXXfMem;
typedef enum _GXBPRegs {
GX_BP_REG_GENMODE = 0x0,
GX_BP_REG_DISPCOPYFILTER0 = 0x1,
GX_BP_REG_DISPCOPYFILTER1 = 0x2,
GX_BP_REG_DISPCOPYFILTER2 = 0x3,
GX_BP_REG_DISPCOPYFILTER3 = 0x4,
GX_BP_REG_INDMTX0A = 0x6,
GX_BP_REG_INDMTX0B = 0x7,
GX_BP_REG_INDMTX0C = 0x8,
GX_BP_REG_INDMTX1A = 0x9,
GX_BP_REG_INDMTX1B = 0xA,
GX_BP_REG_INDMTX1C = 0xB,
GX_BP_REG_INDMTX2A = 0xC,
GX_BP_REG_INDMTX2B = 0xD,
GX_BP_REG_INDMTX2C = 0xE,
GX_BP_REG_INDIMASK = 0xF,
GX_BP_REG_INDTEVSTAGE0 = 0x10,
GX_BP_REG_INDTEVSTAGE1 = 0x11,
GX_BP_REG_INDTEVSTAGE2 = 0x12,
GX_BP_REG_INDTEVSTAGE3 = 0x13,
GX_BP_REG_INDTEVSTAGE4 = 0x14,
GX_BP_REG_INDTEVSTAGE5 = 0x15,
GX_BP_REG_INDTEVSTAGE6 = 0x16,
GX_BP_REG_INDTEVSTAGE7 = 0x17,
GX_BP_REG_INDTEVSTAGE8 = 0x18,
GX_BP_REG_INDTEVSTAGE9 = 0x19,
GX_BP_REG_INDTEVSTAGE10 = 0x1A,
GX_BP_REG_INDTEVSTAGE11 = 0x1B,
GX_BP_REG_INDTEVSTAGE12 = 0x1C,
GX_BP_REG_INDTEVSTAGE13 = 0x1D,
GX_BP_REG_INDTEVSTAGE14 = 0x1E,
GX_BP_REG_INDTEVSTAGE15 = 0x1F,
GX_BP_REG_SCISSORTL = 0x20,
GX_BP_REG_SCISSORBR = 0x21,
GX_BP_REG_LINEPTWIDTH = 0x22,
GX_BP_REG_PERF0TRI = 0x23,
GX_BP_REG_PERF0QUAD = 0x24,
GX_BP_REG_RAS1_SS0 = 0x25,
GX_BP_REG_RAS1_SS1 = 0x26,
GX_BP_REG_RAS1_IREF = 0x27,
GX_BP_REG_RAS1_TREF0 = 0x28,
GX_BP_REG_RAS1_TREF1 = 0x29,
GX_BP_REG_RAS1_TREF2 = 0x2A,
GX_BP_REG_RAS1_TREF3 = 0x2B,
GX_BP_REG_RAS1_TREF4 = 0x2C,
GX_BP_REG_RAS1_TREF5 = 0x2D,
GX_BP_REG_RAS1_TREF6 = 0x2E,
GX_BP_REG_RAS1_TREF7 = 0x2F,
GX_BP_REG_SU_SSIZE0 = 0x30,
GX_BP_REG_SU_TSIZE0 = 0x31,
GX_BP_REG_SU_SSIZE1 = 0x32,
GX_BP_REG_SU_TSIZE1 = 0x33,
GX_BP_REG_SU_SSIZE2 = 0x34,
GX_BP_REG_SU_TSIZE2 = 0x35,
GX_BP_REG_SU_SSIZE3 = 0x36,
GX_BP_REG_SU_TSIZE3 = 0x37,
GX_BP_REG_SU_SSIZE4 = 0x38,
GX_BP_REG_SU_TSIZE4 = 0x39,
GX_BP_REG_SU_SSIZE5 = 0x3A,
GX_BP_REG_SU_TSIZE5 = 0x3B,
GX_BP_REG_SU_SSIZE6 = 0x3C,
GX_BP_REG_SU_TSIZE6 = 0x3D,
GX_BP_REG_SU_SSIZE7 = 0x3E,
GX_BP_REG_SU_TSIZE7 = 0x3F,
GX_BP_REG_ZMODE = 0x40,
GX_BP_REG_BLENDMODE = 0x41,
GX_BP_REG_DSTALPHA = 0x42,
GX_BP_REG_ZCONTROL = 0x43,
GX_BP_REG_FIELDMASK = 0x44,
GX_BP_REG_DRAWDONE = 0x45,
GX_BP_REG_PETOKEN = 0x47,
GX_BP_REG_PETOKENINT = 0x48,
GX_BP_REG_TEXCOPYSRCXY = 0x49,
GX_BP_REG_TEXCOPYSRCWH = 0x4A,
GX_BP_REG_TEXCOPYDST = 0x4B,
GX_BP_REG_DISPCOPYSTRIDE = 0x4D,
GX_BP_REG_DISPCOPYSCALEY = 0x4E,
GX_BP_REG_COPYCLEARAR = 0x4F,
GX_BP_REG_COPYCLEARGB = 0x50,
GX_BP_REG_COPYCLEARZ = 0x51,
GX_BP_REG_COPYFILTER0 = 0x53,
GX_BP_REG_COPYFILTER1 = 0x54,
GX_BP_REG_BOUNDINGBOX0 = 0x55,
GX_BP_REG_BOUNDINGBOX1 = 0x56,
GX_BP_REG_SCISSOROFFSET = 0x59,
GX_BP_REG_TMEMPRELOADADDR = 0x60,
GX_BP_REG_TMEMPRELOADEVEN = 0x61,
GX_BP_REG_TMEMPRELOADODD = 0x62,
GX_BP_REG_TMEMPRELOADMODE = 0x63,
GX_BP_REG_TMEMTLUTSRC = 0x64,
GX_BP_REG_TMEMTLUTDST = 0x65,
GX_BP_REG_TMEMTEXINVALIDATE = 0x66,
GX_BP_REG_PERF1 = 0x67,
GX_BP_REG_FIELDMODE = 0x68,
GX_BP_REG_SETMODE0_TEX0 = 0x80,
GX_BP_REG_SETMODE0_TEX1 = 0x81,
GX_BP_REG_SETMODE0_TEX2 = 0x82,
GX_BP_REG_SETMODE0_TEX3 = 0x83,
GX_BP_REG_SETMODE1_TEX0 = 0x84,
GX_BP_REG_SETMODE1_TEX1 = 0x85,
GX_BP_REG_SETMODE1_TEX2 = 0x86,
GX_BP_REG_SETMODE1_TEX3 = 0x87,
GX_BP_REG_SETIMAGE0_TEX0 = 0x88,
GX_BP_REG_SETIMAGE0_TEX1 = 0x89,
GX_BP_REG_SETIMAGE0_TEX2 = 0x8A,
GX_BP_REG_SETIMAGE0_TEX3 = 0x8B,
GX_BP_REG_SETIMAGE1_TEX0 = 0x8C,
GX_BP_REG_SETIMAGE1_TEX1 = 0x8D,
GX_BP_REG_SETIMAGE1_TEX2 = 0x8E,
GX_BP_REG_SETIMAGE1_TEX3 = 0x8F,
GX_BP_REG_SETIMAGE2_TEX0 = 0x90,
GX_BP_REG_SETIMAGE2_TEX1 = 0x91,
GX_BP_REG_SETIMAGE2_TEX2 = 0x92,
GX_BP_REG_SETIMAGE2_TEX3 = 0x93,
GX_BP_REG_SETIMAGE3_TEX0 = 0x94,
GX_BP_REG_SETIMAGE3_TEX1 = 0x95,
GX_BP_REG_SETIMAGE3_TEX2 = 0x96,
GX_BP_REG_SETIMAGE3_TEX3 = 0x97,
GX_BP_REG_SETTLUT_TEX0 = 0x98,
GX_BP_REG_SETTLUT_TEX1 = 0x99,
GX_BP_REG_SETTLUT_TEX2 = 0x9A,
GX_BP_REG_SETTLUT_TEX3 = 0x9B,
GX_BP_REG_SETMODE0_TEX4 = 0xA0,
GX_BP_REG_SETMODE0_TEX5 = 0xA1,
GX_BP_REG_SETMODE0_TEX6 = 0xA2,
GX_BP_REG_SETMODE0_TEX7 = 0xA3,
GX_BP_REG_SETMODE1_TEX4 = 0xA4,
GX_BP_REG_SETMODE1_TEX5 = 0xA5,
GX_BP_REG_SETMODE1_TEX6 = 0xA6,
GX_BP_REG_SETMODE1_TEX7 = 0xA7,
GX_BP_REG_SETIMAGE0_TEX4 = 0xA8,
GX_BP_REG_SETIMAGE0_TEX5 = 0xA9,
GX_BP_REG_SETIMAGE0_TEX6 = 0xAA,
GX_BP_REG_SETIMAGE0_TEX7 = 0xAB,
GX_BP_REG_SETIMAGE1_TEX4 = 0xAC,
GX_BP_REG_SETIMAGE1_TEX5 = 0xAD,
GX_BP_REG_SETIMAGE1_TEX6 = 0xAE,
GX_BP_REG_SETIMAGE1_TEX7 = 0xAF,
GX_BP_REG_SETIMAGE2_TEX4 = 0xB0,
GX_BP_REG_SETIMAGE2_TEX5 = 0xB1,
GX_BP_REG_SETIMAGE2_TEX6 = 0xB2,
GX_BP_REG_SETIMAGE2_TEX7 = 0xB3,
GX_BP_REG_SETIMAGE3_TEX4 = 0xB4,
GX_BP_REG_SETIMAGE3_TEX5 = 0xB5,
GX_BP_REG_SETIMAGE3_TEX6 = 0xB6,
GX_BP_REG_SETIMAGE3_TEX7 = 0xB7,
GX_BP_REG_SETTLUT_TEX4 = 0xB8,
GX_BP_REG_SETTLUT_TEX5 = 0xB9,
GX_BP_REG_SETTLUT_TEX6 = 0xBA,
GX_BP_REG_SETTLUT_TEX7 = 0xBB,
GX_BP_REG_TEVCOLORCOMBINER0 = 0xC0,
GX_BP_REG_TEVALPHACOMBINER0 = 0xC1,
GX_BP_REG_TEVCOLORCOMBINER1 = 0xC2,
GX_BP_REG_TEVALPHACOMBINER1 = 0xC3,
GX_BP_REG_TEVCOLORCOMBINER2 = 0xC4,
GX_BP_REG_TEVALPHACOMBINER2 = 0xC5,
GX_BP_REG_TEVCOLORCOMBINER3 = 0xC6,
GX_BP_REG_TEVALPHACOMBINER3 = 0xC7,
GX_BP_REG_TEVCOLORCOMBINER4 = 0xC8,
GX_BP_REG_TEVALPHACOMBINER4 = 0xC9,
GX_BP_REG_TEVCOLORCOMBINER5 = 0xCA,
GX_BP_REG_TEVALPHACOMBINER5 = 0xCB,
GX_BP_REG_TEVCOLORCOMBINER6 = 0xCC,
GX_BP_REG_TEVALPHACOMBINER6 = 0xCD,
GX_BP_REG_TEVCOLORCOMBINER7 = 0xCE,
GX_BP_REG_TEVALPHACOMBINER7 = 0xCF,
GX_BP_REG_TEVCOLORCOMBINER8 = 0xD0,
GX_BP_REG_TEVALPHACOMBINER8 = 0xD1,
GX_BP_REG_TEVCOLORCOMBINER9 = 0xD2,
GX_BP_REG_TEVALPHACOMBINER9 = 0xD3,
GX_BP_REG_TEVCOLORCOMBINER10 = 0xD4,
GX_BP_REG_TEVALPHACOMBINER10 = 0xD5,
GX_BP_REG_TEVCOLORCOMBINER11 = 0xD6,
GX_BP_REG_TEVALPHACOMBINER11 = 0xD7,
GX_BP_REG_TEVCOLORCOMBINER12 = 0xD8,
GX_BP_REG_TEVALPHACOMBINER12 = 0xD9,
GX_BP_REG_TEVCOLORCOMBINER13 = 0xDA,
GX_BP_REG_TEVALPHACOMBINER13 = 0xDB,
GX_BP_REG_TEVCOLORCOMBINER14 = 0xDC,
GX_BP_REG_TEVALPHACOMBINER14 = 0xDD,
GX_BP_REG_TEVCOLORCOMBINER15 = 0xDE,
GX_BP_REG_TEVALPHACOMBINER15 = 0xDF,
GX_BP_REG_TEVREG0LO = 0xE0,
GX_BP_REG_TEVREG0HI = 0xE1,
GX_BP_REG_TEVREG1LO = 0xE2,
GX_BP_REG_TEVREG1HI = 0xE3,
GX_BP_REG_TEVREG2LO = 0xE4,
GX_BP_REG_TEVREG2HI = 0xE5,
GX_BP_REG_TEVREG3LO = 0xE6,
GX_BP_REG_TEVREG3HI = 0xE7,
GX_BP_REG_FOGRANGE = 0xE8,
GX_BP_REG_FOGRANGEK0 = 0xE9,
GX_BP_REG_FOGRANGEK1 = 0xEA,
GX_BP_REG_FOGRANGEK2 = 0xEB,
GX_BP_REG_FOGRANGEK3 = 0xEC,
GX_BP_REG_FOGRANGEK4 = 0xED,
GX_BP_REG_FOGPARAM0 = 0xEE,
GX_BP_REG_FOGPARAM1 = 0xEF,
GX_BP_REG_FOGPARAM2 = 0xF0,
GX_BP_REG_FOGPARAM3 = 0xF1,
GX_BP_REG_FOGCOLOR = 0xF2,
GX_BP_REG_ALPHACOMPARE = 0xF3,
GX_BP_REG_ZTEXTURE0 = 0xF4,
GX_BP_REG_ZTEXTURE1 = 0xF5,
GX_BP_REG_TEVKSEL0 = 0xF6,
GX_BP_REG_TEVKSEL1 = 0xF7,
GX_BP_REG_TEVKSEL2 = 0xF8,
GX_BP_REG_TEVKSEL3 = 0xF9,
GX_BP_REG_TEVKSEL4 = 0xFA,
GX_BP_REG_TEVKSEL5 = 0xFB,
GX_BP_REG_TEVKSEL6 = 0xFC,
GX_BP_REG_TEVKSEL7 = 0xFD,
GX_BP_REG_SSMASK = 0xFE,
} GXBPRegs;
typedef enum _GXCPRegs {
GX_CP_REG_MTXIDXA = 0x30,
GX_CP_REG_MTXIDXB = 0x40,
GX_CP_REG_VCD_LO = 0x50,
GX_CP_REG_VCD_HI = 0x60,
GX_CP_REG_VAT_GRP0 = 0x70,
GX_CP_REG_VAT_GRP1 = 0x80,
GX_CP_REG_VAT_GRP2 = 0x90,
GX_CP_REG_ARRAYBASE = 0xA0,
GX_CP_REG_ARRAYSTRIDE = 0xB0,
} GXCPRegs;
typedef enum _GXXFRegs {
GX_XF_REG_ERROR = 0x1000,
GX_XF_REG_DIAGNOSTICS = 0x1001,
GX_XF_REG_STATE0 = 0x1002,
GX_XF_REG_STATE1 = 0x1003,
GX_XF_REG_CLOCK = 0x1004,
GX_XF_REG_CLIPDISABLE = 0x1005,
GX_XF_REG_PERF0 = 0x1006,
GX_XF_REG_PERF1 = 0x1007,
GX_XF_REG_INVERTEXSPEC = 0x1008,
GX_XF_REG_NUMCOLORS = 0x1009,
GX_XF_REG_AMBIENT0 = 0x100A,
GX_XF_REG_AMBIENT1 = 0x100B,
GX_XF_REG_MATERIAL0 = 0x100C,
GX_XF_REG_MATERIAL1 = 0x100D,
GX_XF_REG_COLOR0CNTRL = 0x100E,
GX_XF_REG_COLOR1CNTRL = 0x100F,
GX_XF_REG_ALPHA0CNTRL = 0x1010,
GX_XF_REG_ALPHA1CNTRL = 0x1011,
GX_XF_REG_DUALTEXTRAN = 0x1012,
GX_XF_REG_MATRIXINDEX0 = 0x1018,
GX_XF_REG_MATRIXINDEX1 = 0x1019,
GX_XF_REG_SCALEX = 0x101A,
GX_XF_REG_SCALEY = 0x101B,
GX_XF_REG_SCALEZ = 0x101C,
GX_XF_REG_OFFSETX = 0x101D,
GX_XF_REG_OFFSETY = 0x101E,
GX_XF_REG_OFFSETZ = 0x101F,
GX_XF_REG_PROJECTIONA = 0x1020,
GX_XF_REG_PROJECTIONB = 0x1021,
GX_XF_REG_PROJECTIONC = 0x1022,
GX_XF_REG_PROJECTIOND = 0x1023,
GX_XF_REG_PROJECTIONE = 0x1024,
GX_XF_REG_PROJECTIONF = 0x1025,
GX_XF_REG_PROJECTORTHO = 0x1026,
GX_XF_REG_NUMTEX = 0x103F,
GX_XF_REG_TEX0 = 0x1040,
GX_XF_REG_TEX1 = 0x1041,
GX_XF_REG_TEX2 = 0x1042,
GX_XF_REG_TEX3 = 0x1043,
GX_XF_REG_TEX4 = 0x1044,
GX_XF_REG_TEX5 = 0x1045,
GX_XF_REG_TEX6 = 0x1046,
GX_XF_REG_TEX7 = 0x1047,
GX_XF_REG_DUALTEX0 = 0x1050,
GX_XF_REG_DUALTEX1 = 0x1051,
GX_XF_REG_DUALTEX2 = 0x1052,
GX_XF_REG_DUALTEX3 = 0x1053,
GX_XF_REG_DUALTEX4 = 0x1054,
GX_XF_REG_DUALTEX5 = 0x1055,
GX_XF_REG_DUALTEX6 = 0x1056,
GX_XF_REG_DUALTEX7 = 0x1057,
} GXXFRegs;
typedef enum _GXBPGenMode {
GX_BP_GENMODE_NUMTEX_ST = 28,
GX_BP_GENMODE_NUMTEX_END = 31,
GX_BP_GENMODE_NUMCOLORS_ST = 25,
GX_BP_GENMODE_NUMCOLORS_END = 27,
GX_BP_GENMODE_MULTISAMPLE_ST = 22,
GX_BP_GENMODE_MULTISAMPLE_END = 22,
GX_BP_GENMODE_CULLMODE_ST = 16,
GX_BP_GENMODE_CULLMODE_END = 17,
GX_BP_GENMODE_NUMINDSTAGES_ST = 13,
GX_BP_GENMODE_NUMINDSTAGES_END = 15,
GX_BP_GENMODE_COPLANAR_ST = 12,
GX_BP_GENMODE_COPLANAR_END = 12,
} GXBPGenMode;
typedef enum _GXBPIndMtx {
GX_BP_INDMTX_M00_ST = 21,
GX_BP_INDMTX_M00_END = 31,
GX_BP_INDMTX_M10_ST = 10,
GX_BP_INDMTX_M10_END = 20,
GX_BP_INDMTX_EXP_ST = 8,
GX_BP_INDMTX_EXP_END = 9,
} GXBPIndMtx;
typedef enum _GXBPIndIMask {
GX_BP_INDIMASK_ST = 24,
GX_BP_INDIMASK_END = 31,
} GXBPIndIMask;
typedef enum _GXBPIndTevStage {
GX_BP_INDTEV_STAGE_ST = 30,
GX_BP_INDTEV_STAGE_END = 31,
GX_BP_INDTEV_FMT_ST = 28,
GX_BP_INDTEV_FMT_END = 29,
GX_BP_INDTEV_BIAS_ST = 25,
GX_BP_INDTEV_BIAS_END = 27,
GX_BP_INDTEV_ALPHA_ST = 23,
GX_BP_INDTEV_ALPHA_END = 24,
GX_BP_INDTEV_MTX_ST = 19,
GX_BP_INDTEV_MTX_END = 22,
GX_BP_INDTEV_WRAPS_ST = 16,
GX_BP_INDTEV_WRAPS_END = 18,
GX_BP_INDTEV_WRAPT_ST = 13,
GX_BP_INDTEV_WRAPT_END = 15,
GX_BP_INDTEV_UNMODTEXCOORD_ST = 12,
GX_BP_INDTEV_UNMODTEXCOORD_END = 12,
GX_BP_INDTEV_ADDPREV_ST = 11,
GX_BP_INDTEV_ADDPREV_END = 11,
} GXBPIndTevStage;
typedef enum _GXBPScissorTL {
GX_BP_SCISSORTL_TOP_ST = 21,
GX_BP_SCISSORTL_TOP_END = 31,
GX_BP_SCISSORTL_LEFT_ST = 9,
GX_BP_SCISSORTL_LEFT_END = 19,
} GXBPScissorTL;
typedef enum _GXBPScissorBR {
GX_BP_SCISSORBR_BOT_ST = 21,
GX_BP_SCISSORBR_BOT_END = 31,
GX_BP_SCISSORBR_RIGHT_ST = 9,
GX_BP_SCISSORBR_RIGHT_END = 19,
} GXBPScissorBR;
typedef enum _GXBPLinePtWidth {
GX_BP_LINEPTWIDTH_LINESZ_ST = 24,
GX_BP_LINEPTWIDTH_LINESZ_END = 31,
GX_BP_LINEPTWIDTH_POINTSZ_ST = 16,
GX_BP_LINEPTWIDTH_POINTSZ_END = 23,
GX_BP_LINEPTWIDTH_LINEOFS_ST = 13,
GX_BP_LINEPTWIDTH_LINEOFS_END = 15,
GX_BP_LINEPTWIDTH_POINTOFS_ST = 10,
GX_BP_LINEPTWIDTH_POINTOFS_END = 12,
GX_BP_LINEPTWIDTH_ADJUST_ST = 9,
GX_BP_LINEPTWIDTH_ADJUST_END = 9,
} GXBPLinePtWidth;
typedef enum _GXBPRas1SS0 {
GX_BP_RAS1_SS0_S0_ST = 28,
GX_BP_RAS1_SS0_S0_END = 31,
GX_BP_RAS1_SS0_T0_ST = 24,
GX_BP_RAS1_SS0_T0_END = 27,
GX_BP_RAS1_SS0_S1_ST = 20,
GX_BP_RAS1_SS0_S1_END = 23,
GX_BP_RAS1_SS0_T1_ST = 16,
GX_BP_RAS1_SS0_T1_END = 19,
} GXBPRas1SS0;
typedef enum _GXBPRas1SS1 {
GX_BP_RAS1_SS1_S2_ST = 28,
GX_BP_RAS1_SS1_S2_END = 31,
GX_BP_RAS1_SS1_T2_ST = 24,
GX_BP_RAS1_SS1_T2_END = 27,
GX_BP_RAS1_SS1_S3_ST = 20,
GX_BP_RAS1_SS1_S3_END = 23,
GX_BP_RAS1_SS1_T3_ST = 16,
GX_BP_RAS1_SS1_T3_END = 19,
} GXBPRas1SS1;
typedef enum _GXBPRasIRef {
GX_BP_RAS1_IREF_MAP0_ST = 29,
GX_BP_RAS1_IREF_MAP0_END = 31,
GX_BP_RAS1_IREF_TXC0_ST = 26,
GX_BP_RAS1_IREF_TXC0_END = 28,
GX_BP_RAS1_IREF_MAP1_ST = 23,
GX_BP_RAS1_IREF_MAP1_END = 25,
GX_BP_RAS1_IREF_TXC1_ST = 20,
GX_BP_RAS1_IREF_TXC1_END = 22,
GX_BP_RAS1_IREF_MAP2_ST = 17,
GX_BP_RAS1_IREF_MAP2_END = 19,
GX_BP_RAS1_IREF_TXC2_ST = 14,
GX_BP_RAS1_IREF_TXC2_END = 16,
GX_BP_RAS1_IREF_MAP3_ST = 11,
GX_BP_RAS1_IREF_MAP3_END = 13,
GX_BP_RAS1_IREF_TXC3_ST = 8,
GX_BP_RAS1_IREF_TXC3_END = 10,
} GXBPRasIRef;
typedef enum _GXBPSUSSize {
GX_BP_SU_SSIZE_USELINEOFS_ST = 13,
GX_BP_SU_SSIZE_USELINEOFS_END = 13,
GX_BP_SU_SSIZE_USEPTOFS_ST = 12,
GX_BP_SU_SSIZE_USEPTOFS_END = 12,
} GXBPSUSSize;
typedef enum _GXBPZMode {
GX_BP_ZMODE_TEST_ENABLE_ST = 31,
GX_BP_ZMODE_TEST_ENABLE_END = 31,
GX_BP_ZMODE_COMPARE_ST = 28,
GX_BP_ZMODE_COMPARE_END = 30,
GX_BP_ZMODE_UPDATE_ENABLE_ST = 27,
GX_BP_ZMODE_UPDATE_ENABLE_END = 27,
} GXBPZMode;
typedef enum _GXBPBlendMode {
GX_BP_BLENDMODE_ENABLE_ST = 31,
GX_BP_BLENDMODE_ENABLE_END = 31,
GX_BP_BLENDMODE_LOGIC_OP_ST = 30,
GX_BP_BLENDMODE_LOGIC_OP_END = 30,
GX_BP_BLENDMODE_DITHER_ST = 29,
GX_BP_BLENDMODE_DITHER_END = 29,
GX_BP_BLENDMODE_COLOR_UPDATE_ST = 28,
GX_BP_BLENDMODE_COLOR_UPDATE_END = 28,
GX_BP_BLENDMODE_ALPHA_UPDATE_ST = 27,
GX_BP_BLENDMODE_ALPHA_UPDATE_END = 27,
GX_BP_BLENDMODE_DSTFACTOR_ST = 24,
GX_BP_BLENDMODE_DSTFACTOR_END = 26,
GX_BP_BLENDMODE_SRCFACTOR_ST = 21,
GX_BP_BLENDMODE_SRCFACTOR_END = 23,
GX_BP_BLENDMODE_SUBTRACT_ST = 20,
GX_BP_BLENDMODE_SUBTRACT_END = 20,
GX_BP_BLENDMODE_LOGICMODE_ST = 16,
GX_BP_BLENDMODE_LOGICMODE_END = 19,
} GXBPBlendMode;
typedef enum _GXBPDstAlpha {
GX_BP_DSTALPHA_ALPHA_ST = 24,
GX_BP_DSTALPHA_ALPHA_END = 31,
GX_BP_DSTALPHA_ENABLE_ST = 23,
GX_BP_DSTALPHA_ENABLE_END = 23,
GX_BP_DSTALPHA_YUV_FMT_ST = 21,
GX_BP_DSTALPHA_YUV_FMT_END = 22,
} GXBPDstAlpha;
typedef enum _GXBPZControl {
GX_BP_ZCONTROL_PIXEL_FMT_ST = 29,
GX_BP_ZCONTROL_PIXEL_FMT_END = 31,
GX_BP_ZCONTROL_Z_FMT_ST = 26,
GX_BP_ZCONTROL_Z_FMT_END = 28,
GX_BP_ZCONTROL_BEFORE_TEX_ST = 25,
GX_BP_ZCONTROL_BEFORE_TEX_END = 25,
} GXBPZControl;
typedef enum _GXBPFieldMask {
GX_BP_FIELDMASK_ODD_ST = 31,
GX_BP_FIELDMASK_ODD_END = 31,
GX_BP_FIELDMASK_EVEN_ST = 30,
GX_BP_FIELDMASK_EVEN_END = 30,
} GXBPFieldMask;
typedef enum _GXBPScissorOffset {
GX_BP_SCISSOROFS_OX_ST = 22,
GX_BP_SCISSOROFS_OX_END = 31,
GX_BP_SCISSOROFS_OY_ST = 12,
GX_BP_SCISSOROFS_OY_END = 21,
} GXBPScissorOffset;
typedef enum _GXBPFieldMode {
GX_BP_FIELDMODE_TEX_LOD_ST = 31,
GX_BP_FIELDMODE_TEX_LOD_END = 31,
} GXBPFieldMode;
typedef enum _GXBPFogRange {
GX_BP_FOGRANGE_CENTER_ST = 22,
GX_BP_FOGRANGE_CENTER_END = 31,
GX_BP_FOGRANGE_ENABLED_ST = 21,
GX_BP_FOGRANGE_ENABLED_END = 21,
} GXBPFogRange;
typedef enum _GXBPFogRangeK {
GX_BP_FOGRANGEK_HI_ST = 20,
GX_BP_FOGRANGEK_HI_END = 31,
GX_BP_FOGRANGEK_LO_ST = 8,
GX_BP_FOGRANGEK_LO_END = 19,
} GXBPFogRangeK;
typedef enum _GXBPFogParam0 {
GX_BP_FOGPARAM0_A_MANT_ST = 21,
GX_BP_FOGPARAM0_A_MANT_END = 31,
GX_BP_FOGPARAM0_A_EXP_ST = 13,
GX_BP_FOGPARAM0_A_EXP_END = 20,
GX_BP_FOGPARAM0_A_SIGN_ST = 12,
GX_BP_FOGPARAM0_A_SIGN_END = 12,
} GXBPFogParam0;
typedef enum _GXBPFogParam1 {
GX_BP_FOGPARAM1_B_MAG_ST = 8,
GX_BP_FOGPARAM1_B_MAG_END = 31,
} GXBPFogParam1;
typedef enum _GXBPFogParam2 {
GX_BP_FOGPARAM2_B_SHIFT_ST = 27,
GX_BP_FOGPARAM2_B_SHIFT_END = 31,
} GXBPFogParam2;
typedef enum _GXBPFogParam3 {
GX_BP_FOGPARAM3_C_MANT_ST = 21,
GX_BP_FOGPARAM3_C_MANT_END = 31,
GX_BP_FOGPARAM3_C_EXP_ST = 13,
GX_BP_FOGPARAM3_C_EXP_END = 20,
GX_BP_FOGPARAM3_C_SIGN_ST = 12,
GX_BP_FOGPARAM3_C_SIGN_END = 12,
GX_BP_FOGPARAM3_PROJ_ST = 11,
GX_BP_FOGPARAM3_PROJ_END = 11,
GX_BP_FOGPARAM3_FSEL_ST = 8,
GX_BP_FOGPARAM3_FSEL_END = 10,
} GXBPFogParam3;
typedef enum _GXBPFogColor {
GX_BP_FOGCOLOR_RGB_ST = 8,
GX_BP_FOGCOLOR_RGB_END = 31,
} GXBPFogColor;
typedef enum _GXCPMtxIdxA {
GX_CP_MTXIDXA_GEOM_ST = 26,
GX_CP_MTXIDXA_GEOM_END = 31,
GX_CP_MTXIDXA_TEX0_ST = 20,
GX_CP_MTXIDXA_TEX0_END = 25,
GX_CP_MTXIDXA_TEX1_ST = 14,
GX_CP_MTXIDXA_TEX1_END = 19,
GX_CP_MTXIDXA_TEX2_ST = 8,
GX_CP_MTXIDXA_TEX2_END = 13,
GX_CP_MTXIDXA_TEX3_ST = 2,
GX_CP_MTXIDXA_TEX3_END = 7,
} GXCPMtxIdxA;
typedef enum _GXCPMtxIdxB {
GX_CP_MTXIDXB_TEX4_ST = 26,
GX_CP_MTXIDXB_TEX4_END = 31,
GX_CP_MTXIDXB_TEX5_ST = 20,
GX_CP_MTXIDXB_TEX5_END = 25,
GX_CP_MTXIDXB_TEX6_ST = 14,
GX_CP_MTXIDXB_TEX6_END = 19,
GX_CP_MTXIDXB_TEX7_ST = 8,
GX_CP_MTXIDXB_TEX7_END = 13,
} GXCPMtxIdxB;
typedef enum _GXCPVCDLo {
GX_CP_VCD_LO_POSMTXIDX_ST = 31,
GX_CP_VCD_LO_POSMTXIDX_END = 31,
GX_CP_VCD_LO_TEX0MTXIDX_ST = 30,
GX_CP_VCD_LO_TEX0MTXIDX_END = 30,
GX_CP_VCD_LO_TEX1MTXIDX_ST = 29,
GX_CP_VCD_LO_TEX1MTXIDX_END = 29,
GX_CP_VCD_LO_TEX2MTXIDX_ST = 28,
GX_CP_VCD_LO_TEX2MTXIDX_END = 28,
GX_CP_VCD_LO_TEX3MTXIDX_ST = 27,
GX_CP_VCD_LO_TEX3MTXIDX_END = 27,
GX_CP_VCD_LO_TEX4MTXIDX_ST = 26,
GX_CP_VCD_LO_TEX4MTXIDX_END = 26,
GX_CP_VCD_LO_TEX5MTXIDX_ST = 25,
GX_CP_VCD_LO_TEX5MTXIDX_END = 25,
GX_CP_VCD_LO_TEX6MTXIDX_ST = 24,
GX_CP_VCD_LO_TEX6MTXIDX_END = 24,
GX_CP_VCD_LO_TEX7MTXIDX_ST = 23,
GX_CP_VCD_LO_TEX7MTXIDX_END = 23,
GX_CP_VCD_LO_POS_ST = 21,
GX_CP_VCD_LO_POS_END = 22,
GX_CP_VCD_LO_NRM_ST = 19,
GX_CP_VCD_LO_NRM_END = 20,
GX_CP_VCD_LO_CLRDIF_ST = 17,
GX_CP_VCD_LO_CLRDIF_END = 18,
GX_CP_VCD_LO_CLRSPEC_ST = 15,
GX_CP_VCD_LO_CLRSPEC_END = 16,
} GXCPVCDLo;
typedef enum _GXCPVCDHi {
GX_CP_VCD_HI_TEX0COORD_ST = 30,
GX_CP_VCD_HI_TEX0COORD_END = 31,
GX_CP_VCD_HI_TEX1COORD_ST = 28,
GX_CP_VCD_HI_TEX1COORD_END = 29,
GX_CP_VCD_HI_TEX2COORD_ST = 26,
GX_CP_VCD_HI_TEX2COORD_END = 27,
GX_CP_VCD_HI_TEX3COORD_ST = 24,
GX_CP_VCD_HI_TEX3COORD_END = 25,
GX_CP_VCD_HI_TEX4COORD_ST = 22,
GX_CP_VCD_HI_TEX4COORD_END = 23,
GX_CP_VCD_HI_TEX5COORD_ST = 20,
GX_CP_VCD_HI_TEX5COORD_END = 21,
GX_CP_VCD_HI_TEX6COORD_ST = 18,
GX_CP_VCD_HI_TEX6COORD_END = 19,
GX_CP_VCD_HI_TEX7COORD_ST = 16,
GX_CP_VCD_HI_TEX7COORD_END = 17,
} GXCPVCDHi;
typedef enum _GXCPVATGrp0 {
GX_CP_VAT_GRP0_POS_CNT_ST = 31,
GX_CP_VAT_GRP0_POS_CNT_END = 31,
GX_CP_VAT_GRP0_POS_TYPE_ST = 28,
GX_CP_VAT_GRP0_POS_TYPE_END = 30,
GX_CP_VAT_GRP0_POS_SHIFT_ST = 23,
GX_CP_VAT_GRP0_POS_SHIFT_END = 27,
GX_CP_VAT_GRP0_NRM_CNT_ST = 22,
GX_CP_VAT_GRP0_NRM_CNT_END = 22,
GX_CP_VAT_GRP0_NRM_TYPE_ST = 19,
GX_CP_VAT_GRP0_NRM_TYPE_END = 21,
GX_CP_VAT_GRP0_CLRDIFF_CNT_ST = 18,
GX_CP_VAT_GRP0_CLRDIFF_CNT_END = 18,
GX_CP_VAT_GRP0_CLRDIFF_TYPE_ST = 15,
GX_CP_VAT_GRP0_CLRDIFF_TYPE_END = 17,
GX_CP_VAT_GRP0_CLRSPEC_CNT_ST = 14,
GX_CP_VAT_GRP0_CLRSPEC_CNT_END = 14,
GX_CP_VAT_GRP0_CLRSPEC_TYPE_ST = 11,
GX_CP_VAT_GRP0_CLRSPEC_TYPE_END = 13,
GX_CP_VAT_GRP0_TXC0_CNT_ST = 10,
GX_CP_VAT_GRP0_TXC0_CNT_END = 10,
GX_CP_VAT_GRP0_TXC0_TYPE_ST = 7,
GX_CP_VAT_GRP0_TXC0_TYPE_END = 9,
GX_CP_VAT_GRP0_TXC0_SHIFT_ST = 2,
GX_CP_VAT_GRP0_TXC0_SHIFT_END = 6,
GX_CP_VAT_GRP0_BYTEDEQ_ST = 1,
GX_CP_VAT_GRP0_BYTEDEQ_END = 1,
GX_CP_VAT_GRP0_NRMIDX3_ST = 0,
GX_CP_VAT_GRP0_NRMIDX3_END = 0,
} GXCPVATGrp0;
typedef enum _GXCPVATGrp1 {
GX_CP_VAT_GRP1_TXC1_CNT_ST = 31,
GX_CP_VAT_GRP1_TXC1_CNT_END = 31,
GX_CP_VAT_GRP1_TXC1_TYPE_ST = 28,
GX_CP_VAT_GRP1_TXC1_TYPE_END = 30,
GX_CP_VAT_GRP1_TXC1_SHIFT_ST = 23,
GX_CP_VAT_GRP1_TXC1_SHIFT_END = 27,
GX_CP_VAT_GRP1_TXC2_CNT_ST = 22,
GX_CP_VAT_GRP1_TXC2_CNT_END = 22,
GX_CP_VAT_GRP1_TXC2_TYPE_ST = 19,
GX_CP_VAT_GRP1_TXC2_TYPE_END = 21,
GX_CP_VAT_GRP1_TXC2_SHIFT_ST = 14,
GX_CP_VAT_GRP1_TXC2_SHIFT_END = 18,
GX_CP_VAT_GRP1_TXC3_CNT_ST = 13,
GX_CP_VAT_GRP1_TXC3_CNT_END = 13,
GX_CP_VAT_GRP1_TXC3_TYPE_ST = 10,
GX_CP_VAT_GRP1_TXC3_TYPE_END = 12,
GX_CP_VAT_GRP1_TXC3_SHIFT_ST = 5,
GX_CP_VAT_GRP1_TXC3_SHIFT_END = 9,
GX_CP_VAT_GRP1_TXC4_CNT_ST = 4,
GX_CP_VAT_GRP1_TXC4_CNT_END = 4,
GX_CP_VAT_GRP1_TXC4_TYPE_ST = 1,
GX_CP_VAT_GRP1_TXC4_TYPE_END = 3,
} GXCPVATGrp1;
typedef enum _GXCPVATGrp2 {
GX_CP_VAT_GRP2_TXC4_SHIFT_ST = 27,
GX_CP_VAT_GRP2_TXC4_SHIFT_END = 31,
GX_CP_VAT_GRP2_TXC5_CNT_ST = 26,
GX_CP_VAT_GRP2_TXC5_CNT_END = 26,
GX_CP_VAT_GRP2_TXC5_TYPE_ST = 23,
GX_CP_VAT_GRP2_TXC5_TYPE_END = 25,
GX_CP_VAT_GRP2_TXC5_SHIFT_ST = 18,
GX_CP_VAT_GRP2_TXC5_SHIFT_END = 22,
GX_CP_VAT_GRP2_TXC6_CNT_ST = 17,
GX_CP_VAT_GRP2_TXC6_CNT_END = 17,
GX_CP_VAT_GRP2_TXC6_TYPE_ST = 14,
GX_CP_VAT_GRP2_TXC6_TYPE_END = 16,
GX_CP_VAT_GRP2_TXC6_SHIFT_ST = 9,
GX_CP_VAT_GRP2_TXC6_SHIFT_END = 13,
GX_CP_VAT_GRP2_TXC7_CNT_ST = 8,
GX_CP_VAT_GRP2_TXC7_CNT_END = 8,
GX_CP_VAT_GRP2_TXC7_TYPE_ST = 5,
GX_CP_VAT_GRP2_TXC7_TYPE_END = 7,
GX_CP_VAT_GRP2_TXC7_SHIFT_ST = 0,
GX_CP_VAT_GRP2_TXC7_SHIFT_END = 4,
} GXCPVATGrp2;
typedef enum _GXCPArrayBase {
GX_CP_ARRAYBASE_BASE_ST = 6,
GX_CP_ARRAYBASE_BASE_END = 31,
} GXCPArrayBase;
typedef enum _GXCPArrayStride {
GX_CP_ARRAYSTRIDE_STRIDE_ST = 24,
GX_CP_ARRAYSTRIDE_STRIDE_END = 31,
} GXCPArrayStride;
typedef enum _GXXFClipDisable {
GX_XF_CLIPDISABLE_DETECT_ST = 31,
GX_XF_CLIPDISABLE_DETECT_END = 31,
GX_XF_CLIPDISABLE_REJECT_ST = 30,
GX_XF_CLIPDISABLE_REJECT_END = 30,
GX_XF_CLIPDISABLE_ACCEL_ST = 29,
GX_XF_CLIPDISABLE_ACCEL_END = 29,
} GXXFClipDisable;
typedef enum _GXXFInVertexSpec {
GX_XF_INVERTEXSPEC_CLR_ST = 30,
GX_XF_INVERTEXSPEC_CLR_END = 31,
GX_XF_INVERTEXSPEC_NRM_ST = 28,
GX_XF_INVERTEXSPEC_NRM_END = 29,
GX_XF_INVERTEXSPEC_TEX_ST = 24,
GX_XF_INVERTEXSPEC_TEX_END = 27,
} GXXFInVertexSpec;
typedef enum _GXXFClr0Ctrl {
GX_XF_CLR0CTRL_MTXSRC_ST = 31,
GX_XF_CLR0CTRL_MTXSRC_END = 31,
GX_XF_CLR0CTRL_LIGHT_ST = 30,
GX_XF_CLR0CTRL_LIGHT_END = 30,
GX_XF_CLR0CTRL_LMASKHI_ST = 26,
GX_XF_CLR0CTRL_LMASKHI_END = 29,
GX_XF_CLR0CTRL_AMBSRC_ST = 25,
GX_XF_CLR0CTRL_AMBSRC_END = 25,
GX_XF_CLR0CTRL_DIFATTN_ST = 23,
GX_XF_CLR0CTRL_DIFATTN_END = 24,
GX_XF_CLR0CTRL_ATTNENABLE_ST = 22,
GX_XF_CLR0CTRL_ATTNENABLE_END = 22,
GX_XF_CLR0CTRL_ATTNSEL_ST = 21,
GX_XF_CLR0CTRL_ATTNSEL_END = 21,
GX_XF_CLR0CTRL_LMASKLO_ST = 17,
GX_XF_CLR0CTRL_LMASKLO_END = 20,
} GXXFClr0Ctrl;
typedef enum _GXXFMtxIdx0 {
GX_XF_MTXIDX0_GEOM_ST = 26,
GX_XF_MTXIDX0_GEOM_END = 31,
GX_XF_MTXIDX0_TEX0_ST = 20,
GX_XF_MTXIDX0_TEX0_END = 25,
GX_XF_MTXIDX0_TEX1_ST = 14,
GX_XF_MTXIDX0_TEX1_END = 19,
GX_XF_MTXIDX0_TEX2_ST = 8,
GX_XF_MTXIDX0_TEX2_END = 13,
GX_XF_MTXIDX0_TEX3_ST = 2,
GX_XF_MTXIDX0_TEX3_END = 7,
} GXXFMtxIdx0;
typedef enum _GXXFMtxIdx1 {
GX_XF_MTXIDX1_TEX4_ST = 26,
GX_XF_MTXIDX1_TEX4_END = 31,
GX_XF_MTXIDX1_TEX5_ST = 20,
GX_XF_MTXIDX1_TEX5_END = 25,
GX_XF_MTXIDX1_TEX6_ST = 14,
GX_XF_MTXIDX1_TEX6_END = 19,
GX_XF_MTXIDX1_TEX7_ST = 8,
GX_XF_MTXIDX1_TEX7_END = 13,
} GXXFMtxIdx1;
typedef enum _GXXFTex {
GX_XF_TEX_PROJTYPE_ST = 30,
GX_XF_TEX_PROJTYPE_END = 30,
GX_XF_TEX_INPUTFORM_ST = 29,
GX_XF_TEX_INPUTFORM_END = 29,
GX_XF_TEX_TEXGENTYPE_ST = 25,
GX_XF_TEX_TEXGENTYPE_END = 27,
GX_XF_TEX_SRCROW_ST = 20,
GX_XF_TEX_SRCROW_END = 24,
GX_XF_TEX_BUMPSRCTEX_ST = 17,
GX_XF_TEX_BUMPSRCTEX_END = 19,
GX_XF_TEX_BUMPSRCLIGHT_ST = 14,
GX_XF_TEX_BUMPSRCLIGHT_END = 16,
} GXXFTex;
typedef enum _GXXFDualTex {
GX_XF_DUALTEX_BASEROW_ST = 26,
GX_XF_DUALTEX_BASEROW_END = 31,
GX_XF_DUALTEX_NORMALISE_ST = 23,
GX_XF_DUALTEX_NORMALISE_END = 23,
} GXXFDualTex;
}
extern "C"{
typedef void (*VIRetraceCallback)(u32 retraceCount);
typedef void (*VIPositionCallback)(s16 x, s16 y);
typedef enum {
VI_TVMODE_NTSC_INT = ((((0)) << 2) + ((0))) ,
VI_TVMODE_NTSC_DS = ((((0)) << 2) + ((1))) ,
VI_TVMODE_NTSC_PROG = ((((0)) << 2) + ((2))) ,
VI_TVMODE_NTSC_3D = ((((0)) << 2) + ((3))) ,
VI_TVMODE_PAL_INT = ((((1)) << 2) + ((0))) ,
VI_TVMODE_PAL_DS = ((((1)) << 2) + ((1))) ,
VI_TVMODE_MPAL_INT = ((((2)) << 2) + ((0))) ,
VI_TVMODE_MPAL_DS = ((((2)) << 2) + ((1))) ,
VI_TVMODE_DEBUG_INT = ((((3)) << 2) + ((0))) ,
VI_TVMODE_DEBUG_PAL_INT = ((((4)) << 2) + ((0))) ,
VI_TVMODE_DEBUG_PAL_DS = ((((4)) << 2) + ((1))) ,
VI_TVMODE_EURGB60_INT = ((((5)) << 2) + ((0))) ,
VI_TVMODE_EURGB60_DS = ((((5)) << 2) + ((1))) ,
VI_TVMODE_GCA_INT = ((((6)) << 2) + ((0))) ,
VI_TVMODE_GCA_DS = ((((6)) << 2) + ((1))) ,
VI_TVMODE_GCA_PROG = ((((6)) << 2) + ((2))) ,
} VITVMode;
typedef enum {
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF = 1,
} VIXFBMode;
typedef struct VITimingInfo {
u8 equ;
u16 acv;
u16 prbOdd;
u16 prbEven;
u16 psbOdd;
u16 psbEven;
u8 bs1;
u8 bs2;
u8 bs3;
u8 bs4;
u16 be1;
u16 be2;
u16 be3;
u16 be4;
u16 numHalfLines;
u16 hlw;
u8 hsy;
u8 hcs;
u8 hce;
u8 hbe640;
u16 hbs640;
u8 hbeCCIR656;
u16 hbsCCIR656;
} VITimingInfo;
typedef struct VIPositionInfo {
u16 dispPosX;
u16 dispPosY;
u16 dispSizeX;
u16 dispSizeY;
u16 adjDispPosX;
u16 adjDispPosY;
u16 adjDispSizeY;
u16 adjPanPosY;
u16 adjPanSizeY;
u16 fbSizeX;
u16 fbSizeY;
u16 panPosX;
u16 panPosY;
u16 panSizeX;
u16 panSizeY;
VIXFBMode xfbMode;
u32 nonInter;
u32 tv;
u8 wordPerLine;
u8 std;
u8 wpl;
u32 bufAddr;
u32 tfbb;
u32 bfbb;
u8 xof;
BOOL isBlack;
BOOL is3D;
u32 rbufAddr;
u32 rtfbb;
u32 rbfbb;
VITimingInfo* timing;
} VIPositionInfo;
}
extern "C"{
typedef struct _GXColor {
u8 r, g, b, a;
} GXColor;
typedef struct _GXColorS10 {
s16 r, g, b, a;
} GXColorS10;
typedef struct _GXTexObj {
u8 pad[0x20];
} GXTexObj;
typedef struct _GXTexObjPriv {
u32 mode0;
u32 mode1;
u32 image0;
u32 image3;
void* userData;
GXTexFmt format;
u32 tlutName;
u16 loadCount;
u8 loadFormat;
u8 flags;
} GXTexObjPriv;
typedef struct _GXTexRegion {
u8 padding[0x10];
} GXTexRegion;
typedef struct _GXTexRegionPriv {
u32 image1;
u32 image2;
u16 sizeEven;
u16 sizeOdd;
u8 is32bMipmap;
u8 isCached;
} GXTexRegionPriv;
typedef struct _GXTlutObj {
u8 padding[0xc];
} GXTlutObj;
typedef struct _GXTlutObjPriv {
u32 tlut;
u32 loadTlut0;
u16 numEntries;
u8 padding[0x2];
} GXTlutObjPriv;
typedef struct _GXTlutRegion {
u8 padding[0x10];
} GXTlutRegion;
typedef struct _GXTlutRegionPriv {
u32 loadTlut1;
GXTlutObjPriv tlutObj;
} GXTlutRegionPriv;
typedef struct _GXLightObj {
u8 padding[0x40];
} GXLightObj;
typedef struct __GXLightObjPriv {
u32 reserved[3];
GXColor color;
f32 a[3];
f32 k[3];
f32 lpos[3];
f32 ldir[3];
} GXLightObjPriv;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt count;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXFogAdjTable {
u16 fogVals[10];
} GXFogAdjTable;
}
extern "C"{
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(GXVtxDescList* attrPtr);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetVtxAttrFmtv(GXVtxFmt vtxfmt, GXVtxAttrFmtList* list);
void GXSetArray(GXAttr attr, void* base_ptr, u8 stride);
void GXInvalidateVtxCache(void);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx, GXBool normalize, u32 pt_texmtx);
void GXSetNumTexGens(u8 nTexGens);
void __GXSetVCD(void);
void __GXSetVAT(void);
void GXGetVtxDesc(GXAttr attr, GXAttrType* type);
void GXGetVtxDescv(GXVtxDescList* vcd);
void GXGetVtxAttrFmt(GXVtxFmt fmt, GXAttr attr, GXCompCnt* cnt, GXCompType* type, u8* frac);
void GXGetVtxAttrFmtv(GXVtxFmt fmt, GXVtxAttrFmtList* vat);
}
extern "C"{
extern void __GXFlushTextureState();
extern void GXSetTevIndirect(GXTevStageID tevStage, GXIndTexStageID indStage, GXIndTexFormat format, GXIndTexBiasSel bias,
GXIndTexMtxID mtx, GXIndTexWrap sWrap, GXIndTexWrap tWrap, GXBool doAddPrev, GXBool isIndLOD,
GXIndTexAlphaSel alpha);
extern void GXSetIndTexMtx(GXIndTexMtxID mtx, const Mtx23 offsets, s8 scale);
extern void GXSetIndTexCoordScale(GXIndTexStageID stage, GXIndTexScale sScale, GXIndTexScale tScale);
extern void GXSetIndTexOrder(GXIndTexStageID stage, GXTexCoordID texCoord, GXTexMapID texMap);
extern void GXSetNumIndStages(u8 stageCount);
extern void __GXSetIndirectMask(u32 mask);
extern void GXSetTevDirect(GXTevStageID stage);
extern void GXSetTevIndWarp(GXTevStageID tevStage, GXIndTexStageID indStage, GXBool isSignedOffset, GXBool isReplaceMode,
GXIndTexMtxID mtx);
extern void GXSetTevIndTile(GXTevStageID tevStage, GXIndTexStageID indStage, u16 sTileSize, u16 tTileSize, u16 sTileSpacing,
u16 tTileSpacing, GXIndTexFormat format, GXIndTexMtxID mtx, GXIndTexBiasSel bias, GXIndTexAlphaSel alpha);
extern void GXSetTevIndBumpST(GXTevStageID tevStage, GXIndTexStageID indStage, GXIndTexMtxID mtx);
extern void GXSetTevIndBumpXYZ(GXTevStageID tevStage, GXIndTexStageID indStage, GXIndTexMtxID mtx);
extern void GXSetTevIndRepeat(GXTevStageID stage);
void __GXUpdateBPMask(void);
}
extern "C"{
typedef struct _GXFifoObj {
u8 padding[(128) ];
} GXFifoObj;
typedef struct __GXFifoObj {
u8* base;
u8* top;
u32 size;
u32 hiWatermark;
u32 loWatermark;
void* rdPtr;
void* wrPtr;
s32 count;
u8 bind_cpu;
u8 bind_gp;
} __GXFifoObj;
typedef struct _GXFifoObjPriv {
void* base;
void* end;
u32 size;
u32 highWatermark;
u32 lowWatermark;
void* readPtr;
void* writePtr;
s32 rwDistance;
u8 _20[0x60];
} GXFifoObjPriv;
typedef void (*GXBreakPtCallback)(void);
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
extern volatile PPCWGPipe GXWGFifo : (0xCC008000) ;
static inline void GXPosition2f32(const f32 x, const f32 y)
{
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
}
static inline void GXPosition3s16(const s16 x, const s16 y, const s16 z)
{
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXPosition3u16(const u16 x, const u16 y, const u16 z)
{
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
GXWGFifo.u16 = z;
}
static inline void GXPosition3f32(f32 x, f32 y, f32 z)
{
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXNormal3f32(const f32 x, const f32 y, const f32 z)
{
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXColor1u32(u32 c)
{
GXWGFifo.u32 = c;
}
static inline void GXColor4u8(const u8 r, const u8 g, const u8 b, const u8 a)
{
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
GXWGFifo.u8 = a;
}
static inline void GXTexCoord2s8(const s8 u, const s8 v)
{
GXWGFifo.s8 = u;
GXWGFifo.s8 = v;
}
static inline void GXTexCoord2u8(u8 s, u8 t)
{
GXWGFifo.u8 = s;
GXWGFifo.u8 = t;
}
static inline void GXPosition2u16(u16 x, u16 y)
{
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
}
static inline void GXPosition2s16(s16 x, s16 y)
{
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
}
static inline void GXTexCoord2s16(const s16 u, const s16 v)
{
GXWGFifo.s16 = u;
GXWGFifo.s16 = v;
}
static inline void GXTexCoord2u16(const u16 u, const u16 v)
{
GXWGFifo.u16 = u;
GXWGFifo.u16 = v;
}
static inline void GXTexCoord2f32(const f32 u, const f32 v)
{
GXWGFifo.f32 = u;
GXWGFifo.f32 = v;
}
static inline void GXEnd(void)
{
}
extern void __GXFifoInit();
extern void GXInitFifoBase(GXFifoObj* obj, void* base, u32 size);
extern void GXInitFifoPtrs(GXFifoObj* obj, void* readPtr, void* writePtr);
extern void GXInitFifoLimits(GXFifoObj* obj, u32 hiWaterMark, u32 loWaterMark);
extern void GXSetCPUFifo(GXFifoObj* obj);
extern void GXSetGPFifo(GXFifoObj* obj);
extern void GXSaveCPUFifo(GXFifoObj* obj);
extern void GXGetGPStatus(GXBool* isOverHi, GXBool* isUnderLo, GXBool* isReadIdle, GXBool* isCmdIdle, GXBool* isHitBrkPt);
extern GXFifoObj* GXGetCPUFifo();
extern GXFifoObj* GXGetGPFifo();
extern void GXBeginDisplayList(void* list, u32 size);
extern u32 GXEndDisplayList();
extern void GXCallDisplayList(void* list, u32 numBytes);
extern GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback callback);
void __GXSaveCPUFifoAux(__GXFifoObj* obj);
void __GXFifoReadEnable();
void __GXFifoReadDisable();
void __GXFifoLink(u8);
void __GXWriteFifoIntEnable(u8, u8);
void __GXWriteFifoIntReset(u8, u8);
void __GXCleanGPFifo(void);
extern void GXSaveGPFifo(GXFifoObj* obj);
extern void GXGetFifoStatus(GXFifoObj* obj, GXBool* isOverHi, GXBool* isUnderLo, u32* fifoCount, GXBool* isCpuWrite, GXBool* isGPRead,
GXBool* isFifoWrap);
extern void GXGetFifoPtrs(GXFifoObj* obj, void** readPtr, void** writePtr);
extern void* GXGetFifoBase(GXFifoObj* obj);
extern u32 GXGetFifoSize(GXFifoObj* obj);
extern void GXGetFifoLimits(GXFifoObj* obj, u32* hi, u32* lo);
extern void GXEnableBreakPt(void* breakPtr);
extern void GXDisableBreakPt();
}
extern "C"{
typedef GXTexRegion* (*GXTexRegionCallback)(GXTexObj* t_obj, GXTexMapID id);
typedef GXTlutRegion* (*GXTlutRegionCallback)(u32 idx);
extern void GXInitTexObj(GXTexObj* obj, void* imagePtr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode sWrap, GXTexWrapMode tWrap,
GXBool useMIPmap);
extern void GXInitTexObjCI(GXTexObj* obj, void* imagePtr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode sWrap,
GXTexWrapMode tWrap, GXBool useMIPmap, u32 tlutName);
extern void GXInitTexObjLOD(GXTexObj* obj, GXTexFilter minFilter, GXTexFilter maxFilter, f32 minLOD, f32 maxLOD, f32 lodBias,
GXBool doBiasClamp, GXBool doEdgeLOD, GXAnisotropy maxAniso);
extern GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
extern GXBool GXGetTexObjMipMap(const GXTexObj* obj);
extern u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, GXBool mipmap, u8 max_lod);
extern void GXLoadTexObjPreLoaded(GXTexObj* obj, GXTexRegion* region, GXTexMapID map);
extern void GXLoadTexObj(GXTexObj* obj, GXTexMapID map);
extern void GXInitTlutObj(GXTlutObj* obj, void* table, GXTlutFmt format, u16 numEntries);
extern void GXLoadTlut(GXTlutObj* obj, u32 tlutName);
extern void GXInitTexCacheRegion(GXTexRegion* region, GXBool is32bMIPmap, u32 memEven, GXTexCacheSize sizeEven, u32 memOdd,
GXTexCacheSize sizeOdd);
extern void GXInitTlutRegion(GXTlutRegion* region, u32 memAddr, GXTlutSize tlutSize);
extern void GXInvalidateTexAll();
extern GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback func);
extern GXTlutRegionCallback GXSetTlutRegionCallback(GXTlutRegionCallback func);
extern void __GXSetSUTexRegs();
extern void __GXSetTmemConfig(u32 config);
extern void GXInitTexObjData(GXTexObj* obj, void* imagePtr);
extern void GXInitTexObjWrapMode(GXTexObj* obj, GXTexWrapMode sWrap, GXTexWrapMode tWrap);
extern void GXInitTexObjTlut(GXTexObj* obj, u32 tlutName);
extern void __GetImageTileCount(GXTexFmt format, u16 width, u16 height, u32* a, u32* b, u32* c);
}
extern "C"{
typedef enum _CPStatus {
GX_FIFO_OVERFLOW = 0x1,
GX_FIFO_UNDERFLOW = 0x2,
GP_IS_IDLE_FOR_READING = 0x4,
GP_IS_IDLE_FOR_COMMANDS = 0x8,
BP_INTERRUPT = 0x10,
} CPStatus;
typedef enum _CPControl {
GP_FIFO_READ_ENABLE = 0x1,
CP_IRQ_ENABLE_MAYBE = 0x2,
FIFO_OVERFLOW_IRQ_ENABLE_MAYBE = 0x4,
FIFO_UNDERFLOW_IRQ_ENABLE_MAYBE = 0x8,
GP_LINK_ENABLE = 0x10,
BP_ENABLE = 0x20,
} CPControl;
typedef enum _CPClear {
CLEAR_FIFO_OVERFLOW = 0x1,
CLEAR_FIFO_UNDERFLOW = 0x2,
} CPClear;
struct __GXData_struct {
unsigned short vNum;
unsigned short bpSent;
unsigned long vLim;
unsigned long cpEnable;
unsigned long cpStatus;
unsigned long cpClr;
unsigned long vcdLo;
unsigned long vcdHi;
unsigned long vatA[8];
unsigned long vatB[8];
unsigned long vatC[8];
unsigned long lpSize;
unsigned long matIdxA;
unsigned long matIdxB;
unsigned long indexBase[4];
unsigned long indexStride[4];
unsigned long ambColor[2];
unsigned long matColor[2];
unsigned long suTs0[8];
unsigned long suTs1[8];
unsigned long suScis0;
unsigned long suScis1;
unsigned long tref[8];
unsigned long iref;
unsigned long bpMask;
unsigned long IndTexScale0;
unsigned long IndTexScale1;
unsigned long tevc[16];
unsigned long teva[16];
unsigned long tevKsel[8];
unsigned long cmode0;
unsigned long cmode1;
unsigned long zmode;
unsigned long peCtrl;
unsigned long cpDispSrc;
unsigned long cpDispSize;
unsigned long cpDispStride;
unsigned long cpDisp;
unsigned long cpTexSrc;
unsigned long cpTexSize;
unsigned long cpTexStride;
unsigned long cpTex;
unsigned char cpTexZ;
unsigned long genMode;
GXTexRegion TexRegions[8];
GXTexRegion TexRegionsCI[4];
unsigned long nextTexRgn;
unsigned long nextTexRgnCI;
GXTlutRegion TlutRegions[20];
GXTexRegion* (*texRegionCallback)(GXTexObj*, GXTexMapID);
GXTlutRegion* (*tlutRegionCallback)(unsigned long);
GXAttrType nrmType;
unsigned char hasNrms;
unsigned char hasBiNrms;
unsigned long projType;
float projMtx[6];
float vpLeft;
float vpTop;
float vpWd;
float vpHt;
float vpNearz;
float vpFarz;
unsigned char fgRange;
float fgSideX;
unsigned long tImage0[8];
unsigned long tMode0[8];
unsigned long texmapId[16];
unsigned long tcsManEnab;
GXPerf0 perf0;
GXPerf1 perf1;
unsigned long perfSel;
unsigned char inDispList;
unsigned char dlSaveContext;
unsigned char dirtyVAT;
unsigned long dirtyState;
};
extern struct __GXData_struct* gx;
extern vu16* __cpReg;
extern vu32* __piReg;
extern vu16* __memReg;
extern vu16* __peReg;
static inline u32 GXReadMEMReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __memReg[addrHi];
do {
hiNew = hiStart;
lo = __memReg[addrLo];
hiStart = __memReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
static inline u32 GXReadCPReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __cpReg[addrHi];
do {
hiNew = hiStart;
lo = __cpReg[addrLo];
hiStart = __cpReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
static inline u32 GXReadPEReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __peReg[addrHi];
do {
hiNew = hiStart;
lo = __peReg[addrLo];
hiStart = __peReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
static inline u32 GXReadPIReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __piReg[addrHi];
do {
hiNew = hiStart;
lo = __piReg[addrLo];
hiStart = __piReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
}
extern "C"{
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXMpal480Int;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
extern void GXSetDispCopySrc(u16 left, u16 top, u16 width, u16 height);
extern void GXSetTexCopySrc(u16 left, u16 top, u16 width, u16 height);
extern void GXSetDispCopyDst(u16 width, u16 height);
extern void GXSetTexCopyDst(u16 width, u16 height, GXTexFmt format, GXBool useMIPmap);
extern void GXSetDispCopyFrame2Field(GXCopyMode mode);
extern void GXSetCopyClamp(GXFBClamp clamp);
extern u32 GXSetDispCopyYScale(f32 vertScale);
extern void GXSetCopyClear(GXColor clearColor, u32 clearZ);
extern void GXSetCopyFilter(GXBool useAA, const u8 samplePattern[12][2], GXBool doVertFilt, const u8 vFilt[7]);
extern void GXSetDispCopyGamma(GXGamma gamma);
extern void GXCopyDisp(void* dest, GXBool doClear);
extern void GXCopyTex(void* dest, GXBool doClear);
extern u16 GXGetNumXfbLines(u16 efbHeight, f32 yScale);
extern f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
extern void GXClearBoundingBox();
extern void GXAdjustForOverscan(GXRenderModeObj* rIn, GXRenderModeObj* rOut, u16 horiz, u16 vert);
extern void GXReadBoundingBox(u16* left, u16* top, u16* right, u16* bottom);
}
extern "C"{
extern void __GXSetDirtyState();
extern void GXBegin(GXPrimitive type, GXVtxFmt format, u16 numVertices);
extern void __GXSendFlushPrim();
extern void GXSetVtxDesc(GXAttr attr, GXAttrType type);
extern void GXClearVtxDesc();
extern void GXSetVtxAttrFmt(GXVtxFmt format, GXAttr attr, GXCompCnt count, GXCompType type, u8 frac);
extern void GXSetVtxAttrFmtv(GXVtxFmt format, GXVtxAttrFmtList* list);
extern void GXSetArray(GXAttr attr, void* basePtr, u8 stride);
extern void GXInvalidateVtxCache();
extern void GXSetTexCoordGen2(GXTexCoordID coord, GXTexGenType genType, GXTexGenSrc srcParam, u32 mtx, GXBool doNormalise, u32 postMtx);
extern void GXSetNumTexGens(u8 count);
extern void GXSetLineWidth(u8 width, GXTexOffset offset);
extern void GXSetPointSize(u8 pointSize, GXTexOffset offset);
extern void GXEnableTexOffsets(GXTexCoordID coord, GXBool enableLine, GXBool enablePoint);
extern void __GXSetGenMode();
extern void GXSetCullMode(GXCullMode mode);
extern void GXSetCoPlanar(GXBool doEnable);
extern void GXGetLineWidth(u8* width, GXTexOffset* offset);
extern void GXGetPointSize(u8* pointSize, GXTexOffset* offset);
extern void GXGetCullMode(GXCullMode* mode);
}
extern "C"{
}
extern "C"{
extern void GXInitLightAttn(GXLightObj* obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
extern void GXInitLightSpot(GXLightObj* obj, f32 cutoff, GXSpotFn spotFunc);
extern void GXInitLightDistAttn(GXLightObj* obj, f32 refDist, f32 refBrightness, GXDistAttnFn distFunc);
extern void GXInitLightPos(GXLightObj* obj, f32 x, f32 y, f32 z);
extern void GXInitLightDir(GXLightObj* obj, f32 nX, f32 nY, f32 nZ);
extern void GXInitSpecularDir(GXLightObj* obj, f32 nX, f32 nY, f32 nZ);
extern void GXInitLightColor(GXLightObj* obj, GXColor color);
extern void GXLoadLightObjImm(GXLightObj* obj, GXLightID light);
extern void GXSetChanAmbColor(GXChannelID channel, GXColor color);
extern void GXSetChanMatColor(GXChannelID channel, GXColor color);
extern void GXSetNumChans(u8 count);
extern void GXSetChanCtrl(GXChannelID channel, GXBool doEnable, GXColorSrc ambSrc, GXColorSrc matSrc, u32 mask, GXDiffuseFn diffFunc,
GXAttnFn attnFunc);
extern void GXInitLightAttnA(GXLightObj* obj, f32 a0, f32 a1, f32 a2);
extern void GXGetLightAttnA(GXLightObj* obj, f32* a0, f32* a1, f32* a2);
extern void GXInitLightAttnK(GXLightObj* obj, f32 k0, f32 k1, f32 k2);
extern void GXGetLightAttnK(GXLightObj* obj, f32* k0, f32* k1, f32* k2);
extern void GXGetLightPos(GXLightObj* obj, f32* x, f32* y, f32* z);
extern void GXGetLightDir(GXLightObj* obj, f32* nX, f32* nY, f32* nZ);
extern void GXInitSpecularDirHA(GXLightObj* obj, f32 nX, f32 nY, f32 nZ, f32 hX, f32 hY, f32 hZ);
extern void GXGetLightColor(GXLightObj* obj, GXColor* color);
extern void GXLoadLightObjIndx(u32 objIndex, GXLightID light);
}
extern "C"{
typedef void (*GXDrawSyncCallback)(u16 token);
typedef void (*GXDrawDoneCallback)(void);
static GXTexRegion* __GXDefaultTexRegionCallback(GXTexObj* obj, GXTexMapID id);
static GXTlutRegion* __GXDefaultTlutRegionCallback(u32 tlut);
static BOOL __GXShutdown(BOOL final);
extern GXFifoObj* GXInit(void* base, u32 size);
extern void __GXInitGX();
extern void __GXPEInit();
extern void GXSetMisc(GXMiscToken token, u32 val);
extern void GXFlush();
extern void __GXAbort();
extern void GXAbortFrame();
extern void GXSetDrawSync(u16 token);
extern void GXSetDrawDone();
extern void GXWaitDrawDone();
extern void GXDrawDone();
extern void GXPixModeSync();
extern GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback callback);
extern GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback callback);
extern void GXPokeAlphaMode(GXCompare func, u8 threshold);
extern void GXPokeAlphaRead(GXAlphaReadMode mode);
extern void GXPokeAlphaUpdate(GXBool doUpdate);
extern void GXPokeBlendMode(GXBlendMode mode, GXBlendFactor srcFactor, GXBlendFactor destFactor, GXLogicOp op);
extern void GXPokeColorUpdate(GXBool doUpdate);
extern void GXPokeDstAlpha(GXBool doEnable, u8 alpha);
extern void GXPokeDither(GXBool doDither);
extern void GXPokeZMode(GXBool doCompare, GXCompare func, GXBool doUpdate);
extern void GXResetWriteGatherPipe();
extern u16 GXReadDrawSync();
extern void GXTexModeSync();
extern void GXPeekARGB(u16 x, u16 y, u32* color);
extern void GXPokeARGB(u16 x, u16 y, u32 color);
extern void GXPeekZ(u16 x, u16 y, u32* z);
extern void GXPokeZ(u16 x, u16 y, u32 z);
extern u32 GXCompressZ16(u32 z24, GXZFmt16 zFormat);
extern u32 GXDecompressZ16(u32 z16, GXZFmt16 zFormat);
struct OSThread* GXSetCurrentGXThread();
}
extern "C"{
extern void GXSetGPMetric(GXPerf0 perf0, GXPerf1 perf1);
extern void GXClearGPMetric();
extern void GXReadXfRasMetric(u32* xfWaitIn, u32* xfWaitOut, u32* rasBusy, u32* clocks);
extern void GXReadGPMetric(u32* count0, u32* count1);
extern u32 GXReadGP0Metric();
extern u32 GXReadGP1Metric();
extern void GXReadMemMetric(u32* cpReq, u32* tcReq, u32* cpuReadReq, u32* cpuWriteReq, u32* dspReq, u32* ioReq, u32* viReq, u32* peReq,
u32* rfReq, u32* fiReq);
extern void GXClearMemMetric();
extern void GXReadPixMetric(u32* topIn, u32* topOut, u32* bottomIn, u32* bottomOut, u32* clearIn, u32* copyClocks);
extern void GXClearPixMetric();
extern void GXSetVCacheMetric(GXVCachePerf attr);
extern void GXReadVCacheMetric(u32* check, u32* miss, u32* stall);
extern void GXClearVCacheMetric();
extern void GXInitXfRasMetric();
extern u32 GXReadClksPerVtx();
}
extern "C"{
extern void GXSetFog(GXFogType type, f32 startZ, f32 endZ, f32 nearZ, f32 farZ, GXColor color);
extern void GXInitFogAdjTable(GXFogAdjTable* table, u16 width, const Mtx44 projMtx);
extern void GXSetFogRangeAdj(GXBool doEnable, u16 center, GXFogAdjTable* table);
extern void GXSetBlendMode(GXBlendMode type, GXBlendFactor srcFactor, GXBlendFactor destFactor, GXLogicOp op);
extern void GXSetColorUpdate(GXBool enableUpdate);
extern void GXSetAlphaUpdate(GXBool enableUpdate);
extern void GXSetZMode(GXBool enableCompare, GXCompare func, GXBool enableUpdate);
extern void GXSetZCompLoc(GXBool isBeforeTex);
extern void GXSetPixelFmt(GXPixelFmt pixelFormat, GXZFmt16 zFormat);
extern void GXSetDither(GXBool doDither);
extern void GXSetDstAlpha(GXBool doEnable, u8 alpha);
extern void GXSetFieldMask(GXBool doOddMask, GXBool doEvenMask);
extern void GXSetFieldMode(GXBool doFieldMode, GXBool doHalfAspectRatio);
}
extern "C"{
void __GXSetRange(f32, f32);
}
extern "C"{
extern void GXSetTevOp(GXTevStageID stage, GXTevMode mode);
extern void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c, GXTevColorArg d);
extern void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c, GXTevAlphaArg d);
extern void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool doClamp, GXTevRegID outReg);
extern void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool doClamp, GXTevRegID outReg);
extern void GXSetTevColor(GXTevRegID reg, GXColor color);
extern void GXSetTevColorS10(GXTevRegID reg, GXColorS10 color);
extern void GXSetTevKColor(GXTevKColorID id, GXColor color);
extern void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
extern void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
extern void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel rasSel, GXTevSwapSel texSel);
extern void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green, GXTevColorChan blue, GXTevColorChan alpha);
extern void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
extern void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
extern void GXSetZTexture(GXZTexOp op, GXTexFmt format, u32 bias);
extern void GXSetNumTevStages(u8 count);
extern void GXSetTevClampMode(GXTevStageID stage, GXTevClampMode mode);
}
extern "C"{
extern void GXSetProjection(const Mtx44 mtx, GXProjectionType type);
extern void GXSetProjectionv(const f32* ptr);
extern void GXLoadPosMtxImm(const Mtx mtx, u32 id);
extern void GXLoadNrmMtxImm(const Mtx mtx, u32 id);
extern void GXSetCurrentMtx(u32 id);
extern void GXLoadTexMtxImm(const Mtx mtx, u32 id, GXTexMtxType type);
extern void __GXSetMatrixIndex(GXAttr index);
extern void __GXSetViewport();
extern void GXSetViewport(f32 left, f32 top, f32 width, f32 height, f32 nearZ, f32 farZ);
extern void GXSetScissor(u32 left, u32 top, u32 width, u32 height);
extern void GXSetScissorBoxOffset(s32 x, s32 y);
extern void GXGetScissor(u32* left, u32* top, u32* width, u32* height);
extern void GXGetScissorBoxOffset(int xOffset, int yOffset);
extern void GXSetClipMode(GXClipMode mode);
extern void GXProject(f32 x, f32 y, f32 z, const Mtx viewMtx, f32* projMtx, f32* viewport, f32* screenX, f32* screenY, f32* screenZ);
extern void GXGetProjectionv(f32* ptr);
extern void GXLoadPosMtxIndx(u16 index, u32 id);
extern void GXLoadNrmMtxImm3x3(const Mtx33, u32 id);
extern void GXLoadNrmMtxIndx3x3(u16 index, u32 id);
extern void GXLoadTexMtxIndx(u16 index, u32 id, GXTexMtxType type);
extern void GXSetViewportJitter(f32 left, f32 top, f32 width, f32 height, f32 nearZ, f32 farZ, u32 field);
extern void GXGetViewportv(f32* viewport);
static inline void GXSetViewportv(f32* port)
{
GXSetViewport(port[0], port[1], port[2], port[3], port[4], port[5]);
}
}
extern "C"{
void __VIInit(VITVMode mode);
void VIInit(void);
void VIFlush(void);
void VIWaitForRetrace(void);
void VIConfigure(const GXRenderModeObj* obj);
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void VISetNextFrameBuffer(void* fb);
void* VIGetCurrentFrameBuffer();
void __VIGetCurrentPosition(s16* x, s16* y);
void VISetBlack(BOOL isBlack);
u32 VIGetRetraceCount(void);
u32 VIGetNextField(void);
u32 VIGetCurrentLine(void);
u32 VIGetTvFormat(void);
u32 VIGetDTVStatus(void);
void VIConfigurePan(u16 panPosX, u16 panPosY, u16 panSizeX, u16 panSizeY);
void* VIGetNextFrameBuffer();
void VISetNextRightFrameBuffer(void* fb);
void VISet3D();
}
class Texture;
class TexImg;
class Colour;
class TexobjInfo;
struct SystemCache;
enum TexImgFormat {
TEX_FMT_NULL = -1,
TEX_FMT_RGB565 = 0,
TEX_FMT_S3TC = 1,
TEX_FMT_RGB5A3 = 2,
TEX_FMT_I4 = 3,
TEX_FMT_I8 = 4,
TEX_FMT_IA4 = 5,
TEX_FMT_IA8 = 6,
TEX_FMT_RGBA8 = 7,
TEX_FMT_Z8 = 8,
TEX_FMT_COUNT,
};
class TexAttr : public CoreNode {
public:
enum TilingType {
TILING_REPEAT = 0,
TILING_CLAMP = 1,
};
enum Flags {
FLAG_EDG = 2,
FLAG_XLU = 4,
};
TexAttr()
: CoreNode("texattr")
{
mTextureName = 0 ;
mTexture = 0 ;
mImage = 0 ;
mTilingType = TILING_REPEAT;
mUseOffsetImgData = 0;
mLODBias = 0.0f;
}
virtual void read(RandomAccessStream&);
void initImage();
int mIndex;
int mTextureIndex;
s16 mTilingType;
s16 mFlags;
u16 mUseOffsetImgData;
f32 mLODBias;
char* mTextureName;
Texture* mTexture;
TexImg* mImage;
};
struct BtiHeader {
void read(RandomAccessStream& input)
{
mImageFormat = input.readByte();
mIsAlphaEnabled = input.readByte();
mWidth = input.readShort();
mHeight = input.readShort();
mWrapS = input.readByte();
mWrapT = input.readByte();
_08 = input.readByte();
_09 = input.readByte();
mNumPaletteEntries = input.readShort();
mPaletteDataOffset = input.readInt();
mIsMipmapEnabled = input.readByte();
mIsEdgeLODEnabled = input.readByte();
mDoClampLODBias = input.readByte();
mMaxAnisotropy = input.readByte();
mMiniFilterType = input.readByte();
mMaxiFilterType = input.readByte();
mMinLOD = input.readByte();
mMaxLOD = input.readByte();
mNumImages = input.readByte();
_19 = input.readByte();
mLODBias = input.readShort();
mImageDataOffset = input.readInt();
}
u8 mImageFormat;
u8 mIsAlphaEnabled;
u16 mWidth;
u16 mHeight;
u8 mWrapS;
u8 mWrapT;
u8 _08;
u8 _09;
u16 mNumPaletteEntries;
u32 mPaletteDataOffset;
u8 mIsMipmapEnabled;
u8 mIsEdgeLODEnabled;
u8 mDoClampLODBias;
u8 mMaxAnisotropy;
u8 mMiniFilterType;
u8 mMaxiFilterType;
u8 mMinLOD;
u8 mMaxLOD;
u8 mNumImages;
u8 _19;
u16 mLODBias;
u32 mImageDataOffset;
};
class TexImg : public CoreNode {
public:
TexImg()
: CoreNode("texImg")
{
mImageCount = 1;
mPixelData = 0 ;
}
void read(RandomAccessStream&);
void importBti(Texture*, RandomAccessStream&, u8*);
void importTxe(Texture*, RandomAccessStream&);
static int calcDataSize(int texFmt, int width, int height);
static void getTileSize(int texFmt, u32& tileSizeX, u32& tileSizeY);
static char* formatName(u32 texFmt);
TexImgFormat convFormat(u32);
void setColour( Colour&);
void readTexData(Texture*, RandomAccessStream&, u8*);
void dumpBti(Texture*, char*, RandomAccessStream&, RandomAccessStream&);
int mIndex;
TexImgFormat mFormat;
int mWidth;
int mHeight;
int mImageCount;
int mDataSize;
void* mTextureData;
void* mPixelData;
};
class Texture : public GfxObject {
public:
enum TexFlags {
TEX_CLAMP_S = 1 << 0,
TEX_MIRROR_S = 1 << 1,
TEX_Unk2 = 1 << 2,
TEX_CLAMP_T = 1 << 8,
TEX_MIRROR_T = 1 << 9,
};
Texture();
virtual void attach();
virtual void detach();
virtual void makeResident() { }
u8 getAlpha(int x, int y);
u8 getRed(int x, int y);
void read(RandomAccessStream& input);
void createBuffer(int width, int height, int texFmt, void* buf);
void grabBuffer(int width, int height, bool doClear, bool useMIPmap);
void decodeData(TexImg* texImg);
int offsetGLtoGX(int, int);
static int offsetGXtoGL(int, int, int, int);
int offsetGXtoGL(int);
void write(Stream*);
static void decodeS3TC(int, int, u8*, u8*);
u16 mTexFormat;
u16 mTexFlags;
u16 mWidth;
u16 mHeight;
u32 mTileSizeX;
u32 mTileSizeY;
void* mPixelData;
u32 mLODCount;
f32 mLODBias;
u32 mAttachName;
GXTexObj* mTexObj;
f32 mWidthFactor;
f32 mHeightFactor;
u32 _30;
u32 _34;
TexobjInfo* mInfo;
};
class TexobjInfo : public GfxobjInfo {
public:
TexobjInfo()
: mTexture(0 )
{
}
virtual void attach() { static_cast<GfxObject*>(mTexture)->attach(); }
virtual void detach() { static_cast<GfxObject*>(mTexture)->detach(); }
Texture* mTexture;
};
class CacheInfo {
public:
void insertAfter(CacheInfo* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
char* mName;
CacheInfo* mPrev;
CacheInfo* mNext;
};
class TexCacheInfo : public CacheInfo {
public:
TexCacheInfo() { initData(); }
void initData() { _10 = 0; }
TexCacheInfo** mActiveCacheSlot;
u32 _10;
};
class CacheTexture : public Texture {
public:
CacheTexture()
{
mSystemCache = 0 ;
mTexImage = 0 ;
mActiveCache = 0 ;
}
virtual void makeResident();
SystemCache* mSystemCache;
TexCacheInfo* mActiveCache;
TexImg* mTexImage;
u32 mAramAddress;
};
class TextureCacher : public TexCacheInfo {
public:
TextureCacher(u32 size)
{
mCache = new AyuCache(size);
mName = "root";
mPrev = this;
mNext = this;
}
void updateInfo(CacheTexture*);
void purgeAll();
void removeOldest();
void cacheTexture(CacheTexture*);
AyuCache* mCache;
};
class Sphere;
class Cylinder {
public:
Cylinder( Vector3f& startPoint, Vector3f& endPoint, f32 radius = 1.0f)
: mStartPoint(startPoint)
, mEndPoint(endPoint)
, mRadius(radius)
{
}
f32 get2dDist( Vector3f& point) ;
bool collide(const Sphere& sphere, Vector3f& pushVector, f32& depth) ;
f32 getPosRatio(const Vector3f& point) ;
Vector3f mStartPoint;
Vector3f mEndPoint;
f32 mRadius;
};
class RectArea {
public:
RectArea(int x0, int y0, int x1, int y1)
{
mMinX = x0;
mMinY = y0;
mMaxX = x1;
mMaxY = y1;
}
RectArea()
{
mMinY = mMaxY = 0;
mMinX = mMaxX = 0;
}
void set(int minX, int minY, int maxX, int maxY)
{
mMinX = minX;
mMinY = minY;
mMaxX = maxX;
mMaxY = maxY;
}
int width() { return mMaxX - mMinX; }
int height() { return mMaxY - mMinY; }
bool pointInside(int, int) ;
int mMinX;
int mMinY;
int mMaxX;
int mMaxY;
};
class Sphere {
public:
Sphere( Vector3f& centre, f32 radius)
: mCentre(centre)
, mRadius(radius)
{
}
Vector3f mCentre;
f32 mRadius;
};
class Tube {
public:
Tube( Vector3f& start, Vector3f& end, f32 startRad, f32 endRad)
: mStartPoint(start)
, mEndPoint(end)
, mStartRadius(startRad)
, mEndRadius(endRad)
{
}
Tube() { }
f32 getYRatio(f32 heightToCheck) ;
bool collide(const Sphere&, Vector3f&, f32&) ;
f32 getPosRatio(const Vector3f&) ;
void getPosGradient( Vector3f&, f32, Vector3f&, Vector3f&) ;
Vector3f setPos(f32) ;
f32 getRatioRadius(f32) ;
Vector3f mStartPoint;
Vector3f mEndPoint;
f32 mStartRadius;
f32 mEndRadius;
};
class Texture;
class FontChar {
public:
FontChar()
{
mTextureX = mTextureY = 0;
mWidth = mHeight = 8;
}
u16 mTextureX;
u16 mTextureY;
s16 mWidth;
s16 mHeight;
s16 mCharSpacing;
s16 mLeftOffset;
RectArea mTextureCoords;
};
class Font {
public:
void setTexture(Texture*, int, int);
int charToIndex(char);
int stringWidth( char*);
int charToIndex(u16);
int stringHeight( char* str) { return mCharHeight; }
Texture* mTexture;
int mCharWidth;
int mCharHeight;
FontChar* mChars;
};
class FntobjInfo : public GfxobjInfo {
public:
FntobjInfo() { mFont = 0 ; }
Font* mFont;
};
class P2DFont {
public:
P2DFont( char*);
Font* loadFont( char* fileName, int&, int&);
void setGX();
void setGradColor(const Colour& topColour, const Colour& bottomColour);
f32 getWidth(int charCode, int drawWidth);
f32 drawChar(f32 xPos, f32 yPos, int charCode, int drawWidth, int drawHeight);
int charToIndex(int c);
int getHeight() { return mFont->mCharHeight; }
int getNormalWidth() { return mWidth; }
u16 getWidth() { return mWidth; }
u16 getLeading() { return mLeading; }
u16 getFontType() { return mFontType; }
int getAscent() { return mAscent; }
int getDescent() { return mDescent; }
u8 getAlpha() { return mTLColour.a; }
void makeResident() { mFont->mTexture->makeResident(); }
void loadFontTexture()
{
mFont->mTexture->makeResident();
GXLoadTexObj(mFont->mTexture->mTexObj, GX_TEXMAP0);
}
Font* mFont;
u16 mFontType;
u16 mWidth;
u16 mLeading;
u16 mAscent;
u16 mDescent;
Colour mTLColour;
Colour mTRColour;
Colour mBLColour;
Colour mBRColour;
};
enum P2DBinding {
P2DBIND_Unk0 = 0x1,
P2DBIND_Unk1 = 0x2,
P2DBIND_Unk2 = 0x4,
P2DBIND_Unk3 = 0x8,
P2DBIND_All = P2DBIND_Unk0 | P2DBIND_Unk1 | P2DBIND_Unk2 | P2DBIND_Unk3,
};
enum P2DMirror {
P2DMIRROR_Unk0 = 0,
P2DMIRROR_Unk1 = 1,
P2DMIRROR_Unk2 = 2,
};
enum P2DWrapmode {
P2DWRAP_NULL = -1,
P2DWRAP_Unk0 = 0,
};
enum P2DRotateAxis {
P2DROTATE_Unk1 = 1,
P2DROTATE_Unk2 = 2,
P2DROTATE_X = 'x',
P2DROTATE_Y = 'y',
P2DROTATE_Z = 'z',
};
enum P2DTextBoxHBinding {
TBOXHBIND_Center = 0,
TBOXHBIND_Right = 1,
TBOXHBIND_Left = 2,
};
enum P2DTextBoxVBinding {
TBOXVBIND_Center = 0,
TBOXVBIND_Bottom = 1,
TBOXVBIND_Top = 2,
};
class P2DFont;
struct P2DPrint {
public:
struct TSize {
f32 mTotalWidth;
f32 mTotalHeight;
f32 mWidthFromStart;
f32 mHeightFromStart;
};
void setFontSize(int width, int height)
{
mFontWidth = width > 0 ? width : 0;
mFontHeight = height > 0 ? height : 0;
}
f32 getCursorH() { return mCursorX; }
f32 getCursorV() { return mCursorY; }
P2DPrint(P2DFont* font, int spacing, int leading, Colour topColour, Colour bottomColour);
void printReturn(const char* textBuffer, int, int, P2DTextBoxHBinding, P2DTextBoxVBinding, int, int);
void locate(int x, int y);
void setFontSize();
private:
void private_initiate(P2DFont* font, int spacing, int leading, Colour topColour, Colour bottomColour);
void initchar();
f32 parse(const u8* textBuffer, int textLen, int maxWidth, u16* outLineWidths, P2DPrint::TSize& textSize, bool doDraw);
u16 doEscapeCode(const u8** textPtr);
void doCtrlCode(int charCode);
s32 getNumber(const u8** textPtr, s32 defaultValue, s32 invalidValue, int base);
void u32ToColour(u32 value, Colour* outColour)
{
outColour->set(((u8*)&value)[0], ((u8*)&value)[1], ((u8*)&value)[2], ((u8*)&value)[3]);
}
u32 ColourTou32(const Colour& colour) { return colour.r << 24 | colour.g << 16 | colour.b << 8 | colour.a; }
P2DFont* mFont;
int mFontSpacing;
int mFontLeading;
bool mFontGradientActive;
bool mSkipEscCtrlCodes;
int mInitX;
int mInitY;
f32 mCursorX;
f32 mCursorY;
f32 mCurrCharWidth;
Colour mCharTopColour;
Colour mFontTopColour;
Colour mCharBottomColour;
Colour mFontBottomColour;
int mFontTabWidth;
int mFontWidth;
int mFontHeight;
int mCharSpacing;
int mCharLeading;
bool mCharGradientActive;
int mCharTabWidth;
int mCharWidth;
int mCharHeight;
};
void P2DPrint::doCtrlCode(int inputChar)
{
switch (inputChar) {
case '\b':
{
mCursorX -= mCurrCharWidth;
mCurrCharWidth = 0.0f;
break;
}
case '\t':
{
int width = mCharTabWidth;
if (width > 0) {
f32 oldX = mCursorX;
mCursorX = f32(width + width * ((int)mCursorX / width));
mCurrCharWidth = mCursorX - oldX;
}
break;
}
case '\n':
{
mCurrCharWidth = 0.0f;
mCursorX = mInitX;
mCursorY = mCursorY + mCharLeading;
break;
}
case '\r':
{
mCurrCharWidth = 0.0f;
mCursorX = mInitX;
break;
}
case '\x1C':
{
mCursorX += 1.0f;
break;
}
case '\x1D':
{
mCursorX -= 1.0f;
break;
}
case '\x1E':
{
mCursorY -= 1.0f;
break;
}
case '\x1F':
{
mCursorY += 1.0f;
break;
}
}
}
