
typedef unsigned int uint;
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef long double f128;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef volatile f128 vf128;
typedef int BOOL;
inline void padStack(void)
{
int pad = 0;
}
extern "C"{
typedef struct Vec {
f32 x;
f32 y;
f32 z;
} Vec;
typedef struct SVec {
s16 x;
s16 y;
s16 z;
} SVec;
void C_VECAdd(const Vec* a, const Vec* b, Vec* ab);
void PSVECAdd(const Vec* a, const Vec* b, Vec* ab);
void C_VECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void PSVECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void C_VECScale(const Vec* src, Vec* dst, f32 scale);
void PSVECScale(const Vec* src, Vec* dst, f32 scale);
void C_VECNormalize(const Vec* src, Vec* unit);
void PSVECNormalize(const Vec* src, Vec* unit);
f32 C_VECSquareMag(const Vec* v);
f32 PSVECSquareMag(const Vec* v);
f32 VECMag (const Vec* v);
f32 PSVECMag(const Vec* v);
f32 C_VECDotProduct(const Vec* a, const Vec* b);
f32 PSVECDotProduct(const Vec* a, const Vec* b);
void C_VECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void PSVECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void VECHalfAngle (const Vec* a, const Vec* b, Vec* half);
void VECReflect (const Vec* src, const Vec* normal, Vec* dst);
f32 C_VECSquareDistance(const Vec* a, const Vec* b);
f32 PSVECSquareDistance(const Vec* a, const Vec* b);
f32 VECDistanc (const Vec* a, const Vec* b);
f32 PSVECDistance(const Vec* a, const Vec* b);
}
extern "C"{
typedef f32 Mtx[3][4];
typedef f32 Mtx23[2][3];
typedef f32 Mtx33[3][3];
typedef f32 Mtx44[4][4];
typedef f32 (*MtxPtr)[4];
typedef f32 (*Mtx23Ptr)[2];
typedef f32 (*Mtx33Ptr)[3];
typedef f32 (*Mtx44Ptr)[4];
typedef f32 PSQuaternion[4];
typedef struct Quaternion {
f32 x, y, z, w;
} Quaternion;
void C_MTXIdentity(Mtx m);
void PSMTXIdentity(Mtx m);
void C_MTXCopy(const Mtx src, Mtx dst);
void PSMTXCopy(const Mtx src, Mtx dst);
void C_MTXConcat(const Mtx a, const Mtx b, Mtx dst);
void PSMTXConcat(const Mtx a, const Mtx b, Mtx dst);
void C_MTXTranspose(const Mtx src, Mtx xPose);
void PSMTXTranspose(const Mtx src, Mtx xPose);
u32 C_MTXInverse(const Mtx src, Mtx inv);
u32 PSMTXInverse(const Mtx src, Mtx inv);
u32 C_MTXInvXpose(const Mtx src, Mtx inv);
u32 PSMTXInvXpose(const Mtx src, Mtx inv);
void MTXRotRad (Mtx m, char axis, f32 rad);
void PSMTXRotRad(Mtx m, char axis, f32 rad);
void MTXRotTrig (Mtx m, char axis, f32 sinA, f32 cosA);
void PSMTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void MTXRotAxisRad (Mtx m, const Vec* axis, f32 rad);
void PSMTXRotAxisRad(Mtx m, const Vec* axis, f32 rad);
void MTXTrans (Mtx m, f32 xT, f32 yT, f32 zT);
void PSMTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void MTXTransApply (const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void PSMTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void MTXScale (Mtx m, f32 xS, f32 yS, f32 zS);
void PSMTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void MTXScaleApply (const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void PSMTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void MTXQuat (Mtx m, const Quaternion* quat);
void PSMTXQuat(Mtx m, const Quaternion* quat);
void MTXReflect (Mtx m, const Vec* p, const Vec* n);
void PSMTXReflect(Mtx m, const Vec* p, const Vec* n);
void MTXLookAt (Mtx m, const Vec* camPos, const Vec* camUp, const Vec* target);
void MTXLightFrustum (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightPerspective (Mtx m, f32 fovY, f32 aspect, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightOrtho (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXFrustum (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void MTXPerspective (Mtx44 m, f32 fovY, f32 aspect, f32 n, f32 f);
void MTXOrtho (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTX44Identity(Mtx44 m);
void PSMTX44Identity(Mtx44 m);
void C_MTX44Copy(const Mtx44 src, Mtx44 dst);
void PSMTX44Copy(const Mtx44 src, Mtx44 dst);
void C_MTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void PSMTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void C_MTX44Transpose(const Mtx44 src, Mtx44 xPose);
void PSMTX44Transpose(const Mtx44 src, Mtx44 xPose);
u32 C_MTX44Inverse(const Mtx44 src, Mtx44 inv);
void C_MTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void PSMTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void C_MTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void PSMTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void C_MTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void PSMTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void C_MTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void PSMTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void C_MTX44RotRad(Mtx44 m, char axis, f32 rad);
void PSMTX44RotRad(Mtx44 m, char axis, f32 rad);
void C_MTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void PSMTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void C_MTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
void PSMTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
static inline void MTXSetPosition(Mtx mtx, const Vec* pos)
{
mtx[0][3] = pos->x;
mtx[1][3] = pos->y;
mtx[2][3] = pos->z;
}
}
extern "C"{
typedef unsigned long size_t;
}
extern "C"{
void* memcpy(void*, const void*, size_t);
void __fill_mem(void*, int, size_t);
void* memset(void*, int, size_t);
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, u8 type);
}
extern "C"{
int memcmp(const void*, const void*, size_t);
void* memchr(u8*, int, size_t);
void* memmove(void*, const void*, size_t);
void* memcpy(void* dest, const void* src, size_t n);
void* memset(void* dest, int val, size_t count);
}
extern "C"{
int stricmp(const char*, const char*);
}
extern "C"{
char* strcpy(char* dst, const char* src);
char* strncpy(char* dst, const char* src, size_t n);
char* strcat(char* dst, const char* src);
char* strncat(char* dst, const char* src, size_t n);
int strcmp(const char* lhs, const char* rhs);
int strncmp(const char* lhs, const char* rhs, size_t n);
char* strchr(const char* str, int ch);
char* strstr(const char* str, const char* substr);
char* strrchr(const char* str, int chr);
size_t strlen(const char* str);
}
class String;
class Stream {
public:
Stream() { }
char* mPath;
virtual int readInt();
virtual u8 readByte();
virtual short readShort();
virtual f32 readFloat();
virtual void readString(char*, int);
virtual void readString(String&);
virtual char* readString();
virtual void writeInt(int);
virtual void writeByte(u8);
virtual void writeShort(short);
virtual void writeFloat(f32);
virtual void writeString( char*);
virtual void writeString( String&);
virtual void read(void*, int);
virtual void write( void*, int);
virtual int getPending();
virtual int getAvailable();
virtual void close();
virtual bool getClosing() { return false; }
virtual void flush() { }
void print( char*, ...);
void vPrintf( char*, va_list);
};
class RandomAccessStream : public Stream {
public:
virtual int getPosition() { return 0; }
virtual int getPending() { return getLength() - getPosition(); }
virtual void setPosition(int) { }
virtual int getLength() { return getAvailable(); }
void skipPadding(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
readByte();
}
}
void padFile(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
void padFileTo(u32 paddingAmount, u32 offset)
{
int position = getPosition();
int count = paddingAmount - position - offset;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
inline BOOL checkInput()
{
if (readByte() == 0) {
return false;
}
return true;
}
void writeTo(int, void*, int);
void readFrom(int, void*, int);
void writeIntTo(int, int);
int readIntFrom(int);
};
class AlignedStream : public RandomAccessStream {
public:
virtual void read(void*, int);
virtual void write( void*, int);
virtual void alignedWrite( void*, int) = 0;
virtual void alignedRead(void*, int) = 0;
int mAlignment;
};
class BufferedInputStream : public RandomAccessStream {
public:
BufferedInputStream()
{
mBuffer = 0 ;
mStream = 0 ;
}
BufferedInputStream(Stream*, u8*, int);
virtual void read(void*, int);
virtual int getPending() { return mStream->getPending() - mPosition; }
virtual void close() { mStream->close(); }
virtual int getPosition() { return mPosition; }
void init(Stream*, u8*, int);
void fillBuffer();
u8* mBuffer;
int mBufferSize;
int mRemainingBytes;
int mCurrentBufferPos;
int mPosition;
Stream* mStream;
};
class RamStream : public RandomAccessStream {
public:
inline RamStream(void* buffer, int size)
{
mBufferAddr = buffer;
mPosition = 0;
mLength = size;
}
virtual int getPending() { return mLength - mPosition; }
virtual void setPosition(int pos) { mPosition = pos; }
virtual int getPosition() { return mPosition; }
virtual int getLength() { return mLength; }
virtual void setLength(int len) { mLength = len; }
virtual void read(void* dest, int size)
{
memcpy(dest, (char*)mBufferAddr + mPosition, size);
mPosition += size;
}
virtual void write( void* src, int size)
{
memcpy((char*)mBufferAddr + mPosition, src, size);
mPosition += size;
}
void* mBufferAddr;
int mPosition;
int mLength;
};
extern Stream* sysCon;
extern Stream* errCon;
extern "C"{
extern const f32 __float_huge[];
extern const f32 __float_nan[];
extern const f64 __double_huge[];
extern const f64 __double_nan[];
f64 cos(f64);
f32 cosf(f32);
f64 sin(f64);
f32 sinf(f32);
f64 tan(f64);
f32 tanf(f32);
f64 acos(f64);
f32 acosf(f32);
f64 asin(f64);
f64 atan(f64);
f32 atanf(f32);
f64 atan2(f64, f64);
f32 atan2f(f32, f32);
f64 ceil(f64);
f64 floor(f64);
f64 frexp(f64, int*);
f64 ldexp(f64, int);
f64 sqrt(f64);
f64 pow(f64, f64);
f64 log(f64);
f64 log10(f64);
f64 fmod(f64, f64);
f64 scalbn(f64, int);
inline f128 fabsl(f128 x)
{
return __fabs((f64)x);
}
inline f32 sqrtf(f32 x)
{
static const f64 _half = .5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
}
namespace std {
inline f32 sqrtf(f32 x)
{
static const f64 _half = 0.5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
inline f32 fmodf(f32 x, f32 m)
{
f32 b, a;
a = __fabsf(m) ;
b = __fabsf(x) ;
if (a > b) {
return x;
}
long long c = (long long)(x / m);
return x - m * c;
}
}
inline f32 fmod(f32 x, f32 m)
{
return std::fmodf(x, m);
}
class Vector3f;
class BoundBox;
class KTri;
class KRect;
class KSegment;
static inline f32 quickABS(f32 x)
{
*reinterpret_cast<u32*>(&x) &= ~0x80000000;
return x;
}
static inline f32 u32ToFloat(u32 a)
{
union {
u32 w;
f32 f;
} tmp;
tmp.w = a;
return tmp.f;
}
inline f32 absF(f32 val)
{
return (f32)__fabsf(val) ;
}
inline f32 absVal(f32 val)
{
if (val > 0.0f) {
return val;
}
return -val;
}
f32 roundAng(f32 angle);
f32 angDist(f32 x, f32 z);
f32 qdist2(f32 x0, f32 z0, f32 x1, f32 z1);
f32 triRectDistance( Vector3f*, Vector3f*, Vector3f*, BoundBox&, bool);
f32 distanceTriRect(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KTri&, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KSegment&, f32*, f32*);
f32 sqrDistance(KSegment&, KRect&, f32*, f32*, f32*);
f32 sqrDistance(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance( Vector3f&, KTri&, f32*, f32*);
f32 qdist3(f32 x0, f32 y0, f32 z0, f32 x1, f32 y1, f32 z1);
inline f32 speedy_sqrtf(f32 x)
{
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte(x) ;
y = (f32)(x * guess);
return y;
}
return x;
}
class AgeServer;
class Matrix3f;
class Matrix4f;
class Quat;
class Vector3f {
public:
Vector3f() { x = y = z = 0.0f; }
Vector3f(const f32& _x, const f32& _y, const f32& _z)
: x(_x)
, y(_y)
, z(_z)
{
}
Vector3f(const Vector3f& other)
{
x = other.x;
y = other.y;
z = other.z;
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
z = stream.readFloat();
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
stream.writeFloat(z);
}
void set(const f32& pX, const f32& pY, const f32& pZ)
{
x = pX;
y = pY;
z = pZ;
}
void set(const Vector3f& other) { set(other.x, other.y, other.z); }
void input( Vector3f& other) { set(other.x, other.y, other.z); }
void output(Vector3f& outVec) { outVec.set(x, y, z); }
f32 length() { return std::sqrtf((x * x) + (y * y) + (z * z) ); }
f32 squaredLength() { return (x * x) + (y * y) + (z * z) ; }
f32 DP( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 dot( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 distance( Vector3f& to)
{
Vector3f result;
result.sub2(to, *this);
return result.length();
}
f32 normalise()
{
f32 norm = length();
if (norm != 0.0f) {
div(norm);
}
return norm;
}
void CP( Vector3f& other)
{
Vector3f tmp;
tmp.x = y * other.z - z * other.y;
tmp.y = z * other.x - x * other.z;
tmp.z = x * other.y - y * other.x;
x = tmp.x;
y = tmp.y;
z = tmp.z;
}
void cross( Vector3f& vec1, Vector3f& vec2)
{
set(vec1.y * vec2.z - vec1.z * vec2.y, vec1.z * vec2.x - vec1.x * vec2.z, vec1.x * vec2.y - vec1.y * vec2.x);
}
void add( Vector3f& other)
{
x += other.x;
y += other.y;
z += other.z;
}
void add2( Vector3f& a, Vector3f& b) { set(a.x + b.x, a.y + b.y, a.z + b.z); }
void sub( Vector3f& other)
{
x -= other.x;
y -= other.y;
z -= other.z;
}
void sub( Vector3f& a, Vector3f& b)
{
x = a.x - b.x;
y = a.y - b.y;
z = a.z - b.z;
}
void sub2( Vector3f& a, Vector3f& b) { set(a.x - b.x, a.y - b.y, a.z - b.z); }
void div(f32 divisor)
{
x /= divisor;
y /= divisor;
z /= divisor;
}
void multiply(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale2(f32 scale, Vector3f& vec)
{
x = scale * vec.x;
y = scale * vec.y;
z = scale * vec.z;
}
void negate()
{
x = -x;
y = -y;
z = -z;
}
void bounce( Vector3f& surface, f32 elasticity)
{
f32 dp = -DP(surface) * elasticity;
if (dp > 0.0f) {
x = surface.x * dp + x;
y = surface.y * dp + y;
z = surface.z * dp + z;
}
}
void lerpTo( Vector3f& other, f32 t, Vector3f& outVec)
{
outVec.x = (other.x - x) * t + x;
outVec.y = (other.y - y) * t + y;
outVec.z = (other.z - z) * t + z;
}
void rotate( Matrix4f&);
void rotateTo( Matrix4f&, Vector3f&);
void multMatrix( Matrix4f&);
void multMatrixTo( Matrix4f&, Vector3f&);
void rotateTranspose( Matrix4f&);
void rotate( Quat&);
void rotateInverse( Quat&);
void normalize() { normalise(); }
void project( Vector3f& dirToRemove)
{
f32 projAmt = DP(dirToRemove);
x = -(projAmt * dirToRemove.x - x);
y = -(projAmt * dirToRemove.y - y);
z = -(projAmt * dirToRemove.z - z);
}
void middle( Vector3f& a, Vector3f& b)
{
add2(a, b);
scale(0.5f);
}
bool isSame( Vector3f& other)
{
return __fabsf(x - other.x) < 0.0001f && __fabsf(y - other.y) < 0.0001f && __fabsf(z - other.z) < 0.0001f;
}
void add( Vector3f& a, Vector3f& b)
{
x = a.x + b.x;
y = a.y + b.y;
z = a.z + b.z;
}
void add(f32 _x, f32 _y, f32 _z)
{
x += _x;
y += _y;
z += _z;
}
f32 x;
f32 y;
f32 z;
};
class Vector2f {
public:
Vector2f() { }
Vector2f(const f32& _x, const f32& _y)
{
x = _x;
y = _y;
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
}
void set(f32 _x, f32 _y)
{
x = _x;
y = _y;
}
f32 x, y;
};
class Vector2i {
public:
void read(Stream& stream)
{
x = stream.readInt();
y = stream.readInt();
}
void write(Stream& stream)
{
stream.writeInt(x);
stream.writeInt(y);
}
void set(int _x, int _y)
{
x = _x;
y = _y;
}
int x, y;
};
class Quat {
public:
Quat() { }
Quat(f32 _x, f32 _y, f32 _z, f32 _s) { set(_x, _y, _z, _s); }
void fromMat3f( Matrix3f&);
void rotate( Vector3f&, f32);
void multiply( Quat&);
void normalise();
void genVectorX(Vector3f&) ;
void genVectorY(Vector3f&) ;
void genVectorZ(Vector3f&) ;
void slerp( Quat&, f32, int);
void fromEuler( Vector3f&);
void multiplyTo( Quat&, Quat&);
void set(f32 _x, f32 _y, f32 _z, f32 _s)
{
v.x = _x;
v.y = _y;
v.z = _z;
s = _s;
}
Vector3f v;
f32 s;
};
inline Vector3f operator*(const Vector3f& a, const f32& b)
{
return Vector3f(a.x * b, a.y * b, a.z * b);
}
inline Vector3f operator*(const f32& a, const Vector3f& b)
{
return b * a;
}
inline Vector3f operator+(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x + b.x, a.y + b.y, a.z + b.z);
}
inline Vector3f operator-(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x - b.x, a.y - b.y, a.z - b.z);
}
inline Vector3f operator-(const Vector3f& a)
{
return Vector3f(-a.x, -a.y, -a.z);
}
inline Vector3f operator/(const Vector3f& a, const f32& b)
{
return a * (1.0f / b);
}
inline Vector3f CP(const Vector3f& a, const Vector3f& b)
{
f32 x = a.y * b.z - a.z * b.y;
f32 y = a.z * b.x - a.x * b.z;
f32 z = a.x * b.y - a.y * b.x;
return Vector3f(x, y, z);
}
class SRT {
public:
SRT() { }
SRT(const SRT& other)
: s(other.s)
, r(other.r)
, t(other.t)
{
}
Vector3f s;
Vector3f r;
Vector3f t;
};
class Plane;
class Matrix4f {
public:
Matrix4f() { }
Matrix4f( Mtx44);
void makeIdentity();
void makeRotate( Vector3f&, f32, f32);
void makeRotate( Vector3f&, f32);
void multiply( Matrix4f&);
void multiplyTo( Matrix4f&, Matrix4f&) ;
void makeSRT( Vector3f&, Vector3f&, Vector3f&);
void makeConcatSRT( Matrix4f*, Matrix4f&, SRT&);
void inverse(Matrix4f*);
void scale( Vector3f&);
void makeLookat( Vector3f& cameraPos, Vector3f& targetPos, Vector3f* optionalUp);
void makeLookat( Vector3f& cameraPos, Vector3f& rightDir, Vector3f& upDir, Vector3f& backDir);
void transposeTo(Matrix4f&);
void makeVQS( Vector3f&, Quat&, Vector3f&);
void blend( Matrix4f&, f32);
void makeOrtho(f32, f32, f32, f32, f32, f32, f32);
void makePerspective(f32 fovY, f32 aspectRatio, f32 nearZ, f32 farZ);
void makeBallRotate(Vector3f&);
void rotate(Vector3f&, f32);
void rotate(Vector3f&);
void rotate(f32, f32, f32);
void makeAligned(Vector3f&, f32);
void rotateX(f32);
void rotateY(f32);
void rotateZ(f32);
void translate(f32, f32, f32);
void makeLookfrom( Vector3f&, Vector3f&);
void makeProjection(Vector3f&, Plane&);
void makeReflection(Plane&);
void makeBillVector(Vector3f&, Matrix4f&, Vector3f&);
void makeSRT(SRT srt) { makeSRT(srt.s, srt.r, srt.t); }
inline void set( Matrix4f& other)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = other.mMtx[i][j];
}
}
}
inline void set(f32 value)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = value;
}
}
}
void getRow(int rowNum, Vector3f& row) { row.set(mMtx[rowNum][0], mMtx[rowNum][1], mMtx[rowNum][2]); }
void getColumn(int colNum, Vector3f& col) { col.set(mMtx[0][colNum], mMtx[1][colNum], mMtx[2][colNum]); }
void setRow(int rowNum, const Vector3f& row)
{
mMtx[rowNum][0] = row.x;
mMtx[rowNum][1] = row.y;
mMtx[rowNum][2] = row.z;
}
void setColumn(int colNum, const Vector3f& col)
{
mMtx[0][colNum] = col.x;
mMtx[1][colNum] = col.y;
mMtx[2][colNum] = col.z;
}
void setTranslation( Vector3f& trans)
{
mMtx[0][3] = trans.x;
mMtx[1][3] = trans.y;
mMtx[2][3] = trans.z;
}
void setTranslation(f32 x, f32 y, f32 z)
{
mMtx[0][3] = x;
mMtx[1][3] = y;
mMtx[2][3] = z;
}
static Matrix4f ident;
Mtx44 mMtx;
};
extern f32 sintable[0x1000];
extern f32 costable[0x1000];
static inline f32 sinShort(u16 x)
{
return sintable[(x >> 4) & 0xFFF];
}
static inline f32 cosShort(u16 x)
{
return costable[(x >> 4) & 0xFFF];
}
