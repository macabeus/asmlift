
typedef unsigned int uint;
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef long double f128;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef volatile f128 vf128;
typedef int BOOL;
inline void padStack(void)
{
int pad = 0;
}
extern "C"{
typedef struct OSContext {
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
f64 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
void OSLoadContext(OSContext* context);
void OSClearContext(OSContext* context);
void OSInitContext(OSContext* context, u32 pc, u32 stackPtr);
void OSDumpContext(OSContext* context);
u32 OSSaveContext(OSContext* context);
u32 OSGetStackPointer();
OSContext* OSGetCurrentContext();
void OSSetCurrentContext(OSContext* context);
void OSSaveFPUContext(OSContext* context);
void OSFillFPUContext(OSContext* context);
u32 OSSwitchStack(u32 newStackPtr);
int OSSwitchFiber(u32 pc, u32 newStackPtr);
void OSLoadFPUContext(OSContext* context);
}
extern "C"{
}
extern "C"{
typedef unsigned long size_t;
}
extern "C"{
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef s32 OSPriority;
typedef void (*OSIdleFunction)(void* param);
typedef void* (*OSThreadStartFunction)(void*);
typedef void (*OSSwitchThreadCallback)(OSThread* from, OSThread* to);
struct OSThreadQueue {
OSThread* head;
OSThread* tail;
};
struct OSThreadLink {
OSThread* next;
OSThread* prev;
};
struct OSMutexQueue {
OSMutex* head;
OSMutex* tail;
};
struct OSMutexLink {
OSMutex* next;
OSMutex* prev;
};
struct OSThread {
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void* val;
OSThreadQueue* queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex* mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8* stackBase;
u32* stackEnd;
s32 error;
};
extern volatile OSContext* __OSCurrentContext : ((u32)((void*)((u32)(0x00D4) + (0x80000000)))) ;
extern volatile OSContext* __OSFPUContext : ((u32)((void*)((u32)(0x00D8) + (0x80000000)))) ;
extern OSThreadQueue __OSActiveThreadQueue : ((u32)((void*)((u32)(0x00DC) + (0x80000000)))) ;
extern OSThread* __OSCurrentThread : ((u32)((void*)((u32)(0x00E4) + (0x80000000)))) ;
void OSInitThreadQueue(OSThreadQueue* queue);
OSThread* OSGetCurrentThread();
BOOL OSIsThreadTerminated(OSThread* thread);
s32 OSDisableScheduler();
s32 OSEnableScheduler();
void OSYieldThread();
BOOL OSCreateThread(OSThread* thread, OSThreadStartFunction func, void* param, void* stack, u32 stackSize, OSPriority priority, u16 attr);
void OSExitThread(void* val);
void OSCancelThread(OSThread* thread);
void OSDetachThread(OSThread* thread);
s32 OSResumeThread(OSThread* thread);
s32 OSSuspendThread(OSThread* thread);
void OSSleepThread(OSThreadQueue* queue);
void OSWakeupThread(OSThreadQueue* queue);
void OSClearStack(u8 val);
OSPriority OSGetThreadPriority(OSThread* thread);
BOOL OSIsThreadSuspended(OSThread* thread);
BOOL OSJoinThread(OSThread* thread, void** val);
BOOL OSSetThreadPriority(OSThread* thread, OSPriority prio);
OSThread* OSSetIdleFunction(OSIdleFunction idleFunc, void* param, void* stack, u32 stackSize);
OSThread* OSGetIdleFunction();
s32 OSCheckActiveThreads();
void __OSReschedule(void);
OSPriority __OSGetEffectivePriority(OSThread* thread);
void __OSPromoteThread(OSThread* thread, OSPriority priority);
enum OS_THREAD_STATE {
OS_THREAD_STATE_NULL = 0,
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8,
};
}
extern "C"{
struct OSMutex {
OSThreadQueue queue;
OSThread* thread;
int count;
OSMutexLink link;
};
typedef struct OSCond {
OSThreadQueue queue;
} OSCond;
void OSInitMutex(OSMutex* mutex);
void OSLockMutex(OSMutex* mutex);
void OSUnlockMutex(OSMutex* mutex);
BOOL OSTryLockMutex(OSMutex* mutex);
void __OSUnlockAllMutex(OSThread* thread);
BOOL __OSCheckMutex(OSMutex* mutex);
BOOL __OSCheckDeadLock(OSThread* thread);
BOOL __OSCheckMutexes(OSThread* thread);
void OSInitCond(OSCond* cond);
void OSWaitCond(OSCond* cond, OSMutex* mutex);
void OSSignalCond(OSCond* cond);
}
extern "C"{
typedef u8 __OSException;
typedef void (*__OSExceptionHandler)(__OSException exception, OSContext* context);
__OSExceptionHandler __OSSetExceptionHandler(__OSException exception, __OSExceptionHandler handler);
__OSExceptionHandler __OSGetExceptionHandler(__OSException exception);
}
extern "C"{
typedef s64 OSTime;
typedef u32 OSTick;
extern u32 __OSBusClock : ((0x80000000) | 0x00F8) ;
extern u32 __OSCoreClock : ((0x80000000) | 0x00FC) ;
OSTime __OSGetSystemTime();
OSTick OSGetTick();
OSTime OSGetTime();
typedef struct OSCalendarTime {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* timeDate);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* timeDate);
}
extern "C"{
typedef s16 __OSInterrupt;
typedef void (*__OSInterruptHandler)(__OSInterrupt interrupt, OSContext* context);
typedef u32 OSInterruptMask;
extern volatile __OSInterrupt __OSLastInterrupt;
extern vu32 __OSLastInterruptSrr0;
extern volatile OSTime __OSLastInterruptTime;
extern volatile OSInterruptMask __OSPriorInterruptMask : ((u32)((void*)((u32)(0x00C4) + (0x80000000)))) ;
extern volatile OSInterruptMask __OSCurrentInterruptMask : ((u32)((void*)((u32)(0x00C8) + (0x80000000)))) ;
__OSInterruptHandler __OSSetInterruptHandler(__OSInterrupt interrupt, __OSInterruptHandler handler);
__OSInterruptHandler __OSGetInterruptHandler(__OSInterrupt interrupt);
void __OSDispatchInterrupt(__OSException exception, OSContext* context);
BOOL OSEnableInterrupts();
BOOL OSDisableInterrupts();
BOOL OSRestoreInterrupts(BOOL enabled);
OSInterruptMask __OSMaskInterrupts(OSInterruptMask mask);
OSInterruptMask __OSUnmaskInterrupts(OSInterruptMask mask);
OSInterruptMask OSGetInterruptMask();
OSInterruptMask OSSetInterruptMask(OSInterruptMask mask);
void __RAS_OSDisableInterrupts_begin();
void __RAS_OSDisableInterrupts_end();
}
extern "C"{
typedef struct STRUCT_DSP_TASK DSPTaskInfo;
typedef void (*DSPCallback)(void* task);
struct STRUCT_DSP_TASK {
vu32 state;
vu32 priority;
vu32 flags;
u16* iram_mmem_addr;
u32 iram_length;
u32 iram_addr;
u16* dram_mmem_addr;
u32 dram_length;
u32 dram_addr;
u16 dsp_init_vector;
u16 dsp_resume_vector;
DSPCallback init_cb;
DSPCallback res_cb;
DSPCallback done_cb;
DSPCallback req_cb;
DSPTaskInfo* next;
DSPTaskInfo* prev;
OSTime t_context;
OSTime t_task;
};
extern DSPTaskInfo* __DSP_tmp_task;
extern DSPTaskInfo* __DSP_last_task;
extern DSPTaskInfo* __DSP_first_task;
extern DSPTaskInfo* __DSP_curr_task;
void __DSP_exec_task(DSPTaskInfo* curr, DSPTaskInfo* next);
void __DSP_boot_task(DSPTaskInfo* task);
void __DSP_remove_task(DSPTaskInfo* task);
void __DSP_insert_task(DSPTaskInfo* task);
void __DSP_debug_printf(const char* format, ...);
void DSPInit();
void DSPAssertInt();
void DSPSendMailToDSP(u32 mail);
u32 DSPReadMailFromDSP();
u32 DSPCheckMailToDSP();
u32 DSPCheckMailFromDSP();
void __DSPHandler(__OSInterrupt interrupt, OSContext* context);
void __DSP_add_task(DSPTaskInfo* task);
void DSPHalt();
void DSPReset();
DSPTaskInfo* DSPAddTask(DSPTaskInfo*);
}
typedef void (*CommandTask)(u16);
extern "C"{
typedef struct OSAlarm OSAlarm;
typedef struct OSAlarmQueue OSAlarmQueue;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm {
OSAlarmHandler handler;
u32 tag;
OSTime fire;
OSAlarm* prev;
OSAlarm* next;
OSTime period;
OSTime start;
};
struct OSAlarmQueue {
OSAlarm* head;
OSAlarm* tail;
};
void OSInitAlarm();
void OSSetAlarm(OSAlarm* alarm, OSTime tick, OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm* alarm);
void OSCancelAlarm(OSAlarm* alarm);
BOOL OSCheckAlarmQueue();
void OSSetAbsAlarm(OSAlarm* alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm* alarm, OSTime start, OSTime period, OSAlarmHandler handler);
void OSSetAlarmTag(OSAlarm* alarm, u32 tag);
void OSCancelAlarms(u32 tag);
}
extern "C"{
typedef int OSHeapHandle;
typedef void (*OSAllocVisitor)(void* obj, u32 size);
extern volatile OSHeapHandle __OSCurrHeap;
void* OSInitAlloc(void* arenaStart, void* arenaEnd, int maxHeaps);
OSHeapHandle OSCreateHeap(void* start, void* end);
OSHeapHandle OSSetCurrentHeap(OSHeapHandle heap);
void OSFreeToHeap(OSHeapHandle heap, void* ptr);
void* OSAllocFromHeap(OSHeapHandle heap, u32 size);
}
extern "C"{
void* OSGetArenaHi(void);
void* OSGetArenaLo(void);
void OSSetArenaHi(void* addr);
void OSSetArenaLo(void* addr);
}
extern "C"{
typedef struct DVDCommandBlock DVDCommandBlock;
typedef struct DVDFileInfo DVDFileInfo;
typedef void (*DVDCallback)(s32 result, DVDFileInfo* fileInfo);
typedef void (*DVDCBCallback)(s32 result, DVDCommandBlock* block);
typedef void (*DVDLowCallback)(u32 intType);
typedef void (*DVDDoneReadCallback)(s32, DVDFileInfo*);
typedef void (*DVDOptionalCommandChecker)(DVDCommandBlock* block, DVDLowCallback callback);
typedef struct DVDDriveInfo {
u16 revisionLevel;
u16 deviceCode;
u32 releaseDate;
u8 padding[24];
} DVDDriveInfo;
typedef struct DVDDiskID {
char gameName[4];
char company[2];
u8 diskNumber;
u8 gameVersion;
u8 streaming;
u8 streamBufSize;
u8 padding[22];
} DVDDiskID;
struct DVDCommandBlock {
DVDCommandBlock* next;
DVDCommandBlock* prev;
u32 command;
s32 state;
u32 offset;
u32 length;
void* addr;
u32 currTransferSize;
u32 transferredSize;
DVDDiskID* id;
DVDCBCallback callback;
void* userData;
};
struct DVDFileInfo {
DVDCommandBlock cBlock;
u32 startAddr;
u32 length;
DVDCallback callback;
};
typedef struct DVDDir {
u32 entryNum;
u32 location;
u32 next;
} DVDDir;
typedef struct DVDDirEntry {
u32 entryNum;
BOOL isDir;
const char* name;
} DVDDirEntry;
typedef struct DVDQueue DVDQueue;
struct DVDQueue {
DVDQueue* mHead;
DVDQueue* mTail;
};
typedef struct DVDBB1 {
u32 appLoaderLength;
void* appLoaderFunc1;
void* appLoaderFunc2;
void* appLoaderFunc3;
} DVDBB1;
typedef struct DVDBB2 {
u32 bootFilePosition;
u32 FSTPosition;
u32 FSTLength;
u32 FSTMaxLength;
void* FSTAddress;
u32 userPosition;
u32 userLength;
u32 reserved_1C;
} DVDBB2;
void DVDInit();
BOOL DVDOpen(const char* filename, DVDFileInfo* fileInfo);
BOOL DVDFastOpen(s32 entryNum, DVDFileInfo* fileInfo);
s32 DVDReadPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, s32 prio);
BOOL DVDReadAsyncPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, DVDCallback callback, s32 prio);
BOOL DVDReadAbsAsyncPrio(DVDCommandBlock* block, void* addr, s32 length, s32 offset, DVDCBCallback callback, s32 prio);
BOOL DVDClose(DVDFileInfo* fileInfo);
BOOL DVDPrepareStreamAsync(DVDFileInfo* fileInfo, u32 length, u32 offset, DVDCallback callback);
void DVDResume();
void DVDReset();
BOOL DVDCancelAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancel(DVDCommandBlock* block);
s32 DVDChangeDisk(DVDCommandBlock* block, DVDDiskID* id);
BOOL DVDChangeDiskAsync(DVDCommandBlock* block, DVDDiskID* id, DVDCBCallback callback);
s32 DVDGetCommandBlockStatus(const DVDCommandBlock* block);
s32 DVDGetDriveStatus();
BOOL DVDSetAutoInvalidation(BOOL doAutoInval);
void* DVDGetFSTLocation();
BOOL DVDOpenDir(const char* dirName, DVDDir* dir);
BOOL DVDReadDir(DVDDir* dir, DVDDirEntry* dirEntry);
BOOL DVDCloseDir(DVDDir* dir);
BOOL DVDGetCurrentDir(char* path, u32 maxLength);
BOOL DVDChangeDir(const char* dirName);
s32 DVDConvertPathToEntrynum(const char* path);
void __DVDLowSetWAType(u32 type, u32 location);
s32 DVDGetTransferredSize(DVDFileInfo* fileInfo);
DVDDiskID* DVDGetCurrentDiskID();
BOOL DVDCompareDiskID(DVDDiskID* id1, DVDDiskID* id2);
DVDLowCallback DVDLowClearCallback();
BOOL DVDCancelStreamAsync(DVDCommandBlock* block, DVDCBCallback callback);
BOOL DVDCancelStream(DVDCommandBlock* block);
BOOL DVDCheckDisk();
void DVDPause();
s32 DVDSeekPrio(DVDFileInfo* fileInfo, s32 offset, s32 prio);
BOOL DVDSeekAsyncPrio(DVDFileInfo* fileInfo, s32 offset, DVDCallback callback, s32 prio);
s32 DVDGetFileInfoStatus(DVDFileInfo* fileInfo);
BOOL DVDFastOpenDir(s32 entryNum, DVDDir* dir);
BOOL DVDCancelAllAsync(DVDCBCallback callback);
s32 DVDCancelAll();
void DVDDumpWaitingQueue();
void __DVDFSInit();
void __DVDClearWaitingQueue();
void __DVDInitWA(void);
void __fstLoad(void);
BOOL DVDLowRead(void* addr, u32 length, u32 offset, DVDLowCallback callback);
void __DVDStoreErrorCode(u32 error);
BOOL DVDLowStopMotor(DVDLowCallback callback);
BOOL DVDLowRequestError(DVDLowCallback callback);
BOOL DVDLowSeek(u32 offset, DVDLowCallback callback);
BOOL DVDLowAudioBufferConfig(BOOL enable, u32 size, DVDLowCallback callback);
BOOL DVDLowReadDiskID(DVDDiskID* diskID, DVDLowCallback callback);
BOOL DVDLowWaitCoverClose(DVDLowCallback callback);
BOOL __DVDCheckWaitingQueue();
BOOL DVDLowRequestAudioStatus(u32 subcmd, DVDLowCallback callback);
BOOL DVDLowAudioStream(u32 subcmd, u32 length, u32 offset, DVDLowCallback callback);
BOOL DVDLowInquiry(DVDDriveInfo* info, DVDLowCallback callback);
BOOL __DVDPushWaitingQueue(int idx, struct DVDQueue* newTail);
void DVDLowReset();
BOOL DVDLowBreak();
BOOL __DVDDequeueWaitingQueue(DVDQueue* queue);
BOOL DVDReadDiskID(DVDCommandBlock* block, DVDDiskID* diskID, DVDCBCallback callback);
void DVDSeekAbsAsyncPrio(DVDCommandBlock* block, void* addr, DVDCBCallback callback, s32 prio);
BOOL DVDPrepareStreamAbsAsync(DVDCommandBlock* block, u32 length, u32 offset, DVDCBCallback callback);
BOOL DVDReadAbsAsyncForBS(DVDCommandBlock* block, void* addr, s32 length, s32 offset, DVDCBCallback callback);
void __DVDPrepareResetAsync(DVDCBCallback callback);
extern OSThreadQueue __DVDThreadQueue;
}
extern "C"{
typedef struct OSBootInfo {
DVDDiskID DVDDiskID;
u32 magic;
u32 version;
u32 memorySize;
u32 consoleType;
void* arenaLo;
void* arenaHi;
void* FSTLocation;
u32 FSTMaxLength;
} OSBootInfo;
typedef struct BI2Debug {
int debugMonSize;
int simMemSize;
u32 argOffset;
u32 debugFlag;
int trackLocation;
int trackSize;
u32 countryCode;
u8 _1C[0x4];
u32 dvdLongFileNameFlag;
u32 padSpec;
} BI2Debug;
extern void* OS_BOOT_REGION_START : (0x812FDFF0) ;
extern void* OS_BOOT_REGION_END : (0x812FDFEC) ;
}
extern "C"{
void DCInvalidateRange(void* addr, u32 numBytes);
void DCFlushRange(void* addr, u32 numBytes);
void DCStoreRange(void* addr, u32 numBytes);
void DCFlushRangeNoSync(void* addr, u32 numBytes);
void DCStoreRangeNoSync(void* addr, u32 numBytes);
void DCZeroRange(void* addr, u32 numBytes);
void ICInvalidateRange(void* addr, u32 numBytes);
void ICFlashInvalidate();
void ICEnable();
void LCEnable();
void LCDisable();
void LCStoreBlocks(void* destAddr, void* srcTag, u32 numBlocks);
u32 LCStoreData(void* destAddr, void* srcAddr, u32 numBytes);
void LCQueueWait(u32 length);
void L2GlobalInvalidate();
void DCTouchRange(void* addr, u32 numBytes);
void ICSync();
void ICDisable();
void ICFreeze();
void ICUnfreeze();
void ICBlockInvalidate(void* addr);
void LCLoadBlocks(void* destTag, void* srcAddr, u32 numBlocks);
u32 LCLoadData(void* destAddr, void* srcAddr, u32 numBytes);
u32 LCQueueLength();
void LCFlushQueue();
void L2Enable();
void L2Disable();
void L2SetDataOnly(BOOL doDataOnly);
void L2SetWriteThrough(BOOL doWriteThrough);
}
extern "C"{
typedef u16 OSError;
typedef void (*OSErrorHandler)(OSError error, OSContext* context, ...);
OSErrorHandler OSSetErrorHandler(OSError error, OSErrorHandler handler);
void __OSUnhandledException(__OSException exception, OSContext* context, u32 dsisr, u32 dar);
void OSReport(const char* message, ...);
void OSPanic(const char* file, int line, const char* message, ...);
extern OSErrorHandler __OSErrorTable[((15) + 1) ];
}
extern "C"{
typedef void (*EXICallback)(s32 channel, OSContext* context);
BOOL EXIProbe(s32 channel);
s32 EXIProbeEx(s32 channel);
s32 EXIGetType(s32 channel, u32 dev, u32* type);
char* EXIGetTypeString(u32 type);
u32 __OSGetDIConfig(void);
void __OSEnableBarnacle(s32 chan, u32 dev);
}
extern "C"{
void PPCSync(void);
void PPCEieio(void);
void PPCHalt(void);
u32 PPCMfmsr(void);
void PPCMtmsr(u32 value);
void PPCOrMsr(void);
void PPCAndMsr(void);
void PPCAndCMsr(void);
u32 PPCMfhid0(void);
void PPCMthid0(u32 value);
u32 PPCMfhid1(void);
u32 PPCMfhid2(void);
void PPCMthid2(u32 value);
u32 PPCMfl2cr(void);
void PPCMtl2cr(u32 value);
u32 PPCMfdec(void);
void PPCMtdec(u32 value);
u32 PPCMfmmcr0(void);
void PPCMtmmcr0(u32 value);
u32 PPCMfmmcr1(void);
void PPCMtmmcr1(u32 value);
u32 PPCMfpmc1(void);
void PPCMtpmc1(u32 value);
u32 PPCMfpmc2(void);
void PPCMtpmc2(u32 value);
u32 PPCMfpmc3(void);
void PPCMtpmc3(u32 value);
u32 PPCMfpmc4(void);
void PPCMtpmc4(u32 value);
u32 PPCMfsia(void);
void PPCMtsia(u32 value);
u32 PPCMfwpar(void);
void PPCMtwpar(u32 value);
u32 PPCMfdmaU(void);
void PPCMtdmaU(u32 value);
u32 PPCMfdmaL(void);
void PPCMtdmaL(u32 value);
u32 PPCMfpvr(void);
}
extern "C"{
static inline void OSInitFastCast(void)
{
asm {
li r3, (0x0004)
oris r3, r3, (0x0004)
mtspr 914 , r3
li r3, (0x0005)
oris r3, r3, (0x0005)
mtspr 915 , r3
li r3, (0x0006)
oris r3, r3, (0x0006)
mtspr 916 , r3
li r3, (0x0007)
oris r3, r3, (0x0007)
mtspr 917 , r3
}
}
static inline void OSf32tou8(register f32* in, register u8* out)
{
asm {
lfs f1, 0 (in)
psq_st f1, 0 (out), 1, (2)
}
}
static inline void OSf32tou16(register f32* in, register u16* out)
{
asm {
lfs f1, 0 (in)
psq_st f1, 0 (out), 1, (3)
}
}
static inline void OSf32tos8(register f32* in, register s8* out)
{
asm {
lfs fp1, 0 (in)
psq_st fp1, 0 (out), 1, (4)
}
}
static inline void OSf32tos16(register f32* in, register s16* out)
{
asm {
lfs fp1, 0 (in)
psq_st fp1, 0 (out), 1, (5)
}
}
static inline void OSu8tof32(register u8* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (2)
stfs fp1, 0 (out)
}
}
static inline void OSu16tof32(register u16* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (3)
stfs fp1, 0 (out)
}
}
static inline void OSs8tof32(register s8* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (4)
stfs fp1, 0 (out)
}
}
static inline void OSs16tof32(register s16* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (5)
stfs fp1, 0 (out)
}
}
}
extern "C"{
typedef struct OSFontHeader {
u16 fontType;
u16 firstChar;
u16 lastChar;
u16 invalChar;
u16 ascent;
u16 descent;
u16 width;
u16 leading;
u16 cellWidth;
u16 cellHeight;
u32 sheetSize;
u16 sheetFormat;
u16 sheetColumn;
u16 sheetRow;
u16 sheetWidth;
u16 sheetHeight;
u16 widthTable;
u32 sheetImage;
u32 sheetFullSize;
u8 c0;
u8 c1;
u8 c2;
u8 c3;
} OSFontHeader;
u16 OSGetFontEncode();
char* OSGetFontWidth(const char* string, s32* width);
BOOL OSInitFont(OSFontHeader* fontInfo);
char* OSGetFontTexture(const char* string, void** image, s32* x, s32* y, s32* width);
u32 OSLoadFont(OSFontHeader* fontInfo, void* temp);
char* OSGetFontTexel(const char* string, void* image, s32 pos, s32 stride, s32* width);
typedef enum {
OS_FONT_ENCODE_ANSI,
OS_FONT_ENCODE_SJIS,
OS_FONT_ENCODE_2,
OS_FONT_ENCODE_UTF8,
OS_FONT_ENCODE_UTF16,
OS_FONT_ENCODE_UTF32,
OS_FONT_ENCODE_MAX,
} OSFontEncode;
}
extern "C"{
void OSProtectRange(u32 channel, void* addr, u32 numBytes, u32 control);
}
extern "C"{
typedef struct OSMesgQueue_s OSMesgQueue_s;
typedef struct OSMesgQueue_s OSMessageQueue;
typedef void* OSMessage;
struct OSMesgQueue_s {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
s32 msgCount;
s32 firstIndex;
s32 usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, s32 msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, s32 flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, s32 flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, s32 flags);
}
extern "C"{
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSModuleHeader OSModuleHeader;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
typedef u32 OSModuleID;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u32 prolog;
u32 epilog;
u32 unresolved;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
void OSSetStringTable(void* stringTable);
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* oldModule);
OSModuleInfo* OSSearchModule(void* ptr, u32* section, u32* offset);
}
extern "C"{
typedef struct OSResetFunctionInfo OSResetFunctionInfo;
typedef BOOL (*OSResetFunction)(BOOL final);
typedef void (*OSResetCallback)(void);
struct OSResetFunctionInfo {
OSResetFunction func;
u32 priority;
OSResetFunctionInfo* next;
OSResetFunctionInfo* prev;
};
typedef struct OSResetQueue {
OSResetFunctionInfo* head;
OSResetFunctionInfo* tail;
} OSResetQueue;
void OSRegisterResetFunction(OSResetFunctionInfo* info);
void OSResetSystem(int reset, u32 code, BOOL doForceMenu);
u32 OSGetResetCode();
void OSGetSaveRegion(void** start, void** end);
void OSSetSaveRegion(void* start, void* end);
BOOL OSGetResetButtonState();
BOOL OSGetResetSwitchState();
void __OSReboot(u32 resetCode, u32 bootDol);
void __OSDoHotReset(s32 code);
void OSSetSaveRegion(void* start, void* end);
void OSGetSaveRegion(void** start, void** end);
void OSGetSavedRegion(void** start, void** end);
void OSUnregisterResetFunction(OSResetFunctionInfo* info);
OSResetCallback OSSetResetCallback(OSResetCallback callback);
extern BOOL __OSIsGcam;
extern u32 OS_RESET_CODE : (0x800030F0) ;
extern volatile u8 OS_REBOOT_BOOL : (0x800030E2) ;
}
extern "C"{
typedef void (*SramCallback)(void);
typedef struct OSSram {
u16 checkSum;
u16 checkSumInv;
u32 ead0;
u32 ead1;
u32 counterBias;
s8 displayOffsetH;
u8 ntd;
u8 language;
u8 flags;
} OSSram;
typedef struct OSSramEx {
u8 flashID[2][12];
u32 wirelessKeyboardID;
u16 wirelessPadID[4];
u8 dvdErrorCode;
u8 reserved_25;
u8 flashIDCheckSum[2];
u16 gbs;
u8 reserved_2A[2];
} OSSramEx;
typedef struct SramControlBlock {
u8 sram[0x40];
u32 offset;
BOOL enabled;
BOOL locked;
BOOL sync;
SramCallback callback;
} SramControlBlock;
void __OSInitSram();
OSSram* __OSLockSram();
OSSramEx* __OSLockSramEx();
BOOL __OSUnlockSram(BOOL commit);
BOOL __OSUnlockSramEx(BOOL commit);
BOOL __OSSyncSram(void);
u32 OSGetSoundMode();
void OSSetSoundMode(u32 mode);
u32 OSGetProgressiveMode();
void OSSetProgressiveMode(u32 on);
u8 OSGetLanguage();
void OSSetLanguage(u8 language);
u32 OSGetEuRgb60Mode();
void OSSetEuRgb60Mode(u32 on);
void OSSetWirelessID(s32 channel, u16 id);
u16 OSGetWirelessID(s32 channel);
}
extern "C"{
extern void __OSPSInit();
extern void __OSFPRInit();
extern void __OSCacheInit();
extern void __OSContextInit();
extern void __OSInterruptInit();
extern void __OSThreadInit();
extern void __OSInitSystemCall();
extern void __OSModuleInit();
extern void __OSInitAudioSystem();
extern void __OSStopAudioSystem();
extern void __OSInitMemoryProtection();
void OSInit(void);
u32 OSGetConsoleType();
extern BOOL __OSInIPL;
extern OSTime __OSStartTime;
}
extern "C"{
typedef struct CARDFileInfo CARDFileInfo;
typedef struct CARDStat CARDStat;
typedef struct CARDDir CARDDir;
typedef struct CARDDirCheck CARDDirCheck;
typedef struct CARDControl CARDControl;
typedef struct CARDID CARDID;
typedef struct CARDHeaderBlock CARDHeaderBlock;
typedef struct CARDDirectoryBlock CARDDirectoryBlock;
typedef struct CARDFatBlock CARDFatBlock;
typedef struct CARDMemoryCard CARDMemoryCard;
typedef struct CARDDecodeParameters CARDDecodeParameters;
typedef void (*CARDCallback)(s32 channel, s32 result);
struct CARDFileInfo {
s32 chan;
s32 fileNo;
s32 offset;
s32 length;
u16 iBlock;
};
struct CARDStat {
char fileName[(32) ];
u32 length;
u32 time;
u8 gameName[4];
u8 company[2];
u8 bannerFormat;
u32 iconAddr;
u16 iconFormat;
u16 iconSpeed;
u32 commentAddr;
u32 offsetBanner;
u32 offsetBannerTlut;
u32 offsetIcon[(8) ];
u32 offsetIconTlut;
u32 offsetData;
};
struct CARDDir {
u8 gameName[4];
u8 company[2];
u8 reserved_06;
u8 bannerFormat;
u8 fileName[(32) ];
u32 time;
u32 iconAddr;
u16 iconFormat;
u16 iconSpeed;
u8 permission;
u8 copyTimes;
u16 startBlock;
u16 length;
u16 reserved_3A;
u32 commentAddr;
};
struct CARDDirCheck {
u8 padding[0x3A];
s16 checkCode;
u16 checkSum;
u16 checkSumInv;
};
struct CARDControl {
BOOL attached;
s32 result;
u16 size;
u16 pageSize;
s32 sectorSize;
u16 cBlock;
u16 vendorID;
s32 latency;
u8 id[0xC];
int mountStep;
u32 scramble;
int formatStep;
DSPTaskInfo task;
CARDMemoryCard* workArea;
CARDDirectoryBlock* currentDir;
CARDFatBlock* currentFat;
OSThreadQueue threadQueue;
u8 cmd[9];
s32 cmdlen;
u32 mode;
int retry;
int repeat;
u32 addr;
void* buffer;
s32 xferred;
u16 freeNo;
u16 startBlock;
CARDFileInfo* fileInfo;
CARDCallback extCallback;
CARDCallback txCallback;
CARDCallback exiCallback;
CARDCallback apiCallback;
CARDCallback xferCallback;
CARDCallback eraseCallback;
CARDCallback unlockCallback;
OSAlarm alarm;
};
struct CARDID {
u8 serial[0x20];
u16 deviceID;
u16 size;
u16 encode;
u8 padding[0x1D4];
s16 checkCode;
u16 checkSum;
u16 checkSumInv;
};
struct CARDHeaderBlock {
CARDID id;
u8 buffer[0x1E00];
};
struct CARDDirectoryBlock {
CARDDir entries[(127) ];
CARDDirCheck check;
};
struct CARDFatBlock {
u16 checkSum;
u16 checkSumInv;
u16 checkCode;
u16 freeBlocks;
u16 lastAllocBlock;
u16 allocMap[0xFFB];
};
struct CARDMemoryCard {
CARDHeaderBlock header;
CARDDirectoryBlock dirBlock;
CARDDirectoryBlock dirBlockBackup;
CARDFatBlock blockAllocMap;
CARDFatBlock blockAllocMapBackup;
};
struct CARDDecodeParameters {
u8* inputAddr;
u32 inputLength;
u32 aramAddr;
u8* outputAddr;
};
typedef enum {
FilePermPublic = 0x2,
FilePermNoCopy = 0x4,
FilePermNoMove = 0x8,
} CARDFilePermissions;
typedef enum {
BannerColorCI8 = 0x1,
BannerPresent = 0x2,
IconAnimationPingPong = 0x4,
} CARDBannerFlag;
extern CARDControl __CARDBlock[2];
extern DVDDiskID __CARDDiskNone;
extern DVDDiskID* __CARDDiskID;
extern u16 __CARDVendorID;
extern u8 __CARDPermMask;
void CARDInit();
s32 CARDCheck(s32 channel);
s32 CARDCheckExAsync(s32 channel, s32* xferBytes, CARDCallback callback);
s32 CARDCheckAsync(s32 channel, CARDCallback);
s32 CARDGetResultCode(s32 channel);
s32 CARDFreeBlocks(s32 channel, s32* byteNotUsed, s32* filesNotUsed);
s32 CARDGetSectorSize(s32 channel, u32* size);
BOOL CARDProbe(s32 channel);
s32 CARDProbeEx(s32 channel, s32* memSize, s32* sectorSize);
s32 CARDMountAsync(s32 channel, CARDMemoryCard* workArea, CARDCallback detachCallback, CARDCallback attachCallback);
s32 CARDMount(s32 channel, CARDMemoryCard* workArea, CARDCallback detachCallback);
s32 CARDUnmount(s32 channel);
s32 CARDFormatAsync(s32 channel, CARDCallback callback);
s32 CARDFormat(s32 channel);
s32 CARDOpen(s32 channel, const char* fileName, CARDFileInfo* fileInfo);
s32 CARDFastOpen(s32 channel, s32 fileNo, CARDFileInfo* fileInfo);
s32 CARDClose(CARDFileInfo* fileInfo);
s32 CARDCreate(s32 channel, const char* fileName, u32 size, CARDFileInfo* fileInfo);
s32 CARDCreateAsync(s32 channel, const char* fileName, u32 size, CARDFileInfo* fileInfo, CARDCallback callback);
s32 CARDRead(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset);
s32 CARDReadAsync(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset, CARDCallback callback);
s32 CARDWrite(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset);
s32 CARDWriteAsync(CARDFileInfo* fileInfo, void* addr, s32 length, s32 offset, CARDCallback callback);
s32 CARDGetXferredBytes(s32 channel);
s32 CARDFastDeleteAsync(s32 channel, s32 fileNo, CARDCallback callback);
s32 CARDFastDelete(s32 channel, s32 fileNo);
s32 CARDRenameAsync(s32 channel, const char* oldName, const char* newName, CARDCallback callback);
s32 CARDRename(s32 channel, const char* oldName, const char* newName);
s32 CARDGetStatus(s32 channel, s32 fileNo, CARDStat* state);
s32 CARDSetStatus(s32 channel, s32 fileNo, CARDStat* state);
s32 CARDSetStatusAsync(s32 channel, s32 fileNo, CARDStat* state, CARDCallback callback);
s32 CARDGetSerialNo(s32 channel, u64* serialNo);
void __CARDDefaultApiCallback(s32 channel, s32 result);
void __CARDSyncCallback(s32 channel, s32 result);
void __CARDExtHandler(s32 channel, OSContext* context);
void __CARDExiHandler(s32 channel, OSContext* context);
void __CARDTxHandler(s32 channel, OSContext* context);
void __CARDUnlockedHandler(s32 channel, OSContext* context);
void __CARDMountCallback(s32 channel, s32 result);
int __CARDReadNintendoID(s32 channel, u32* id);
s32 __CARDEnableInterrupt(s32 channel, BOOL enable);
s32 __CARDReadStatus(s32 channel, u8* status);
s32 __CARDClearStatus(s32 channel);
s32 __CARDReadSegment(s32 channel, CARDCallback callback);
s32 __CARDWritePage(s32 channel, CARDCallback callback);
s32 __CARDEraseSector(s32 channel, u32 addr, CARDCallback callback);
u16 __CARDGetFontEncode();
void __CARDSetDiskID(DVDDiskID* diskID);
s32 __CARDGetControlBlock(s32 channel, CARDControl** card);
s32 __CARDPutControlBlock(CARDControl* card, s32 result);
s32 __CARDSync(s32 channel);
void __CARDCheckSum(void* data, int length, u16* checksum, u16* checksumInv);
s32 __CARDVerify(CARDControl* card);
BOOL __CARDCompareFileName(CARDDir* entry, const char* fileName);
s32 __CARDAccess(CARDDir* entry);
s32 __CARDIsPublic(CARDDir* ent);
BOOL __CardIsOpened(CARDControl* card, s32 fileNo);
s32 __CARDRead(s32 channel, u32 addr, s32 length, void* dst, CARDCallback callback);
s32 __CARDWrite(s32 channel, u32 addr, s32 length, void* dst, CARDCallback callback);
CARDDirectoryBlock* __CARDGetDirBlock(CARDControl* card);
s32 __CARDUpdateDir(s32 channel, CARDCallback callback);
s32 __CARDAllocBlock(s32 channel, u32 cBlock, CARDCallback callback);
s32 __CARDFreeBlock(s32 channel, u16 nBlock, CARDCallback callback);
CARDFatBlock* __CARDGetFatBlock(CARDControl* card);
s32 __CARDUpdateFatBlock(s32 channel, CARDFatBlock* fat, CARDCallback callback);
BOOL __CARDIsOpened(CARDControl* card, s32 fileNo);
int __CARDUnlock(int chan, u8 flashID[12]);
s32 __CARDSeek(CARDFileInfo* fileInfo, s32 length, s32 offset, CARDControl** outCard);
}
struct CARDStat;
enum CardUtilCommands {
CARDCMD_Mount = 1,
CARDCMD_Unmount = 2,
CARDCMD_Format = 3,
CARDCMD_List = 4,
CARDCMD_Erase = 5,
CARDCMD_Open = 6,
CARDCMD_Save = 7,
CARDCMD_Write = 9,
};
struct CardUtilDirent {
u8 mFileData[0x5A00];
u8 mFileCommentData[(64) ];
s32 mFileNo;
CARDStat mState;
u32 mAnimTotalFrames;
u32 mAnimFrameOffsets[14];
u32 mAnimIconIndices[14];
u8 _5B0C[0x5B40 - 0x5B24];
};
struct CardUtilThread {
OSThread mThread;
};
struct CardUtilControl {
OSMutex mMutex;
OSCond mCondition;
s32 mChannel;
s32 mCommand;
void* mFileNo;
void* mDataPtr;
u32 mOffset;
u32 mLength;
s32 mResultCode;
s32 mByteNotUsed;
s32 mFilesNotUsed;
u32 mSectorSize;
u32 mTransferredBytes;
u32 mOperationSize;
OSMutex mDirMutex;
CardUtilDirent* mDirentList;
int mDirentCount;
};
s32 CardUtilResultCode();
void CardUtilMount(s32 chan, void* workBuffer);
void CardUtilUnmount(s32 chan);
bool CardUtilIsCardBusy();
void CardUtilIdleWhileBusy();
void CardUtilErase(s32 chan, s32 fileNo);
void CardUtilOpen(s32 chan, s32 fileNo, void* workBuffer);
void CardUtilSave(s32 chan, CARDStat* fileState, void* data);
void CardUtilWrite(s32 chan, s32 fileNo, void* data, u32 offset, u32 length);
void CardUtilInit(void* stack, u32 stackSize, s32 prio);
extern "C"{
void* memcpy(void*, const void*, size_t);
void __fill_mem(void*, int, size_t);
void* memset(void*, int, size_t);
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, u8 type);
}
extern "C"{
int memcmp(const void*, const void*, size_t);
void* memchr(u8*, int, size_t);
void* memmove(void*, const void*, size_t);
void* memcpy(void* dest, const void* src, size_t n);
void* memset(void* dest, int val, size_t count);
}
extern "C"{
int stricmp(const char*, const char*);
}
extern "C"{
char* strcpy(char* dst, const char* src);
char* strncpy(char* dst, const char* src, size_t n);
char* strcat(char* dst, const char* src);
char* strncat(char* dst, const char* src, size_t n);
int strcmp(const char* lhs, const char* rhs);
int strncmp(const char* lhs, const char* rhs, size_t n);
char* strchr(const char* str, int ch);
char* strstr(const char* str, const char* substr);
char* strrchr(const char* str, int chr);
size_t strlen(const char* str);
}
class String;
class Stream {
public:
Stream() { }
char* mPath;
virtual int readInt();
virtual u8 readByte();
virtual short readShort();
virtual f32 readFloat();
virtual void readString(char*, int);
virtual void readString(String&);
virtual char* readString();
virtual void writeInt(int);
virtual void writeByte(u8);
virtual void writeShort(short);
virtual void writeFloat(f32);
virtual void writeString( char*);
virtual void writeString( String&);
virtual void read(void*, int);
virtual void write( void*, int);
virtual int getPending();
virtual int getAvailable();
virtual void close();
virtual bool getClosing() { return false; }
virtual void flush() { }
void print( char*, ...);
void vPrintf( char*, va_list);
};
class RandomAccessStream : public Stream {
public:
virtual int getPosition() { return 0; }
virtual int getPending() { return getLength() - getPosition(); }
virtual void setPosition(int) { }
virtual int getLength() { return getAvailable(); }
void skipPadding(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
readByte();
}
}
void padFile(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
void padFileTo(u32 paddingAmount, u32 offset)
{
int position = getPosition();
int count = paddingAmount - position - offset;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
inline BOOL checkInput()
{
if (readByte() == 0) {
return false;
}
return true;
}
void writeTo(int, void*, int);
void readFrom(int, void*, int);
void writeIntTo(int, int);
int readIntFrom(int);
};
class AlignedStream : public RandomAccessStream {
public:
virtual void read(void*, int);
virtual void write( void*, int);
virtual void alignedWrite( void*, int) = 0;
virtual void alignedRead(void*, int) = 0;
int mAlignment;
};
class BufferedInputStream : public RandomAccessStream {
public:
BufferedInputStream()
{
mBuffer = 0 ;
mStream = 0 ;
}
BufferedInputStream(Stream*, u8*, int);
virtual void read(void*, int);
virtual int getPending() { return mStream->getPending() - mPosition; }
virtual void close() { mStream->close(); }
virtual int getPosition() { return mPosition; }
void init(Stream*, u8*, int);
void fillBuffer();
u8* mBuffer;
int mBufferSize;
int mRemainingBytes;
int mCurrentBufferPos;
int mPosition;
Stream* mStream;
};
class RamStream : public RandomAccessStream {
public:
inline RamStream(void* buffer, int size)
{
mBufferAddr = buffer;
mPosition = 0;
mLength = size;
}
virtual int getPending() { return mLength - mPosition; }
virtual void setPosition(int pos) { mPosition = pos; }
virtual int getPosition() { return mPosition; }
virtual int getLength() { return mLength; }
virtual void setLength(int len) { mLength = len; }
virtual void read(void* dest, int size)
{
memcpy(dest, (char*)mBufferAddr + mPosition, size);
mPosition += size;
}
virtual void write( void* src, int size)
{
memcpy((char*)mBufferAddr + mPosition, src, size);
mPosition += size;
}
void* mBufferAddr;
int mPosition;
int mLength;
};
extern Stream* sysCon;
extern Stream* errCon;
class MemHead {
public:
u32 mTagAndSize;
MemHead* mNext;
MemHead* mPrev;
u32 mGuardValue;
};
class AyuCache {
public:
AyuCache(u32);
void init(u32 bufferStart, u32 bufferEnd);
void* mallocL(u32 sizeBytes);
void cacheFree(void* ptr);
bool isEmpty();
u32 largestBlockFree();
int getIndex();
void releaseIndex(int);
void deleteIdAll(u32);
u32 amountFree();
MemHead mFreeBlockHead;
MemHead mAllocatedBlockHead;
u32 mCurrentAllocationTag;
u32 mTotalAllocatedUnits;
u32 mTotalCacheSizeBytes;
u8 mPageIndexPool[256];
u32 mNextPageSlot;
};
class AyuStack {
public:
AyuStack() { mIsActive = false; }
void reset(int resetFlags);
void* push(int requestedSizeBytes);
void pop();
void create( char* name, int allocFlags, void* stackBase, int stackSizeBytes, bool enableOverflowGuard);
void reset();
void checkStack();
int setAllocType(int type)
{
int old = mAllocType;
mAllocType = type;
return old;
}
int getFree() { return mSize - mTotalSize; }
int getTopUsed() { return mInitialStackLimit - mStackLimit; }
int getMaxFree() { return (mSize - mTotalSize - 8 > 0) ? mSize - mTotalSize - 8 : 0; }
void inactivate() { mIsActive = false; }
s32 mAllocType;
int mSize;
int mTotalSize;
u32 mInitialStackTop;
u32 mInitialStackLimit;
u32 mStackTop;
u32 mStackLimit;
bool mProtectOverflow;
bool mIsActive;
char* mName;
};
class AyuHeap : public AyuStack {
public:
AyuHeap() { }
void init( char* name, int allocFlags, void* stackBase, int stackSizeBytes);
u8 _24;
};
class AgeServer;
class ANode {
public:
virtual int getAgeNodeType() { return 0; }
};
class RandomAccessStream;
class CoreNode : public ANode {
public:
CoreNode( char* name = "CoreNode") { initCore(name); }
virtual void read(RandomAccessStream& stream) { }
void initCore( char* name)
{
mParent = mNext = mChild = 0 ;
setName(name);
}
CoreNode* Child() { return mChild; }
CoreNode* Next() { return mNext; }
CoreNode* Parent() { return mParent; }
void Child(CoreNode* child) { mChild = child; }
void Next(CoreNode* next) { mNext = next; }
char* Name() { return mName; }
int getChildCount();
void add(class CoreNode* child);
void del();
void setName( char* name) { mName = name; }
void load( char* dirPath, char* fileName, u32);
void genRead(AgeServer&) { }
void genWrite(AgeServer&) { }
char* mName;
CoreNode* mParent;
CoreNode* mNext;
CoreNode* mChild;
};
extern "C"{
typedef struct Vec {
f32 x;
f32 y;
f32 z;
} Vec;
typedef struct SVec {
s16 x;
s16 y;
s16 z;
} SVec;
void C_VECAdd(const Vec* a, const Vec* b, Vec* ab);
void PSVECAdd(const Vec* a, const Vec* b, Vec* ab);
void C_VECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void PSVECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void C_VECScale(const Vec* src, Vec* dst, f32 scale);
void PSVECScale(const Vec* src, Vec* dst, f32 scale);
void C_VECNormalize(const Vec* src, Vec* unit);
void PSVECNormalize(const Vec* src, Vec* unit);
f32 C_VECSquareMag(const Vec* v);
f32 PSVECSquareMag(const Vec* v);
f32 VECMag (const Vec* v);
f32 PSVECMag(const Vec* v);
f32 C_VECDotProduct(const Vec* a, const Vec* b);
f32 PSVECDotProduct(const Vec* a, const Vec* b);
void C_VECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void PSVECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void VECHalfAngle (const Vec* a, const Vec* b, Vec* half);
void VECReflect (const Vec* src, const Vec* normal, Vec* dst);
f32 C_VECSquareDistance(const Vec* a, const Vec* b);
f32 PSVECSquareDistance(const Vec* a, const Vec* b);
f32 VECDistanc (const Vec* a, const Vec* b);
f32 PSVECDistance(const Vec* a, const Vec* b);
}
extern "C"{
typedef f32 Mtx[3][4];
typedef f32 Mtx23[2][3];
typedef f32 Mtx33[3][3];
typedef f32 Mtx44[4][4];
typedef f32 (*MtxPtr)[4];
typedef f32 (*Mtx23Ptr)[2];
typedef f32 (*Mtx33Ptr)[3];
typedef f32 (*Mtx44Ptr)[4];
typedef f32 PSQuaternion[4];
typedef struct Quaternion {
f32 x, y, z, w;
} Quaternion;
void C_MTXIdentity(Mtx m);
void PSMTXIdentity(Mtx m);
void C_MTXCopy(const Mtx src, Mtx dst);
void PSMTXCopy(const Mtx src, Mtx dst);
void C_MTXConcat(const Mtx a, const Mtx b, Mtx dst);
void PSMTXConcat(const Mtx a, const Mtx b, Mtx dst);
void C_MTXTranspose(const Mtx src, Mtx xPose);
void PSMTXTranspose(const Mtx src, Mtx xPose);
u32 C_MTXInverse(const Mtx src, Mtx inv);
u32 PSMTXInverse(const Mtx src, Mtx inv);
u32 C_MTXInvXpose(const Mtx src, Mtx inv);
u32 PSMTXInvXpose(const Mtx src, Mtx inv);
void MTXRotRad (Mtx m, char axis, f32 rad);
void PSMTXRotRad(Mtx m, char axis, f32 rad);
void MTXRotTrig (Mtx m, char axis, f32 sinA, f32 cosA);
void PSMTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void MTXRotAxisRad (Mtx m, const Vec* axis, f32 rad);
void PSMTXRotAxisRad(Mtx m, const Vec* axis, f32 rad);
void MTXTrans (Mtx m, f32 xT, f32 yT, f32 zT);
void PSMTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void MTXTransApply (const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void PSMTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void MTXScale (Mtx m, f32 xS, f32 yS, f32 zS);
void PSMTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void MTXScaleApply (const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void PSMTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void MTXQuat (Mtx m, const Quaternion* quat);
void PSMTXQuat(Mtx m, const Quaternion* quat);
void MTXReflect (Mtx m, const Vec* p, const Vec* n);
void PSMTXReflect(Mtx m, const Vec* p, const Vec* n);
void MTXLookAt (Mtx m, const Vec* camPos, const Vec* camUp, const Vec* target);
void MTXLightFrustum (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightPerspective (Mtx m, f32 fovY, f32 aspect, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightOrtho (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXFrustum (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void MTXPerspective (Mtx44 m, f32 fovY, f32 aspect, f32 n, f32 f);
void MTXOrtho (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTX44Identity(Mtx44 m);
void PSMTX44Identity(Mtx44 m);
void C_MTX44Copy(const Mtx44 src, Mtx44 dst);
void PSMTX44Copy(const Mtx44 src, Mtx44 dst);
void C_MTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void PSMTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void C_MTX44Transpose(const Mtx44 src, Mtx44 xPose);
void PSMTX44Transpose(const Mtx44 src, Mtx44 xPose);
u32 C_MTX44Inverse(const Mtx44 src, Mtx44 inv);
void C_MTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void PSMTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void C_MTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void PSMTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void C_MTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void PSMTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void C_MTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void PSMTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void C_MTX44RotRad(Mtx44 m, char axis, f32 rad);
void PSMTX44RotRad(Mtx44 m, char axis, f32 rad);
void C_MTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void PSMTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void C_MTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
void PSMTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
static inline void MTXSetPosition(Mtx mtx, const Vec* pos)
{
mtx[0][3] = pos->x;
mtx[1][3] = pos->y;
mtx[2][3] = pos->z;
}
}
extern "C"{
extern const f32 __float_huge[];
extern const f32 __float_nan[];
extern const f64 __double_huge[];
extern const f64 __double_nan[];
f64 cos(f64);
f32 cosf(f32);
f64 sin(f64);
f32 sinf(f32);
f64 tan(f64);
f32 tanf(f32);
f64 acos(f64);
f32 acosf(f32);
f64 asin(f64);
f64 atan(f64);
f32 atanf(f32);
f64 atan2(f64, f64);
f32 atan2f(f32, f32);
f64 ceil(f64);
f64 floor(f64);
f64 frexp(f64, int*);
f64 ldexp(f64, int);
f64 sqrt(f64);
f64 pow(f64, f64);
f64 log(f64);
f64 log10(f64);
f64 fmod(f64, f64);
f64 scalbn(f64, int);
inline f128 fabsl(f128 x)
{
return __fabs((f64)x);
}
inline f32 sqrtf(f32 x)
{
static const f64 _half = .5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
}
namespace std {
inline f32 sqrtf(f32 x)
{
static const f64 _half = 0.5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
inline f32 fmodf(f32 x, f32 m)
{
f32 b, a;
a = __fabsf(m) ;
b = __fabsf(x) ;
if (a > b) {
return x;
}
long long c = (long long)(x / m);
return x - m * c;
}
}
inline f32 fmod(f32 x, f32 m)
{
return std::fmodf(x, m);
}
class Vector3f;
class BoundBox;
class KTri;
class KRect;
class KSegment;
static inline f32 quickABS(f32 x)
{
*reinterpret_cast<u32*>(&x) &= ~0x80000000;
return x;
}
static inline f32 u32ToFloat(u32 a)
{
union {
u32 w;
f32 f;
} tmp;
tmp.w = a;
return tmp.f;
}
inline f32 absF(f32 val)
{
return (f32)__fabsf(val) ;
}
inline f32 absVal(f32 val)
{
if (val > 0.0f) {
return val;
}
return -val;
}
f32 roundAng(f32 angle);
f32 angDist(f32 x, f32 z);
f32 qdist2(f32 x0, f32 z0, f32 x1, f32 z1);
f32 triRectDistance( Vector3f*, Vector3f*, Vector3f*, BoundBox&, bool);
f32 distanceTriRect(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KTri&, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KSegment&, f32*, f32*);
f32 sqrDistance(KSegment&, KRect&, f32*, f32*, f32*);
f32 sqrDistance(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance( Vector3f&, KTri&, f32*, f32*);
f32 qdist3(f32 x0, f32 y0, f32 z0, f32 x1, f32 y1, f32 z1);
inline f32 speedy_sqrtf(f32 x)
{
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte(x) ;
y = (f32)(x * guess);
return y;
}
return x;
}
class AgeServer;
class Matrix3f;
class Matrix4f;
class Quat;
class Vector3f {
public:
Vector3f() { x = y = z = 0.0f; }
Vector3f(const f32& _x, const f32& _y, const f32& _z)
: x(_x)
, y(_y)
, z(_z)
{
}
Vector3f(const Vector3f& other)
{
x = other.x;
y = other.y;
z = other.z;
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
z = stream.readFloat();
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
stream.writeFloat(z);
}
void set(const f32& pX, const f32& pY, const f32& pZ)
{
x = pX;
y = pY;
z = pZ;
}
void set(const Vector3f& other) { set(other.x, other.y, other.z); }
void input( Vector3f& other) { set(other.x, other.y, other.z); }
void output(Vector3f& outVec) { outVec.set(x, y, z); }
f32 length() { return std::sqrtf((x * x) + (y * y) + (z * z) ); }
f32 squaredLength() { return (x * x) + (y * y) + (z * z) ; }
f32 DP( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 dot( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 distance( Vector3f& to)
{
Vector3f result;
result.sub2(to, *this);
return result.length();
}
f32 normalise()
{
f32 norm = length();
if (norm != 0.0f) {
div(norm);
}
return norm;
}
void CP( Vector3f& other)
{
Vector3f tmp;
tmp.x = y * other.z - z * other.y;
tmp.y = z * other.x - x * other.z;
tmp.z = x * other.y - y * other.x;
x = tmp.x;
y = tmp.y;
z = tmp.z;
}
void cross( Vector3f& vec1, Vector3f& vec2)
{
set(vec1.y * vec2.z - vec1.z * vec2.y, vec1.z * vec2.x - vec1.x * vec2.z, vec1.x * vec2.y - vec1.y * vec2.x);
}
void add( Vector3f& other)
{
x += other.x;
y += other.y;
z += other.z;
}
void add2( Vector3f& a, Vector3f& b) { set(a.x + b.x, a.y + b.y, a.z + b.z); }
void sub( Vector3f& other)
{
x -= other.x;
y -= other.y;
z -= other.z;
}
void sub( Vector3f& a, Vector3f& b)
{
x = a.x - b.x;
y = a.y - b.y;
z = a.z - b.z;
}
void sub2( Vector3f& a, Vector3f& b) { set(a.x - b.x, a.y - b.y, a.z - b.z); }
void div(f32 divisor)
{
x /= divisor;
y /= divisor;
z /= divisor;
}
void multiply(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale2(f32 scale, Vector3f& vec)
{
x = scale * vec.x;
y = scale * vec.y;
z = scale * vec.z;
}
void negate()
{
x = -x;
y = -y;
z = -z;
}
void bounce( Vector3f& surface, f32 elasticity)
{
f32 dp = -DP(surface) * elasticity;
if (dp > 0.0f) {
x = surface.x * dp + x;
y = surface.y * dp + y;
z = surface.z * dp + z;
}
}
void lerpTo( Vector3f& other, f32 t, Vector3f& outVec)
{
outVec.x = (other.x - x) * t + x;
outVec.y = (other.y - y) * t + y;
outVec.z = (other.z - z) * t + z;
}
void rotate( Matrix4f&);
void rotateTo( Matrix4f&, Vector3f&);
void multMatrix( Matrix4f&);
void multMatrixTo( Matrix4f&, Vector3f&);
void rotateTranspose( Matrix4f&);
void rotate( Quat&);
void rotateInverse( Quat&);
void normalize() { normalise(); }
void project( Vector3f& dirToRemove)
{
f32 projAmt = DP(dirToRemove);
x = -(projAmt * dirToRemove.x - x);
y = -(projAmt * dirToRemove.y - y);
z = -(projAmt * dirToRemove.z - z);
}
void middle( Vector3f& a, Vector3f& b)
{
add2(a, b);
scale(0.5f);
}
bool isSame( Vector3f& other)
{
return __fabsf(x - other.x) < 0.0001f && __fabsf(y - other.y) < 0.0001f && __fabsf(z - other.z) < 0.0001f;
}
void add( Vector3f& a, Vector3f& b)
{
x = a.x + b.x;
y = a.y + b.y;
z = a.z + b.z;
}
void add(f32 _x, f32 _y, f32 _z)
{
x += _x;
y += _y;
z += _z;
}
f32 x;
f32 y;
f32 z;
};
class Vector2f {
public:
Vector2f() { }
Vector2f(const f32& _x, const f32& _y)
{
x = _x;
y = _y;
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
}
void set(f32 _x, f32 _y)
{
x = _x;
y = _y;
}
f32 x, y;
};
class Vector2i {
public:
void read(Stream& stream)
{
x = stream.readInt();
y = stream.readInt();
}
void write(Stream& stream)
{
stream.writeInt(x);
stream.writeInt(y);
}
void set(int _x, int _y)
{
x = _x;
y = _y;
}
int x, y;
};
class Quat {
public:
Quat() { }
Quat(f32 _x, f32 _y, f32 _z, f32 _s) { set(_x, _y, _z, _s); }
void fromMat3f( Matrix3f&);
void rotate( Vector3f&, f32);
void multiply( Quat&);
void normalise();
void genVectorX(Vector3f&) ;
void genVectorY(Vector3f&) ;
void genVectorZ(Vector3f&) ;
void slerp( Quat&, f32, int);
void fromEuler( Vector3f&);
void multiplyTo( Quat&, Quat&);
void set(f32 _x, f32 _y, f32 _z, f32 _s)
{
v.x = _x;
v.y = _y;
v.z = _z;
s = _s;
}
Vector3f v;
f32 s;
};
inline Vector3f operator*(const Vector3f& a, const f32& b)
{
return Vector3f(a.x * b, a.y * b, a.z * b);
}
inline Vector3f operator*(const f32& a, const Vector3f& b)
{
return b * a;
}
inline Vector3f operator+(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x + b.x, a.y + b.y, a.z + b.z);
}
inline Vector3f operator-(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x - b.x, a.y - b.y, a.z - b.z);
}
inline Vector3f operator-(const Vector3f& a)
{
return Vector3f(-a.x, -a.y, -a.z);
}
inline Vector3f operator/(const Vector3f& a, const f32& b)
{
return a * (1.0f / b);
}
inline Vector3f CP(const Vector3f& a, const Vector3f& b)
{
f32 x = a.y * b.z - a.z * b.y;
f32 y = a.z * b.x - a.x * b.z;
f32 z = a.x * b.y - a.y * b.x;
return Vector3f(x, y, z);
}
class SRT {
public:
SRT() { }
SRT(const SRT& other)
: s(other.s)
, r(other.r)
, t(other.t)
{
}
Vector3f s;
Vector3f r;
Vector3f t;
};
class Plane;
class Matrix4f {
public:
Matrix4f() { }
Matrix4f( Mtx44);
void makeIdentity();
void makeRotate( Vector3f&, f32, f32);
void makeRotate( Vector3f&, f32);
void multiply( Matrix4f&);
void multiplyTo( Matrix4f&, Matrix4f&) ;
void makeSRT( Vector3f&, Vector3f&, Vector3f&);
void makeConcatSRT( Matrix4f*, Matrix4f&, SRT&);
void inverse(Matrix4f*);
void scale( Vector3f&);
void makeLookat( Vector3f& cameraPos, Vector3f& targetPos, Vector3f* optionalUp);
void makeLookat( Vector3f& cameraPos, Vector3f& rightDir, Vector3f& upDir, Vector3f& backDir);
void transposeTo(Matrix4f&);
void makeVQS( Vector3f&, Quat&, Vector3f&);
void blend( Matrix4f&, f32);
void makeOrtho(f32, f32, f32, f32, f32, f32, f32);
void makePerspective(f32 fovY, f32 aspectRatio, f32 nearZ, f32 farZ);
void makeBallRotate(Vector3f&);
void rotate(Vector3f&, f32);
void rotate(Vector3f&);
void rotate(f32, f32, f32);
void makeAligned(Vector3f&, f32);
void rotateX(f32);
void rotateY(f32);
void rotateZ(f32);
void translate(f32, f32, f32);
void makeLookfrom( Vector3f&, Vector3f&);
void makeProjection(Vector3f&, Plane&);
void makeReflection(Plane&);
void makeBillVector(Vector3f&, Matrix4f&, Vector3f&);
void makeSRT(SRT srt) { makeSRT(srt.s, srt.r, srt.t); }
inline void set( Matrix4f& other)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = other.mMtx[i][j];
}
}
}
inline void set(f32 value)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = value;
}
}
}
void getRow(int rowNum, Vector3f& row) { row.set(mMtx[rowNum][0], mMtx[rowNum][1], mMtx[rowNum][2]); }
void getColumn(int colNum, Vector3f& col) { col.set(mMtx[0][colNum], mMtx[1][colNum], mMtx[2][colNum]); }
void setRow(int rowNum, const Vector3f& row)
{
mMtx[rowNum][0] = row.x;
mMtx[rowNum][1] = row.y;
mMtx[rowNum][2] = row.z;
}
void setColumn(int colNum, const Vector3f& col)
{
mMtx[0][colNum] = col.x;
mMtx[1][colNum] = col.y;
mMtx[2][colNum] = col.z;
}
void setTranslation( Vector3f& trans)
{
mMtx[0][3] = trans.x;
mMtx[1][3] = trans.y;
mMtx[2][3] = trans.z;
}
void setTranslation(f32 x, f32 y, f32 z)
{
mMtx[0][3] = x;
mMtx[1][3] = y;
mMtx[2][3] = z;
}
static Matrix4f ident;
Mtx44 mMtx;
};
extern f32 sintable[0x1000];
extern f32 costable[0x1000];
static inline f32 sinShort(u16 x)
{
return sintable[(x >> 4) & 0xFFF];
}
static inline f32 cosShort(u16 x)
{
return costable[(x >> 4) & 0xFFF];
}
class Graphics;
class Vector3f;
class VQS;
class Node : public CoreNode {
public:
Node( char* name = "<Node>")
: CoreNode(name)
{
init(name);
}
virtual void update();
virtual void draw(Graphics&);
virtual void render(Graphics&);
virtual void concat() { }
virtual void concat(VQS&) { concat(); }
virtual void concat(SRT&) { concat(); }
virtual void concat(Matrix4f&) { concat(); }
virtual Matrix4f* getModelMatrix() { return 0 ; }
void init( char*);
bool getFlag(int);
int getFlags();
int getType();
void clearFlag(int);
void setFlag(int);
void setFlag(int, bool);
void setFlags(int);
void setType(int);
void togFlag(int);
static int currID;
s32 mType;
s32 mFlags;
s32 _1C;
};
class FaceNode : public CoreNode {
public:
FaceNode()
: CoreNode("face")
{
}
FaceNode(int faceCount)
: CoreNode("face")
{
mFaceCount = faceCount;
mMtxIdx = 0 ;
mVtxIdx = 0 ;
mColIdx = 0 ;
mNrmIdx = 0 ;
mTexCoords[0] = 0 ;
}
int mFaceCount;
int* mMtxIdx;
int* mVtxIdx;
int* mColIdx;
int* mNrmIdx;
int* mTexCoords[8];
};
class SRTNode : public Node {
public:
SRTNode( char* name);
virtual void update();
virtual void concat(Matrix4f&) { }
virtual void concat() { }
virtual Matrix4f* getModelMatrix() { return &mWorldMtx; }
Vector3f& getPosition() { return mSRT.t; }
Vector3f& getRotation() { return mSRT.r; }
Vector3f& getScale() { return mSRT.s; }
Vector3f& getWorldPosition() { return reinterpret_cast<Vector3f&>(mWorldMtx.mMtx[3]); }
void setPosition( Vector3f& pos) { mSRT.t = pos; }
void setRotation( Vector3f& rot) { mSRT.r = rot; }
void setScale( Vector3f& scale) { mSRT.s = scale; }
Matrix4f mWorldMtx;
SRT mSRT;
};
class NodeMgr {
public:
NodeMgr();
~NodeMgr();
inline CoreNode* firstNode() { return &mRootNode; }
CoreNode* findNode( char*, CoreNode*);
void recFindNode(CoreNode*, char*);
void Del(Node*);
bool mDelHappened;
CoreNode mRootNode;
};
extern NodeMgr* nodeMgr;
enum KeyboardButtons {
KBBTN_CSTICK_LEFT = 1 << 0,
KBBTN_CSTICK_RIGHT = 1 << 1,
KBBTN_CSTICK_UP = 1 << 2,
KBBTN_CSTICK_DOWN = 1 << 3,
KBBTN_DPAD_LEFT = 1 << 8,
KBBTN_DPAD_RIGHT = 1 << 9,
KBBTN_DPAD_UP = 1 << 10,
KBBTN_DPAD_DOWN = 1 << 11,
KBBTN_A = 1 << 12,
KBBTN_B = 1 << 13,
KBBTN_X = 1 << 14,
KBBTN_Y = 1 << 15,
KBBTN_Z = 1 << 16,
KBBTN_L = 1 << 17,
KBBTN_R = 1 << 18,
KBBTN_MSTICK_UP = 1 << 19,
KBBTN_MSTICK_RIGHT = 1 << 20,
KBBTN_MSTICK_DOWN = 1 << 21,
KBBTN_MSTICK_LEFT = 1 << 22,
KBBTN_START = 1 << 24,
KBBTN_NONE = 0x0,
KBBTN_ANY = 0xffffffff,
KBBTN_ANY_BUTTON = KBBTN_A | KBBTN_B | KBBTN_X | KBBTN_Y | KBBTN_Z | KBBTN_L | KBBTN_R | KBBTN_START,
};
class Controller : public Node {
public:
Controller(int playerNum)
: Node("<Controller>")
{
initialise(playerNum);
}
virtual void update();
void reset(u32 playerNum);
void updateCont(u32 keyStatus);
f32 getMainStickX();
f32 getMainStickY();
f32 getSubStickX();
f32 getSubStickY();
void initialise(u32 playerNum) { reset(playerNum); }
bool keyDown(u32 button) { return (mCurrentInput & button) != 0; }
bool keyUp(u32 button) { return (mCurrentInput & button) == 0; }
bool keyClick(u32 button) { return (mInputPressed & button) != 0; }
bool keyDoubleClick(u32 button) { return (mInputDoublePressed & button) != 0; }
bool keyUnClick(u32 button) { return (mInputReleased & button) != 0; }
u32 mCurrentInput;
u32 mPrevInput;
u32 mInputPressed;
u32 mInputReleased;
u32 mInputDoublePressed;
u32 mDoublePressMask;
u32 mPlayerNum;
u32 _3C;
u32 mInputDelay;
bool mIsControllerFrozen;
s8 mMainStickX;
s8 mMainStickY;
s8 mSubStickX;
s8 mSubStickY;
u8 mAnalogA;
u8 mAnalogB;
u8 mTriggerL;
u8 mTriggerR;
};
class ControllerMgr {
public:
virtual bool keyDown(int);
void update();
void init();
void updateController(Controller*);
};
class IDelegate {
public:
virtual void invoke() = 0;
};
template <typename A>
class IDelegate1 {
public:
virtual void invoke(A) = 0;
};
template <typename A, typename B>
class IDelegate2 {
public:
virtual void invoke(A, B) = 0;
};
template <typename T>
struct Delegate : public IDelegate {
typedef void (T::*CallbackFunc)();
inline Delegate(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke() { (mTarget->*mCallback)(); }
T* mTarget;
CallbackFunc mCallback;
};
template <typename T, typename A>
struct Delegate1 : public IDelegate1<A> {
typedef void (T::*CallbackFunc)(A);
inline Delegate1(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke(A arg) { (mTarget->*mCallback)(arg); }
T* mTarget;
CallbackFunc mCallback;
};
template <typename T, typename A, typename B>
struct Delegate2 : public IDelegate2<A, B> {
typedef void (T::*CallbackFunc)(A, B);
inline Delegate2(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke(A argA, B argB) { (mTarget->*mCallback)(argA, argB); }
T* mTarget;
CallbackFunc mCallback;
};
extern "C"{
typedef struct ARQRequest ARQRequest;
typedef void (*ARCallback)(void);
typedef void (*ARQCallback)(u32 ptrToRequest);
struct ARQRequest {
ARQRequest* next;
u32 owner;
u32 type;
u32 priority;
u32 source;
u32 dest;
u32 length;
ARQCallback callback;
};
void __ARQServiceQueueLo();
void __ARQCallbackHack();
void __ARQInterruptServiceRoutine();
void ARQInit();
void ARQPostRequest(ARQRequest* task, u32 owner, u32 type, u32 priority, u32 source, u32 dest, u32 length, ARQCallback callback);
ARCallback ARRegisterDMACallback(ARCallback callback);
void ARStartDMA(u32 type, u32 mainmem_addr, u32 aram_addr, u32 length);
u32 ARInit(u32* stack_index_addr, u32 num_entries);
u32 ARGetBaseAddress();
u16 __ARGetInterruptStatus();
}
class AgeServer;
class RandomAccessStream;
class ID32 {
public:
ID32();
ID32(u32 id);
void operator=(u32 id);
bool operator==(u32 id) ;
bool operator!=(u32 id) ;
bool match(u32 id, char wild = '*') ;
void print() ;
void read(RandomAccessStream& stream);
void setID(u32 id);
void sprint(char* str) ;
void updateID();
void updateString();
void write(RandomAccessStream& stream) ;
void genAge(AgeServer&, char*);
void ageChangeID() { updateID(); }
u32 mId;
char mStringID[5];
};
class AnimData;
class Shape;
class TexImg;
class Texture;
class GfxobjInfo {
public:
GfxobjInfo()
{
mPrev = mNext = 0 ;
mString = "";
mId.setID('none');
mAttached = 0;
}
void insertAfter(GfxobjInfo* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
GfxobjInfo* mPrev;
GfxobjInfo* mNext;
char* mString;
ID32 mId;
u32 mAttached;
virtual void attach() { }
virtual void detach() { }
};
class GfxObject {
public:
virtual void attach() { }
virtual void detach() { }
};
class ShpobjInfo : public GfxobjInfo {
public:
ShpobjInfo()
: mTarget(0 )
{
}
Shape* mTarget;
};
void free(void*);
extern "C"{
typedef struct {
int quot;
int rem;
} div_t;
s32 abs(s32 __x);
s32 labs(s32 __x);
div_t div(s32 __numer, s32 __denom);
inline int _abs(int __x)
{
return __x > 0 ? __x : -__x;
}
}
extern "C"{
}
extern "C"{
int __mbtowc_noconv(wchar_t*, const char*, size_t);
int __wctomb_noconv(char*, wchar_t);
size_t wcstombs(char* s, const wchar_t* pwcs, size_t n);
int mbstowcs(wchar_t* pwc, const char* s, size_t n);
int wctomb(char* s, wchar_t wchar);
static int unicode_to_UTF8(char* s, wchar_t wchar);
int mbtowc(wchar_t* pwc, const char* s, size_t n);
static int is_utf8_complete(const char* s, size_t n);
}
extern "C"{
int rand();
void srand(u32 seed);
}
extern "C"{
f128 __strtold(int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* overflow);
s32 strtol(const char* str, char** end, int base);
f64 atof(const char* str);
}
extern "C"{
u32 __strtoul(int base, int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* negative,
int* overflow);
u64 __strtoull(int base, int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* negative,
int* overflow);
int atoi(const char* str);
u32 strtoul(const char* str, char** end, int base);
}
extern "C"{
void abort(void);
void atexit(void);
void exit(int);
}
struct DGXGraphics;
class BaseApp;
class CacheTexture;
class TextureCacher;
class LoadIdler;
class Timers;
class Font;
class BaseShape;
class CoreNode;
class LFInfo;
class LightFlare;
class LFlareGroup;
class Matrix4f;
class AtxRouter;
class ControllerMgr;
struct OSContext;
struct OSThread;
class Shape;
class AnimData;
class AnimFrameCacher;
class MemInfo;
class CacheInfo;
enum SystemHeapType {
SYSHEAP_NULL = -1,
SYSHEAP_Sys = 0,
SYSHEAP_Ovl = 1,
SYSHEAP_App = 2,
SYSHEAP_Load = 3,
SYSHEAP_Teki = 4,
SYSHEAP_Movie = 5,
SYSHEAP_Message = 6,
SYSHEAP_Lang = 7,
SYSHEAP_COUNT,
};
enum TimerState {
TS_Off = 0,
TS_On,
TS_Full
};
enum LanguageID {
LANG_FORCE_CHANGE = -1,
LANG_Adult = 0,
LANG_Child = 1,
LANG_CAPACITY = 8,
};
struct AddressNode : public CoreNode {
AddressNode()
: CoreNode("")
{
}
};
struct DirEntry : public CoreNode {
DirEntry()
: CoreNode("")
{
}
int mPending;
u32 mAddress;
};
class BinobjInfo : public GfxobjInfo {
public:
BinobjInfo()
: mData(0 )
{
}
u8* mData;
};
struct SystemCache : public ARQRequest {
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
void insertAfter(SystemCache* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
SystemCache* mNext;
SystemCache* mPrev;
};
struct SystemFlags { typedef
enum {
Active = 0x00200000,
Shutdown = 0x80000000,
} Type; } ;
class StdSystem {
public:
StdSystem();
void onceInit();
AyuHeap* getHeap(int heapIdx);
void resetHeap(int heapIdx, int flag);
int setHeap(int);
GfxobjInfo* findGfxObject( char*, u32);
Texture* loadTexture( char* path, bool isRelativePath);
Shape* loadShape( char* modelPath, bool checkCache);
AnimData* findAnimation( char*);
int findAnyIndex( char*, char*);
AnimData* loadAnimation(Shape* model, char* dataPath, bool isRelativePath);
void addAnimation(AnimData*, char*);
void addGfxObject(GfxobjInfo*);
void attachObjs();
void detachObjs();
void invalidateObjs(u32, u32);
void addTexture(Texture*, char*);
Shape* getShape( char*, char*, char*, bool);
void initLFlares(int);
void resetLFlares();
LFInfo* getLFlareInfo();
LFlareGroup* registerLFlare(Texture*);
void flushLFlares(Graphics&);
void loadBundle( char* pPath, bool loadWithCache);
void getAppMemory(char*);
GfxobjInfo* findAnyGfxObject( char*, u32);
GfxobjInfo* findTexture(Texture*);
AnimData* findAnyAnimation( char*);
AnimData* findIndexAnimation( char*, int);
static char* stringDup( char*);
f32 getRand(f32 max) { return max * (rand() / f32((0x7fff) )); }
f32 getHalfRand(f32 max) { return max * (rand() / f32((0x7fff) ) - 0.5f); }
f32 getFade() { return mCurrentFade; }
void setFade(f32 target, f32 rate = 3.0f)
{
mTargetFade = target;
mFadeRate = rate;
}
void set2DRoot( char* bloDir, char* texDir)
{
mBloDir = bloDir;
mTexDir = texDir;
}
void setTextureBase( char* base1, char* base2)
{
mTextureBase1 = base1;
mTextureBase2 = base2;
}
void setDataRoot( char* dir) { mDataRoot = dir; }
void softReset() { mSoftResetPending = true; }
void Shutdown() { mSystemFlags = SystemFlags::Shutdown; }
bool isShutdown() { return mSystemFlags == SystemFlags::Shutdown; }
bool resetPending() { return mSoftResetPending; }
void setFrameClamp(int frameRate) { mFrameRate = frameRate; }
int getHeapNum() { return mActiveHeapIdx; }
void setActive(bool set)
{
u32 unused;
if (set) {
mSystemFlags |= SystemFlags::Active;
unused = mSystemFlags;
} else {
mSystemFlags &= ~SystemFlags::Active;
unused = mSystemFlags;
}
Activate(set);
}
bool isActive(void) { return (mSystemFlags & SystemFlags::Active) == SystemFlags::Active; }
bool mSoftResetPending;
f32 mCurrentFade;
f32 mTargetFade;
f32 mFadeRate;
Font* mConsFont;
s32 mFrameRate;
u32 mTimerState;
u32 mTogglePrint;
u32 mToggleDebugInfo;
u32 mToggleDebugExtra;
u32 mToggleBlur;
u32 mToggleFileInfo;
u32 mToggleColls;
Timers* mTimer;
TextureCacher* mCacher;
u32 mMatrixCount;
Matrix4f* mMatrices;
char* mBloDir;
char* mTexDir;
char* mActiveDir;
char* mDataRoot;
AyuHeap mHeaps[SYSHEAP_COUNT];
int mActiveHeapIdx;
BOOL mToggleHeapAllocPrint;
MemInfo* mCurrMemInfo;
virtual void initSoftReset();
virtual RandomAccessStream* openFile( char* path, bool isRelativePath = true, bool = true) { return 0 ; }
virtual u32 copyRamToCache(u32, u32, u32) { return 0; }
virtual void copyCacheToRam(u32, u32, u32) { }
virtual void copyWaitUntilDone() { }
virtual void copyCacheToTexture(CacheTexture*) { }
virtual void Activate(bool) { }
virtual void parseArchiveDirectory( char* arcPath, char* dirPath) { }
virtual void sndPlaySe(u32) = 0;
virtual void startLoading(LoadIdler*, bool, u32) { }
virtual void endLoading() { }
int mPolygonCount;
u32 mMaterialCount;
u32 mDispCount;
u32 mLightCount;
s32 mActiveLightCount;
u32 mAnimatedPolygons;
u32 mLightingSkips;
u32 mLightingSets;
u32 mLightSetNum;
u32 mSystemFlags;
Graphics* mGraphics;
GfxobjInfo mGfxobjInfo;
bool mHasGfxObjects;
char* mTextureBase1;
char* mTextureBase2;
Shape* mCurrentShape;
CoreNode mDvdRoot;
CoreNode mAramRoot;
DirEntry* mFileList;
int mFlareCount;
int mLfInfoCount;
LFInfo* mFlareInfoList;
LFlareGroup* mFlareGroupList;
int mDvdOpenFiles;
u32 mDvdBytesRead;
void ageAnyAnimations(AgeServer&, char*);
};
struct AramAllocator {
void init(u32 start, u32 size)
{
mStartAddress = start;
mTotalSize = size;
reset();
}
void reset() { mNextFreeAddress = mStartAddress; }
u32 alloc(u32 numBytes)
{
u32 allocAddr = 0;
u32 nextFree = mNextFreeAddress;
if (nextFree + numBytes <= mStartAddress + mTotalSize) {
allocAddr = nextFree;
mNextFreeAddress = nextFree + numBytes;
}
return allocAddr;
}
u32 getFreeSize() { return mStartAddress + mTotalSize - mNextFreeAddress; }
u32 mStartAddress;
u32 mNextFreeAddress;
u32 mTotalSize;
};
struct DvdError { typedef
enum {
None = -1,
ReadingDisc = 0,
FatalError = 1,
RetryError = 2,
NoDisc = 3,
CoverOpen = 4,
WrongDisc = 5
} Type; } ;
struct SystemClass250 {
virtual void method(Graphics& gfx) = 0;
};
struct SymbolInfo {
SymbolInfo* mNext;
u32 mVirtualAddress;
char mDemangledName[];
};
class System : public StdSystem {
public:
System();
virtual void initSoftReset();
virtual RandomAccessStream* openFile( char* path, bool isRelativePath = true, bool = true);
virtual u32 copyRamToCache(u32, u32, u32);
virtual void copyCacheToRam(u32, u32, u32);
virtual void copyWaitUntilDone();
virtual void copyCacheToTexture(CacheTexture*);
virtual void parseArchiveDirectory( char* arcPath, char* dirPath);
virtual void sndPlaySe(u32);
virtual void startLoading(LoadIdler* idler, bool useLoadScreen, u32 loadDelay);
virtual void endLoading();
~System();
void run(BaseApp* app);
void beginRender();
void doneRender();
void waitRetrace();
f32 getTime();
void updateSysClock();
void hardReset();
void showDvdError(Graphics&);
void nudgeLoading();
void nudgeDvdThread();
void startDvdThread();
void Initialise();
RandomAccessStream* createFile( char*, BOOL);
char* findAddress(u32);
bool hasDebugInfo();
static void halt( char* file, int line, char* message);
void sleep(f32 seconds);
static void* alloc(size_t);
AtxRouter* getAtxRouter() { return mAtxRouter; }
void setAtxRouter(AtxRouter* router) { mAtxRouter = router; }
f32 getFrameTime() { return mDeltaTime; }
f32 getFrameRate() { return mFPS; }
int setStreamType(int);
void setActiveAramAllocator(AramAllocator* allocator) { mActiveAramAllocator = allocator; }
u32 mHeapStart;
u32 mHeapEnd;
Graphics* mDGXGfx;
SystemClass250* mHaltCallback;
Delegate1<System, Graphics&>* mDvdErrorCallback;
int mDvdErrorCode;
u32 mDvdBufferSize;
u32 mIsLoadingActive;
u32 mLoadTimeBeforeIdling;
u32 mIsLoadScreenActive;
vu32 mIsRendering;
u32 mIsCardSaving;
OSThread* mCurrentThread;
AtxRouter* mAtxRouter;
ControllerMgr mControllerMgr;
u32 mPrevTick;
u32 mFpsSampleStart;
int mFrameTicks;
f32 mDeltaTime;
f32 mFPS;
u32 mEngineFrames;
u32 mFramesAtSampleStart;
u32 mTotalFrames;
u32 mRetraceCount;
BOOL mPrevAllocType;
AddressNode _2A8;
SymbolInfo* mBuildMapFuncList;
SystemCache mActiveCacheList;
SystemCache mFreeCacheList;
AramAllocator mShapeAramAllocator;
AramAllocator mBaseAramAllocator;
AramAllocator* mActiveAramAllocator;
vu32 mDmaComplete;
vu32 mTexComplete;
};
extern System* gsys;
struct LogStream : public Stream {
LogStream()
{
mBufPosition = 0;
_UNUSED0C = 0;
}
virtual void flush()
{
mBuffer[mBufPosition] = 0;
if (gsys->mTogglePrint) {
OSReport("%s\n", mBuffer);
}
mBufPosition = 0;
}
virtual void write( void* data, int size)
{
for (int i = 0; i < size; i++) {
char c = (( char*)data)[i];
if (c == 0xA) {
flush();
continue;
}
if (c == 0x9) {
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = ' ';
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = ' ';
continue;
}
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = c;
}
}
int mBufPosition;
u32 _UNUSED0C;
char mBuffer[0x100];
};
struct AramStream : public RandomAccessStream {
virtual int getPending() { return mPending; }
virtual void read(void* data, int size)
{
int readSize = (((u32)(size) + 0x1F) & ~(0x1F)) ;
gsys->copyCacheToRam((u32)data, mBaseAddress + mOffset, readSize);
gsys->copyWaitUntilDone();
mOffset += readSize;
}
void init( char* path, u32 address, int pending)
{
mPath = path;
mPending = pending;
mBaseAddress = address;
mOffset = 0;
}
u32 mBaseAddress;
u32 mOffset;
int mPending;
};
extern int glnWidth;
extern int glnHeight;
extern "C"{
typedef u32 __file_handle;
typedef u32 fpos_t;
typedef struct _IO_FILE _IO_FILE, *P_IO_FILE;
enum __file_kinds { __closed_file, __disk_file, __console_file, __unavailable_file };
enum __file_orientation { __unoriented, __char_oriented, __wide_oriented };
typedef struct __file_modes {
u32 open_mode : 2;
u32 io_mode : 3;
u32 buffer_mode : 2;
u32 file_kind : 3;
u32 binary_io : 1;
u32 unk12 : 1;
u32 unk13 : 1;
} file_modes;
enum __io_states { __neutral, __writing, __reading, __rereading };
typedef struct __file_states {
u32 io_state : 3;
u32 free_buffer : 1;
u8 eof;
u8 error;
} file_states;
typedef void* __ref_con;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc ref_con);
typedef int (*__io_proc)(__file_handle file, char* buff, size_t* count, __idle_proc ref_con);
typedef int (*__close_proc)(__file_handle file);
struct _IO_FILE {
__file_handle mHandle;
file_modes mMode;
file_states mState;
u8 mIsDynamicallyAllocated;
u8 mCharBuffer;
u8 mCharBufferOverflow;
u8 mUngetcBuffer[2 ];
u32 mPosition;
char* mBuffer;
u32 mBufferSize;
char* mBufferPtr;
u32 mBufferLength;
u32 mBufferAlignment;
u32 mBufferLength2;
u32 mBufferPosition;
__pos_proc positionFunc;
__io_proc readFunc;
__io_proc writeFunc;
__close_proc closeFunc;
__ref_con ref_con;
};
typedef struct _IO_FILE FILE;
typedef struct {
char* CharStr;
size_t MaxCharCount;
size_t CharsWritten;
} __OutStrCtrl;
typedef struct {
const char* NextChar;
int NullCharDetected;
} __InStrCtrl;
typedef struct {
wchar_t* wCharStr;
size_t MaxCharCount;
size_t CharsWritten;
} __wOutStrCtrl;
typedef struct {
const wchar_t* wNextChar;
int wNullCharDetected;
} __wInStrCtrl;
int puts(const char* s);
int printf(const char*, ...);
int vprintf(const char* format, va_list arg);
int vsnprintf(char* s, size_t n, const char* format, va_list arg);
int vsprintf(char* s, const char* format, va_list arg);
int snprintf(char* s, size_t n, const char* format, ...);
int sprintf(char* s, const char* format, ...);
int sscanf(const char* s, const char* format, ...);
extern FILE __files[3];
}
extern BOOL _nsPrint;
extern BOOL _cPrint;
extern BOOL _kPrint;
extern BOOL _nPrint;
extern BOOL _yPrint;
class Stream;
class String {
public:
String() { init(64); }
String(int length) { init(length); }
String(char* str, int length) { init(str, length); }
void init(char* str)
{
mString = str;
}
void init(int length)
{
mString = length ? new char[length + 1] : 0 ;
mLength = length;
}
void init(char* str, int length)
{
mString = str;
mLength = length;
}
static bool equals( char* lhs, char* rhs) { return isSame(lhs, rhs); }
static bool isSame( char*, char*);
bool isSame( char*) ;
bool isSame( String* other) { return isSame(other->mString); }
static bool contains( char*, char*);
static bool contains( char* str, char c)
{
char substr[] = { c, '\0' };
return contains(str, substr);
}
bool contains( char* substr) { return contains(mString, substr); }
static char* dup( char*);
char* dup() { return dup(mString); }
static bool isWhiteSpace(char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c < ' '; }
float toFloat() ;
static int toInt( char*);
int toInt() ;
static int getLength( char*);
int getLength() ;
static u32 calcHash( char*);
u32 calcHash() ;
static char* copy(char*, char*);
static bool copyUntil(char*, char*, char, char**);
static void concat(char*, char*);
int mLength;
char* mString;
};
struct StringArray {
void read(Stream&);
void write(Stream&);
int mSize;
String* mElems;
};
enum StageID {
STAGE_Practice = 0,
STAGE_Forest = 1,
STAGE_Cave = 2,
STAGE_Yakushima = 3,
STAGE_Last = 4,
STAGE_COUNT,
STAGE_START = STAGE_Practice,
STAGE_TESTMAP = STAGE_COUNT,
STAGE_COUNT_INCLUDING_TESTMAPS,
};
enum ChalStageID {
CHALSTAGE_Practice = STAGE_Practice,
CHALSTAGE_Forest = STAGE_Forest,
CHALSTAGE_Cave = STAGE_Cave,
CHALSTAGE_Yakushima = STAGE_Yakushima,
CHALSTAGE_Last = STAGE_Last,
CHALSTAGE_COUNT,
CHALSTAGE_START = CHALSTAGE_Practice,
CHALSTAGE_NOT = CHALSTAGE_COUNT + 2,
};
enum PikiColor {
Blue = 0,
Red = 1,
Yellow = 2,
PikiColorCount,
PikiMinColor = Blue,
PikiMaxColor = Yellow,
PIKI_Kinoko = 3,
};
enum PikiHappa {
Leaf = 0,
Bud = 1,
Flower = 2,
PikiHappaCount,
PikiMinHappa = Leaf,
PikiMaxHappa = Flower,
};
class Graphics;
class LoadIdler : public CoreNode {
public:
LoadIdler()
: CoreNode("")
{
}
virtual void init() { }
virtual void draw(Graphics&) { }
};
struct GameLoadIdler : public LoadIdler {
virtual void init() { }
virtual void draw(Graphics& gfx);
};
struct CARDStat;
class PlayState;
class RamStream;
extern u8 cardData[(0x26000) ];
class CardQuickInfo {
public:
CardQuickInfo() { mSaveStatus = 0; }
int mMemCardSaveIndex;
u32 mGameSaveSlot;
u32 mSaveStatus;
int mCurrentDay;
int mCurrentPartsCount;
int mRedPikiCount;
int mYellowPikiCount;
int mBluePikiCount;
int mMostRecentSaveSlot;
u32 mCrc;
};
struct MemoryCard : public CoreNode {
public:
inline MemoryCard()
: CoreNode("memoryCard")
{
mTempFileIndex = -1;
mCardChannel = -1;
mSaveFileIndex = -1;
mRequiredFreeSpace = (0x26000) ;
mErrorCode = 0;
}
void init();
bool hasCardFinished();
s32 getMemoryCardState(bool);
s32 getNewestOptionsIndex();
void loadOptions();
void saveOptions();
void loadCurrentGame();
void saveCurrentGame();
s32 makeDefaultFile();
void copyFile(CardQuickInfo&, CardQuickInfo&);
void delFile(CardQuickInfo&);
s32 doFormatCard();
bool isCardInserted();
bool hasCardChanged();
bool isFileBroken();
void breakFile();
void repairFile();
bool didSaveFail();
void getQuickInfos(CardQuickInfo*);
protected:
u32 calcChecksum(void*, u32);
void waitPolling();
void createFile(CARDStat&);
void writeOneBanner();
void writeOneOption(int);
void writeOneGameFile(int);
bool attemptFormatCard(int);
s32 waitWhileBusy(int);
bool getCardStatus(int);
void checkUseFile();
void loadCurrentFile();
void writeCurrentGame(RandomAccessStream*, PlayState&);
void readCurrentGame(RandomAccessStream*);
void initBannerArea(CARDStat&, char*);
void initFileArea(int, int);
void initOptionsArea(int);
u32 getOkSections();
int getOptionsOffset(int);
int getGameFileOffset(int);
void GetBlockSize(s32);
void* getBannerPtr();
void* getOptionsPtr(int);
void* getGameFilePtr(int);
void* FAKE_getGameFilePtr(int);
RamStream* getBannerStream();
RamStream* getOptionsStream(int);
RamStream* getGameFileStream(int);
public:
char mFilePath[32];
int mCardChannel;
int mSaveFileIndex;
int mTempFileIndex;
u32 mRequiredFreeSpace;
u32 mErrorCode;
u32 mOkSectionsMask;
BOOL mValidSlots[4];
int mValidBlockCount;
int mValidOptionsCount;
u32 mSectorSize;
bool mDidSaveFail;
int _UNUSED6C;
};
enum EObjType {
OBJTYPE_INVALID = -1,
OBJTYPE_Piki = 0,
OBJTYPE_Water = 1,
OBJTYPE_Seed = 2,
OBJTYPE_Key = 3,
OBJTYPE_Door = 4,
OBJTYPE_Gate = 5,
OBJTYPE_FallWater = 6,
OBJTYPE_Gem5 = 7,
OBJTYPE_Gem10 = 8,
OBJTYPE_Gem20 = 9,
OBJTYPE_Gem50 = 10,
OBJTYPE_Gem1 = 11,
OBJTYPE_GemItem = 12,
OBJTYPE_BombGen = 13,
OBJTYPE_Bomb = 14,
OBJTYPE_Pikihead = 15,
OBJTYPE_Goal = 16,
OBJTYPE_Fulcrum = 17,
OBJTYPE_Rope = 18,
OBJTYPE_Ivy = 19,
OBJTYPE_TestCylinder = 20,
OBJTYPE_TestDual = 21,
OBJTYPE_SluiceSoft = 22,
OBJTYPE_SluiceHard = 23,
OBJTYPE_SluiceBomb = 24,
OBJTYPE_SluiceBombHard = 25,
OBJTYPE_Rocket = 26,
OBJTYPE_SunsetStart = 27,
OBJTYPE_SunsetGoal = 28,
OBJTYPE_Kusa = 29,
OBJTYPE_Ufo = 30,
OBJTYPE_Weeds = 31,
OBJTYPE_Weed = 32,
OBJTYPE_RockGen = 33,
OBJTYPE_GrassGen = 34,
OBJTYPE_BoBase = 35,
OBJTYPE_Secret1 = 36,
OBJTYPE_Fish = 37,
OBJTYPE_WorkObject = 38,
OBJTYPE_BossBegin = 39,
OBJTYPE_Spider = OBJTYPE_BossBegin,
OBJTYPE_Giant = 40,
OBJTYPE_Snake = 41,
OBJTYPE_TwSnake = 42,
OBJTYPE_King = 43,
OBJTYPE_Slime = 44,
OBJTYPE_Kogane = 45,
OBJTYPE_Pom = 46,
OBJTYPE_KingBack = 47,
OBJTYPE_Nucleus = 48,
OBJTYPE_Mizu = 49,
OBJTYPE_XXX3 = 50,
OBJTYPE_BossEnd = OBJTYPE_XXX3,
OBJTYPE_Plant = 51,
OBJTYPE_Pellet = 52,
OBJTYPE_Navi = 54,
OBJTYPE_Teki = 55,
OBJTYPE_NULL = 57,
};
struct ObjType {
static char* getName(int);
static int getIndex( char*);
EObjType mIndex;
char* mName;
};
class Creature;
class CreatureInf;
class Piki;
class RandomAccessStream;
typedef CreatureInf* (*CreatureStoreFun)(Creature*);
typedef Creature* (*CreatureRestoreFun)(CreatureInf*);
class BaseInf : public CoreNode {
public:
BaseInf();
virtual void doStore(Creature*) { }
virtual void doRestore(Creature*) { }
virtual void saveCard(RandomAccessStream&);
virtual void loadCard(RandomAccessStream&);
void store(Creature*);
void restore(Creature*);
Vector3f mPosition;
Vector3f mRotation;
};
struct BPikiInf : public BaseInf {
BPikiInf();
virtual void doStore(Creature*);
virtual void doRestore(Creature*);
virtual void saveCard(RandomAccessStream&);
virtual void loadCard(RandomAccessStream&);
u8 mPikiColour;
u8 mNextKeyIndex;
};
class CreatureInf : public BaseInf {
public:
CreatureInf();
virtual void doStore(Creature*);
virtual void doRestore(Creature*);
EObjType mObjType;
int mCurrentDay;
int mRebirthDay;
int mAdjustFaceDirection;
int mObjInfo1;
int mObjInfo2;
f32 mHealth;
f32 mMaxHealth;
};
struct InfMgr {
virtual void init(int) { }
virtual BaseInf* getFreeInf() = 0;
virtual void delInf(BaseInf*) = 0;
virtual int getFreeNum() = 0;
virtual int getActiveNum() = 0;
};
struct MonoInfMgr : public InfMgr {
MonoInfMgr();
virtual void init(int);
virtual BaseInf* getFreeInf();
virtual void delInf(BaseInf*);
virtual int getFreeNum();
virtual int getActiveNum();
virtual BaseInf* newInf() = 0;
void loadCard(RandomAccessStream&);
void saveCard(RandomAccessStream&);
int mInfCount;
BaseInf** mInfs;
BaseInf mActiveList;
BaseInf mFreeList;
};
struct BPikiInfMgr : public MonoInfMgr {
virtual BaseInf* newInf();
int getPikiCount(int color);
void initGame();
};
struct CreatureInfMgr : public MonoInfMgr {
struct TypeData {
int mType;
CreatureStoreFun mStoreFun;
CreatureRestoreFun mRestoreFun;
};
virtual BaseInf* newInf();
static void beginRegister(int size);
static void registerType(int, CreatureStoreFun, CreatureRestoreFun);
static void endRegister();
static CreatureStoreFun getStoreFun(int);
static CreatureRestoreFun getRestoreFun(int);
void updateUseList();
void restoreAll();
static int maxTypes;
static int numTypes;
static int* idx2type;
static TypeData* typeData;
};
class PikiInfMgr {
public:
PikiInfMgr();
void initGame();
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
void incPiki(Piki*);
void incPiki(int, int);
void decPiki(Piki*);
void clear();
int getTotal();
int getColorTotal(int col) { return mPikiCounts[col][Leaf] + mPikiCounts[col][Bud] + mPikiCounts[col][Flower]; }
int mPikiCounts[PikiColorCount][PikiHappaCount];
};
struct StageInf {
void init();
void initGame();
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
BPikiInfMgr mBPikiInfMgr;
};
extern PikiInfMgr pikiInfMgr;
class Controller;
class ModeState;
class Menu;
enum GameSectionID {
SECTION_NinLogo = 0,
SECTION_Titles = 1,
SECTION_MovSample = 2,
SECTION_PaniTest = 3,
SECTION_OnePlayer = 4,
SECTION_OgTest = 5,
};
enum OnePlayerSectionID {
ONEPLAYER_GameSetup = 0,
ONEPLAYER_CardSelect = 1,
ONEPLAYER_E3Tutorial = 2,
ONEPLAYER_E3ForestDay1 = 3,
ONEPLAYER_E3ForestDay2 = 4,
ONEPLAYER_IntroGame = 5,
ONEPLAYER_MapSelect = 6,
ONEPLAYER_NewPikiGame = 7,
ONEPLAYER_GameCourseClear = 8,
ONEPLAYER_GameStageClear = 9,
ONEPLAYER_GameCredits = 10,
ONEPLAYER_GameExit = 11,
ONEPLAYER_E3_MIN = ONEPLAYER_E3Tutorial,
ONEPLAYER_E3_MAX = ONEPLAYER_E3ForestDay2,
ONEPLAYER_E3_STAGE_OFFSET = ONEPLAYER_E3Tutorial,
};
enum ModeUpdateFlags {
UPDATE_NONE = 0,
UPDATE_AI = 1 << 0,
UPDATE_WORLD_CLOCK = 1 << 1,
UPDATE_COUNTDOWN = 1 << 2,
UPDATE_ALL = UPDATE_AI | UPDATE_WORLD_CLOCK | UPDATE_COUNTDOWN,
};
struct Section : public Node {
Section() { }
virtual void init() = 0;
};
class BaseGameSection : public Node {
public:
BaseGameSection();
virtual void draw(Graphics& gfx);
virtual void openMenu() { }
Menu* mActiveMenu;
Controller* mController;
f32 mCurrentFade;
f32 mTargetFade;
f32 mFadeSpeed;
ModeState* mCurrentModeState;
ModeState* mNextModeState;
u32 mUpdateFlags;
int mPendingOnePlayerSectionID;
};
class ModeState {
public:
ModeState(BaseGameSection* game)
: mParentSection(game)
{
}
BaseGameSection* mParentSection;
virtual ModeState* update(u32& result)
{
result = UPDATE_AI | UPDATE_WORLD_CLOCK;
return this;
}
virtual void postRender(Graphics&) { }
virtual void postUpdate() { }
};
class CmdStream;
struct GenFileInfo : public CoreNode {
inline GenFileInfo()
: CoreNode("")
{
}
u8 mFirstSpawnDay;
u8 mLastSpawnDay;
u8 mDayLimit;
};
class StageInfo : public CoreNode {
public:
inline StageInfo()
: CoreNode("stageInfo")
{
mStageIndex = 0;
mStageID = STAGE_TESTMAP;
mChalStageID = CHALSTAGE_NOT;
mHasInitialised = (0) ;
mGenFileList.initCore("");
}
virtual void read(RandomAccessStream&);
void parseGenerators(CmdStream*);
void write(RandomAccessStream&);
char* mStageName;
char* mFileName;
BOOL mIsVisible;
BOOL mHasInitialised;
u16 mStageIndex;
u16 mStageID;
u16 mChalStageID;
StageInf mStageInf;
GenFileInfo mGenFileList;
};
struct OnePlayerSection : public Section {
virtual void init();
};
class AgeServer;
class Parameters;
class RandomAccessStream;
class ayuID {
public:
ayuID() { mID = 0; }
ayuID( char* const id) { Set(id); }
void Set( char* id) { mID = *(s32*)id; }
long& Num() { return mID; };
long mID;
};
struct BaseParm {
BaseParm(Parameters*, ayuID);
ayuID mID;
BaseParm* mNext;
virtual int size() = 0;
virtual void write(RandomAccessStream& output) { }
virtual void read(RandomAccessStream& input) { }
};
class Parameters {
public:
Parameters( char* name)
{
mFirstParm = 0 ;
}
void write(RandomAccessStream&);
void read(RandomAccessStream&);
int sizeInFile();
BaseParm* mFirstParm;
};
template <typename T>
struct Parm : public BaseParm {
Parm(Parameters* owner, T value, T min, T max, ayuID id, char* name)
: BaseParm(owner, id)
{
mValue = value;
}
virtual int size() { return sizeof(T); }
virtual void write(RandomAccessStream&);
virtual void read(RandomAccessStream&);
T& operator()() { return mValue; }
void operator()(T val) { mValue = val; }
T mValue;
};
struct WorldClock {
void setTime(f32 timeOfDay);
void update(f32 playRate);
void setClockSpd(f32 minsPerGameDay);
void reset(f32 minsPerGameDay);
f32 age(f32 referenceDay);
f32 mRealSecsPerGameHour;
f32 mHoursInDay;
f32 mRealSecsPerGameDay;
u8 _0C[0x4];
f32 mPrevTimeOfDay;
f32 mRealSecsIntoHour;
f32 mTimeOfDay;
f32 mDeltaTimeOfDay;
int mCurrentGameHour;
int mCurrentDay;
int mCurrentGameMinute;
};
class AnimFrameCacher;
class BaseApp;
class GameQuickInfo;
class GameChalQuickInfo;
struct GameInterface;
struct GameGenFlow;
class Menu;
struct MoviePlayer;
struct Section;
class Shape;
class Texture;
enum GamePrefsFlags {
GAMEPREF_Vibe = 0x1,
GAMEPREF_Stereo = 0x2,
GAMEPREF_Child = 0x4,
};
enum GameFilterType {
FILTER_Custom = 0,
FILTER_DFOff = 1,
FILTER_COUNT,
};
enum MovSampleID {
MOV_GrowDemo = 0,
MOV_ThrowDemo = 1,
MOV_WorkDemo = 2,
MOV_DeathDemo = 3,
MOV_NormalEnding = 4,
MOV_HappyEnding = 5,
MOV_COUNT,
MOV_INTRO_CYCLE_MASK = 0x3,
MOV_ENDING_OFFSET = 0x3,
};
enum LanguageFileType {
LANGFILE_Dir = 0,
LANGFILE_Arc = 1,
LANGFILE_Bun = 2,
LANGFILE_Blo = 3,
LANGFILE_Tex = 4,
LANGFILE_COUNT,
};
enum ShipTextType {
SHIPTEXT_CollectEngine = -1,
SHIPTEXT_PartCollect = 0,
SHIPTEXT_PartsAccess = 1,
SHIPTEXT_PowerUp = 2,
SHIPTEXT_PartDiscovery = 3,
};
class GameQuickInfo {
public:
u32 mParts;
u32 mDay;
u32 mBornPikis;
u32 mDeadPikis;
int mPartsDaysRank;
int mBornPikisRank;
int mDeadPikisRank;
};
class GameChalQuickInfo {
public:
int mStageID;
u32 mScore;
int mRank;
u32 mCourseScores[(5) ];
};
struct LangMode {
void set( char* dir, char* arc, char* bun, char* blo, char* tex)
{
mDirPath = dir;
mArcPath = arc;
mBunPath = bun;
mBloPath = blo;
mTexPath = tex;
}
char* mDirPath;
char* mArcPath;
char* mBunPath;
char* mBloPath;
char* mTexPath;
};
struct GameGenNode : public Node {
inline GameGenNode( char* name, CoreNode* node)
: Node(name)
{
mNode = node;
}
CoreNode* mNode;
};
class PlayState : public CoreNode {
public:
enum SaveStatus {
Fresh = 1,
ReadyToSave = 2,
};
PlayState()
: CoreNode("playState")
{
mSaveSlot = 0;
mSaveStatus = Fresh;
}
virtual void read(RandomAccessStream& input);
virtual void write(RandomAccessStream& output);
void openStage(int storyStageID);
void Initialise()
{
mSaveStatus = Fresh;
mBluePikiCount = -1;
mYellowPikiCount = -1;
mRedPikiCount = -1;
mSavedDay = 1;
mShipPartsCount = 0;
(mCourseOpenFlags) = 1 << (STAGE_Practice) ;
}
bool isStageOpen(int storyStageID)
{
if (storyStageID >= STAGE_START && storyStageID <= STAGE_TESTMAP) {
return ((mCourseOpenFlags) & (1 << (storyStageID))) != false;
}
return false;
}
int mRedPikiCount;
int mYellowPikiCount;
int mBluePikiCount;
u8 mSaveStatus;
u8 mSavedDay;
u8 mShipPartsCount;
u8 mSaveSlot;
u32 mCourseOpenFlags;
};
struct GameRecMinDay {
GameRecMinDay() { Initialise(); }
void Initialise()
{
mNumParts = 0;
mNumDays = (30) ;
}
void read(RandomAccessStream& input)
{
mNumParts = input.readInt();
mNumDays = input.readInt();
}
void write(RandomAccessStream& output)
{
output.writeInt(mNumParts);
output.writeInt(mNumDays);
}
int mNumParts;
int mNumDays;
};
struct GameRecBornPikmin {
GameRecBornPikmin() { Initialise(); }
void Initialise() { mNumBorn = 0; }
void read(RandomAccessStream& input) { mNumBorn = input.readInt(); }
void write(RandomAccessStream& output) { output.writeInt(mNumBorn); }
int mNumBorn;
};
struct GameRecDeadPikmin {
GameRecDeadPikmin() { Initialise(); }
void Initialise() { mNumDead = 9999; }
void read(RandomAccessStream& input) { mNumDead = input.readInt(); }
void write(RandomAccessStream& output) { output.writeInt(mNumDead); }
int mNumDead;
};
struct GameRecChalCourse {
GameRecChalCourse() { Initialise(); }
void Initialise()
{
for (int i = 0; i < (5) ; i++) {
mScores[(5) ] = 0;
}
}
void read(RandomAccessStream& input)
{
for (int i = 0; i < (5) ; i++) {
mScores[i] = input.readInt();
}
}
void write(RandomAccessStream& output)
{
for (int i = 0; i < (5) ; i++) {
output.writeInt(mScores[i]);
}
}
int mScores[(5) ];
};
struct GameHiscores {
void Initialise()
{
mTotalPikis = 0;
for (int i = 0; i < (5) ; i++) {
mMinDayRecords[i].Initialise();
mBornPikminRecords[i].Initialise();
mDeadPikminRecords[i].Initialise();
mChalModeRecords[i].Initialise();
}
}
void read(RandomAccessStream& input)
{
mTotalPikis = input.readInt();
for (int i = 0; i < (5) ; i++) {
mMinDayRecords[i].read(input);
mBornPikminRecords[i].read(input);
mDeadPikminRecords[i].read(input);
mChalModeRecords[i].read(input);
}
}
void write(RandomAccessStream& output)
{
output.writeInt(mTotalPikis);
for (int i = 0; i < (5) ; i++) {
mMinDayRecords[i].write(output);
mBornPikminRecords[i].write(output);
mDeadPikminRecords[i].write(output);
mChalModeRecords[i].write(output);
}
}
int mTotalPikis;
GameRecMinDay mMinDayRecords[(5) ];
GameRecBornPikmin mBornPikminRecords[(5) ];
GameRecDeadPikmin mDeadPikminRecords[(5) ];
GameRecChalCourse mChalModeRecords[CHALSTAGE_COUNT];
};
struct GamePrefs : public CoreNode {
GamePrefs()
: CoreNode("gamePrefs")
{
Initialise();
}
virtual void read(RandomAccessStream& input);
virtual void write(RandomAccessStream& output);
void Initialise()
{
mFlags = GAMEPREF_Vibe | GAMEPREF_Stereo;
mBgmVol = 8;
mSfxVol = 8;
mMostRecentFileSlot = 0;
mHasSaveGame = false;
mMemCardSaveIndex = 0;
mSpareMemCardSaveIndex = 0;
_1F = 0;
mChalCourseOpenFlags = 0 ;
mChangesPending = false;
mHiscores.Initialise();
}
void setBgmVol(u8 vol);
void setSfxVol(u8 vol);
void setStereoMode(bool set);
void setVibeMode(bool set);
void setChildMode(bool set);
void getChallengeScores(GameChalQuickInfo& info);
void checkIsHiscore(GameChalQuickInfo& info);
void checkIsHiscore(GameQuickInfo& info);
void fixSoundMode();
void addBornPikis(u32 count) { mHiscores.mTotalPikis += count; }
void openStage(int chalStageID)
{
if (chalStageID >= CHALSTAGE_START && chalStageID <= CHALSTAGE_COUNT) {
(mChalCourseOpenFlags) |= 1 << (chalStageID) ;
}
}
bool isStageOpen(int chalStageID)
{
if (chalStageID >= CHALSTAGE_START && chalStageID <= CHALSTAGE_COUNT) {
return ((mChalCourseOpenFlags) & (1 << (chalStageID))) != false;
}
return false;
}
bool getVibeMode() { return (mFlags & GAMEPREF_Vibe) != 0; }
bool getStereoMode() { return (mFlags & GAMEPREF_Stereo) != 0; }
bool getChildMode() { return (mFlags & GAMEPREF_Child) != 0; }
u8 getBgmVol() { return mBgmVol; }
u8 getSfxVol() { return mSfxVol; }
bool isChallengeOpen() { return mChalCourseOpenFlags != 0; }
bool mChangesPending;
int mFlags;
u8 mBgmVol;
u8 mSfxVol;
bool mHasSaveGame;
u8 _1F;
u8 mMemCardSaveIndex;
u8 mSpareMemCardSaveIndex;
u8 mChalCourseOpenFlags;
GameHiscores mHiscores;
u32 mMostRecentSaveIndex;
u32 mMostRecentOptionsIndex;
u8 _E4[0x108 - 0xE4];
u32 mMostRecentFileSlot;
};
class GameFlow : public Node {
public:
struct Parms : public Parameters {
inline Parms()
: Parameters("GameFlow::Preferences")
, mStartHour(this, 7.0f, 0.0f, 0.0f, "t00", "startHour")
, mEndHour(this, 19.0f, 0.0f, 0.0f, "t01", "endHour")
, mRealMinutesPerGameDay(this, 20.0f, 0.0f, 0.0f, "p00", "daySpeed")
, mMorningStart(this, 7.0f, 0.0f, 0.0f, "p01", "mornStart")
, mMorningMid(this, 8.0f, 0.0f, 0.0f, "s01", "mornMid")
, mMorningEnd(this, 9.0f, 0.0f, 0.0f, "p02", "mornEnd")
, mEveningStart(this, 17.5f, 0.0f, 0.0f, "p03", "nightStart")
, mEveningMid(this, 18.5f, 0.0f, 0.0f, "s03", "nightMid")
, mEveningEnd(this, 19.5f, 0.0f, 0.0f, "p04", "nightEnd")
, mNightWarning(this, 16.0f, 0.0f, 0.0f, "p05", "nightWarning")
, mNightCountdown(this, 18.5f, 0.0f, 0.0f, "p06", "nightTimer")
, mTekiAbility(this, 1, 0, 0, "x99", "tekiAbility")
, mGameTitle(this, String("blah", 0), String("", 0), String("", 0), "x98", "gameTitle")
{
}
Parm<f32> mStartHour;
Parm<f32> mEndHour;
Parm<f32> mRealMinutesPerGameDay;
Parm<f32> mMorningStart;
Parm<f32> mMorningMid;
Parm<f32> mMorningEnd;
Parm<f32> mEveningStart;
Parm<f32> mEveningMid;
Parm<f32> mEveningEnd;
Parm<f32> mNightWarning;
Parm<f32> mNightCountdown;
Parm<int> mTekiAbility;
Parm<String> mGameTitle;
};
virtual void read(RandomAccessStream&);
virtual void update();
void drawLoadLogo(Graphics& gfx, bool force60FPSSpin, Texture* logoTex, f32 alphaFactor);
void menuToggleTimers(Menu& menu);
void menuTogglePrint(Menu& menu);
void menuToggleDInfo(Menu& menu);
void menuToggleDExtra(Menu& menu);
void menuToggleBlur(Menu& menu);
void menuToggleInfo(Menu& menu);
void menuToggleColls(Menu& menu);
void menuChangeFilter(Menu& menu);
void menuIncreaseFilter(Menu& menu);
void menuDecreaseFilter(Menu& menu);
Texture* setLoadBanner( char* texPath);
void hardReset(BaseApp* baseApp);
void softReset();
Shape* loadShape( char* modelPath, bool checkCache);
void addGenNode( char* name, CoreNode* node);
void addOptionsMenu(Menu* parent);
void addFilterMenu(Menu* parent);
Parms* mParameters;
MemoryCard mMemoryCard;
GamePrefs mGamePrefs;
u32 mSaveGameCrc;
PlayState mPlayState;
int mCurrentStageID;
int mPendingStageUnlockID;
u32 _1D4;
u32 mDemoFlags;
MoviePlayer* mMoviePlayer;
s16 mShipTextPartID;
s16 mShipTextType;
s16 mIsDayEndActive;
s16 mIsDayEndTriggered;
GameInterface* mGameInterface;
int mCurrGameSectionID;
int mNextGameSectionID;
s32 mNextOnePlayerSectionID;
u8 _1F8[0x4];
int mNextOnePlayerSectionOnDayEnd;
u32 _200;
Section* mGameSection;
LangMode mLangModes[LANG_CAPACITY];
int mLanguageIndex;
u32 mNextIntroMovieID;
u32 mCurrIntroMovieID;
BOOL mIsChallengeMode;
u32 _2B8;
u32 mGenFlowUpdateTickCount;
f32 mLoadTimeSeconds;
f32 mCurrLoadTextAlpha;
vf32 mTargetLoadTextAlpha;
f32 mLoadTextDisplayTimer;
int mAppTickCounter;
BOOL mIsNintendoLoadLogo;
WorldClock mWorldClock;
f32 mTimeMultiplier;
AnimFrameCacher* mFrameCacher;
GameGenFlow* mFlowManager;
Texture* mLevelBannerTex;
f32 mLevelBannerFadeValue;
Texture* mLastLoadedBannerTex;
GameLoadIdler mGameLoadIdler;
u8 _330[0x4];
BOOL mIsPauseAllowed;
BOOL mIsUIOverlayActive;
BOOL mPauseAll;
BOOL mIsTutorialTextActive;
u8 _344[0x4];
u32 _348;
u32 _34C;
int mFilterType;
u8 mVFilters[FILTER_COUNT][8];
};
extern GameFlow gameflow;
struct GameGenFlow : public Node {
GameGenFlow(char* name)
: Node(name)
{
_24 = 332;
_20 = 32;
_28 = 1;
_2C = 0;
}
virtual void update()
{
gameflow.mGenFlowUpdateTickCount++;
gameflow.mWorldClock.mRealSecsPerGameDay = 60.0f * (gameflow.mTimeMultiplier * gameflow.mParameters->mRealMinutesPerGameDay());
gameflow.mWorldClock.mRealSecsPerGameHour = gameflow.mWorldClock.mRealSecsPerGameDay / gameflow.mWorldClock.mHoursInDay;
Node::update();
}
int _20;
int _24;
int _28;
u32 _2C;
};
void preloadLanguage();
CardUtilThread CardThread;
CardUtilControl CardControl;
void CardUtilLockDirectory()
{
OSLockMutex(&CardControl.mDirMutex);
}
void CardUtilUnlockDirectory()
{
OSUnlockMutex(&CardControl.mDirMutex);
}
s32* CardUtilByteNotUsed()
{
return &CardControl.mByteNotUsed;
}
s32* CardUtilFilesNotUsed()
{
return &CardControl.mFilesNotUsed;
}
u32* CardUtilSectorSize()
{
return &CardControl.mSectorSize;
}
