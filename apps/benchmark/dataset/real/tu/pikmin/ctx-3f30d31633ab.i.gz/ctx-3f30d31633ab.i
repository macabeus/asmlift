
typedef unsigned int uint;
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef long double f128;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef volatile f128 vf128;
typedef int BOOL;
inline void padStack(void)
{
int pad = 0;
}
enum StageID {
STAGE_Practice = 0,
STAGE_Forest = 1,
STAGE_Cave = 2,
STAGE_Yakushima = 3,
STAGE_Last = 4,
STAGE_COUNT,
STAGE_START = STAGE_Practice,
STAGE_TESTMAP = STAGE_COUNT,
STAGE_COUNT_INCLUDING_TESTMAPS,
};
enum ChalStageID {
CHALSTAGE_Practice = STAGE_Practice,
CHALSTAGE_Forest = STAGE_Forest,
CHALSTAGE_Cave = STAGE_Cave,
CHALSTAGE_Yakushima = STAGE_Yakushima,
CHALSTAGE_Last = STAGE_Last,
CHALSTAGE_COUNT,
CHALSTAGE_START = CHALSTAGE_Practice,
CHALSTAGE_NOT = CHALSTAGE_COUNT + 2,
};
enum PikiColor {
Blue = 0,
Red = 1,
Yellow = 2,
PikiColorCount,
PikiMinColor = Blue,
PikiMaxColor = Yellow,
PIKI_Kinoko = 3,
};
enum PikiHappa {
Leaf = 0,
Bud = 1,
Flower = 2,
PikiHappaCount,
PikiMinHappa = Leaf,
PikiMaxHappa = Flower,
};
class AgeServer;
class ANode {
public:
virtual int getAgeNodeType() { return 0; }
};
class RandomAccessStream;
class CoreNode : public ANode {
public:
CoreNode( char* name = "CoreNode") { initCore(name); }
virtual void read(RandomAccessStream& stream) { }
void initCore( char* name)
{
mParent = mNext = mChild = 0 ;
setName(name);
}
CoreNode* Child() { return mChild; }
CoreNode* Next() { return mNext; }
CoreNode* Parent() { return mParent; }
void Child(CoreNode* child) { mChild = child; }
void Next(CoreNode* next) { mNext = next; }
char* Name() { return mName; }
int getChildCount();
void add(class CoreNode* child);
void del();
void setName( char* name) { mName = name; }
void load( char* dirPath, char* fileName, u32);
void genRead(AgeServer&) { }
void genWrite(AgeServer&) { }
char* mName;
CoreNode* mParent;
CoreNode* mNext;
CoreNode* mChild;
};
extern "C"{
typedef struct Vec {
f32 x;
f32 y;
f32 z;
} Vec;
typedef struct SVec {
s16 x;
s16 y;
s16 z;
} SVec;
void C_VECAdd(const Vec* a, const Vec* b, Vec* ab);
void PSVECAdd(const Vec* a, const Vec* b, Vec* ab);
void C_VECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void PSVECSubtract(const Vec* a, const Vec* b, Vec* a_b);
void C_VECScale(const Vec* src, Vec* dst, f32 scale);
void PSVECScale(const Vec* src, Vec* dst, f32 scale);
void C_VECNormalize(const Vec* src, Vec* unit);
void PSVECNormalize(const Vec* src, Vec* unit);
f32 C_VECSquareMag(const Vec* v);
f32 PSVECSquareMag(const Vec* v);
f32 VECMag (const Vec* v);
f32 PSVECMag(const Vec* v);
f32 C_VECDotProduct(const Vec* a, const Vec* b);
f32 PSVECDotProduct(const Vec* a, const Vec* b);
void C_VECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void PSVECCrossProduct(const Vec* a, const Vec* b, Vec* axb);
void VECHalfAngle (const Vec* a, const Vec* b, Vec* half);
void VECReflect (const Vec* src, const Vec* normal, Vec* dst);
f32 C_VECSquareDistance(const Vec* a, const Vec* b);
f32 PSVECSquareDistance(const Vec* a, const Vec* b);
f32 VECDistanc (const Vec* a, const Vec* b);
f32 PSVECDistance(const Vec* a, const Vec* b);
}
extern "C"{
typedef f32 Mtx[3][4];
typedef f32 Mtx23[2][3];
typedef f32 Mtx33[3][3];
typedef f32 Mtx44[4][4];
typedef f32 (*MtxPtr)[4];
typedef f32 (*Mtx23Ptr)[2];
typedef f32 (*Mtx33Ptr)[3];
typedef f32 (*Mtx44Ptr)[4];
typedef f32 PSQuaternion[4];
typedef struct Quaternion {
f32 x, y, z, w;
} Quaternion;
void C_MTXIdentity(Mtx m);
void PSMTXIdentity(Mtx m);
void C_MTXCopy(const Mtx src, Mtx dst);
void PSMTXCopy(const Mtx src, Mtx dst);
void C_MTXConcat(const Mtx a, const Mtx b, Mtx dst);
void PSMTXConcat(const Mtx a, const Mtx b, Mtx dst);
void C_MTXTranspose(const Mtx src, Mtx xPose);
void PSMTXTranspose(const Mtx src, Mtx xPose);
u32 C_MTXInverse(const Mtx src, Mtx inv);
u32 PSMTXInverse(const Mtx src, Mtx inv);
u32 C_MTXInvXpose(const Mtx src, Mtx inv);
u32 PSMTXInvXpose(const Mtx src, Mtx inv);
void MTXRotRad (Mtx m, char axis, f32 rad);
void PSMTXRotRad(Mtx m, char axis, f32 rad);
void MTXRotTrig (Mtx m, char axis, f32 sinA, f32 cosA);
void PSMTXRotTrig(Mtx m, char axis, f32 sinA, f32 cosA);
void MTXRotAxisRad (Mtx m, const Vec* axis, f32 rad);
void PSMTXRotAxisRad(Mtx m, const Vec* axis, f32 rad);
void MTXTrans (Mtx m, f32 xT, f32 yT, f32 zT);
void PSMTXTrans(Mtx m, f32 xT, f32 yT, f32 zT);
void MTXTransApply (const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void PSMTXTransApply(const Mtx src, Mtx dst, f32 xT, f32 yT, f32 zT);
void MTXScale (Mtx m, f32 xS, f32 yS, f32 zS);
void PSMTXScale(Mtx m, f32 xS, f32 yS, f32 zS);
void MTXScaleApply (const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void PSMTXScaleApply(const Mtx src, Mtx dst, f32 xS, f32 yS, f32 zS);
void MTXQuat (Mtx m, const Quaternion* quat);
void PSMTXQuat(Mtx m, const Quaternion* quat);
void MTXReflect (Mtx m, const Vec* p, const Vec* n);
void PSMTXReflect(Mtx m, const Vec* p, const Vec* n);
void MTXLookAt (Mtx m, const Vec* camPos, const Vec* camUp, const Vec* target);
void MTXLightFrustum (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightPerspective (Mtx m, f32 fovY, f32 aspect, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXLightOrtho (Mtx m, f32 t, f32 b, f32 l, f32 r, f32 scaleS, f32 scaleT, f32 transS, f32 transT);
void MTXFrustum (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void MTXPerspective (Mtx44 m, f32 fovY, f32 aspect, f32 n, f32 f);
void MTXOrtho (Mtx44 m, f32 t, f32 b, f32 l, f32 r, f32 n, f32 f);
void C_MTX44Identity(Mtx44 m);
void PSMTX44Identity(Mtx44 m);
void C_MTX44Copy(const Mtx44 src, Mtx44 dst);
void PSMTX44Copy(const Mtx44 src, Mtx44 dst);
void C_MTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void PSMTX44Concat(const Mtx44 a, const Mtx44 b, Mtx44 ab);
void C_MTX44Transpose(const Mtx44 src, Mtx44 xPose);
void PSMTX44Transpose(const Mtx44 src, Mtx44 xPose);
u32 C_MTX44Inverse(const Mtx44 src, Mtx44 inv);
void C_MTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void PSMTX44Trans(Mtx44 m, f32 xT, f32 yT, f32 zT);
void C_MTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void PSMTX44TransApply(const Mtx44 src, Mtx44 dst, f32 xT, f32 yT, f32 zT);
void C_MTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void PSMTX44Scale(Mtx44 m, f32 xS, f32 yS, f32 zS);
void C_MTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void PSMTX44ScaleApply(const Mtx44 src, Mtx44 dst, f32 xS, f32 yS, f32 zS);
void C_MTX44RotRad(Mtx44 m, char axis, f32 rad);
void PSMTX44RotRad(Mtx44 m, char axis, f32 rad);
void C_MTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void PSMTX44RotTrig(Mtx44 m, char axis, f32 sinA, f32 cosA);
void C_MTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
void PSMTX44RotAxisRad(Mtx44 m, const Vec* axis, f32 rad);
static inline void MTXSetPosition(Mtx mtx, const Vec* pos)
{
mtx[0][3] = pos->x;
mtx[1][3] = pos->y;
mtx[2][3] = pos->z;
}
}
extern "C"{
typedef unsigned long size_t;
}
extern "C"{
__declspec(section ".init") void* memcpy(void*, const void*, size_t);
__declspec(section ".init") void __fill_mem(void*, int, size_t);
__declspec(section ".init") void* memset(void*, int, size_t);
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, u8 type);
}
extern "C"{
int memcmp(const void*, const void*, size_t);
void* memchr(u8*, int, size_t);
void* memmove(void*, const void*, size_t);
void* memcpy(void* dest, const void* src, size_t n);
void* memset(void* dest, int val, size_t count);
}
extern "C"{
int stricmp(const char*, const char*);
}
extern "C"{
char* strcpy(char* dst, const char* src);
char* strncpy(char* dst, const char* src, size_t n);
char* strcat(char* dst, const char* src);
char* strncat(char* dst, const char* src, size_t n);
int strcmp(const char* lhs, const char* rhs);
int strncmp(const char* lhs, const char* rhs, size_t n);
char* strchr(const char* str, int ch);
char* strstr(const char* str, const char* substr);
char* strrchr(const char* str, int chr);
size_t strlen(const char* str);
}
class String;
class Stream {
public:
Stream() { }
char* mPath;
virtual int readInt();
virtual u8 readByte();
virtual short readShort();
virtual f32 readFloat();
virtual void readString(char*, int);
virtual void readString(String&);
virtual char* readString();
virtual void writeInt(int);
virtual void writeByte(u8);
virtual void writeShort(short);
virtual void writeFloat(f32);
virtual void writeString( char*);
virtual void writeString( String&);
virtual void read(void*, int);
virtual void write( void*, int);
virtual int getPending();
virtual int getAvailable();
virtual void close();
virtual bool getClosing() { return false; }
virtual void flush() { }
void print( char*, ...);
void vPrintf( char*, va_list);
};
class RandomAccessStream : public Stream {
public:
virtual int getPosition() { return 0; }
virtual int getPending() { return getLength() - getPosition(); }
virtual void setPosition(int) { }
virtual int getLength() { return getAvailable(); }
void skipPadding(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
readByte();
}
}
void padFile(u32 paddingAmount)
{
int position = getPosition();
int count = ((((position) + ((paddingAmount) - 1))) & ~((paddingAmount) - 1)) - position;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
void padFileTo(u32 paddingAmount, u32 offset)
{
int position = getPosition();
int count = paddingAmount - position - offset;
for (int i = 0; i < count; i++) {
writeByte(0);
}
}
inline BOOL checkInput()
{
if (readByte() == 0) {
return false;
}
return true;
}
void writeTo(int, void*, int);
void readFrom(int, void*, int);
void writeIntTo(int, int);
int readIntFrom(int);
};
class AlignedStream : public RandomAccessStream {
public:
virtual void read(void*, int);
virtual void write( void*, int);
virtual void alignedWrite( void*, int) = 0;
virtual void alignedRead(void*, int) = 0;
int mAlignment;
};
class BufferedInputStream : public RandomAccessStream {
public:
BufferedInputStream()
{
mBuffer = 0 ;
mStream = 0 ;
}
BufferedInputStream(Stream*, u8*, int);
virtual void read(void*, int);
virtual int getPending() { return mStream->getPending() - mPosition; }
virtual void close() { mStream->close(); }
virtual int getPosition() { return mPosition; }
void init(Stream*, u8*, int);
void fillBuffer();
u8* mBuffer;
int mBufferSize;
int mRemainingBytes;
int mCurrentBufferPos;
int mPosition;
Stream* mStream;
};
class RamStream : public RandomAccessStream {
public:
inline RamStream(void* buffer, int size)
{
mBufferAddr = buffer;
mPosition = 0;
mLength = size;
}
virtual int getPending() { return mLength - mPosition; }
virtual void setPosition(int pos) { mPosition = pos; }
virtual int getPosition() { return mPosition; }
virtual int getLength() { return mLength; }
virtual void setLength(int len) { mLength = len; }
virtual void read(void* dest, int size)
{
memcpy(dest, (char*)mBufferAddr + mPosition, size);
mPosition += size;
}
virtual void write( void* src, int size)
{
memcpy((char*)mBufferAddr + mPosition, src, size);
mPosition += size;
}
void* mBufferAddr;
int mPosition;
int mLength;
};
extern Stream* sysCon;
extern Stream* errCon;
extern "C"{
extern const f32 __float_huge[];
extern const f32 __float_nan[];
extern const f64 __double_huge[];
extern const f64 __double_nan[];
f64 cos(f64);
f32 cosf(f32);
f64 sin(f64);
f32 sinf(f32);
f64 tan(f64);
f32 tanf(f32);
f64 acos(f64);
f32 acosf(f32);
f64 asin(f64);
f64 atan(f64);
f32 atanf(f32);
f64 atan2(f64, f64);
f32 atan2f(f32, f32);
f64 ceil(f64);
f64 floor(f64);
f64 frexp(f64, int*);
f64 ldexp(f64, int);
f64 sqrt(f64);
f64 pow(f64, f64);
f64 log(f64);
f64 log10(f64);
f64 fmod(f64, f64);
f64 scalbn(f64, int);
inline f128 fabsl(f128 x)
{
return __fabs((f64)x);
}
inline f32 sqrtf(f32 x)
{
static const f64 _half = .5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
}
namespace std {
inline f32 sqrtf(f32 x)
{
static const f64 _half = 0.5;
static const f64 _three = 3.0;
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte((f64)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (f32)(x * guess);
return y;
}
return x;
}
inline f32 fmodf(f32 x, f32 m)
{
f32 b, a;
a = __fabsf(m) ;
b = __fabsf(x) ;
if (a > b) {
return x;
}
long long c = (long long)(x / m);
return x - m * c;
}
}
inline f32 fmod(f32 x, f32 m)
{
return std::fmodf(x, m);
}
class Vector3f;
class BoundBox;
class KTri;
class KRect;
class KSegment;
static inline f32 quickABS(f32 x)
{
*reinterpret_cast<u32*>(&x) &= ~0x80000000;
return x;
}
static inline f32 u32ToFloat(u32 a)
{
union {
u32 w;
f32 f;
} tmp;
tmp.w = a;
return tmp.f;
}
inline f32 absF(f32 val)
{
return (f32)__fabsf(val) ;
}
inline f32 absVal(f32 val)
{
if (val > 0.0f) {
return val;
}
return -val;
}
f32 roundAng(f32 angle);
f32 angDist(f32 x, f32 z);
f32 qdist2(f32 x0, f32 z0, f32 x1, f32 z1);
f32 triRectDistance( Vector3f*, Vector3f*, Vector3f*, BoundBox&, bool);
f32 distanceTriRect(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KTri&, f32*, f32*, f32*);
f32 sqrDistance(KSegment&, KSegment&, f32*, f32*);
f32 sqrDistance(KSegment&, KRect&, f32*, f32*, f32*);
f32 sqrDistance(KTri&, KRect&, f32*, f32*, f32*, f32*);
f32 sqrDistance( Vector3f&, KTri&, f32*, f32*);
f32 qdist3(f32 x0, f32 y0, f32 z0, f32 x1, f32 y1, f32 z1);
inline f32 speedy_sqrtf(f32 x)
{
vf32 y;
if (x > 0.0f) {
f64 guess = __frsqrte(x) ;
y = (f32)(x * guess);
return y;
}
return x;
}
class AgeServer;
class Matrix3f;
class Matrix4f;
class Quat;
class Vector3f {
public:
Vector3f() { x = y = z = 0.0f; }
Vector3f(const f32& _x, const f32& _y, const f32& _z)
: x(_x)
, y(_y)
, z(_z)
{
}
Vector3f(const Vector3f& other)
{
x = other.x;
y = other.y;
z = other.z;
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
z = stream.readFloat();
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
stream.writeFloat(z);
}
void set(const f32& pX, const f32& pY, const f32& pZ)
{
x = pX;
y = pY;
z = pZ;
}
void set(const Vector3f& other) { set(other.x, other.y, other.z); }
void input( Vector3f& other) { set(other.x, other.y, other.z); }
void output(Vector3f& outVec) { outVec.set(x, y, z); }
f32 length() { return std::sqrtf((x * x) + (y * y) + (z * z) ); }
f32 squaredLength() { return (x * x) + (y * y) + (z * z) ; }
f32 DP( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 dot( Vector3f& other) { return x * other.x + y * other.y + z * other.z; }
f32 distance( Vector3f& to)
{
Vector3f result;
result.sub2(to, *this);
return result.length();
}
f32 normalise()
{
f32 norm = length();
if (norm != 0.0f) {
div(norm);
}
return norm;
}
void CP( Vector3f& other)
{
Vector3f tmp;
tmp.x = y * other.z - z * other.y;
tmp.y = z * other.x - x * other.z;
tmp.z = x * other.y - y * other.x;
x = tmp.x;
y = tmp.y;
z = tmp.z;
}
void cross( Vector3f& vec1, Vector3f& vec2)
{
set(vec1.y * vec2.z - vec1.z * vec2.y, vec1.z * vec2.x - vec1.x * vec2.z, vec1.x * vec2.y - vec1.y * vec2.x);
}
void add( Vector3f& other)
{
x += other.x;
y += other.y;
z += other.z;
}
void add2( Vector3f& a, Vector3f& b) { set(a.x + b.x, a.y + b.y, a.z + b.z); }
void sub( Vector3f& other)
{
x -= other.x;
y -= other.y;
z -= other.z;
}
void sub( Vector3f& a, Vector3f& b)
{
x = a.x - b.x;
y = a.y - b.y;
z = a.z - b.z;
}
void sub2( Vector3f& a, Vector3f& b) { set(a.x - b.x, a.y - b.y, a.z - b.z); }
void div(f32 divisor)
{
x /= divisor;
y /= divisor;
z /= divisor;
}
void multiply(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale(f32 scale)
{
x *= scale;
y *= scale;
z *= scale;
}
void scale2(f32 scale, Vector3f& vec)
{
x = scale * vec.x;
y = scale * vec.y;
z = scale * vec.z;
}
void negate()
{
x = -x;
y = -y;
z = -z;
}
void bounce( Vector3f& surface, f32 elasticity)
{
f32 dp = -DP(surface) * elasticity;
if (dp > 0.0f) {
x = surface.x * dp + x;
y = surface.y * dp + y;
z = surface.z * dp + z;
}
}
void lerpTo( Vector3f& other, f32 t, Vector3f& outVec)
{
outVec.x = (other.x - x) * t + x;
outVec.y = (other.y - y) * t + y;
outVec.z = (other.z - z) * t + z;
}
void rotate( Matrix4f&);
void rotateTo( Matrix4f&, Vector3f&);
void multMatrix( Matrix4f&);
void multMatrixTo( Matrix4f&, Vector3f&);
void rotateTranspose( Matrix4f&);
void rotate( Quat&);
void rotateInverse( Quat&);
void normalize() { normalise(); }
void project( Vector3f& dirToRemove)
{
f32 projAmt = DP(dirToRemove);
x = -(projAmt * dirToRemove.x - x);
y = -(projAmt * dirToRemove.y - y);
z = -(projAmt * dirToRemove.z - z);
}
void middle( Vector3f& a, Vector3f& b)
{
add2(a, b);
scale(0.5f);
}
bool isSame( Vector3f& other)
{
return __fabsf(x - other.x) < 0.0001f && __fabsf(y - other.y) < 0.0001f && __fabsf(z - other.z) < 0.0001f;
}
void add( Vector3f& a, Vector3f& b)
{
x = a.x + b.x;
y = a.y + b.y;
z = a.z + b.z;
}
void add(f32 _x, f32 _y, f32 _z)
{
x += _x;
y += _y;
z += _z;
}
f32 x;
f32 y;
f32 z;
};
class Vector2f {
public:
Vector2f() { }
Vector2f(const f32& _x, const f32& _y)
{
x = _x;
y = _y;
}
void write(Stream& stream)
{
stream.writeFloat(x);
stream.writeFloat(y);
}
void read(Stream& stream)
{
x = stream.readFloat();
y = stream.readFloat();
}
void set(f32 _x, f32 _y)
{
x = _x;
y = _y;
}
f32 x, y;
};
class Vector2i {
public:
void read(Stream& stream)
{
x = stream.readInt();
y = stream.readInt();
}
void write(Stream& stream)
{
stream.writeInt(x);
stream.writeInt(y);
}
void set(int _x, int _y)
{
x = _x;
y = _y;
}
int x, y;
};
class Quat {
public:
Quat() { }
Quat(f32 _x, f32 _y, f32 _z, f32 _s) { set(_x, _y, _z, _s); }
void fromMat3f( Matrix3f&);
void rotate( Vector3f&, f32);
void multiply( Quat&);
void normalise();
void genVectorX(Vector3f&) ;
void genVectorY(Vector3f&) ;
void genVectorZ(Vector3f&) ;
void slerp( Quat&, f32, int);
void fromEuler( Vector3f&);
void multiplyTo( Quat&, Quat&);
void set(f32 _x, f32 _y, f32 _z, f32 _s)
{
v.x = _x;
v.y = _y;
v.z = _z;
s = _s;
}
Vector3f v;
f32 s;
};
inline Vector3f operator*(const Vector3f& a, const f32& b)
{
return Vector3f(a.x * b, a.y * b, a.z * b);
}
inline Vector3f operator*(const f32& a, const Vector3f& b)
{
return b * a;
}
inline Vector3f operator+(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x + b.x, a.y + b.y, a.z + b.z);
}
inline Vector3f operator-(const Vector3f& a, const Vector3f& b)
{
return Vector3f(a.x - b.x, a.y - b.y, a.z - b.z);
}
inline Vector3f operator-(const Vector3f& a)
{
return Vector3f(-a.x, -a.y, -a.z);
}
inline Vector3f operator/(const Vector3f& a, const f32& b)
{
return a * (1.0f / b);
}
inline Vector3f CP(const Vector3f& a, const Vector3f& b)
{
f32 x = a.y * b.z - a.z * b.y;
f32 y = a.z * b.x - a.x * b.z;
f32 z = a.x * b.y - a.y * b.x;
return Vector3f(x, y, z);
}
class SRT {
public:
SRT() { }
SRT(const SRT& other)
: s(other.s)
, r(other.r)
, t(other.t)
{
}
Vector3f s;
Vector3f r;
Vector3f t;
};
class Plane;
class Matrix4f {
public:
Matrix4f() { }
Matrix4f( Mtx44);
void makeIdentity();
void makeRotate( Vector3f&, f32, f32);
void makeRotate( Vector3f&, f32);
void multiply( Matrix4f&);
void multiplyTo( Matrix4f&, Matrix4f&) ;
void makeSRT( Vector3f&, Vector3f&, Vector3f&);
void makeConcatSRT( Matrix4f*, Matrix4f&, SRT&);
void inverse(Matrix4f*);
void scale( Vector3f&);
void makeLookat( Vector3f& cameraPos, Vector3f& targetPos, Vector3f* optionalUp);
void makeLookat( Vector3f& cameraPos, Vector3f& rightDir, Vector3f& upDir, Vector3f& backDir);
void transposeTo(Matrix4f&);
void makeVQS( Vector3f&, Quat&, Vector3f&);
void blend( Matrix4f&, f32);
void makeOrtho(f32, f32, f32, f32, f32, f32, f32);
void makePerspective(f32 fovY, f32 aspectRatio, f32 nearZ, f32 farZ);
void makeBallRotate(Vector3f&);
void rotate(Vector3f&, f32);
void rotate(Vector3f&);
void rotate(f32, f32, f32);
void makeAligned(Vector3f&, f32);
void rotateX(f32);
void rotateY(f32);
void rotateZ(f32);
void translate(f32, f32, f32);
void makeLookfrom( Vector3f&, Vector3f&);
void makeProjection(Vector3f&, Plane&);
void makeReflection(Plane&);
void makeBillVector(Vector3f&, Matrix4f&, Vector3f&);
void makeSRT(SRT srt) { makeSRT(srt.s, srt.r, srt.t); }
inline void set( Matrix4f& other)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = other.mMtx[i][j];
}
}
}
inline void set(f32 value)
{
for (int i = 0; i < 4; i++) {
for (int j = 0; j < 4; j++) {
mMtx[i][j] = value;
}
}
}
void getRow(int rowNum, Vector3f& row) { row.set(mMtx[rowNum][0], mMtx[rowNum][1], mMtx[rowNum][2]); }
void getColumn(int colNum, Vector3f& col) { col.set(mMtx[0][colNum], mMtx[1][colNum], mMtx[2][colNum]); }
void setRow(int rowNum, const Vector3f& row)
{
mMtx[rowNum][0] = row.x;
mMtx[rowNum][1] = row.y;
mMtx[rowNum][2] = row.z;
}
void setColumn(int colNum, const Vector3f& col)
{
mMtx[0][colNum] = col.x;
mMtx[1][colNum] = col.y;
mMtx[2][colNum] = col.z;
}
void setTranslation( Vector3f& trans)
{
mMtx[0][3] = trans.x;
mMtx[1][3] = trans.y;
mMtx[2][3] = trans.z;
}
void setTranslation(f32 x, f32 y, f32 z)
{
mMtx[0][3] = x;
mMtx[1][3] = y;
mMtx[2][3] = z;
}
static Matrix4f ident;
Mtx44 mMtx;
};
extern f32 sintable[0x1000];
extern f32 costable[0x1000];
static inline f32 sinShort(u16 x)
{
return sintable[(x >> 4) & 0xFFF];
}
static inline f32 cosShort(u16 x)
{
return costable[(x >> 4) & 0xFFF];
}
class Graphics;
class Vector3f;
class VQS;
class Node : public CoreNode {
public:
Node( char* name = "<Node>")
: CoreNode(name)
{
init(name);
}
virtual void update();
virtual void draw(Graphics&);
virtual void render(Graphics&);
virtual void concat() { }
virtual void concat(VQS&) { concat(); }
virtual void concat(SRT&) { concat(); }
virtual void concat(Matrix4f&) { concat(); }
virtual Matrix4f* getModelMatrix() { return 0 ; }
void init( char*);
bool getFlag(int);
int getFlags();
int getType();
void clearFlag(int);
void setFlag(int);
void setFlag(int, bool);
void setFlags(int);
void setType(int);
void togFlag(int);
static int currID;
s32 mType;
s32 mFlags;
s32 _1C;
};
class FaceNode : public CoreNode {
public:
FaceNode()
: CoreNode("face")
{
}
FaceNode(int faceCount)
: CoreNode("face")
{
mFaceCount = faceCount;
mMtxIdx = 0 ;
mVtxIdx = 0 ;
mColIdx = 0 ;
mNrmIdx = 0 ;
mTexCoords[0] = 0 ;
}
int mFaceCount;
int* mMtxIdx;
int* mVtxIdx;
int* mColIdx;
int* mNrmIdx;
int* mTexCoords[8];
};
class SRTNode : public Node {
public:
SRTNode( char* name);
virtual void update();
virtual void concat(Matrix4f&) { }
virtual void concat() { }
virtual Matrix4f* getModelMatrix() { return &mWorldMtx; }
Vector3f& getPosition() { return mSRT.t; }
Vector3f& getRotation() { return mSRT.r; }
Vector3f& getScale() { return mSRT.s; }
Vector3f& getWorldPosition() { return reinterpret_cast<Vector3f&>(mWorldMtx.mMtx[3]); }
void setPosition( Vector3f& pos) { mSRT.t = pos; }
void setRotation( Vector3f& rot) { mSRT.r = rot; }
void setScale( Vector3f& scale) { mSRT.s = scale; }
Matrix4f mWorldMtx;
SRT mSRT;
};
class NodeMgr {
public:
NodeMgr();
~NodeMgr();
inline CoreNode* firstNode() { return &mRootNode; }
CoreNode* findNode( char*, CoreNode*);
void recFindNode(CoreNode*, char*);
void Del(Node*);
bool mDelHappened;
CoreNode mRootNode;
};
extern NodeMgr* nodeMgr;
class AgeServer;
class Parameters;
class RandomAccessStream;
class ayuID {
public:
ayuID() { mID = 0; }
ayuID( char* const id) { Set(id); }
void Set( char* id) { mID = *(s32*)id; }
long& Num() { return mID; };
long mID;
};
struct BaseParm {
BaseParm(Parameters*, ayuID);
ayuID mID;
BaseParm* mNext;
virtual int size() = 0;
virtual void write(RandomAccessStream& output) { }
virtual void read(RandomAccessStream& input) { }
};
class Parameters {
public:
Parameters( char* name)
{
mFirstParm = 0 ;
}
void write(RandomAccessStream&);
void read(RandomAccessStream&);
int sizeInFile();
BaseParm* mFirstParm;
};
template <typename T>
struct Parm : public BaseParm {
Parm(Parameters* owner, T value, T min, T max, ayuID id, char* name)
: BaseParm(owner, id)
{
mValue = value;
}
virtual int size() { return sizeof(T); }
virtual void write(RandomAccessStream&);
virtual void read(RandomAccessStream&);
T& operator()() { return mValue; }
void operator()(T val) { mValue = val; }
T mValue;
};
class Creature;
enum EDemoFlags {
DEMOFLAG_NULL = -1,
DEMOFLAG_DiscoverRedOnyon = 0,
DEMOFLAG_DiscoverYellowOnyon = 1,
DEMOFLAG_DiscoverBlueOnyon = 2,
DEMOFLAG_ApproachSeed = 3,
DEMOFLAG_PluckRedPikmin = 4,
DEMOFLAG_PluckYellowPikmin = 5,
DEMOFLAG_PluckBluePikmin = 6,
DEMOFLAG_NoPikminTimeout = 7,
DEMOFLAG_CameraInfo = 8,
DEMOFLAG_Unk9 = 9,
DEMOFLAG_CollectFirstPellet = 10,
DEMOFLAG_FirstSluiceDown = 11,
DEMOFLAG_ApproachEngine = 12,
DEMOFLAG_CollectEngine = 13,
DEMOFLAG_StartBoxPush = 14,
DEMOFLAG_FinishBoxPush = 15,
DEMOFLAG_OnyonMenuInfo = 16,
DEMOFLAG_PostExtinctionSeed = 17,
DEMOFLAG_GrabFirstBomb = 18,
DEMOFLAG_FirstHurryUp = 19,
DEMOFLAG_FirstBombExplode = 20,
DEMOFLAG_PikminLimitOffset = 21,
DEMOFLAG_PikminLimitTutorial = 21,
DEMOFLAG_PikminLimitForest = 22,
DEMOFLAG_PikminLimitCave = 23,
DEMOFLAG_PikminLimitYakushima = 24,
DEMOFLAG_PikminLimitLast = 25,
DEMOFLAG_FirstNectar = 26,
DEMOFLAG_FirstBombDeath = 27,
DEMOFLAG_CarryPathBlocked = 28,
DEMOFLAG_OlimarLowHealth = 29,
DEMOFLAG_Pluck15thPikmin = 30,
DEMOFLAG_FirstNoon = 31,
DEMOFLAG_UfoPartDiscoveryOffset = 32,
DEMOFLAG_COUNT = DEMOFLAG_UfoPartDiscoveryOffset + (30) + 1,
};
class DemoFlag {
public:
char* mName;
u16 mIndex;
s16 mMovieIndex;
u16 _08;
bool _0A;
};
class DemoParms : public Node {
public:
struct Parms : Parameters {
Parms();
Parm<f32> mOnionBootTriggerRadius;
Parm<f32> mSeedDemoTriggerRadius;
Parm<f32> mSeedDemoWaitTime;
Parm<f32> _30;
Parm<f32> mDemoTriggerRadius;
};
DemoParms();
virtual void read(RandomAccessStream& data) { mParms.read(data); }
Parms mParms;
};
struct DemoFlags {
DemoFlags();
void initGame();
void initCourse();
void update();
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
void registerDemoFlag(int, char*, u16, u16, bool);
bool isFlag(int);
void resetFlag(int);
void setFlag(int, Creature*);
void setFlagOnly(int);
void setTimer(f32, int, Creature*);
void resetTimer();
DemoFlag* getDemoFlag(int);
u16 mFlagCount;
u16 mCurrentDataIndex;
u16 mFlagDataNum;
u8* mStoredFlags;
DemoFlag** mFlagDataList;
Creature* mTargetCreature;
f32 mWaitTimer;
s16 mCurrentDemoIndex;
};
class DemoEventMgr {
public:
DemoEventMgr();
void act(int, int);
char* getEventName(int, int);
char* getSenderName(int);
int getEventMax() { return 6; }
int getSenderMax() { return 0x20; }
};
extern DemoEventMgr* demoEventMgr;
extern DemoParms* demoParms;
class CmdStream {
public:
CmdStream();
CmdStream(Stream* stream);
char* skipLine();
char* getToken(bool skipComments);
char nextChar();
void fillBuffer(bool force);
void copyToToken(int length);
bool whiteSpace(char toCheck);
bool endOfCmds();
bool isToken( char* str);
bool LineIsComment();
bool endOfSection();
inline void init(Stream* stream);
static char* statbuff;
Stream* mStream;
char* mBuffer;
char mCurrentToken[0x100];
int mTotalStreamSize;
int mBufferUsed;
int mBufferOffset;
int mCurrentPosition;
u8 _118[0x4];
};
extern "C"{
}
extern "C"{
typedef u32 __file_handle;
typedef u32 fpos_t;
typedef struct _IO_FILE _IO_FILE, *P_IO_FILE;
enum __file_kinds { __closed_file, __disk_file, __console_file, __unavailable_file };
enum __file_orientation { __unoriented, __char_oriented, __wide_oriented };
typedef struct __file_modes {
u32 open_mode : 2;
u32 io_mode : 3;
u32 buffer_mode : 2;
u32 file_kind : 3;
u32 binary_io : 1;
u32 unk12 : 1;
u32 unk13 : 1;
} file_modes;
enum __io_states { __neutral, __writing, __reading, __rereading };
typedef struct __file_states {
u32 io_state : 3;
u32 free_buffer : 1;
u8 eof;
u8 error;
} file_states;
typedef void* __ref_con;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc ref_con);
typedef int (*__io_proc)(__file_handle file, char* buff, size_t* count, __idle_proc ref_con);
typedef int (*__close_proc)(__file_handle file);
struct _IO_FILE {
__file_handle mHandle;
file_modes mMode;
file_states mState;
u8 mIsDynamicallyAllocated;
u8 mCharBuffer;
u8 mCharBufferOverflow;
u8 mUngetcBuffer[2 ];
u32 mPosition;
char* mBuffer;
u32 mBufferSize;
char* mBufferPtr;
u32 mBufferLength;
u32 mBufferAlignment;
u32 mBufferLength2;
u32 mBufferPosition;
__pos_proc positionFunc;
__io_proc readFunc;
__io_proc writeFunc;
__close_proc closeFunc;
__ref_con ref_con;
};
typedef struct _IO_FILE FILE;
typedef struct {
char* CharStr;
size_t MaxCharCount;
size_t CharsWritten;
} __OutStrCtrl;
typedef struct {
const char* NextChar;
int NullCharDetected;
} __InStrCtrl;
typedef struct {
wchar_t* wCharStr;
size_t MaxCharCount;
size_t CharsWritten;
} __wOutStrCtrl;
typedef struct {
const wchar_t* wNextChar;
int wNullCharDetected;
} __wInStrCtrl;
int puts(const char* s);
int printf(const char*, ...);
int vprintf(const char* format, va_list arg);
int vsnprintf(char* s, size_t n, const char* format, va_list arg);
int vsprintf(char* s, const char* format, va_list arg);
int snprintf(char* s, size_t n, const char* format, ...);
int sprintf(char* s, const char* format, ...);
int sscanf(const char* s, const char* format, ...);
extern FILE __files[3];
}
class Stream;
class String {
public:
String() { init(64); }
String(int length) { init(length); }
String(char* str, int length) { init(str, length); }
void init(char* str)
{
mString = str;
}
void init(int length)
{
mString = length ? new char[length + 1] : 0 ;
mLength = length;
}
void init(char* str, int length)
{
mString = str;
mLength = length;
}
static bool equals( char* lhs, char* rhs) { return isSame(lhs, rhs); }
static bool isSame( char*, char*);
bool isSame( char*) ;
bool isSame( String* other) { return isSame(other->mString); }
static bool contains( char*, char*);
static bool contains( char* str, char c)
{
char substr[] = { c, '\0' };
return contains(str, substr);
}
bool contains( char* substr) { return contains(mString, substr); }
static char* dup( char*);
char* dup() { return dup(mString); }
static bool isWhiteSpace(char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c < ' '; }
float toFloat() ;
static int toInt( char*);
int toInt() ;
static int getLength( char*);
int getLength() ;
static u32 calcHash( char*);
u32 calcHash() ;
static char* copy(char*, char*);
static bool copyUntil(char*, char*, char, char**);
static void concat(char*, char*);
int mLength;
char* mString;
};
struct StringArray {
void read(Stream&);
void write(Stream&);
int mSize;
String* mElems;
};
class AgeServer;
class RandomAccessStream;
class ID32 {
public:
ID32();
ID32(u32 id);
void operator=(u32 id);
bool operator==(u32 id) ;
bool operator!=(u32 id) ;
bool match(u32 id, char wild = '*') ;
void print() ;
void read(RandomAccessStream& stream);
void setID(u32 id);
void sprint(char* str) ;
void updateID();
void updateString();
void write(RandomAccessStream& stream) ;
void genAge(AgeServer&, char*);
void ageChangeID() { updateID(); }
u32 mId;
char mStringID[5];
};
class AnimData;
class Shape;
class TexImg;
class Texture;
class GfxobjInfo {
public:
GfxobjInfo()
{
mPrev = mNext = 0 ;
mString = "";
mId.setID('none');
mAttached = 0;
}
void insertAfter(GfxobjInfo* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
GfxobjInfo* mPrev;
GfxobjInfo* mNext;
char* mString;
ID32 mId;
u32 mAttached;
virtual void attach() { }
virtual void detach() { }
};
class GfxObject {
public:
virtual void attach() { }
virtual void detach() { }
};
class ShpobjInfo : public GfxobjInfo {
public:
ShpobjInfo()
: mTarget(0 )
{
}
Shape* mTarget;
};
class MemHead {
public:
u32 mTagAndSize;
MemHead* mNext;
MemHead* mPrev;
u32 mGuardValue;
};
class AyuCache {
public:
AyuCache(u32);
void init(u32 bufferStart, u32 bufferEnd);
void* mallocL(u32 sizeBytes);
void cacheFree(void* ptr);
bool isEmpty();
u32 largestBlockFree();
int getIndex();
void releaseIndex(int);
void deleteIdAll(u32);
u32 amountFree();
MemHead mFreeBlockHead;
MemHead mAllocatedBlockHead;
u32 mCurrentAllocationTag;
u32 mTotalAllocatedUnits;
u32 mTotalCacheSizeBytes;
u8 mPageIndexPool[256];
u32 mNextPageSlot;
};
class AyuStack {
public:
AyuStack() { mIsActive = false; }
void reset(int resetFlags);
void* push(int requestedSizeBytes);
void pop();
void create( char* name, int allocFlags, void* stackBase, int stackSizeBytes, bool enableOverflowGuard);
void reset();
void checkStack();
int setAllocType(int type)
{
int old = mAllocType;
mAllocType = type;
return old;
}
int getFree() { return mSize - mTotalSize; }
int getTopUsed() { return mInitialStackLimit - mStackLimit; }
int getMaxFree() { return (mSize - mTotalSize - 8 > 0) ? mSize - mTotalSize - 8 : 0; }
void inactivate() { mIsActive = false; }
s32 mAllocType;
int mSize;
int mTotalSize;
u32 mInitialStackTop;
u32 mInitialStackLimit;
u32 mStackTop;
u32 mStackLimit;
bool mProtectOverflow;
bool mIsActive;
char* mName;
};
class AyuHeap : public AyuStack {
public:
AyuHeap() { }
void init( char* name, int allocFlags, void* stackBase, int stackSizeBytes);
u8 _24;
};
extern "C"{
typedef u8 GXBool;
typedef enum _GXCompare {
GX_NEVER = 0,
GX_LESS = 1,
GX_EQUAL = 2,
GX_LEQUAL = 3,
GX_GREATER = 4,
GX_NEQUAL = 5,
GX_GEQUAL = 6,
GX_ALWAYS = 7,
} GXCompare;
typedef GXCompare _SDK_GXCompare;
typedef enum _GXLogicOp {
GX_LO_CLEAR = 0,
GX_LO_AND = 1,
GX_LO_REVAND = 2,
GX_LO_COPY = 3,
GX_LO_INVAND = 4,
GX_LO_NOOP = 5,
GX_LO_XOR = 6,
GX_LO_OR = 7,
GX_LO_NOR = 8,
GX_LO_EQUIV = 9,
GX_LO_INV = 10,
GX_LO_REVOR = 11,
GX_LO_INVCOPY = 12,
GX_LO_INVOR = 13,
GX_LO_NAND = 14,
GX_LO_SET = 15,
} GXLogicOp;
typedef GXLogicOp _SDK_GXLogicOp;
typedef enum _GXPrimitive {
GX_POINTS = 0xB8,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xa0,
GX_QUADS = 0x80,
} GXPrimitive;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 3 * 0,
GX_PNMTX1 = 3 * 1,
GX_PNMTX2 = 3 * 2,
GX_PNMTX3 = 3 * 3,
GX_PNMTX4 = 3 * 4,
GX_PNMTX5 = 3 * 5,
GX_PNMTX6 = 3 * 6,
GX_PNMTX7 = 3 * 7,
GX_PNMTX8 = 3 * 8,
GX_PNMTX9 = 3 * 9,
} GXPosNrmMtx;
typedef enum _GXCommand {
GX_CMD_LOAD_INDX_A = 0x20,
GX_CMD_LOAD_INDX_B = 0x28,
GX_CMD_LOAD_INDX_C = 0x30,
GX_CMD_LOAD_INDX_D = 0x38,
GX_CMD_LOAD_BP_REG = 0x61,
GX_CMD_LOAD_CP_REG = 0x08,
GX_CMD_LOAD_XF_REG = 0x10,
GX_CMD_CALL_DL = 0x40,
GX_CMD_INVL_VC = 0x48,
GX_CMD_NOP = 0x00,
GX_CMD_DRAW_QUADS = 0x80,
GX_CMD_DRAW_TRIANGLES = 0x90,
GX_CMD_DRAW_TRIANGLE_STRIP = 0x98,
GX_CMD_DRAW_TRIANGLE_FAN = 0xA0,
GX_CMD_DRAW_LINES = 0xA8,
GX_CMD_DRAW_LINE_STRIP = 0xB0,
GX_CMD_DRAW_POINTS = 0xB8,
} GXCommand;
typedef enum _GXAttr {
GX_VA_PNMTXIDX = 0,
GX_VA_TEX0MTXIDX = 1,
GX_VA_TEX1MTXIDX = 2,
GX_VA_TEX2MTXIDX = 3,
GX_VA_TEX3MTXIDX = 4,
GX_VA_TEX4MTXIDX = 5,
GX_VA_TEX5MTXIDX = 6,
GX_VA_TEX6MTXIDX = 7,
GX_VA_TEX7MTXIDX = 8,
GX_VA_POS = 9,
GX_VA_NRM = 10,
GX_VA_CLR0 = 11,
GX_VA_CLR1 = 12,
GX_VA_TEX0 = 13,
GX_VA_TEX1 = 14,
GX_VA_TEX2 = 15,
GX_VA_TEX3 = 16,
GX_VA_TEX4 = 17,
GX_VA_TEX5 = 18,
GX_VA_TEX6 = 19,
GX_VA_TEX7 = 20,
GX_POS_MTX_ARRAY = 21,
GX_NRM_MTX_ARRAY = 22,
GX_TEX_MTX_ARRAY = 23,
GX_LIGHT_ARRAY = 24,
GX_VA_NBT = 25,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF,
} GXAttr;
typedef enum _GXAttrType {
GX_NONE = 0,
GX_DIRECT = 1,
GX_INDEX8 = 2,
GX_INDEX16 = 3,
} GXAttrType;
typedef enum _GXVtxFmt {
GX_VTXFMT0 = 0,
GX_VTXFMT1 = 1,
GX_VTXFMT2 = 2,
GX_VTXFMT3 = 3,
GX_VTXFMT4 = 4,
GX_VTXFMT5 = 5,
GX_VTXFMT6 = 6,
GX_VTXFMT7 = 7,
GX_MAX_VTXFMT,
} GXVtxFmt;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1,
GX_COMPCNT_NULL = 0,
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5,
GX_COMP_NULL = 0,
} GXCompType;
typedef enum _GXAnisotropy {
GX_ANISO_1 = 0,
GX_ANISO_2 = 1,
GX_ANISO_4 = 2,
GX_MAX_ANISOTROPY,
} GXAnisotropy;
typedef enum _GXLightID {
GX_LIGHT_NULL = 0x0,
GX_LIGHT0 = 0x1,
GX_LIGHT1 = 0x2,
GX_LIGHT2 = 0x4,
GX_LIGHT3 = 0x8,
GX_LIGHT4 = 0x10,
GX_LIGHT5 = 0x20,
GX_LIGHT6 = 0x40,
GX_LIGHT7 = 0x80,
GX_MAX_LIGHT = 0x100,
} GXLightID;
typedef enum _GXDiffuseFn {
GX_DF_NONE = 0,
GX_DF_SIGN = 1,
GX_DF_CLAMP = 2,
} GXDiffuseFn;
typedef enum _GXAttnFn {
GX_AF_SPEC = 0,
GX_AF_SPOT = 1,
GX_AF_NONE = 2,
} GXAttnFn;
typedef enum _GXSpotFn {
GX_SP_OFF = 0,
GX_SP_FLAT = 1,
GX_SP_COS = 2,
GX_SP_COS2 = 3,
GX_SP_SHARP = 4,
GX_SP_RING1 = 5,
GX_SP_RING2 = 6,
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF = 0,
GX_DA_GENTLE = 1,
GX_DA_MEDIUM = 2,
GX_DA_STEEP = 3,
} GXDistAttnFn;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_LINEAR = 2,
GX_FOG_EXPONENT = 4,
GX_FOG_EXPONENT2 = 5,
GX_FOG_REVERSEEXP = 6,
GX_FOG_REVERSEXP2 = 7
} GXFogType;
typedef GXFogType _SDK_GXFogType;
typedef enum _GXBlendMode {
GX_BM_NONE = 0,
GX_BM_BLEND = 1,
GX_BM_LOGIC = 2,
GX_BM_SUBTRACT = 3,
GX_MAX_BLENDMODE,
} GXBlendMode;
typedef GXBlendMode _SDK_GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO = 0,
GX_BL_ONE = 1,
GX_BL_SRCCOL = 2,
GX_BL_DSTCOL = GX_BL_SRCCOL,
GX_BL_INVSRCCOL = 3,
GX_BL_INVDSTCOL = GX_BL_INVSRCCOL,
GX_BL_SRCALPHA = 4,
GX_BL_INVSRCALPHA = 5,
GX_BL_DSTALPHA = 6,
GX_BL_INVDSTALPHA = 7,
} GXBlendFactor;
typedef GXBlendFactor _SDK_GXBlendFactor;
typedef enum _GXCullMode {
GX_CULL_NONE = 0,
GX_CULL_FRONT = 1,
GX_CULL_BACK = 2,
GX_CULL_ALL = 3,
GX_CULL_INVALID = 0xFF,
} GXCullMode;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1,
} GXClipMode;
typedef enum _GXCopyMode {
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3,
} GXCopyMode;
typedef enum _GXChannelID {
GX_COLOR0 = 0,
GX_COLOR1 = 1,
GX_ALPHA0 = 2,
GX_ALPHA1 = 3,
GX_COLOR0A0 = 4,
GX_COLOR1A1 = 5,
GX_COLOR_ZERO = 6,
GX_ALPHA_BUMP = 7,
GX_ALPHA_BUMPN = 8,
GX_COLOR_NULL = 0xFF,
} GXChannelID;
typedef enum _GXColorSrc {
GX_SRC_REG = 0,
GX_SRC_VTX = 1,
} GXColorSrc;
typedef enum _GXAlphaOp {
GX_AOP_AND = 0,
GX_AOP_OR = 1,
GX_AOP_XOR = 2,
GX_AOP_XNOR = 3,
GX_MAX_ALPHAOP,
} GXAlphaOp;
typedef enum _GXAlphaReadMode {
GX_READ_00 = 0,
GX_READ_FF = 1,
GX_READ_NONE = 2,
} GXAlphaReadMode;
typedef enum _GXGamma {
GX_GM_1_0 = 0,
GX_GM_1_7 = 1,
GX_GM_2_2 = 2,
} GXGamma;
typedef enum _GXTexCoordID {
GX_TEXCOORD0 = 0,
GX_TEXCOORD1 = 1,
GX_TEXCOORD2 = 2,
GX_TEXCOORD3 = 3,
GX_TEXCOORD4 = 4,
GX_TEXCOORD5 = 5,
GX_TEXCOORD6 = 6,
GX_TEXCOORD7 = 7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF,
} GXTexCoordID;
typedef enum _GXTexGenType {
GX_TG_MTX2X4 = 0,
GX_TG_MTX3X4 = 1,
GX_TG_BUMP0 = 2,
GX_TG_BUMP1 = 3,
GX_TG_BUMP2 = 4,
GX_TG_BUMP3 = 5,
GX_TG_BUMP4 = 6,
GX_TG_BUMP5 = 7,
GX_TG_BUMP6 = 8,
GX_TG_BUMP7 = 9,
GX_TG_SRTG = 10,
} GXTexGenType;
typedef enum _GXTexGenSrc {
GX_TG_POS = 0,
GX_TG_NRM = 1,
GX_TG_BINRM = 2,
GX_TG_TANGENT = 3,
GX_TG_TEX0 = 4,
GX_TG_TEX1 = 5,
GX_TG_TEX2 = 6,
GX_TG_TEX3 = 7,
GX_TG_TEX4 = 8,
GX_TG_TEX5 = 9,
GX_TG_TEX6 = 10,
GX_TG_TEX7 = 11,
GX_TG_TEXCOORD0 = 12,
GX_TG_TEXCOORD1 = 13,
GX_TG_TEXCOORD2 = 14,
GX_TG_TEXCOORD3 = 15,
GX_TG_TEXCOORD4 = 16,
GX_TG_TEXCOORD5 = 17,
GX_TG_TEXCOORD6 = 18,
GX_TG_COLOR0 = 19,
GX_TG_COLOR1 = 20,
} GXTexGenSrc;
typedef enum _GXTexMapID {
GX_TEXMAP0 = 0,
GX_TEXMAP1 = 1,
GX_TEXMAP2 = 2,
GX_TEXMAP3 = 3,
GX_TEXMAP4 = 4,
GX_TEXMAP5 = 5,
GX_TEXMAP6 = 6,
GX_TEXMAP7 = 7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100,
} GXTexMapID;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_TF_Z8 = 0x11,
GX_TF_Z16 = 0x13,
GX_TF_Z24X8 = 0x16,
GX_CTF_R4 = 0x20,
GX_CTF_RA4 = 0x22,
GX_CTF_RA8 = 0x23,
GX_CTF_YUVA8 = 0x26,
GX_CTF_A8 = 0x26,
GX_CTF_R8 = 0x27,
GX_CTF_G8 = 0x28,
GX_CTF_B8 = 0x29,
GX_CTF_RG8 = 0x2A,
GX_CTF_GB8 = 0x2B,
GX_CTF_Z4 = 0x30,
GX_CTF_Z8M = 0x39,
GX_CTF_Z8L = 0x3A,
GX_CTF_Z16L = 0x3C,
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xA,
} GXCITexFmt;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30 + 0 * 3,
GX_TEXMTX1 = 30 + 1 * 3,
GX_TEXMTX2 = 30 + 2 * 3,
GX_TEXMTX3 = 30 + 3 * 3,
GX_TEXMTX4 = 30 + 4 * 3,
GX_TEXMTX5 = 30 + 5 * 3,
GX_TEXMTX6 = 30 + 6 * 3,
GX_TEXMTX7 = 30 + 7 * 3,
GX_TEXMTX8 = 30 + 8 * 3,
GX_TEXMTX9 = 30 + 9 * 3,
GX_IDENTITY = 60,
GX_TEXMTX_NULL = 0,
} GXTexMtx;
typedef enum _GXTexMtxType {
GX_MTX3x4 = 0,
GX_MTX2x4 = 1,
} GXTexMtxType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64 + 0 * 3,
GX_PTTEXMTX1 = 64 + 1 * 3,
GX_PTTEXMTX2 = 64 + 2 * 3,
GX_PTTEXMTX3 = 64 + 3 * 3,
GX_PTTEXMTX4 = 64 + 4 * 3,
GX_PTTEXMTX5 = 64 + 5 * 3,
GX_PTTEXMTX6 = 64 + 6 * 3,
GX_PTTEXMTX7 = 64 + 7 * 3,
GX_PTTEXMTX8 = 64 + 8 * 3,
GX_PTTEXMTX9 = 64 + 9 * 3,
GX_PTTEXMTX10 = 64 + 10 * 3,
GX_PTTEXMTX11 = 64 + 11 * 3,
GX_PTTEXMTX12 = 64 + 12 * 3,
GX_PTTEXMTX13 = 64 + 13 * 3,
GX_PTTEXMTX14 = 64 + 14 * 3,
GX_PTTEXMTX15 = 64 + 15 * 3,
GX_PTTEXMTX16 = 64 + 16 * 3,
GX_PTTEXMTX17 = 64 + 17 * 3,
GX_PTTEXMTX18 = 64 + 18 * 3,
GX_PTTEXMTX19 = 64 + 19 * 3,
GX_PTIDENTITY = 125,
} GXPTTexMtx;
typedef enum _GXTexOffset {
GX_TO_ZERO = 0,
GX_TO_SIXTEENTH = 1,
GX_TO_EIGHTH = 2,
GX_TO_FOURTH = 3,
GX_TO_HALF = 4,
GX_TO_ONE = 5,
GX_MAX_TEXOFFSET,
} GXTexOffset;
typedef enum _GXTexWrapMode {
GX_CLAMP = 0,
GX_REPEAT = 1,
GX_MIRROR = 2,
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR = 0,
GX_LINEAR = 1,
GX_NEAR_MIP_NEAR = 2,
GX_LIN_MIP_NEAR = 3,
GX_NEAR_MIP_LIN = 4,
GX_LIN_MIP_LIN = 5,
} GXTexFilter;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K = 0,
GX_TEXCACHE_128K = 1,
GX_TEXCACHE_512K = 2,
GX_TEXCACHE_NONE = 3,
} GXTexCacheSize;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_MAX_TLUT = 16,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19,
GX_MAX_BIGTLUT = 4,
GX_MAX_TLUT_ALL = GX_MAX_TLUT + GX_MAX_BIGTLUT,
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8 = 0,
GX_TL_RGB565 = 1,
GX_TL_RGB5A3 = 2,
GX_MAX_TLUTFMT,
} GXTlutFmt;
typedef enum _GXTlutSize {
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024,
} GXTlutSize;
typedef enum _GXIndTexFormat {
GX_ITF_8 = 0,
GX_ITF_5 = 1,
GX_ITF_4 = 2,
GX_ITF_3 = 3,
GX_MAX_ITFORMAT,
} GXIndTexFormat;
typedef enum _GXIndTexStageID {
GX_IND_TEX_STAGE_0 = 0,
GX_IND_TEX_STAGE_1 = 1,
GX_IND_TEX_STAGE_2 = 2,
GX_IND_TEX_STAGE_3 = 3,
GX_IND_MAX_TEX_STAGE_ID,
} GXIndTexStageID;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF = 0,
GX_ITM_0 = 1,
GX_ITM_1 = 2,
GX_ITM_2 = 3,
GX_ITM_S0 = 5,
GX_ITM_S1 = 6,
GX_ITM_S2 = 7,
GX_ITM_T0 = 9,
GX_ITM_T1 = 10,
GX_ITM_T2 = 11,
} GXIndTexMtxID;
typedef enum _GXIndTexScale {
GX_ITS_1 = 0,
GX_ITS_2 = 1,
GX_ITS_4 = 2,
GX_ITS_8 = 3,
GX_ITS_16 = 4,
GX_ITS_32 = 5,
GX_ITS_64 = 6,
GX_ITS_128 = 7,
GX_ITS_256 = 8,
GX_MAX_ITSCALE,
} GXIndTexScale;
typedef enum _GXIndTexWrap {
GX_ITW_OFF = 0,
GX_ITW_256 = 1,
GX_ITW_128 = 2,
GX_ITW_64 = 3,
GX_ITW_32 = 4,
GX_ITW_16 = 5,
GX_ITW_0 = 6,
GX_MAX_ITWRAP,
} GXIndTexWrap;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE = 0,
GX_ITB_S = 1,
GX_ITB_T = 2,
GX_ITB_ST = 3,
GX_ITB_U = 4,
GX_ITB_SU = 5,
GX_ITB_TU = 6,
GX_ITB_STU = 7,
GX_MAX_ITBIAS,
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF = 0,
GX_ITBA_S = 1,
GX_ITBA_T = 2,
GX_ITBA_U = 3,
GX_MAX_ITBALPHA,
} GXIndTexAlphaSel;
typedef enum _GXTevStageID {
GX_TEVSTAGE0 = 0,
GX_TEVSTAGE1 = 1,
GX_TEVSTAGE2 = 2,
GX_TEVSTAGE3 = 3,
GX_TEVSTAGE4 = 4,
GX_TEVSTAGE5 = 5,
GX_TEVSTAGE6 = 6,
GX_TEVSTAGE7 = 7,
GX_TEVSTAGE8 = 8,
GX_TEVSTAGE9 = 9,
GX_TEVSTAGE10 = 10,
GX_TEVSTAGE11 = 11,
GX_TEVSTAGE12 = 12,
GX_TEVSTAGE13 = 13,
GX_TEVSTAGE14 = 14,
GX_TEVSTAGE15 = 15,
GX_MAXTEVSTAGE,
} GXTevStageID;
typedef enum _GXTevRegID {
GX_TEVPREV = 0,
GX_TEVREG0 = 1,
GX_TEVREG1 = 2,
GX_TEVREG2 = 3,
GX_MAX_TEVREG,
} GXTevRegID;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ
} GXTevOp;
typedef enum _GXTevMode {
GX_MODULATE = 0,
GX_DECAL = 1,
GX_BLEND = 2,
GX_REPLACE = 3,
GX_PASSCLR = 4,
} GXTevMode;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN = 1,
GX_CH_BLUE = 2,
GX_CH_ALPHA = 3,
} GXTevColorChan;
typedef enum _GXTevColorArg {
GX_CC_CPREV = 0,
GX_CC_APREV = 1,
GX_CC_C0 = 2,
GX_CC_C1 = 3,
GX_CC_C2 = 4,
GX_CC_A0 = 5,
GX_CC_A1 = 6,
GX_CC_A2 = 7,
GX_CC_TEXC = 8,
GX_CC_TEXA = 9,
GX_CC_RASC = 10,
GX_CC_RASA = 11,
GX_CC_ONE = 12,
GX_CC_HALF = 13,
GX_CC_KONST = 14,
GX_CC_ZERO = 15,
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV = 0,
GX_CA_A0 = 1,
GX_CA_A1 = 2,
GX_CA_A2 = 3,
GX_CA_TEXA = 4,
GX_CA_RASA = 5,
GX_CA_KONST = 6,
GX_CA_ZERO = 7,
} GXTevAlphaArg;
typedef enum _GXTevBias {
GX_TB_ZERO = 0,
GX_TB_ADDHALF = 1,
GX_TB_SUBHALF = 2,
GX_MAX_TEVBIAS,
} GXTevBias;
typedef enum _GXTevClampMode {
GX_TC_LINEAR = 0,
GX_TC_GE = 1,
GX_TC_EQ = 2,
GX_TC_LE = 3,
GX_MAX_TEVCLAMPMODE,
} GXTevClampMode;
typedef enum _GXTevScale {
GX_CS_SCALE_1 = 0,
GX_CS_SCALE_2 = 1,
GX_CS_SCALE_4 = 2,
GX_CS_DIVIDE_2 = 3,
GX_MAX_TEVSCALE,
} GXTevScale;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1 = 1,
GX_TEV_SWAP2 = 2,
GX_TEV_SWAP3 = 3,
GX_MAX_TEVSWAP,
} GXTevSwapSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1 = 1,
GX_KCOLOR2 = 2,
GX_KCOLOR3 = 3,
GX_MAX_KCOLOR,
} GXTevKColorID;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_1 = 0,
GX_TEV_KCSEL_7_8 = 1,
GX_TEV_KCSEL_3_4 = 2,
GX_TEV_KCSEL_5_8 = 3,
GX_TEV_KCSEL_1_2 = 4,
GX_TEV_KCSEL_3_8 = 5,
GX_TEV_KCSEL_1_4 = 6,
GX_TEV_KCSEL_1_8 = 7,
GX_TEV_KCSEL_K0 = 12,
GX_TEV_KCSEL_K1 = 13,
GX_TEV_KCSEL_K2 = 14,
GX_TEV_KCSEL_K3 = 15,
GX_TEV_KCSEL_K0_R = 16,
GX_TEV_KCSEL_K1_R = 17,
GX_TEV_KCSEL_K2_R = 18,
GX_TEV_KCSEL_K3_R = 19,
GX_TEV_KCSEL_K0_G = 20,
GX_TEV_KCSEL_K1_G = 21,
GX_TEV_KCSEL_K2_G = 22,
GX_TEV_KCSEL_K3_G = 23,
GX_TEV_KCSEL_K0_B = 24,
GX_TEV_KCSEL_K1_B = 25,
GX_TEV_KCSEL_K2_B = 26,
GX_TEV_KCSEL_K3_B = 27,
GX_TEV_KCSEL_K0_A = 28,
GX_TEV_KCSEL_K1_A = 29,
GX_TEV_KCSEL_K2_A = 30,
GX_TEV_KCSEL_K3_A = 31,
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_1 = 0,
GX_TEV_KASEL_7_8 = 1,
GX_TEV_KASEL_3_4 = 2,
GX_TEV_KASEL_5_8 = 3,
GX_TEV_KASEL_1_2 = 4,
GX_TEV_KASEL_3_8 = 5,
GX_TEV_KASEL_1_4 = 6,
GX_TEV_KASEL_1_8 = 7,
GX_TEV_KASEL_K0_R = 16,
GX_TEV_KASEL_K1_R = 17,
GX_TEV_KASEL_K2_R = 18,
GX_TEV_KASEL_K3_R = 19,
GX_TEV_KASEL_K0_G = 20,
GX_TEV_KASEL_K1_G = 21,
GX_TEV_KASEL_K2_G = 22,
GX_TEV_KASEL_K3_G = 23,
GX_TEV_KASEL_K0_B = 24,
GX_TEV_KASEL_K1_B = 25,
GX_TEV_KASEL_K2_B = 26,
GX_TEV_KASEL_K3_B = 27,
GX_TEV_KASEL_K0_A = 28,
GX_TEV_KASEL_K1_A = 29,
GX_TEV_KASEL_K2_A = 30,
GX_TEV_KASEL_K3_A = 31,
} GXTevKAlphaSel;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24 = 0,
GX_PF_RGBA6_Z24 = 1,
GX_PF_RGB565_Z16 = 2,
GX_PF_Z24 = 3,
GX_PF_Y8 = 4,
GX_PF_U8 = 5,
GX_PF_V8 = 6,
GX_PF_YUV420 = 7,
GX_MAX_PIXELFMT,
} GXPixelFmt;
typedef GXPixelFmt _SDK_GXPixelFmt;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR = 0,
GX_ZC_NEAR = 1,
GX_ZC_MID = 2,
GX_ZC_FAR = 3,
} GXZFmt16;
typedef GXZFmt16 _SDK_GXZFmt16;
typedef enum _GXProjectionType {
GX_PERSPECTIVE = 0,
GX_ORTHOGRAPHIC = 1,
} GXProjectionType;
typedef enum _GXFBClamp {
GX_CLAMP_NONE = 0,
GX_CLAMP_TOP = 1,
GX_CLAMP_BOTTOM = 2,
GX_CLAMP_BOTH = GX_CLAMP_TOP | GX_CLAMP_BOTTOM,
} GXFBClamp;
typedef enum _GXZTexOp {
GX_ZT_DISABLE = 0,
GX_ZT_ADD = 1,
GX_ZT_REPLACE = 2,
GX_MAX_ZTEXOP,
} GXZTexOp;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES = 0,
GX_PERF0_CLIP_VTX = 1,
GX_PERF0_CLIP_CLKS = 2,
GX_PERF0_XF_WAIT_IN = 3,
GX_PERF0_XF_WAIT_OUT = 4,
GX_PERF0_XF_XFRM_CLKS = 5,
GX_PERF0_XF_LIT_CLKS = 6,
GX_PERF0_XF_BOT_CLKS = 7,
GX_PERF0_XF_REGLD_CLKS = 8,
GX_PERF0_XF_REGRD_CLKS = 9,
GX_PERF0_CLIP_RATIO = 10,
GX_PERF0_TRIANGLES = 11,
GX_PERF0_TRIANGLES_CULLED = 12,
GX_PERF0_TRIANGLES_PASSED = 13,
GX_PERF0_TRIANGLES_SCISSORED = 14,
GX_PERF0_TRIANGLES_0TEX = 15,
GX_PERF0_TRIANGLES_1TEX = 16,
GX_PERF0_TRIANGLES_2TEX = 17,
GX_PERF0_TRIANGLES_3TEX = 18,
GX_PERF0_TRIANGLES_4TEX = 19,
GX_PERF0_TRIANGLES_5TEX = 20,
GX_PERF0_TRIANGLES_6TEX = 21,
GX_PERF0_TRIANGLES_7TEX = 22,
GX_PERF0_TRIANGLES_8TEX = 23,
GX_PERF0_TRIANGLES_0CLR = 24,
GX_PERF0_TRIANGLES_1CLR = 25,
GX_PERF0_TRIANGLES_2CLR = 26,
GX_PERF0_QUAD_0CVG = 27,
GX_PERF0_QUAD_NON0CVG = 28,
GX_PERF0_QUAD_1CVG = 29,
GX_PERF0_QUAD_2CVG = 30,
GX_PERF0_QUAD_3CVG = 31,
GX_PERF0_QUAD_4CVG = 32,
GX_PERF0_AVG_QUAD_CNT = 33,
GX_PERF0_CLOCKS = 34,
GX_PERF0_NONE = 35,
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS = 0,
GX_PERF1_TX_IDLE = 1,
GX_PERF1_TX_REGS = 2,
GX_PERF1_TX_MEMSTALL = 3,
GX_PERF1_TC_CHECK1_2 = 4,
GX_PERF1_TC_CHECK3_4 = 5,
GX_PERF1_TC_CHECK5_6 = 6,
GX_PERF1_TC_CHECK7_8 = 7,
GX_PERF1_TC_MISS = 8,
GX_PERF1_VC_ELEMQ_FULL = 9,
GX_PERF1_VC_MISSQ_FULL = 10,
GX_PERF1_VC_MEMREQ_FULL = 11,
GX_PERF1_VC_STATUS7 = 12,
GX_PERF1_VC_MISSREP_FULL = 13,
GX_PERF1_VC_STREAMBUF_LOW = 14,
GX_PERF1_VC_ALL_STALLS = 15,
GX_PERF1_VERTICES = 16,
GX_PERF1_FIFO_REQ = 17,
GX_PERF1_CALL_REQ = 18,
GX_PERF1_VC_MISS_REQ = 19,
GX_PERF1_CP_ALL_REQ = 20,
GX_PERF1_CLOCKS = 21,
GX_PERF1_NONE = 22,
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS = 0,
GX_VC_NRM = 1,
GX_VC_CLR0 = 2,
GX_VC_CLR1 = 3,
GX_VC_TEX0 = 4,
GX_VC_TEX1 = 5,
GX_VC_TEX2 = 6,
GX_VC_TEX3 = 7,
GX_VC_TEX4 = 8,
GX_VC_TEX5 = 9,
GX_VC_TEX6 = 10,
GX_VC_TEX7 = 11,
GX_VC_ALL = 15
} GXVCachePerf;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3,
} GXMiscToken;
typedef enum _GXDirtyFlag {
GX_DIRTY_SU_TEX = (1 << 0),
GX_DIRTY_BP_MASK = (1 << 1),
GX_DIRTY_GEN_MODE = (1 << 2),
GX_DIRTY_VCD = (1 << 3),
GX_DIRTY_VAT = (1 << 4),
GX_DIRTY_AMB_COLOR0 = (1 << 8),
GX_DIRTY_AMB_COLOR1 = (1 << 9),
GX_DIRTY_MAT_COLOR0 = (1 << 10),
GX_DIRTY_MAT_COLOR1 = (1 << 11),
GX_DIRTY_CHAN_COLOR0 = (1 << 12),
GX_DIRTY_CHAN_COLOR1 = (1 << 13),
GX_DIRTY_CHAN_ALPHA0 = (1 << 14),
GX_DIRTY_CHAN_ALPHA1 = (1 << 15),
GX_DIRTY_TEX0 = (1 << 16),
GX_DIRTY_TEX1 = (1 << 17),
GX_DIRTY_TEX2 = (1 << 18),
GX_DIRTY_TEX3 = (1 << 19),
GX_DIRTY_TEX4 = (1 << 20),
GX_DIRTY_TEX5 = (1 << 21),
GX_DIRTY_TEX6 = (1 << 22),
GX_DIRTY_TEX7 = (1 << 23),
GX_DIRTY_NUM_COLORS = (1 << 24),
GX_DIRTY_NUM_TEX = (1 << 25),
GX_DIRTY_MTX_IDX = (1 << 26),
GX_DIRTY_PROJECTION = (1 << 27),
GX_DIRTY_VIEWPORT = (1 << 28),
GX_AMB_MAT_MASK = GX_DIRTY_AMB_COLOR0 | GX_DIRTY_AMB_COLOR1 | GX_DIRTY_MAT_COLOR0 | GX_DIRTY_MAT_COLOR1,
GX_LIGHT_CHAN_MASK
= GX_DIRTY_CHAN_COLOR0 | GX_DIRTY_CHAN_COLOR1 | GX_DIRTY_CHAN_ALPHA0 | GX_DIRTY_CHAN_ALPHA1 | GX_DIRTY_NUM_COLORS,
GX_TEX_GEN_MASK = 0x2FF0000,
} GXDirtyFlag;
typedef enum _GXFifoCmd {
GX_FIFO_CMD_NOOP = 0x00,
GX_FIFO_CMD_LOAD_BP_REG = 0x61,
GX_FIFO_CMD_LOAD_CP_REG = 0x08,
GX_FIFO_CMD_LOAD_XF_REG = 0x10,
GX_FIFO_CMD_LOAD_INDX_A = 0x20,
GX_FIFO_CMD_LOAD_INDX_B = 0x28,
GX_FIFO_CMD_LOAD_INDX_C = 0x30,
GX_FIFO_CMD_LOAD_INDX_D = 0x38,
GX_FIFO_CMD_CALL_DL = 0x40,
GX_FIFO_CMD_INVAL_VTX = 0x48,
} GXFifoCmd;
typedef enum _GXXfTexReg {
GX_XF_TEX_PROJ_ST = 0,
GX_XF_TEX_PROJ_STQ = 1,
GX_XF_TEX_FORM_AB11 = 0,
GX_XF_TEX_FORM_ABC1 = 1,
} GXXfTexReg;
typedef enum _GXXfTexGen {
GX_XF_TG_REGULAR = 0,
GX_XF_TG_BUMP = 1,
GX_XF_TG_CLR0 = 2,
GX_XF_TG_CLR1 = 3,
} GXXfTexGen;
typedef enum _GXXfMem {
GX_XF_MEM_POSMTX = 0x000,
GX_XF_MEM_NRMMTX = 0x400,
GX_XF_MEM_DUALTEXMTX = 0x500,
GX_XF_MEM_LIGHTOBJ = 0x600,
} GXXfMem;
typedef enum _GXBPRegs {
GX_BP_REG_GENMODE = 0x0,
GX_BP_REG_DISPCOPYFILTER0 = 0x1,
GX_BP_REG_DISPCOPYFILTER1 = 0x2,
GX_BP_REG_DISPCOPYFILTER2 = 0x3,
GX_BP_REG_DISPCOPYFILTER3 = 0x4,
GX_BP_REG_INDMTX0A = 0x6,
GX_BP_REG_INDMTX0B = 0x7,
GX_BP_REG_INDMTX0C = 0x8,
GX_BP_REG_INDMTX1A = 0x9,
GX_BP_REG_INDMTX1B = 0xA,
GX_BP_REG_INDMTX1C = 0xB,
GX_BP_REG_INDMTX2A = 0xC,
GX_BP_REG_INDMTX2B = 0xD,
GX_BP_REG_INDMTX2C = 0xE,
GX_BP_REG_INDIMASK = 0xF,
GX_BP_REG_INDTEVSTAGE0 = 0x10,
GX_BP_REG_INDTEVSTAGE1 = 0x11,
GX_BP_REG_INDTEVSTAGE2 = 0x12,
GX_BP_REG_INDTEVSTAGE3 = 0x13,
GX_BP_REG_INDTEVSTAGE4 = 0x14,
GX_BP_REG_INDTEVSTAGE5 = 0x15,
GX_BP_REG_INDTEVSTAGE6 = 0x16,
GX_BP_REG_INDTEVSTAGE7 = 0x17,
GX_BP_REG_INDTEVSTAGE8 = 0x18,
GX_BP_REG_INDTEVSTAGE9 = 0x19,
GX_BP_REG_INDTEVSTAGE10 = 0x1A,
GX_BP_REG_INDTEVSTAGE11 = 0x1B,
GX_BP_REG_INDTEVSTAGE12 = 0x1C,
GX_BP_REG_INDTEVSTAGE13 = 0x1D,
GX_BP_REG_INDTEVSTAGE14 = 0x1E,
GX_BP_REG_INDTEVSTAGE15 = 0x1F,
GX_BP_REG_SCISSORTL = 0x20,
GX_BP_REG_SCISSORBR = 0x21,
GX_BP_REG_LINEPTWIDTH = 0x22,
GX_BP_REG_PERF0TRI = 0x23,
GX_BP_REG_PERF0QUAD = 0x24,
GX_BP_REG_RAS1_SS0 = 0x25,
GX_BP_REG_RAS1_SS1 = 0x26,
GX_BP_REG_RAS1_IREF = 0x27,
GX_BP_REG_RAS1_TREF0 = 0x28,
GX_BP_REG_RAS1_TREF1 = 0x29,
GX_BP_REG_RAS1_TREF2 = 0x2A,
GX_BP_REG_RAS1_TREF3 = 0x2B,
GX_BP_REG_RAS1_TREF4 = 0x2C,
GX_BP_REG_RAS1_TREF5 = 0x2D,
GX_BP_REG_RAS1_TREF6 = 0x2E,
GX_BP_REG_RAS1_TREF7 = 0x2F,
GX_BP_REG_SU_SSIZE0 = 0x30,
GX_BP_REG_SU_TSIZE0 = 0x31,
GX_BP_REG_SU_SSIZE1 = 0x32,
GX_BP_REG_SU_TSIZE1 = 0x33,
GX_BP_REG_SU_SSIZE2 = 0x34,
GX_BP_REG_SU_TSIZE2 = 0x35,
GX_BP_REG_SU_SSIZE3 = 0x36,
GX_BP_REG_SU_TSIZE3 = 0x37,
GX_BP_REG_SU_SSIZE4 = 0x38,
GX_BP_REG_SU_TSIZE4 = 0x39,
GX_BP_REG_SU_SSIZE5 = 0x3A,
GX_BP_REG_SU_TSIZE5 = 0x3B,
GX_BP_REG_SU_SSIZE6 = 0x3C,
GX_BP_REG_SU_TSIZE6 = 0x3D,
GX_BP_REG_SU_SSIZE7 = 0x3E,
GX_BP_REG_SU_TSIZE7 = 0x3F,
GX_BP_REG_ZMODE = 0x40,
GX_BP_REG_BLENDMODE = 0x41,
GX_BP_REG_DSTALPHA = 0x42,
GX_BP_REG_ZCONTROL = 0x43,
GX_BP_REG_FIELDMASK = 0x44,
GX_BP_REG_DRAWDONE = 0x45,
GX_BP_REG_PETOKEN = 0x47,
GX_BP_REG_PETOKENINT = 0x48,
GX_BP_REG_TEXCOPYSRCXY = 0x49,
GX_BP_REG_TEXCOPYSRCWH = 0x4A,
GX_BP_REG_TEXCOPYDST = 0x4B,
GX_BP_REG_DISPCOPYSTRIDE = 0x4D,
GX_BP_REG_DISPCOPYSCALEY = 0x4E,
GX_BP_REG_COPYCLEARAR = 0x4F,
GX_BP_REG_COPYCLEARGB = 0x50,
GX_BP_REG_COPYCLEARZ = 0x51,
GX_BP_REG_COPYFILTER0 = 0x53,
GX_BP_REG_COPYFILTER1 = 0x54,
GX_BP_REG_BOUNDINGBOX0 = 0x55,
GX_BP_REG_BOUNDINGBOX1 = 0x56,
GX_BP_REG_SCISSOROFFSET = 0x59,
GX_BP_REG_TMEMPRELOADADDR = 0x60,
GX_BP_REG_TMEMPRELOADEVEN = 0x61,
GX_BP_REG_TMEMPRELOADODD = 0x62,
GX_BP_REG_TMEMPRELOADMODE = 0x63,
GX_BP_REG_TMEMTLUTSRC = 0x64,
GX_BP_REG_TMEMTLUTDST = 0x65,
GX_BP_REG_TMEMTEXINVALIDATE = 0x66,
GX_BP_REG_PERF1 = 0x67,
GX_BP_REG_FIELDMODE = 0x68,
GX_BP_REG_SETMODE0_TEX0 = 0x80,
GX_BP_REG_SETMODE0_TEX1 = 0x81,
GX_BP_REG_SETMODE0_TEX2 = 0x82,
GX_BP_REG_SETMODE0_TEX3 = 0x83,
GX_BP_REG_SETMODE1_TEX0 = 0x84,
GX_BP_REG_SETMODE1_TEX1 = 0x85,
GX_BP_REG_SETMODE1_TEX2 = 0x86,
GX_BP_REG_SETMODE1_TEX3 = 0x87,
GX_BP_REG_SETIMAGE0_TEX0 = 0x88,
GX_BP_REG_SETIMAGE0_TEX1 = 0x89,
GX_BP_REG_SETIMAGE0_TEX2 = 0x8A,
GX_BP_REG_SETIMAGE0_TEX3 = 0x8B,
GX_BP_REG_SETIMAGE1_TEX0 = 0x8C,
GX_BP_REG_SETIMAGE1_TEX1 = 0x8D,
GX_BP_REG_SETIMAGE1_TEX2 = 0x8E,
GX_BP_REG_SETIMAGE1_TEX3 = 0x8F,
GX_BP_REG_SETIMAGE2_TEX0 = 0x90,
GX_BP_REG_SETIMAGE2_TEX1 = 0x91,
GX_BP_REG_SETIMAGE2_TEX2 = 0x92,
GX_BP_REG_SETIMAGE2_TEX3 = 0x93,
GX_BP_REG_SETIMAGE3_TEX0 = 0x94,
GX_BP_REG_SETIMAGE3_TEX1 = 0x95,
GX_BP_REG_SETIMAGE3_TEX2 = 0x96,
GX_BP_REG_SETIMAGE3_TEX3 = 0x97,
GX_BP_REG_SETTLUT_TEX0 = 0x98,
GX_BP_REG_SETTLUT_TEX1 = 0x99,
GX_BP_REG_SETTLUT_TEX2 = 0x9A,
GX_BP_REG_SETTLUT_TEX3 = 0x9B,
GX_BP_REG_SETMODE0_TEX4 = 0xA0,
GX_BP_REG_SETMODE0_TEX5 = 0xA1,
GX_BP_REG_SETMODE0_TEX6 = 0xA2,
GX_BP_REG_SETMODE0_TEX7 = 0xA3,
GX_BP_REG_SETMODE1_TEX4 = 0xA4,
GX_BP_REG_SETMODE1_TEX5 = 0xA5,
GX_BP_REG_SETMODE1_TEX6 = 0xA6,
GX_BP_REG_SETMODE1_TEX7 = 0xA7,
GX_BP_REG_SETIMAGE0_TEX4 = 0xA8,
GX_BP_REG_SETIMAGE0_TEX5 = 0xA9,
GX_BP_REG_SETIMAGE0_TEX6 = 0xAA,
GX_BP_REG_SETIMAGE0_TEX7 = 0xAB,
GX_BP_REG_SETIMAGE1_TEX4 = 0xAC,
GX_BP_REG_SETIMAGE1_TEX5 = 0xAD,
GX_BP_REG_SETIMAGE1_TEX6 = 0xAE,
GX_BP_REG_SETIMAGE1_TEX7 = 0xAF,
GX_BP_REG_SETIMAGE2_TEX4 = 0xB0,
GX_BP_REG_SETIMAGE2_TEX5 = 0xB1,
GX_BP_REG_SETIMAGE2_TEX6 = 0xB2,
GX_BP_REG_SETIMAGE2_TEX7 = 0xB3,
GX_BP_REG_SETIMAGE3_TEX4 = 0xB4,
GX_BP_REG_SETIMAGE3_TEX5 = 0xB5,
GX_BP_REG_SETIMAGE3_TEX6 = 0xB6,
GX_BP_REG_SETIMAGE3_TEX7 = 0xB7,
GX_BP_REG_SETTLUT_TEX4 = 0xB8,
GX_BP_REG_SETTLUT_TEX5 = 0xB9,
GX_BP_REG_SETTLUT_TEX6 = 0xBA,
GX_BP_REG_SETTLUT_TEX7 = 0xBB,
GX_BP_REG_TEVCOLORCOMBINER0 = 0xC0,
GX_BP_REG_TEVALPHACOMBINER0 = 0xC1,
GX_BP_REG_TEVCOLORCOMBINER1 = 0xC2,
GX_BP_REG_TEVALPHACOMBINER1 = 0xC3,
GX_BP_REG_TEVCOLORCOMBINER2 = 0xC4,
GX_BP_REG_TEVALPHACOMBINER2 = 0xC5,
GX_BP_REG_TEVCOLORCOMBINER3 = 0xC6,
GX_BP_REG_TEVALPHACOMBINER3 = 0xC7,
GX_BP_REG_TEVCOLORCOMBINER4 = 0xC8,
GX_BP_REG_TEVALPHACOMBINER4 = 0xC9,
GX_BP_REG_TEVCOLORCOMBINER5 = 0xCA,
GX_BP_REG_TEVALPHACOMBINER5 = 0xCB,
GX_BP_REG_TEVCOLORCOMBINER6 = 0xCC,
GX_BP_REG_TEVALPHACOMBINER6 = 0xCD,
GX_BP_REG_TEVCOLORCOMBINER7 = 0xCE,
GX_BP_REG_TEVALPHACOMBINER7 = 0xCF,
GX_BP_REG_TEVCOLORCOMBINER8 = 0xD0,
GX_BP_REG_TEVALPHACOMBINER8 = 0xD1,
GX_BP_REG_TEVCOLORCOMBINER9 = 0xD2,
GX_BP_REG_TEVALPHACOMBINER9 = 0xD3,
GX_BP_REG_TEVCOLORCOMBINER10 = 0xD4,
GX_BP_REG_TEVALPHACOMBINER10 = 0xD5,
GX_BP_REG_TEVCOLORCOMBINER11 = 0xD6,
GX_BP_REG_TEVALPHACOMBINER11 = 0xD7,
GX_BP_REG_TEVCOLORCOMBINER12 = 0xD8,
GX_BP_REG_TEVALPHACOMBINER12 = 0xD9,
GX_BP_REG_TEVCOLORCOMBINER13 = 0xDA,
GX_BP_REG_TEVALPHACOMBINER13 = 0xDB,
GX_BP_REG_TEVCOLORCOMBINER14 = 0xDC,
GX_BP_REG_TEVALPHACOMBINER14 = 0xDD,
GX_BP_REG_TEVCOLORCOMBINER15 = 0xDE,
GX_BP_REG_TEVALPHACOMBINER15 = 0xDF,
GX_BP_REG_TEVREG0LO = 0xE0,
GX_BP_REG_TEVREG0HI = 0xE1,
GX_BP_REG_TEVREG1LO = 0xE2,
GX_BP_REG_TEVREG1HI = 0xE3,
GX_BP_REG_TEVREG2LO = 0xE4,
GX_BP_REG_TEVREG2HI = 0xE5,
GX_BP_REG_TEVREG3LO = 0xE6,
GX_BP_REG_TEVREG3HI = 0xE7,
GX_BP_REG_FOGRANGE = 0xE8,
GX_BP_REG_FOGRANGEK0 = 0xE9,
GX_BP_REG_FOGRANGEK1 = 0xEA,
GX_BP_REG_FOGRANGEK2 = 0xEB,
GX_BP_REG_FOGRANGEK3 = 0xEC,
GX_BP_REG_FOGRANGEK4 = 0xED,
GX_BP_REG_FOGPARAM0 = 0xEE,
GX_BP_REG_FOGPARAM1 = 0xEF,
GX_BP_REG_FOGPARAM2 = 0xF0,
GX_BP_REG_FOGPARAM3 = 0xF1,
GX_BP_REG_FOGCOLOR = 0xF2,
GX_BP_REG_ALPHACOMPARE = 0xF3,
GX_BP_REG_ZTEXTURE0 = 0xF4,
GX_BP_REG_ZTEXTURE1 = 0xF5,
GX_BP_REG_TEVKSEL0 = 0xF6,
GX_BP_REG_TEVKSEL1 = 0xF7,
GX_BP_REG_TEVKSEL2 = 0xF8,
GX_BP_REG_TEVKSEL3 = 0xF9,
GX_BP_REG_TEVKSEL4 = 0xFA,
GX_BP_REG_TEVKSEL5 = 0xFB,
GX_BP_REG_TEVKSEL6 = 0xFC,
GX_BP_REG_TEVKSEL7 = 0xFD,
GX_BP_REG_SSMASK = 0xFE,
} GXBPRegs;
typedef enum _GXCPRegs {
GX_CP_REG_MTXIDXA = 0x30,
GX_CP_REG_MTXIDXB = 0x40,
GX_CP_REG_VCD_LO = 0x50,
GX_CP_REG_VCD_HI = 0x60,
GX_CP_REG_VAT_GRP0 = 0x70,
GX_CP_REG_VAT_GRP1 = 0x80,
GX_CP_REG_VAT_GRP2 = 0x90,
GX_CP_REG_ARRAYBASE = 0xA0,
GX_CP_REG_ARRAYSTRIDE = 0xB0,
} GXCPRegs;
typedef enum _GXXFRegs {
GX_XF_REG_ERROR = 0x1000,
GX_XF_REG_DIAGNOSTICS = 0x1001,
GX_XF_REG_STATE0 = 0x1002,
GX_XF_REG_STATE1 = 0x1003,
GX_XF_REG_CLOCK = 0x1004,
GX_XF_REG_CLIPDISABLE = 0x1005,
GX_XF_REG_PERF0 = 0x1006,
GX_XF_REG_PERF1 = 0x1007,
GX_XF_REG_INVERTEXSPEC = 0x1008,
GX_XF_REG_NUMCOLORS = 0x1009,
GX_XF_REG_AMBIENT0 = 0x100A,
GX_XF_REG_AMBIENT1 = 0x100B,
GX_XF_REG_MATERIAL0 = 0x100C,
GX_XF_REG_MATERIAL1 = 0x100D,
GX_XF_REG_COLOR0CNTRL = 0x100E,
GX_XF_REG_COLOR1CNTRL = 0x100F,
GX_XF_REG_ALPHA0CNTRL = 0x1010,
GX_XF_REG_ALPHA1CNTRL = 0x1011,
GX_XF_REG_DUALTEXTRAN = 0x1012,
GX_XF_REG_MATRIXINDEX0 = 0x1018,
GX_XF_REG_MATRIXINDEX1 = 0x1019,
GX_XF_REG_SCALEX = 0x101A,
GX_XF_REG_SCALEY = 0x101B,
GX_XF_REG_SCALEZ = 0x101C,
GX_XF_REG_OFFSETX = 0x101D,
GX_XF_REG_OFFSETY = 0x101E,
GX_XF_REG_OFFSETZ = 0x101F,
GX_XF_REG_PROJECTIONA = 0x1020,
GX_XF_REG_PROJECTIONB = 0x1021,
GX_XF_REG_PROJECTIONC = 0x1022,
GX_XF_REG_PROJECTIOND = 0x1023,
GX_XF_REG_PROJECTIONE = 0x1024,
GX_XF_REG_PROJECTIONF = 0x1025,
GX_XF_REG_PROJECTORTHO = 0x1026,
GX_XF_REG_NUMTEX = 0x103F,
GX_XF_REG_TEX0 = 0x1040,
GX_XF_REG_TEX1 = 0x1041,
GX_XF_REG_TEX2 = 0x1042,
GX_XF_REG_TEX3 = 0x1043,
GX_XF_REG_TEX4 = 0x1044,
GX_XF_REG_TEX5 = 0x1045,
GX_XF_REG_TEX6 = 0x1046,
GX_XF_REG_TEX7 = 0x1047,
GX_XF_REG_DUALTEX0 = 0x1050,
GX_XF_REG_DUALTEX1 = 0x1051,
GX_XF_REG_DUALTEX2 = 0x1052,
GX_XF_REG_DUALTEX3 = 0x1053,
GX_XF_REG_DUALTEX4 = 0x1054,
GX_XF_REG_DUALTEX5 = 0x1055,
GX_XF_REG_DUALTEX6 = 0x1056,
GX_XF_REG_DUALTEX7 = 0x1057,
} GXXFRegs;
typedef enum _GXBPGenMode {
GX_BP_GENMODE_NUMTEX_ST = 28,
GX_BP_GENMODE_NUMTEX_END = 31,
GX_BP_GENMODE_NUMCOLORS_ST = 25,
GX_BP_GENMODE_NUMCOLORS_END = 27,
GX_BP_GENMODE_MULTISAMPLE_ST = 22,
GX_BP_GENMODE_MULTISAMPLE_END = 22,
GX_BP_GENMODE_CULLMODE_ST = 16,
GX_BP_GENMODE_CULLMODE_END = 17,
GX_BP_GENMODE_NUMINDSTAGES_ST = 13,
GX_BP_GENMODE_NUMINDSTAGES_END = 15,
GX_BP_GENMODE_COPLANAR_ST = 12,
GX_BP_GENMODE_COPLANAR_END = 12,
} GXBPGenMode;
typedef enum _GXBPIndMtx {
GX_BP_INDMTX_M00_ST = 21,
GX_BP_INDMTX_M00_END = 31,
GX_BP_INDMTX_M10_ST = 10,
GX_BP_INDMTX_M10_END = 20,
GX_BP_INDMTX_EXP_ST = 8,
GX_BP_INDMTX_EXP_END = 9,
} GXBPIndMtx;
typedef enum _GXBPIndIMask {
GX_BP_INDIMASK_ST = 24,
GX_BP_INDIMASK_END = 31,
} GXBPIndIMask;
typedef enum _GXBPIndTevStage {
GX_BP_INDTEV_STAGE_ST = 30,
GX_BP_INDTEV_STAGE_END = 31,
GX_BP_INDTEV_FMT_ST = 28,
GX_BP_INDTEV_FMT_END = 29,
GX_BP_INDTEV_BIAS_ST = 25,
GX_BP_INDTEV_BIAS_END = 27,
GX_BP_INDTEV_ALPHA_ST = 23,
GX_BP_INDTEV_ALPHA_END = 24,
GX_BP_INDTEV_MTX_ST = 19,
GX_BP_INDTEV_MTX_END = 22,
GX_BP_INDTEV_WRAPS_ST = 16,
GX_BP_INDTEV_WRAPS_END = 18,
GX_BP_INDTEV_WRAPT_ST = 13,
GX_BP_INDTEV_WRAPT_END = 15,
GX_BP_INDTEV_UNMODTEXCOORD_ST = 12,
GX_BP_INDTEV_UNMODTEXCOORD_END = 12,
GX_BP_INDTEV_ADDPREV_ST = 11,
GX_BP_INDTEV_ADDPREV_END = 11,
} GXBPIndTevStage;
typedef enum _GXBPScissorTL {
GX_BP_SCISSORTL_TOP_ST = 21,
GX_BP_SCISSORTL_TOP_END = 31,
GX_BP_SCISSORTL_LEFT_ST = 9,
GX_BP_SCISSORTL_LEFT_END = 19,
} GXBPScissorTL;
typedef enum _GXBPScissorBR {
GX_BP_SCISSORBR_BOT_ST = 21,
GX_BP_SCISSORBR_BOT_END = 31,
GX_BP_SCISSORBR_RIGHT_ST = 9,
GX_BP_SCISSORBR_RIGHT_END = 19,
} GXBPScissorBR;
typedef enum _GXBPLinePtWidth {
GX_BP_LINEPTWIDTH_LINESZ_ST = 24,
GX_BP_LINEPTWIDTH_LINESZ_END = 31,
GX_BP_LINEPTWIDTH_POINTSZ_ST = 16,
GX_BP_LINEPTWIDTH_POINTSZ_END = 23,
GX_BP_LINEPTWIDTH_LINEOFS_ST = 13,
GX_BP_LINEPTWIDTH_LINEOFS_END = 15,
GX_BP_LINEPTWIDTH_POINTOFS_ST = 10,
GX_BP_LINEPTWIDTH_POINTOFS_END = 12,
GX_BP_LINEPTWIDTH_ADJUST_ST = 9,
GX_BP_LINEPTWIDTH_ADJUST_END = 9,
} GXBPLinePtWidth;
typedef enum _GXBPRas1SS0 {
GX_BP_RAS1_SS0_S0_ST = 28,
GX_BP_RAS1_SS0_S0_END = 31,
GX_BP_RAS1_SS0_T0_ST = 24,
GX_BP_RAS1_SS0_T0_END = 27,
GX_BP_RAS1_SS0_S1_ST = 20,
GX_BP_RAS1_SS0_S1_END = 23,
GX_BP_RAS1_SS0_T1_ST = 16,
GX_BP_RAS1_SS0_T1_END = 19,
} GXBPRas1SS0;
typedef enum _GXBPRas1SS1 {
GX_BP_RAS1_SS1_S2_ST = 28,
GX_BP_RAS1_SS1_S2_END = 31,
GX_BP_RAS1_SS1_T2_ST = 24,
GX_BP_RAS1_SS1_T2_END = 27,
GX_BP_RAS1_SS1_S3_ST = 20,
GX_BP_RAS1_SS1_S3_END = 23,
GX_BP_RAS1_SS1_T3_ST = 16,
GX_BP_RAS1_SS1_T3_END = 19,
} GXBPRas1SS1;
typedef enum _GXBPRasIRef {
GX_BP_RAS1_IREF_MAP0_ST = 29,
GX_BP_RAS1_IREF_MAP0_END = 31,
GX_BP_RAS1_IREF_TXC0_ST = 26,
GX_BP_RAS1_IREF_TXC0_END = 28,
GX_BP_RAS1_IREF_MAP1_ST = 23,
GX_BP_RAS1_IREF_MAP1_END = 25,
GX_BP_RAS1_IREF_TXC1_ST = 20,
GX_BP_RAS1_IREF_TXC1_END = 22,
GX_BP_RAS1_IREF_MAP2_ST = 17,
GX_BP_RAS1_IREF_MAP2_END = 19,
GX_BP_RAS1_IREF_TXC2_ST = 14,
GX_BP_RAS1_IREF_TXC2_END = 16,
GX_BP_RAS1_IREF_MAP3_ST = 11,
GX_BP_RAS1_IREF_MAP3_END = 13,
GX_BP_RAS1_IREF_TXC3_ST = 8,
GX_BP_RAS1_IREF_TXC3_END = 10,
} GXBPRasIRef;
typedef enum _GXBPSUSSize {
GX_BP_SU_SSIZE_USELINEOFS_ST = 13,
GX_BP_SU_SSIZE_USELINEOFS_END = 13,
GX_BP_SU_SSIZE_USEPTOFS_ST = 12,
GX_BP_SU_SSIZE_USEPTOFS_END = 12,
} GXBPSUSSize;
typedef enum _GXBPZMode {
GX_BP_ZMODE_TEST_ENABLE_ST = 31,
GX_BP_ZMODE_TEST_ENABLE_END = 31,
GX_BP_ZMODE_COMPARE_ST = 28,
GX_BP_ZMODE_COMPARE_END = 30,
GX_BP_ZMODE_UPDATE_ENABLE_ST = 27,
GX_BP_ZMODE_UPDATE_ENABLE_END = 27,
} GXBPZMode;
typedef enum _GXBPBlendMode {
GX_BP_BLENDMODE_ENABLE_ST = 31,
GX_BP_BLENDMODE_ENABLE_END = 31,
GX_BP_BLENDMODE_LOGIC_OP_ST = 30,
GX_BP_BLENDMODE_LOGIC_OP_END = 30,
GX_BP_BLENDMODE_DITHER_ST = 29,
GX_BP_BLENDMODE_DITHER_END = 29,
GX_BP_BLENDMODE_COLOR_UPDATE_ST = 28,
GX_BP_BLENDMODE_COLOR_UPDATE_END = 28,
GX_BP_BLENDMODE_ALPHA_UPDATE_ST = 27,
GX_BP_BLENDMODE_ALPHA_UPDATE_END = 27,
GX_BP_BLENDMODE_DSTFACTOR_ST = 24,
GX_BP_BLENDMODE_DSTFACTOR_END = 26,
GX_BP_BLENDMODE_SRCFACTOR_ST = 21,
GX_BP_BLENDMODE_SRCFACTOR_END = 23,
GX_BP_BLENDMODE_SUBTRACT_ST = 20,
GX_BP_BLENDMODE_SUBTRACT_END = 20,
GX_BP_BLENDMODE_LOGICMODE_ST = 16,
GX_BP_BLENDMODE_LOGICMODE_END = 19,
} GXBPBlendMode;
typedef enum _GXBPDstAlpha {
GX_BP_DSTALPHA_ALPHA_ST = 24,
GX_BP_DSTALPHA_ALPHA_END = 31,
GX_BP_DSTALPHA_ENABLE_ST = 23,
GX_BP_DSTALPHA_ENABLE_END = 23,
GX_BP_DSTALPHA_YUV_FMT_ST = 21,
GX_BP_DSTALPHA_YUV_FMT_END = 22,
} GXBPDstAlpha;
typedef enum _GXBPZControl {
GX_BP_ZCONTROL_PIXEL_FMT_ST = 29,
GX_BP_ZCONTROL_PIXEL_FMT_END = 31,
GX_BP_ZCONTROL_Z_FMT_ST = 26,
GX_BP_ZCONTROL_Z_FMT_END = 28,
GX_BP_ZCONTROL_BEFORE_TEX_ST = 25,
GX_BP_ZCONTROL_BEFORE_TEX_END = 25,
} GXBPZControl;
typedef enum _GXBPFieldMask {
GX_BP_FIELDMASK_ODD_ST = 31,
GX_BP_FIELDMASK_ODD_END = 31,
GX_BP_FIELDMASK_EVEN_ST = 30,
GX_BP_FIELDMASK_EVEN_END = 30,
} GXBPFieldMask;
typedef enum _GXBPScissorOffset {
GX_BP_SCISSOROFS_OX_ST = 22,
GX_BP_SCISSOROFS_OX_END = 31,
GX_BP_SCISSOROFS_OY_ST = 12,
GX_BP_SCISSOROFS_OY_END = 21,
} GXBPScissorOffset;
typedef enum _GXBPFieldMode {
GX_BP_FIELDMODE_TEX_LOD_ST = 31,
GX_BP_FIELDMODE_TEX_LOD_END = 31,
} GXBPFieldMode;
typedef enum _GXBPFogRange {
GX_BP_FOGRANGE_CENTER_ST = 22,
GX_BP_FOGRANGE_CENTER_END = 31,
GX_BP_FOGRANGE_ENABLED_ST = 21,
GX_BP_FOGRANGE_ENABLED_END = 21,
} GXBPFogRange;
typedef enum _GXBPFogRangeK {
GX_BP_FOGRANGEK_HI_ST = 20,
GX_BP_FOGRANGEK_HI_END = 31,
GX_BP_FOGRANGEK_LO_ST = 8,
GX_BP_FOGRANGEK_LO_END = 19,
} GXBPFogRangeK;
typedef enum _GXBPFogParam0 {
GX_BP_FOGPARAM0_A_MANT_ST = 21,
GX_BP_FOGPARAM0_A_MANT_END = 31,
GX_BP_FOGPARAM0_A_EXP_ST = 13,
GX_BP_FOGPARAM0_A_EXP_END = 20,
GX_BP_FOGPARAM0_A_SIGN_ST = 12,
GX_BP_FOGPARAM0_A_SIGN_END = 12,
} GXBPFogParam0;
typedef enum _GXBPFogParam1 {
GX_BP_FOGPARAM1_B_MAG_ST = 8,
GX_BP_FOGPARAM1_B_MAG_END = 31,
} GXBPFogParam1;
typedef enum _GXBPFogParam2 {
GX_BP_FOGPARAM2_B_SHIFT_ST = 27,
GX_BP_FOGPARAM2_B_SHIFT_END = 31,
} GXBPFogParam2;
typedef enum _GXBPFogParam3 {
GX_BP_FOGPARAM3_C_MANT_ST = 21,
GX_BP_FOGPARAM3_C_MANT_END = 31,
GX_BP_FOGPARAM3_C_EXP_ST = 13,
GX_BP_FOGPARAM3_C_EXP_END = 20,
GX_BP_FOGPARAM3_C_SIGN_ST = 12,
GX_BP_FOGPARAM3_C_SIGN_END = 12,
GX_BP_FOGPARAM3_PROJ_ST = 11,
GX_BP_FOGPARAM3_PROJ_END = 11,
GX_BP_FOGPARAM3_FSEL_ST = 8,
GX_BP_FOGPARAM3_FSEL_END = 10,
} GXBPFogParam3;
typedef enum _GXBPFogColor {
GX_BP_FOGCOLOR_RGB_ST = 8,
GX_BP_FOGCOLOR_RGB_END = 31,
} GXBPFogColor;
typedef enum _GXCPMtxIdxA {
GX_CP_MTXIDXA_GEOM_ST = 26,
GX_CP_MTXIDXA_GEOM_END = 31,
GX_CP_MTXIDXA_TEX0_ST = 20,
GX_CP_MTXIDXA_TEX0_END = 25,
GX_CP_MTXIDXA_TEX1_ST = 14,
GX_CP_MTXIDXA_TEX1_END = 19,
GX_CP_MTXIDXA_TEX2_ST = 8,
GX_CP_MTXIDXA_TEX2_END = 13,
GX_CP_MTXIDXA_TEX3_ST = 2,
GX_CP_MTXIDXA_TEX3_END = 7,
} GXCPMtxIdxA;
typedef enum _GXCPMtxIdxB {
GX_CP_MTXIDXB_TEX4_ST = 26,
GX_CP_MTXIDXB_TEX4_END = 31,
GX_CP_MTXIDXB_TEX5_ST = 20,
GX_CP_MTXIDXB_TEX5_END = 25,
GX_CP_MTXIDXB_TEX6_ST = 14,
GX_CP_MTXIDXB_TEX6_END = 19,
GX_CP_MTXIDXB_TEX7_ST = 8,
GX_CP_MTXIDXB_TEX7_END = 13,
} GXCPMtxIdxB;
typedef enum _GXCPVCDLo {
GX_CP_VCD_LO_POSMTXIDX_ST = 31,
GX_CP_VCD_LO_POSMTXIDX_END = 31,
GX_CP_VCD_LO_TEX0MTXIDX_ST = 30,
GX_CP_VCD_LO_TEX0MTXIDX_END = 30,
GX_CP_VCD_LO_TEX1MTXIDX_ST = 29,
GX_CP_VCD_LO_TEX1MTXIDX_END = 29,
GX_CP_VCD_LO_TEX2MTXIDX_ST = 28,
GX_CP_VCD_LO_TEX2MTXIDX_END = 28,
GX_CP_VCD_LO_TEX3MTXIDX_ST = 27,
GX_CP_VCD_LO_TEX3MTXIDX_END = 27,
GX_CP_VCD_LO_TEX4MTXIDX_ST = 26,
GX_CP_VCD_LO_TEX4MTXIDX_END = 26,
GX_CP_VCD_LO_TEX5MTXIDX_ST = 25,
GX_CP_VCD_LO_TEX5MTXIDX_END = 25,
GX_CP_VCD_LO_TEX6MTXIDX_ST = 24,
GX_CP_VCD_LO_TEX6MTXIDX_END = 24,
GX_CP_VCD_LO_TEX7MTXIDX_ST = 23,
GX_CP_VCD_LO_TEX7MTXIDX_END = 23,
GX_CP_VCD_LO_POS_ST = 21,
GX_CP_VCD_LO_POS_END = 22,
GX_CP_VCD_LO_NRM_ST = 19,
GX_CP_VCD_LO_NRM_END = 20,
GX_CP_VCD_LO_CLRDIF_ST = 17,
GX_CP_VCD_LO_CLRDIF_END = 18,
GX_CP_VCD_LO_CLRSPEC_ST = 15,
GX_CP_VCD_LO_CLRSPEC_END = 16,
} GXCPVCDLo;
typedef enum _GXCPVCDHi {
GX_CP_VCD_HI_TEX0COORD_ST = 30,
GX_CP_VCD_HI_TEX0COORD_END = 31,
GX_CP_VCD_HI_TEX1COORD_ST = 28,
GX_CP_VCD_HI_TEX1COORD_END = 29,
GX_CP_VCD_HI_TEX2COORD_ST = 26,
GX_CP_VCD_HI_TEX2COORD_END = 27,
GX_CP_VCD_HI_TEX3COORD_ST = 24,
GX_CP_VCD_HI_TEX3COORD_END = 25,
GX_CP_VCD_HI_TEX4COORD_ST = 22,
GX_CP_VCD_HI_TEX4COORD_END = 23,
GX_CP_VCD_HI_TEX5COORD_ST = 20,
GX_CP_VCD_HI_TEX5COORD_END = 21,
GX_CP_VCD_HI_TEX6COORD_ST = 18,
GX_CP_VCD_HI_TEX6COORD_END = 19,
GX_CP_VCD_HI_TEX7COORD_ST = 16,
GX_CP_VCD_HI_TEX7COORD_END = 17,
} GXCPVCDHi;
typedef enum _GXCPVATGrp0 {
GX_CP_VAT_GRP0_POS_CNT_ST = 31,
GX_CP_VAT_GRP0_POS_CNT_END = 31,
GX_CP_VAT_GRP0_POS_TYPE_ST = 28,
GX_CP_VAT_GRP0_POS_TYPE_END = 30,
GX_CP_VAT_GRP0_POS_SHIFT_ST = 23,
GX_CP_VAT_GRP0_POS_SHIFT_END = 27,
GX_CP_VAT_GRP0_NRM_CNT_ST = 22,
GX_CP_VAT_GRP0_NRM_CNT_END = 22,
GX_CP_VAT_GRP0_NRM_TYPE_ST = 19,
GX_CP_VAT_GRP0_NRM_TYPE_END = 21,
GX_CP_VAT_GRP0_CLRDIFF_CNT_ST = 18,
GX_CP_VAT_GRP0_CLRDIFF_CNT_END = 18,
GX_CP_VAT_GRP0_CLRDIFF_TYPE_ST = 15,
GX_CP_VAT_GRP0_CLRDIFF_TYPE_END = 17,
GX_CP_VAT_GRP0_CLRSPEC_CNT_ST = 14,
GX_CP_VAT_GRP0_CLRSPEC_CNT_END = 14,
GX_CP_VAT_GRP0_CLRSPEC_TYPE_ST = 11,
GX_CP_VAT_GRP0_CLRSPEC_TYPE_END = 13,
GX_CP_VAT_GRP0_TXC0_CNT_ST = 10,
GX_CP_VAT_GRP0_TXC0_CNT_END = 10,
GX_CP_VAT_GRP0_TXC0_TYPE_ST = 7,
GX_CP_VAT_GRP0_TXC0_TYPE_END = 9,
GX_CP_VAT_GRP0_TXC0_SHIFT_ST = 2,
GX_CP_VAT_GRP0_TXC0_SHIFT_END = 6,
GX_CP_VAT_GRP0_BYTEDEQ_ST = 1,
GX_CP_VAT_GRP0_BYTEDEQ_END = 1,
GX_CP_VAT_GRP0_NRMIDX3_ST = 0,
GX_CP_VAT_GRP0_NRMIDX3_END = 0,
} GXCPVATGrp0;
typedef enum _GXCPVATGrp1 {
GX_CP_VAT_GRP1_TXC1_CNT_ST = 31,
GX_CP_VAT_GRP1_TXC1_CNT_END = 31,
GX_CP_VAT_GRP1_TXC1_TYPE_ST = 28,
GX_CP_VAT_GRP1_TXC1_TYPE_END = 30,
GX_CP_VAT_GRP1_TXC1_SHIFT_ST = 23,
GX_CP_VAT_GRP1_TXC1_SHIFT_END = 27,
GX_CP_VAT_GRP1_TXC2_CNT_ST = 22,
GX_CP_VAT_GRP1_TXC2_CNT_END = 22,
GX_CP_VAT_GRP1_TXC2_TYPE_ST = 19,
GX_CP_VAT_GRP1_TXC2_TYPE_END = 21,
GX_CP_VAT_GRP1_TXC2_SHIFT_ST = 14,
GX_CP_VAT_GRP1_TXC2_SHIFT_END = 18,
GX_CP_VAT_GRP1_TXC3_CNT_ST = 13,
GX_CP_VAT_GRP1_TXC3_CNT_END = 13,
GX_CP_VAT_GRP1_TXC3_TYPE_ST = 10,
GX_CP_VAT_GRP1_TXC3_TYPE_END = 12,
GX_CP_VAT_GRP1_TXC3_SHIFT_ST = 5,
GX_CP_VAT_GRP1_TXC3_SHIFT_END = 9,
GX_CP_VAT_GRP1_TXC4_CNT_ST = 4,
GX_CP_VAT_GRP1_TXC4_CNT_END = 4,
GX_CP_VAT_GRP1_TXC4_TYPE_ST = 1,
GX_CP_VAT_GRP1_TXC4_TYPE_END = 3,
} GXCPVATGrp1;
typedef enum _GXCPVATGrp2 {
GX_CP_VAT_GRP2_TXC4_SHIFT_ST = 27,
GX_CP_VAT_GRP2_TXC4_SHIFT_END = 31,
GX_CP_VAT_GRP2_TXC5_CNT_ST = 26,
GX_CP_VAT_GRP2_TXC5_CNT_END = 26,
GX_CP_VAT_GRP2_TXC5_TYPE_ST = 23,
GX_CP_VAT_GRP2_TXC5_TYPE_END = 25,
GX_CP_VAT_GRP2_TXC5_SHIFT_ST = 18,
GX_CP_VAT_GRP2_TXC5_SHIFT_END = 22,
GX_CP_VAT_GRP2_TXC6_CNT_ST = 17,
GX_CP_VAT_GRP2_TXC6_CNT_END = 17,
GX_CP_VAT_GRP2_TXC6_TYPE_ST = 14,
GX_CP_VAT_GRP2_TXC6_TYPE_END = 16,
GX_CP_VAT_GRP2_TXC6_SHIFT_ST = 9,
GX_CP_VAT_GRP2_TXC6_SHIFT_END = 13,
GX_CP_VAT_GRP2_TXC7_CNT_ST = 8,
GX_CP_VAT_GRP2_TXC7_CNT_END = 8,
GX_CP_VAT_GRP2_TXC7_TYPE_ST = 5,
GX_CP_VAT_GRP2_TXC7_TYPE_END = 7,
GX_CP_VAT_GRP2_TXC7_SHIFT_ST = 0,
GX_CP_VAT_GRP2_TXC7_SHIFT_END = 4,
} GXCPVATGrp2;
typedef enum _GXCPArrayBase {
GX_CP_ARRAYBASE_BASE_ST = 6,
GX_CP_ARRAYBASE_BASE_END = 31,
} GXCPArrayBase;
typedef enum _GXCPArrayStride {
GX_CP_ARRAYSTRIDE_STRIDE_ST = 24,
GX_CP_ARRAYSTRIDE_STRIDE_END = 31,
} GXCPArrayStride;
typedef enum _GXXFClipDisable {
GX_XF_CLIPDISABLE_DETECT_ST = 31,
GX_XF_CLIPDISABLE_DETECT_END = 31,
GX_XF_CLIPDISABLE_REJECT_ST = 30,
GX_XF_CLIPDISABLE_REJECT_END = 30,
GX_XF_CLIPDISABLE_ACCEL_ST = 29,
GX_XF_CLIPDISABLE_ACCEL_END = 29,
} GXXFClipDisable;
typedef enum _GXXFInVertexSpec {
GX_XF_INVERTEXSPEC_CLR_ST = 30,
GX_XF_INVERTEXSPEC_CLR_END = 31,
GX_XF_INVERTEXSPEC_NRM_ST = 28,
GX_XF_INVERTEXSPEC_NRM_END = 29,
GX_XF_INVERTEXSPEC_TEX_ST = 24,
GX_XF_INVERTEXSPEC_TEX_END = 27,
} GXXFInVertexSpec;
typedef enum _GXXFClr0Ctrl {
GX_XF_CLR0CTRL_MTXSRC_ST = 31,
GX_XF_CLR0CTRL_MTXSRC_END = 31,
GX_XF_CLR0CTRL_LIGHT_ST = 30,
GX_XF_CLR0CTRL_LIGHT_END = 30,
GX_XF_CLR0CTRL_LMASKHI_ST = 26,
GX_XF_CLR0CTRL_LMASKHI_END = 29,
GX_XF_CLR0CTRL_AMBSRC_ST = 25,
GX_XF_CLR0CTRL_AMBSRC_END = 25,
GX_XF_CLR0CTRL_DIFATTN_ST = 23,
GX_XF_CLR0CTRL_DIFATTN_END = 24,
GX_XF_CLR0CTRL_ATTNENABLE_ST = 22,
GX_XF_CLR0CTRL_ATTNENABLE_END = 22,
GX_XF_CLR0CTRL_ATTNSEL_ST = 21,
GX_XF_CLR0CTRL_ATTNSEL_END = 21,
GX_XF_CLR0CTRL_LMASKLO_ST = 17,
GX_XF_CLR0CTRL_LMASKLO_END = 20,
} GXXFClr0Ctrl;
typedef enum _GXXFMtxIdx0 {
GX_XF_MTXIDX0_GEOM_ST = 26,
GX_XF_MTXIDX0_GEOM_END = 31,
GX_XF_MTXIDX0_TEX0_ST = 20,
GX_XF_MTXIDX0_TEX0_END = 25,
GX_XF_MTXIDX0_TEX1_ST = 14,
GX_XF_MTXIDX0_TEX1_END = 19,
GX_XF_MTXIDX0_TEX2_ST = 8,
GX_XF_MTXIDX0_TEX2_END = 13,
GX_XF_MTXIDX0_TEX3_ST = 2,
GX_XF_MTXIDX0_TEX3_END = 7,
} GXXFMtxIdx0;
typedef enum _GXXFMtxIdx1 {
GX_XF_MTXIDX1_TEX4_ST = 26,
GX_XF_MTXIDX1_TEX4_END = 31,
GX_XF_MTXIDX1_TEX5_ST = 20,
GX_XF_MTXIDX1_TEX5_END = 25,
GX_XF_MTXIDX1_TEX6_ST = 14,
GX_XF_MTXIDX1_TEX6_END = 19,
GX_XF_MTXIDX1_TEX7_ST = 8,
GX_XF_MTXIDX1_TEX7_END = 13,
} GXXFMtxIdx1;
typedef enum _GXXFTex {
GX_XF_TEX_PROJTYPE_ST = 30,
GX_XF_TEX_PROJTYPE_END = 30,
GX_XF_TEX_INPUTFORM_ST = 29,
GX_XF_TEX_INPUTFORM_END = 29,
GX_XF_TEX_TEXGENTYPE_ST = 25,
GX_XF_TEX_TEXGENTYPE_END = 27,
GX_XF_TEX_SRCROW_ST = 20,
GX_XF_TEX_SRCROW_END = 24,
GX_XF_TEX_BUMPSRCTEX_ST = 17,
GX_XF_TEX_BUMPSRCTEX_END = 19,
GX_XF_TEX_BUMPSRCLIGHT_ST = 14,
GX_XF_TEX_BUMPSRCLIGHT_END = 16,
} GXXFTex;
typedef enum _GXXFDualTex {
GX_XF_DUALTEX_BASEROW_ST = 26,
GX_XF_DUALTEX_BASEROW_END = 31,
GX_XF_DUALTEX_NORMALISE_ST = 23,
GX_XF_DUALTEX_NORMALISE_END = 23,
} GXXFDualTex;
}
extern "C"{
typedef void (*VIRetraceCallback)(u32 retraceCount);
typedef void (*VIPositionCallback)(s16 x, s16 y);
typedef enum {
VI_TVMODE_NTSC_INT = ((((0)) << 2) + ((0))) ,
VI_TVMODE_NTSC_DS = ((((0)) << 2) + ((1))) ,
VI_TVMODE_NTSC_PROG = ((((0)) << 2) + ((2))) ,
VI_TVMODE_NTSC_3D = ((((0)) << 2) + ((3))) ,
VI_TVMODE_PAL_INT = ((((1)) << 2) + ((0))) ,
VI_TVMODE_PAL_DS = ((((1)) << 2) + ((1))) ,
VI_TVMODE_MPAL_INT = ((((2)) << 2) + ((0))) ,
VI_TVMODE_MPAL_DS = ((((2)) << 2) + ((1))) ,
VI_TVMODE_DEBUG_INT = ((((3)) << 2) + ((0))) ,
VI_TVMODE_DEBUG_PAL_INT = ((((4)) << 2) + ((0))) ,
VI_TVMODE_DEBUG_PAL_DS = ((((4)) << 2) + ((1))) ,
VI_TVMODE_EURGB60_INT = ((((5)) << 2) + ((0))) ,
VI_TVMODE_EURGB60_DS = ((((5)) << 2) + ((1))) ,
VI_TVMODE_GCA_INT = ((((6)) << 2) + ((0))) ,
VI_TVMODE_GCA_DS = ((((6)) << 2) + ((1))) ,
VI_TVMODE_GCA_PROG = ((((6)) << 2) + ((2))) ,
} VITVMode;
typedef enum {
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF = 1,
} VIXFBMode;
typedef struct VITimingInfo {
u8 equ;
u16 acv;
u16 prbOdd;
u16 prbEven;
u16 psbOdd;
u16 psbEven;
u8 bs1;
u8 bs2;
u8 bs3;
u8 bs4;
u16 be1;
u16 be2;
u16 be3;
u16 be4;
u16 numHalfLines;
u16 hlw;
u8 hsy;
u8 hcs;
u8 hce;
u8 hbe640;
u16 hbs640;
u8 hbeCCIR656;
u16 hbsCCIR656;
} VITimingInfo;
typedef struct VIPositionInfo {
u16 dispPosX;
u16 dispPosY;
u16 dispSizeX;
u16 dispSizeY;
u16 adjDispPosX;
u16 adjDispPosY;
u16 adjDispSizeY;
u16 adjPanPosY;
u16 adjPanSizeY;
u16 fbSizeX;
u16 fbSizeY;
u16 panPosX;
u16 panPosY;
u16 panSizeX;
u16 panSizeY;
VIXFBMode xfbMode;
u32 nonInter;
u32 tv;
u8 wordPerLine;
u8 std;
u8 wpl;
u32 bufAddr;
u32 tfbb;
u32 bfbb;
u8 xof;
BOOL isBlack;
BOOL is3D;
u32 rbufAddr;
u32 rtfbb;
u32 rbfbb;
VITimingInfo* timing;
} VIPositionInfo;
}
extern "C"{
typedef struct _GXColor {
u8 r, g, b, a;
} GXColor;
typedef struct _GXColorS10 {
s16 r, g, b, a;
} GXColorS10;
typedef struct _GXTexObj {
u8 pad[0x20];
} GXTexObj;
typedef struct _GXTexObjPriv {
u32 mode0;
u32 mode1;
u32 image0;
u32 image3;
void* userData;
GXTexFmt format;
u32 tlutName;
u16 loadCount;
u8 loadFormat;
u8 flags;
} GXTexObjPriv;
typedef struct _GXTexRegion {
u8 padding[0x10];
} GXTexRegion;
typedef struct _GXTexRegionPriv {
u32 image1;
u32 image2;
u16 sizeEven;
u16 sizeOdd;
u8 is32bMipmap;
u8 isCached;
} GXTexRegionPriv;
typedef struct _GXTlutObj {
u8 padding[0xc];
} GXTlutObj;
typedef struct _GXTlutObjPriv {
u32 tlut;
u32 loadTlut0;
u16 numEntries;
u8 padding[0x2];
} GXTlutObjPriv;
typedef struct _GXTlutRegion {
u8 padding[0x10];
} GXTlutRegion;
typedef struct _GXTlutRegionPriv {
u32 loadTlut1;
GXTlutObjPriv tlutObj;
} GXTlutRegionPriv;
typedef struct _GXLightObj {
u8 padding[0x40];
} GXLightObj;
typedef struct __GXLightObjPriv {
u32 reserved[3];
GXColor color;
f32 a[3];
f32 k[3];
f32 lpos[3];
f32 ldir[3];
} GXLightObjPriv;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt count;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXFogAdjTable {
u16 fogVals[10];
} GXFogAdjTable;
}
extern "C"{
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(GXVtxDescList* attrPtr);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetVtxAttrFmtv(GXVtxFmt vtxfmt, GXVtxAttrFmtList* list);
void GXSetArray(GXAttr attr, void* base_ptr, u8 stride);
void GXInvalidateVtxCache(void);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx, GXBool normalize, u32 pt_texmtx);
void GXSetNumTexGens(u8 nTexGens);
void __GXSetVCD(void);
void __GXSetVAT(void);
void GXGetVtxDesc(GXAttr attr, GXAttrType* type);
void GXGetVtxDescv(GXVtxDescList* vcd);
void GXGetVtxAttrFmt(GXVtxFmt fmt, GXAttr attr, GXCompCnt* cnt, GXCompType* type, u8* frac);
void GXGetVtxAttrFmtv(GXVtxFmt fmt, GXVtxAttrFmtList* vat);
}
extern "C"{
extern void __GXFlushTextureState();
extern void GXSetTevIndirect(GXTevStageID tevStage, GXIndTexStageID indStage, GXIndTexFormat format, GXIndTexBiasSel bias,
GXIndTexMtxID mtx, GXIndTexWrap sWrap, GXIndTexWrap tWrap, GXBool doAddPrev, GXBool isIndLOD,
GXIndTexAlphaSel alpha);
extern void GXSetIndTexMtx(GXIndTexMtxID mtx, const Mtx23 offsets, s8 scale);
extern void GXSetIndTexCoordScale(GXIndTexStageID stage, GXIndTexScale sScale, GXIndTexScale tScale);
extern void GXSetIndTexOrder(GXIndTexStageID stage, GXTexCoordID texCoord, GXTexMapID texMap);
extern void GXSetNumIndStages(u8 stageCount);
extern void __GXSetIndirectMask(u32 mask);
extern void GXSetTevDirect(GXTevStageID stage);
extern void GXSetTevIndWarp(GXTevStageID tevStage, GXIndTexStageID indStage, GXBool isSignedOffset, GXBool isReplaceMode,
GXIndTexMtxID mtx);
extern void GXSetTevIndTile(GXTevStageID tevStage, GXIndTexStageID indStage, u16 sTileSize, u16 tTileSize, u16 sTileSpacing,
u16 tTileSpacing, GXIndTexFormat format, GXIndTexMtxID mtx, GXIndTexBiasSel bias, GXIndTexAlphaSel alpha);
extern void GXSetTevIndBumpST(GXTevStageID tevStage, GXIndTexStageID indStage, GXIndTexMtxID mtx);
extern void GXSetTevIndBumpXYZ(GXTevStageID tevStage, GXIndTexStageID indStage, GXIndTexMtxID mtx);
extern void GXSetTevIndRepeat(GXTevStageID stage);
void __GXUpdateBPMask(void);
}
extern "C"{
typedef struct _GXFifoObj {
u8 padding[(128) ];
} GXFifoObj;
typedef struct __GXFifoObj {
u8* base;
u8* top;
u32 size;
u32 hiWatermark;
u32 loWatermark;
void* rdPtr;
void* wrPtr;
s32 count;
u8 bind_cpu;
u8 bind_gp;
} __GXFifoObj;
typedef struct _GXFifoObjPriv {
void* base;
void* end;
u32 size;
u32 highWatermark;
u32 lowWatermark;
void* readPtr;
void* writePtr;
s32 rwDistance;
u8 _20[0x60];
} GXFifoObjPriv;
typedef void (*GXBreakPtCallback)(void);
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
extern volatile PPCWGPipe GXWGFifo : (0xCC008000) ;
static inline void GXPosition2f32(const f32 x, const f32 y)
{
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
}
static inline void GXPosition3s16(const s16 x, const s16 y, const s16 z)
{
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXPosition3u16(const u16 x, const u16 y, const u16 z)
{
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
GXWGFifo.u16 = z;
}
static inline void GXPosition3f32(f32 x, f32 y, f32 z)
{
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXNormal3f32(const f32 x, const f32 y, const f32 z)
{
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXColor1u32(u32 c)
{
GXWGFifo.u32 = c;
}
static inline void GXColor4u8(const u8 r, const u8 g, const u8 b, const u8 a)
{
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
GXWGFifo.u8 = a;
}
static inline void GXTexCoord2s8(const s8 u, const s8 v)
{
GXWGFifo.s8 = u;
GXWGFifo.s8 = v;
}
static inline void GXTexCoord2u8(u8 s, u8 t)
{
GXWGFifo.u8 = s;
GXWGFifo.u8 = t;
}
static inline void GXPosition2u16(u16 x, u16 y)
{
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
}
static inline void GXPosition2s16(s16 x, s16 y)
{
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
}
static inline void GXTexCoord2s16(const s16 u, const s16 v)
{
GXWGFifo.s16 = u;
GXWGFifo.s16 = v;
}
static inline void GXTexCoord2u16(const u16 u, const u16 v)
{
GXWGFifo.u16 = u;
GXWGFifo.u16 = v;
}
static inline void GXTexCoord2f32(const f32 u, const f32 v)
{
GXWGFifo.f32 = u;
GXWGFifo.f32 = v;
}
static inline void GXEnd(void)
{
}
extern void __GXFifoInit();
extern void GXInitFifoBase(GXFifoObj* obj, void* base, u32 size);
extern void GXInitFifoPtrs(GXFifoObj* obj, void* readPtr, void* writePtr);
extern void GXInitFifoLimits(GXFifoObj* obj, u32 hiWaterMark, u32 loWaterMark);
extern void GXSetCPUFifo(GXFifoObj* obj);
extern void GXSetGPFifo(GXFifoObj* obj);
extern void GXSaveCPUFifo(GXFifoObj* obj);
extern void GXGetGPStatus(GXBool* isOverHi, GXBool* isUnderLo, GXBool* isReadIdle, GXBool* isCmdIdle, GXBool* isHitBrkPt);
extern GXFifoObj* GXGetCPUFifo();
extern GXFifoObj* GXGetGPFifo();
extern void GXBeginDisplayList(void* list, u32 size);
extern u32 GXEndDisplayList();
extern void GXCallDisplayList(void* list, u32 numBytes);
extern GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback callback);
void __GXSaveCPUFifoAux(__GXFifoObj* obj);
void __GXFifoReadEnable();
void __GXFifoReadDisable();
void __GXFifoLink(u8);
void __GXWriteFifoIntEnable(u8, u8);
void __GXWriteFifoIntReset(u8, u8);
void __GXCleanGPFifo(void);
extern void GXSaveGPFifo(GXFifoObj* obj);
extern void GXGetFifoStatus(GXFifoObj* obj, GXBool* isOverHi, GXBool* isUnderLo, u32* fifoCount, GXBool* isCpuWrite, GXBool* isGPRead,
GXBool* isFifoWrap);
extern void GXGetFifoPtrs(GXFifoObj* obj, void** readPtr, void** writePtr);
extern void* GXGetFifoBase(GXFifoObj* obj);
extern u32 GXGetFifoSize(GXFifoObj* obj);
extern void GXGetFifoLimits(GXFifoObj* obj, u32* hi, u32* lo);
extern void GXEnableBreakPt(void* breakPtr);
extern void GXDisableBreakPt();
}
extern "C"{
typedef GXTexRegion* (*GXTexRegionCallback)(GXTexObj* t_obj, GXTexMapID id);
typedef GXTlutRegion* (*GXTlutRegionCallback)(u32 idx);
extern void GXInitTexObj(GXTexObj* obj, void* imagePtr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode sWrap, GXTexWrapMode tWrap,
GXBool useMIPmap);
extern void GXInitTexObjCI(GXTexObj* obj, void* imagePtr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode sWrap,
GXTexWrapMode tWrap, GXBool useMIPmap, u32 tlutName);
extern void GXInitTexObjLOD(GXTexObj* obj, GXTexFilter minFilter, GXTexFilter maxFilter, f32 minLOD, f32 maxLOD, f32 lodBias,
GXBool doBiasClamp, GXBool doEdgeLOD, GXAnisotropy maxAniso);
extern GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
extern GXBool GXGetTexObjMipMap(const GXTexObj* obj);
extern u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, GXBool mipmap, u8 max_lod);
extern void GXLoadTexObjPreLoaded(GXTexObj* obj, GXTexRegion* region, GXTexMapID map);
extern void GXLoadTexObj(GXTexObj* obj, GXTexMapID map);
extern void GXInitTlutObj(GXTlutObj* obj, void* table, GXTlutFmt format, u16 numEntries);
extern void GXLoadTlut(GXTlutObj* obj, u32 tlutName);
extern void GXInitTexCacheRegion(GXTexRegion* region, GXBool is32bMIPmap, u32 memEven, GXTexCacheSize sizeEven, u32 memOdd,
GXTexCacheSize sizeOdd);
extern void GXInitTlutRegion(GXTlutRegion* region, u32 memAddr, GXTlutSize tlutSize);
extern void GXInvalidateTexAll();
extern GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback func);
extern GXTlutRegionCallback GXSetTlutRegionCallback(GXTlutRegionCallback func);
extern void __GXSetSUTexRegs();
extern void __GXSetTmemConfig(u32 config);
extern void GXInitTexObjData(GXTexObj* obj, void* imagePtr);
extern void GXInitTexObjWrapMode(GXTexObj* obj, GXTexWrapMode sWrap, GXTexWrapMode tWrap);
extern void GXInitTexObjTlut(GXTexObj* obj, u32 tlutName);
extern void __GetImageTileCount(GXTexFmt format, u16 width, u16 height, u32* a, u32* b, u32* c);
}
extern "C"{
typedef struct OSContext {
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
f64 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
void OSLoadContext(OSContext* context);
void OSClearContext(OSContext* context);
void OSInitContext(OSContext* context, u32 pc, u32 stackPtr);
void OSDumpContext(OSContext* context);
u32 OSSaveContext(OSContext* context);
u32 OSGetStackPointer();
OSContext* OSGetCurrentContext();
void OSSetCurrentContext(OSContext* context);
void OSSaveFPUContext(OSContext* context);
void OSFillFPUContext(OSContext* context);
u32 OSSwitchStack(u32 newStackPtr);
int OSSwitchFiber(u32 pc, u32 newStackPtr);
void OSLoadFPUContext(OSContext* context);
}
extern "C"{
}
extern "C"{
typedef s64 OSTime;
typedef u32 OSTick;
extern u32 __OSBusClock : ((0x80000000) | 0x00F8) ;
extern u32 __OSCoreClock : ((0x80000000) | 0x00FC) ;
OSTime __OSGetSystemTime();
OSTick OSGetTick();
OSTime OSGetTime();
typedef struct OSCalendarTime {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* timeDate);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* timeDate);
}
extern "C"{
typedef struct OSAlarm OSAlarm;
typedef struct OSAlarmQueue OSAlarmQueue;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm {
OSAlarmHandler handler;
u32 tag;
OSTime fire;
OSAlarm* prev;
OSAlarm* next;
OSTime period;
OSTime start;
};
struct OSAlarmQueue {
OSAlarm* head;
OSAlarm* tail;
};
void OSInitAlarm();
void OSSetAlarm(OSAlarm* alarm, OSTime tick, OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm* alarm);
void OSCancelAlarm(OSAlarm* alarm);
BOOL OSCheckAlarmQueue();
void OSSetAbsAlarm(OSAlarm* alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm* alarm, OSTime start, OSTime period, OSAlarmHandler handler);
void OSSetAlarmTag(OSAlarm* alarm, u32 tag);
void OSCancelAlarms(u32 tag);
}
extern "C"{
typedef int OSHeapHandle;
typedef void (*OSAllocVisitor)(void* obj, u32 size);
extern volatile OSHeapHandle __OSCurrHeap;
void* OSInitAlloc(void* arenaStart, void* arenaEnd, int maxHeaps);
OSHeapHandle OSCreateHeap(void* start, void* end);
OSHeapHandle OSSetCurrentHeap(OSHeapHandle heap);
void OSFreeToHeap(OSHeapHandle heap, void* ptr);
void* OSAllocFromHeap(OSHeapHandle heap, u32 size);
}
extern "C"{
void* OSGetArenaHi(void);
void* OSGetArenaLo(void);
void OSSetArenaHi(void* addr);
void OSSetArenaLo(void* addr);
}
extern "C"{
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef s32 OSPriority;
typedef void (*OSIdleFunction)(void* param);
typedef void* (*OSThreadStartFunction)(void*);
typedef void (*OSSwitchThreadCallback)(OSThread* from, OSThread* to);
struct OSThreadQueue {
OSThread* head;
OSThread* tail;
};
struct OSThreadLink {
OSThread* next;
OSThread* prev;
};
struct OSMutexQueue {
OSMutex* head;
OSMutex* tail;
};
struct OSMutexLink {
OSMutex* next;
OSMutex* prev;
};
struct OSThread {
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void* val;
OSThreadQueue* queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex* mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8* stackBase;
u32* stackEnd;
s32 error;
};
extern volatile OSContext* __OSCurrentContext : ((u32)((void*)((u32)(0x00D4) + (0x80000000)))) ;
extern volatile OSContext* __OSFPUContext : ((u32)((void*)((u32)(0x00D8) + (0x80000000)))) ;
extern OSThreadQueue __OSActiveThreadQueue : ((u32)((void*)((u32)(0x00DC) + (0x80000000)))) ;
extern OSThread* __OSCurrentThread : ((u32)((void*)((u32)(0x00E4) + (0x80000000)))) ;
void OSInitThreadQueue(OSThreadQueue* queue);
OSThread* OSGetCurrentThread();
BOOL OSIsThreadTerminated(OSThread* thread);
s32 OSDisableScheduler();
s32 OSEnableScheduler();
void OSYieldThread();
BOOL OSCreateThread(OSThread* thread, OSThreadStartFunction func, void* param, void* stack, u32 stackSize, OSPriority priority, u16 attr);
void OSExitThread(void* val);
void OSCancelThread(OSThread* thread);
void OSDetachThread(OSThread* thread);
s32 OSResumeThread(OSThread* thread);
s32 OSSuspendThread(OSThread* thread);
void OSSleepThread(OSThreadQueue* queue);
void OSWakeupThread(OSThreadQueue* queue);
void OSClearStack(u8 val);
OSPriority OSGetThreadPriority(OSThread* thread);
BOOL OSIsThreadSuspended(OSThread* thread);
BOOL OSJoinThread(OSThread* thread, void** val);
BOOL OSSetThreadPriority(OSThread* thread, OSPriority prio);
OSThread* OSSetIdleFunction(OSIdleFunction idleFunc, void* param, void* stack, u32 stackSize);
OSThread* OSGetIdleFunction();
s32 OSCheckActiveThreads();
void __OSReschedule(void);
OSPriority __OSGetEffectivePriority(OSThread* thread);
void __OSPromoteThread(OSThread* thread, OSPriority priority);
enum OS_THREAD_STATE {
OS_THREAD_STATE_NULL = 0,
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8,
};
}
extern "C"{
typedef struct DVDCommandBlock DVDCommandBlock;
typedef struct DVDFileInfo DVDFileInfo;
typedef void (*DVDCallback)(s32 result, DVDFileInfo* fileInfo);
typedef void (*DVDCBCallback)(s32 result, DVDCommandBlock* block);
typedef void (*DVDLowCallback)(u32 intType);
typedef void (*DVDDoneReadCallback)(s32, DVDFileInfo*);
typedef void (*DVDOptionalCommandChecker)(DVDCommandBlock* block, DVDLowCallback callback);
typedef struct DVDDriveInfo {
u16 revisionLevel;
u16 deviceCode;
u32 releaseDate;
u8 padding[24];
} DVDDriveInfo;
typedef struct DVDDiskID {
char gameName[4];
char company[2];
u8 diskNumber;
u8 gameVersion;
u8 streaming;
u8 streamBufSize;
u8 padding[22];
} DVDDiskID;
struct DVDCommandBlock {
DVDCommandBlock* next;
DVDCommandBlock* prev;
u32 command;
s32 state;
u32 offset;
u32 length;
void* addr;
u32 currTransferSize;
u32 transferredSize;
DVDDiskID* id;
DVDCBCallback callback;
void* userData;
};
struct DVDFileInfo {
DVDCommandBlock cBlock;
u32 startAddr;
u32 length;
DVDCallback callback;
};
typedef struct DVDDir {
u32 entryNum;
u32 location;
u32 next;
} DVDDir;
typedef struct DVDDirEntry {
u32 entryNum;
BOOL isDir;
const char* name;
} DVDDirEntry;
typedef struct DVDQueue DVDQueue;
struct DVDQueue {
DVDQueue* mHead;
DVDQueue* mTail;
};
typedef struct DVDBB1 {
u32 appLoaderLength;
void* appLoaderFunc1;
void* appLoaderFunc2;
void* appLoaderFunc3;
} DVDBB1;
typedef struct DVDBB2 {
u32 bootFilePosition;
u32 FSTPosition;
u32 FSTLength;
u32 FSTMaxLength;
void* FSTAddress;
u32 userPosition;
u32 userLength;
u32 reserved_1C;
} DVDBB2;
void DVDInit();
BOOL DVDOpen(const char* filename, DVDFileInfo* fileInfo);
BOOL DVDFastOpen(s32 entryNum, DVDFileInfo* fileInfo);
s32 DVDReadPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, s32 prio);
BOOL DVDReadAsyncPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, DVDCallback callback, s32 prio);
BOOL DVDReadAbsAsyncPrio(DVDCommandBlock* block, void* addr, s32 length, s32 offset, DVDCBCallback callback, s32 prio);
BOOL DVDClose(DVDFileInfo* fileInfo);
BOOL DVDPrepareStreamAsync(DVDFileInfo* fileInfo, u32 length, u32 offset, DVDCallback callback);
void DVDResume();
void DVDReset();
BOOL DVDCancelAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancel(DVDCommandBlock* block);
s32 DVDChangeDisk(DVDCommandBlock* block, DVDDiskID* id);
BOOL DVDChangeDiskAsync(DVDCommandBlock* block, DVDDiskID* id, DVDCBCallback callback);
s32 DVDGetCommandBlockStatus(const DVDCommandBlock* block);
s32 DVDGetDriveStatus();
BOOL DVDSetAutoInvalidation(BOOL doAutoInval);
void* DVDGetFSTLocation();
BOOL DVDOpenDir(const char* dirName, DVDDir* dir);
BOOL DVDReadDir(DVDDir* dir, DVDDirEntry* dirEntry);
BOOL DVDCloseDir(DVDDir* dir);
BOOL DVDGetCurrentDir(char* path, u32 maxLength);
BOOL DVDChangeDir(const char* dirName);
s32 DVDConvertPathToEntrynum(const char* path);
void __DVDLowSetWAType(u32 type, u32 location);
s32 DVDGetTransferredSize(DVDFileInfo* fileInfo);
DVDDiskID* DVDGetCurrentDiskID();
BOOL DVDCompareDiskID(DVDDiskID* id1, DVDDiskID* id2);
DVDLowCallback DVDLowClearCallback();
BOOL DVDCancelStreamAsync(DVDCommandBlock* block, DVDCBCallback callback);
BOOL DVDCancelStream(DVDCommandBlock* block);
BOOL DVDCheckDisk();
void DVDPause();
s32 DVDSeekPrio(DVDFileInfo* fileInfo, s32 offset, s32 prio);
BOOL DVDSeekAsyncPrio(DVDFileInfo* fileInfo, s32 offset, DVDCallback callback, s32 prio);
s32 DVDGetFileInfoStatus(DVDFileInfo* fileInfo);
BOOL DVDFastOpenDir(s32 entryNum, DVDDir* dir);
BOOL DVDCancelAllAsync(DVDCBCallback callback);
s32 DVDCancelAll();
void DVDDumpWaitingQueue();
void __DVDFSInit();
void __DVDClearWaitingQueue();
void __DVDInitWA(void);
void __fstLoad(void);
BOOL DVDLowRead(void* addr, u32 length, u32 offset, DVDLowCallback callback);
void __DVDStoreErrorCode(u32 error);
BOOL DVDLowStopMotor(DVDLowCallback callback);
BOOL DVDLowRequestError(DVDLowCallback callback);
BOOL DVDLowSeek(u32 offset, DVDLowCallback callback);
BOOL DVDLowAudioBufferConfig(BOOL enable, u32 size, DVDLowCallback callback);
BOOL DVDLowReadDiskID(DVDDiskID* diskID, DVDLowCallback callback);
BOOL DVDLowWaitCoverClose(DVDLowCallback callback);
BOOL __DVDCheckWaitingQueue();
BOOL DVDLowRequestAudioStatus(u32 subcmd, DVDLowCallback callback);
BOOL DVDLowAudioStream(u32 subcmd, u32 length, u32 offset, DVDLowCallback callback);
BOOL DVDLowInquiry(DVDDriveInfo* info, DVDLowCallback callback);
BOOL __DVDPushWaitingQueue(int idx, struct DVDQueue* newTail);
void DVDLowReset();
BOOL DVDLowBreak();
BOOL __DVDDequeueWaitingQueue(DVDQueue* queue);
BOOL DVDReadDiskID(DVDCommandBlock* block, DVDDiskID* diskID, DVDCBCallback callback);
void DVDSeekAbsAsyncPrio(DVDCommandBlock* block, void* addr, DVDCBCallback callback, s32 prio);
BOOL DVDPrepareStreamAbsAsync(DVDCommandBlock* block, u32 length, u32 offset, DVDCBCallback callback);
BOOL DVDReadAbsAsyncForBS(DVDCommandBlock* block, void* addr, s32 length, s32 offset, DVDCBCallback callback);
void __DVDPrepareResetAsync(DVDCBCallback callback);
extern OSThreadQueue __DVDThreadQueue;
}
extern "C"{
typedef struct OSBootInfo {
DVDDiskID DVDDiskID;
u32 magic;
u32 version;
u32 memorySize;
u32 consoleType;
void* arenaLo;
void* arenaHi;
void* FSTLocation;
u32 FSTMaxLength;
} OSBootInfo;
typedef struct BI2Debug {
int debugMonSize;
int simMemSize;
u32 argOffset;
u32 debugFlag;
int trackLocation;
int trackSize;
u32 countryCode;
u8 _1C[0x4];
u32 dvdLongFileNameFlag;
u32 padSpec;
} BI2Debug;
extern void* OS_BOOT_REGION_START : (0x812FDFF0) ;
extern void* OS_BOOT_REGION_END : (0x812FDFEC) ;
}
extern "C"{
void DCInvalidateRange(void* addr, u32 numBytes);
void DCFlushRange(void* addr, u32 numBytes);
void DCStoreRange(void* addr, u32 numBytes);
void DCFlushRangeNoSync(void* addr, u32 numBytes);
void DCStoreRangeNoSync(void* addr, u32 numBytes);
void DCZeroRange(void* addr, u32 numBytes);
void ICInvalidateRange(void* addr, u32 numBytes);
void ICFlashInvalidate();
void ICEnable();
void LCEnable();
void LCDisable();
void LCStoreBlocks(void* destAddr, void* srcTag, u32 numBlocks);
u32 LCStoreData(void* destAddr, void* srcAddr, u32 numBytes);
void LCQueueWait(u32 length);
void L2GlobalInvalidate();
void DCTouchRange(void* addr, u32 numBytes);
void ICSync();
void ICDisable();
void ICFreeze();
void ICUnfreeze();
void ICBlockInvalidate(void* addr);
void LCLoadBlocks(void* destTag, void* srcAddr, u32 numBlocks);
u32 LCLoadData(void* destAddr, void* srcAddr, u32 numBytes);
u32 LCQueueLength();
void LCFlushQueue();
void L2Enable();
void L2Disable();
void L2SetDataOnly(BOOL doDataOnly);
void L2SetWriteThrough(BOOL doWriteThrough);
}
extern "C"{
typedef u8 __OSException;
typedef void (*__OSExceptionHandler)(__OSException exception, OSContext* context);
__OSExceptionHandler __OSSetExceptionHandler(__OSException exception, __OSExceptionHandler handler);
__OSExceptionHandler __OSGetExceptionHandler(__OSException exception);
}
extern "C"{
typedef u16 OSError;
typedef void (*OSErrorHandler)(OSError error, OSContext* context, ...);
OSErrorHandler OSSetErrorHandler(OSError error, OSErrorHandler handler);
void __OSUnhandledException(__OSException exception, OSContext* context, u32 dsisr, u32 dar);
void OSReport(const char* message, ...);
void OSPanic(const char* file, int line, const char* message, ...);
extern OSErrorHandler __OSErrorTable[((15) + 1) ];
}
extern "C"{
typedef void (*EXICallback)(s32 channel, OSContext* context);
BOOL EXIProbe(s32 channel);
s32 EXIProbeEx(s32 channel);
s32 EXIGetType(s32 channel, u32 dev, u32* type);
char* EXIGetTypeString(u32 type);
u32 __OSGetDIConfig(void);
void __OSEnableBarnacle(s32 chan, u32 dev);
}
extern "C"{
void PPCSync(void);
void PPCEieio(void);
void PPCHalt(void);
u32 PPCMfmsr(void);
void PPCMtmsr(u32 value);
void PPCOrMsr(void);
void PPCAndMsr(void);
void PPCAndCMsr(void);
u32 PPCMfhid0(void);
void PPCMthid0(u32 value);
u32 PPCMfhid1(void);
u32 PPCMfhid2(void);
void PPCMthid2(u32 value);
u32 PPCMfl2cr(void);
void PPCMtl2cr(u32 value);
u32 PPCMfdec(void);
void PPCMtdec(u32 value);
u32 PPCMfmmcr0(void);
void PPCMtmmcr0(u32 value);
u32 PPCMfmmcr1(void);
void PPCMtmmcr1(u32 value);
u32 PPCMfpmc1(void);
void PPCMtpmc1(u32 value);
u32 PPCMfpmc2(void);
void PPCMtpmc2(u32 value);
u32 PPCMfpmc3(void);
void PPCMtpmc3(u32 value);
u32 PPCMfpmc4(void);
void PPCMtpmc4(u32 value);
u32 PPCMfsia(void);
void PPCMtsia(u32 value);
u32 PPCMfwpar(void);
void PPCMtwpar(u32 value);
u32 PPCMfdmaU(void);
void PPCMtdmaU(u32 value);
u32 PPCMfdmaL(void);
void PPCMtdmaL(u32 value);
u32 PPCMfpvr(void);
}
extern "C"{
static inline void OSInitFastCast(void)
{
asm {
li r3, (0x0004)
oris r3, r3, (0x0004)
mtspr 914 , r3
li r3, (0x0005)
oris r3, r3, (0x0005)
mtspr 915 , r3
li r3, (0x0006)
oris r3, r3, (0x0006)
mtspr 916 , r3
li r3, (0x0007)
oris r3, r3, (0x0007)
mtspr 917 , r3
}
}
static inline void OSf32tou8(register f32* in, register u8* out)
{
asm {
lfs f1, 0 (in)
psq_st f1, 0 (out), 1, (2)
}
}
static inline void OSf32tou16(register f32* in, register u16* out)
{
asm {
lfs f1, 0 (in)
psq_st f1, 0 (out), 1, (3)
}
}
static inline void OSf32tos8(register f32* in, register s8* out)
{
asm {
lfs fp1, 0 (in)
psq_st fp1, 0 (out), 1, (4)
}
}
static inline void OSf32tos16(register f32* in, register s16* out)
{
asm {
lfs fp1, 0 (in)
psq_st fp1, 0 (out), 1, (5)
}
}
static inline void OSu8tof32(register u8* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (2)
stfs fp1, 0 (out)
}
}
static inline void OSu16tof32(register u16* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (3)
stfs fp1, 0 (out)
}
}
static inline void OSs8tof32(register s8* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (4)
stfs fp1, 0 (out)
}
}
static inline void OSs16tof32(register s16* in, register f32* out)
{
asm {
psq_l fp1, 0 (in), 1, (5)
stfs fp1, 0 (out)
}
}
}
extern "C"{
typedef struct OSFontHeader {
u16 fontType;
u16 firstChar;
u16 lastChar;
u16 invalChar;
u16 ascent;
u16 descent;
u16 width;
u16 leading;
u16 cellWidth;
u16 cellHeight;
u32 sheetSize;
u16 sheetFormat;
u16 sheetColumn;
u16 sheetRow;
u16 sheetWidth;
u16 sheetHeight;
u16 widthTable;
u32 sheetImage;
u32 sheetFullSize;
u8 c0;
u8 c1;
u8 c2;
u8 c3;
} OSFontHeader;
u16 OSGetFontEncode();
char* OSGetFontWidth(const char* string, s32* width);
BOOL OSInitFont(OSFontHeader* fontInfo);
char* OSGetFontTexture(const char* string, void** image, s32* x, s32* y, s32* width);
u32 OSLoadFont(OSFontHeader* fontInfo, void* temp);
char* OSGetFontTexel(const char* string, void* image, s32 pos, s32 stride, s32* width);
typedef enum {
OS_FONT_ENCODE_ANSI,
OS_FONT_ENCODE_SJIS,
OS_FONT_ENCODE_2,
OS_FONT_ENCODE_UTF8,
OS_FONT_ENCODE_UTF16,
OS_FONT_ENCODE_UTF32,
OS_FONT_ENCODE_MAX,
} OSFontEncode;
}
extern "C"{
typedef s16 __OSInterrupt;
typedef void (*__OSInterruptHandler)(__OSInterrupt interrupt, OSContext* context);
typedef u32 OSInterruptMask;
extern volatile __OSInterrupt __OSLastInterrupt;
extern vu32 __OSLastInterruptSrr0;
extern volatile OSTime __OSLastInterruptTime;
extern volatile OSInterruptMask __OSPriorInterruptMask : ((u32)((void*)((u32)(0x00C4) + (0x80000000)))) ;
extern volatile OSInterruptMask __OSCurrentInterruptMask : ((u32)((void*)((u32)(0x00C8) + (0x80000000)))) ;
__OSInterruptHandler __OSSetInterruptHandler(__OSInterrupt interrupt, __OSInterruptHandler handler);
__OSInterruptHandler __OSGetInterruptHandler(__OSInterrupt interrupt);
void __OSDispatchInterrupt(__OSException exception, OSContext* context);
BOOL OSEnableInterrupts();
BOOL OSDisableInterrupts();
BOOL OSRestoreInterrupts(BOOL enabled);
OSInterruptMask __OSMaskInterrupts(OSInterruptMask mask);
OSInterruptMask __OSUnmaskInterrupts(OSInterruptMask mask);
OSInterruptMask OSGetInterruptMask();
OSInterruptMask OSSetInterruptMask(OSInterruptMask mask);
void __RAS_OSDisableInterrupts_begin();
void __RAS_OSDisableInterrupts_end();
}
extern "C"{
void OSProtectRange(u32 channel, void* addr, u32 numBytes, u32 control);
}
extern "C"{
typedef struct OSMesgQueue_s OSMesgQueue_s;
typedef struct OSMesgQueue_s OSMessageQueue;
typedef void* OSMessage;
struct OSMesgQueue_s {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
s32 msgCount;
s32 firstIndex;
s32 usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, s32 msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, s32 flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, s32 flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, s32 flags);
}
extern "C"{
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSModuleHeader OSModuleHeader;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
typedef u32 OSModuleID;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u32 prolog;
u32 epilog;
u32 unresolved;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
void OSSetStringTable(void* stringTable);
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* oldModule);
OSModuleInfo* OSSearchModule(void* ptr, u32* section, u32* offset);
}
extern "C"{
struct OSMutex {
OSThreadQueue queue;
OSThread* thread;
int count;
OSMutexLink link;
};
typedef struct OSCond {
OSThreadQueue queue;
} OSCond;
void OSInitMutex(OSMutex* mutex);
void OSLockMutex(OSMutex* mutex);
void OSUnlockMutex(OSMutex* mutex);
BOOL OSTryLockMutex(OSMutex* mutex);
void __OSUnlockAllMutex(OSThread* thread);
BOOL __OSCheckMutex(OSMutex* mutex);
BOOL __OSCheckDeadLock(OSThread* thread);
BOOL __OSCheckMutexes(OSThread* thread);
void OSInitCond(OSCond* cond);
void OSWaitCond(OSCond* cond, OSMutex* mutex);
void OSSignalCond(OSCond* cond);
}
extern "C"{
typedef struct OSResetFunctionInfo OSResetFunctionInfo;
typedef BOOL (*OSResetFunction)(BOOL final);
typedef void (*OSResetCallback)(void);
struct OSResetFunctionInfo {
OSResetFunction func;
u32 priority;
OSResetFunctionInfo* next;
OSResetFunctionInfo* prev;
};
typedef struct OSResetQueue {
OSResetFunctionInfo* head;
OSResetFunctionInfo* tail;
} OSResetQueue;
void OSRegisterResetFunction(OSResetFunctionInfo* info);
void OSResetSystem(int reset, u32 code, BOOL doForceMenu);
u32 OSGetResetCode();
void OSGetSaveRegion(void** start, void** end);
void OSSetSaveRegion(void* start, void* end);
BOOL OSGetResetButtonState();
BOOL OSGetResetSwitchState();
void __OSReboot(u32 resetCode, u32 bootDol);
void __OSDoHotReset(s32 code);
void OSSetSaveRegion(void* start, void* end);
void OSGetSaveRegion(void** start, void** end);
void OSGetSavedRegion(void** start, void** end);
void OSUnregisterResetFunction(OSResetFunctionInfo* info);
OSResetCallback OSSetResetCallback(OSResetCallback callback);
extern BOOL __OSIsGcam;
extern u32 OS_RESET_CODE : (0x800030F0) ;
extern volatile u8 OS_REBOOT_BOOL : (0x800030E2) ;
}
extern "C"{
typedef void (*SramCallback)(void);
typedef struct OSSram {
u16 checkSum;
u16 checkSumInv;
u32 ead0;
u32 ead1;
u32 counterBias;
s8 displayOffsetH;
u8 ntd;
u8 language;
u8 flags;
} OSSram;
typedef struct OSSramEx {
u8 flashID[2][12];
u32 wirelessKeyboardID;
u16 wirelessPadID[4];
u8 dvdErrorCode;
u8 reserved_25;
u8 flashIDCheckSum[2];
u16 gbs;
u8 reserved_2A[2];
} OSSramEx;
typedef struct SramControlBlock {
u8 sram[0x40];
u32 offset;
BOOL enabled;
BOOL locked;
BOOL sync;
SramCallback callback;
} SramControlBlock;
void __OSInitSram();
OSSram* __OSLockSram();
OSSramEx* __OSLockSramEx();
BOOL __OSUnlockSram(BOOL commit);
BOOL __OSUnlockSramEx(BOOL commit);
BOOL __OSSyncSram(void);
u32 OSGetSoundMode();
void OSSetSoundMode(u32 mode);
u32 OSGetProgressiveMode();
void OSSetProgressiveMode(u32 on);
u8 OSGetLanguage();
void OSSetLanguage(u8 language);
u32 OSGetEuRgb60Mode();
void OSSetEuRgb60Mode(u32 on);
void OSSetWirelessID(s32 channel, u16 id);
u16 OSGetWirelessID(s32 channel);
}
extern "C"{
extern void __OSPSInit();
extern void __OSFPRInit();
extern void __OSCacheInit();
extern void __OSContextInit();
extern void __OSInterruptInit();
extern void __OSThreadInit();
extern void __OSInitSystemCall();
extern void __OSModuleInit();
extern void __OSInitAudioSystem();
extern void __OSStopAudioSystem();
extern void __OSInitMemoryProtection();
void OSInit(void);
u32 OSGetConsoleType();
extern BOOL __OSInIPL;
extern OSTime __OSStartTime;
}
extern "C"{
typedef enum _CPStatus {
GX_FIFO_OVERFLOW = 0x1,
GX_FIFO_UNDERFLOW = 0x2,
GP_IS_IDLE_FOR_READING = 0x4,
GP_IS_IDLE_FOR_COMMANDS = 0x8,
BP_INTERRUPT = 0x10,
} CPStatus;
typedef enum _CPControl {
GP_FIFO_READ_ENABLE = 0x1,
CP_IRQ_ENABLE_MAYBE = 0x2,
FIFO_OVERFLOW_IRQ_ENABLE_MAYBE = 0x4,
FIFO_UNDERFLOW_IRQ_ENABLE_MAYBE = 0x8,
GP_LINK_ENABLE = 0x10,
BP_ENABLE = 0x20,
} CPControl;
typedef enum _CPClear {
CLEAR_FIFO_OVERFLOW = 0x1,
CLEAR_FIFO_UNDERFLOW = 0x2,
} CPClear;
struct __GXData_struct {
unsigned short vNum;
unsigned short bpSent;
unsigned long vLim;
unsigned long cpEnable;
unsigned long cpStatus;
unsigned long cpClr;
unsigned long vcdLo;
unsigned long vcdHi;
unsigned long vatA[8];
unsigned long vatB[8];
unsigned long vatC[8];
unsigned long lpSize;
unsigned long matIdxA;
unsigned long matIdxB;
unsigned long indexBase[4];
unsigned long indexStride[4];
unsigned long ambColor[2];
unsigned long matColor[2];
unsigned long suTs0[8];
unsigned long suTs1[8];
unsigned long suScis0;
unsigned long suScis1;
unsigned long tref[8];
unsigned long iref;
unsigned long bpMask;
unsigned long IndTexScale0;
unsigned long IndTexScale1;
unsigned long tevc[16];
unsigned long teva[16];
unsigned long tevKsel[8];
unsigned long cmode0;
unsigned long cmode1;
unsigned long zmode;
unsigned long peCtrl;
unsigned long cpDispSrc;
unsigned long cpDispSize;
unsigned long cpDispStride;
unsigned long cpDisp;
unsigned long cpTexSrc;
unsigned long cpTexSize;
unsigned long cpTexStride;
unsigned long cpTex;
unsigned char cpTexZ;
unsigned long genMode;
GXTexRegion TexRegions[8];
GXTexRegion TexRegionsCI[4];
unsigned long nextTexRgn;
unsigned long nextTexRgnCI;
GXTlutRegion TlutRegions[20];
GXTexRegion* (*texRegionCallback)(GXTexObj*, GXTexMapID);
GXTlutRegion* (*tlutRegionCallback)(unsigned long);
GXAttrType nrmType;
unsigned char hasNrms;
unsigned char hasBiNrms;
unsigned long projType;
float projMtx[6];
float vpLeft;
float vpTop;
float vpWd;
float vpHt;
float vpNearz;
float vpFarz;
unsigned char fgRange;
float fgSideX;
unsigned long tImage0[8];
unsigned long tMode0[8];
unsigned long texmapId[16];
unsigned long tcsManEnab;
GXPerf0 perf0;
GXPerf1 perf1;
unsigned long perfSel;
unsigned char inDispList;
unsigned char dlSaveContext;
unsigned char dirtyVAT;
unsigned long dirtyState;
};
extern struct __GXData_struct* gx;
extern vu16* __cpReg;
extern vu32* __piReg;
extern vu16* __memReg;
extern vu16* __peReg;
static inline u32 GXReadMEMReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __memReg[addrHi];
do {
hiNew = hiStart;
lo = __memReg[addrLo];
hiStart = __memReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
static inline u32 GXReadCPReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __cpReg[addrHi];
do {
hiNew = hiStart;
lo = __cpReg[addrLo];
hiStart = __cpReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
static inline u32 GXReadPEReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __peReg[addrHi];
do {
hiNew = hiStart;
lo = __peReg[addrLo];
hiStart = __peReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
static inline u32 GXReadPIReg(u32 addrLo, u32 addrHi)
{
u32 hiStart, hiNew, lo;
hiStart = __piReg[addrHi];
do {
hiNew = hiStart;
lo = __piReg[addrLo];
hiStart = __piReg[addrHi];
} while (hiStart != hiNew);
return ((hiStart << 16) | lo);
}
}
extern "C"{
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXMpal480Int;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
extern void GXSetDispCopySrc(u16 left, u16 top, u16 width, u16 height);
extern void GXSetTexCopySrc(u16 left, u16 top, u16 width, u16 height);
extern void GXSetDispCopyDst(u16 width, u16 height);
extern void GXSetTexCopyDst(u16 width, u16 height, GXTexFmt format, GXBool useMIPmap);
extern void GXSetDispCopyFrame2Field(GXCopyMode mode);
extern void GXSetCopyClamp(GXFBClamp clamp);
extern u32 GXSetDispCopyYScale(f32 vertScale);
extern void GXSetCopyClear(GXColor clearColor, u32 clearZ);
extern void GXSetCopyFilter(GXBool useAA, const u8 samplePattern[12][2], GXBool doVertFilt, const u8 vFilt[7]);
extern void GXSetDispCopyGamma(GXGamma gamma);
extern void GXCopyDisp(void* dest, GXBool doClear);
extern void GXCopyTex(void* dest, GXBool doClear);
extern u16 GXGetNumXfbLines(u16 efbHeight, f32 yScale);
extern f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
extern void GXClearBoundingBox();
extern void GXAdjustForOverscan(GXRenderModeObj* rIn, GXRenderModeObj* rOut, u16 horiz, u16 vert);
extern void GXReadBoundingBox(u16* left, u16* top, u16* right, u16* bottom);
}
extern "C"{
extern void __GXSetDirtyState();
extern void GXBegin(GXPrimitive type, GXVtxFmt format, u16 numVertices);
extern void __GXSendFlushPrim();
extern void GXSetVtxDesc(GXAttr attr, GXAttrType type);
extern void GXClearVtxDesc();
extern void GXSetVtxAttrFmt(GXVtxFmt format, GXAttr attr, GXCompCnt count, GXCompType type, u8 frac);
extern void GXSetVtxAttrFmtv(GXVtxFmt format, GXVtxAttrFmtList* list);
extern void GXSetArray(GXAttr attr, void* basePtr, u8 stride);
extern void GXInvalidateVtxCache();
extern void GXSetTexCoordGen2(GXTexCoordID coord, GXTexGenType genType, GXTexGenSrc srcParam, u32 mtx, GXBool doNormalise, u32 postMtx);
extern void GXSetNumTexGens(u8 count);
extern void GXSetLineWidth(u8 width, GXTexOffset offset);
extern void GXSetPointSize(u8 pointSize, GXTexOffset offset);
extern void GXEnableTexOffsets(GXTexCoordID coord, GXBool enableLine, GXBool enablePoint);
extern void __GXSetGenMode();
extern void GXSetCullMode(GXCullMode mode);
extern void GXSetCoPlanar(GXBool doEnable);
extern void GXGetLineWidth(u8* width, GXTexOffset* offset);
extern void GXGetPointSize(u8* pointSize, GXTexOffset* offset);
extern void GXGetCullMode(GXCullMode* mode);
}
extern "C"{
}
extern "C"{
extern void GXInitLightAttn(GXLightObj* obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
extern void GXInitLightSpot(GXLightObj* obj, f32 cutoff, GXSpotFn spotFunc);
extern void GXInitLightDistAttn(GXLightObj* obj, f32 refDist, f32 refBrightness, GXDistAttnFn distFunc);
extern void GXInitLightPos(GXLightObj* obj, f32 x, f32 y, f32 z);
extern void GXInitLightDir(GXLightObj* obj, f32 nX, f32 nY, f32 nZ);
extern void GXInitSpecularDir(GXLightObj* obj, f32 nX, f32 nY, f32 nZ);
extern void GXInitLightColor(GXLightObj* obj, GXColor color);
extern void GXLoadLightObjImm(GXLightObj* obj, GXLightID light);
extern void GXSetChanAmbColor(GXChannelID channel, GXColor color);
extern void GXSetChanMatColor(GXChannelID channel, GXColor color);
extern void GXSetNumChans(u8 count);
extern void GXSetChanCtrl(GXChannelID channel, GXBool doEnable, GXColorSrc ambSrc, GXColorSrc matSrc, u32 mask, GXDiffuseFn diffFunc,
GXAttnFn attnFunc);
extern void GXInitLightAttnA(GXLightObj* obj, f32 a0, f32 a1, f32 a2);
extern void GXGetLightAttnA(GXLightObj* obj, f32* a0, f32* a1, f32* a2);
extern void GXInitLightAttnK(GXLightObj* obj, f32 k0, f32 k1, f32 k2);
extern void GXGetLightAttnK(GXLightObj* obj, f32* k0, f32* k1, f32* k2);
extern void GXGetLightPos(GXLightObj* obj, f32* x, f32* y, f32* z);
extern void GXGetLightDir(GXLightObj* obj, f32* nX, f32* nY, f32* nZ);
extern void GXInitSpecularDirHA(GXLightObj* obj, f32 nX, f32 nY, f32 nZ, f32 hX, f32 hY, f32 hZ);
extern void GXGetLightColor(GXLightObj* obj, GXColor* color);
extern void GXLoadLightObjIndx(u32 objIndex, GXLightID light);
}
extern "C"{
typedef void (*GXDrawSyncCallback)(u16 token);
typedef void (*GXDrawDoneCallback)(void);
static GXTexRegion* __GXDefaultTexRegionCallback(GXTexObj* obj, GXTexMapID id);
static GXTlutRegion* __GXDefaultTlutRegionCallback(u32 tlut);
static BOOL __GXShutdown(BOOL final);
extern GXFifoObj* GXInit(void* base, u32 size);
extern void __GXInitGX();
extern void __GXPEInit();
extern void GXSetMisc(GXMiscToken token, u32 val);
extern void GXFlush();
extern void __GXAbort();
extern void GXAbortFrame();
extern void GXSetDrawSync(u16 token);
extern void GXSetDrawDone();
extern void GXWaitDrawDone();
extern void GXDrawDone();
extern void GXPixModeSync();
extern GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback callback);
extern GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback callback);
extern void GXPokeAlphaMode(GXCompare func, u8 threshold);
extern void GXPokeAlphaRead(GXAlphaReadMode mode);
extern void GXPokeAlphaUpdate(GXBool doUpdate);
extern void GXPokeBlendMode(GXBlendMode mode, GXBlendFactor srcFactor, GXBlendFactor destFactor, GXLogicOp op);
extern void GXPokeColorUpdate(GXBool doUpdate);
extern void GXPokeDstAlpha(GXBool doEnable, u8 alpha);
extern void GXPokeDither(GXBool doDither);
extern void GXPokeZMode(GXBool doCompare, GXCompare func, GXBool doUpdate);
extern void GXResetWriteGatherPipe();
extern u16 GXReadDrawSync();
extern void GXTexModeSync();
extern void GXPeekARGB(u16 x, u16 y, u32* color);
extern void GXPokeARGB(u16 x, u16 y, u32 color);
extern void GXPeekZ(u16 x, u16 y, u32* z);
extern void GXPokeZ(u16 x, u16 y, u32 z);
extern u32 GXCompressZ16(u32 z24, GXZFmt16 zFormat);
extern u32 GXDecompressZ16(u32 z16, GXZFmt16 zFormat);
struct OSThread* GXSetCurrentGXThread();
}
extern "C"{
extern void GXSetGPMetric(GXPerf0 perf0, GXPerf1 perf1);
extern void GXClearGPMetric();
extern void GXReadXfRasMetric(u32* xfWaitIn, u32* xfWaitOut, u32* rasBusy, u32* clocks);
extern void GXReadGPMetric(u32* count0, u32* count1);
extern u32 GXReadGP0Metric();
extern u32 GXReadGP1Metric();
extern void GXReadMemMetric(u32* cpReq, u32* tcReq, u32* cpuReadReq, u32* cpuWriteReq, u32* dspReq, u32* ioReq, u32* viReq, u32* peReq,
u32* rfReq, u32* fiReq);
extern void GXClearMemMetric();
extern void GXReadPixMetric(u32* topIn, u32* topOut, u32* bottomIn, u32* bottomOut, u32* clearIn, u32* copyClocks);
extern void GXClearPixMetric();
extern void GXSetVCacheMetric(GXVCachePerf attr);
extern void GXReadVCacheMetric(u32* check, u32* miss, u32* stall);
extern void GXClearVCacheMetric();
extern void GXInitXfRasMetric();
extern u32 GXReadClksPerVtx();
}
extern "C"{
extern void GXSetFog(GXFogType type, f32 startZ, f32 endZ, f32 nearZ, f32 farZ, GXColor color);
extern void GXInitFogAdjTable(GXFogAdjTable* table, u16 width, const Mtx44 projMtx);
extern void GXSetFogRangeAdj(GXBool doEnable, u16 center, GXFogAdjTable* table);
extern void GXSetBlendMode(GXBlendMode type, GXBlendFactor srcFactor, GXBlendFactor destFactor, GXLogicOp op);
extern void GXSetColorUpdate(GXBool enableUpdate);
extern void GXSetAlphaUpdate(GXBool enableUpdate);
extern void GXSetZMode(GXBool enableCompare, GXCompare func, GXBool enableUpdate);
extern void GXSetZCompLoc(GXBool isBeforeTex);
extern void GXSetPixelFmt(GXPixelFmt pixelFormat, GXZFmt16 zFormat);
extern void GXSetDither(GXBool doDither);
extern void GXSetDstAlpha(GXBool doEnable, u8 alpha);
extern void GXSetFieldMask(GXBool doOddMask, GXBool doEvenMask);
extern void GXSetFieldMode(GXBool doFieldMode, GXBool doHalfAspectRatio);
}
extern "C"{
void __GXSetRange(f32, f32);
}
extern "C"{
extern void GXSetTevOp(GXTevStageID stage, GXTevMode mode);
extern void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c, GXTevColorArg d);
extern void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c, GXTevAlphaArg d);
extern void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool doClamp, GXTevRegID outReg);
extern void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool doClamp, GXTevRegID outReg);
extern void GXSetTevColor(GXTevRegID reg, GXColor color);
extern void GXSetTevColorS10(GXTevRegID reg, GXColorS10 color);
extern void GXSetTevKColor(GXTevKColorID id, GXColor color);
extern void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
extern void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
extern void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel rasSel, GXTevSwapSel texSel);
extern void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green, GXTevColorChan blue, GXTevColorChan alpha);
extern void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
extern void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
extern void GXSetZTexture(GXZTexOp op, GXTexFmt format, u32 bias);
extern void GXSetNumTevStages(u8 count);
extern void GXSetTevClampMode(GXTevStageID stage, GXTevClampMode mode);
}
extern "C"{
extern void GXSetProjection(const Mtx44 mtx, GXProjectionType type);
extern void GXSetProjectionv(const f32* ptr);
extern void GXLoadPosMtxImm(const Mtx mtx, u32 id);
extern void GXLoadNrmMtxImm(const Mtx mtx, u32 id);
extern void GXSetCurrentMtx(u32 id);
extern void GXLoadTexMtxImm(const Mtx mtx, u32 id, GXTexMtxType type);
extern void __GXSetMatrixIndex(GXAttr index);
extern void __GXSetViewport();
extern void GXSetViewport(f32 left, f32 top, f32 width, f32 height, f32 nearZ, f32 farZ);
extern void GXSetScissor(u32 left, u32 top, u32 width, u32 height);
extern void GXSetScissorBoxOffset(s32 x, s32 y);
extern void GXGetScissor(u32* left, u32* top, u32* width, u32* height);
extern void GXGetScissorBoxOffset(int xOffset, int yOffset);
extern void GXSetClipMode(GXClipMode mode);
extern void GXProject(f32 x, f32 y, f32 z, const Mtx viewMtx, f32* projMtx, f32* viewport, f32* screenX, f32* screenY, f32* screenZ);
extern void GXGetProjectionv(f32* ptr);
extern void GXLoadPosMtxIndx(u16 index, u32 id);
extern void GXLoadNrmMtxImm3x3(const Mtx33, u32 id);
extern void GXLoadNrmMtxIndx3x3(u16 index, u32 id);
extern void GXLoadTexMtxIndx(u16 index, u32 id, GXTexMtxType type);
extern void GXSetViewportJitter(f32 left, f32 top, f32 width, f32 height, f32 nearZ, f32 farZ, u32 field);
extern void GXGetViewportv(f32* viewport);
static inline void GXSetViewportv(f32* port)
{
GXSetViewport(port[0], port[1], port[2], port[3], port[4], port[5]);
}
}
extern "C"{
void __VIInit(VITVMode mode);
void VIInit(void);
void VIFlush(void);
void VIWaitForRetrace(void);
void VIConfigure(const GXRenderModeObj* obj);
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void VISetNextFrameBuffer(void* fb);
void* VIGetCurrentFrameBuffer();
void __VIGetCurrentPosition(s16* x, s16* y);
void VISetBlack(BOOL isBlack);
u32 VIGetRetraceCount(void);
u32 VIGetNextField(void);
u32 VIGetCurrentLine(void);
u32 VIGetTvFormat(void);
u32 VIGetDTVStatus(void);
void VIConfigurePan(u16 panPosX, u16 panPosY, u16 panSizeX, u16 panSizeY);
void* VIGetNextFrameBuffer();
void VISetNextRightFrameBuffer(void* fb);
void VISet3D();
}
class Texture;
class TexImg;
class Colour;
class TexobjInfo;
struct SystemCache;
enum TexImgFormat {
TEX_FMT_NULL = -1,
TEX_FMT_RGB565 = 0,
TEX_FMT_S3TC = 1,
TEX_FMT_RGB5A3 = 2,
TEX_FMT_I4 = 3,
TEX_FMT_I8 = 4,
TEX_FMT_IA4 = 5,
TEX_FMT_IA8 = 6,
TEX_FMT_RGBA8 = 7,
TEX_FMT_Z8 = 8,
TEX_FMT_COUNT,
};
class TexAttr : public CoreNode {
public:
enum TilingType {
TILING_REPEAT = 0,
TILING_CLAMP = 1,
};
enum Flags {
FLAG_EDG = 2,
FLAG_XLU = 4,
};
TexAttr()
: CoreNode("texattr")
{
mTextureName = 0 ;
mTexture = 0 ;
mImage = 0 ;
mTilingType = TILING_REPEAT;
mUseOffsetImgData = 0;
mLODBias = 0.0f;
}
virtual void read(RandomAccessStream&);
void initImage();
int mIndex;
int mTextureIndex;
s16 mTilingType;
s16 mFlags;
u16 mUseOffsetImgData;
f32 mLODBias;
char* mTextureName;
Texture* mTexture;
TexImg* mImage;
};
struct BtiHeader {
void read(RandomAccessStream& input)
{
mImageFormat = input.readByte();
mIsAlphaEnabled = input.readByte();
mWidth = input.readShort();
mHeight = input.readShort();
mWrapS = input.readByte();
mWrapT = input.readByte();
_08 = input.readByte();
_09 = input.readByte();
mNumPaletteEntries = input.readShort();
mPaletteDataOffset = input.readInt();
mIsMipmapEnabled = input.readByte();
mIsEdgeLODEnabled = input.readByte();
mDoClampLODBias = input.readByte();
mMaxAnisotropy = input.readByte();
mMiniFilterType = input.readByte();
mMaxiFilterType = input.readByte();
mMinLOD = input.readByte();
mMaxLOD = input.readByte();
mNumImages = input.readByte();
_19 = input.readByte();
mLODBias = input.readShort();
mImageDataOffset = input.readInt();
}
u8 mImageFormat;
u8 mIsAlphaEnabled;
u16 mWidth;
u16 mHeight;
u8 mWrapS;
u8 mWrapT;
u8 _08;
u8 _09;
u16 mNumPaletteEntries;
u32 mPaletteDataOffset;
u8 mIsMipmapEnabled;
u8 mIsEdgeLODEnabled;
u8 mDoClampLODBias;
u8 mMaxAnisotropy;
u8 mMiniFilterType;
u8 mMaxiFilterType;
u8 mMinLOD;
u8 mMaxLOD;
u8 mNumImages;
u8 _19;
u16 mLODBias;
u32 mImageDataOffset;
};
class TexImg : public CoreNode {
public:
TexImg()
: CoreNode("texImg")
{
mImageCount = 1;
mPixelData = 0 ;
}
void read(RandomAccessStream&);
void importBti(Texture*, RandomAccessStream&, u8*);
void importTxe(Texture*, RandomAccessStream&);
static int calcDataSize(int texFmt, int width, int height);
static void getTileSize(int texFmt, u32& tileSizeX, u32& tileSizeY);
static char* formatName(u32 texFmt);
TexImgFormat convFormat(u32);
void setColour( Colour&);
void readTexData(Texture*, RandomAccessStream&, u8*);
void dumpBti(Texture*, char*, RandomAccessStream&, RandomAccessStream&);
int mIndex;
TexImgFormat mFormat;
int mWidth;
int mHeight;
int mImageCount;
int mDataSize;
void* mTextureData;
void* mPixelData;
};
class Texture : public GfxObject {
public:
enum TexFlags {
TEX_CLAMP_S = 1 << 0,
TEX_MIRROR_S = 1 << 1,
TEX_Unk2 = 1 << 2,
TEX_CLAMP_T = 1 << 8,
TEX_MIRROR_T = 1 << 9,
};
Texture();
virtual void attach();
virtual void detach();
virtual void makeResident() { }
u8 getAlpha(int x, int y);
u8 getRed(int x, int y);
void read(RandomAccessStream& input);
void createBuffer(int width, int height, int texFmt, void* buf);
void grabBuffer(int width, int height, bool doClear, bool useMIPmap);
void decodeData(TexImg* texImg);
int offsetGLtoGX(int, int);
static int offsetGXtoGL(int, int, int, int);
int offsetGXtoGL(int);
void write(Stream*);
static void decodeS3TC(int, int, u8*, u8*);
u16 mTexFormat;
u16 mTexFlags;
u16 mWidth;
u16 mHeight;
u32 mTileSizeX;
u32 mTileSizeY;
void* mPixelData;
u32 mLODCount;
f32 mLODBias;
u32 mAttachName;
GXTexObj* mTexObj;
f32 mWidthFactor;
f32 mHeightFactor;
u32 _30;
u32 _34;
TexobjInfo* mInfo;
};
class TexobjInfo : public GfxobjInfo {
public:
TexobjInfo()
: mTexture(0 )
{
}
virtual void attach() { static_cast<GfxObject*>(mTexture)->attach(); }
virtual void detach() { static_cast<GfxObject*>(mTexture)->detach(); }
Texture* mTexture;
};
class CacheInfo {
public:
void insertAfter(CacheInfo* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
char* mName;
CacheInfo* mPrev;
CacheInfo* mNext;
};
class TexCacheInfo : public CacheInfo {
public:
TexCacheInfo() { initData(); }
void initData() { _10 = 0; }
TexCacheInfo** mActiveCacheSlot;
u32 _10;
};
class CacheTexture : public Texture {
public:
CacheTexture()
{
mSystemCache = 0 ;
mTexImage = 0 ;
mActiveCache = 0 ;
}
virtual void makeResident();
SystemCache* mSystemCache;
TexCacheInfo* mActiveCache;
TexImg* mTexImage;
u32 mAramAddress;
};
class TextureCacher : public TexCacheInfo {
public:
TextureCacher(u32 size)
{
mCache = new AyuCache(size);
mName = "root";
mPrev = this;
mNext = this;
}
void updateInfo(CacheTexture*);
void purgeAll();
void removeOldest();
void cacheTexture(CacheTexture*);
AyuCache* mCache;
};
enum KeyboardButtons {
KBBTN_CSTICK_LEFT = 1 << 0,
KBBTN_CSTICK_RIGHT = 1 << 1,
KBBTN_CSTICK_UP = 1 << 2,
KBBTN_CSTICK_DOWN = 1 << 3,
KBBTN_DPAD_LEFT = 1 << 8,
KBBTN_DPAD_RIGHT = 1 << 9,
KBBTN_DPAD_UP = 1 << 10,
KBBTN_DPAD_DOWN = 1 << 11,
KBBTN_A = 1 << 12,
KBBTN_B = 1 << 13,
KBBTN_X = 1 << 14,
KBBTN_Y = 1 << 15,
KBBTN_Z = 1 << 16,
KBBTN_L = 1 << 17,
KBBTN_R = 1 << 18,
KBBTN_MSTICK_UP = 1 << 19,
KBBTN_MSTICK_RIGHT = 1 << 20,
KBBTN_MSTICK_DOWN = 1 << 21,
KBBTN_MSTICK_LEFT = 1 << 22,
KBBTN_START = 1 << 24,
KBBTN_NONE = 0x0,
KBBTN_ANY = 0xffffffff,
KBBTN_ANY_BUTTON = KBBTN_A | KBBTN_B | KBBTN_X | KBBTN_Y | KBBTN_Z | KBBTN_L | KBBTN_R | KBBTN_START,
};
class Controller : public Node {
public:
Controller(int playerNum)
: Node("<Controller>")
{
initialise(playerNum);
}
virtual void update();
void reset(u32 playerNum);
void updateCont(u32 keyStatus);
f32 getMainStickX();
f32 getMainStickY();
f32 getSubStickX();
f32 getSubStickY();
void initialise(u32 playerNum) { reset(playerNum); }
bool keyDown(u32 button) { return (mCurrentInput & button) != 0; }
bool keyUp(u32 button) { return (mCurrentInput & button) == 0; }
bool keyClick(u32 button) { return (mInputPressed & button) != 0; }
bool keyDoubleClick(u32 button) { return (mInputDoublePressed & button) != 0; }
bool keyUnClick(u32 button) { return (mInputReleased & button) != 0; }
u32 mCurrentInput;
u32 mPrevInput;
u32 mInputPressed;
u32 mInputReleased;
u32 mInputDoublePressed;
u32 mDoublePressMask;
u32 mPlayerNum;
u32 _3C;
u32 mInputDelay;
bool mIsControllerFrozen;
s8 mMainStickX;
s8 mMainStickY;
s8 mSubStickX;
s8 mSubStickY;
u8 mAnalogA;
u8 mAnalogB;
u8 mTriggerL;
u8 mTriggerR;
};
class ControllerMgr {
public:
virtual bool keyDown(int);
void update();
void init();
void updateController(Controller*);
};
class IDelegate {
public:
virtual void invoke() = 0;
};
template <typename A>
class IDelegate1 {
public:
virtual void invoke(A) = 0;
};
template <typename A, typename B>
class IDelegate2 {
public:
virtual void invoke(A, B) = 0;
};
template <typename T>
struct Delegate : public IDelegate {
typedef void (T::*CallbackFunc)();
inline Delegate(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke() { (mTarget->*mCallback)(); }
T* mTarget;
CallbackFunc mCallback;
};
template <typename T, typename A>
struct Delegate1 : public IDelegate1<A> {
typedef void (T::*CallbackFunc)(A);
inline Delegate1(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke(A arg) { (mTarget->*mCallback)(arg); }
T* mTarget;
CallbackFunc mCallback;
};
template <typename T, typename A, typename B>
struct Delegate2 : public IDelegate2<A, B> {
typedef void (T::*CallbackFunc)(A, B);
inline Delegate2(T* target, CallbackFunc func)
{
mTarget = target;
mCallback = func;
}
virtual void invoke(A argA, B argB) { (mTarget->*mCallback)(argA, argB); }
T* mTarget;
CallbackFunc mCallback;
};
extern "C"{
typedef struct ARQRequest ARQRequest;
typedef void (*ARCallback)(void);
typedef void (*ARQCallback)(u32 ptrToRequest);
struct ARQRequest {
ARQRequest* next;
u32 owner;
u32 type;
u32 priority;
u32 source;
u32 dest;
u32 length;
ARQCallback callback;
};
void __ARQServiceQueueLo();
void __ARQCallbackHack();
void __ARQInterruptServiceRoutine();
void ARQInit();
void ARQPostRequest(ARQRequest* task, u32 owner, u32 type, u32 priority, u32 source, u32 dest, u32 length, ARQCallback callback);
ARCallback ARRegisterDMACallback(ARCallback callback);
void ARStartDMA(u32 type, u32 mainmem_addr, u32 aram_addr, u32 length);
u32 ARInit(u32* stack_index_addr, u32 num_entries);
u32 ARGetBaseAddress();
u16 __ARGetInterruptStatus();
}
void free(void*);
extern "C"{
typedef struct {
int quot;
int rem;
} div_t;
s32 abs(s32 __x);
s32 labs(s32 __x);
div_t div(s32 __numer, s32 __denom);
inline int _abs(int __x)
{
return __x > 0 ? __x : -__x;
}
}
extern "C"{
int __mbtowc_noconv(wchar_t*, const char*, size_t);
int __wctomb_noconv(char*, wchar_t);
size_t wcstombs(char* s, const wchar_t* pwcs, size_t n);
int mbstowcs(wchar_t* pwc, const char* s, size_t n);
int wctomb(char* s, wchar_t wchar);
static int unicode_to_UTF8(char* s, wchar_t wchar);
int mbtowc(wchar_t* pwc, const char* s, size_t n);
static int is_utf8_complete(const char* s, size_t n);
}
extern "C"{
int rand();
void srand(u32 seed);
}
extern "C"{
f128 __strtold(int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* overflow);
s32 strtol(const char* str, char** end, int base);
f64 atof(const char* str);
}
extern "C"{
u32 __strtoul(int base, int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* negative,
int* overflow);
u64 __strtoull(int base, int max_width, int (*ReadProc)(void*, int, int), void* ReadProcArg, int* chars_scanned, int* negative,
int* overflow);
int atoi(const char* str);
u32 strtoul(const char* str, char** end, int base);
}
extern "C"{
void abort(void);
void atexit(void);
void exit(int);
}
struct DGXGraphics;
class BaseApp;
class CacheTexture;
class TextureCacher;
class LoadIdler;
class Timers;
class Font;
class BaseShape;
class CoreNode;
class LFInfo;
class LightFlare;
class LFlareGroup;
class Matrix4f;
class AtxRouter;
class ControllerMgr;
struct OSContext;
struct OSThread;
class Shape;
class AnimData;
class AnimFrameCacher;
class MemInfo;
class CacheInfo;
enum SystemHeapType {
SYSHEAP_NULL = -1,
SYSHEAP_Sys = 0,
SYSHEAP_Ovl = 1,
SYSHEAP_App = 2,
SYSHEAP_Load = 3,
SYSHEAP_Teki = 4,
SYSHEAP_Movie = 5,
SYSHEAP_Message = 6,
SYSHEAP_Lang = 7,
SYSHEAP_COUNT,
};
enum TimerState {
TS_Off = 0,
TS_On,
TS_Full
};
enum LanguageID {
LANG_FORCE_CHANGE = -1,
LANG_Adult = 0,
LANG_Child = 1,
LANG_CAPACITY = 8,
};
struct AddressNode : public CoreNode {
AddressNode()
: CoreNode("")
{
}
};
struct DirEntry : public CoreNode {
DirEntry()
: CoreNode("")
{
}
int mPending;
u32 mAddress;
};
class BinobjInfo : public GfxobjInfo {
public:
BinobjInfo()
: mData(0 )
{
}
u8* mData;
};
struct SystemCache : public ARQRequest {
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
void insertAfter(SystemCache* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
SystemCache* mNext;
SystemCache* mPrev;
};
struct SystemFlags { typedef
enum {
Active = 0x00200000,
Shutdown = 0x80000000,
} Type; } ;
class StdSystem {
public:
StdSystem();
void onceInit();
AyuHeap* getHeap(int heapIdx);
void resetHeap(int heapIdx, int flag);
int setHeap(int);
GfxobjInfo* findGfxObject( char*, u32);
Texture* loadTexture( char* path, bool isRelativePath);
Shape* loadShape( char* modelPath, bool checkCache);
AnimData* findAnimation( char*);
int findAnyIndex( char*, char*);
AnimData* loadAnimation(Shape* model, char* dataPath, bool isRelativePath);
void addAnimation(AnimData*, char*);
void addGfxObject(GfxobjInfo*);
void attachObjs();
void detachObjs();
void invalidateObjs(u32, u32);
void addTexture(Texture*, char*);
Shape* getShape( char*, char*, char*, bool);
void initLFlares(int);
void resetLFlares();
LFInfo* getLFlareInfo();
LFlareGroup* registerLFlare(Texture*);
void flushLFlares(Graphics&);
void loadBundle( char* pPath, bool loadWithCache);
void getAppMemory(char*);
GfxobjInfo* findAnyGfxObject( char*, u32);
GfxobjInfo* findTexture(Texture*);
AnimData* findAnyAnimation( char*);
AnimData* findIndexAnimation( char*, int);
static char* stringDup( char*);
f32 getRand(f32 max) { return max * (rand() / f32((0x7fff) )); }
f32 getHalfRand(f32 max) { return max * (rand() / f32((0x7fff) ) - 0.5f); }
f32 getFade() { return mCurrentFade; }
void setFade(f32 target, f32 rate = 3.0f)
{
mTargetFade = target;
mFadeRate = rate;
}
void set2DRoot( char* bloDir, char* texDir)
{
mBloDir = bloDir;
mTexDir = texDir;
}
void setTextureBase( char* base1, char* base2)
{
mTextureBase1 = base1;
mTextureBase2 = base2;
}
void setDataRoot( char* dir) { mDataRoot = dir; }
void softReset() { mSoftResetPending = true; }
void Shutdown() { mSystemFlags = SystemFlags::Shutdown; }
bool isShutdown() { return mSystemFlags == SystemFlags::Shutdown; }
bool resetPending() { return mSoftResetPending; }
void setFrameClamp(int frameRate) { mFrameRate = frameRate; }
int getHeapNum() { return mActiveHeapIdx; }
void setActive(bool set)
{
u32 unused;
if (set) {
mSystemFlags |= SystemFlags::Active;
unused = mSystemFlags;
} else {
mSystemFlags &= ~SystemFlags::Active;
unused = mSystemFlags;
}
Activate(set);
}
bool isActive(void) { return (mSystemFlags & SystemFlags::Active) == SystemFlags::Active; }
bool mSoftResetPending;
f32 mCurrentFade;
f32 mTargetFade;
f32 mFadeRate;
Font* mConsFont;
s32 mFrameRate;
u32 mTimerState;
u32 mTogglePrint;
u32 mToggleDebugInfo;
u32 mToggleDebugExtra;
u32 mToggleBlur;
u32 mToggleFileInfo;
u32 mToggleColls;
Timers* mTimer;
TextureCacher* mCacher;
u32 mMatrixCount;
Matrix4f* mMatrices;
char* mBloDir;
char* mTexDir;
char* mActiveDir;
char* mDataRoot;
AyuHeap mHeaps[SYSHEAP_COUNT];
int mActiveHeapIdx;
BOOL mToggleHeapAllocPrint;
MemInfo* mCurrMemInfo;
virtual void initSoftReset();
virtual RandomAccessStream* openFile( char* path, bool isRelativePath = true, bool = true) { return 0 ; }
virtual u32 copyRamToCache(u32, u32, u32) { return 0; }
virtual void copyCacheToRam(u32, u32, u32) { }
virtual void copyWaitUntilDone() { }
virtual void copyCacheToTexture(CacheTexture*) { }
virtual void Activate(bool) { }
virtual void parseArchiveDirectory( char* arcPath, char* dirPath) { }
virtual void sndPlaySe(u32) = 0;
virtual void startLoading(LoadIdler*, bool, u32) { }
virtual void endLoading() { }
int mPolygonCount;
u32 mMaterialCount;
u32 mDispCount;
u32 mLightCount;
s32 mActiveLightCount;
u32 mAnimatedPolygons;
u32 mLightingSkips;
u32 mLightingSets;
u32 mLightSetNum;
u32 mSystemFlags;
Graphics* mGraphics;
GfxobjInfo mGfxobjInfo;
bool mHasGfxObjects;
char* mTextureBase1;
char* mTextureBase2;
Shape* mCurrentShape;
CoreNode mDvdRoot;
CoreNode mAramRoot;
DirEntry* mFileList;
int mFlareCount;
int mLfInfoCount;
LFInfo* mFlareInfoList;
LFlareGroup* mFlareGroupList;
int mDvdOpenFiles;
u32 mDvdBytesRead;
void ageAnyAnimations(AgeServer&, char*);
};
struct AramAllocator {
void init(u32 start, u32 size)
{
mStartAddress = start;
mTotalSize = size;
reset();
}
void reset() { mNextFreeAddress = mStartAddress; }
u32 alloc(u32 numBytes)
{
u32 allocAddr = 0;
u32 nextFree = mNextFreeAddress;
if (nextFree + numBytes <= mStartAddress + mTotalSize) {
allocAddr = nextFree;
mNextFreeAddress = nextFree + numBytes;
}
return allocAddr;
}
u32 getFreeSize() { return mStartAddress + mTotalSize - mNextFreeAddress; }
u32 mStartAddress;
u32 mNextFreeAddress;
u32 mTotalSize;
};
struct DvdError { typedef
enum {
None = -1,
ReadingDisc = 0,
FatalError = 1,
RetryError = 2,
NoDisc = 3,
CoverOpen = 4,
WrongDisc = 5
} Type; } ;
struct SystemClass250 {
virtual void method(Graphics& gfx) = 0;
};
struct SymbolInfo {
SymbolInfo* mNext;
u32 mVirtualAddress;
char mDemangledName[];
};
class System : public StdSystem {
public:
System();
virtual void initSoftReset();
virtual RandomAccessStream* openFile( char* path, bool isRelativePath = true, bool = true);
virtual u32 copyRamToCache(u32, u32, u32);
virtual void copyCacheToRam(u32, u32, u32);
virtual void copyWaitUntilDone();
virtual void copyCacheToTexture(CacheTexture*);
virtual void parseArchiveDirectory( char* arcPath, char* dirPath);
virtual void sndPlaySe(u32);
virtual void startLoading(LoadIdler* idler, bool useLoadScreen, u32 loadDelay);
virtual void endLoading();
~System();
void run(BaseApp* app);
void beginRender();
void doneRender();
void waitRetrace();
f32 getTime();
void updateSysClock();
void hardReset();
void showDvdError(Graphics&);
void nudgeLoading();
void nudgeDvdThread();
void startDvdThread();
void Initialise();
RandomAccessStream* createFile( char*, BOOL);
char* findAddress(u32);
bool hasDebugInfo();
static void halt( char* file, int line, char* message);
void sleep(f32 seconds);
static void* alloc(size_t);
AtxRouter* getAtxRouter() { return mAtxRouter; }
void setAtxRouter(AtxRouter* router) { mAtxRouter = router; }
f32 getFrameTime() { return mDeltaTime; }
f32 getFrameRate() { return mFPS; }
int setStreamType(int);
void setActiveAramAllocator(AramAllocator* allocator) { mActiveAramAllocator = allocator; }
u32 mHeapStart;
u32 mHeapEnd;
Graphics* mDGXGfx;
SystemClass250* mHaltCallback;
Delegate1<System, Graphics&>* mDvdErrorCallback;
int mDvdErrorCode;
u32 mDvdBufferSize;
u32 mIsLoadingActive;
u32 mLoadTimeBeforeIdling;
u32 mIsLoadScreenActive;
vu32 mIsRendering;
u32 mIsCardSaving;
OSThread* mCurrentThread;
AtxRouter* mAtxRouter;
ControllerMgr mControllerMgr;
u32 mPrevTick;
u32 mFpsSampleStart;
int mFrameTicks;
f32 mDeltaTime;
f32 mFPS;
u32 mEngineFrames;
u32 mFramesAtSampleStart;
u32 mTotalFrames;
u32 mRetraceCount;
BOOL mPrevAllocType;
AddressNode _2A8;
SymbolInfo* mBuildMapFuncList;
SystemCache mActiveCacheList;
SystemCache mFreeCacheList;
AramAllocator mShapeAramAllocator;
AramAllocator mBaseAramAllocator;
AramAllocator* mActiveAramAllocator;
vu32 mDmaComplete;
vu32 mTexComplete;
};
extern System* gsys;
struct LogStream : public Stream {
LogStream()
{
mBufPosition = 0;
_UNUSED0C = 0;
}
virtual void flush()
{
mBuffer[mBufPosition] = 0;
if (gsys->mTogglePrint) {
OSReport("%s\n", mBuffer);
}
mBufPosition = 0;
}
virtual void write( void* data, int size)
{
for (int i = 0; i < size; i++) {
char c = (( char*)data)[i];
if (c == 0xA) {
flush();
continue;
}
if (c == 0x9) {
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = ' ';
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = ' ';
continue;
}
if (mBufPosition >= 255) {
flush();
}
mBuffer[mBufPosition++] = c;
}
}
int mBufPosition;
u32 _UNUSED0C;
char mBuffer[0x100];
};
struct AramStream : public RandomAccessStream {
virtual int getPending() { return mPending; }
virtual void read(void* data, int size)
{
int readSize = (((u32)(size) + 0x1F) & ~(0x1F)) ;
gsys->copyCacheToRam((u32)data, mBaseAddress + mOffset, readSize);
gsys->copyWaitUntilDone();
mOffset += readSize;
}
void init( char* path, u32 address, int pending)
{
mPath = path;
mPending = pending;
mBaseAddress = address;
mOffset = 0;
}
u32 mBaseAddress;
u32 mOffset;
int mPending;
};
extern int glnWidth;
extern int glnHeight;
class AnimMgr;
class BaseShape;
class CmdStream;
class Shape;
class AgeServer;
enum AnimInfoFlags {
ANIMFLAG_Unk1 = 1 << 0,
ANIMFLAG_UseDynamicSpeed = 1 << 1,
ANIMFLAG_UseCache = 1 << 2,
};
enum AnimKeyEvents {
ANIMEVENT_Notify = 0,
ANIMEVENT_Action = 1,
ANIMEVENT_None = 2,
ANIMEVENT_COUNT,
};
enum AnimPlayState {
ANIMSTATE_Inactive = 0,
ANIMSTATE_Loop = 1,
ANIMSTATE_OneShot = 2,
};
enum KeyEventTypes {
KEY_NULL = -1,
KEY_Finished = 0,
KEY_Action0 = 1,
KEY_Action1 = 2,
KEY_Action2 = 3,
KEY_Action3 = 4,
KEY_LoopStart = 5,
KEY_LoopEnd = 6,
KEY_PlaySound = 7,
KEY_PlayEffect = 8,
KEY_Reserved = 9,
};
class DataChunk {
public:
DataChunk()
{
mDataIndex = 0;
mDataSize = 0;
mData = 0 ;
}
void addData(f32 data)
{
if (mDataIndex >= mDataSize) {
mDataSize = mDataIndex + 0x800;
f32* newData = new f32[mDataSize];
if (mDataIndex) {
memcpy(newData, mData, mDataIndex * sizeof(f32));
}
delete mData;
mData = newData;
}
mData[mDataIndex++] = data;
}
void setDataSize(int size)
{
mData = new f32[size];
mDataSize = size;
}
void read(RandomAccessStream& stream)
{
int dataSize = stream.readInt();
setDataSize(dataSize);
for (int i = 0; i < dataSize; i++) {
mData[i] = stream.readFloat();
}
}
void getData(CmdStream* stream)
{
stream->getToken(true);
int tokenCount = 0;
while (!stream->endOfCmds() && !stream->endOfSection()) {
if ((tokenCount & 7) == 0) {
stream->getToken(true);
if (stream->isToken("size")) {
int dataSize;
sscanf(stream->getToken(true), "%d", &dataSize);
setDataSize(dataSize);
stream->getToken(true);
}
}
f32 data;
sscanf(stream->getToken(true), "%f", &data);
addData(data);
++tokenCount;
}
if (!stream->endOfCmds()) {
stream->getToken(true);
}
}
int mDataIndex;
int mDataSize;
f32* mData;
};
class AnimCacheInfo : public CacheInfo {
public:
AnimCacheInfo() { initData(); }
void initData()
{
mBoneMatrices = 0;
mCachedMtxBlock = 0;
}
AnimCacheInfo** _0C;
CacheInfo* mCachedMtxBlock;
Matrix4f* mBoneMatrices;
Matrix4f** mBoneMtxList;
};
struct AnimParam {
int mEntryNum;
int mDataOffset;
int mFlags;
};
struct AnimDataFlags { typedef
enum {
ScaleXStatic = 1 << 0,
ScaleYStatic = 1 << 1,
ScaleZStatic = 1 << 2,
AllIndividualScaleStatic = ScaleXStatic | ScaleYStatic | ScaleZStatic,
AllScaleStatic = 1 << 3,
RotationXStatic = 1 << 4,
RotationYStatic = 1 << 5,
RotationZStatic = 1 << 6,
AllIndividualRotationStatic = RotationXStatic | RotationYStatic | RotationZStatic,
AllRotationStatic = 1 << 7,
TranslationXStatic = 1 << 8,
TranslationYStatic = 1 << 9,
TranslationZStatic = 1 << 10,
AllIndividualTranslationStatic = TranslationXStatic | TranslationYStatic | TranslationZStatic,
AllTranslationStatic = 1 << 11,
AllComponentsStatic = AllIndividualScaleStatic | AllIndividualRotationStatic | AllIndividualTranslationStatic,
MatrixCalculated = 1 << 15,
} Type; } ;
class AnimDataInfo {
public:
AnimDataInfo() { mFlags = 0; }
AnimParam mScale[3];
AnimParam mRotation[3];
AnimParam mTranslation[3];
int mGroupIndex;
AnimDataInfo* mParentInfo;
Matrix4f mMtx;
SRT mSRT;
u16 mFlags;
};
class AnimData : public CoreNode {
public:
AnimData()
: CoreNode("")
{
mAnimFlags = 0;
_38 = 0;
}
AnimData( char* name)
: CoreNode(name)
{
mAnimFlags = 0;
_38 = 0;
}
virtual void extractSRT(SRT&, int, AnimDataInfo*, f32);
virtual void makeAnimSRT(int, Matrix4f*, Matrix4f*, AnimDataInfo*, f32);
virtual void detach();
virtual void writeType(RandomAccessStream&) { }
void checkMask();
void initData();
DataChunk* mScaleDataBlock;
DataChunk* mRotateDataBlock;
DataChunk* mTranslationDataBlock;
u16* mAnimJointIndices;
int mAnimFlags;
int mJointCount;
int mActiveJointCount;
int mTotalFrameCount;
BaseShape* mModel;
int _38;
AnimDataInfo* mAnimInfo;
AnimCacheInfo* mAnimInfoList;
};
class AnimDca : public AnimData {
public:
AnimDca(BaseShape*, int)
: AnimData()
{
}
AnimDca( char* name)
: AnimData(StdSystem::stringDup(name))
{
}
virtual void read(RandomAccessStream&);
void parse(CmdStream*);
void getAnimInfo(CmdStream*);
};
class AnimDck : public AnimData {
public:
AnimDck(BaseShape*, int);
AnimDck( char* name)
: AnimData(StdSystem::stringDup(name))
{
}
virtual void read(RandomAccessStream&);
virtual void extractSRT(SRT&, int, AnimDataInfo*, f32);
virtual void makeAnimSRT(int, Matrix4f*, Matrix4f*, AnimDataInfo*, f32);
void parse(CmdStream*);
void getAnimInfo(CmdStream*);
};
class AnmobjInfo : public GfxobjInfo {
public:
AnmobjInfo()
: mAnimation(0 )
{
}
virtual void detach();
AnimData* mAnimation;
};
class AnimKey {
public:
AnimKey()
{
mFrameIndex = 0;
mEventType = 0;
mKeyType = 0;
mEventCmdID = 0;
mPrev = mNext = 0 ;
}
AnimKey(int index, int value)
{
mFrameIndex = index;
mKeyType = value;
mPrev = 0 ;
mNext = 0 ;
}
void insertAfter(AnimKey* key)
{
key->mNext = mNext;
key->mPrev = this;
mNext->mPrev = key;
mNext = key;
}
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
void ageDelLastKey(AgeServer&);
int mFrameIndex;
s16 mEventType;
u8 mKeyType;
u8 mEventCmdID;
AnimKey* mPrev;
AnimKey* mNext;
};
class AnimInfo : public CoreNode {
public:
struct Parms : public Parameters {
Parms()
: Parameters("AnimInfoParms")
, mFlags(this, 2, 0, 0, "p00", "flags")
, mSpeed(this, 30.0f, 0.0f, 0.0f, "spd", "speed")
{
}
Parm<int> mFlags;
Parm<f32> mSpeed;
};
AnimInfo()
: CoreNode("")
{
mData = 0 ;
mMgr = 0 ;
}
AnimInfo(AnimMgr* mgr, AnimData* data);
void initAnimData(AnimData* data);
void checkAnimData();
void doread(RandomAccessStream& input, int version);
void setIndex();
void setAnimFlags(u32 flags);
void updateAnimFlags();
int countAKeys();
int countIKeys();
int countEKeys();
AnimKey* getInfoKey(int idx);
AnimKey* getEventKey(int idx);
int getKeyValue(int idx);
AnimKey* addKeyFrame();
void addInfoKey(AnimKey* key) { mInfoKeys.mPrev->insertAfter(key); }
void ageAddEffectKey(AgeServer&);
void ageAddInfoKey(AgeServer&);
void ageAddKey(AgeServer&);
void ageChangeAnim(AgeServer&);
void ageDelAnim(AgeServer&);
void genAgeKeyTypes(AgeServer&);
Parms mParams;
AnimKey mAnimKeys;
AnimKey mEventKeys;
AnimKey mInfoKeys;
AnimData* mData;
int mIndex;
AnimMgr* mMgr;
};
class AnimContext {
public:
AnimContext()
: mData(0 )
, mCurrentFrame(0.0f)
, mAnimSpeed(30.0f)
{
}
AnimData* mData;
f32 mCurrentFrame;
f32 mAnimSpeed;
virtual void animate(f32 animSpeed);
};
struct Animator {
Animator() { }
void startAnim(int playState, int animIdx, int firstKeyFrameIdx, int lastKeyFrameIdx);
void updateContext();
void init(AnimContext* context, AnimMgr* mgr)
{
mContext = context;
mMgr = mgr;
mAnimInfo = 0 ;
mAnimationCounter = 0.0f;
}
AnimMgr* mMgr;
AnimContext* mContext;
int mPostOneShotPlayState;
int mPostOneShotAnimID;
int mPostOneShotStartKeyIndex;
int mPostOneShotEndKeyIndex;
int mPlayState;
int mCurrentAnimID;
int mStartKeyIndex;
int mEndKeyIndex;
AnimInfo* mAnimInfo;
f32 mAnimationCounter;
virtual void changeContext(AnimContext* context)
{
mContext = context;
}
virtual void animate(f32 animSpeed);
virtual void finishOneShot();
virtual void finishLoop();
};
class AnimMgr : public CoreNode {
public:
struct Parms : public Parameters {
Parms()
: Parameters("AnimMgr Parms")
, mFlags(this, 2, 0, 0, "a00", "flags")
, mBasePath(this, String("base dir", 0), String("", 0), String("", 0), "a01", "baseAnimDir")
{
}
Parm<int> mFlags;
Parm<String> mBasePath;
};
AnimMgr(Shape* model, char* animPath, int flags, char* bundlePath);
virtual void read(RandomAccessStream& input);
void loadAnims( char* animPath, char* bundlePath);
AnimInfo* addAnimation( char* dataPath, bool isRelativePath);
int countAnims();
AnimInfo* findAnim(int idx);
Parms mParams;
Shape* mModel;
AnimInfo mAnimList;
BOOL mSkipLoading;
};
struct FrameCacher : public CacheInfo {
CacheInfo** mInfo;
u8 _10[4];
u32* mBoneMatricesEnd;
u32* mBoneMtxList;
u32 mBoneMatrices[1];
};
class AnimFrameCacher {
public:
AnimFrameCacher(int);
void updateInfo(AnimCacheInfo*);
void removeOldest();
void cacheFrameSpace(int, AnimCacheInfo*);
AyuCache* mCache;
CacheInfo mInfo;
u8 _10[0x8];
};
class PaniMotion;
class PaniMotionTable;
class PaniMotionInfo;
class PaniAnimKeyEvent {
public:
PaniAnimKeyEvent(int eventType)
{
mEventType = eventType;
mValue = -1;
}
PaniAnimKeyEvent(int eventType, int value)
{
mEventType = eventType;
mValue = value;
}
int mEventType;
int mValue;
};
class PaniAnimKeyListener {
public:
virtual void animationKeyUpdated( PaniAnimKeyEvent&) = 0;
};
class PaniMotion {
public:
PaniMotion(int);
PaniMotion(int, int);
void init(int, int);
int mAnimID;
int _UNUSED04;
};
class PaniMotionTable {
public:
PaniMotionTable(int);
PaniMotion* getMotion(int motionIdx) { return mMotions[motionIdx]; }
void setMotion(int motionIdx, PaniMotion* motion) { mMotions[motionIdx] = motion; }
int mMotionCount;
PaniMotion** mMotions;
};
struct PaniAnimator : public Animator {
PaniAnimator();
virtual void changeContext(AnimContext*);
virtual void animate(f32);
virtual void updateContext();
void init(AnimContext*, AnimMgr*, PaniMotionTable*);
void startMotion( PaniMotionInfo&);
void finishMotion( PaniMotionInfo&);
void checkConstantKeys();
void checkConstantKey(int);
void checkEventKeys(f32, f32);
void finishAnimation();
f32 getKeyValueByKeyType(int);
void checkCounter_4DEBUG();
inline int getCurrentKeyIndex() { return mCurrentKeyIndex; }
inline int getInfoKeyValue(int idx) { return mAnimInfo->getInfoKey(idx)->mFrameIndex; }
inline int getEventKeyValue(int idx) { return mAnimInfo->getEventKey(idx)->mFrameIndex; }
bool isFinished() { return mIsFinished; }
bool isFinishing() { return mCurrentKeyIndex < 0; }
f32 getCounter() { return mAnimationCounter; }
void setCounter(f32 frame) { mAnimationCounter = frame; }
f32 getKeyValue(int idx) { return mAnimInfo->getKeyValue(idx); }
int getCurrentMotionIndex() { return mMotionIdx; }
PaniMotion* getMotion(int motionIdx) { return mMotionTable->getMotion(motionIdx); }
bool getCurrentOption(int opt) { return mAnimInfo->mParams.mFlags() & opt; }
f32 getAnimationSpeed() { return mAnimInfo->mParams.mSpeed(); }
int getFrameCount()
{
if (!mAnimInfo) {
return -1;
}
return mAnimInfo->mData->mTotalFrameCount;
}
static char* keyNames[6];
PaniAnimKeyListener* mListener;
int mCurrentKeyIndex;
u8 _3C[0x4];
u32 mPreviousKeyIndex;
int mMotionIdx;
bool mIsFinished;
u32 _4C;
PaniMotionTable* mMotionTable;
};
struct PaniItemAnimator : public PaniAnimator {
PaniItemAnimator();
char* getCurrentMotionName()
{
if (mMotionIdx < 0) {
return "NULL";
}
return motionLabels[mMotionIdx];
}
static PaniMotionTable* createMotionTable();
static char* motionLabels[15];
};
struct PelletMotion { typedef
enum {
Carry = 0,
Appear = 1,
After = 2,
Piston = 3,
Special = 4,
Unused5 = 5,
Unused6 = 6,
COUNT,
} Type; } ;
class PaniPelletAnimator : public PaniAnimator {
public:
PaniPelletAnimator();
static PaniMotionTable* createMotionTable();
static char* motionLabels[PelletMotion::COUNT];
};
struct PlantMotion { typedef
enum {
Touch = 0,
Unused1 = 1,
Unused2 = 2,
Unused3 = 3,
Unused4 = 4,
Unused5 = 5,
Unused6 = 6,
COUNT,
} Type; } ;
struct PaniPlantAnimator : public PaniAnimator {
PaniPlantAnimator();
static PaniMotionTable* createMotionTable();
static char* motionLabels[PlantMotion::COUNT];
};
struct TekiMotion { typedef
enum {
Dead = 0,
Damage = 1,
Wait1 = 2,
Wait2 = 3,
WaitAct1 = 4,
WaitAct2 = 5,
Move1 = 6,
Move2 = 7,
Attack = 8,
Flick = 9,
Type1 = 10,
Type2 = 11,
Type3 = 12,
Type4 = 13,
Type5 = 14,
COUNT,
} Type; } ;
struct PaniTekiAnimator : public PaniAnimator {
PaniTekiAnimator();
static PaniMotionTable* createMotionTable();
static char* motionLabels[TekiMotion::COUNT];
char* getCurrentMotionName()
{
if (mMotionIdx < 0) {
return "NULL";
}
return motionLabels[mMotionIdx];
}
};
struct UfoMotion { typedef
enum {
WaitTutorial = 0,
Wait = 1,
Takeoff = 2,
Henka1 = 3,
Henka1b = 4,
Henka1d = 5,
Henka2 = 6,
Henka2d = 7,
Henka3 = 8,
Henka4a = 9,
Henka4b = 10,
Takeoff1 = 11,
Takeoff2 = 12,
Takeoff3 = 13,
Takeoff4 = 14,
Takeoff5 = 15,
OpenClose = 16,
COUNT,
} Type; } ;
struct PaniUfoAnimator : public PaniAnimator {
PaniUfoAnimator();
static PaniMotionTable* createMotionTable();
static char* motionLabels[UfoMotion::COUNT];
};
class PaniMotionInfo {
public:
PaniMotionInfo(int);
PaniMotionInfo(int, PaniAnimKeyListener*);
void init(int, PaniAnimKeyListener*);
int mMotionIdx;
PaniAnimKeyListener* mListener;
};
class PaniSound {
public:
PaniSound(int soundID)
: mSoundID(soundID)
{
}
int mSoundID;
};
class PaniSoundTable {
public:
PaniSoundTable(int);
int getSize() { return mSoundCount; }
PaniSound* getSound(int idx) { return mSounds[idx]; }
int mSoundCount;
PaniSound** mSounds;
};
enum PikiNaviAnim {
PIKIANIM_Run = 0,
PIKIANIM_Nigeru = 1,
PIKIANIM_Walk = 2,
PIKIANIM_Wait = 3,
PIKIANIM_Pick = 4,
PIKIANIM_Nuku = 5,
PIKIANIM_Nukareru = 6,
PIKIANIM_Dead = 7,
PIKIANIM_Dead2 = 8,
PIKIANIM_Dead3 = 9,
PIKIANIM_Damage = 10,
PIKIANIM_Asibumi = 11,
PIKIANIM_OCarry = 12,
PIKIANIM_LSuberu = 13,
PIKIANIM_RSuberu = 14,
PIKIANIM_Tanemaki = 15,
PIKIANIM_Job1 = 16,
PIKIANIM_GrowUp1 = 17,
PIKIANIM_GrowUp2 = 18,
PIKIANIM_Job2 = 19,
PIKIANIM_Korobu = 20,
PIKIANIM_Jump = 21,
PIKIANIM_StillJump = 22,
PIKIANIM_Attack = 23,
PIKIANIM_Butukaru = 24,
PIKIANIM_Punch = 25,
PIKIANIM_Kenka = 26,
PIKIANIM_Throw = 27,
PIKIANIM_Hang = 28,
PIKIANIM_Fall = 29,
PIKIANIM_JKoke = 30,
PIKIANIM_JHit = 31,
PIKIANIM_GetUp = 32,
PIKIANIM_NewJmp = 33,
PIKIANIM_RollJmp = 34,
PIKIANIM_WaveJmp = 35,
PIKIANIM_ThrowWait = 36,
PIKIANIM_Push = 37,
PIKIANIM_Umaru = 38,
PIKIANIM_Akubi = 39,
PIKIANIM_Rinbow = 40,
PIKIANIM_Iraira = 41,
PIKIANIM_Furimuku = 42,
PIKIANIM_JumpKick = 43,
PIKIANIM_Kaifuku = 44,
PIKIANIM_Kizuku = 45,
PIKIANIM_PickLoop = 46,
PIKIANIM_Mizunomi = 47,
PIKIANIM_Kuttuku = 48,
PIKIANIM_Fue = 49,
PIKIANIM_Suwaru = 50,
PIKIANIM_Aogu = 51,
PIKIANIM_Neru = 52,
PIKIANIM_Press1 = 53,
PIKIANIM_Press2 = 54,
PIKIANIM_SPress = 55,
PIKIANIM_TYakusui = 56,
PIKIANIM_Oboreru = 57,
PIKIANIM_Sizumu = 58,
PIKIANIM_Hikakaru = 59,
PIKIANIM_Otikake = 60,
PIKIANIM_Otiru = 61,
PIKIANIM_HNoboru = 62,
PIKIANIM_Noboru = 63,
PIKIANIM_Chatting = 64,
PIKIANIM_Sagasu2 = 65,
PIKIANIM_Otikake2 = 66,
PIKIANIM_Kaifuku3 = 67,
PIKIANIM_Punch2 = 68,
PIKIANIM_Moeru = 69,
PIKIANIM_Esa = 70,
PIKIANIM_GameOver = 71,
PIKIANIM_Gattu = 72,
PIKIANIM_Gakkari = 73,
PIKIANIM_Okoru = 74,
PIKIANIM_RotJump = 75,
PIKIANIM_GWait1 = 76,
PIKIANIM_GWait2 = 77,
PIKIANIM_GFuri1 = 78,
PIKIANIM_GFuri2 = 79,
PIKIANIM_GNuke = 80,
PIKIANIM_Jump_B1 = 81,
PIKIANIM_Nuku_Fast = 82,
PIKIANIM_Nukare_Fast = 83,
PIKIANIM_Mizuage = 84,
PIKIANIM_Sagasu = 85,
PIKIANIM_Osu = 86,
PIKIANIM_Osu_Walk = 87,
PIKIANIM_Noru = 88,
PIKIANIM_ODead = 89,
PIKIANIM_COUNT,
};
class PaniPikiAnimator : public PaniAnimator {
public:
PaniPikiAnimator();
char* getCurrentMotionName()
{
if (mMotionIdx >= 0) {
return motionLabels[mMotionIdx];
} else {
return "NULL";
}
}
static PaniMotionTable* createMotionTable();
static char* motionLabels[PIKIANIM_COUNT];
};
struct PaniPikiAnimMgr {
PaniPikiAnimMgr();
void init(AnimMgr*, AnimContext*, AnimContext*, PaniMotionTable*);
void changeContext(AnimContext*, AnimContext*);
void startMotion( PaniMotionInfo*, PaniMotionInfo*);
void finishMotion( PaniMotionInfo*, PaniMotionInfo*);
void startMotion( PaniMotionInfo&, PaniMotionInfo&);
void finishMotion(PaniAnimKeyListener*);
void updateAnimation(f32);
void updateContext();
static PaniMotionTable* getMotionTable();
PaniPikiAnimator& getUpperAnimator() { return mUpperAnimator; }
PaniPikiAnimator& getLowerAnimator() { return mLowerAnimator; }
static PaniMotionTable* motionTable;
f32 mAnimSpeed;
PaniPikiAnimator mUpperAnimator;
PaniPikiAnimator mLowerAnimator;
};
class PaniAnimKeyListener;
class PaniMotionInfo;
class PaniMotionTable;
class PelletShapeObject;
enum PelletCreationType {
PCT_Resident = 0,
PCT_LoadIfExists = 1,
PCT_LoadOnTeki = 2,
PCT_LoadOnBoss = 3,
};
class PelletAnimInfo : public Parameters, public CoreNode {
public:
PelletAnimInfo();
PelletShapeObject* createShapeObject();
void changeType(AgeServer&);
void newShapeObject(AgeServer&);
void removeSelf(AgeServer&);
ID32 mID;
int mCreationType;
int mTekiType;
Parm<String> mFolderPath;
Parm<String> mFileName;
int mOverrideJoint;
virtual void read(RandomAccessStream&);
PelletShapeObject* mPelletShapeObject;
};
struct PelletAnimator {
PelletAnimator();
void init(AnimContext*, AnimContext*, AnimMgr*, PaniMotionTable*);
void finishMotion( PaniMotionInfo*, PaniMotionInfo*);
void startMotion( PaniMotionInfo&, PaniMotionInfo&);
void startMotion( PaniMotionInfo&);
void updateAnimation(f32, f32);
void updateContext();
void startMotion( PaniMotionInfo*, PaniMotionInfo*);
void finishMotion(PaniAnimKeyListener*);
PaniPelletAnimator& getLowerAnimator() { return mLowerAnimator; }
PaniPelletAnimator& getUpperAnimator() { return mUpperAnimator; }
int getMainMotionIndex();
PaniPelletAnimator mLowerAnimator;
PaniPelletAnimator mUpperAnimator;
};
class Event {
public:
Event(int unk, u32 id)
{
_00 = unk;
mId = id;
}
int _00;
u32 mId;
};
class EventListener : public CoreNode {
public:
inline EventListener()
{
mParent = mNext = mChild = 0 ;
mName = "eventListeners";
}
virtual void gotEvent(Event&) { }
};
struct EventTalker {
EventTalker();
void informEvent(Event&);
EventListener mListener;
};
class Graphics;
class Texture;
class Vector3f;
class FastGrid {
public:
FastGrid();
void delAIGrid();
bool aiCulling();
bool aiCullingLarge(int);
bool doCulling(const FastGrid&, f32);
void updateGrid(const Vector3f&);
void updateAIGrid(const Vector3f&, bool);
void addAIGrid();
void renderAIGrid2D(Graphics&);
static void initAIGrid(u8);
static void clearAIGrid();
static void renderAIGrid(Graphics&);
void setNeighbourSize(int size) { mNeighbourSize = size; }
static u16 aiGridShift;
static u8* aiGridMap;
static u16 aiGridSize;
static Texture* aiGridTex;
s16 mGridPositionX;
u8 _02[0x04 - 0x02];
s16 mGridPositionY;
u8 _06[0x08 - 0x06];
s16 mGridPositionZ;
u8 _0A[0x0C - 0x0A];
s16 mWidth;
u8 _0E[0x10 - 0x0E];
s16 mHeight;
u8 _12[0x14 - 0x12];
u16 mNeighbourSize;
u8 _16[0x18 - 0x16];
};
typedef u32 HWND;
class BaseApp;
class AtxStream : public Stream {
public:
AtxStream() { init(); }
virtual void read(void* buffer, int size);
virtual void write( void* buffer, int size);
virtual int getPending();
virtual void close();
virtual void flush();
bool open( char* name, int unused);
void init() { _0C = 0; }
Stream* mStream;
int _0C;
};
class AtxCommandStream : public AtxStream {
public:
AtxCommandStream(BaseApp* app)
: mParentApp(app)
{
}
BOOL checkCommands();
BaseApp* mParentApp;
};
class AtxFileStream : public RandomAccessStream {
public:
virtual void read(void*, int);
virtual void write( void*, int);
virtual int getPending();
virtual void close();
virtual int getPosition();
virtual void setPosition(int);
virtual int getLength();
virtual void setLength(int);
bool open( char*, u32);
int mPosition;
int mLength;
AtxStream mAtxStream;
};
class AyuImage;
class Colour;
enum PROP_TYPE {
CHAR_PROP = 0,
SHORT_PROP,
INT_PROP,
FLOAT_PROP,
COLOUR_PROP,
IMAGE_PROP,
STRING_PROP,
UNK7,
CHAR_PTR_PROP,
UNK9
};
class AgeServer : public AtxStream {
public:
AgeServer() { }
virtual void close();
bool Open();
void readPropValue(PROP_TYPE type, void* val);
void writeProp(PROP_TYPE type, void* data);
void writePropValue(PROP_TYPE type, void* data);
int update();
void setSectionRefresh(IDelegate1<AgeServer&>* cmd);
void setOnChange(IDelegate1<AgeServer&>* cmd);
void setOnChange(IDelegate* cmd);
void NewNodeWindow(char* name);
void NewPropWindow(char* name, u32 a);
void RefreshSection();
void RefreshNode();
bool getOpenFilename(String& path, char* option);
bool getSaveFilename(String& path, char* option);
void NewNode(char* name, ANode* node);
void EndNode();
void Done();
void StartSection(char* name, bool unk);
void EndSection();
void StartGroup(char* name);
void EndGroup();
void NewEditor(char* name, int* val, int min, int max, int step);
void NewEditor(char* name, short* val, int min, int max, int step);
void NewEditor(char* name, char* val, int min, int max, int step);
void NewEditor(char* name, float* val, float min, float max, int step);
void NewEditor(char* name, Colour* col);
void NewEditor(char* name, char* val, int len);
void NewEditor(char* name, AyuImage* img, bool a);
void NewViewer(char* name, int* val);
void NewViewer(char* name, float* val);
void StartBitGroup(char* name, u32* val, int a);
void StartBitGroup(char* name, u8* val, int a);
void NewBit(char* name, u32 a1, u32 a2);
void EndBitGroup();
void StartOptionBox(char* name, int* val, int a);
void StartOptionBox(char* name, u8* val, int a);
void StartOptionBox(char* name, u16* val, int a);
void NewOption(char* name, int a);
void NewLabel(char* lbl);
void EndOptionBox();
void NewButton(char* name, IDelegate1<AgeServer&>* cmd, int a);
void NewButton(char* name, IDelegate* cmd, int a);
private:
bool mIsActive;
};
class Colour {
public:
Colour() { }
Colour(u8 _r, u8 _g, u8 _b, u8 _a) { set(_r, _g, _b, _a); }
void set(u8 _r, u8 _g, u8 _b, u8 _a)
{
r = _r;
g = _g;
b = _b;
a = _a;
}
void set(f32 _r, f32 _g, f32 _b)
{
r = _r;
g = _g;
b = _b;
a = 255;
}
void write(Stream&);
void lerpTo( Colour& target, f32 ratio, Colour& outColour)
{
outColour.r = (f32(target.r) - f32(r)) * ratio + f32(r);
outColour.g = (f32(target.g) - f32(g)) * ratio + f32(g);
outColour.b = (f32(target.b) - f32(b)) * ratio + f32(b);
outColour.a = (f32(target.a) - f32(a)) * ratio + f32(a);
}
void read(Stream& input)
{
r = input.readByte();
g = input.readByte();
b = input.readByte();
a = input.readByte();
}
bool operator==(u32 other)
{
u32 color = a | ((b << 8) | ((g << 16) | (r << 24)));
if (color == other) {
return true;
}
return false;
}
bool operator!=(u32 other) { return !(*this == other); }
u8 r, g, b, a;
};
class ShortColour {
public:
void read(RandomAccessStream& input)
{
r = input.readShort();
g = input.readShort();
b = input.readShort();
a = input.readShort();
}
s16 r, g, b, a;
};
class LShortColour {
public:
s16 r, g, b, a;
};
class Matrix4f;
class RandomAccessStream;
class ShortColour;
class TexAttr;
class Texture;
class PVWKeyInfoU8 {
public:
void read(RandomAccessStream& input)
{
mTime = input.readByte();
input.readByte();
input.readByte();
input.readByte();
mValue = input.readFloat();
mTangent = input.readFloat();
}
u8 mTime;
f32 mValue;
f32 mTangent;
};
class PVWKeyInfoS10 {
public:
void read(RandomAccessStream& input)
{
mTime = input.readShort();
u16 padding = input.readShort();
mValue = input.readFloat();
mTangent = input.readFloat();
}
s16 mTime;
f32 mValue;
f32 mTangent;
};
class PVWKeyInfoF32 {
public:
void read(RandomAccessStream& input)
{
mTime = input.readFloat();
mValue = input.readFloat();
mTangent = input.readFloat();
}
f32 mTime;
f32 mValue;
f32 mTangent;
};
template <typename T>
struct PVWAnimKey1 {
void read(RandomAccessStream& input)
{
mTime = input.readInt();
mData.read(input);
}
u32 mTime;
T mData;
};
template <typename T>
struct PVWAnimKey3 {
void read(RandomAccessStream& input)
{
mTime = input.readInt();
mRedData.read(input);
mGreenData.read(input);
mBlueData.read(input);
}
u32 mTime;
T mRedData;
T mGreenData;
T mBlueData;
};
template <typename T>
class PVWAnimInfo1 {
public:
u32 mSize;
PVWAnimKey1<T>* mKeyframes;
void read(RandomAccessStream& stream)
{
mSize = stream.readInt();
if (mSize != 0) {
mKeyframes = new PVWAnimKey1<T>[mSize];
for (int i = 0; i < mSize; i++) {
mKeyframes[i].read(stream);
}
}
}
};
template <typename T>
class PVWAnimInfo3 {
public:
u32 mSize;
PVWAnimKey3<T>* mKeyframes;
void read(RandomAccessStream& stream)
{
mSize = stream.readInt();
if (mSize != 0) {
mKeyframes = new PVWAnimKey3<T>[mSize];
for (int i = 0; i < (int)mSize; i++) {
mKeyframes[i].read(stream);
}
}
}
};
struct LightingControlFlags { typedef
enum {
EnableColor0 = 1 << 0,
EnableSpecular = 1 << 1,
EnableAlpha0 = 1 << 2,
DiffFnColor0Shift = 3,
DiffFnAlpha0Shift = 5,
DiffFnSpecularShift = 7,
AmbSrcColor0Vtx = 1 << 9,
AmbSrcAlpha0Vtx = 1 << 10,
MatSrcColor0Vtx = 1 << 11,
MatSrcAlpha0Vtx = 1 << 12,
} Type; } ;
class PVWLightingInfo {
public:
PVWLightingInfo()
{
mNumChans = 1;
mCtrlFlag = LightingControlFlags::EnableColor0;
_UNUSED08 = 50.0f;
}
void read(RandomAccessStream&);
u32 mCtrlFlag;
u32 mNumChans;
f32 _UNUSED08;
};
class AKeyInfo {
public:
AKeyInfo(f32 pos, f32 val, f32 inTan, f32 outTan)
: mKeyframePosition(pos)
, mValue(val)
, mEndTangent(inTan)
, mStartTangent(outTan)
{
}
f32 mKeyframePosition;
f32 mValue;
f32 mEndTangent;
f32 mStartTangent;
};
class PVWColourAnimInfo {
public:
void extract(f32, Colour&);
void read(RandomAccessStream& input) { mAnimInfo.read(input); }
PVWAnimInfo3<PVWKeyInfoU8> mAnimInfo;
};
class PVWAlphaAnimInfo {
public:
void extract(f32, Colour&);
void read(RandomAccessStream& input) { mAnimInfo.read(input); }
PVWAnimInfo1<PVWKeyInfoU8> mAnimInfo;
};
class PVWPolygonColourInfo {
public:
PVWPolygonColourInfo() { mCurrentFrame = 0.0f; }
void animate(f32*, Colour&);
void read(RandomAccessStream& input)
{
mColour.read(input);
mTotalFrameCount = input.readInt();
mSpeed = input.readFloat();
mColourInfo.read(input);
mAlphaInfo.read(input);
}
Colour mColour;
u32 mTotalFrameCount;
f32 mSpeed;
PVWColourAnimInfo mColourInfo;
PVWAlphaAnimInfo mAlphaInfo;
f32 mCurrentFrame;
};
class PVWColourShortAnimInfo {
public:
void extract(f32, ShortColour&);
PVWAnimInfo3<PVWKeyInfoS10> mInfo;
};
class PVWAlphaShortAnimInfo {
public:
void extract(f32, ShortColour&);
PVWAnimInfo1<PVWKeyInfoS10> mInfo;
};
class PVWTexAnimInfo {
public:
void extract(f32, Vector3f&);
PVWAnimInfo3<PVWKeyInfoF32> mInfo;
};
class PVWTextureData;
class PVWTexGenData;
class PVWTextureInfo {
public:
PVWTextureInfo()
{
mTevStageCount = 0;
mTexGenDataCount = 0;
}
void read(RandomAccessStream&);
Vector3f mScale;
u32 mTextureDataCount;
u32 mTexGenDataCount;
u32 mUseScale;
u32 mTevStageCount;
PVWTextureData* mTextureData;
PVWTexGenData* mTexGenData;
};
class PVWTevColReg {
public:
PVWTevColReg() { mCurrentAnimFrame = 0.0f; }
void animate(f32*, ShortColour&);
void read(RandomAccessStream& input)
{
mAnimatedColor.read(input);
mAnimFrameCount = input.readInt();
mAnimSpeed = input.readFloat();
mColorAnimData.mInfo.read(input);
mAlphaAnimData.mInfo.read(input);
}
ShortColour mAnimatedColor;
u32 mAnimFrameCount;
f32 mAnimSpeed;
PVWColourShortAnimInfo mColorAnimData;
PVWAlphaShortAnimInfo mAlphaAnimData;
f32 mCurrentAnimFrame;
};
class PVWCombiner {
public:
void read(RandomAccessStream& input)
{
mInArgA = input.readByte();
mInArgB = input.readByte();
mInArgC = input.readByte();
mInArgD = input.readByte();
mTevOp = input.readByte();
mBias = input.readByte();
mScale = input.readByte();
mDoClamp = input.readByte();
mOutReg = input.readByte();
_UNUSED09 = input.readByte();
_UNUSED0A = input.readByte();
_UNUSED0B = input.readByte();
}
u8 mInArgA;
u8 mInArgB;
u8 mInArgC;
u8 mInArgD;
u8 mTevOp;
u8 mBias;
u8 mScale;
u8 mDoClamp;
u8 mOutReg;
u8 _UNUSED09;
u8 _UNUSED0A;
u8 _UNUSED0B;
};
class PVWTevStage {
public:
void read(RandomAccessStream& input)
{
u8 _;
_UNUSED00 = input.readByte();
mTexCoordID = input.readByte();
mTexMapID = input.readByte();
mChannelID = input.readByte();
mTevKColorSel = input.readByte();
mTevKAlphaSel = input.readByte();
_ = input.readByte();
_ = input.readByte();
mTevColorCombiner.read(input);
mTevAlphaCombiner.read(input);
}
u8 _UNUSED00;
u8 mTexCoordID;
u8 mTexMapID;
u8 mChannelID;
u8 mTevKColorSel;
u8 mTevKAlphaSel;
PVWCombiner mTevColorCombiner;
PVWCombiner mTevAlphaCombiner;
};
class PVWTevInfo {
public:
void read(RandomAccessStream& input)
{
mTevColRegs[0].read(input);
mTevColRegs[1].read(input);
mTevColRegs[2].read(input);
mKonstColors[0].read(input);
mKonstColors[1].read(input);
mKonstColors[2].read(input);
mKonstColors[3].read(input);
mTevStageCount = input.readInt();
if (mTevStageCount) {
mTevStages = new PVWTevStage[mTevStageCount];
for (int i = 0; i < mTevStageCount; i++) {
mTevStages[i].read(input);
}
}
}
PVWTevColReg mTevColRegs[3];
Colour mKonstColors[4];
u32 mTevStageCount;
PVWTevStage* mTevStages;
};
class PVWTextureData {
public:
PVWTextureData()
{
mCurrentFrame = 0.0f;
mTexture = 0 ;
mIsMatrixDirty = false;
}
void animate(f32*, Matrix4f&);
void read(RandomAccessStream&);
u32 mSourceAttrIndex;
TexAttr* mTextureAttribute;
Texture* mTexture;
u16 _UNUSED0C;
u16 _UNUSED0E;
u8 _UNUSED10;
u8 _UNUSED11;
u8 _UNUSED12;
u8 _UNUSED13;
u8 mAnimationFactor;
u8 _UNUSED15;
bool mIsMatrixDirty;
u32 _UNUSED18;
f32 mScaleX;
f32 mScaleY;
f32 mRotationZ;
f32 mTranslationX;
f32 mTranslationY;
f32 mPivotX;
f32 mPivotY;
u32 mTotalFrameCount;
f32 mAnimSpeed;
PVWTexAnimInfo mScaleInfo;
PVWTexAnimInfo mRotationInfo;
PVWTexAnimInfo mTranslationInfo;
f32 mCurrentFrame;
Matrix4f mAnimatedTexMtx;
};
class PVWTexGenData {
public:
void read(RandomAccessStream& input);
u8 mTexCoordID;
u8 mTexGenType;
u8 mTexGenSrc;
u8 mMatrixType;
};
class PVWPeInfo {
public:
void read(RandomAccessStream& input)
{
mControlFlags = input.readInt();
mAlphaCompareFlags = input.readInt();
mDepthTestFlags = input.readInt();
mBlendModeFlags = input.readInt();
}
u32 mControlFlags;
u32 mAlphaCompareFlags;
u32 mDepthTestFlags;
u32 mBlendModeFlags;
};
class Graphics;
class Colour;
enum MaterialFlags {
MATFLAG_PVW = 1 << 0,
MATFLAG_Opaque = 1 << 8,
MATFLAG_AlphaTest = 1 << 9,
MATFLAG_AlphaBlend = 1 << 10,
MATFLAG_InverseColorBlend = 1 << 15,
MATFLAG_Skip = 1 << 16,
};
class Material : public CoreNode {
public:
Material()
: CoreNode("material")
{
mIndex = 0;
mEnvMapTexture = 0 ;
mTexture = 0 ;
mAttribute = 0 ;
mEnvMapTexture = 0 ;
mFlags = MATFLAG_Opaque;
colour().set(0xFF, 0xFF, 0xFF, 0xFF);
mTevInfoIndex = 0;
mDisplayListPtr = 0 ;
}
virtual void read(RandomAccessStream&);
virtual void attach();
void setColour( Colour& colour)
{
if (mLightingInfo.mCtrlFlag & LightingControlFlags::EnableSpecular) {
mTevInfo->mTevColRegs[0].mAnimatedColor.r = colour.r;
mTevInfo->mTevColRegs[0].mAnimatedColor.g = colour.g;
mTevInfo->mTevColRegs[0].mAnimatedColor.b = colour.b;
mTevInfo->mTevColRegs[0].mAnimatedColor.a = colour.a;
} else {
mColourInfo.mColour = colour;
}
}
void getColour(Colour& colour)
{
if (mLightingInfo.mCtrlFlag & LightingControlFlags::EnableSpecular) {
colour.r = mTevInfo->mTevColRegs[0].mAnimatedColor.r;
colour.g = mTevInfo->mTevColRegs[0].mAnimatedColor.g;
colour.b = mTevInfo->mTevColRegs[0].mAnimatedColor.b;
colour.a = mTevInfo->mTevColRegs[0].mAnimatedColor.a;
} else {
colour = mColourInfo.mColour;
}
}
Colour& colour() { return mColourInfo.mColour; }
u32 mIndex;
u32 mFlags;
int mTextureIndex;
TexAttr* mAttribute;
Texture* mTexture;
Texture* mEnvMapTexture;
PVWPolygonColourInfo mColourInfo;
PVWLightingInfo mLightingInfo;
PVWPeInfo mPeInfo;
PVWTextureInfo mTextureInfo;
u32 mTevInfoIndex;
PVWTevInfo* mTevInfo;
u32 mDisplayListSize;
u8* mDisplayListPtr;
};
class MatobjInfo : public GfxobjInfo {
public:
MatobjInfo()
{
mTarget = 0 ;
mString = "material";
mId.setID('_gfx');
}
virtual void attach() { mTarget->attach(); }
virtual void detach() { }
Material* mTarget;
};
class MaterialHandler {
public:
MaterialHandler() { mGfx = 0 ; }
Graphics* mGfx;
virtual void setMaterial(Material*);
virtual void setTexMatrix(bool);
};
class Colour;
class Graphics;
struct LifeGauge;
class LFlareGroup;
class GaugeInfo : public CoreNode {
public:
enum State {
STATE_FadeIn = 0,
STATE_Visible = 1,
STATE_FadeOut = 2,
};
GaugeInfo()
: CoreNode("")
{
mParentLifeGauge = 0 ;
}
void update();
void showDigits(Vector3f centerPos, Colour& colour, int number, f32 digitHalfWidth, f32 digitHalfHeight);
void refresh(Graphics& gfx);
void init();
LifeGauge* mParentLifeGauge;
u32 mState;
int mStickCount;
int mMinCount;
BOOL mIsPendingRemoval;
Vector3f mCachedOwnerPosition;
f32 mFadeInPhase;
f32 mHeightOffset;
f32 mDisplayAlpha;
f32 mDigitHalfWidth;
f32 mDigitHalfHeight;
};
class LifeGaugeMgr {
public:
LifeGaugeMgr() { init(66); }
void init(int maxGauges);
void update();
void refresh(Graphics& gfx);
GaugeInfo* getGaugeInfo();
void addLG(GaugeInfo* info);
void removeLG(GaugeInfo* info);
GaugeInfo mActiveGaugeList;
GaugeInfo mInactiveGaugeList;
LFlareGroup* mDigitFlareGroup;
Material _94;
};
struct LifeGauge {
enum RenderStyle {
Bar,
Wheel,
};
enum DisplayState {
STATE_Inactive = -1,
STATE_Hidden,
STATE_FadeIn,
STATE_Display,
STATE_FadeOut,
};
LifeGauge();
void updValue(f32 currHealth, f32 maxHealth);
void adjustValue();
void refresh(Graphics& gfx);
void countOn( Vector3f& position, int stickCount, int minCount);
void countOff();
Vector3f mPosition;
Vector3f mOffset;
int mDisplayState;
RenderStyle mRenderStyle;
bool mSnapToTargetHealth;
f32 mFadeTransitionValue;
f32 mVisibleHoldTimer;
f32 mTargetHealthRatio;
f32 mCurrentDisplayHealthRatio;
f32 mScale;
GaugeInfo* mActiveCarryNumber;
};
extern LifeGaugeMgr* lgMgr;
enum EObjType {
OBJTYPE_INVALID = -1,
OBJTYPE_Piki = 0,
OBJTYPE_Water = 1,
OBJTYPE_Seed = 2,
OBJTYPE_Key = 3,
OBJTYPE_Door = 4,
OBJTYPE_Gate = 5,
OBJTYPE_FallWater = 6,
OBJTYPE_Gem5 = 7,
OBJTYPE_Gem10 = 8,
OBJTYPE_Gem20 = 9,
OBJTYPE_Gem50 = 10,
OBJTYPE_Gem1 = 11,
OBJTYPE_GemItem = 12,
OBJTYPE_BombGen = 13,
OBJTYPE_Bomb = 14,
OBJTYPE_Pikihead = 15,
OBJTYPE_Goal = 16,
OBJTYPE_Fulcrum = 17,
OBJTYPE_Rope = 18,
OBJTYPE_Ivy = 19,
OBJTYPE_TestCylinder = 20,
OBJTYPE_TestDual = 21,
OBJTYPE_SluiceSoft = 22,
OBJTYPE_SluiceHard = 23,
OBJTYPE_SluiceBomb = 24,
OBJTYPE_SluiceBombHard = 25,
OBJTYPE_Rocket = 26,
OBJTYPE_SunsetStart = 27,
OBJTYPE_SunsetGoal = 28,
OBJTYPE_Kusa = 29,
OBJTYPE_Ufo = 30,
OBJTYPE_Weeds = 31,
OBJTYPE_Weed = 32,
OBJTYPE_RockGen = 33,
OBJTYPE_GrassGen = 34,
OBJTYPE_BoBase = 35,
OBJTYPE_Secret1 = 36,
OBJTYPE_Fish = 37,
OBJTYPE_WorkObject = 38,
OBJTYPE_BossBegin = 39,
OBJTYPE_Spider = OBJTYPE_BossBegin,
OBJTYPE_Giant = 40,
OBJTYPE_Snake = 41,
OBJTYPE_TwSnake = 42,
OBJTYPE_King = 43,
OBJTYPE_Slime = 44,
OBJTYPE_Kogane = 45,
OBJTYPE_Pom = 46,
OBJTYPE_KingBack = 47,
OBJTYPE_Nucleus = 48,
OBJTYPE_Mizu = 49,
OBJTYPE_XXX3 = 50,
OBJTYPE_BossEnd = OBJTYPE_XXX3,
OBJTYPE_Plant = 51,
OBJTYPE_Pellet = 52,
OBJTYPE_Navi = 54,
OBJTYPE_Teki = 55,
OBJTYPE_NULL = 57,
};
struct ObjType {
static char* getName(int);
static int getIndex( char*);
EObjType mIndex;
char* mName;
};
struct RefCountable {
RefCountable();
virtual void addCntCallback() { }
virtual void subCntCallback() { }
void clearCnt();
void addCnt();
void subCnt();
int getCnt() { return mCount; }
bool removable() { return mCount == 0; }
int mCount;
};
template <typename T>
struct SmartPtr {
SmartPtr() { mPtr = 0 ; }
void set(T* creature)
{
if (mPtr) {
clear();
}
mPtr = creature;
if (mPtr) {
mPtr->addCnt();
}
}
void clear()
{
if (mPtr) {
mPtr->subCnt();
mPtr = 0 ;
}
}
T* getPtr() { return mPtr; }
bool isNull() { return mPtr == 0 ; }
void reset() { mPtr = 0 ; }
T* mPtr;
};
class Creature;
class Condition {
public:
Condition() { }
virtual bool satisfy(Creature*) { return true; }
};
struct CndIsAtari : public Condition {
virtual bool satisfy(Creature*) ;
};
struct CndIsVisible : public Condition {
virtual bool satisfy(Creature*) ;
};
struct CndStickMouth : public Condition {
virtual bool satisfy(Creature*) ;
Creature* mMouthOwner;
};
class Creature;
class Traversable {
public:
inline Traversable()
: _04(0)
{
}
virtual Creature* getCreature(int) = 0;
virtual int getFirst() = 0;
virtual int getNext(int) = 0;
virtual bool isDone(int) = 0;
u32 _04;
};
struct Iterator {
Iterator(Traversable* trav, Condition* condition = 0 )
{
mTrav = trav;
mCondition = condition;
}
Creature* operator*()
{
if (mIndex == -1) {
return mTrav->getCreature(0);
}
return mTrav->getCreature(mIndex);
}
void first()
{
if (mCondition) {
mIndex = mTrav->getFirst();
while (!isDone()) {
if (mCondition->satisfy(mTrav->getCreature(mIndex))) {
break;
}
mIndex = mTrav->getNext(mIndex);
}
return;
}
mIndex = mTrav->getFirst();
}
void next()
{
if (mCondition) {
mIndex = mTrav->getNext(mIndex);
while (!isDone()) {
if (mCondition->satisfy(mTrav->getCreature(mIndex))) {
break;
}
mIndex = mTrav->getNext(mIndex);
}
return;
}
mIndex = mTrav->getNext(mIndex);
}
void dec()
{
if (mIndex >= 0) {
mIndex--;
}
}
bool isDone()
{
if (mTrav->isDone(mIndex)) {
return true;
}
if (!mTrav->getCreature(mIndex)) {
return true;
}
return false;
}
int mIndex;
Traversable* mTrav;
Condition* mCondition;
};
class Creature;
class SearchData {
public:
SearchData();
SmartPtr<Creature> mTargetCreature;
f32 mDistance;
int mSearchIteration;
};
class SearchBuffer : public Traversable {
public:
SearchBuffer();
void init(SearchData*, int);
void clear();
void invalidate();
void insertQuick(Creature*, f32);
void insert(Creature*, f32);
SearchBuffer operator=( SearchBuffer&);
int getIndex(Creature*);
void reset();
void update();
bool available() { return mDataList != 0 ; }
protected:
virtual Creature* getCreature(int);
virtual int getFirst();
virtual int getNext(int);
virtual bool isDone(int);
f32 mMaxDistance;
int mLastEntry;
u32 _10;
SearchData* mDataList;
s16 mCurrentEntries;
s16 mMaxEntries;
s16 _1C;
u32 _20;
u8 _24;
};
struct SearchSystem {
SearchSystem();
void update();
void updateLoopOptimised();
};
class Graphics;
class UpdateMgr;
class UpdateContext {
public:
UpdateContext();
bool updatable();
void init(UpdateMgr*);
void exit();
bool isPiki() { return mIsPiki; }
void setPiki(bool isPiki) { mIsPiki = isPiki; }
UpdateMgr* mMgr;
int mMgrSlotIndex;
bool mIsPiki;
};
class UpdateMgr {
public:
UpdateMgr();
void update();
bool updatable(UpdateContext*);
void create(int);
void addClient(UpdateContext*);
void removeClient(UpdateContext*);
void balanceClient(UpdateContext*);
void showInfo(Graphics&, int, int);
int mSlotCount;
int mClientTotal;
int* mClientSlotList;
int* mActiveClientSlotList;
int mCurrentIndex;
u32 mUnused14;
};
extern UpdateMgr* pikiUpdateMgr;
extern UpdateMgr* searchUpdateMgr;
extern UpdateMgr* pikiLookUpdateMgr;
extern UpdateMgr* pikiOptUpdateMgr;
extern UpdateMgr* tekiOptUpdateMgr;
class CollEvent;
class CollInfo;
class CollTriInfo;
class CollPart;
class Colour;
class Condition;
class CreatureInf;
class CreatureProp;
class DynCollObject;
class FormationMgr;
class FormPoint;
class Generator;
class Graphics;
class Interaction;
class Matrix4f;
class MoveTrace;
class Msg;
class Pellet;
class Plane;
class RandomAccessStream;
class RopeCreature;
class RouteTracer;
class SeContext;
class Sphere;
enum CreatureFlags {
CF_Unk1 = (1 << 0),
CF_Unk2 = (1 << 1),
CF_IsOnGround = (1 << 2),
CF_Unk4 = (1 << 3),
CF_EnableAirDrag = (1 << 4),
CF_SkipPhysicsAndCollision = (1 << 5),
CF_IsFlying = (1 << 6),
CF_IgnoreGravity = (1 << 7),
CF_EnableGroundOffset = (1 << 8),
CF_DisableAutoFaceDir = (1 << 9),
CF_UsePriorityFaceDir = (1 << 10),
CF_IsAiDisabled = (1 << 11),
CF_Free = (1 << 12),
CF_IsClimbing = (1 << 13),
CF_StuckToObject = (1 << 14),
CF_StuckToMouth = (1 << 15),
CF_AdjustFaceDirOnSpawn = (1 << 16),
CF_Unk17 = (1 << 17),
CF_DisableMovement = (1 << 18),
CF_UseAICulling = (1 << 19),
CF_AIAlwaysActive = (1 << 20),
CF_IsPositionFixed = (1 << 21),
CF_AllowFixPosition = (1 << 22),
};
enum CreatureStandType {
STANDTYPE_Ground = 0,
STANDTYPE_TekiPlatform = 1,
STANDTYPE_Platform = 2,
STANDTYPE_Air = 3,
STANDTYPE_COUNT,
};
struct DynCollAttachment {
Vector3f mCollSpacePosition;
};
class Creature : public RefCountable, public EventTalker {
public:
Creature(CreatureProp*);
virtual bool insideSafeArea( Vector3f&) { return true; }
virtual bool platAttachable() { return false; }
virtual bool alwaysUpdatePlatform() { return false; }
virtual bool doDoAI() { return true; }
virtual void setRouteTracer(RouteTracer*) { }
virtual void init();
virtual void init( Vector3f& pos);
virtual void resetPosition( Vector3f& pos);
virtual void initParam(int) { }
virtual void startAI(int) { }
virtual f32 getiMass() { return 100.0f; }
virtual f32 getSize() { return 15.0f; }
virtual f32 getHeight() { return 0.0f; }
virtual f32 getCylinderHeight() { return 10.0f; }
virtual void doStore(CreatureInf*) { }
virtual void doRestore(CreatureInf*) { }
virtual void doSave(RandomAccessStream&) { }
virtual void doLoad(RandomAccessStream&) { }
virtual Vector3f getCentre();
virtual f32 getCentreSize();
virtual Vector3f getBoundingSphereCentre();
virtual f32 getBoundingSphereRadius();
virtual Vector3f getShadowPos() { return mSRT.t; }
virtual void setCentre( Vector3f& centre) { mSRT.t = centre; }
virtual f32 getShadowSize();
virtual bool isVisible() { return true; }
virtual bool isOrganic() { return true; }
virtual bool isTerrible();
virtual bool isBuried() { return false; }
virtual bool isAtari() { return true; }
virtual bool isAlive() { return mHealth > 0.0f; }
virtual bool isFixed() { return false; }
virtual bool needShadow();
virtual bool needFlick(Creature*) { return true; }
virtual bool ignoreAtari(Creature*) { return false; }
virtual bool isFree() { return isCreatureFlag(CF_Free) != 0; }
virtual bool stimulate( Interaction&);
virtual void sendMsg(Msg*) { }
virtual void collisionCallback( CollEvent&) { }
virtual void bounceCallback() { }
virtual void jumpCallback() { }
virtual void wallCallback( Plane&, DynCollObject*) { }
virtual void offwallCallback(DynCollObject*) { }
virtual void stickCallback(Creature*) { }
virtual void offstickCallback(Creature*) { }
virtual void stickToCallback(Creature*) { }
virtual void dump() { }
virtual void startWaterEffect() { }
virtual void finishWaterEffect() { }
virtual bool isRopable() { return false; }
virtual bool mayIstick() { return false; }
virtual int getFormationPri() { return 128; }
virtual void update();
virtual void postUpdate(int unused, f32 deltaTime);
virtual void stickUpdate();
virtual void refresh(Graphics&) = 0;
virtual void refresh2d(Graphics&) { }
virtual void renderAtari(Graphics&);
virtual void drawShadow(Graphics&);
virtual void demoDraw(Graphics&, Matrix4f*) { }
virtual Vector3f getCatchPos(Creature*);
protected:
virtual void doAI() { }
virtual void doAnimation() { }
virtual void doKill() = 0;
public:
virtual void exitCourse() { }
void finishFixPosition();
void load(RandomAccessStream&, bool);
void save(RandomAccessStream&, bool);
Creature* getCollidePlatformCreature();
Vector3f getCollidePlatformNormal();
bool isBoss();
void enableStick();
void disableStick();
CollPart* getNearestCollPart( Vector3f&, u32);
CollPart* getRandomCollPart(u32);
void playEventSound(Creature*, int);
void stopEventSound(Creature*, int);
int getStandType();
u32 getGeneratorID();
bool setStateGrabbed(Creature*);
void resetStateGrabbed();
void turnTo( Vector3f&);
void detachGenerator();
void kill(bool);
void updateStatic();
void updateAI();
void moveVelocity();
bool getAvoid( Vector3f&, Vector3f&);
void moveRotation(f32);
void moveNew(f32);
Plane* getNearestPlane(CollTriInfo*);
void interactStickers(Creature*, Interaction&, Condition*);
void killStickers(Creature*, Condition*, int);
void startClimb();
void endClimb();
bool isStickToPlatform();
void startStickMouth(Creature*, CollPart*);
void endStickMouth();
void startStickObject(Creature*, CollPart*, int, f32);
void endStickObject();
bool startStick(Creature*, CollPart*);
void endStick();
bool startRope(RopeCreature*, f32);
void endRope();
void updateStickPlatform();
void updateStickNonPlatform();
void updateStickRope();
void startFixPosition();
bool insideSphere( Sphere&);
void adjustDistance( Vector3f&, f32);
int getAtariType();
CollTriInfo* checkForward( Vector3f&, f32, f32&);
CollTriInfo* getNextTri(CollTriInfo*, Vector3f&, int&);
void renderCollTriInfo(Graphics&, CollTriInfo*, Colour&);
bool isStickToSphere();
void adjustStickObject( Vector3f&);
bool isStickLeader();
void disableGravity() { setCreatureFlag(CF_IgnoreGravity); }
void enableGravity() { resetCreatureFlag(CF_IgnoreGravity); }
inline void setFlag400() { setCreatureFlag(CF_UsePriorityFaceDir); }
inline void resetFlag400() { resetCreatureFlag(CF_UsePriorityFaceDir); }
void setCreatureFlag(u32 flag) { mCreatureFlags |= flag; }
void resetCreatureFlag(u32 flag) { mCreatureFlags &= ~flag; }
bool isCreatureFlag(u32 flag) { return mCreatureFlags & flag; }
void enableFixPos() { setCreatureFlag(CF_AllowFixPosition); }
void disableFixPos() { resetCreatureFlag(CF_AllowFixPosition); }
void startFix() { setCreatureFlag(CF_DisableMovement); }
void finishFix() { resetCreatureFlag(CF_DisableMovement); }
void setInsideView() { setCreatureFlag(CF_AIAlwaysActive); }
void setOutsideView() { resetCreatureFlag(CF_AIAlwaysActive); }
bool insideView() { return isCreatureFlag(CF_AIAlwaysActive); }
void enableFaceDirAdjust() { setCreatureFlag(CF_AdjustFaceDirOnSpawn); }
void disableFaceDirAdjust() { resetCreatureFlag(CF_AdjustFaceDirOnSpawn); }
void startFlying()
{
setCreatureFlag(CF_IsFlying);
resetCreatureFlag(CF_Unk2);
}
void finishFlying()
{
resetCreatureFlag(CF_IsFlying);
setCreatureFlag(CF_Unk2);
}
BOOL isFlying() { return isCreatureFlag(CF_IsFlying); }
void disableAICulling() { resetCreatureFlag(CF_UseAICulling); }
void enableAICulling() { setCreatureFlag(CF_UseAICulling); }
bool aiCullable() { return !isCreatureFlag(CF_UseAICulling); }
bool isAIActive() { return !isCreatureFlag(CF_IsAiDisabled); }
void stopAI() { setCreatureFlag(CF_IsAiDisabled); }
void restartAI() { resetCreatureFlag(CF_IsAiDisabled); }
BOOL isStickToMouth() { return isCreatureFlag(CF_StuckToMouth); }
void enableGroundOffset(f32 offset)
{
setCreatureFlag(CF_EnableGroundOffset);
mGroundOffset = offset;
}
void disableGroundOffset() { resetCreatureFlag(CF_EnableGroundOffset); }
void setFree(bool) { setCreatureFlag(CF_Free); }
void enableAirResist(f32 res)
{
setCreatureFlag(CF_EnableAirDrag);
mAirResistance = res;
}
Vector3f& getPosition() { return mSRT.t; }
void inputPosition( Vector3f& pos) { mSRT.t = pos; }
void outputPosition(Vector3f& pos) { pos = mSRT.t; }
bool isGrabbed() { return !mHoldingCreature.isNull(); }
Creature* getHolder() { return mHoldingCreature.getPtr(); }
bool isHolding() { return !mGrabbedCreature.isNull(); }
Creature* getHoldCreature() { return mGrabbedCreature.getPtr(); }
CollPart* getStickPart() { return mStickPart; }
Creature* getStickObject() { return mStickTarget; }
bool isStickTo() { return mStickTarget != 0 ; }
bool isObjType(int type) { return mObjType == type; }
bool isSluice()
{
return mObjType == OBJTYPE_SluiceSoft || mObjType == OBJTYPE_SluiceHard || mObjType == OBJTYPE_SluiceBomb
|| mObjType == OBJTYPE_SluiceBombHard;
}
bool isTeki() { return mObjType == OBJTYPE_Teki; }
bool isPiki() { return mObjType == OBJTYPE_Piki; }
void setRebirthDay(int day) { mRebirthDay = day; }
int getRebirthDay() { return mRebirthDay; }
bool roughCulling(Creature* other, f32 radius) { return mGrid.doCulling(other->mGrid, radius); }
void setStateDamaged() { mIsBeingDamaged = true; }
void resetStateDamaged() { mIsBeingDamaged = false; }
bool isDamaged() { return mIsBeingDamaged; }
protected:
void moveAttach();
void respondColl(Creature*, f32, CollPart*, CollPart*, const Vector3f&);
void startStickObjectSphere(Creature*, CollPart*, f32);
void startStickObjectTube(Creature*, CollPart*);
void startStickObjectPellet(Pellet*, int, f32);
void updateStickSphere();
void updateStickPellet();
void updateStickTube();
private:
void collisionCheck(f32);
public:
Vector3f mFixedPosition;
FormPoint* mFormPoint;
SeContext* mSeContext;
u8 _30;
int mRebirthDay;
u8 _38[0x40 - 0x38];
FastGrid mGrid;
f32 mHealth;
f32 mMaxHealth;
u8 mWaterFxTimer;
Generator* mGenerator;
u32 _68;
EObjType mObjType;
Vector3f mVelocity;
SRT mSRT;
f32 mFaceDirection;
Vector3f mTargetVelocity;
Vector3f _B0;
Vector3f mVolatileVelocity;
u32 mCreatureFlags;
f32 mAirResistance;
f32 mGroundOffset;
Vector3f mPrevAngularVelocity;
Quat mRotationQuat;
Quat mPreGrabRotation;
Quat _100;
f32 _110;
Matrix4f mConstrainedMoveMtx;
Creature* mRopeListHead;
RopeCreature* mRope;
f32 mRopePosRatio;
Creature* mNextRopeHolder;
Creature* mPrevRopeHolder;
UpdateContext mSearchContext;
UpdateContext mOptUpdateContext;
Creature* mStickListHead;
Creature* mStickTarget;
CollPart* mStickPart;
Creature* mNextSticker;
Creature* mPrevSticker;
Vector3f mAttachPosition;
int mPelletStickSlot;
u32 mHasCollChangedVelocity;
u32 mCollisionOccurred;
Vector3f mLastPosition;
SearchBuffer mSearchBuffer;
LifeGauge mLifeGauge;
FormationMgr* mFormMgr;
CollInfo* mCollInfo;
CreatureProp* mProps;
Matrix4f mWorldMtx;
f32 _268;
f32 mSize;
f32 mCollisionRadius;
DynCollAttachment mCollAttachment;
DynCollObject* mCollPlatform;
Vector3f* mCollNormal;
CollTriInfo* mPikiPlatformTriangle;
CollTriInfo* mGroundTriangle;
CollTriInfo* mPreviousTriangle;
Shape* mCurrCollisionModel;
u32 _298;
Vector3f mPlatformAdjustDelta;
SmartPtr<Creature> mHoldingCreature;
SmartPtr<Creature> mGrabbedCreature;
u32 mIsFrozen;
bool mIsBeingDamaged;
};
f32 centreDist(Creature*, Creature*);
f32 sphereDist(Creature*, Creature*);
f32 qdist2(Creature*, Creature*);
f32 circleDist(Creature*, Creature*);
bool roughCull(Creature*, Creature*, f32);
void traceMove2(Creature*, MoveTrace&, f32);
struct OdoMeter {
OdoMeter();
void start(f32 startTime, f32 maxDistance);
bool moving( Vector3f& start, Vector3f& target);
void reset()
{
mTotalDistance = 0.0f;
mRemainingTime = mResetTimeValue;
}
f32 mTotalDistance;
f32 mRemainingTime;
f32 mMinAllowedDistance;
f32 mResetTimeValue;
};
class Creature;
class CmdStream;
class DataMsg;
class Graphics;
class MapMgr;
class Plane;
class BaseShape;
class PathFinder;
class Texture;
class TexAttr;
class RoutePoint;
class EditNode : public CoreNode {
public:
EditNode( char* name)
: CoreNode(name)
{
}
virtual void msgCommand(DataMsg& msg) { }
virtual void render2d(Graphics& gfx, int& textHeight) { }
};
class RouteLink : public CoreNode {
public:
RouteLink()
: CoreNode("rp")
{
mPoint = 0 ;
}
RoutePoint* mPoint;
};
class RoutePoint : public CoreNode {
public:
RoutePoint();
void loadini(CmdStream* stream);
void refresh(Graphics& gfx);
f32 mScreenX;
f32 mScreenY;
f32 mScreenDepth;
f32 mDebugDrawSize;
f32 mRadius;
Vector3f mPosition;
int mIsOpen;
int mIndex;
RouteLink mLink;
};
class RouteGroup : public EditNode {
public:
RouteGroup();
virtual void render2d(Graphics& gfx, int& textHeight);
void refresh(Graphics& gfx, EditNode* node);
void loadini(CmdStream* stream);
inline void setID(u32 id)
{
mIntID = id;
char* str = reinterpret_cast<char*>(&mIntID);
for (int i = 0; i < 4; i++) {
mStringID[i] = str[i];
}
mStringID[4] = '\0';
}
inline void updateID()
{
char* str = reinterpret_cast<char*>(&mIntID);
for (int i = 0; i < 4; i++) {
str[i] = mStringID[i];
}
}
void saveini( char* filename, RandomAccessStream& stream);
Colour mColour;
char mRouteName[0x40];
u32 mIntID;
char mStringID[8];
BaseShape* mParentShape;
RoutePoint mPointListRoot;
Texture* mDebugWaypointTexture;
};
struct WayPointFlags { typedef
enum {
InWater = 1 << 0,
Pebble = 1 << 1,
Destination = 1 << 2,
} Type; } ;
class WayPoint {
public:
struct LinkInfo {
int getInfo(int linkIdx) { return mValues[linkIdx]; }
void setInfo(int linkIdx, int value) { mValues[linkIdx] = value; }
int mValues[4];
};
WayPoint() { }
void setFlag(bool isOpen);
void refresh(Graphics& gfx);
void resetLinkInfos();
void initLinkInfos();
int getLinkIndex(int targetWpIdx);
bool inWater() { return mFlags & WayPointFlags::InWater; }
Vector3f mPosition;
f32 mRadius;
int mIndex;
int mLinkIndices[8];
int mLinkCount;
bool mIsOpen;
RoutePoint* mRoutePoint;
u8 mFlags;
LinkInfo mLinkInfos[8];
};
class RouteMgr : public Node {
public:
class Group {
public:
int getNumPoints() { return mNumPoints; }
WayPoint* mWayPoints;
int mNumPoints;
};
RouteMgr();
virtual void update();
PathFinder* getPathFinder(u32 handle);
int getNumWayPoints(u32 handle);
Vector3f getSafePosition(u32 handle, Vector3f& pos);
void findNearestEdge(WayPoint** outNearestStart, WayPoint** outNearestEnd, u32 handle, Vector3f& pos, bool allowWater,
bool requireOpen, bool avoidDestination);
void findNearestEdgeAvoidOff(WayPoint** outNearestStart, WayPoint** outNearestEnd, u32 handle, Vector3f& pos, bool allowWater,
bool requireOpen, bool avoidDestination);
WayPoint* findNearestWayPoint(u32 handle, Vector3f& pos, bool excludeWater);
WayPoint* findNearestOffWayPoint(u32 handle, Vector3f& pos, bool excludeWater);
void createOffPlane(u32 handle, Plane& plane, WayPoint* wp);
WayPoint* findNearestWayPointAll(u32 handle, Vector3f& pos);
WayPoint* getWayPoint(u32 handle, int wpIdx);
void construct(MapMgr* map);
void initLinks();
void refresh(Graphics& gfx);
void dump(u32 handle);
protected:
int id2idx(u32 id);
u32 idx2id(int idx);
int getColinIndex(RouteGroup* group, RoutePoint* point);
Group* mGroupList;
PathFinder** mPathFinders;
int mRouteCount;
u32* mRouteGroupIDs;
};
struct PathFinderMode { typedef
enum {
None = 0,
AvoidWater = 1 << 0,
AvoidOwnIndex = 1 << 1,
} Type; } ;
class PathFinder {
friend class WayPoint;
public:
class Buffer {
public:
Buffer()
{
mDirection = 0xFF;
mWayPointIdx = -1;
}
bool check(int flag) { return mDirection & (1 << flag); }
void resetFlag(int flag) { mDirection ^= (1 << flag); }
void setFlag(int flag) { mDirection |= (1 << flag); }
int mWayPointIdx;
u8 mDirection;
};
struct PathStatus { typedef
enum {
Searching = 0,
Success = 1,
Failed = 2,
} Type; } ;
class Client {
public:
Buffer* mBuffer;
int mStartWpIdx;
int mDestWpIdx;
bool mIncludeBlockedPaths;
int mHandle;
u16 mMode;
int mCurrentBufIdx;
PathStatus::Type mStatus;
bool mIsBacktracking;
int mPathLength;
};
PathFinder(RouteMgr::Group& group);
u32 findASync(Buffer* buf, int startWPIdx, int destWPIdx, bool includeBlockedPaths);
int checkASync(u32 handle);
void releaseHandle(u32 handle);
int findSync(WayPoint** pathWayPoints, int numWPsToFind, int startWPIdx, int destWPIdx, bool includeBlockedPaths);
int findSync(Buffer* bufferList, int startWPIdx, int destWPIdx, bool includeBlockedPaths);
WayPoint* getWayPoint(int wpIdx);
int selectWay(Buffer& buf, int destWPIdx, Buffer* bufferList, int wpCount, bool includeBlockedPaths);
int findSyncOnyon( Vector3f& startPos, Buffer* bufferList, int startWPIdx, int goalType, bool ignoreClosedWaypoints);
int selectWayOnyon(int additionalCost, int goalType, Buffer& buf, int destWPIdx, Buffer* bufferList, int visitedBufferCount,
bool ignoreClosedWaypoints);
int selectSecondBestWayOnyon( Vector3f& curPos, int& secondBestCost, int goalType, Buffer& buf, int destWPIdx, Buffer* bufferList,
int bufIdx, bool ignoreClosedWaypoints);
void updateASync();
int findFirstStepOnyon(int startWPIdx, int goalType, Buffer* bufferList);
static bool checkMode(int flag) { return mode & flag; }
static void clearMode() { mode = 0; }
static void setMode(int flag) { mode |= flag; }
protected:
int handle2idx(u32 handle);
void updateClient(Client& client, int loops);
static f32 limitDistance;
static int avoidWayPointIndex;
static u16 mode;
RouteMgr::Group* mGroup;
int mBufferSize;
Buffer* mBuffer;
int mHandleCount;
int mClientCount;
int mMaxClients;
Client* mClient;
};
class RouteTracer {
public:
struct Context {
struct PointInfo {
PointInfo();
Vector3f _00;
f32 _0C;
};
void makeContext(RouteTracer* tracer);
void setTarget(RouteTracer* tracer);
int recognise(RouteTracer* tracer);
PointInfo _00[3];
};
RouteTracer();
void render(Graphics& gfx);
bool noLink();
void startConsult(Creature* creature, PathFinder* pathfinder, PathFinder::Buffer* buffer, int wpCount, Vector3f& pos);
Vector3f getTarget();
protected:
void updateState();
Context mContext;
u8 _30[0x44 - 0x30];
Vector3f _44;
Vector3f _50;
Creature* _5C;
Vector3f _60;
Vector3f _6C;
Vector3f _78;
};
extern RouteMgr* routeMgr;
class Sphere;
class Cylinder {
public:
Cylinder( Vector3f& startPoint, Vector3f& endPoint, f32 radius = 1.0f)
: mStartPoint(startPoint)
, mEndPoint(endPoint)
, mRadius(radius)
{
}
f32 get2dDist( Vector3f& point) ;
bool collide(const Sphere& sphere, Vector3f& pushVector, f32& depth) ;
f32 getPosRatio(const Vector3f& point) ;
Vector3f mStartPoint;
Vector3f mEndPoint;
f32 mRadius;
};
class RectArea {
public:
RectArea(int x0, int y0, int x1, int y1)
{
mMinX = x0;
mMinY = y0;
mMaxX = x1;
mMaxY = y1;
}
RectArea()
{
mMinY = mMaxY = 0;
mMinX = mMaxX = 0;
}
void set(int minX, int minY, int maxX, int maxY)
{
mMinX = minX;
mMinY = minY;
mMaxX = maxX;
mMaxY = maxY;
}
int width() { return mMaxX - mMinX; }
int height() { return mMaxY - mMinY; }
bool pointInside(int, int) ;
int mMinX;
int mMinY;
int mMaxX;
int mMaxY;
};
class Sphere {
public:
Sphere( Vector3f& centre, f32 radius)
: mCentre(centre)
, mRadius(radius)
{
}
Vector3f mCentre;
f32 mRadius;
};
class Tube {
public:
Tube( Vector3f& start, Vector3f& end, f32 startRad, f32 endRad)
: mStartPoint(start)
, mEndPoint(end)
, mStartRadius(startRad)
, mEndRadius(endRad)
{
}
Tube() { }
f32 getYRatio(f32 heightToCheck) ;
bool collide(const Sphere&, Vector3f&, f32&) ;
f32 getPosRatio(const Vector3f&) ;
void getPosGradient( Vector3f&, f32, Vector3f&, Vector3f&) ;
Vector3f setPos(f32) ;
f32 getRatioRadius(f32) ;
Vector3f mStartPoint;
Vector3f mEndPoint;
f32 mStartRadius;
f32 mEndRadius;
};
class Plane {
public:
Plane() { }
bool equal( Plane&);
f32 calcRadScale();
void reflect(Vector3f&) ;
void reflectVector(Vector3f&) ;
void bounceVector(Vector3f&, f32) ;
void frictionVector(Vector3f&, f32) ;
void copy( Plane& other)
{
mNormal.x = other.mNormal.x;
mNormal.y = other.mNormal.y;
mNormal.z = other.mNormal.z;
mOffset = other.mOffset;
}
void copyInv( Plane& other)
{
mNormal.x = -other.mNormal.x;
mNormal.y = -other.mNormal.y;
mNormal.z = -other.mNormal.z;
mOffset = -other.mOffset;
}
f32 dist( Vector3f& point)
{
return mNormal.DP(point) - mOffset;
}
int whichSide( Vector3f& point)
{
f32 distance = dist(point);
if (distance > 0.1 ) {
return 1;
}
if (distance < -0.1 ) {
return 1;
}
return 0;
}
void write(RandomAccessStream& output)
{
mNormal.write(output);
output.writeFloat(mOffset);
}
void read(RandomAccessStream& input)
{
mNormal.read(input);
mOffset = input.readFloat();
}
Vector3f mNormal;
f32 mOffset;
};
class CmdStream;
class Creature;
class DynCollObject;
struct DynCollShape;
class ObjCollInfo;
class CollInfo;
class CollPart;
class Shape;
class BaseShape;
class RoomInfo;
class RigidBody;
class Graphics;
enum ObjCollType {
OCT_Invalid = 0,
OCT_Sphere = 1,
OCT_Platform = 2,
};
enum ObjCollFlags {
OCF_None = 0,
OCF_GetMinY = 1,
};
enum CollPartType {
PART_Collision = 0,
PART_BoundSphere = 1,
PART_Reference = 2,
PART_Platform = 3,
PART_Cylinder = 4,
PART_Tube = 5,
PART_TubeChild = 6,
};
class BaseRoomInfo {
public:
void read(RandomAccessStream& input) { mJointIndex = input.readInt(); }
int mJointIndex;
};
class RoomInfo : public BaseRoomInfo {
public:
};
class ObjCollInfo : public CoreNode {
public:
ObjCollInfo()
: CoreNode("")
{
mId.setID('none');
mCode.setID('none');
mJointIndex = -1;
mCollType = OCT_Sphere;
mRadius = 10.0f;
mCentrePosition.set(0.0f, 0.0f, 0.0f);
mParentShape = 0 ;
mPlatformName = 0 ;
mPlatShape = 0 ;
mFlags = OCF_None;
}
void loadini(CmdStream* cmdStream);
void getCentreSize(Vector3f& centre, f32& radius);
void showInfo(Graphics& gfx, Matrix4f& mtx) ;
void saveini( char* path, RandomAccessStream& output);
ID32 mId;
ID32 mCode;
u32 mCollType;
s32 mJointIndex;
Vector3f mCentrePosition;
f32 mRadius;
BaseShape* mParentShape;
Shape* mPlatShape;
char* mPlatformName;
u32 mFlags;
};
class CollPartUpdater {
public:
virtual Vector3f getPos() = 0;
virtual f32 getSize() = 0;
void updateCollPart(CollPart* part);
ID32 _04;
ID32 _10;
};
class CollPart {
public:
CollPart();
bool isStickable();
bool isClimbable();
bool isBouncy();
int getChildCount();
CollPart* getChild();
CollPart* getChildAt(int);
char* getTypeString();
ID32 getID();
ID32 getCode();
Matrix4f getMatrix();
void update(Graphics& gfx, bool drawDebug);
bool collide(CollPart* otherPart, Vector3f& pushVector);
void makeTube(Tube& tube);
bool isDamagable();
CollPart* getNext();
bool collide(Creature* collider, Vector3f& pushVector);
bool collide( Vector3f& pos, f32 radius, Vector3f& pushVector);
void makeSphere(Sphere& sphere);
void makeCylinder(Cylinder& cylinder);
bool samePlatShape(Shape* shape);
bool isTubeType() { return mPartType == PART_Tube || mPartType == PART_TubeChild; }
bool isPlatformType() { return mPartType == PART_Platform; }
bool isCollisionType() { return mPartType == PART_Collision; }
bool isSphereType() { return mPartType == PART_BoundSphere; }
bool isCylinderType() { return mPartType == PART_Cylinder; }
bool isReferenceType() { return mPartType == PART_Reference; }
bool isBouncySphereType() { return isSphereType() || isCollisionType(); }
Matrix4f getJointMatrix() { return mJointMatrix; }
f32 mRadius;
Vector3f mCentre;
Matrix4f mJointMatrix;
bool mIsUpdateActive;
bool mIsStickEnabled;
s16 mNextIndex;
s16 mFirstChildIndex;
ObjCollInfo* mCollInfo;
u8 mPartType;
CollInfo* mParentInfo;
CollPartUpdater* mPartUpdater;
};
class CollEvent {
public:
CollEvent(Creature* collider, CollPart* colliderPart, CollPart* selfPart)
{
mCollider = collider;
mColliderPart = colliderPart;
mSelfPart = selfPart;
}
Creature* mCollider;
CollPart* mColliderPart;
CollPart* mSelfPart;
};
class CndCollPart {
public:
virtual bool satisfy(CollPart*) { return false; }
};
struct CndBombable : public CndCollPart {
virtual bool satisfy(CollPart* part)
{
if (part && part->getCode().match('**b*')) {
return true;
}
return false;
}
};
class CollInfo {
friend class CollPart;
public:
CollInfo(int);
void enableStick();
void disableStick();
CollPart* checkCollisionSpecial( Vector3f& pos, f32 radius, CndCollPart* condition);
CollPart* checkCollision(Creature* creature, Vector3f& pushVector);
bool checkCollision(CollInfo* otherInfo, CollPart** outPartA, CollPart** outPartB, Vector3f& pushVector);
CollPart* getBoundingSphere();
CollPart* getSphere(u32 id);
CollPart* getNearestCollPart( Vector3f& pos, u32 tag);
CollPart* getRandomCollPart(u32 tag);
CollPart* getPlatform(DynCollObject*);
void updateInfo(Graphics& gfx, bool drawDebug);
bool hasInfo();
void initInfo(Shape*, CollPart*, u32*);
void makeTubesChild(u32, int);
void setUpdater(u32, CollPartUpdater*);
void dumpInfo();
void makeTubes(u32, int);
void startUpdate(u32);
void stopUpdate(u32);
private:
void startUpdateRec(int);
void stopUpdateRec(int);
CollPart* checkCollisionSpecialRec(int, Vector3f&, f32, CndCollPart*);
CollPart* checkCollisionRec(Creature*, int, Vector3f&);
bool checkCollisionRec(CollInfo*, int, int, CollPart**, CollPart**, Vector3f&);
void createPart(ObjCollInfo* objInfo, int depth, bool forceCollision);
int getId2Index(u32);
int getIndex(ObjCollInfo*);
void makeTree();
bool mUseDefaultMaxParts;
CollPart* mCollParts;
u32* mPartIDs;
u16 mPartsCount;
u16 mMaxParts;
Shape* mShape;
};
class BaseCollTriInfo {
public:
void read(RandomAccessStream& input)
{
mMapCode = input.readInt();
mVertexIndices[0] = input.readInt();
mVertexIndices[1] = input.readInt();
mVertexIndices[2] = input.readInt();
mCollRoomIndex = input.readShort();
mAdjacentTriIndices[0] = input.readShort();
mAdjacentTriIndices[1] = input.readShort();
mAdjacentTriIndices[2] = input.readShort();
mTriangle.read(input);
}
u32 mMapCode;
u32 mVertexIndices[3];
s16 mCollRoomIndex;
s16 mAdjacentTriIndices[3];
Plane mTriangle;
};
class CollTriInfo : public BaseCollTriInfo {
public:
CollTriInfo() { }
void init(RoomInfo* roomInfo, Vector3f* vertices);
int behindEdge( Vector3f& point);
bool inTriClampTo(Vector3f& pos)
{
pos.y = -(pos.x * mTriangle.mNormal.x + pos.z * mTriangle.mNormal.z - mTriangle.mOffset) / mTriangle.mNormal.y;
bool inTri = true;
for (int i = 0; inTri && i < 3; i++) {
f32 dist = mEdgePlanes[i].dist(pos);
if (dist < 0.0f) {
inTri = false;
}
}
return inTri;
}
Plane mEdgePlanes[3];
};
class CollGroup {
public:
CollGroup()
{
mTriangleList = 0 ;
mTriCount = 0;
mJointIndex = 0;
mFarCulledTriDistances = 0 ;
}
u8 _unused00[0x4];
s16 mTriCount;
s16 mFarCulledTriCount;
CollTriInfo** mTriangleList;
u8* mFarCulledTriDistances;
Shape* mModel;
Vector3f* mVertexList;
int mJointIndex;
DynCollShape* mPlatCollision;
CollGroup* mNextCollGroup;
};
class Collision {
public:
Collision() { }
u8 _unused00[0x4];
Vector3f mNormal;
Vector3f mContactPoint;
RigidBody* mColliderBody;
u8 _unused20[0x4];
};
class CollState {
public:
enum Status {
Unk0 = 0,
PendingCollision = 1,
Resolved = 2,
};
CollState()
{
mStatus = Resolved;
_04 = 0.0001f;
_08 = 0;
mResetCount = 0;
}
void resetCollisions(Shape* shape);
bool add( Vector3f& normal, Vector3f& contactPt, RigidBody* collider);
int mStatus;
f32 _04;
u32 _08;
int mResetCount;
int mCollisionCount;
Collision mCollisions[10];
Shape* mModel;
};
class Creature;
class PaniAnimKeyEvent;
enum MsgType {
MSG_Bounce = 0,
MSG_Hang = 1,
MSG_Target = 2,
MSG_Collide = 3,
MSG_Anim = 4,
MSG_Damage = 5,
MSG_Wall = 6,
MSG_OffWall = 7,
MSG_Stick = 8,
MSG_Ground = 9,
MSG_User = 10,
};
class Msg {
public:
inline Msg(int type)
: mMsgType(type)
{
}
int mMsgType;
};
class MsgAnim : public Msg {
public:
inline MsgAnim( PaniAnimKeyEvent* event)
: Msg(MSG_Anim)
, mKeyEvent(event)
{
}
PaniAnimKeyEvent* mKeyEvent;
};
class MsgBounce : public Msg {
public:
inline MsgBounce( Vector3f& normal)
: Msg(MSG_Bounce)
, mNormal(normal)
{
}
Vector3f mNormal;
};
class MsgCollide : public Msg {
public:
inline MsgCollide( CollEvent& event)
: Msg(MSG_Collide)
, mEvent(event)
{
}
CollEvent mEvent;
};
class MsgDamage : public Msg {
public:
inline MsgDamage()
: Msg(MSG_Damage)
{
}
};
class MsgGround : public Msg {
public:
inline MsgGround()
: Msg(MSG_Ground)
{
}
};
class MsgHang : public Msg {
public:
inline MsgHang()
: Msg(MSG_Hang)
{
}
};
class MsgOffWall : public Msg {
public:
inline MsgOffWall(DynCollObject* object)
: Msg(MSG_OffWall)
, mObject(object)
{
}
DynCollObject* mObject;
};
class MsgStick : public Msg {
public:
inline MsgStick()
: Msg(MSG_Stick)
{
}
};
class MsgTarget : public Msg {
public:
MsgTarget(Creature* target)
: Msg(MSG_Target)
{
mTarget = target;
}
Creature* mTarget;
};
class MsgUser : public Msg {
public:
inline MsgUser(int val)
: Msg(MSG_User)
{
mUserID = val;
}
int mUserID;
};
class MsgWall : public Msg {
public:
inline MsgWall( Plane& plane, DynCollObject* wall)
: Msg(MSG_Wall)
{
mWallPlane = &plane;
mWallCollObject = wall;
}
Plane* mWallPlane;
DynCollObject* mWallCollObject;
};
template <typename T>
struct Receiver {
virtual void procMsg(T* target, Msg* msg)
{
switch (msg->mMsgType) {
case MSG_Bounce:
{
procBounceMsg(target, static_cast<MsgBounce*>(msg));
break;
}
case MSG_Stick:
{
procStickMsg(target, static_cast<MsgStick*>(msg));
break;
}
case MSG_Hang:
{
procHangMsg(target, static_cast<MsgHang*>(msg));
break;
}
case MSG_Target:
{
procTargetMsg(target, static_cast<MsgTarget*>(msg));
break;
}
case MSG_Collide:
{
procCollideMsg(target, static_cast<MsgCollide*>(msg));
break;
}
case MSG_Anim:
{
procAnimMsg(target, static_cast<MsgAnim*>(msg));
break;
}
case MSG_Damage:
{
procDamageMsg(target, static_cast<MsgDamage*>(msg));
break;
}
case MSG_Wall:
{
procWallMsg(target, static_cast<MsgWall*>(msg));
break;
}
case MSG_OffWall:
{
procOffWallMsg(target, static_cast<MsgOffWall*>(msg));
break;
}
case MSG_User:
{
procUserMsg(target, static_cast<MsgUser*>(msg));
break;
}
case MSG_Ground:
{
procGroundMsg(target, static_cast<MsgGround*>(msg));
break;
}
}
}
virtual void procBounceMsg(T*, MsgBounce*) { }
virtual void procStickMsg(T*, MsgStick*) { }
virtual void procHangMsg(T*, MsgHang*) { }
virtual void procTargetMsg(T*, MsgTarget*) { }
virtual void procCollideMsg(T*, MsgCollide*) { }
virtual void procAnimMsg(T*, MsgAnim*) { }
virtual void procDamageMsg(T*, MsgDamage*) { }
virtual void procWallMsg(T*, MsgWall*) { }
virtual void procOffWallMsg(T*, MsgOffWall*) { }
virtual void procUserMsg(T*, MsgUser*) { }
virtual void procGroundMsg(T*, MsgGround*) { }
};
template <typename T>
class StateMachine;
class Msg;
template <typename T>
class AState : public Receiver<T> {
public:
inline AState(int stateID)
: mStateID(stateID)
, mStateMachine(0 )
{
}
virtual void init(T*) { }
virtual void exec(T*) { }
virtual void cleanup(T*) { }
virtual void resume(T*) { }
virtual void restart(T*) { }
virtual void transit(T* obj, int stateID)
{
mStateMachine->transit(obj, stateID);
}
int getID() { return mStateID; }
void setMachine(StateMachine<T>* owner) { mStateMachine = owner; }
char* getName() { return mName; }
void setName( char* name) { mName = name; }
protected:
int mStateID;
StateMachine<T>* mStateMachine;
char* mName;
};
template <typename T>
class StateMachine {
public:
inline StateMachine()
: mLastStateID(-1)
{
}
virtual void init(T*) { }
virtual void exec(T* target)
{
AState<T>* state = target->getCurrState();
if (state) {
state->exec(target);
}
}
virtual void procMsg(T* target, Msg* msg)
{
AState<T>* state = target->getCurrState();
if (state) {
state->procMsg(target, msg);
}
}
virtual void transit(T* target, int nextStateID)
{
isValidID(nextStateID);
int nextStateIdx = mStateIndexes[nextStateID];
AState<T>* state = target->getCurrState();
if (state) {
state->cleanup(target);
mLastStateID = state->getID();
}
if (nextStateIdx >= mStateLimit) {
while (true) {
;
}
}
state = mStates[nextStateIdx];
target->setCurrState(state);
state->init(target);
}
bool isValidID(int stateID)
{
if (stateID < 0 || stateID >= mStateLimit) {
return false;
}
return true;
}
void registerState(AState<T>* state)
{
if (mStateCount < mStateLimit) {
mStates[mStateCount] = state;
if (isValidID(state->getID())) {
state->setMachine(this);
mStateIDs[mStateCount] = state->getID();
mStateIndexes[state->getID()] = mStateCount;
mStateCount++;
}
}
}
void create(int limit)
{
mStateLimit = limit;
mStateCount = 0;
mStates = new AState<T>*[mStateLimit];
mStateIDs = new int[mStateLimit];
mStateIndexes = new int[mStateLimit];
}
int getLastStateID() { return mLastStateID; }
char* getCurrName(T* target)
{
AState<T>* state = target->getCurrState();
if (state) {
return state->getName();
}
return "no name";
}
void resume(T* target)
{
AState<T>* state = target->getCurrState();
if (state) {
state->resume(target);
}
}
void restart(T* target)
{
AState<T>* state = target->getCurrState();
if (state) {
state->restart(target);
}
}
int getCurrID(T* target)
{
AState<T>* state = target->getCurrState();
if (state) {
return state->getID();
}
return -1;
}
AState<T>** mStates;
int mStateCount;
int mStateLimit;
int* mStateIDs;
int* mStateIndexes;
int mLastStateID;
};
class Graphics;
class BoundBox {
public:
BoundBox( Vector3f& min, Vector3f& max)
{
mMin = min;
mMax = max;
}
BoundBox() { resetBound(); }
void resetBound()
{
mMin.set(32768.0f, 32768.0f, 32768.0f);
mMax.set(-32768.0f, -32768.0f, -32768.0f);
}
void expandBound( BoundBox& other)
{
if (other.mMin.x < mMin.x) {
mMin.x = other.mMin.x;
}
if (other.mMin.y < mMin.y) {
mMin.y = other.mMin.y;
}
if (other.mMin.z < mMin.z) {
mMin.z = other.mMin.z;
}
if (other.mMax.x > mMax.x) {
mMax.x = other.mMax.x;
}
if (other.mMax.y > mMax.y) {
mMax.y = other.mMax.y;
}
if (other.mMax.z > mMax.z) {
mMax.z = other.mMax.z;
}
}
void expandBound( Vector3f& other)
{
if (other.x < mMin.x) {
mMin.x = other.x;
}
if (other.y < mMin.y) {
mMin.y = other.y;
}
if (other.z < mMin.z) {
mMin.z = other.z;
}
if (other.x > mMax.x) {
mMax.x = other.x;
}
if (other.y > mMax.y) {
mMax.y = other.y;
}
if (other.z > mMax.z) {
mMax.z = other.z;
}
}
bool intersects( BoundBox& other)
{
if (other.mMin.x <= mMax.x && other.mMax.x >= mMin.x && other.mMin.y <= mMax.y && other.mMax.y >= mMin.y && other.mMin.z <= mMax.z
&& other.mMax.z >= mMin.z) {
return true;
}
return false;
}
void draw(Graphics&);
void read(RandomAccessStream& input)
{
mMin.read(input);
mMax.read(input);
}
Vector3f mMin;
Vector3f mMax;
};
class AnimContext;
class Material;
class BaseShape;
class Graphics;
class Mesh;
class Joint;
class Joint : public CoreNode {
public:
class MatPoly : public CoreNode {
public:
MatPoly()
: CoreNode("matpoly")
{
mJointList = 0;
}
MatPoly(Material* mat, Mesh* mesh)
: CoreNode("matpoly")
{
mMaterial = mat;
mMesh = mesh;
mJointList = 0;
}
Material* mMaterial;
Mesh* mMesh;
int mIndex;
int mMeshIndex;
Joint* mJointList;
};
Joint()
: CoreNode(0 )
{
mIsVisible = (1) ;
_10C = 0;
}
virtual void read(RandomAccessStream&);
void recOverrideAnim(AnimContext*);
void recShowHierarchy();
void overrideAnim(AnimContext*);
void render(Graphics&);
int mIndex;
int mParentIndex;
int mType;
BOOL mIsVisible;
Vector3f mScale;
Vector3f mRotation;
Vector3f mTranslation;
Matrix4f mAnimMatrix;
Matrix4f mInverseAnimMatrix;
bool mIsBillboard;
bool mUseVolume;
bool mUseLightGroup;
BoundBox mBounds;
MatPoly mMatPoly;
int _10C;
int mMatPolyCount;
int mCullIndex;
BaseShape* mParentShape;
};
class Graphics;
class Node;
class Plane;
class Texture;
class SceneData;
class CullingPlane {
public:
CullingPlane() { }
void CheckMinMaxDir();
Plane mPlane;
int mPVertexXIndex;
int mPVertexYIndex;
int mPVertexZIndex;
int mNVertexXIndex;
int mNVertexYIndex;
int mNVertexZIndex;
bool mIsEnabled;
};
class CullFrustum {
public:
CullFrustum()
{
_155 = false;
mPosition.set(0.0f, 0.0f, 0.0f);
mFov = 60.0f;
mNear = 1.0f;
mFar = 1000.0f;
}
bool isPointVisible( Vector3f&, f32);
void draw(Graphics&);
void updateViewPlanes(f32, f32, f32, f32);
void createViewPlanes();
void update(f32, f32, f32, f32);
void calcVectors( Vector3f&, Vector3f&);
void calcLookAt( Vector3f&, Vector3f&, Vector3f*);
void vectorToWorldPlane( Vector3f&, CullingPlane&);
void additionalPlanes(CullFrustum*);
void createVecs();
void createInvVecs();
void calcLookFrom( Vector3f&, Vector3f&);
void projectVector( Vector3f& vec, Vector3f& projVec)
{
projVec.x = vec.dot(mViewXAxis);
projVec.y = vec.dot(mViewYAxis);
projVec.z = vec.dot(mViewZAxis);
}
void setBoundOffset( Vector3f* pos)
{
mHasBoundOffset = pos != 0 ;
if (mHasBoundOffset) {
mBoundOffset = *pos;
}
}
int isBoundVisible( BoundBox& bound, int planeFlag)
{
f32* boundArray = ( f32*)&bound;
for (int i = 0; i < mActivePlaneCount; i++) {
CullingPlane* plane = mPlanePointers[i];
if (plane->mIsEnabled && (planeFlag & (1 << i))) {
if (mHasBoundOffset) {
if ((boundArray[plane->mNVertexXIndex] + mBoundOffset.x) * plane->mPlane.mNormal.x
+ (boundArray[plane->mNVertexYIndex] + mBoundOffset.y) * plane->mPlane.mNormal.y
+ (boundArray[plane->mNVertexZIndex] + mBoundOffset.z) * plane->mPlane.mNormal.z - plane->mPlane.mOffset
< 0.0f) {
return 0;
}
if ((boundArray[plane->mPVertexXIndex] + mBoundOffset.x) * plane->mPlane.mNormal.x
+ (boundArray[plane->mPVertexYIndex] + mBoundOffset.y) * plane->mPlane.mNormal.y
+ (boundArray[plane->mPVertexZIndex] + mBoundOffset.z) * plane->mPlane.mNormal.z - plane->mPlane.mOffset
>= 0.0f) {
planeFlag &= ~(1 << i);
}
} else {
if ((boundArray[plane->mNVertexXIndex]) * plane->mPlane.mNormal.x
+ (boundArray[plane->mNVertexYIndex]) * plane->mPlane.mNormal.y
+ (boundArray[plane->mNVertexZIndex]) * plane->mPlane.mNormal.z - plane->mPlane.mOffset
< 0.0f) {
return 0;
}
if ((boundArray[plane->mPVertexXIndex]) * plane->mPlane.mNormal.x
+ (boundArray[plane->mPVertexYIndex]) * plane->mPlane.mNormal.y
+ (boundArray[plane->mPVertexZIndex]) * plane->mPlane.mNormal.z - plane->mPlane.mOffset
>= 0.0f) {
planeFlag &= ~(1 << i);
}
}
}
}
return planeFlag;
}
int mTotalPlaneCount;
int mActivePlaneCount;
int mViewPlaneIdx;
CullingPlane mCullPlanes[6];
CullingPlane* mPlanePointers[6];
u8 _12C[0x154 - 0x12C];
bool mHasBoundOffset;
bool _155;
Vector3f mBoundOffset;
Vector3f mPosition;
Vector3f mFocus;
Vector3f mViewXAxis;
Vector3f mViewYAxis;
Vector3f mViewZAxis;
Vector3f mInvXAxis;
Vector3f mInvYAxis;
Vector3f mInvZAxis;
f32 mAspectRatio;
f32 mVerticalScale;
f32 mFov;
f32 mNear;
f32 mFar;
f32 mDepth;
f32 mWidth;
Matrix4f mLookAtMtx;
Matrix4f mInverseLookAtMtx;
};
class Camera : public CullFrustum {
public:
Camera();
f32 projectWorldPoint(Graphics&, Vector3f&) ;
void camReflect(Camera&, Plane&) ;
f32 projectCamPoint(Vector3f&) ;
Matrix4f mPerspectiveMatrix;
Matrix4f mProjectionMatrix;
Matrix4f _2E0;
Vector3f mRotation;
Vector3f _32C;
Vector3f _338;
f32 mBlurAlpha;
};
class LightCamera : public Camera {
public:
LightCamera() { mLightMap = 0 ; }
void initLightmap(int size, int texFmt);
void calcProjection(Graphics&, bool, Node*);
f32 mProjectionX;
f32 mProjectionY;
f32 mFrustumSize;
f32 mFrustumRange;
Texture* mLightMap;
Vector3f mProjectionScale;
};
class CamDataInfo {
public:
CamDataInfo();
void update(f32, Matrix4f&);
Vector3f mCameraPosition;
Vector3f mCameraLookAt;
Vector3f mStaticLookAt;
f32 mTargetFov;
f32 mBlendRatio;
bool mUseStaticCamera;
AnimParam mCamPosAnims[3];
AnimParam mCamLatAnims[3];
AnimParam mCamTwistAnims[1];
AnimParam mCamFovyAnims[1];
AnimParam mCamNearAnims[1];
AnimParam mCamFarAnims[1];
Camera mCamera;
int mCameraIdx;
SceneData* mSceneData;
};
class AgeServer;
class CmdStream;
class Graphics;
class Material;
class SceneData;
class Shape;
class Texture;
enum LightType {
LIGHT_None = 0,
LIGHT_Parallel = 1,
LIGHT_Point = 2,
LIGHT_Spot = 3,
LIGHT_TYPECOUNT,
};
enum SpotMode {
SPOT_NoAttn = 0,
SPOT_Linear = 1,
SPOT_Smooth = 2,
SPOT_Quadratic = 3,
SPOT_Cubic = 4,
SPOT_Quartic = 5,
SPOT_Special = 6,
};
enum LightFlag {
LIGHTFLAG_None = 0x000,
LIGHTFLAG_Unk100 = 0x100,
LIGHTFLAG_Unk200 = 0x200,
};
enum BlendMode {
BLEND_Alpha = 0,
BLEND_Additive = 1,
BLEND_Subtractive = 2,
BLEND_AlphaAdditive = 3,
BLEND_AdditiveNoZ = 4,
BLEND_AlphaTest = 5,
BLEND_MultiTexture = 6,
};
class LFInfo {
public:
LFInfo() { mPrevInfo = 0 ; }
Colour mColour;
Vector3f mFlarePos;
Vector2f mSize;
Vector2f mUvMin;
Vector2f mUvMax;
LFInfo* mPrevInfo;
};
class LightFlare : public CoreNode {
public:
LightFlare()
: CoreNode("")
{
}
void loadini(CmdStream*);
void saveini( char*, RandomAccessStream&);
f32 mSize;
Vector3f mPosition;
};
class LFlareGroup : public CoreNode {
public:
LFlareGroup()
: CoreNode("lfgroup")
{
mTexture = 0 ;
mMaterial = 0;
mLFInfo = 0 ;
mBlendMode = BLEND_Additive;
}
void addLFlare( Colour& color, Vector3f& pos, Vector2f& size, Vector2f* a5, Vector2f* a6)
{
LFInfo* info = gsys->getLFlareInfo();
if (!info) {
return;
}
info->mColour = color;
info->mFlarePos = pos;
info->mSize = size;
if (a5 && a6) {
info->mUvMin = *a5;
info->mUvMax = *a6;
} else {
info->mUvMin.set(0.0f, 0.0f);
info->mUvMax.set(1.0f, 1.0f);
}
info->mPrevInfo = mLFInfo;
mLFInfo = info;
}
u32 _14;
Texture* mTexture;
Material* mMaterial;
LFInfo* mLFInfo;
u32 mBlendMode;
};
class Light : public CoreNode {
public:
Light();
void setLightDistAttn(f32, f32, int);
void setLightSpot(f32, int);
void update();
void setLightParallel();
void calcLightSizes();
f32 calcLightMapRadius();
f32 calcLightObjRadius();
void refresh(Graphics&, LFlareGroup*);
u32 mLightFlag;
f32 mDistancedRange;
f32 mAttenuation;
f32 mSpotAngle;
u32 mMode;
u32 mSpotMode;
f32 mConstantAttn;
f32 mLinearAttn;
f32 mQuadAttn;
f32 mSpotConstTerm;
f32 mSpotLinearTerm;
f32 mSpotQuadTerm;
f32 mMapAttnThreshold;
f32 mObjAttnThreshold;
f32 mObjRadius;
f32 mMapRadius;
Vector3f mPosition;
Vector3f mDirection;
Colour mDiffuseColour;
u32 mLightValuesSet;
CullFrustum* mFrustum;
u32 _78;
u32 _7C;
CullingPlane mCullPlanes[6];
u8 _188[0x1C8 - 0x188];
u8 _1C8;
u8 _1C9;
Vector3f _1CC;
Vector3f _1D8;
Vector3f _1E4;
Vector3f _1F0;
Vector3f _1FC;
Vector3f _208;
Vector3f _214;
Vector3f _220;
Vector3f _22C;
u8 _238[0x8];
f32 _240;
f32 _244;
f32 _248;
u8 _24C[0x2D4 - 0x24C];
};
class LightGroup : public CoreNode {
public:
LightGroup()
{
mFlags = 0;
mType = 0;
mJointIndex = -1;
mTexture = 0 ;
mFlares.initCore("");
mLightColour.set(255, 255, 255, 255);
mTexSource = 0 ;
mHaloTex = 0 ;
mFlareGroup = 0 ;
}
void loadini(CmdStream*);
void refresh(Graphics&, Matrix4f*);
void saveini( char*, RandomAccessStream&);
inline LFlareGroup* getLFlareGroup() { return mFlareGroup; }
int mFlags;
int mType;
u32 mJointIndex;
Texture* mTexture;
Vector3f mDirection;
Colour mLightColour;
char* mTexSource;
char* mMatSource;
Texture* mHaloTex;
LightFlare mFlares;
Shape* mParentShape;
LFlareGroup* mFlareGroup;
};
struct LightPoolFlags { typedef
enum {
DrawDebugFrustum = 1,
} Type; } ;
struct LightPool : public Node {
LightPool();
virtual void draw(Graphics& gfx);
Light mLight;
LightCamera mCamera;
f32 mFocusRotationAngle;
Colour mColour;
Texture* mBeamTexture;
Texture* mParticleTexture;
u8 mFlags;
};
class LightDataInfo {
public:
LightDataInfo() { mLight.mDistancedRange = 1000.0f; }
void update(f32);
AnimParam mLightPosAnims[3];
AnimParam mLightColourAnims[3];
AnimParam mLightVisibleAnims[1];
int mIsActive;
Light mLight;
int mLightIdx;
SceneData* mSceneData;
};
template <typename A, typename B>
class IDelegate2;
class AnimContext;
class AnimFrameCacher;
class Camera;
class CollTriInfo;
class CmdStream;
class DispList;
class Graphics;
class Joint;
class LFlareGroup;
struct NBT;
class PVWTevInfo;
class RouteGroup;
class Texture;
class VtxMatrix;
struct NBT {
Vector3f mNormal;
Vector3f mBinormal;
Vector3f mTangent;
inline void read(RandomAccessStream& stream)
{
mNormal.read(stream);
mBinormal.read(stream);
mTangent.read(stream);
}
};
class VtxMatrix {
public:
void read(RandomAccessStream& input)
{
int weights = input.readShort();
mHasPartialWeights = (weights >= 0) ? true : false;
if (mHasPartialWeights) {
mIndex = weights;
} else {
mIndex = -weights - 1;
}
}
void write(RandomAccessStream&);
bool mHasPartialWeights;
u32 mIndex;
};
class Envelope {
public:
Envelope()
{
mIndexCount = 0;
mJointIndices = 0 ;
mWeights = 0 ;
}
void read(RandomAccessStream& stream);
s32 mIndexCount;
s32* mJointIndices;
f32* mWeights;
};
class MtxGroup {
public:
MtxGroup()
{
mDepLength = 0;
mDispLength = 0;
mDispList = 0;
}
void read(RandomAccessStream&);
int mDepLength;
int* mDepList;
int mDispLength;
DispList* mDispList;
};
class ShapeDynMaterials {
public:
ShapeDynMaterials()
: mNext(0 )
, mMatCount(0)
, mMaterials(0 )
, mModel(0 )
{
}
void animate(f32*);
void updateContext();
ShapeDynMaterials* mNext;
int mMatCount;
Material* mMaterials;
BaseShape* mModel;
};
struct DisplayListFlags { typedef
enum {
Front = 0,
Other = 1,
Both = 2,
Stripped = 0x1000000,
} Type; } ;
class DispList : public CoreNode {
public:
DispList()
{
mFaceNode.initCore("");
mNodeCount = 0;
mFaceCount = 0;
mFlags = 0;
mOglListHandle = -1;
}
DispList(int flags)
{
mFaceNode.initCore("");
mNodeCount = 0;
mFaceCount = 0;
mFlags = flags & 3;
mOglListHandle = -1;
}
virtual void read(RandomAccessStream&);
int mFlags;
int mDataLength;
u8* mData;
int mOglListHandle;
int mNodeCount;
int mFaceCount;
FaceNode mFaceNode;
};
class DlobjInfo : public GfxobjInfo {
public:
DlobjInfo();
DispList* mDispList;
};
struct BaseShapeChunk { typedef
enum {
Header = 0x00,
Vertex = 0x10,
VertexNormal = 0x11,
VertexNBT = 0x12,
VertexColour = 0x13,
TexCoord0 = 0x18,
TexCoord1 = 0x19,
TexCoord2 = 0x1A,
TexCoord3 = 0x1B,
TexCoord4 = 0x1C,
TexCoord5 = 0x1D,
TexCoord6 = 0x1E,
TexCoord7 = 0x1F,
Texture = 0x20,
TextureAttribute = 0x22,
Material = 0x30,
VertexMatrix = 0x40,
MatrixEnvelope = 0x41,
Mesh = 0x50,
Joint = 0x60,
JointName = 0x61,
CollisionPrism = 0x100,
CollisionGrid = 0x110,
EndOfFile = 0xFFFF,
} Type; } ;
struct ShapeFlags { typedef
enum {
None = 0,
AllowCaching = 1 << 1,
AlwaysRedraw = 1 << 2,
IsPlatform = 1 << 4,
} Type; } ;
struct VertexCacheFlags { typedef
enum {
None = 0,
VertexList = 1 << 0,
NormalList = 1 << 1,
NBTList = 1 << 2,
ColorList = 1 << 4,
TexCoord0 = 1 << 5,
TexCoord1 = 1 << 6,
TexCoord2 = 1 << 7,
TexCoord3 = 1 << 8,
TexCoord4 = 1 << 9,
TexCoord5 = 1 << 10,
TexCoord6 = 1 << 11,
TexCoord7 = 1 << 12,
} Type; } ;
class BaseShape : public CoreNode {
public:
BaseShape();
virtual void read(RandomAccessStream&);
virtual void optimize() { }
virtual void update() { }
virtual void render(Graphics&) { }
virtual void render2d(Graphics&) { }
virtual RouteGroup* makeRouteGroup()
{
RouteGroup* newGroup = new RouteGroup;
newGroup->mParentShape = this;
return newGroup;
}
void importIni(RandomAccessStream&);
void countMaterials(Joint*, u32);
void recTraverseMaterials(Joint*, IDelegate2<Joint*, u32>*);
ShapeDynMaterials* instanceMaterials(int);
void makeInstance(ShapeDynMaterials&, int);
void drawculled(Graphics&, Camera&, ShapeDynMaterials*);
void drawshape(Graphics&, Camera&, ShapeDynMaterials*);
void resolveTextureNames();
void recAddMatpoly(Joint*, int);
void initIni(bool);
void initialise();
void createCollisions(int);
void calcBasePose( Matrix4f&);
AnimData* loadDck( char*, RandomAccessStream&);
AnimData* importDck( char*, CmdStream*);
AnimData* loadDca( char*, RandomAccessStream&);
AnimData* loadAnimation( char* path, bool isRelativePath);
Matrix4f& getAnimMatrix(int);
void backupAnimOverrides(AnimContext**);
void restoreAnimOverrides();
void overrideAnim(int, AnimContext*);
void updateAnim(Graphics&, Matrix4f&, f32*);
void calcWeightedMatrices();
void makeNormalIndexes(u16*);
f32 calcJointWorldPos(Graphics&, int, Vector3f&);
void calcJointWorldDir(Graphics&, int, Vector3f&);
void exportIni(RandomAccessStream&, bool);
void drawobjcolls(Graphics&, Camera&);
void drawlights(Graphics&, Camera&);
void drawroutes(Graphics&, Camera&);
void skipChunk(RandomAccessStream&, u32);
void importDca( char*, CmdStream*);
void calcJointWorldScale(Graphics&, int, Vector3f&);
CollTriInfo* findCollTri(Vector3f&, Vector3f&, Vector3f&, char*);
CollGroup* getCollTris( Vector3f& pos)
{
int x = (pos.x - mCourseExtents.mMin.x) / mGridSize;
int z = (pos.z - mCourseExtents.mMin.z) / mGridSize;
if (x < 0 || z < 0 || x >= mGridSizeX || z >= mGridSizeY) {
return 0 ;
}
return mCollGroups[x + z * mGridSizeX];
}
void removeMtxDependancy() { }
u32 mShapeFlags;
AnimContext* mCurrentAnimation;
AnimContext** mAnimOverrides;
AnimContext** mBackupAnimOverrides;
AnimFrameCacher* mFrameCacher;
Matrix4f* mAnimMatrices;
u32 mAnimMtxCount;
s32 mEnvelopeCount;
Envelope* mEnvelopeList;
s32 mVtxMatrixCount;
VtxMatrix* mVtxMatrixList;
s32 mMaterialCount;
Material* mMaterialList;
s32 mTevInfoCount;
PVWTevInfo* mTevInfoList;
s32 mMeshCount;
Mesh* mMeshList;
int mJointCount;
Joint* mJointList;
s32 mTotalMatpolyCount;
Joint::MatPoly** mMatpolyList;
s32 mTexAttrCount;
TexAttr* mTexAttrList;
s32 _70;
s32 mTextureCount;
TexImg* mTextureList;
LightGroup mLightGroup;
ObjCollInfo mCollisionInfo;
u32 mVertexCacheFlags;
BoundBox mCourseExtents;
f32 mGridSize;
int mGridSizeX;
int mGridSizeY;
CollGroup** mCollGroups;
int mTriCount;
CollTriInfo* mTriList;
s32 mBaseRoomCount;
RoomInfo* mRoomInfoList;
RouteGroup mRouteGroup;
s32 mVertexCount;
Vector3f* mVertexList;
int mVtxColorCount;
Colour* mVtxColorList;
s32 mTotalActiveTexCoords;
s32 mTexCoordCounts[8];
Vector2f* mTexCoordList[8];
s32 mNormalCount;
Vector3f* mNormalList;
int mNBTCount;
NBT* mNBTList;
int mFallbackTexAttrCount;
Texture** mResolvedTextureList;
int mAttrListMatCount;
char (*mTextureNameList)[32];
u8 _2AC;
};
class Shape : public BaseShape {
public:
Shape();
virtual void optimize();
};
class CachedShape {
public:
CachedShape() { mPrev = mNext = this; }
inline void insertAfter(CachedShape* other)
{
other->mNext = mNext;
other->mPrev = this;
mNext->mPrev = other;
mNext = other;
}
CachedShape* mPrev;
CachedShape* mNext;
ShapeDynMaterials* mAnimatedMaterials;
Shape* mParentShape;
Matrix4f* mAnimMatrices;
f32 mDistanceFromOrigin;
};
inline void* operator new(size_t size)
{
return System::alloc(size);
}
inline void* operator new[](size_t size)
{
return System::alloc(size);
}
void* operator new(size_t size, int alignment);
void* operator new[](size_t size, int alignment);
void operator delete(void* ptr);
void operator delete[](void* ptr);
namespace zen {
template <typename A>
class CallBack1 {
public:
virtual bool invoke(A) = 0;
};
template <typename A, typename B>
class CallBack2 {
public:
virtual bool invoke(A, B) = 0;
};
}
class Vector3f;
class Matrix3f;
class Matrix4f;
class Quat;
namespace zen {
f32 getDistPointAndLine(Vector3f point, Vector3f lineStartPt, Vector3f lineEndPt, f32& t);
void makeRotMatrix( Vector3f&, Matrix3f&);
inline f32 correctRad(f32 val)
{
if (val < 0.0f) {
val += 6.2831855f ;
} else if (val > 6.2831855f ) {
val -= 6.2831855f ;
}
return val;
}
inline int RoundOff(f32 val)
{
return int((val >= 0.0f) ? val + 0.5f : val - 0.5f);
}
inline f32 Rand(f32 max)
{
return 1.0f * gsys->getRand(max);
}
inline f32 Abs(f32 val)
{
return (val < 0.0f) ? -val : val;
}
inline int Abs(int val)
{
return (val < 0) ? -val : val;
}
inline f32 RandShift(f32 min)
{
return Rand(2.0f * min) - min;
}
struct ZenQuat {
static void GetMatrix(const Quat&, Matrix3f&);
static void GetMatrix(const Quat&, Matrix4f&);
static void GetRotate(const Quat&, Vector3f&);
};
struct zenMatrix4f {
static void tMatrixTo(Matrix4f&, Matrix4f&);
};
}
class Colour;
namespace zen {
class bBoardColourAnimData {
public:
bBoardColourAnimData()
{
mBlendMode = 0;
mDuration = 0;
mFlags.all = 0;
mMaxFrame = 0;
mFrameThresholds = 0;
mPrimColors = 0;
mEnvColors = 0;
}
void set(u8*);
~bBoardColourAnimData() { }
u8 mBlendMode;
u8 mDuration;
union {
struct {
u8 _m0 : 1;
u8 mRotationType : 3;
u8 _m4 : 1;
u8 mOrientationSource : 1;
u8 mIsDoubleSided : 1;
u8 _m7 : 1;
} bits;
u8 all;
} mFlags;
u8 mMaxFrame;
f32* mFrameThresholds;
Colour* mPrimColors;
Colour* mEnvColors;
};
struct bBoardColourAnim {
void update(f32, Colour*, Colour*);
void init(zen::bBoardColourAnimData* data, s16 lifeTime)
{
mProgress = 0.0f;
mCurrentFrame = 0;
mAnimData = data;
if (mAnimData) {
if (mAnimData->mFlags.all) {
mDuration = lifeTime;
} else {
mDuration = mAnimData->mDuration;
}
} else {
mDuration = lifeTime;
}
}
f32 mProgress;
u8 mCurrentFrame;
s16 mDuration;
bBoardColourAnimData* mAnimData;
};
}
namespace zen {
class zenList {
public:
zenList() { mPrev = mNext = this; }
virtual void insertAfter(zenList* newList)
{
newList->mNext = mNext;
newList->mPrev = this;
mNext->mPrev = newList;
mNext = newList;
}
virtual void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
zenList* mPrev;
zenList* mNext;
};
class zenListManager {
public:
zenListManager()
{
mOrigin = &mList;
init();
}
~zenListManager() { }
void init() { mOrigin->mPrev = mOrigin->mNext = mOrigin; }
zenList* get()
{
zenList* out = 0 ;
if (mOrigin != mOrigin->mNext) {
out = mOrigin->mNext;
out->remove();
}
return out;
}
void put(zenList* list)
{
list->remove();
mOrigin->insertAfter(list);
}
zenList* getOrigin() { return mOrigin; }
zenList* getTopList() { return mOrigin->mNext; }
zenList* getBottomList() { return mOrigin->mPrev; }
void merge(zenListManager* other)
{
zenList* list = other->getTopList();
if (list != other->getOrigin()) {
zenList* end = other->getBottomList();
list->mPrev = mOrigin->mPrev->mNext;
mOrigin->mPrev->mNext = list;
mOrigin->mPrev = end;
end->mNext = mOrigin;
other->init();
}
}
int getListNum()
{
int count = 0;
for (zenList* list = getTopList(); list != getOrigin(); list = list->mNext) {
count++;
}
return count;
}
private:
zenList* mOrigin;
zenList mList;
};
}
class Colour;
class Graphics;
class Texture;
class Vector3f;
struct PtclLoadInfo {
char* mPCRPath;
char* mTex1Path;
char* mTex2Path;
};
struct GeometryLoadInfo {
char* mMODPath;
char* mAnimPath;
f32 mScale;
u8 mLoopMax;
};
struct SimplePtclLoadInfo {
char* mBTIPath;
GXColor _04;
GXColor _08;
};
namespace zen {
class particleMdl;
class particleMdlManager;
class particleGenerator;
typedef void (particleGenerator::*PtclDrawCallBack)(Graphics&);
typedef void (particleGenerator::*RotAxisCallBack)(Mtx&, f32&, f32&);
enum ParticleGeneratorControlFlags {
PTCLCTRL_Stop = 1 << 0,
PTCLCTRL_Finished = 1 << 1,
PTCLCTRL_Active = 1 << 2,
PTCLCTRL_GenStopped = 1 << 3,
PTCLCTRL_Visible = 1 << 4,
};
enum ParticleGeneratorFlags {
PTCLFLAG_EmitShapeSphere = 1 << 0,
PTCLFLAG_EmitShapeBox = 1 << 1,
PTCLFLAG_VelDirOmni = 1 << 2,
PTCLFLAG_VelDirDirectional = 1 << 3,
PTCLFLAG_ClampVelocity = 1 << 4,
PTCLFLAG_EmissionRateManual = 1 << 6,
PTCLFLAG_EmissionRateLinear = 1 << 7,
PTCLFLAG_EmissionRadiusManual = 1 << 8,
PTCLFLAG_EmissionRadiusLinear = 1 << 9,
PTCLFLAG_InitVelocityManual = 1 << 10,
PTCLFLAG_InitVelocityLinear = 1 << 11,
PTCLFLAG_DisableEmission = 1 << 12,
PTCLFLAG_EnableChildParticles = 1 << 13,
PTCLFLAG_InheritParentColor = 1 << 14,
PTCLFLAG_UseGravityField = 1 << 16,
PTCLFLAG_UseAirField = 1 << 17,
PTCLFLAG_UseVortexField = 1 << 18,
PTCLFLAG_UseDampedNewtonField = 1 << 19,
PTCLFLAG_UseNewtonField = 1 << 20,
PTCLFLAG_UseSolidTexField = 1 << 21,
PTCLFLAG_UseJitterField = 1 << 22,
PTCLFLAG_UseLineField = 1 << 23,
};
struct particleMdlBase : public zenList {
inline particleMdlBase() { InitParam(); }
virtual void remove()
{
zenList::remove();
InitParam();
}
~particleMdlBase() { }
Vector3f getPos() { return mLocalPosition + mGlobalPosition; }
void InitParam()
{
mLocalPosition.set(0.0f, 0.0f, 0.0f);
mGlobalPosition.set(0.0f, 0.0f, 0.0f);
mSize = 1.0f;
mPrimaryColor.set(0, 0, 0, 0);
}
Vector3f mLocalPosition;
Vector3f mGlobalPosition;
f32 mSize;
Colour mPrimaryColor;
};
class particleMdl : public particleMdlBase {
public:
particleMdl()
{
mBBoardColourAnim.mProgress = 0.0f;
mBBoardColourAnim.mCurrentFrame = 0;
mBBoardColourAnim.mDuration = 1;
mBBoardColourAnim.mAnimData = 0 ;
InitParam();
}
virtual void remove()
{
particleMdlBase::remove();
InitParam();
}
~particleMdl() { }
void InitParam()
{
mAge = 0;
mLifeTime = 0;
mAgeTimer = 0.0f;
mVelocity.set(0.0f, 0.0f, 0.0f);
mAlphaFactor = 0.0f;
mScaleFactor = 0.0f;
mScaleFactor = 0.0f;
mOrientedNormal.set(0.0f, 0.0f, 0.0f);
mRotAngle = 0;
mRotSpeed = 0;
mOrientedNormal.z = 1.0f;
_UNUSED4C = 0;
mEnvColor.set(0, 0, 0, 0);
mBBoardColourAnim.init(0 , 1);
mSimpleTex = 0;
}
s16 mLifeTime;
s16 mAge;
f32 mAgeTimer;
Vector3f mVelocity;
Vector3f mAcceleration;
u8 _UNUSED4C;
f32 mScaleFactor;
f32 mAlphaFactor;
u16 mRotAngle;
s16 mRotSpeed;
Vector3f mOrientedNormal;
Colour mEnvColor;
bBoardColourAnim mBBoardColourAnim;
Texture* mSimpleTex;
CallBack1<particleMdl*>* mPtclCallBack;
};
class particleChildMdl : public particleMdlBase {
public:
particleChildMdl()
{
_2C = 0.0f;
_31 = 0;
_30 = 0;
_32 = 0;
}
virtual void remove()
{
particleMdlBase::remove();
}
~particleChildMdl() { }
f32 _2C;
u8 _30;
u8 _31;
u8 _32;
};
class particleMdlManager {
public:
particleMdlManager()
{
mPtclList = 0 ;
mChildPtclList = 0 ;
}
void init(u32, u32);
~particleMdlManager() { }
int getSleepPtclNum() { return mSleepPtclList.getListNum(); }
int getSleepPtclChildNum() { return mSleepPtclChildList.getListNum(); }
void putPtcl(zenList* ptcl) { mSleepPtclList.put(ptcl); }
void putPtclChild(zenList* child) { mSleepPtclChildList.put(child); }
zenList* getPtcl() { return mSleepPtclList.get(); }
zenList* getPtclChild() { return mSleepPtclChildList.get(); }
protected:
zenListManager mSleepPtclList;
zenListManager mSleepPtclChildList;
particleMdl* mPtclList;
particleChildMdl* mChildPtclList;
};
class particleGenerator : public zenList {
public:
particleGenerator()
{
ClearPtclsStatus(0 , 0 );
mCallBack1 = 0 ;
mCallBack2 = 0 ;
mParticleFlags = 0;
mControlFlags = 0;
}
virtual void remove()
{
zenList::remove();
ClearPtclsStatus(0 , 0 );
}
~particleGenerator() { }
void init(u8* data, Texture* tex, Texture* childTex, Vector3f& pos, particleMdlManager* mdlMgr,
CallBack1<particleGenerator*>* cbGen, CallBack2<particleGenerator*, particleMdl*>* cbPtcl);
bool update(f32 timeStep);
void draw(Graphics& gfx);
void RotAxisX(Mtx&, f32&, f32&);
void RotAxisY(Mtx&, f32&, f32&);
void RotAxisZ(Mtx&, f32&, f32&);
void RotAxisXY(Mtx&, f32&, f32&);
void RotAxisXZ(Mtx&, f32&, f32&);
void RotAxisYZ(Mtx&, f32&, f32&);
void RotAxisXYZ(Mtx&, f32&, f32&);
void forceFinish();
bool finish(CallBack1<particleGenerator*>*, CallBack2<particleGenerator*, particleMdl*>*);
bool forceFinish(CallBack1<particleGenerator*>*, CallBack2<particleGenerator*, particleMdl*>*);
zenListManager& getPtclMdlListManager() { return mPtclMdlListManager; }
void setEmitPos( Vector3f& pos) { mEmitPos = pos; }
void setEmitPosPtr( Vector3f* posPtr) { mEmitPosPtr = posPtr; }
void setEmitDir( Vector3f& dir) { mEmitDir = dir; }
void setEmitVelocity( Vector3f& vel) { mEmitVelocity = vel; }
void setOrientedNormalVector( Vector3f& vec) { mOrientedNormal = vec; }
void setCallBack(CallBack1<particleGenerator*>* cb1, CallBack2<particleGenerator*, particleMdl*>* cb2)
{
mCallBack1 = cb1;
if (cb1) {
mCallBack1->invoke(this);
}
mCallBack2 = cb2;
}
Vector3f& getGPos()
{
if (mEmitPosPtr) {
return *mEmitPosPtr;
}
return mEmitPos;
}
Vector3f& getEmitPos()
{
if (mEmitPosPtr) {
return *mEmitPosPtr;
}
return mEmitPos;
}
f32 getScaleSize() { return mScaleSize; }
void setScaleSize(f32 scale) { mScaleSize = scale; }
void start() { mControlFlags &= ~PTCLCTRL_Stop; }
void stop() { mControlFlags |= PTCLCTRL_Stop; }
void startGen() { mControlFlags &= ~PTCLCTRL_GenStopped; }
void stopGen() { mControlFlags |= PTCLCTRL_GenStopped; }
void finish() { mControlFlags |= PTCLCTRL_Finished; }
void visible() { mControlFlags |= PTCLCTRL_Visible; }
void invisible() { mControlFlags &= ~PTCLCTRL_Visible; }
bool checkStop() { return mControlFlags & PTCLCTRL_Stop; }
bool checkEmit() { return !(mControlFlags & PTCLCTRL_Finished); }
bool checkActive() { return mControlFlags & PTCLCTRL_Active; }
bool checkStopGen() { return mControlFlags & PTCLCTRL_GenStopped; }
u32 getControlFlag() { return mControlFlags; }
void killParticle(particleMdl* ptcl) { pmPutParticle(ptcl); }
void setAirField( Vector3f& vel, bool set)
{
mAirFieldVelocity.set(vel);
pmSwitch(set, PTCLFLAG_UseAirField);
}
Vector3f getAirField() { return mAirFieldVelocity; }
void setNewtonField(Vector3f attractorPos, f32 strength, bool set)
{
mNewtonFieldDir.set(attractorPos - getGPos());
mNewtonFieldStrength = strength;
pmSwitch(set, PTCLFLAG_UseNewtonField);
}
f32 getNewtonFieldFrc() { return mNewtonFieldStrength; }
void setOrientedConstZAxis(bool set) { mOrientedDrawConfig.mFlipNormal = set; }
void setVortexField(Vector3f pos, f32 a, f32 b, f32 c, f32 d, bool set)
{
mVortexCenter.set(pos);
mVortexRotationSpeed = a;
mVortexStrength = b;
mVortexFalloffFactor = c;
mVortexFalloffDivisor = d;
pmSwitch(set, PTCLFLAG_UseVortexField);
}
void setGravityField( Vector3f& accel, bool set)
{
mGravFieldAccel.set(accel);
pmSwitch(set, PTCLFLAG_UseGravityField);
}
f32 getFreqFrm() { return mEmissionRate; }
void setFreqFrm(f32 freq) { mEmissionRate = freq; }
f32 getInitVel() { return mInitVel; }
void setInitVel(f32 vel) { mInitVel = vel; }
s16 getCurrentFrame() { return mCurrentFrame; }
s16 getMaxFrame() { return mMaxFrame; }
protected:
void pmSwitchOn(u32 flag) { mParticleFlags |= flag; }
void pmSwitchOff(u32 flag) { mParticleFlags &= ~flag; }
void pmSwitch(bool turnOn, u32 flag)
{
if (turnOn) {
pmSwitchOn(flag);
} else {
pmSwitchOff(flag);
}
}
void pmPutParticle(zenList* ptcl) { mMdlMgr->putPtcl(ptcl); }
void pmSetDDF(u8* data);
f32 pmIntpManual(f32*, f32*);
f32 pmIntpLinear(f32*, f32*);
particleMdl* pmGetParticle();
particleChildMdl* pmGetParticleChild();
void pmPutParticleChild(zenList* child) { mMdlMgr->putPtclChild(child); }
void pmCalcAccel(particleMdl* ptcl);
void pmGetArbitUnitVec(Vector3f& unitVec)
{
f32 angle1 = zen::Rand(6.2831855f );
f32 angle2 = zen::Rand(6.2831855f );
f32 sin1 = sinf(angle1);
f32 cos1 = cosf(angle1);
f32 sin2 = sinf(angle2);
f32 cos2 = cosf(angle2);
unitVec.set(sin1 * cos2, sin1 * sin2, cos1);
}
void ClearPtclsStatus(Texture* tex, Texture* childTex);
void SetPtclsLife();
void PtclsGen(particleMdl* ptcl);
void drawPtclBillboard(Graphics& gfx);
void drawPtclOriented(Graphics& gfx);
void drawPtclChildren(Graphics& gfx);
void UpdatePtclsStatus(f32 timeStep);
void updatePtclChildren(f32 timeStep);
Vector3f mEmitPos;
Vector3f* mEmitPosPtr;
Vector3f mEmitVelocity;
zenListManager mPtclMdlListManager;
zenListManager mPtclChildListManager;
bBoardColourAnimData mAnimData;
Texture* mTexture;
Texture* mChildTexture;
f32 mLengthScale;
f32 mPivotOffsetY;
struct {
u32 mOrientationSource : 1;
u32 mIsDoubleSided : 1;
u32 mFlipNormal : 1;
u32 m3 : 1;
u32 m4 : 1;
u32 m5 : 1;
u32 m6 : 1;
u32 m7 : 1;
u32 m8 : 1;
} mOrientedDrawConfig;
f32 mScaleRate1;
f32 mScaleRate2;
f32 mAlphaRate1;
f32 mAlphaRate2;
u16* mSolidTexFieldData;
u32 mControlFlags;
u32 mParticleFlags;
f32 mPartialParticleCount;
f32 mPassTimer;
s16 mCurrentFrame;
u8 mCurrentPass;
Vector3f mEmitPosOffset;
Vector3f mEmitDir;
Vector3f mEmissionBoxSize;
f32 mEmissionRate;
f32 mEmissionRateJitter;
f32 mEmissionSpread;
f32 mEmissionRadiusScale;
f32 mEmissionRadius;
f32 mInitVel;
f32 mInitialVelocityJitter;
f32 mDrag;
f32 mDragJitter;
f32 mMaxVel;
f32 mScaleThreshold1;
f32 mScaleThreshold2;
f32 mMinScaleFactor1;
f32 mMinScaleFactor2;
f32 mScaleSize;
f32 mSizeJitter;
f32 mAlphaThreshold1;
f32 mAlphaThreshold2;
f32 mAlphaJitter;
s16 mRotSpeedMin;
s16 mRotSpeedJitter;
s16 mRotAngle;
f32 mLifetimeJitter;
s16 mBaseLifetime;
u8 _UNUSED112;
f32 mChildScaleFactor;
f32 mChildAlphaMultiplier;
f32 mChildPosJitter;
Colour mChildColor;
u8 _124;
u8 mChildSpawnInterval;
u8 _126[0x6];
Vector3f mGravFieldAccel;
Vector3f mAirFieldVelocity;
Vector3f mVortexCenter;
f32 mVortexRotationSpeed;
f32 mVortexStrength;
f32 mVortexFalloffFactor;
f32 mVortexFalloffDivisor;
Vector3f mDampedNewtonFieldDir;
f32 mDampedNewtonFieldStrength;
Vector3f mNewtonFieldDir;
f32 mNewtonFieldStrength;
Vector3f mSolidFieldForceMultiplier;
u8 mSolidFieldGridScale;
u8 mSolidFieldSampleOffset;
u8 mSolidFieldType;
f32 mJitterStrength;
Vector3f mLineFieldAxis;
f32 mLineFieldAxialForce;
f32 mLineFieldRadialForce;
u8 mFreePtclMotionTime;
f32* mEmissionRateKeyframes;
f32* mEmissionRateValues;
f32* mEmissionRadiusKeyframes;
f32* mEmissionRadiusValues;
f32* mInitVelIntpThresholds;
f32* mInitVelIntpValues;
u8 mEmissionRateKeyCount;
u8 mEmissionRadiusKeyCount;
u8 mInitialVelocityKeyCount;
s16 mMaxFrame;
u8 mMaxPasses;
u8 mBlendFactor;
u8 mZMode;
particleMdlManager* mMdlMgr;
CallBack1<particleGenerator*>* mCallBack1;
CallBack2<particleGenerator*, particleMdl*>* mCallBack2;
Vector3f mOrientedNormal;
PtclDrawCallBack mDrawCallBack;
RotAxisCallBack mRotAxisCallBack;
};
class PCRData : public zenList {
public:
PCRData( char* name, unsigned int bufSize) { pmSet(name, bufSize); }
char* getName() { return mName; }
u8* getDataBuf() { return mDataBuf; }
protected:
u8* pmSet( char* name, unsigned int bufSize)
{
mName = StdSystem::stringDup(name);
mDataBuf = new (0x20) u8[bufSize];
return mDataBuf;
}
char* mName;
u8* mDataBuf;
};
class particleLoader : public zenListManager {
public:
u8* load( char*, bool);
~particleLoader() { }
protected:
u8* pmFind( char*);
PCRData* pmCreatePCRData( char* name, u32 bufSize)
{
PCRData* data = new PCRData(name, bufSize);
put(data);
return data;
}
};
struct simplePtclManager : public zenListManager {
public:
simplePtclManager() { mMdlMgr = 0 ; }
void update(f32);
void draw(Graphics&);
void forceFinish();
zen::particleMdl* create(Texture* simpleTex, s16 lifeTime, const Vector3f& globalPos, const Vector3f& vel, const Vector3f& accel,
f32 size, f32 rotSpeed, const Colour& primColor, const Colour& envColor,
zen::CallBack1<zen::particleMdl*>* cbPtcl);
~simplePtclManager() { }
void init(particleMdlManager* mdlMgr) { mMdlMgr = mdlMgr; }
protected:
void pmPutParticle(zenList* ptcl) { mMdlMgr->putPtcl(ptcl); }
particleMdl* pmGetParticle()
{
particleMdl* ptcl = (particleMdl*)mMdlMgr->getPtcl();
if (ptcl) {
put(ptcl);
}
return ptcl;
}
particleMdlManager* mMdlMgr;
};
class particleManager {
public:
particleManager()
{
mPtclGenList = 0 ;
_5C = 0;
}
void init(u32 numPtclGens, u32 numParticles, u32 numChildParticles, f32 p4);
particleGenerator* createGenerator(u8*, Texture*, Texture*, Vector3f&, CallBack1<particleGenerator*>*,
CallBack2<particleGenerator*, particleMdl*>*);
void update();
void draw(Graphics& gfx);
void cullingDraw(Graphics& gfx);
void killAllGenarator(bool doForceFinish);
void killGenerator(particleGenerator* gen, bool doForceFinish);
void killGenerator(CallBack1<particleGenerator*>* cb1, CallBack2<particleGenerator*, particleMdl*>* cb2, bool doForceFinish);
~particleManager() { }
void debugUpdate();
void debugDraw(Graphics&);
particleMdl* createParticle(Texture* simpleTex, s16 lifeTime, Vector3f& globalPos, Vector3f& vel, Vector3f& accel,
f32 size, f32 rotSpeed, Colour primColor, Colour envColor, CallBack1<particleMdl*>* cbPtcl)
{
return mSimplePtclMgr.create(simpleTex, lifeTime, globalPos, vel, accel, size, rotSpeed, primColor, envColor, cbPtcl);
}
static const f32 DEFAULT_FRAME_RATE;
protected:
void calcActiveList();
bool pmCheckList(particleGenerator* testGen);
particleGenerator* pmGetPtclGen();
void pmPutPtclGen(zenList* gen) { _20.put(gen); }
static const u16 MAX_PTCLGENS_NUM;
static const u16 MAX_PTCLS_NUM;
static const u16 MAX_PTCL_CHILD_NUM;
zenListManager mActiveGenList;
zenListManager mInactiveGenList;
zenListManager _20;
particleGenerator* mPtclGenList;
particleMdlManager mMdlMgr;
u32 _5C;
simplePtclManager mSimplePtclMgr;
u32 mMaxPtclGens;
u32 mMaxParticles;
u32 mMaxChildParticles;
u32 mActivePtclGenCount;
u32 mActiveParticleCount;
u32 mActiveChildParticleCount;
u32 mMaxUsedPtclGenCount;
u32 mMaxUsedParticleCount;
u32 mMaxUsedChildParticleCount;
f32 _98;
};
struct PtclGenPack {
public:
inline PtclGenPack(int limit)
{
mLimit = limit;
mGeneratorList = new particleGenerator*[mLimit];
for (int i = 0; i < mLimit; i++) {
mGeneratorList[i] = 0 ;
}
}
void setPtclGenPtr(u32, particleGenerator*);
void setEmitPosPtr( Vector3f*);
void startGen();
void stopGen();
void finish();
void forceFinish();
bool checkStopGen();
particleGenerator* getPtclGenPtr(u32 idx);
void setEmitPos( Vector3f&);
void setEmitDir( Vector3f&);
void setCallBack(CallBack1<particleGenerator*>*, CallBack2<particleGenerator*, particleMdl*>*);
void start();
void stop();
bool checkStop();
bool checkEmit();
bool checkActive();
protected:
u32 mLimit;
particleGenerator** mGeneratorList;
};
extern u16* UseSolidTex[6];
}
class Texture;
struct EffectParticleRegistration;
struct EffectGeometryRegistration;
struct EffectSimpleParticleRegistration;
struct SmokeEmitter : public Node {
class Smoke {
public:
Smoke() { mNext = mPrev = 0 ; }
void insertAfter(Smoke* newSmoke)
{
newSmoke->mNext = mNext;
newSmoke->mPrev = this;
mNext->mPrev = newSmoke;
mNext = newSmoke;
}
void remove()
{
mNext->mPrev = mPrev;
mPrev->mNext = mNext;
}
Vector3f mPosition;
f32 mSize;
Smoke* mNext;
Smoke* mPrev;
f32 mLifeTimer;
f32 mExpandRate;
f32 mAlpha;
f32 mAlphaIncRate;
f32 mMaxSize;
Vector3f mVelocity;
};
SmokeEmitter(int, Texture*);
virtual void draw(Graphics&);
Smoke* emit( Vector3f&, Vector3f&);
void update(f32);
Smoke* mSmokes;
int mSmokeCount;
int mBlendMode;
Smoke* mActiveSmokeList;
Smoke* mInactiveSmokeList;
Texture* mTexture;
Shape* mModel;
};
struct EffectShape : public CoreNode {
EffectShape()
: CoreNode("")
{
}
EffectShape( char* modelFile)
: CoreNode("")
{
initShape(modelFile);
}
void initShape( char*);
bool update();
void refresh(Graphics&, Matrix4f&, f32*);
Shape* mModel;
ShapeDynMaterials mAnimatedMaterials;
};
class EffShpInst : public CoreNode {
public:
EffShpInst()
: CoreNode("")
{
initEffShpInst();
visible();
}
bool update();
void initEffShpInst();
void draw(Graphics&);
bool isVisible() { return mIsVisible; }
void visible() { mIsVisible = true; }
void setLoop(u8 loop) { mLoop = loop; }
void setLoopMax(u8 max) { mLoopMax = max; }
void invisible();
SRT mSRT;
EffectShape* mEffectShape;
f32 _3C;
u8 mLoop;
u8 mLoopMax;
bool mIsVisible;
};
class EffectMgr : public CoreNode {
friend struct EffectParticleRegistration;
friend struct EffectGeometryRegistration;
friend struct EffectSimpleParticleRegistration;
public:
enum effTypeTable {
EFF_NULL = -1,
EFF_Rocket_NaviRecover = 0,
EFF_Rocket_NaviNormalRings = 1,
EFF_Rocket_NaviActionRings = 2,
EFF_Rocket_NaviSparkle = 3,
EFF_Navi_DamageA = 4,
EFF_Navi_DamageB = 5,
EFF_Navi_DamageC = 6,
EFF_Navi_PunchA = 7,
EFF_Navi_PunchB = 8,
EFF_Navi_Whistle3 = 9,
EFF_Navi_Whistle2 = 10,
EFF_Navi_Whistle1 = 11,
EFF_RippleSurface = 12,
EFF_RippleBlack = 13,
EFF_RippleWhite = 14,
EFF_P_Bubbles = 15,
EFF_Kogane_Walk3 = 16,
EFF_Kogane_Walk2 = 17,
EFF_Kogane_Walk1 = 18,
EFF_Kogane_Walk0 = 19,
EFF_Navi_WhistleCursor = 20,
EFF_Navi_Light = 21,
EFF_Navi_LightGlow = 22,
EFF_BombLight_Bang = 23,
EFF_BombLight_Wave = 24,
EFF_BombLight_FireBang = 25,
EFF_BombLight_FireGlow = 26,
EFF_Piki_DeflowerPetals = 27,
EFF_Piki_DeflowerSpores = 28,
EFF_Piki_FireRecover = 29,
EFF_Bomb_Bang = 30,
EFF_Bomb_Wave = 31,
EFF_Bomb_Glow = 32,
EFF_Bomb_DustRing = 33,
EFF_Bomb_FireBang = 34,
EFF_Bomb_FireGlow = 35,
EFF_Piki_Bubble = 36,
EFF_Piki_BubbleRecover = 37,
EFF_Piki_DeadSoul = 38,
EFF_Piki_WorkCloud = 39,
EFF_Piki_IdleYellow = 40,
EFF_Piki_IdleRed = 41,
EFF_Piki_IdleBlue = 42,
EFF_Piki_Fire = 43,
EFF_Piki_FireSparkles = 44,
EFF_Piki_GrowUp1 = 45,
EFF_Piki_GrowUp2 = 46,
EFF_Piki_HitA = 47,
EFF_Piki_HitB = 48,
EFF_SD_Sparkle = 49,
EFF_SD_DirtCloud = 50,
EFF_SD_DirtSpray = 51,
EFF_RippleWhite2 = 52,
EFF_RippleBlack2 = 53,
EFF_RippleSurface2 = 54,
EFF_Teki_DeathWaveL = 55,
EFF_Teki_DeathGlowL = 56,
EFF_Teki_DeathSmokeL = 57,
EFF_Teki_DeathWaveM = 58,
EFF_Teki_DeathGlowM = 59,
EFF_Teki_DeathSmokeM = 60,
EFF_Teki_DeathWaveS = 61,
EFF_Teki_DeathGlowS = 62,
EFF_Teki_DeathSmokeS = 63,
EFF_Teki_SoulL = 64,
EFF_Teki_SoulM = 65,
EFF_Teki_SoulS = 66,
EFF_SmokeRing_M = 67,
EFF_SmokeRing_S = 68,
EFF_Piki_BigHit = 69,
EFF_GrowPellet_A1 = 70,
EFF_GrowPellet_A2 = 71,
EFF_GrowPellet_B = 72,
EFF_GrowPellet_C = 73,
EFF_Slime_DeadI = 74,
EFF_Slime_DeadK = 75,
EFF_Miurin_Attack = 76,
EFF_Miurin_A01 = 77,
EFF_Miurin_A02 = 78,
EFF_Kabekui_EatBridgeA = 79,
EFF_Kabekui_EatBridgeB = 80,
EFF_Frog_BubbleRingL = 81,
EFF_Frog_Bubble2 = 82,
EFF_Frog_Water1 = 83,
EFF_Frog_Water2 = 84,
EFF_Frog_BubbleRingS = 85,
EFF_Mizinko_Spawn = 86,
EFF_Kogane_SmokeL = 87,
EFF_Kogane_SmokeR = 88,
EFF_Kogane_Hit = 89,
EFF_Iwagon_Start1 = 90,
EFF_Shell_Boom = 91,
EFF_Shell_Twinkle = 92,
EFF_Collec_Ashi = 93,
EFF_Collec_Hiki = 94,
EFF_Collec_StA = 95,
EFF_Collec_StB = 96,
EFF_Collec_HmA = 97,
EFF_Collec_HmB = 98,
EFF_Tank_Smoke = 99,
EFF_Tank_Fire = 100,
EFF_Chappy_SnoreBubble = 101,
EFF_King_Slip = 102,
EFF_King_StepCloud = 103,
EFF_King_SeedFlash = 104,
EFF_King_Flick = 105,
EFF_King_Jump = 106,
EFF_King_DeadA = 107,
EFF_King_DeadB = 108,
EFF_King_DeadC = 109,
EFF_King_DeadD = 110,
EFF_King_DeadE = 111,
EFF_King_AppearA = 112,
EFF_King_AppearB = 113,
EFF_King_AppearC = 114,
EFF_King_AppearD = 115,
EFF_King_Saliva1A = 116,
EFF_King_Saliva1B = 117,
EFF_King_Saliva2 = 118,
EFF_King_SalivaDroplet = 119,
EFF_CloudOfDust_2 = 120,
EFF_CloudOfDust_1 = 121,
EFF_King_EatBomb1 = 122,
EFF_King_EatBomb2 = 123,
EFF_King_EatBomb3 = 124,
EFF_King_SpitParts = 125,
EFF_Snake_Appear1 = 126,
EFF_Snake_Appear2 = 127,
EFF_Snake_OnGround = 128,
EFF_Snake_Rotate = 129,
EFF_Snake_DeadHeadCloud = 130,
EFF_Snake_DeadHeadFeathers = 131,
EFF_Snake_DeadHeadSpecks = 132,
EFF_Snake_DeadBody1 = 133,
EFF_Snake_DeadBodyExplode = 134,
EFF_Snake_DeadBody2 = 135,
EFF_Beatle_Flick1 = 136,
EFF_Beatle_ShootRockHalo = 137,
EFF_Beatle_ShootRockSpecks = 138,
EFF_Beatle_Flick2 = 139,
EFF_Beatle_Flick3 = 140,
EFF_Beatle_EyeGlow = 141,
EFF_Beatle_SuckAir1 = 142,
EFF_Beatle_SuckAir2 = 143,
EFF_Beatle_RockClouds = 144,
EFF_Beatle_RockSpray = 145,
EFF_Beatle_RockBlast = 146,
EFF_Iwagon_Start2 = 147,
EFF_Kinoko_DeathSpores = 148,
EFF_Kinoko_DeathSmoke = 149,
EFF_Kinoko_ChargeSpores = 150,
EFF_Kinoko_SporesUp = 151,
EFF_Kinoko_AttackCloud = 152,
EFF_Kinoko_PostAttackCloud = 153,
EFF_Kinoko_AttackSpores = 154,
EFF_Kinoko_PostAttackSpores = 155,
EFF_Kinoko_EyeGlow = 156,
EFF_Dororo_Eye = 157,
EFF_Onyon_FireworkTrail = 158,
EFF_Onyon_FireworkMain = 159,
EFF_Onyon_FireworkKisek = 160,
EFF_Onyon_FireworkSmall = 161,
EFF_Dororo_DeadFragments = 162,
EFF_Dororo_HowlZigZags = 163,
EFF_Dororo_HowlRipples = 164,
EFF_Dororo_HowlHalo = 165,
EFF_Dororo_DeadFumes = 166,
EFF_Tamago_DeadFumes = 167,
EFF_Tamago_EyeGlow = 168,
EFF_Tamago_DeadFragments = 169,
EFF_Tamago_DeadSmoke = 170,
EFF_Dororo_BodyFragments = 171,
EFF_Dororo_BodySpecks = 172,
EFF_Dororo_BodyTrail = 173,
EFF_Dororo_BodyGlow = 174,
EFF_Dororo_BodySmoke = 175,
EFF_Mar_WindJet = 176,
EFF_Mar_WindSpray = 177,
EFF_Mar_WindDust = 178,
EFF_Mar_DeadSmoke = 179,
EFF_Mar_DeadJet = 180,
EFF_Spider_OffGroundDebris = 181,
EFF_Spider_OffGroundSmoke = 182,
EFF_Spider_HalfDeadFall = 183,
EFF_Spider_HalfDead = 184,
EFF_Spider_DeadBombDebris = 185,
EFF_Spider_DeadBombSmoke = 186,
EFF_Spider_UnusedDeadBombDebris = 187,
EFF_Spider_UnusedDeadBombSmoke = 188,
EFF_Spider_DeadBombSparks = 189,
EFF_Spider_SmallSparks = 190,
EFF_Spider_PerishSmoke = 191,
EFF_Spider_PerishBubbles = 192,
EFF_Mizu_IdleBubbles = 193,
EFF_Mizu_IdleMist = 194,
EFF_Mizu_JetStream = 195,
EFF_Mizu_JetPuff = 196,
EFF_Mizu_JetMist = 197,
EFF_Kusa_Extend1 = 198,
EFF_Kusa_Extend2 = 199,
EFF_Weed_Pull = 200,
EFF_Weed_Rocks = 201,
EFF_Weed_Smoke = 202,
EFF_Onyon_HaloRingYellow = 203,
EFF_Onyon_HaloRingRed = 204,
EFF_Onyon_HaloRingBlue = 205,
EFF_Onyon_BeaconRingYellow = 206,
EFF_Onyon_BeaconRingRed = 207,
EFF_Onyon_BeaconRingBlue = 208,
EFF_WL_Hit3 = 209,
EFF_WL_Hit2 = 210,
EFF_Empl_20 = 211,
EFF_Empl_10 = 212,
EFF_Empl_05 = 213,
EFF_Empl_01 = 214,
EFF_Bridge_FinishStage = 215,
EFF_Onyon_Sparkles = 216,
EFF_Onyon_Puff = 217,
EFF_HinderRock_MoveFront = 218,
EFF_HinderRock_MoveSides = 219,
EFF_Wl_Brk01 = 220,
EFF_Wl_Brk00 = 221,
EFF_Wl_Hit1 = 222,
EFF_Wl_Hit0 = 223,
EFF_BigDustRing = 224,
EFF_Onyon_Suck = 225,
EFF_Onyon_ActEffect = 226,
EFF_Hiba_Fire = 227,
EFF_Rocket_Opa1 = 228,
EFF_Rocket_SmokeD = 229,
EFF_Rocket_SSLight = 230,
EFF_MTotl01 = 231,
EFF_MTotl03 = 232,
EFF_Rocket_Land = 233,
EFF_MC_Bang = 234,
EFF_MC_Debris = 235,
EFF_Onyon_BubblesSmall = 236,
EFF_Onyon_Bubbles = 237,
EFF_Onyon_Ripples1 = 238,
EFF_Onyon_Ripples2 = 239,
EFF_Rocket_Complete1 = 240,
EFF_Rocket_Complete2 = 241,
EFF_Rocket_1Meteor = 242,
EFF_Rocket_3Meteor = 243,
EFF_Rocket_4Meteor = 244,
EFF_Rocket_5Meteor = 245,
EFF_Rocket_6Meteor = 246,
EFF_Rocket_7Meteor = 247,
EFF_Rocket_7Meteor2 = 248,
EFF_Rocket_SCT01 = 249,
EFF_Rocket_SCT02 = 250,
EFF_Rocket_SCT03 = 251,
EFF_Rocket_SCT01C = 252,
EFF_Rocket_SCT02C = 253,
EFF_Rocket_SCT01CC = 254,
EFF_Rocket_SCT03C = 255,
EFF_Rocket_SCT02CC = 256,
EFF_Rocket_SCT03CC = 257,
EFF_Rocket_SCT00N = 258,
EFF_Rocket_JetG01 = 259,
EFF_Rocket_JetG02 = 260,
EFF_Rocket_JetG03 = 261,
EFF_Rocket_Bst1da = 262,
EFF_Rocket_Bst1db = 263,
EFF_Rocket_Bstg = 264,
EFF_Rocket_MkB = 265,
EFF_Rocket_MkS = 266,
EFF_Rocket_Hiba = 267,
EFF_Rocket_Biri = 268,
EFF_Rocket_TakeS = 269,
EFF_Rocket_Tbc1 = 270,
EFF_Rocket_Tbf1 = 271,
EFF_Rocket_Tbf2 = 272,
EFF_Rocket_BeBomK = 273,
EFF_Rocket_BeBomP = 274,
EFF_Rocket_BeBomH = 275,
EFF_Rocket_BeBomW = 276,
EFF_Rocket_BeBomC = 277,
EFF_Rocket_WakeK1 = 278,
EFF_Rocket_WakeK2 = 279,
EFF_Rocket_WakeP1 = 280,
EFF_Rocket_WakeP2 = 281,
EFF_Rocket_Bst1cb = 282,
EFF_Rocket_Bst1fa = 283,
EFF_Rocket_Bst1fb = 284,
EFF_Rocket_PCA1 = 285,
EFF_Rocket_PCA2 = 286,
EFF_Rocket_Gep = 287,
EFF_Rocket_Suck1 = 288,
EFF_Onyon_Suck2 = 289,
EFF_Rocket_Bm1o = 290,
EFF_Rocket_Bm2o = 291,
EFF_UfoPart_ASN01 = 292,
EFF_UfoPart_ASN02 = 293,
EFF_UfoPart_KafunB = 294,
EFF_Kafun_BS = 295,
EFF_Kafun_NG = 296,
EFF_Rocket_FlowLight = 297,
EFF_Rocket_LandS = 298,
EFF_Rocket_C = 299,
EFF_Rocket_NJ1CA = 300,
EFF_Rocket_NJ1CB = 301,
EFF_Rocket_NJ1FA = 302,
EFF_Rocket_NJ1FB = 303,
EFF_Rocket_NJ1CA2 = 304,
EFF_Rocket_NJ1CB2 = 305,
EFF_Rocket_NJ1FA2 = 306,
EFF_Rocket_NJ1FB2 = 307,
EFF_Rocket_NJ1CA3 = 308,
EFF_Rocket_NJ1CB3 = 309,
EFF_Rocket_NJ1FA3 = 310,
EFF_Rocket_NJ1FB3 = 311,
EFF_Rocket_NJ1CA4 = 312,
EFF_Rocket_NJ1CB4 = 313,
EFF_Rocket_NJ1FA4 = 314,
EFF_Rocket_NJ1FB4 = 315,
EFF_Rocket_NJ2CA = 316,
EFF_Rocket_NJ2CB = 317,
EFF_Rocket_NJ2FA = 318,
EFF_Rocket_NJ2FB = 319,
EFF_Rocket_NJ3CA = 320,
EFF_Rocket_NJ3CB = 321,
EFF_Rocket_NJ3FA = 322,
EFF_Rocket_NJ3FB = 323,
EFF_Rocket_NJ3FB2 = 324,
EFF_Rocket_Sparkles1 = 325,
EFF_Rocket_Bm1 = 326,
EFF_Rocket_Bm2 = 327,
EFF_Rocket_Suck2 = 328,
EFF_Rocket_Nke1 = 329,
EFF_Rocket_Nke2 = 330,
EFF_Rocket_Fkm1 = 331,
EFF_COUNT,
};
enum modelTypeTable {
MOD_BlueOnyon = 0,
MOD_RedOnyon = 1,
MOD_YellowOnyon = 2,
MOD_COUNT,
};
enum simpleTypeTable {
SIMPLE_Horoki = 0,
SIMPLE_COUNT,
};
EffectMgr();
void update();
void draw(Graphics&);
void drawshapes(Graphics&);
void exit();
zen::particleGenerator* create(EffectMgr::effTypeTable, Vector3f&, zen::CallBack1<zen::particleGenerator*>*,
zen::CallBack2<zen::particleGenerator*, zen::particleMdl*>*);
EffShpInst* create(EffectMgr::modelTypeTable, Vector3f&, Vector3f&, Vector3f&);
EffShpInst* getShapeInst();
void killAllShapes();
zen::particleMdl* create(EffectMgr::simpleTypeTable, Vector3f&, s16, Vector3f&, Vector3f&, f32, f32,
zen::CallBack1<zen::particleMdl*>*);
void putShapeInst(EffShpInst*);
void kill(zen::CallBack1<zen::particleGenerator*>* cb1, zen::CallBack2<zen::particleGenerator*, zen::particleMdl*>* cb2,
bool doForceFinish)
{
mPtclMgr.killGenerator(cb1, cb2, doForceFinish);
}
void kill(zen::particleGenerator* gen, bool doForceFinish) { mPtclMgr.killGenerator(gen, doForceFinish); }
void killAll()
{
mPtclMgr.killAllGenarator(true);
killAllShapes();
}
void cullingOn() { mDoCulling = true; }
void cullingOff() { mDoCulling = false; }
protected:
void initEffectGeometry(int);
zen::particleManager mPtclMgr;
zen::particleLoader mPtclLoader;
EffectShape mEffectShapeList;
EffShpInst mInactiveGeomList;
EffShpInst mActiveGeomList;
EffectParticleRegistration* mParticles[EFF_COUNT];
EffectSimpleParticleRegistration* mSimpleParticles[SIMPLE_COUNT];
EffectGeometryRegistration* mModels[MOD_COUNT];
bool mDoCulling;
};
extern EffectMgr* effectMgr;
struct EffectParticleRegistration {
EffectParticleRegistration( char*, char*, char*);
virtual zen::particleGenerator* create( Vector3f& pos, zen::CallBack1<zen::particleGenerator*>* cbGen,
zen::CallBack2<zen::particleGenerator*, zen::particleMdl*>* cbPtcl)
{
return effectMgr->mPtclMgr.createGenerator(mPtclData, mPtclTex, mChildPtclTex, pos, cbGen, cbPtcl);
}
u8* mPtclData;
Texture* mPtclTex;
Texture* mChildPtclTex;
};
struct EffectGeometryRegistration {
EffectGeometryRegistration( char*, char*, f32, u8);
virtual EffShpInst* create( Vector3f&, Vector3f&, Vector3f&);
EffectShape* mEffectShape;
f32 mScale;
u8 mLoopMax;
};
struct EffectSimpleParticleRegistration {
EffectSimpleParticleRegistration( char*, Colour, Colour);
zen::particleMdl* create(s16 lifeTime, Vector3f& globalPos, Vector3f& vel, Vector3f& accel, f32 size, f32 rotSpeed,
zen::CallBack1<zen::particleMdl*>* cbPtcl)
{
return effectMgr->mPtclMgr.createParticle(mSimpleTex, lifeTime, globalPos, vel, accel, size, rotSpeed, mPrimColor, mEnvColor,
cbPtcl);
}
Texture* mSimpleTex;
Colour mPrimColor;
Colour mEnvColor;
};
class Creature;
class EffectParm {
public:
EffectParm( Vector3f* pos)
{
mPositionRef = pos;
mScale = 1.0f;
}
EffectParm( Vector3f& pos)
{
mPosition = pos;
mScale = 1.0f;
}
EffectParm(Creature* owner) { mOwner = owner; }
EffectParm( Vector3f& pos, Vector3f& dir)
{
mPosition = pos;
mDirection = dir;
mScale = 1.0f;
}
Vector3f mPosition;
Vector3f mDirection;
u8 _18[0x8];
Vector3f* mPositionRef;
f32 mScale;
Creature* mOwner;
};
class KEffect : public zen::CallBack1<zen::particleGenerator*>,
public zen::CallBack2<zen::particleGenerator*, zen::particleMdl*>,
public zen::CallBack1<zen::particleMdl*> {
public:
virtual bool invoke(zen::particleGenerator*) { return false; }
virtual bool invoke(zen::particleGenerator*, zen::particleMdl*) { return false; }
virtual bool invoke(zen::particleMdl*) { return false; }
virtual void emit( EffectParm&) = 0;
virtual void kill() { }
virtual void stop() { }
virtual void restart() { }
};
struct SlimeEffect : public KEffect {
SlimeEffect();
virtual bool invoke(zen::particleGenerator*, zen::particleMdl*);
virtual void emit( EffectParm&);
virtual void kill();
virtual void stop();
virtual void restart();
zen::particleGenerator* mEfxGen;
Creature* mObj;
};
class BaseShape;
class CachedShape;
class Camera;
class Colour;
class Font;
class Light;
class LightCamera;
class Material;
class MaterialHandler;
class Matrix4f;
class Mesh;
struct OSContext;
class Plane;
class PVWLightingInfo;
class RectArea;
class Shape;
class ShapeDynMaterials;
class Texture;
class Vector2f;
class Vector3f;
struct GColor {
GColor()
{
mMatColor.r = 255;
mMatColor.g = 255;
mMatColor.b = 255;
mMatColor.a = 255;
mAmbColor.r = 255;
mAmbColor.g = 255;
mAmbColor.b = 255;
mAmbColor.a = 255;
}
GXColor mMatColor;
GXColor mAmbColor;
};
extern GColor GColors[];
class Graphics {
public:
struct ClearBufferFlag { typedef
enum {
Color = 1 << 0,
Depth = 1 << 1,
Both = Color | Depth,
} Type; } ;
Graphics();
void resetMatrixBuffer();
Matrix4f* getMatrices(int);
void resetCacheBuffer();
void cacheShape(BaseShape*, ShapeDynMaterials*);
void flushCachedShapes();
void drawCylinder( Vector3f&, Vector3f&, f32, Matrix4f&);
void drawSphere( Vector3f&, f32, Matrix4f&);
int calcLighting(f32);
void drawCircle( Vector3f&, f32, Matrix4f&);
int calcSphereLighting( Vector3f&, f32);
int calcBoxLighting( BoundBox&);
void addLight(Light* light)
{
light->initCore("");
gsys->mLightCount++;
mLight.add(light);
}
int mRenderMode;
u32 mMatRenderMask;
Matrix4f* mLastModelMatrix;
Matrix4f* mActiveMatrix;
Light mLight;
Camera* mCamera;
Texture* mActiveTexture[8];
u32 _308;
int mScreenWidth;
int mScreenHeight;
Colour mBufferClearColour;
Colour mPrimaryColour;
Colour mAuxiliaryColour;
bool mIsLightingEnabled;
bool mIsDepthEnabled;
BOOL mHasTexGen;
u32 mMtxDepIdx;
int mBlendMode;
int mCullMode;
u32 mCullFlip;
LightCamera* mLightCam;
Vector3f mSunPosition;
u32 _348;
MaterialHandler* mDefaultMaterialHandler;
MaterialHandler* mCurrentMaterialHandler;
Material* mCurrentMaterial;
f32 mFogStart;
f32 mFogEnd;
f32 mFogDensity;
Colour mFogColour;
Colour mAmbientColour;
Colour _36C;
f32 mLightDistance;
f32 mLightIntensity;
u32 mActiveLightMask;
f32 mLineWidth;
Vector3f* mCustomScale;
Matrix4f* mMatrixBuffer;
int mMaxMatrixCount;
int mNextFreeMatrixIdx;
CachedShape mShapeCache;
CachedShape* mCachedShapes;
int mCachedShapeMax;
int mCachedShapeCount;
virtual void videoReset() { }
virtual void setVerticalFilter(u8*) { }
virtual void getVerticalFilter(u8*) { }
virtual u8* getDListPtr() { return 0 ; }
virtual u32 getDListRemainSize() { return 0; }
virtual u32 compileMaterial(Material*) { return 0; }
virtual void useDList(u32) { }
virtual void initRender(int, int);
virtual void resetCopyFilter() = 0;
virtual void setAmbient() { }
virtual bool setLighting(bool, PVWLightingInfo*) = 0;
virtual void setLight(Light*, int) = 0;
virtual void clearBuffer(int, bool) = 0;
virtual void setPerspective(Mtx44, f32, f32, f32, f32, f32) = 0;
virtual void setOrthogonal(Mtx44, RectArea&) = 0;
virtual void setLightcam(LightCamera* cam) { mLightCam = cam; }
virtual void setViewport( RectArea&) = 0;
virtual void setViewportOffset( RectArea&) = 0;
virtual void setScissor( RectArea&) = 0;
virtual void setBlendMode(u8 blendFactor, u8 zMode, u8 blendMode) { }
virtual int setCullFront(int) = 0;
virtual bool setDepth(bool) = 0;
virtual int setCBlending(int) = 0;
virtual void setPointSize(f32) = 0;
virtual f32 setLineWidth(f32) = 0;
virtual void setCamera(Camera*) = 0;
virtual void calcViewMatrix( Matrix4f& modelMtx, Matrix4f& viewMtx) = 0;
virtual void useMatrix( Matrix4f&, int) = 0;
virtual void setClippingPlane(bool, Plane*) = 0;
virtual void initMesh(Shape*) = 0;
virtual void drawSingleMatpoly(Shape*, Joint::MatPoly*) = 0;
virtual void drawMeshes(Camera&, Shape*) = 0;
virtual bool initParticle(bool) = 0;
virtual void drawParticle(Camera&, Vector3f&, f32) = 0;
virtual void drawRotParticle(Camera&, Vector3f&, u16, f32) = 0;
virtual void drawCamParticle(Camera&, Vector3f&, Vector2f&, Vector2f&, Vector2f&) = 0;
virtual void drawLine( Vector3f&, Vector3f&) = 0;
virtual void drawPoints( Vector3f*, int) = 0;
virtual void drawOneTri( Vector3f* vertices, Vector3f* normals, Vector2f* texCoords, int count) = 0;
virtual void drawOneStrip( Vector3f*, Vector3f*, Vector2f*, int) = 0;
virtual void setColour( Colour&, bool) = 0;
virtual void setAuxColour( Colour&) = 0;
virtual void setPrimEnv( Colour* primColor, Colour* envColor) = 0;
virtual void setClearColour( Colour&) = 0;
virtual void setFog(bool) = 0;
virtual void setFog(bool, Colour&, f32, f32, f32) = 0;
virtual void setMatHandler(MaterialHandler* handler)
{
if (mCurrentMaterialHandler && !handler) {
mCurrentMaterialHandler->setMaterial(0 );
}
mCurrentMaterialHandler = (handler) ? handler : mDefaultMaterialHandler;
mCurrentMaterialHandler->mGfx = this;
}
virtual void setMaterial(Material*, bool) = 0;
virtual void useMaterial(Material* mat) { mCurrentMaterialHandler->setMaterial(mat); }
virtual void useTexture(Texture*, int) = 0;
virtual void drawRectangle( RectArea&, RectArea&, Vector3f*) = 0;
virtual void fillRectangle( RectArea&) = 0;
virtual void blatRectangle( RectArea&) = 0;
virtual void lineRectangle( RectArea&) = 0;
virtual void testRectangle( RectArea&) { }
virtual void initProjTex(bool, LightCamera*) = 0;
virtual void initReflectTex(bool) = 0;
virtual void texturePrintf(Font* font, int x, int y, char* format, ...) = 0;
virtual void perspPrintf(Font*, Vector3f&, int, int, char*, ...);
};
struct DGXGraphics : public Graphics {
DGXGraphics(bool);
virtual void videoReset();
virtual void setVerticalFilter(u8*);
virtual void getVerticalFilter(u8*);
virtual u8* getDListPtr();
virtual u32 getDListRemainSize();
virtual u32 compileMaterial(Material*);
virtual void useDList(u32);
virtual void initRender(int, int);
virtual void resetCopyFilter();
virtual void setAmbient();
virtual bool setLighting(bool, PVWLightingInfo*);
virtual void setLight(Light*, int);
virtual void clearBuffer(int, bool);
virtual void setPerspective(Mtx44, f32, f32, f32, f32, f32);
virtual void setOrthogonal(Mtx44, RectArea&);
virtual void setViewport( RectArea&);
virtual void setViewportOffset( RectArea&);
virtual void setScissor( RectArea&);
virtual void setBlendMode(u8, u8, u8);
virtual int setCullFront(int);
virtual bool setDepth(bool);
virtual int setCBlending(int);
virtual void setPointSize(f32) { }
virtual f32 setLineWidth(f32);
virtual void setCamera(Camera*);
virtual void calcViewMatrix( Matrix4f& modelMtx, Matrix4f& viewMtx);
virtual void useMatrix( Matrix4f&, int);
virtual void setClippingPlane(bool, Plane*) { }
virtual void initMesh(Shape*);
virtual void drawSingleMatpoly(Shape*, Joint::MatPoly*);
virtual void drawMeshes(Camera&, Shape*);
virtual bool initParticle(bool);
virtual void drawParticle(Camera&, Vector3f&, f32);
virtual void drawRotParticle(Camera&, Vector3f&, u16, f32);
virtual void drawCamParticle(Camera&, Vector3f&, Vector2f&, Vector2f&, Vector2f&);
virtual void drawLine( Vector3f&, Vector3f&);
virtual void drawPoints( Vector3f*, int);
virtual void drawOneTri( Vector3f* vertices, Vector3f* normals, Vector2f* texCoords, int count);
virtual void setColour( Colour&, bool);
virtual void setAuxColour( Colour&);
virtual void setPrimEnv( Colour*, Colour*);
virtual void setClearColour( Colour&);
virtual void setFog(bool);
virtual void setFog(bool, Colour&, f32, f32, f32);
virtual void setMaterial(Material*, bool);
virtual void useTexture(Texture*, int);
virtual void drawRectangle( RectArea&, RectArea&, Vector3f*);
virtual void fillRectangle( RectArea&);
virtual void blatRectangle( RectArea&);
virtual void lineRectangle( RectArea&);
virtual void testRectangle( RectArea&);
virtual void initProjTex(bool enableProj, LightCamera* projCamera);
virtual void initReflectTex(bool);
virtual void texturePrintf(Font* font, int x, int y, char* format, ...);
virtual void useMatrixQuick( Matrix4f&, int);
virtual void drawOutline(Camera&, Shape*) { }
virtual void drawOneStrip( Vector3f*, Vector3f*, Vector2f*, int) { }
void setupRender();
void beginRender();
void doneRender();
void waitRetrace();
void waitPostRetrace();
static void retraceProc(u32);
void setMatMatrices(Material*, int);
void setupVtxDesc(Shape*, Material*, Mesh*);
void GXReInit();
void showCrash(u16, OSContext*);
void showError( char*, char*, int);
void directDrawChar(int, int, int);
void directDrawChar( RectArea&, RectArea&);
void directPrint(int, int, char*, ...);
void directErase( RectArea&, bool);
static DGXGraphics* gfx;
GXFifoObj* mGpFifo;
u8* mDefaultFifoBuffer;
u8* mTempFifoBuffer;
u8* mDefaultDLBuffer;
u8* mDisplayListPtr;
int mDisplayListSize;
u32 _3D0;
bool mIsEnvMapActive;
int mCurrentMatrixId;
int mTexMtxBaseID;
Mtx mProjectionTextureMatrix;
GXLightObj mGXLights[8];
u8* mDisplayBuffer;
vu32 mPostRetraceWaitCount;
int mRetraceCount;
int mSystemFrameRate;
VIRetraceCallback mRetraceCallback;
OSMessageQueue mPostRetraceMsgQueue;
OSMessage mPostRetraceMsgBuffer;
};
extern DGXGraphics* gfx;
struct OGLGraphics : public Graphics {
OGLGraphics(int screenWidth, int screenHeight);
virtual void initRender(int, int);
virtual void resetCopyFilter();
virtual bool setLighting(bool, PVWLightingInfo*);
virtual void setLight(Light*, int);
virtual void clearBuffer(int, bool);
virtual void setPerspective(Mtx44, f32, f32, f32, f32, f32);
virtual void setOrthogonal(Mtx44, RectArea&);
virtual void setViewport( RectArea&);
virtual void setViewportOffset( RectArea&);
virtual void setScissor( RectArea&);
virtual int setCullFront(int);
virtual bool setDepth(bool);
virtual int setCBlending(int);
virtual void setPointSize(f32);
virtual f32 setLineWidth(f32);
virtual void setCamera(Camera*);
virtual void calcViewMatrix( Matrix4f& modelMtx, Matrix4f& viewMtx);
virtual void useMatrix( Matrix4f&, int);
virtual void setClippingPlane(bool, Plane*);
virtual void initMesh(Shape*);
virtual void drawSingleMatpoly(Shape*, Joint::MatPoly*);
virtual void drawMeshes(Camera&, Shape*);
virtual bool initParticle(bool);
virtual void drawParticle(Camera&, Vector3f&, f32);
virtual void drawRotParticle(Camera&, Vector3f&, u16, f32);
virtual void drawCamParticle(Camera&, Vector3f&, Vector2f&, Vector2f&, Vector2f&);
virtual void drawLine( Vector3f&, Vector3f&);
virtual void drawPoints( Vector3f*, int);
virtual void drawOneTri( Vector3f* vertices, Vector3f* normals, Vector2f* texCoords, int count);
virtual void drawOneStrip( Vector3f*, Vector3f*, Vector2f*, int);
virtual void setColour( Colour&, bool);
virtual void setAuxColour( Colour&);
virtual void setPrimEnv( Colour* primColor, Colour* envColor);
virtual void setClearColour( Colour&);
virtual void setFog(bool);
virtual void setFog(bool, Colour&, f32, f32, f32);
virtual void setMaterial(Material*, bool);
virtual void useTexture(Texture*, int);
virtual void drawRectangle( RectArea&, RectArea&, Vector3f*);
virtual void fillRectangle( RectArea&);
virtual void blatRectangle( RectArea&);
virtual void lineRectangle( RectArea&);
virtual void initProjTex(bool, LightCamera*);
virtual void initReflectTex(bool);
virtual void texturePrintf(Font* font, int x, int y, char* format, ...);
String mOGLVendor;
String mOGLRenderer;
String mOGLVersion;
String mOGLExtensions;
RectArea mViewportBounds;
};
class GfxInfo {
public:
void createCollData( Vector3f*, f32);
BoundBox mBox;
u8 _18[0x4];
s16* mTriangleCountPtr;
CollTriInfo* mTriangles;
};
struct ShadowCaster : public CoreNode {
ShadowCaster();
void initShadow();
LightCamera mLightCamera;
Vector3f mSourcePosition;
Vector3f mTargetPosition;
Node* mShadowDrawer;
};
class Controller;
class CreatureCollPart;
class DayMgr;
struct DynSimulator;
struct MapLightMgr;
enum MapShapeTypes {
MAPSHAPE_Box = 0,
MAPSHAPE_1 = 1,
MAPSHAPE_2 = 2,
MAPSHAPE_3 = 3,
MAPSHAPE_Log = 4,
MAPSHAPE_Count,
};
class MoveTrace {
public:
MoveTrace( Vector3f& position, Vector3f& velocity, f32 radius, bool ignoreDynColl)
{
mIgnoreDynamicCollision = ignoreDynColl;
mPosition = position;
mVelocity = velocity;
mRadius = radius;
mObject = 0 ;
mStepFraction = 1.0f;
}
Vector3f mPosition;
Vector3f mVelocity;
f32 mRadius;
f32 mStepFraction;
bool mIgnoreDynamicCollision;
Creature* mObject;
};
struct MapShadMatHandler : public MaterialHandler {
MapShadMatHandler()
{
mShadowLightMat = new Material();
mShadowLightMat->colour().set(255, 255, 255, 255);
}
virtual void setMaterial(Material*)
{
mGfx->setMaterial(mShadowLightMat, true);
}
Material* mShadowLightMat;
};
struct MapProjMatHandler : public MaterialHandler {
MapProjMatHandler(Texture* tex)
{
mProjectionCamera = 0 ;
mProjMat = new Material();
mProjMat->mTexture = tex;
mProjMat->colour().set(128, 128, 128, 32);
}
virtual void setMaterial(Material*)
{
mGfx->setMaterial(mProjMat, true);
}
virtual void setTexMatrix(bool enableProj)
{
mGfx->initProjTex(enableProj, mProjectionCamera);
}
Material* mProjMat;
LightCamera* mProjectionCamera;
};
struct MapRoom {
MapRoom()
{
_08 = 0;
_04 = 1.0f;
_00 = 1.0f;
}
f32 _00;
f32 _04;
u32 _08;
};
struct MapColls {
CollGroup* mParentCollGroup;
CollTriInfo* mTriangle;
int mColorCategory;
};
class MapMgr {
public:
enum DebugColourTypes {
DCLR_Yellow = 0,
DCLR_Red = 1,
DCLR_Blue = 2,
DCLR_COUNT,
};
MapMgr(Controller* controller);
void initEffects();
void initShape();
void createLights();
void updateSimulation();
void update();
void preRender(Graphics& gfx);
void drawShadowCasters(Graphics& gfx);
void refresh(Graphics& gfx);
void showCollisions( Vector3f& focusPos);
void drawXLU(Graphics& gfx);
void postrefresh(Graphics& gfx);
void updatePos(f32 x, f32 z);
f32 getLight(f32, f32);
CollGroup* getCollGroupList(f32 x, f32 z, bool includePlatColl);
f32 getMinY(f32 x, f32 z, bool includePlatColl);
f32 getMaxY(f32 x, f32 z, bool includePlatColl);
CollTriInfo* getCurrTri(f32 x, f32 z, bool includePlatColl);
f32 findEdgePenetration(CollTriInfo& tri, Vector3f* vertexList, Vector3f& sphereCenter, f32 sphereRadius,
Vector3f& outNormal);
void recTraceMove(CollGroup* collGroupList, MoveTrace& trace, f32 timeStep);
void traceMove(Creature* creature, MoveTrace& trace, f32 timeStep);
Shape* loadPlatshape( char* modelFilePath);
CreatureCollPart* requestCollPart(ObjCollInfo* info, Creature* obj);
bool closeCollTri(CollGroup* collGroup, CollTriInfo* tri);
Controller* mController;
DayMgr* mDayMgr;
Vector3f _08;
MapRoom* mMapRooms;
int mMinMaxYQueryCount;
int mCurrTriQueryCount;
u8 _20[0x60 - 0x20];
Shape* mMapModel;
ShapeDynMaterials mAnimatedMaterials;
BaseShape* mMapShapes[MAPSHAPE_Count];
DynCollShape* mCollShapeList;
MapLightMgr* mSoftLightMgr;
BoundBox mMapBounds;
int mDebugCollCount;
int mActiveTriCount;
int mMaxDebugColls;
Vector3f mDebugFocusPosition;
BoundBox mOuterCollRenderBounds;
BoundBox mActiveCollisionBounds;
MapColls* mDebugCollisions;
f32 mLastPhysicsTime;
f32 mAccumPhysicsTime;
f32 mPhysicsStepInterval;
f32 mPhysicsSubStepInterval;
bool mSimulationResetPending;
DynSimulator* mWorldSimulator;
int mCurrTraceTick;
int mShadowDelayCounter;
ShadowCaster mGlobalShadowList;
MapShadMatHandler* mShadowCamMatHandler;
MapProjMatHandler* mShadowProjMatHandler;
Texture* mBlurSourceTexture;
Texture* mBlurResultTexture;
int mBlur;
f32 mCurrDesaturationLevel;
f32 mCurrFadeLevel;
f32 mTargetDesaturationLevel;
f32 mTargetFadeLevel;
CreatureCollPart* mCollParts;
};
extern MapMgr* mapMgr;
class Matrix3f {
public:
enum mode {
MODE_Unk0 = 0,
};
enum do_not_initialize { };
Matrix3f() { identity(); }
Matrix3f(const Mtx33 mtx)
{
for (int row = 0; row < 3; row++) {
for (int col = 0; col < 3; col++)
(*this)(row, col) = mtx[row][col];
}
};
Matrix3f(mode)
{
for (int row = 0; row < 3; row++) {
mMtx[row][0] = 0.0f;
mMtx[row][1] = 0.0f;
mMtx[row][2] = 0.0f;
}
}
Matrix3f(const Vector3f& vec, mode)
{
(*this)(0, 0) = 0.0f;
(*this)(0, 1) = -vec.z;
(*this)(0, 2) = vec.y;
(*this)(1, 0) = vec.z;
(*this)(1, 1) = 0.0f;
(*this)(1, 2) = -vec.x;
(*this)(2, 0) = -vec.y;
(*this)(2, 1) = vec.x;
(*this)(2, 2) = 0.0f;
}
protected:
Matrix3f(do_not_initialize) { }
public:
void identity()
{
for (int i = 0; i < 3 * 3; i++) {
mMtx[0] [i] = 0.0f;
}
mMtx[0][0] = mMtx[1][1] = mMtx[2][2] = 1.0f;
}
f32& operator()(int row, int col) { return mMtx[row][col]; }
const f32& operator()(int row, int col) const { return mMtx[row][col]; }
f32 GetElement(int row, int col) const { return mMtx[row][col]; }
Matrix3f& SetElement(int row, int col, f32 val)
{
mMtx[row][col] = val;
return *this;
}
Mtx33 mMtx;
};
inline Matrix3f operator*(f32 scale, const Matrix3f& inMtx)
{
Matrix3f outMtx;
for (int i = 0; i < 3; i++) {
outMtx(0, i) = scale * inMtx(0, i);
outMtx(1, i) = scale * inMtx(1, i);
outMtx(2, i) = scale * inMtx(2, i);
}
return outMtx;
}
inline Matrix3f operator*(const Matrix3f& mtxA, const Matrix3f& mtxB)
{
Matrix3f outMtx;
for (int i = 0; i < 3; i++) {
for (int j = 0; j < 3; j++) {
f32 elem = 0.0f;
for (int k = 0; k < 3; k++) {
elem += mtxA.GetElement(i, k) * mtxB.GetElement(k, j);
}
outMtx.SetElement(i, j, elem);
}
}
return outMtx;
}
inline Matrix3f operator+(const Matrix3f& mtxA, const Matrix3f& mtxB)
{
Matrix3f outMtx;
for (int i = 0; i < 3; i++) {
outMtx(0, i) = mtxA(0, i) + mtxB(0, i);
outMtx(1, i) = mtxA(1, i) + mtxB(1, i);
outMtx(2, i) = mtxA(2, i) + mtxB(2, i);
}
return outMtx;
}
inline Vector3f operator*(const Matrix3f& mtx, const Vector3f& inVec)
{
Vector3f outVec;
outVec.x = mtx.GetElement(0, 0) * inVec.x + mtx.GetElement(0, 1) * inVec.y + mtx.GetElement(0, 2) * inVec.z;
outVec.y = mtx.GetElement(1, 0) * inVec.x + mtx.GetElement(1, 1) * inVec.y + mtx.GetElement(1, 2) * inVec.z;
outVec.z = mtx.GetElement(2, 0) * inVec.x + mtx.GetElement(2, 1) * inVec.y + mtx.GetElement(2, 2) * inVec.z;
return outVec;
}
inline Matrix3f Transpose(const Matrix3f& inMtx)
{
Matrix3f outMtx;
for (int i = 0; i < 3; i++) {
outMtx(0, i) = inMtx(i, 0);
outMtx(1, i) = inMtx(i, 1);
outMtx(2, i) = inMtx(i, 2);
}
return outMtx;
}
inline void OrthonormaliseOrientation(Matrix3f& mtx)
{
Vector3f vec1(mtx(0, 0), mtx(1, 0), mtx(2, 0));
Vector3f vec2(mtx(0, 1), mtx(1, 1), mtx(2, 1));
Vector3f vec3;
vec1.normalise();
vec3 = CP(vec1, vec2);
vec3.normalise();
vec2 = CP(vec3, vec1);
vec2.normalise();
mtx(0, 0) = vec1.x;
mtx(0, 1) = vec2.x;
mtx(0, 2) = vec3.x;
mtx(1, 0) = vec1.y;
mtx(1, 1) = vec2.y;
mtx(1, 2) = vec3.y;
mtx(2, 0) = vec1.z;
mtx(2, 1) = vec2.z;
mtx(2, 2) = vec3.z;
}
class Navi;
struct KandoEffect { typedef
enum {
Goal = 0,
NaviWhistle0,
NaviWhistle1,
SmokeSoil,
SmokeRock,
SmokeGrass,
SmokeTree,
NaviFue0,
NaviFue1,
PikiGrowup1,
PikiGrowup2,
WallHit1,
WallHit0,
WallHit2,
WallHit3,
WallBreak0,
WallBreak1,
Bubbles,
Ripples,
Bomb,
BombLight,
UfoSuck,
UfoSuikomi,
WhistleTemplate0,
WhistleTemplate1,
IdleBluePiki,
IdleRedPiki,
IdleYellowPiki,
COUNT,
START = Goal,
END = IdleYellowPiki,
SmokeOffset = SmokeSoil,
} Type; } ;
struct BurnEffect : public KEffect {
BurnEffect( Vector3f* vec)
{
_0C = vec;
mEfxA = 0;
mEfxB = 0;
}
virtual bool invoke(zen::particleGenerator*);
virtual void emit( EffectParm&);
virtual void kill();
virtual void stop();
virtual void restart();
Vector3f* _0C;
zen::particleGenerator* mEfxA;
zen::particleGenerator* mEfxB;
};
struct FreeLightEffect : public KEffect {
FreeLightEffect() { mEfx = 0 ; }
virtual void emit( EffectParm&);
virtual void kill();
virtual void stop();
virtual void restart();
void setScale(f32);
u16 mColor;
zen::particleGenerator* mEfx;
f32 mScale;
};
struct GoalEffect : public KEffect {
virtual bool invoke(zen::particleGenerator* efx)
{
if (efx->getCurrentFrame() >= 50) {
Vector3f grav(0.0f, 0.0f, 0.0f);
efx->setGravityField(grav, false);
}
return true;
}
virtual void emit( EffectParm& parm)
{
effectMgr->create(EffectMgr::EFF_Onyon_Suck, parm.mPosition, this, this);
}
};
struct RippleEffect : public KEffect {
RippleEffect()
{
mEfxA = 0;
mEfxB = mEfxC = 0;
}
virtual void emit( EffectParm&);
virtual void kill();
virtual void stop();
virtual void restart();
zen::particleGenerator* mEfxA;
zen::particleGenerator* mEfxB;
zen::particleGenerator* mEfxC;
};
struct SimpleEffect : public KEffect {
SimpleEffect(EffectMgr::effTypeTable id)
{
mEfxId = id;
mEfx = 0;
}
virtual void emit( EffectParm& parm)
{
mEfx = effectMgr->create((EffectMgr::effTypeTable)mEfxId, parm.mPosition, 0 , 0 );
}
virtual void kill()
{
if (mEfx) {
effectMgr->kill(mEfx, false);
}
}
int mEfxId;
zen::particleGenerator* mEfx;
};
struct SmokeGrassEffect : public KEffect {
virtual void emit( EffectParm& parm)
{
effectMgr->create(EffectMgr::EFF_Kogane_Walk1, parm.mPosition, 0 , 0 );
}
};
struct SmokeRockEffect : public KEffect {
virtual void emit( EffectParm& parm)
{
effectMgr->create(EffectMgr::EFF_Kogane_Walk2, parm.mPosition, 0 , 0 );
}
};
struct SmokeSoilEffect : public KEffect {
virtual void emit( EffectParm& parm)
{
effectMgr->create(EffectMgr::EFF_Kogane_Walk0, parm.mPosition, 0 , 0 );
}
};
struct SmokeTreeEffect : public KEffect {
virtual void emit( EffectParm& parm)
{
effectMgr->create(EffectMgr::EFF_Kogane_Walk0, parm.mPosition, 0 , 0 );
}
};
struct UfoSuikomiEffect : public KEffect {
UfoSuikomiEffect() { mEfx = 0; }
virtual void emit( EffectParm& parm)
{
_0C = parm.mPosition;
_18 = parm.mDirection;
if (mEfx) {
return;
}
mEfx = effectMgr->create(EffectMgr::EFF_Rocket_Suck2, _0C, this, this);
Vector3f diff = _18 - _0C;
mEfx->setNewtonField(Vector3f(_18), 0.0016f, true);
diff.normalise();
mEfx->setVortexField(Vector3f(diff), -0.12f, -0.09f, 0.3f, 400.0f, true);
}
virtual void kill()
{
if (mEfx) {
effectMgr->kill(mEfx, false);
mEfx = 0 ;
}
}
Vector3f _0C;
Vector3f _18;
zen::particleGenerator* mEfx;
};
struct BombEffect : public KEffect {
virtual void emit( EffectParm& parm)
{
zen::particleGenerator* efx = effectMgr->create(EffectMgr::EFF_Bomb_Glow, parm.mPosition, 0 , 0 );
if (efx) {
Vector3f nrm(0.0f, 1.0f, 0.0f);
efx->setOrientedNormalVector(nrm);
}
effectMgr->create(EffectMgr::EFF_Bomb_Wave, parm.mPosition, 0 , 0 );
effectMgr->create(EffectMgr::EFF_Bomb_DustRing, parm.mPosition, 0 , 0 );
effectMgr->create(EffectMgr::EFF_Bomb_Bang, parm.mPosition, 0 , 0 );
effectMgr->create(EffectMgr::EFF_Bomb_FireBang, parm.mPosition, 0 , 0 );
effectMgr->create(EffectMgr::EFF_Bomb_FireGlow, parm.mPosition, 0 , 0 );
}
virtual void kill() { }
};
struct BombEffectLight : public KEffect {
virtual void emit( EffectParm& parm)
{
zen::particleGenerator* efx = effectMgr->create(EffectMgr::EFF_Bomb_Glow, parm.mPosition, 0 , 0 );
if (efx) {
Vector3f nrm(0.0f, 1.0f, 0.0f);
efx->setOrientedNormalVector(nrm);
}
effectMgr->create(EffectMgr::EFF_BombLight_Bang, parm.mPosition, 0 , 0 );
effectMgr->create(EffectMgr::EFF_BombLight_Wave, parm.mPosition, 0 , 0 );
effectMgr->create(EffectMgr::EFF_BombLight_FireBang, parm.mPosition, 0 , 0 );
effectMgr->create(EffectMgr::EFF_BombLight_FireGlow, parm.mPosition, 0 , 0 );
}
virtual void kill() { }
};
struct WhistleTemplate : public KEffect {
WhistleTemplate(EffectMgr::effTypeTable id1, EffectMgr::effTypeTable id2)
{
mEfxA = mEfxB = 0 ;
mEffIDA = id1;
mEffIDB = id2;
}
virtual bool invoke(zen::particleGenerator* ptclGen, zen::particleMdl* ptcl)
{
Vector3f diff = _0C - _18;
f32 ratio = f32(ptcl->mAge) / f32(ptcl->mLifeTime);
f32 compRatio = 1.0f - ratio;
ptcl->mGlobalPosition = _18;
ptcl->mLocalPosition = diff * ratio;
if (_0C.y < _18.y + 15.0f) {
CollTriInfo* tri = mapMgr->getCurrTri(_0C.x, _0C.z, true);
Matrix3f mtx1;
Matrix3f mtx2;
Quat q1;
Quat q2;
diff.normalize();
zen::makeRotMatrix(diff, mtx1);
zen::makeRotMatrix(Vector3f(tri->mTriangle.mNormal * -1.0f), mtx2);
q1.fromMat3f(mtx1);
q2.fromMat3f(mtx2);
q1.slerp(q2, ratio, 0);
q1.genVectorY(ptcl->mOrientedNormal);
q1.genVectorX(ptcl->mVelocity);
ptcl->mVelocity.multiply(0.01f);
} else {
ptcl->mOrientedNormal.set(diff);
}
return false;
}
virtual void emit( EffectParm& parm)
{
_0C = parm.mPosition;
_18 = parm.mDirection;
if (mEfxA || mEfxB) {
return;
}
mEfxA = effectMgr->create(mEffIDA, _18, this, this);
mEfxB = effectMgr->create(mEffIDB, _18, this, this);
if (mEfxA) {
mEfxA->setOrientedConstZAxis(true);
}
}
virtual void kill()
{
if (mEfxA) {
effectMgr->kill(mEfxA, false);
mEfxA = 0 ;
}
if (mEfxB) {
effectMgr->kill(mEfxB, false);
mEfxB = 0 ;
}
}
Vector3f _0C;
Vector3f _18;
zen::particleGenerator* mEfxA;
zen::particleGenerator* mEfxB;
EffectMgr::effTypeTable mEffIDA;
EffectMgr::effTypeTable mEffIDB;
};
struct UfoSuckEffect : public WhistleTemplate {
UfoSuckEffect()
: WhistleTemplate(EffectMgr::EFF_Rocket_Bm1, EffectMgr::EFF_Rocket_Bm2)
{
}
};
struct PermanentEffect {
PermanentEffect();
void init( Vector3f&, int);
void updatePos( Vector3f&);
void changeEffect(int);
void stop();
void restart();
void kill();
Vector3f mPosition;
zen::particleGenerator* mPtclGen;
};
class UtEffectMgr {
public:
UtEffectMgr();
static void kill(int);
static void cast(int, EffectParm&);
protected:
void registerEffect(int, KEffect*);
static KEffect** effects;
};
extern UtEffectMgr* utEffectMgr;
class TopAction;
class Navi;
struct PikiStateMachine;
struct PikiProp;
class PikiState;
enum PikiSituationType {
PIKISITCH_Unk0 = 0,
PIKISITCH_Unk1 = 1,
PIKISITCH_Unk2 = 2,
PIKISITCH_Unk3 = 3,
PIKISITCH_Unk4 = 4,
PIKISITCH_Unk5 = 5,
PIKISITCH_Unk6 = 6,
PIKISITCH_Unk7 = 7,
PIKISITCH_Unk8 = 8,
PIKISITCH_Unk9 = 9,
PIKISITCH_Unk10 = 10,
PIKISITCH_Unk11 = 11,
PIKISITCH_Unk12 = 12,
PIKISITCH_Unk13 = 13,
PIKISITCH_Unk14 = 14,
};
struct PikiMode { typedef
enum {
FreeMode = 0,
FormationMode,
AttackMode,
NukuMode,
GuardMode,
PickMode,
DecoyMode,
ArrowMode,
CarryMode,
TransportMode,
RopeMode,
EnterMode,
ExitMode,
BreakwallMode,
MineMode,
KinokoMode,
BridgeMode,
PushstoneMode,
PutbombMode,
RescueMode,
WeedMode,
PebbleMode,
BomakeMode,
BoMode,
WarriorMode,
COUNT,
} Type; } ;
struct PikiEmotion { typedef
enum {
Happy = 0,
Sad = 1,
Unused = 2,
ShookDry = 3,
ShipPartGaze = 4,
Excited = 5,
Victorious = 6,
Searching = 7,
Confused = 8,
ShipPartCheer = 9,
None = 10
} Type; } ;
class Piki : public Creature, public PaniAnimKeyListener {
public:
Piki(CreatureProp*);
virtual void addCntCallback();
virtual void subCntCallback();
virtual bool platAttachable();
virtual bool doDoAI();
virtual void resetPosition( Vector3f&);
virtual f32 getiMass();
virtual f32 getSize();
virtual Vector3f getShadowPos() { return mShadowPos; }
virtual bool isVisible();
virtual bool isBuried();
virtual bool isAtari();
virtual bool isAlive();
virtual bool isFixed();
virtual bool needShadow();
virtual bool needFlick(Creature*);
virtual bool ignoreAtari(Creature*);
virtual bool stimulate( Interaction&);
virtual void sendMsg(Msg*);
virtual void collisionCallback( CollEvent&);
virtual void bounceCallback();
virtual void jumpCallback();
virtual void wallCallback( Plane&, DynCollObject*);
virtual void offwallCallback(DynCollObject*);
virtual void stickToCallback(Creature*);
virtual void dump();
virtual bool isRopable();
virtual bool mayIstick();
virtual int getFormationPri();
virtual Vector3f getCatchPos(Creature*);
virtual void doAI();
virtual void doAnimation();
virtual bool isKinoko() = 0;
virtual void animationKeyUpdated( PaniAnimKeyEvent&);
virtual void initBirth() { }
virtual void changeShape(int) { }
virtual void setFlower(int) { }
virtual void setLeaves(int) { }
f32 getSpeed(f32);
void setSpeed(f32, Vector3f&);
void setSpeed(f32, f32);
void init(Navi*);
bool isFruit();
void updateLookCreature();
void updateWalkAnimation();
void realAI();
void changeMode(int, Navi*);
void startHimaLook( Vector3f*);
void finishLook();
bool isLooking();
void updateLook();
void demoCheck();
void startDemo();
void finishDemo();
bool appearDemo();
int getUpperMotionIndex();
f32 getAttackPower();
int findRoute(int, int, bool, bool);
int moveRouteTraceDynamic(f32);
bool initRouteTrace( Vector3f&, bool);
int moveRouteTrace(f32);
bool hasBomb();
void startFire();
void endFire();
bool isTeki(Piki*);
void actOnSituaton();
int getState();
int graspSituation(Creature**);
void initColor(int);
void startKinoko();
void endKinoko();
void setColor(int);
void setPastel();
void unsetPastel();
void updateColor();
void startDamage();
void finishDamage();
bool isThrowable();
void startMotion( PaniMotionInfo&, PaniMotionInfo&);
void enableMotionBlend();
void checkBridgeWall(Creature*, Vector3f&);
static bool isSafeMePos( Vector3f&);
PikiState* getPikiState();
bool initRouteTraceDynamic(Creature*);
void updateFire();
int getNaviID();
int getLastState();
void birthBuried();
bool isGrowable();
bool isTamable();
void growup();
bool doMotionBlend();
void swapMotion( PaniMotionInfo&, PaniMotionInfo&);
void setSpeed(f32);
char* getCurrentMotionName();
void setEraseKill() { mEraseOnKill = true; }
void unsetEraseKill() { mEraseOnKill = false; }
AState<Piki>* getCurrState() { return mCurrentState; }
void setCurrState(AState<Piki>* state) { mCurrentState = state; }
void startLook( Vector3f* other)
{
mLookatPosPtr = other;
mLookTimer = 0;
mIsLooking = false;
mLookAtCreature.clear();
}
void forceFinishLook()
{
mLookatPosPtr = 0 ;
mVerticalRotation = 0.0f;
mHorizontalRotation = 0.0f;
mLookTimer = 0;
mIsLooking = false;
mLookAtCreature.clear();
}
bool isFired() { return mFiredState == 1; }
protected:
virtual void doKill();
Vector3f crGetPoint(int);
bool crPointOpen(int);
f32 crGetRadius(int);
void crMakeRefs();
public:
static bool directDumpMode;
static Colour kinokoColors[6];
static Colour pikiColors[6];
OdoMeter mOdometer;
PathFinder::Buffer* mPathBuffers;
u32 mRouteHandle;
bool mUseAsyncPathfinding;
s16 mRouteSourceIndex;
s16 mRouteDestinationIndex;
bool mIsRetryPathfind;
s16 mCurrRoutePoint;
Vector3f mRouteStartPos;
Vector3f mRouteGoalPos;
Vector3f mSplineControlPts[4];
s16 mNumRoutePoints;
Creature* mRouteTargetCreature;
bool mIsLooking;
f32 _334;
SmartPtr<Creature> mLookAtCreature;
Vector3f* mLookatPosPtr;
u8 mLookTimer;
f32 mHorizontalRotation;
f32 mVerticalRotation;
f32 mOldFaceDirection;
int mBlendMotionIdx;
PaniPikiAnimMgr mPikiAnimMgr;
u8 mEmotion;
Creature* mCarryingShipPart;
u8 mActionState;
bool mIsCallable;
UpdateContext mPikiUpdateContext;
UpdateContext mPikiLookUpdateContext;
bool mIsPanicked;
u16 mInWaterTimer;
PermanentEffect* mPanickedEffect;
BurnEffect* mBurnEffect;
RippleEffect* mRippleEffect;
FreeLightEffect* mFreeLightEffect;
SlimeEffect* mSlimeEffect;
int mPlayerId;
Vector3f mLastAnimPosition;
Vector3f mShadowPos;
Vector3f mCatchPos;
Vector3f mEffectPos;
bool mWantToStick;
u32 _474;
f32 _478;
f32 mMotionSpeed;
int _480;
int _484;
f32 mMoveSpeed;
f32 mDeathTimer;
PikiStateMachine* mFSM;
Creature* mCurrNectar;
f32 mFlickIntensity;
f32 mRotationAngle;
bool mIsWhistlePending;
CollPart* mSwallowMouthPart;
Creature* mLeaderCreature;
Vector3f mPluckVelocity;
int mFormationPriority;
Vector3f mPushTargetPos;
Vector3f _4C8;
u8 _4D4[0x4];
int _4D8;
Piki* mPushTargetPiki;
Plane* mWallPlane;
DynCollObject* mWallObj;
int _4E8;
f32 _4EC;
f32 _4F0;
f32 mPikiSize;
TopAction* mActiveAction;
u16 mMode;
SmartPtr<Creature> _500;
Navi* mNavi;
Colour mCurrentColour;
Colour mDefaultColour;
u16 mColor;
int mFloweringTimer;
bool _518;
bool _519;
u32 _51C;
int mHappa;
u16 mFiredState;
f32 _528;
AState<Piki>* mCurrentState;
Colour mStartBlendColour;
Colour mTargetBlendColour;
f32 mColourBlendRatio;
SearchData mPikiSearchData[6];
bool mEraseOnKill;
};
class PikiShapeObject {
friend class NaviMgr;
friend class ActorMgr;
public:
static void init();
static AnimMgr* getAnimMgr();
static void exitCourse();
static PikiShapeObject* create(int);
protected:
PikiShapeObject(Shape*);
static void initOnce();
static bool firstTime;
public:
static PikiShapeObject* _instances[4];
Shape* mShape;
AnimContext mAnimatorA;
AnimContext mAnimatorB;
AnimMgr* mAnimMgr;
};
class P2DPane;
class Controller;
class P2DPicture;
class Graphics;
class P2DScreen;
class P2DTextBox;
namespace zen {
struct DrawCMbest;
struct ogSaveMgr;
class ogScrMessageMgr;
struct ogGraphMgr;
struct PikaAlphaMgr;
enum EnumResult {
RESFLAG_NULL = -1,
RESFLAG_DOC_END = 0,
RESFLAG_EndFirstDay = 1,
RESFLAG_FirstVisitForest = 3,
RESFLAG_UnlockCave = 5,
RESFLAG_FirstVisitCave = 6,
RESFLAG_UnlockYakushima = 7,
RESFLAG_FirstVisitYakushima = 8,
RESFLAG_FinalDay = 10,
RESFLAG_Collect25Parts = 11,
RESFLAG_Collect29Parts = 12,
RESFLAG_OlimarDown = 13,
RESFLAG_PikminExtinction = 14,
RESFLAG_CollectAllParts = 15,
RESFLAG_YellowWithBomb = 17,
RESFLAG_MeetBluePikmin = 18,
RESFLAG_PikminRouting = 19,
RESFLAG_OlimarDaydream = 20,
RESFLAG_Collect15Parts = 21,
RESFLAG_PikminLeftBehind = 23,
RESFLAG_PikminBombDeath = 24,
RESFLAG_Collect10Parts = 26,
RESFLAG_UnusedControls1 = 27,
RESFLAG_UnusedControls2 = 29,
RESFLAG_UnusedControls3 = 31,
RESFLAG_BrokenBridge = 32,
RESFLAG_PikminSeeds = 33,
RESFLAG_PikminSeedStageUp = 35,
RESFLAG_Onyons = 36,
RESFLAG_MeetYellowPikminNoBomb = 37,
RESFLAG_BluePikminWaterImmunity = 38,
RESFLAG_PikminOnFire = 39,
RESFLAG_Dororo = 40,
RESFLAG_Swallow = 41,
RESFLAG_Kinoko = 42,
RESFLAG_Kogane = 43,
RESFLAG_Mizinko = 44,
RESFLAG_Pom = 45,
RESFLAG_Spider = 46,
RESFLAG_Beatle = 47,
RESFLAG_Snake = 48,
RESFLAG_King = 49,
RESFLAG_Slime = 50,
RESFLAG_Miurin = 51,
RESFLAG_Kabekui = 52,
RESFLAG_Tank = 53,
RESFLAG_Shell = 54,
RESFLAG_Collec = 55,
RESFLAG_Mar = 56,
RESFLAG_Otimoti = 57,
RESFLAG_Misc1 = 58,
RESFLAG_Misc2 = 59,
RESFLAG_Misc3 = 60,
RESFLAG_Misc4 = 61,
RESFLAG_Misc5 = 62,
RESFLAG_Misc6 = 63,
RESFLAG_Misc7 = 64,
RESFLAG_Misc8 = 65,
RESFLAG_Misc9 = 66,
RESFLAG_Misc10 = 67,
RESFLAG_Misc11 = 68,
RESFLAG_Misc12 = 69,
RESFLAG_Misc13 = 70,
RESFLAG_Misc14 = 71,
RESFLAG_Misc15 = 72,
RESFLAG_Misc16 = 73,
RESFLAG_Misc17 = 74,
RESFLAG_Misc18 = 75,
RESFLAG_Misc19 = 76,
RESFLAG_Misc20 = 77,
RESFLAG_Misc21 = 78,
RESFLAG_Misc22 = 79,
RESFLAG_Misc23 = 80,
RESFLAG_Misc24 = 81,
RESFLAG_Misc25 = 82,
RESFLAG_Misc26 = 83,
RESFLAG_Misc27 = 84,
};
struct ogScrResultMgr {
public:
enum returnStatusFlag {
Status_NULL = -1,
RESULT_Active = 0,
RESULT_DiaryMessage = 3,
RESULT_StartDelay = 4,
RESULT_SlideIn = 5,
RESULT_FadeOut = 6,
RESULT_ExitToMapSelect = 7,
RESULT_ExitToCardSelect = 8,
};
ogScrResultMgr();
ogScrResultMgr(EnumResult*);
returnStatusFlag update(Controller*);
void start();
void draw(Graphics&);
private:
void ogScrResultMgrSub();
void check1000(int, P2DPane*, P2DPane*, int);
void setEnumResultTable(EnumResult*);
void StartRESULT();
int _00;
returnStatusFlag mStatus;
returnStatusFlag mPendingStatus;
P2DScreen* mMainScreen;
int _10;
ogScrMessageMgr* mMesgScreen;
PikaAlphaMgr* mAlphaMgr;
int _1C;
P2DPane* mPaneRoot;
ogSaveMgr* mSaveMgr;
ogGraphMgr* mGraphMgr;
DrawCMbest* mCMBestData;
P2DScreen* mBlackScreen;
P2DPicture* mBlackPane;
P2DPane* _38;
P2DPane* _3C;
P2DPane* _40;
P2DPane* _44;
P2DPane* _48;
P2DPane* _4C;
P2DPane* mPaneRedPikis;
P2DPane* mPaneBluePikis;
P2DPane* mPaneYellowPikis;
P2DPane* _5C;
P2DPane* mPaneDaysL;
P2DPane* mPaneDaysC;
P2DPane* mPaneDaysR;
P2DPane* mPaneDaysLeftL;
P2DPane* mPaneDaysLeftC;
P2DPane* mPaneDaysLeftR;
P2DPane* mPanePartsLeftL;
P2DPane* mPanePartsLeftC;
P2DPane* mPanePartsLeftR;
P2DPane* mPaneData;
P2DPane* mPaneFileNum1;
P2DPane* mPaneFileNum2;
P2DPane* mPaneFileNum3;
P2DTextBox* mDiaryTemplateTextBox;
P2DPane* mPaneBornThousandsDigit;
P2DPane* mPaneDeadThousandsDigit;
P2DPane* mPaneVictimThousandsDigit;
P2DPane* mPaneBornOnesDigit;
P2DPane* mPaneDeadOnesDigit;
P2DPane* mPaneVictimOnesDigit;
P2DPane* mPaneSproutedOnesDigit;
P2DPane* mPaneLostToBattleOnesDigit;
P2DPane* mPaneLeftBehindOnesDigit;
P2DPane* mPaneSproutedThousandsDigit;
P2DPane* mPaneLostToBattleThousandsDigit;
P2DPane* mPaneLeftBehindThousandsDigit;
P2DPane* mPaneRedThousandsDigit;
P2DPane* mPaneYellowThousandsDigit;
P2DPane* mPaneBlueThousandsDigit;
P2DPane* mPaneRedOnesDigit;
P2DPane* mPaneBlueOnesDigit;
P2DPane* mPaneYellowOnesDigit;
f32 mWaitTimer;
f32 mSaveWaitTimer;
s16 mBgAlpha;
s16 mGraphAlpha;
int mRedPikis;
int mBluePikis;
int mYellowPikis;
int mTotalPikis;
int mBornPikis;
int mDeadPikis;
int mVictimPikis;
int mSproutedPikis;
int mPikisLostToBattle;
int mLeftBehindPikis;
int _114;
int _118;
int mCurrentParts;
int mCurrentDay;
int mRemainingParts;
int mRemainingDays;
int mTotalParts;
int mTotalDays;
int mPowerupNum;
s16 mStartWaitDelay;
bool mHasBlue;
bool mHasRed;
bool mHasYellow;
char mDiaryTemplateTextBuffer[16];
char* mDiaryPathList[256];
char** mPageInfoPtr;
int _554;
int mSaveStatus;
};
extern char* bloFile_Res_Table[];
}
class RandomAccessStream;
class Creature;
struct ResultFlags {
public:
struct FlagInfo {
enum StoreType {
Store_Forget = 0,
Store_Reset = 1,
Store_Keep = 2,
};
int type();
int mScreenId;
bool mIsAutoSet;
int mPriority;
u32 mStore;
};
ResultFlags();
void initGame();
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
void setOn(int);
void setSeen(int);
int getDayDocument(int, int&);
int getDocument(int& pageCount);
void dump();
protected:
u8 getFlag(int);
void setFlag(int, u8);
static FlagInfo flagTable[];
u16 mLength;
u16 mActiveCount;
u16 mTableSize;
u8* mStates;
s16 mDaysSeen[(30) ];
u32* mScreenToTableList;
};
class Graphics;
class RandomAccessStream;
class Vector3f;
struct Choice {
int mValue;
f32 mChance;
};
struct BitFlags {
BitFlags();
void dump();
void loadCard(RandomAccessStream&);
void saveCard(RandomAccessStream&);
void create(u16, u8*);
void reset();
void setFlag(u16);
bool isFlag(u16);
void resetFlag(u16);
u8* mFlags;
u16 mEntryCount;
u16 mSize;
};
struct LoopChecker {
LoopChecker( char* loopName, f32 timeLimit);
void update();
f32 mLoopTimer;
char* mLoopName;
};
int selectRandomly( Choice* choiceList, int numChoices);
void drawBatten(Graphics&, Vector3f&, f32);
void drawBattenPole(Graphics&, Vector3f&, f32, char*);
void drawArrow(Graphics&, Vector3f&, Vector3f&, f32);
void CRSplineDraw(Graphics&, int, Vector3f* const);
void drawCube(Graphics&, Vector3f&, f32);
class Graphics;
class PelletShapeObject;
struct PermanentEffect;
class PikiShapeObject;
class Shape;
enum UfoPartVisType {
PARTVIS_Uncollected = 0,
PARTVIS_Visible = 1,
PARTVIS_Invisible = 2,
};
struct UfoPartsInfo {
u32 mPartID;
bool mUnusedFlag;
};
struct TimeGraph {
struct PikiNum {
void set(int color, int num)
{
if (color >= PikiMinColor && color <= PikiMaxColor) {
mNum[color] = num;
return;
}
mNum[Yellow] = num;
mNum[Red] = num;
mNum[Blue] = num;
}
int get(int color)
{
if (color >= PikiMinColor && color <= PikiMaxColor) {
return mNum[color];
}
return getSum();
}
int getSum() { return mNum[Blue] + mNum[Red] + mNum[Yellow]; }
int mNum[PikiColorCount];
};
TimeGraph();
void create(u16 startTime, u16 endTime);
void init();
void set(u16 time, int color, int num);
int get(u16 time, int color);
u16 mStartTime;
u16 mEndTime;
PikiNum* mEntries;
};
class PlayerState {
public:
class UfoParts : public PaniAnimKeyListener {
public:
UfoParts() { }
virtual void animationKeyUpdated( PaniAnimKeyEvent&);
void initAnim(PelletShapeObject*);
void startMotion(int);
void startMotion(int, int);
void stopMotion();
void setMotionSpeed(f32 speed) { mMotionSpeed = speed; }
int mRepairAnimJointIndex;
u32 mModelID;
u32 mPelletID;
PelletAnimator mAnimator;
Vector3f mRepairEffectPosition;
ShapeDynMaterials mAnimatedMaterials;
PelletShapeObject* mPelletShape;
f32 mMotionSpeed;
u8 mPartVisType;
};
PlayerState();
bool isEnding();
bool existUfoParts(u32);
void initGame();
bool courseOpen(int);
bool happyEndable();
void setChallengeMode();
int getPartsGetCount(int);
int getCardUfoPartsCount();
int getTotalPikiCount(int);
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
bool isTutorial();
bool isGameCourse();
bool checkLimitGenFlag(int);
void setLimitGenFlag(int);
bool displayPikiCount(int);
void setDisplayPikiCount(int);
bool hasUfoParts(u32 ufoIndex);
void update();
void initCourse();
void exitCourse();
void setNavi(bool);
int getFinalDeadPikis();
void updateFinalResult();
int getCurrDay();
int getTotalDays();
int getStartHour();
int getEndHour();
int getPikiHourCount(int, int);
int getTotalParts();
int getCurrParts();
bool isUfoBroken();
void registerUfoParts(int repairAnimJointIndex, u32 modelID, u32 pelletID);
void ufoAssignStart();
void startSpecialMotions();
void startAfterMotions();
void startUfoPartsMotion(u32, int, bool);
void getUfoParts(u32, bool);
int getNextPowerupNumber();
void preloadHenkaMovie();
void renderParts(Graphics&, Shape*);
void setDebugMode();
int getCardPikiCount(int);
int getUfoPercentage();
void init();
int getFinalBornPikis();
int getRestParts();
void lostUfoParts(u32);
void setContainer(int color) { mContainerFlag |= 1 << color; }
bool hasContainer(int color) { return mContainerFlag & (1 << color); }
void setBootContainer(int color) { mContainerFlag |= 1 << color + 3; }
bool hasBootContainer(int color) { return mContainerFlag & (1 << color + 3); }
int getLastPikmins() { return mLivingPikiNum; }
bool inDayEnd() { return mInDayEnd; }
void setDayEnd(bool set) { mInDayEnd = set; }
bool isChallengeMode() { return mIsChallengeMode; }
bool hasUfoRightControl() { return mShipEffectPartFlag & 4; }
bool hasUfoLeftControl() { return mShipEffectPartFlag & 2; }
bool hasRadar() { return mShipEffectPartFlag & 1; }
void setDayCollectCount(int day, int parts) { mPartsCollectedByDay[day] = parts; }
void setDayPowerupCount(int day, int parts) { mPartsToNextByDay[day] = parts; }
int getDayCollectCount(int day) { return mPartsCollectedByDay[day]; }
int getDayPowerupCount(int day) { return mPartsToNextByDay[day]; }
protected:
UfoParts* findUfoParts(u32);
static int totalUfoParts;
public:
int mSproutedNum;
int mLostBattlePikis;
int mLeftBehindPikis;
int mTotalPluckedPikiCount;
u8 mShipUpgradeLevel;
u8 mShipEffectPartFlag;
UfoParts* mCurrentRepairingPart;
u8 mPartsCollectedByDay[(30) ];
u8 mPartsToNextByDay[(30) ];
DemoFlags mDemoFlags;
ResultFlags mResultFlags;
bool mHasExtinctionDemoPlayed;
PikiShapeObject* mOlimarShapeObj;
PaniPikiAnimMgr mOlimarAnimMgr;
int mTotalRegisteredParts;
int mTotalParts;
UfoParts* mUfoParts;
int mCurrParts;
int mRequiredUfoPartCount;
u8 mContainerFlag;
bool mIsTutorialMode;
bool _186;
u8 mStagePartsCollected[STAGE_COUNT];
TimeGraph mPerHourGraph;
u16 mLastUpdatedTime;
TimeGraph mPerDayGraph;
int mTotalDeadPikiNum;
int mTotalBornPikiNum;
int mLivingPikiNum;
u8 mDisplayPikiFlag;
BitFlags** mCourseFlags;
bool mIsNaviPilot;
bool mInDayEnd;
bool mIsChallengeMode;
PermanentEffect* mNaviLightEfx;
PermanentEffect* mNaviLightGlowEfx;
Vector3f mNaviLightEfxPos;
};
extern bool preloadUFO;
extern PlayerState* playerState;
struct AIConstant : public Node {
struct Parms : public Parameters {
inline Parms()
: Parameters("AI::Parms")
, mGravity(this, 550.0f, 0.0f, 0.0f, "p00", "\202\266\202\343\202\244\202\350\202\345\202\255")
, _34(this, 1, 0, 0, "p01", "\203s\203L\201F\203I\201[\203g\203A\203^\203b\203N")
, _44(this, 1, 0, 0, "p02", "\203s\203L\201F\203I\201[\203g\224\262\202\253\216\350\223`\202\242")
, _54(this, 0, 0, 0, "p03", "\203i\203r\201F\224\262\202\253\203L\203\203\203\223\203Z\203\213")
, _64(this, 1, 0, 0, "p04", "\226\210\203t\203\214\201[\203\200\211\237\202\267")
, mDoCStickAttack(this, 1, 0, 0, "p05", "\213{\226{\220\332\220G\203o\203g\203\213")
, _84(this, 1, 0, 0, "p07", "\203t\203\212\201[\216\236\202\311\223G\202\251\202\347\223\246\202\260\202\351")
, _94(this, 1, 0, 0, "p06", "\203t\203\212\201[\216\236\201A\203w\203\212\203|\201[\203g\202\311\214\374\202\251\202\244")
, _A4(this, 1, 0, 0, "p08", "\215U\214\202\202\265\202\275\202\347\226\337\202\351")
, _B4(this, 1, 0, 0, "p09", "\203t\203H\201[\203\201\201[\203V\203\207\203\223\203\\\201[\203g")
, _C4(this, 1, 0, 0, "p10", "\202P\211\361\202\276\202\257\215U\214\202=1 \216\200\202\312\202\334\202\305\215U\214\202=0")
, mJumpTriangleAngleThreshold(this, 90.0f, 0.0f, 0.0f, "p11", "\203I\201[\203g\203W\203\203\203\223\203v\212p\223x")
, _E4(this, 1, 0, 0, "p12", "\223\212\202\260=1 \223]\202\252\202\265=0")
, mDoPluckWithCursor(this, 1, 0, 0, "p13", "\203J\201[\203\\\203\213\224\262\202\253")
, mDoScaleHappaMoveSpeed(this, 1, 0, 0, "p14", "\211\324\203s\203L\221\253\221\201")
, mMaxPikisOnField(this, (100) , 0, 0, "p15", "\203s\203L\201{\211\350 \203\212\203~\203b\203g")
, _124(this, 1, 0, 0, "p16", "\224\232\222e\225\373\216\256")
, mWeakSlipFactor(this, 1.0f, 0.0f, 0.0f, "p17", "\202\267\202\327\202\350\216\343")
, mStrongSlipFactor(this, 2.5f, 0.0f, 0.0f, "p18", "\202\267\202\327\202\350\213\255")
, _154(this, 6, 0, 0, "p19", "UFO LEVEL 2")
, _164(this, 12, 0, 0, "p20", "UFO LEVEL 3")
, _174(this, 29, 0, 0, "p21", "UFO LEVEL 4")
, _184(this, 30, 0, 0, "p22", "UFO LEVEL 5")
{
}
Parm<f32> mGravity;
Parm<int> _34;
Parm<int> _44;
Parm<int> _54;
Parm<int> _64;
Parm<int> mDoCStickAttack;
Parm<int> _84;
Parm<int> _94;
Parm<int> _A4;
Parm<int> _B4;
Parm<int> _C4;
Parm<f32> mJumpTriangleAngleThreshold;
Parm<int> _E4;
Parm<int> mDoPluckWithCursor;
Parm<int> mDoScaleHappaMoveSpeed;
Parm<int> mMaxPikisOnField;
Parm<int> _124;
Parm<f32> mWeakSlipFactor;
Parm<f32> mStrongSlipFactor;
Parm<int> _154;
Parm<int> _164;
Parm<int> _174;
Parm<int> _184;
};
AIConstant();
virtual void read(RandomAccessStream& input)
{
mConstants.read(input);
}
static void createInstance();
static AIConstant* _instance;
Parms mConstants;
};
class Menu;
class AIPerf {
public:
void addMenu(Menu*);
static void clearCounts();
protected:
void toggleMoveType(Menu&);
void toggleGeneratorMode(Menu&);
void toggleBridge(Menu&);
void toggleShowRoute(Menu&);
void toggleAIGrid(Menu&);
void toggleKando(Menu&);
void toggleLOD(Menu&);
void toggleColls(Menu&);
void toggleASync(Menu&);
void toggleInsQuick(Menu&);
void toggleSoundDebug(Menu&);
void toggleUpdateMgr(Menu&);
void togglePikiMabiki(Menu&);
void togglePsOptimise(Menu&);
void toggleCollSort(Menu&);
void toggleIteratorCull(Menu&);
void toggleUseGrid(Menu&);
void incGridShift(Menu&);
void decGridShift(Menu&);
void incOptLevel(Menu&);
void decOptLevel(Menu&);
void incUfoLevel(Menu&);
void decUfoLevel(Menu&);
void toggleUpdateSearchBuffer(Menu&);
void collectPikis(Menu&);
void fullfillPiki(Menu&);
void flowerPiki(Menu&);
void breakSluice(Menu&);
public:
static int useGrid;
static int gridShift;
static bool pikiMabiki;
static bool useLOD;
static bool iteratorCull;
static int optLevel;
static bool bridgeFast;
static int drawshapeCullCnt;
static int outsideViewCnt;
static int viewCullCnt;
static int aiCullCnt;
static int iteratorCullCnt;
static int collisionCnt;
static int searchInsertCnt;
static int searchCullCnt;
static int searchCnt;
static int moveType;
static bool generatorMode;
static bool kandoOnly;
static bool soundDebug;
static bool updateSearchBuffer;
static bool loopOptimise;
static bool useUpdateMgr;
static bool psOptimise;
static int ufoLevel;
static bool showRoute;
static bool aiGrid;
static bool showColls;
static bool useASync;
static bool insQuick;
static bool useCollSort;
};
extern BOOL _nsPrint;
extern BOOL _cPrint;
extern BOOL _kPrint;
extern BOOL _nPrint;
extern BOOL _yPrint;
class Creature;
class CreatureInf;
class Piki;
class RandomAccessStream;
typedef CreatureInf* (*CreatureStoreFun)(Creature*);
typedef Creature* (*CreatureRestoreFun)(CreatureInf*);
class BaseInf : public CoreNode {
public:
BaseInf();
virtual void doStore(Creature*) { }
virtual void doRestore(Creature*) { }
virtual void saveCard(RandomAccessStream&);
virtual void loadCard(RandomAccessStream&);
void store(Creature*);
void restore(Creature*);
Vector3f mPosition;
Vector3f mRotation;
};
struct BPikiInf : public BaseInf {
BPikiInf();
virtual void doStore(Creature*);
virtual void doRestore(Creature*);
virtual void saveCard(RandomAccessStream&);
virtual void loadCard(RandomAccessStream&);
u8 mPikiColour;
u8 mNextKeyIndex;
};
class CreatureInf : public BaseInf {
public:
CreatureInf();
virtual void doStore(Creature*);
virtual void doRestore(Creature*);
EObjType mObjType;
int mCurrentDay;
int mRebirthDay;
int mAdjustFaceDirection;
int mObjInfo1;
int mObjInfo2;
f32 mHealth;
f32 mMaxHealth;
};
struct InfMgr {
virtual void init(int) { }
virtual BaseInf* getFreeInf() = 0;
virtual void delInf(BaseInf*) = 0;
virtual int getFreeNum() = 0;
virtual int getActiveNum() = 0;
};
struct MonoInfMgr : public InfMgr {
MonoInfMgr();
virtual void init(int);
virtual BaseInf* getFreeInf();
virtual void delInf(BaseInf*);
virtual int getFreeNum();
virtual int getActiveNum();
virtual BaseInf* newInf() = 0;
void loadCard(RandomAccessStream&);
void saveCard(RandomAccessStream&);
int mInfCount;
BaseInf** mInfs;
BaseInf mActiveList;
BaseInf mFreeList;
};
struct BPikiInfMgr : public MonoInfMgr {
virtual BaseInf* newInf();
int getPikiCount(int color);
void initGame();
};
struct CreatureInfMgr : public MonoInfMgr {
struct TypeData {
int mType;
CreatureStoreFun mStoreFun;
CreatureRestoreFun mRestoreFun;
};
virtual BaseInf* newInf();
static void beginRegister(int size);
static void registerType(int, CreatureStoreFun, CreatureRestoreFun);
static void endRegister();
static CreatureStoreFun getStoreFun(int);
static CreatureRestoreFun getRestoreFun(int);
void updateUseList();
void restoreAll();
static int maxTypes;
static int numTypes;
static int* idx2type;
static TypeData* typeData;
};
class PikiInfMgr {
public:
PikiInfMgr();
void initGame();
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
void incPiki(Piki*);
void incPiki(int, int);
void decPiki(Piki*);
void clear();
int getTotal();
int getColorTotal(int col) { return mPikiCounts[col][Leaf] + mPikiCounts[col][Bud] + mPikiCounts[col][Flower]; }
int mPikiCounts[PikiColorCount][PikiHappaCount];
};
struct StageInf {
void init();
void initGame();
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
BPikiInfMgr mBPikiInfMgr;
};
extern PikiInfMgr pikiInfMgr;
class Controller;
class ModeState;
class Menu;
enum GameSectionID {
SECTION_NinLogo = 0,
SECTION_Titles = 1,
SECTION_MovSample = 2,
SECTION_PaniTest = 3,
SECTION_OnePlayer = 4,
SECTION_OgTest = 5,
};
enum OnePlayerSectionID {
ONEPLAYER_GameSetup = 0,
ONEPLAYER_CardSelect = 1,
ONEPLAYER_E3Tutorial = 2,
ONEPLAYER_E3ForestDay1 = 3,
ONEPLAYER_E3ForestDay2 = 4,
ONEPLAYER_IntroGame = 5,
ONEPLAYER_MapSelect = 6,
ONEPLAYER_NewPikiGame = 7,
ONEPLAYER_GameCourseClear = 8,
ONEPLAYER_GameStageClear = 9,
ONEPLAYER_GameCredits = 10,
ONEPLAYER_GameExit = 11,
ONEPLAYER_E3_MIN = ONEPLAYER_E3Tutorial,
ONEPLAYER_E3_MAX = ONEPLAYER_E3ForestDay2,
ONEPLAYER_E3_STAGE_OFFSET = ONEPLAYER_E3Tutorial,
};
enum ModeUpdateFlags {
UPDATE_NONE = 0,
UPDATE_AI = 1 << 0,
UPDATE_WORLD_CLOCK = 1 << 1,
UPDATE_COUNTDOWN = 1 << 2,
UPDATE_ALL = UPDATE_AI | UPDATE_WORLD_CLOCK | UPDATE_COUNTDOWN,
};
struct Section : public Node {
Section() { }
virtual void init() = 0;
};
class BaseGameSection : public Node {
public:
BaseGameSection();
virtual void draw(Graphics& gfx);
virtual void openMenu() { }
Menu* mActiveMenu;
Controller* mController;
f32 mCurrentFade;
f32 mTargetFade;
f32 mFadeSpeed;
ModeState* mCurrentModeState;
ModeState* mNextModeState;
u32 mUpdateFlags;
int mPendingOnePlayerSectionID;
};
class ModeState {
public:
ModeState(BaseGameSection* game)
: mParentSection(game)
{
}
BaseGameSection* mParentSection;
virtual ModeState* update(u32& result)
{
result = UPDATE_AI | UPDATE_WORLD_CLOCK;
return this;
}
virtual void postRender(Graphics&) { }
virtual void postUpdate() { }
};
class Graphics;
class LoadIdler : public CoreNode {
public:
LoadIdler()
: CoreNode("")
{
}
virtual void init() { }
virtual void draw(Graphics&) { }
};
struct GameLoadIdler : public LoadIdler {
virtual void init() { }
virtual void draw(Graphics& gfx);
};
struct CARDStat;
class PlayState;
class RamStream;
extern u8 cardData[(0x26000) ];
class CardQuickInfo {
public:
CardQuickInfo() { mSaveStatus = 0; }
int mMemCardSaveIndex;
u32 mGameSaveSlot;
u32 mSaveStatus;
int mCurrentDay;
int mCurrentPartsCount;
int mRedPikiCount;
int mYellowPikiCount;
int mBluePikiCount;
int mMostRecentSaveSlot;
u32 mCrc;
};
struct MemoryCard : public CoreNode {
public:
inline MemoryCard()
: CoreNode("memoryCard")
{
mTempFileIndex = -1;
mCardChannel = -1;
mSaveFileIndex = -1;
mRequiredFreeSpace = (0x26000) ;
mErrorCode = 0;
}
void init();
bool hasCardFinished();
s32 getMemoryCardState(bool);
s32 getNewestOptionsIndex();
void loadOptions();
void saveOptions();
void loadCurrentGame();
void saveCurrentGame();
s32 makeDefaultFile();
void copyFile(CardQuickInfo&, CardQuickInfo&);
void delFile(CardQuickInfo&);
s32 doFormatCard();
bool isCardInserted();
bool hasCardChanged();
bool isFileBroken();
void breakFile();
void repairFile();
bool didSaveFail();
void getQuickInfos(CardQuickInfo*);
protected:
u32 calcChecksum(void*, u32);
void waitPolling();
void createFile(CARDStat&);
void writeOneBanner();
void writeOneOption(int);
void writeOneGameFile(int);
bool attemptFormatCard(int);
s32 waitWhileBusy(int);
bool getCardStatus(int);
void checkUseFile();
void loadCurrentFile();
void writeCurrentGame(RandomAccessStream*, PlayState&);
void readCurrentGame(RandomAccessStream*);
void initBannerArea(CARDStat&, char*);
void initFileArea(int, int);
void initOptionsArea(int);
u32 getOkSections();
int getOptionsOffset(int);
int getGameFileOffset(int);
void GetBlockSize(s32);
void* getBannerPtr();
void* getOptionsPtr(int);
void* getGameFilePtr(int);
void* FAKE_getGameFilePtr(int);
RamStream* getBannerStream();
RamStream* getOptionsStream(int);
RamStream* getGameFileStream(int);
public:
char mFilePath[32];
int mCardChannel;
int mSaveFileIndex;
int mTempFileIndex;
u32 mRequiredFreeSpace;
u32 mErrorCode;
u32 mOkSectionsMask;
BOOL mValidSlots[4];
int mValidBlockCount;
int mValidOptionsCount;
u32 mSectorSize;
bool mDidSaveFail;
int _UNUSED6C;
};
struct WorldClock {
void setTime(f32 timeOfDay);
void update(f32 playRate);
void setClockSpd(f32 minsPerGameDay);
void reset(f32 minsPerGameDay);
f32 age(f32 referenceDay);
f32 mRealSecsPerGameHour;
f32 mHoursInDay;
f32 mRealSecsPerGameDay;
u8 _0C[0x4];
f32 mPrevTimeOfDay;
f32 mRealSecsIntoHour;
f32 mTimeOfDay;
f32 mDeltaTimeOfDay;
int mCurrentGameHour;
int mCurrentDay;
int mCurrentGameMinute;
};
class AnimFrameCacher;
class BaseApp;
class GameQuickInfo;
class GameChalQuickInfo;
struct GameInterface;
struct GameGenFlow;
class Menu;
struct MoviePlayer;
struct Section;
class Shape;
class Texture;
enum GamePrefsFlags {
GAMEPREF_Vibe = 0x1,
GAMEPREF_Stereo = 0x2,
GAMEPREF_Child = 0x4,
};
enum GameFilterType {
FILTER_Custom = 0,
FILTER_DFOff = 1,
FILTER_COUNT,
};
enum MovSampleID {
MOV_GrowDemo = 0,
MOV_ThrowDemo = 1,
MOV_WorkDemo = 2,
MOV_DeathDemo = 3,
MOV_NormalEnding = 4,
MOV_HappyEnding = 5,
MOV_COUNT,
MOV_INTRO_CYCLE_MASK = 0x3,
MOV_ENDING_OFFSET = 0x3,
};
enum LanguageFileType {
LANGFILE_Dir = 0,
LANGFILE_Arc = 1,
LANGFILE_Bun = 2,
LANGFILE_Blo = 3,
LANGFILE_Tex = 4,
LANGFILE_COUNT,
};
enum ShipTextType {
SHIPTEXT_CollectEngine = -1,
SHIPTEXT_PartCollect = 0,
SHIPTEXT_PartsAccess = 1,
SHIPTEXT_PowerUp = 2,
SHIPTEXT_PartDiscovery = 3,
};
class GameQuickInfo {
public:
u32 mParts;
u32 mDay;
u32 mBornPikis;
u32 mDeadPikis;
int mPartsDaysRank;
int mBornPikisRank;
int mDeadPikisRank;
};
class GameChalQuickInfo {
public:
int mStageID;
u32 mScore;
int mRank;
u32 mCourseScores[(5) ];
};
struct LangMode {
void set( char* dir, char* arc, char* bun, char* blo, char* tex)
{
mDirPath = dir;
mArcPath = arc;
mBunPath = bun;
mBloPath = blo;
mTexPath = tex;
}
char* mDirPath;
char* mArcPath;
char* mBunPath;
char* mBloPath;
char* mTexPath;
};
struct GameGenNode : public Node {
inline GameGenNode( char* name, CoreNode* node)
: Node(name)
{
mNode = node;
}
CoreNode* mNode;
};
class PlayState : public CoreNode {
public:
enum SaveStatus {
Fresh = 1,
ReadyToSave = 2,
};
PlayState()
: CoreNode("playState")
{
mSaveSlot = 0;
mSaveStatus = Fresh;
}
virtual void read(RandomAccessStream& input);
virtual void write(RandomAccessStream& output);
void openStage(int storyStageID);
void Initialise()
{
mSaveStatus = Fresh;
mBluePikiCount = -1;
mYellowPikiCount = -1;
mRedPikiCount = -1;
mSavedDay = 1;
mShipPartsCount = 0;
(mCourseOpenFlags) = 1 << (STAGE_Practice) ;
}
bool isStageOpen(int storyStageID)
{
if (storyStageID >= STAGE_START && storyStageID <= STAGE_TESTMAP) {
return ((mCourseOpenFlags) & (1 << (storyStageID))) != false;
}
return false;
}
int mRedPikiCount;
int mYellowPikiCount;
int mBluePikiCount;
u8 mSaveStatus;
u8 mSavedDay;
u8 mShipPartsCount;
u8 mSaveSlot;
u32 mCourseOpenFlags;
};
struct GameRecMinDay {
GameRecMinDay() { Initialise(); }
void Initialise()
{
mNumParts = 0;
mNumDays = (30) ;
}
void read(RandomAccessStream& input)
{
mNumParts = input.readInt();
mNumDays = input.readInt();
}
void write(RandomAccessStream& output)
{
output.writeInt(mNumParts);
output.writeInt(mNumDays);
}
int mNumParts;
int mNumDays;
};
struct GameRecBornPikmin {
GameRecBornPikmin() { Initialise(); }
void Initialise() { mNumBorn = 0; }
void read(RandomAccessStream& input) { mNumBorn = input.readInt(); }
void write(RandomAccessStream& output) { output.writeInt(mNumBorn); }
int mNumBorn;
};
struct GameRecDeadPikmin {
GameRecDeadPikmin() { Initialise(); }
void Initialise() { mNumDead = 9999; }
void read(RandomAccessStream& input) { mNumDead = input.readInt(); }
void write(RandomAccessStream& output) { output.writeInt(mNumDead); }
int mNumDead;
};
struct GameRecChalCourse {
GameRecChalCourse() { Initialise(); }
void Initialise()
{
for (int i = 0; i < (5) ; i++) {
mScores[(5) ] = 0;
}
}
void read(RandomAccessStream& input)
{
for (int i = 0; i < (5) ; i++) {
mScores[i] = input.readInt();
}
}
void write(RandomAccessStream& output)
{
for (int i = 0; i < (5) ; i++) {
output.writeInt(mScores[i]);
}
}
int mScores[(5) ];
};
struct GameHiscores {
void Initialise()
{
mTotalPikis = 0;
for (int i = 0; i < (5) ; i++) {
mMinDayRecords[i].Initialise();
mBornPikminRecords[i].Initialise();
mDeadPikminRecords[i].Initialise();
mChalModeRecords[i].Initialise();
}
}
void read(RandomAccessStream& input)
{
mTotalPikis = input.readInt();
for (int i = 0; i < (5) ; i++) {
mMinDayRecords[i].read(input);
mBornPikminRecords[i].read(input);
mDeadPikminRecords[i].read(input);
mChalModeRecords[i].read(input);
}
}
void write(RandomAccessStream& output)
{
output.writeInt(mTotalPikis);
for (int i = 0; i < (5) ; i++) {
mMinDayRecords[i].write(output);
mBornPikminRecords[i].write(output);
mDeadPikminRecords[i].write(output);
mChalModeRecords[i].write(output);
}
}
int mTotalPikis;
GameRecMinDay mMinDayRecords[(5) ];
GameRecBornPikmin mBornPikminRecords[(5) ];
GameRecDeadPikmin mDeadPikminRecords[(5) ];
GameRecChalCourse mChalModeRecords[CHALSTAGE_COUNT];
};
struct GamePrefs : public CoreNode {
GamePrefs()
: CoreNode("gamePrefs")
{
Initialise();
}
virtual void read(RandomAccessStream& input);
virtual void write(RandomAccessStream& output);
void Initialise()
{
mFlags = GAMEPREF_Vibe | GAMEPREF_Stereo;
mBgmVol = 8;
mSfxVol = 8;
mMostRecentFileSlot = 0;
mHasSaveGame = false;
mMemCardSaveIndex = 0;
mSpareMemCardSaveIndex = 0;
_1F = 0;
mChalCourseOpenFlags = 0 ;
mChangesPending = false;
mHiscores.Initialise();
}
void setBgmVol(u8 vol);
void setSfxVol(u8 vol);
void setStereoMode(bool set);
void setVibeMode(bool set);
void setChildMode(bool set);
void getChallengeScores(GameChalQuickInfo& info);
void checkIsHiscore(GameChalQuickInfo& info);
void checkIsHiscore(GameQuickInfo& info);
void fixSoundMode();
void addBornPikis(u32 count) { mHiscores.mTotalPikis += count; }
void openStage(int chalStageID)
{
if (chalStageID >= CHALSTAGE_START && chalStageID <= CHALSTAGE_COUNT) {
(mChalCourseOpenFlags) |= 1 << (chalStageID) ;
}
}
bool isStageOpen(int chalStageID)
{
if (chalStageID >= CHALSTAGE_START && chalStageID <= CHALSTAGE_COUNT) {
return ((mChalCourseOpenFlags) & (1 << (chalStageID))) != false;
}
return false;
}
bool getVibeMode() { return (mFlags & GAMEPREF_Vibe) != 0; }
bool getStereoMode() { return (mFlags & GAMEPREF_Stereo) != 0; }
bool getChildMode() { return (mFlags & GAMEPREF_Child) != 0; }
u8 getBgmVol() { return mBgmVol; }
u8 getSfxVol() { return mSfxVol; }
bool isChallengeOpen() { return mChalCourseOpenFlags != 0; }
bool mChangesPending;
int mFlags;
u8 mBgmVol;
u8 mSfxVol;
bool mHasSaveGame;
u8 _1F;
u8 mMemCardSaveIndex;
u8 mSpareMemCardSaveIndex;
u8 mChalCourseOpenFlags;
GameHiscores mHiscores;
u32 mMostRecentSaveIndex;
u32 mMostRecentOptionsIndex;
u8 _E4[0x108 - 0xE4];
u32 mMostRecentFileSlot;
};
class GameFlow : public Node {
public:
struct Parms : public Parameters {
inline Parms()
: Parameters("GameFlow::Preferences")
, mStartHour(this, 7.0f, 0.0f, 0.0f, "t00", "startHour")
, mEndHour(this, 19.0f, 0.0f, 0.0f, "t01", "endHour")
, mRealMinutesPerGameDay(this, 20.0f, 0.0f, 0.0f, "p00", "daySpeed")
, mMorningStart(this, 7.0f, 0.0f, 0.0f, "p01", "mornStart")
, mMorningMid(this, 8.0f, 0.0f, 0.0f, "s01", "mornMid")
, mMorningEnd(this, 9.0f, 0.0f, 0.0f, "p02", "mornEnd")
, mEveningStart(this, 17.5f, 0.0f, 0.0f, "p03", "nightStart")
, mEveningMid(this, 18.5f, 0.0f, 0.0f, "s03", "nightMid")
, mEveningEnd(this, 19.5f, 0.0f, 0.0f, "p04", "nightEnd")
, mNightWarning(this, 16.0f, 0.0f, 0.0f, "p05", "nightWarning")
, mNightCountdown(this, 18.5f, 0.0f, 0.0f, "p06", "nightTimer")
, mTekiAbility(this, 1, 0, 0, "x99", "tekiAbility")
, mGameTitle(this, String("blah", 0), String("", 0), String("", 0), "x98", "gameTitle")
{
}
Parm<f32> mStartHour;
Parm<f32> mEndHour;
Parm<f32> mRealMinutesPerGameDay;
Parm<f32> mMorningStart;
Parm<f32> mMorningMid;
Parm<f32> mMorningEnd;
Parm<f32> mEveningStart;
Parm<f32> mEveningMid;
Parm<f32> mEveningEnd;
Parm<f32> mNightWarning;
Parm<f32> mNightCountdown;
Parm<int> mTekiAbility;
Parm<String> mGameTitle;
};
virtual void read(RandomAccessStream&);
virtual void update();
void drawLoadLogo(Graphics& gfx, bool force60FPSSpin, Texture* logoTex, f32 alphaFactor);
void menuToggleTimers(Menu& menu);
void menuTogglePrint(Menu& menu);
void menuToggleDInfo(Menu& menu);
void menuToggleDExtra(Menu& menu);
void menuToggleBlur(Menu& menu);
void menuToggleInfo(Menu& menu);
void menuToggleColls(Menu& menu);
void menuChangeFilter(Menu& menu);
void menuIncreaseFilter(Menu& menu);
void menuDecreaseFilter(Menu& menu);
Texture* setLoadBanner( char* texPath);
void hardReset(BaseApp* baseApp);
void softReset();
Shape* loadShape( char* modelPath, bool checkCache);
void addGenNode( char* name, CoreNode* node);
void addOptionsMenu(Menu* parent);
void addFilterMenu(Menu* parent);
Parms* mParameters;
MemoryCard mMemoryCard;
GamePrefs mGamePrefs;
u32 mSaveGameCrc;
PlayState mPlayState;
int mCurrentStageID;
int mPendingStageUnlockID;
u32 _1D4;
u32 mDemoFlags;
MoviePlayer* mMoviePlayer;
s16 mShipTextPartID;
s16 mShipTextType;
s16 mIsDayEndActive;
s16 mIsDayEndTriggered;
GameInterface* mGameInterface;
int mCurrGameSectionID;
int mNextGameSectionID;
s32 mNextOnePlayerSectionID;
u8 _1F8[0x4];
int mNextOnePlayerSectionOnDayEnd;
u32 _200;
Section* mGameSection;
LangMode mLangModes[LANG_CAPACITY];
int mLanguageIndex;
u32 mNextIntroMovieID;
u32 mCurrIntroMovieID;
BOOL mIsChallengeMode;
u32 _2B8;
u32 mGenFlowUpdateTickCount;
f32 mLoadTimeSeconds;
f32 mCurrLoadTextAlpha;
vf32 mTargetLoadTextAlpha;
f32 mLoadTextDisplayTimer;
int mAppTickCounter;
BOOL mIsNintendoLoadLogo;
WorldClock mWorldClock;
f32 mTimeMultiplier;
AnimFrameCacher* mFrameCacher;
GameGenFlow* mFlowManager;
Texture* mLevelBannerTex;
f32 mLevelBannerFadeValue;
Texture* mLastLoadedBannerTex;
GameLoadIdler mGameLoadIdler;
u8 _330[0x4];
BOOL mIsPauseAllowed;
BOOL mIsUIOverlayActive;
BOOL mPauseAll;
BOOL mIsTutorialTextActive;
u8 _344[0x4];
u32 _348;
u32 _34C;
int mFilterType;
u8 mVFilters[FILTER_COUNT][8];
};
extern GameFlow gameflow;
struct GameGenFlow : public Node {
GameGenFlow(char* name)
: Node(name)
{
_24 = 332;
_20 = 32;
_28 = 1;
_2C = 0;
}
virtual void update()
{
gameflow.mGenFlowUpdateTickCount++;
gameflow.mWorldClock.mRealSecsPerGameDay = 60.0f * (gameflow.mTimeMultiplier * gameflow.mParameters->mRealMinutesPerGameDay());
gameflow.mWorldClock.mRealSecsPerGameHour = gameflow.mWorldClock.mRealSecsPerGameDay / gameflow.mWorldClock.mHoursInDay;
Node::update();
}
int _20;
int _24;
int _28;
u32 _2C;
};
void preloadLanguage();
class CmdStream;
struct GenFileInfo : public CoreNode {
inline GenFileInfo()
: CoreNode("")
{
}
u8 mFirstSpawnDay;
u8 mLastSpawnDay;
u8 mDayLimit;
};
class StageInfo : public CoreNode {
public:
inline StageInfo()
: CoreNode("stageInfo")
{
mStageIndex = 0;
mStageID = STAGE_TESTMAP;
mChalStageID = CHALSTAGE_NOT;
mHasInitialised = (0) ;
mGenFileList.initCore("");
}
virtual void read(RandomAccessStream&);
void parseGenerators(CmdStream*);
void write(RandomAccessStream&);
char* mStageName;
char* mFileName;
BOOL mIsVisible;
BOOL mHasInitialised;
u16 mStageIndex;
u16 mStageID;
u16 mChalStageID;
StageInf mStageInf;
GenFileInfo mGenFileList;
};
struct OnePlayerSection : public Section {
virtual void init();
};
class StageInfo;
class Navi;
enum EndingType {
ENDING_None = 0,
ENDING_Neutral = 1,
ENDING_Happy = 2,
};
enum GameEndFlag {
GAMEEND_None = 0,
GAMEEND_PikminExtinction = 1,
GAMEEND_NaviDown = 2,
GAMEEND_Clear = 3,
};
enum GameEndCause {
ENDCAUSE_PikminZero = 0,
ENDCAUSE_NaviDown = 1,
};
class FlowController {
public:
inline FlowController()
{
mEndingType = ENDING_None;
mIsVersusMode = (0) ;
}
void readMapList( char* fileName);
void setStage( char* fileName);
StageInfo mStageList;
StageInfo* mCurrentStage;
u8 _AC[0x4];
char mMapModelFilePath[0x80];
char mCurrStageFilePath[0x80];
char mDoorStageFilePath[0x80];
BOOL mIsVersusMode;
int mGameEndFlag;
BOOL mIsDayEndSeqStarted;
BOOL mIsSunsetWhistleActive;
BOOL mIsSunsetStateForceEnded;
int mEndingType;
u32 mClearStatePikiCount;
u32 mNaviSeedCount;
u32 _250;
u32 _254;
u32 _258;
};
extern FlowController flowCont;
struct GameStat {
class Counter {
public:
Counter() { mCount = 0; }
void init() { mCount = 0; }
void inc() { mCount++; }
operator int() { return mCount; }
void dump( char*);
int mCount;
};
class ColCounter {
public:
ColCounter() { mCounts[Blue] = mCounts[Red] = mCounts[Yellow] = 0; }
void init() { mCounts[Blue] = mCounts[Red] = mCounts[Yellow] = 0; }
operator int() { return mCounts[Blue] + mCounts[Red] + mCounts[Yellow]; }
int operator[](int color) { return mCounts[color]; }
void set(int val, int color) { mCounts[color] = val; }
void add(int color, int amt) { mCounts[color] += amt; }
void dec(int color) { mCounts[color]--; }
void inc(int color) { mCounts[color]++; }
void dump( char*);
int mCounts[PikiColorCount];
};
static void init();
static void update();
static void dump();
static ColCounter deadPikis;
static ColCounter fallPikis;
static ColCounter formationPikis;
static ColCounter freePikis;
static ColCounter workPikis;
static ColCounter mePikis;
static ColCounter containerPikis;
static ColCounter bornPikis;
static ColCounter victimPikis;
static ColCounter mapPikis;
static ColCounter allPikis;
static Counter killTekis;
static Counter getPellets;
static int minPikis;
static int maxPikis;
static bool orimaDead;
};
template <typename T>
class AState;
template <typename T>
class StateMachine;
class AICreature;
class CollEvent;
struct SAIContext {
SAIContext()
{
mCollidingCreature = 0 ;
_08.set(0.0f, 0.0f, 0.0f);
mCounter = 0;
mCurrAnimId = 0;
mCurrentState = 0 ;
mCurrentItemHealth = 0.0f;
}
Creature* mCollidingCreature;
Creature* mTargetCreature;
Vector3f _08;
int mCurrAnimId;
int mCounter;
f32 mCurrentItemHealth;
f32 _20;
f32 mMaxItemHealth;
AState<AICreature>* mCurrentState;
StateMachine<AICreature>* mStateMachine;
int mCurrentEventCount;
int mMaxEventCount;
bool mEventFlags[16];
};
class AICreature : public Creature, public PaniAnimKeyListener {
public:
AICreature(CreatureProp*);
virtual void collisionCallback( CollEvent&);
virtual void bounceCallback();
virtual void refresh(Graphics&) = 0;
virtual void doKill() = 0;
virtual AState<AICreature>* getCurrState() { return mSAICtx.mCurrentState; }
virtual void setCurrState(AState<AICreature>* state) { mSAICtx.mCurrentState = state; }
virtual void playSound(int) { }
virtual void playEffect(int) { }
virtual void startMotion(int) { }
virtual void finishMotion() { }
virtual void finishMotion(f32) { }
virtual void startMotion(int, f32) { }
virtual char* getCurrentMotionName() { return "noname"; }
virtual f32 getCurrentMotionCounter() { return -123.4f; }
virtual f32 getMotionSpeed() { return -123.4f; }
virtual void setMotionSpeed(f32) { }
virtual void stopMotion() { }
virtual void animationKeyUpdated( PaniAnimKeyEvent&);
void clearEventFlags();
void setEventFlag(int, bool);
bool checkEventFlag(int);
SAIContext mSAICtx;
};
class Condition;
class Texture;
class Vector3f;
class ObjectMgr : public Traversable, public Node {
public:
ObjectMgr()
: Node()
{
}
virtual Creature* getCreature(int) = 0;
virtual int getFirst() = 0;
virtual int getNext(int) = 0;
virtual bool isDone(int) = 0;
virtual ~ObjectMgr() { }
virtual void update();
virtual void postUpdate(int unused, f32 deltaTime);
virtual void stickUpdate();
virtual void refresh(Graphics&);
virtual void drawShadow(Graphics&, Texture*);
virtual int getSize() = 0;
virtual int getMax() = 0;
virtual Creature* findClosest( Vector3f&, f32, Condition*);
virtual Creature* findClosest( Vector3f&, Condition*);
virtual void search(ObjectMgr*);
virtual void killAll();
void invalidateSearch();
void store();
void restore();
};
struct MonoObjectMgr : public ObjectMgr {
friend struct SearchSystem;
public:
MonoObjectMgr();
virtual ~MonoObjectMgr() { }
virtual void update();
virtual void postUpdate(int unused, f32 deltaTime);
virtual void refresh(Graphics&);
virtual void drawShadow(Graphics&, Texture*);
virtual int getSize() { return mNumObjects; }
virtual int getMax() { return mMaxElements; }
virtual void search(ObjectMgr*);
virtual Creature* birth();
virtual void kill(Creature*);
virtual Creature* createObject() = 0;
void create(int);
void searchSelf();
protected:
virtual Creature* getCreature(int);
virtual int getFirst();
virtual int getNext(int);
virtual bool isDone(int);
int getEmptyIndex();
int getIndex(Creature*);
Creature** mObjectList;
int mMaxElements;
int mNumObjects;
int* mEntryStatus;
u32 _38;
};
struct PolyObjectMgr : public ObjectMgr {
PolyObjectMgr(int);
struct PolyData {
Creature* mClassObj;
int mClassSize;
int mClassId;
};
virtual ~PolyObjectMgr() { }
virtual void update();
virtual void postUpdate(int unused, f32 deltaTime);
virtual void refresh(Graphics&);
virtual void drawShadow(Graphics&, Texture*);
virtual int getSize() { return mActiveObjects; }
virtual int getMax() { return mPoolCapacity; }
virtual void search(ObjectMgr*);
virtual Creature* birth(int);
virtual void kill(Creature*);
void create(int);
int getTemplateID(int i) { return mEntries[i].mClassId; }
int getNumTemplates() { return mEntryCount; }
protected:
virtual Creature* getCreature(int);
virtual int getFirst();
virtual int getNext(int);
virtual bool isDone(int);
void beginRegister();
void endRegister();
void registerClass(int objType, Creature* object, int size);
int getEmptyIndex();
int getIndex(Creature*);
int getTemplateIndex(int i);
Creature* get(int);
void searchSelf();
int mMaxSize;
int mPoolCapacity;
int mActiveObjects;
u8 _34[0x4];
u8* mObjectPool;
int* mObjectIndices;
int mMaxClassLength;
u32 mEntryCount;
PolyData* mEntries;
};
struct CreatureNode : public CoreNode {
inline CreatureNode()
: CoreNode("cnode")
{
mCreature = 0 ;
}
Creature* mCreature;
};
struct CreatureNodeMgr : public ObjectMgr {
virtual Creature* getCreature(int);
virtual int getFirst();
virtual int getNext(int);
virtual bool isDone(int);
virtual ~CreatureNodeMgr() { }
virtual int getSize();
virtual int getMax() { return 0x10000; }
CreatureNode mRootNode;
};
class AICreature;
class SAIEvent;
class SAIAction;
class SAIArrow;
class SimpleAI : public StateMachine<AICreature> {
public:
SimpleAI();
virtual void procMsg(AICreature*, Msg*);
virtual void exec(AICreature*);
void addState(int, int, SAIAction* = 0 , SAIAction* = 0 , SAIAction* = 0 );
SAIArrow* addArrow(int, SAIEvent*, int);
void start(AICreature*, int);
void checkEvent(AICreature*);
};
struct BuildingItemProp;
struct GoalAI;
class GoalItem;
struct GoalItemProp;
struct KusaItemProp;
class MeltingPotMgr;
class PelletShapeObject;
class PikiHeadMgr;
struct SluiceAI;
class UfoItem;
struct UfoItemProp;
class UfoShapeObject;
class ItemShapeObject {
public:
ItemShapeObject(Shape*, char*, char*);
Shape* mShape;
AnimMgr* mAnimMgr;
AnimContext mAnimContext;
};
class ItemCreature : public AICreature {
public:
ItemCreature(int objType, CreatureProp*, Shape*);
virtual void init( Vector3f&);
virtual f32 getHeight() { return 0.0f; }
virtual bool stimulate( Interaction&);
virtual void update();
virtual void refresh(Graphics&);
virtual void doAI();
virtual void doAnimation();
virtual void startMotion(int);
virtual void finishMotion();
virtual void finishMotion(f32);
virtual void startMotion(int, f32);
virtual char* getCurrentMotionName();
virtual f32 getCurrentMotionCounter();
virtual f32 getMotionSpeed();
virtual void setMotionSpeed(f32);
virtual void stopMotion();
virtual void finalSetup() { _3C4 = true; }
protected:
virtual void doKill();
public:
f32 mMotionSpeed;
Shape* mItemShape;
SearchData mItemSearchData[8];
PaniItemAnimator mItemAnimator;
ItemShapeObject* mItemShapeObject;
bool _3C4;
};
class ItemMgr : public PolyObjectMgr {
public:
struct UseNode : public CoreNode {
UseNode() { initCore("usageNode"); }
int mType;
};
ItemMgr();
virtual ~ItemMgr() { }
virtual void update();
virtual void refresh(Graphics&);
virtual Creature* birth(int);
virtual void kill(Creature*);
virtual void refresh2d(Graphics&);
GoalItem* getContainer(int color);
GoalItem* getNearestContainer( Vector3f&, f32);
UfoItem* getUfo();
void addUseList(int);
ItemShapeObject* getPelletShapeObject(int, int);
void initialise();
int getContainerExitCount();
ObjectMgr* getMgr(int);
int getPikiNum();
bool useObjType(int type);
void showInfo();
Shape* getUfoShape();
MeltingPotMgr* getMeltingPotMgr() { return mMeltingPotMgr; }
PikiHeadMgr* getPikiHeadMgr() { return mPikiHeadMgr; }
Shape* getPebbleShape(int i) { return mPebbleShapeList[i]; }
Shape* getGrassShape(int i) { return mGrassShapeList[i]; }
Shape* mPebbleShapeList[3];
Shape* mGrassShapeList[3];
PikiHeadMgr* mPikiHeadMgr;
MeltingPotMgr* mMeltingPotMgr;
UseNode mRootUseNode;
u8 _84[0x4];
ItemShapeObject** mItemShapes;
UfoShapeObject* mUfoShape;
PaniMotionTable* mItemMotionTable;
PaniMotionTable* mUfoMotionTable;
};
class MeltingPotMgr : public CreatureNodeMgr {
public:
MeltingPotMgr(ItemMgr*);
virtual ~MeltingPotMgr() { }
void finalSetup();
void prepare(int objType);
Creature* birth(int objType);
ItemMgr* mItemMgr;
GoalItemProp* mGoalProps;
UfoItemProp* mUfoProps;
KusaItemProp* mKusaProps;
BuildingItemProp* mBuildProps;
GoalAI* mGoalAI;
SluiceAI* mSluiceAI;
Shape* mBouShape;
Shape* mBoBaseShape;
};
extern ItemMgr* itemMgr;
class SAIAction {
public:
virtual void act(AICreature*) = 0;
};
class SAICondition : public CoreNode {
public:
inline SAICondition()
: CoreNode()
{
}
virtual bool satisfy(AICreature*) { return true; }
};
class SAIEvent : public Receiver<AICreature> {
public:
SAIEvent()
: mEventID(-1)
{
}
void setFlag(AICreature* creature, bool value) { creature->setEventFlag(mEventID, value); }
void setContext(int eventID) { mEventID = eventID; }
bool satisfy(AICreature* creature) { return creature->checkEventFlag(mEventID); }
void reset();
int mEventID;
};
class SAIBounceEvent : public SAIEvent {
public:
virtual void procBounceMsg(AICreature*, MsgBounce*);
};
class SAICollideEvent : public SAIEvent {
public:
virtual void procCollideMsg(AICreature*, MsgCollide*);
};
class SAIGroundEvent : public SAIEvent {
public:
virtual void procGroundMsg(AICreature*, MsgGround*);
};
class SAIMotionAction0Event : public SAIEvent {
public:
virtual void procAnimMsg(AICreature*, MsgAnim*);
};
class SAIMotionDoneEvent : public SAIEvent {
public:
virtual void procAnimMsg(AICreature*, MsgAnim*);
};
class SAIMotionLoopStartEvent : public SAIEvent {
public:
virtual void procAnimMsg(AICreature*, MsgAnim*);
};
class SAIMotionLoopEndEvent : public SAIEvent {
public:
virtual void procAnimMsg(AICreature*, MsgAnim*);
};
struct SAIUserEvent : public SAIEvent {
SAIUserEvent(int id) { mUserID = id; }
virtual void procUserMsg(AICreature*, MsgUser*);
int mUserID;
};
class SAIArrow : public CoreNode {
public:
SAIArrow(SAIEvent* event, int nextState)
: CoreNode("SAIArrow")
{
mEvent = event;
mNextStateID = nextState;
}
SAIArrow()
: CoreNode("SAIArrowRoot")
{
mNextStateID = -1;
mEvent = 0 ;
}
SAIArrow* addCondition(SAICondition* cond)
{
mCondition.add(cond);
return this;
}
void setEventContext()
{
if (mEvent) {
mEvent->setContext(mArrowIdx);
}
}
int mNextStateID;
SAIEvent* mEvent;
int mArrowIdx;
SAICondition mCondition;
};
struct SAIState : public AState<AICreature> {
SAIState(int);
virtual void procMsg(AICreature*, Msg*);
virtual void exec(AICreature*);
virtual void init(AICreature*);
virtual void cleanup(AICreature*);
SAIArrow mRootArrow;
int mArrowCount;
int mMotionIdx;
SAIAction* mInitAction;
SAIAction* mExecAction;
SAIAction* mCleanupAction;
};
void SAIEventInit();
extern SAIMotionDoneEvent* saiMotionDoneEvent;
extern SAIBounceEvent* saiBounceEvent;
extern SAIMotionLoopStartEvent* saiMotionLoopStartEvent;
extern SAIMotionLoopEndEvent* saiMotionLoopEndEvent;
extern SAICollideEvent* saiCollideEvent;
extern SAIGroundEvent* saiGroundEvent;
extern SAIMotionAction0Event* saiMotionAction0Event;
class ActorMgr;
struct NaviProp;
struct PoliceAI;
class SimpleAI;
class Actor : public AICreature {
friend class ActorMgr;
public:
Actor();
void setType(int, PikiShapeObject*, CreatureProp*, SimpleAI*);
virtual void startAI(int);
virtual void refresh(Graphics&);
virtual void update();
virtual void doAnimation();
virtual void doAI();
virtual void startMotion(int);
virtual void startMotion(int, f32);
virtual void finishMotion();
virtual void finishMotion(f32);
protected:
virtual void doKill();
PaniPikiAnimMgr mPikiAnimMgr;
PikiShapeObject* mPikiShape;
SearchData mSearchData[3];
ActorMgr* mMgr;
};
class ActorMgr : public MonoObjectMgr {
friend class Actor;
public:
ActorMgr(MapMgr*);
virtual ~ActorMgr() { }
Actor* newActor(int);
protected:
virtual Creature* createObject();
PaniMotionTable* mMotionTable;
PikiShapeObject** mShapeObjectList;
NaviProp** mNaviPropList;
PoliceAI** mPoliceAIList;
u32 mListsLength;
MapMgr* mMapMgr;
};
extern ActorMgr* actorMgr;
struct PoliceAI : public SimpleAI {
struct PoliceStateID { typedef
enum {
StopMove = 0,
GoToCreature = 1,
COUNT,
} Type; } ;
PoliceAI();
struct StopMove : public SAIAction {
StopMove()
{
}
virtual void act(AICreature* police)
{
police->mTargetVelocity.set(0.0f, 0.0f, 0.0f);
}
};
struct GoToCreature : public SAIAction {
GoToCreature()
{
}
virtual void act(AICreature* police)
{
Vector3f displacement = police->mSAICtx.mCollidingCreature->mSRT.t - police->mSRT.t;
f32 norm = displacement.normalise();
police->mTargetVelocity = 50.0f * displacement;
}
};
struct Reached : public SAICondition {
virtual bool satisfy(AICreature* police)
{
Vector3f displacement = police->mSAICtx.mCollidingCreature->mSRT.t - police->mSRT.t;
f32 distance = displacement.length();
return distance <= mSatisfyDistance;
}
Reached(f32 satisfyDistance)
: mSatisfyDistance(satisfyDistance)
{
}
f32 mSatisfyDistance;
};
struct SearchItem : public SAICondition {
virtual bool satisfy(AICreature* police)
{
Iterator iter(itemMgr);
Creature* target = 0 ;
f32 maxDistance = 900.0f;
Creature* candidates[16];
int candidateCount = 0;
for (iter.first(); !iter.isDone(); iter.next())
{
Creature* item = *iter;
if (item->mObjType == mSatisfyObjType && police->mSAICtx.mCollidingCreature != item) {
f32 distance = qdist2(item, police);
if (distance < maxDistance && candidateCount < (sizeof((candidates)) / sizeof(*(candidates))) ) {
candidates[candidateCount++] = item;
}
}
}
if (candidateCount > 0) {
target = candidates[static_cast<int>(gsys->getRand(1.0f) * candidateCount)];
}
if (target) {
police->mSAICtx.mCollidingCreature = target;
return true;
}
return false;
}
EObjType mSatisfyObjType;
};
};
class AgeServer;
class Creature;
class MapMgr;
class Pellet;
class Generator;
class GenType;
class GenArea;
class GenObject;
class GeneratorMgr;
class RandomAccessStream;
class TekiPersonality;
enum GenCarryOverFlags {
GENCARRY_SaveGenerator = 1 << 0,
GENCARRY_SaveCreature = 1 << 1,
GENCARRY_SaveSpawnCount = 1 << 2,
GENCARRY_SaveProperties = 1 << 3,
};
class BirthInfo {
public:
void set( Vector3f& pos, Vector3f& rot, Vector3f& scale, Generator* gen)
{
mPosition = pos;
mRotation = rot;
mScale = scale;
mGenerator = gen;
}
Vector3f mPosition;
Vector3f mRotation;
Vector3f mScale;
Generator* mGenerator;
};
template <typename T>
struct Factory {
typedef T* (*GenFunc)();
struct Member {
u32 mID;
GenFunc mGenFunction;
char* mName;
u32 mLatestVersion;
};
Factory(int maxSpawners)
{
mSpawnerInfo = new Member[maxSpawners];
mMaxSpawners = maxSpawners;
mSpawnerCount = 0;
}
T* create(u32 id)
{
for (int i = 0; i < mSpawnerCount; i++) {
if (id == mSpawnerInfo[i].mID) {
return mSpawnerInfo[i].mGenFunction();
}
}
return 0 ;
}
void registerMember(u32 id, GenFunc func, char* name, u32 latestVersion)
{
if (mSpawnerCount >= mMaxSpawners) {
return;
}
mSpawnerInfo[mSpawnerCount].mID = id;
mSpawnerInfo[mSpawnerCount].mGenFunction = func;
mSpawnerInfo[mSpawnerCount].mName = name;
mSpawnerInfo[mSpawnerCount].mLatestVersion = latestVersion;
mSpawnerCount++;
}
u32 _getLatestVersion(u32 id)
{
for (int i = 0; i < mSpawnerCount; i++) {
if (id == mSpawnerInfo[i].mID) {
return mSpawnerInfo[i].mLatestVersion;
}
}
return id;
}
Member* first()
{
mIterIndex = 0;
return next();
}
Member* next()
{
if (mIterIndex < mSpawnerCount) {
return &mSpawnerInfo[mIterIndex++];
}
return 0 ;
}
bool isDone(Member* member) { return !member; }
int mSpawnerCount;
int mMaxSpawners;
Member* mSpawnerInfo;
int mIterIndex;
};
class GeneratorCache {
public:
class Cache : public CoreNode {
public:
Cache()
{
initCore("");
mStageID = STAGE_Practice;
mGenCount = 0;
mTotalCacheSize = 0;
mCacheHeapOffset = 0;
}
Cache(u32 stageID)
: mStageID(stageID)
{
initCore("");
mGenCount = 0;
mTotalCacheSize = 0;
mCacheHeapOffset = 0;
}
void saveCard(RandomAccessStream& output);
void loadCard(RandomAccessStream& input);
void dump();
u32 mStageID;
u32 mCacheHeapOffset;
u32 mTotalCacheSize;
u32 mGenCacheSize;
u32 mCreatureCacheSize;
u32 mUfoPartsCacheSize;
u32 mGenCount;
u32 mCreatureCount;
u32 mUfoPartsCount;
};
GeneratorCache();
void init(u8*, int);
void initGame();
void saveCard(RandomAccessStream&);
void loadCard(RandomAccessStream&);
void preload(u32);
bool hasUfoParts(u32, u32);
void load(u32);
void beginSave(u32);
void endSave();
void saveGenerator(Generator*);
void prepareUfoParts(Cache*);
void loadUfoParts(Cache*);
void saveUfoParts(Pellet*);
void saveGeneratorCreature(Generator*);
void dump();
void assertValid();
protected:
void addOne(u32);
Cache* findCache(Cache&, u32);
Cache mAliveCacheList;
Cache mDeadCacheList;
u8* mCacheHeap;
int mTotalCacheSize;
int mUsedSize;
int mFreeSize;
u32 mCurrentSaveCacheIdx;
};
class GeneratorList {
public:
GeneratorList();
Generator* findGenerator(int idx);
void createRamGenerators();
void updateUseList();
Generator* mGenListHead;
};
struct GenBase : public Parameters {
GenBase(u32 id, char* type, char* name);
virtual void doWrite(RandomAccessStream&) { }
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void doRead(RandomAccessStream&) { }
virtual void update() { }
virtual void render(Graphics&) { }
virtual u32 getLatestVersion() { return 'udef'; }
void writeVersion(RandomAccessStream&);
void write(RandomAccessStream&);
void readVersion(RandomAccessStream&);
void read(RandomAccessStream&);
u32 mID;
u32 mVersion;
char* mType;
char* mName;
};
class GenObject : public GenBase {
public:
GenObject(u32 id, char* name)
: GenBase(id, "object type", name)
{
}
virtual u32 getLatestVersion();
virtual void updateUseList(Generator*, int) { }
virtual void init(Generator*) { }
virtual void update(Generator*) { }
virtual void render(Graphics&, Generator*) { }
virtual Creature* birth(BirthInfo&) = 0;
};
struct GenObjectActor : public GenObject {
GenObjectActor()
: GenObject('actr', "create actor")
{
mActorId = 0;
}
virtual void doRead(RandomAccessStream&);
virtual Creature* birth(BirthInfo&);
static void initialise();
int mActorId;
};
class GenObjectBoss : public GenObject {
public:
GenObjectBoss()
: GenObject('boss', "\203{\203X\202\360\220\266\202\336")
{
mBossID = 0;
mItemIndex = 0;
mItemColour = 0;
mItemCount = 0;
mPelletConfigIdx = -1;
}
virtual void doWrite(RandomAccessStream&);
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void doRead(RandomAccessStream&);
virtual void updateUseList(Generator*, int);
virtual Creature* birth(BirthInfo&);
static void initialise();
void readParameters(RandomAccessStream&);
void writeParameters(RandomAccessStream&);
int mBossID;
int mItemIndex;
int mItemColour;
int mItemCount;
int mPelletConfigIdx;
};
struct GenObjectDebug : public GenObject {
GenObjectDebug();
virtual void doRead(RandomAccessStream&);
virtual Creature* birth(BirthInfo&);
static void initialise();
Parm<int> mCollision;
Parm<int> mPikiNoAttack;
Parm<int> mNoCarryover;
Parm<int> mPelletDebug;
};
struct GenObjectItem : public GenObject {
GenObjectItem();
virtual void doWrite(RandomAccessStream&);
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void doRead(RandomAccessStream&);
virtual void updateUseList(Generator*, int);
virtual Creature* birth(BirthInfo&);
static void initialise();
Parm<int> mParameterA;
Parm<int> mParameterB;
Parm<int> mParameterC;
Parm<int> mParameterD;
int mObjType;
char mStageName[32];
char mPrintName[32];
};
struct GenObjectMapObject : public GenObject {
enum MapObjectType {
TYPE_SeeSaw,
TYPE_Log,
TYPE_Tabaco,
TYPE_Faller,
TYPE_Iwa,
TYPE_MiniSeeSaw,
TYPE_Kinoko,
TYPE_Lift,
};
GenObjectMapObject();
virtual void doRead(RandomAccessStream& input);
virtual void render(Graphics&, Generator*);
virtual Creature* birth(BirthInfo&);
static void initialise(MapMgr* mgr);
static MapMgr* mapMgr;
u32 mObjType;
};
class GenObjectMapParts : public GenObject {
public:
GenObjectMapParts()
: GenObject('mpar', "\203}\203b\203v\203p\201[\203c\202\360\220\266\202\336")
, _18(this, 1, 1, 1, "p00", "\211\322\223\256\215\305\222\341\220l\220\224")
, _28(this, 100, 100, 100, "p01", "\211\322\223\256\215\305\221\345\220l\220\224")
, _38(this, 0.0f, 0.0f, 0.0f, "p02", "\213N\223\256\202\334\202\305\202\314\216\236\212\324")
, _48(this, 2.0f, 2.0f, 2.0f, "p04", "\217I\223_\202\305\202\314\222\342\216~\216\236\212\324")
, _58(this, 60.0f, 60.0f, 60.0f, "p03", "\203X\203s\201[\203h")
{
mPartKind = 0;
mShapeIndex = 0;
mUseStartOffset = 0;
mStartPosition.set(0.0f, 0.0f, 0.0f);
mEndPosition.set(0.0f, 0.0f, 0.0f);
}
virtual void doRead(RandomAccessStream&);
virtual void render(Graphics&, Generator*);
virtual Creature* birth(BirthInfo&);
static void initialise(MapMgr*);
void refreshSection(AgeServer&);
static MapMgr* mapMgr;
Parm<int> _18;
Parm<int> _28;
Parm<f32> _38;
Parm<f32> _48;
Parm<f32> _58;
int _68;
int mPartKind;
int mShapeIndex;
int mUseStartOffset;
Vector3f mStartPosition;
Vector3f mEndPosition;
};
struct GenObjectNavi : public GenObject {
GenObjectNavi();
virtual void doRead(RandomAccessStream&);
virtual Creature* birth(BirthInfo&);
static void initialise();
};
struct GenObjectPellet : public GenObject {
GenObjectPellet();
virtual void doWrite(RandomAccessStream&);
virtual void doRead(RandomAccessStream&);
virtual void updateUseList(Generator*, int);
virtual Creature* birth(BirthInfo&);
static void initialise();
int mIndex;
ID32 mPelletId;
};
struct GenObjectPiki : public GenObject {
GenObjectPiki()
: GenObject('piki', "create PIKI")
, mSpawnState(this, 0, 0, 2, "p00", "state (0:buried) (1:free) (2:team)")
, mSpawnColor(this, 0, 0, 3, "p01", "color (0-2:3 random)")
{
}
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual Creature* birth(BirthInfo&);
Parm<int> mSpawnState;
Parm<int> mSpawnColor;
};
struct GenObjectPlant : public GenObject {
GenObjectPlant();
virtual void doRead(RandomAccessStream&);
virtual void updateUseList(Generator*, int);
virtual void render(Graphics&, Generator*);
virtual Creature* birth(BirthInfo&);
static void initialise();
int mPlantType;
};
struct GenObjectTeki : public GenObject {
GenObjectTeki();
virtual void doWrite(RandomAccessStream&);
virtual void doRead(RandomAccessStream&);
virtual void updateUseList(Generator*, int);
virtual Creature* birth(BirthInfo&);
static void initialise();
TekiPersonality* mPersonality;
int mTekiType;
};
class GenObjectWorkObject : public GenObject {
public:
GenObjectWorkObject();
virtual void doWrite(RandomAccessStream&);
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void doRead(RandomAccessStream&);
virtual void updateUseList(Generator*, int);
virtual Creature* birth(BirthInfo&);
static void initialise();
void changeNaviPos();
void setNaviPos();
Parm<int> mDay;
Parm<int> mHour;
Parm<int> _38;
Parm<f32> _48;
s32 mObjectType;
int mShapeType;
Vector3f mHinderRockPosition;
};
class GenObjectFactory : public Factory<GenObject> {
protected:
GenObjectFactory()
: Factory<GenObject>(12)
{
}
public:
static GenObject* getProduct(u32 id);
static void createInstance();
static GenObjectFactory* factory;
};
class GenType : public GenBase {
public:
GenType(u32 id, char* name)
: GenBase(id, "time type", name)
, mDaysToResurrection(this, 0, 0, 0, "b00", "\225\234\212\210\223\372\220\224")
, mCarryOver(this, 0, 0, 0, "b01", "\203L\203\203\203\212\201[\203I\201[\203o\201[")
{
}
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual u32 getLatestVersion();
virtual void init(Generator*) { }
virtual void update(Generator*) { }
virtual void render(Graphics&, Generator*) { }
virtual void setBirthInfo(BirthInfo&, Generator*) = 0;
virtual int getMaxCount() = 0;
Parm<int> mDaysToResurrection;
Parm<int> mCarryOver;
};
struct GenTypeAtOnce : public GenType {
GenTypeAtOnce()
: GenType('aton', "\215\305\217\211\202\251\202\347\221S\225\224\220\266\202\336")
, mMaxCount(this, 1, 0, 0, "p00", "\220\224")
{
}
virtual void init(Generator*);
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void setBirthInfo(BirthInfo&, Generator*);
virtual int getMaxCount();
Parm<int> mMaxCount;
};
struct GenTypeInitRand : public GenType {
GenTypeInitRand()
: GenType('irnd', "\215\305\217\211\202\251\202\347\220\266\202\336\201i\203\211\203\223\203_\203\200\201j")
, _38(this, 1, 0, 0, "p00", "\215\305\222\341\220\224")
, mMaxCount(this, 5, 0, 0, "p01", "\215\305\215\202\220\224")
{
}
virtual void init(Generator*);
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void setBirthInfo(BirthInfo&, Generator*);
virtual int getMaxCount();
Parm<int> _38;
Parm<int> mMaxCount;
};
struct GenTypeOne : public GenType {
GenTypeOne()
: GenType('1one', "\202P\202\302\202\276\202\257\202\244\202\336")
, _38(this, 0, 0, 0, "p00", "\211\361\223](x)")
, _48(this, 0, 0, 0, "p01", "\211\361\223](y)")
, _58(this, 0, 0, 0, "p02", "\211\361\223](z)")
{
}
virtual void init(Generator*);
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void render(Graphics&, Generator*);
virtual void setBirthInfo(BirthInfo&, Generator*);
virtual int getMaxCount() { return 1; }
Parm<int> _38;
Parm<int> _48;
Parm<int> _58;
};
class GenTypeFactory : public Factory<GenType> {
protected:
GenTypeFactory()
: Factory<GenType>(6)
{
}
public:
static GenType* getProduct(u32 id);
static void createInstance();
static GenTypeFactory* factory;
};
class GenArea : public GenBase {
public:
GenArea(u32 id, char* name)
: GenBase(id, "area type", name)
{
}
virtual u32 getLatestVersion();
virtual void init(Generator*) { }
virtual void update(Generator*) { }
virtual void render(Graphics&, Generator*) { }
virtual Vector3f getPos(Generator*) = 0;
virtual f32 getRadius() { return 0.0f; }
virtual void doWrite(RandomAccessStream&);
virtual void doRead(RandomAccessStream&);
Vector3f _18;
};
struct GenAreaCircle : public GenArea {
GenAreaCircle()
: GenArea('circ', "inside circle")
, mRadius(this, 50.0f, 0.0f, 0.0f, "p00", "\224\274\214a")
{
}
virtual Vector3f getPos(Generator*);
virtual void ramSaveParameters(RandomAccessStream&);
virtual void ramLoadParameters(RandomAccessStream&);
virtual void render(Graphics&, Generator*);
virtual f32 getRadius() { return mRadius(); }
Parm<f32> mRadius;
};
struct GenAreaPoint : public GenArea {
GenAreaPoint()
: GenArea('pint', "at a point")
{
}
virtual Vector3f getPos(Generator*);
virtual void render(Graphics&, Generator*);
};
class GenAreaFactory : public Factory<GenArea> {
protected:
GenAreaFactory()
: Factory<GenArea>(6)
{
}
public:
static GenArea* getProduct(u32 id);
static void createInstance();
static GenAreaFactory* factory;
};
class Generator : public Node {
public:
Generator();
Generator(int);
virtual void read(RandomAccessStream&);
virtual void update();
virtual void render(Graphics&);
bool isExpired();
void loadCreature(RandomAccessStream&);
void saveCreature(RandomAccessStream&);
void init();
void informDeath(Creature*);
void write(RandomAccessStream&);
~Generator();
void updateUseList();
void removeSelf(AgeServer&);
static bool ramMode;
void setDayLimit(int limit) { mDayLimit = limit; }
Vector3f getPos() { return mGenPosition + mGenOffset; }
int getRebirthDay() { return mGenType->mDaysToResurrection(); }
bool readFromRam() { return !mIsRamReadDisabled; }
int doAdjustFaceDir() { return mGenType->mCarryOver(); }
void changeNaviPos();
void setNaviPos();
void setOffset( Vector3f& ofs) { mGenOffset = ofs; }
void setPos( Vector3f& pos) { mGenPosition = pos; }
void genAge(AgeServer&);
void changeArea(AgeServer&);
void changeObject(AgeServer&);
void changeType(AgeServer&);
GenArea* mGenArea;
u32 mGenAreaID;
GenType* mGenType;
u32 mGenTypeID;
GenObject* mGenObject;
u32 mGenObjectID;
char mMemo[0x20];
ID32 mGeneratorName;
ID32 mGeneratorVersion;
u32 _70;
u32 mCarryOverFlags;
Generator* mPrevGenerator;
Generator* mNextGenerator;
GeneratorMgr* mMgr;
Creature* mLatestSpawnCreature;
int mAliveCount;
int mLatestSpawnDay;
int mRespawnInterval;
int mDayLimit;
Vector3f mGenPosition;
Vector3f mGenOffset;
bool mIsRamReadDisabled;
int mGeneratorListIdx;
};
class GeneratorMgr : public Node {
public:
GeneratorMgr();
virtual void update();
virtual void render(Graphics&);
void init();
void setDayLimit(int);
void updateUseList();
void read(RandomAccessStream&, bool);
void write(RandomAccessStream&);
void setLimitGenerator(bool val) { mIsLimitGenerator = val; }
void genWrite(AgeServer&);
void addGenerator(AgeServer&);
void removeGenerator(AgeServer&, Generator*);
protected:
void setNaviPos();
void changeNaviPos();
Generator* mGenListHead;
ID32 _24;
ID32 mGeneratorVersionId;
int mGenCount;
ID32 _40;
Vector3f mNaviPos;
f32 mNaviDirection;
bool mIsLimitGenerator;
};
extern GeneratorCache* generatorCache;
extern GeneratorList* generatorList;
extern GeneratorMgr* generatorMgr;
extern GeneratorMgr* onceGeneratorMgr;
extern GeneratorMgr* dailyGeneratorMgr;
extern GeneratorMgr* plantGeneratorMgr;
extern GeneratorMgr* limitGeneratorMgr;
class Creature;
class Vector3f;
enum GameMovieCommand {
MOVIECMD_TextDemo = 0,
MOVIECMD_Unused = 1,
MOVIECMD_ForceDayEnd = 2,
MOVIECMD_HideHUD = 3,
MOVIECMD_ShowHUD = 4,
MOVIECMD_GameEndCondition = 5,
MOVIECMD_ForceResults = 6,
MOVIECMD_StartMovie = 7,
MOVIECMD_EndMovie = 8,
MOVIECMD_FadeOut = 9,
MOVIECMD_FadeIn = 10,
MOVIECMD_CleanupDayEnd = 11,
MOVIECMD_StartTotalResults = 12,
MOVIECMD_SpecialDayEnd = 13,
MOVIECMD_SetPauseAllowed = 14,
MOVIECMD_CountDownLastSecond = 15,
MOVIECMD_StageFinish = 16,
MOVIECMD_CreateMenuWindow = 17,
};
struct GameInterface {
virtual void message(int, int) { }
virtual void movie(int, int, Creature*, Vector3f*, Vector3f*, u32, bool) { }
virtual void parseMessages() { }
virtual void parse(int, int) { }
};
class MemInfoNode : public CoreNode {
public:
MemInfoNode()
: CoreNode("meminfo")
{
}
};
class MemInfo : public MemInfoNode {
public:
int mMemorySize;
};
class MemStat {
public:
MemStat();
void reset();
void start( char* name);
void end( char* name);
void print();
int getMemorySize( char*);
int getRestMemory();
protected:
MemInfo* getInfo( char*);
void printInfoRec(MemInfo*, int);
MemInfo* getInfoRec( char*, MemInfo*);
MemInfo mInfoListRoot;
MemInfo* mCurrentInfo;
MemInfo* mPrevInfoStack[32];
u32 mStatCount;
};
extern MemStat* memStat;
class AgeServer;
class CmdStream;
class Graphics;
class Matrix4f;
class Vector3f;
class CinematicPlayer;
class CineShapeObject;
class ActorInstance;
struct CinePlayerFlags { typedef
enum {
Empty = 0,
Localized = 1 << 0,
Unknown = 1 << 1,
HideNavi = 1 << 2,
HideBluePiki = 1 << 3,
HideRedPiki = 1 << 4,
HideYellowPiki = 1 << 5,
NaviNoAI = 1 << 6,
NonGameMovie = 1 << 7,
Concurrent = 1 << 8,
CameraBlend = 1 << 9,
ShowTekis = 1 << 10,
ShowFreePiki = 1 << 11,
UpdateFreePiki = 1 << 12,
ShowFormPiki = 1 << 13,
UpdateFormPiki = 1 << 14,
ShowWorkPiki = 1 << 15,
UpdateWorkPiki = 1 << 16,
ObjWatching = 1 << 17,
ShowPellets = 1 << 18,
PauseAll = 1 << 19,
HideRedCont = 1 << 20,
PikiNearUfo = 1 << 21,
CameraReturn = 1 << 22,
UseNaviView = 1 << 31,
} Type; } ;
enum SceneSkipFlags {
SCENESKIP_NULL = 0,
SCENESKIP_Invalid = 1,
SCENESKIP_Skip = 2,
SCENESKIP_SkipAll = 3,
};
enum SceneFlags {
SCENEFLAG_Unk1 = 0x1,
SCENEFLAG_2 = 0x2,
SCENEFLAG_4 = 0x4,
SCENEFLAG_8 = 0x8,
SCENEFLAG_ModeNormal = SCENEFLAG_2,
SCENEFLAG_ModeLoop = SCENEFLAG_4,
};
enum CinPlayBackMode {
CINMODE_Play = 0x1,
CINMODE_LoopScene = 0x2,
};
class SceneData : public CoreNode {
public:
SceneData()
: CoreNode("")
{
mNumFrames = 0;
mNumCameras = 0;
mNumLights = 0;
}
void parse(CmdStream*);
void getAnimInfo(CmdStream*);
DataChunk* mCameraAnimations;
DataChunk* mLightAnimations;
CamDataInfo* mCameraData;
LightDataInfo* mLightData;
u32 mNumFrames;
int mNumCameras;
int mNumLights;
};
enum CineActorFlags {
CAF_MoveAiNavi = 1 << 0,
CAF_ColourAnims = 1 << 1,
CAF_FixedBlu = 1 << 2,
CAF_FixedRed = 1 << 3,
CAF_FixedYel = 1 << 4,
CAF_MoveDayEndNavi = 1 << 5,
CAF_MoveAiUfo = 1 << 6,
CAF_MoveAiPiki = 1 << 7,
CAF_NoSync = 1 << 8,
CAF_MoveAiOnion = 1 << 9,
CAF_DummyUfo = 1 << 10,
CAF_ObjMask1 = 1 << 11,
CAF_ObjMask2 = 1 << 12,
CAF_ObjMask3 = 1 << 13,
CAF_ObjMask4 = 1 << 14,
CAF_ObjMask5 = 1 << 15,
CAF_MoveFaller = 1 << 16,
CAF_NoXluSort = 1 << 17,
CAF_MultiColour = 1 << 18,
CAF_AllObjMasks = CAF_ObjMask1 | CAF_ObjMask2 | CAF_ObjMask3 | CAF_ObjMask4 | CAF_ObjMask5,
CAF_DayEndRedPikmin = CAF_ObjMask2,
CAF_DayEndYellowPikmin = CAF_ObjMask3,
CAF_DayEndBluePikmin = CAF_ObjMask4,
CAF_DayEndEnemyAttack = CAF_ObjMask1,
CAF_DayEndEnemyNoDeaths = CAF_ObjMask5,
CAF_BadEndingRedPikmin = CAF_ObjMask2,
CAF_BadEndingYellowPikmin = CAF_ObjMask3,
CAF_BadEndingBluePikmin = CAF_ObjMask4,
CAF_BadEndingExtraRed1 = CAF_ObjMask1,
CAF_BadEndingExtraRed2 = CAF_ObjMask5,
CAF_AllVisibleMask = 0xFFFFFFFF,
};
class ActorInstance : public CoreNode {
public:
ActorInstance()
: CoreNode("")
{
mActiveActor = 0;
mDefaultActor = 0;
mParentFirstChild = 0;
mAnimator.mMgr = 0;
_19E = false;
mMeteorFlag = false;
mUsingRocketLightPos = false;
mUseMeteorFxDir = false;
_6C = 0;
mAnimPlayState = 1;
mColourAnimIndex = -1;
mColourValue = 0.0f;
mFlags = CAF_ColourAnims;
mIsLeaf = (0) ;
}
void exitInstance();
void initInstance();
void checkEventKeys(f32, f32, Vector3f&);
void refresh( Matrix4f&, Graphics&, f32*);
void onceInit();
void ageChangeAttach(AgeServer&);
void ageChangeObject(AgeServer&);
void ageDelInstance(AgeServer&);
void genSection(AgeServer&);
Animator mAnimator;
ShapeDynMaterials mAnimatedMaterials;
Shape* mLeafModel;
CineShapeObject* mActiveActor;
CineShapeObject* mDefaultActor;
CineShapeObject* mParentFirstChild;
u32 mFlags;
int _6C;
int mAnimPlayState;
int mColourAnimIndex;
BOOL mIsLeaf;
CinematicPlayer* mParentPlayer;
f32 mColourValue;
Vector3f mCenterPosition;
Vector3f mActorWorldDir;
Vector3f mJointPositions[9];
Vector3f mRocketLightPosList[4];
zen::particleGenerator* mEffectList[9];
zen::particleGenerator* mEffectGrid[4][4];
bool mUseMeteorFxDir;
bool mMeteorFlag;
bool _19E;
bool mUsingRocketLightPos;
};
class SceneCut : public CoreNode {
public:
SceneCut()
: CoreNode("")
{
mStartFrame = 0;
mEndFrame = 0;
mActorList.initCore("");
mFlags = SCENEFLAG_Unk1 | SCENEFLAG_ModeNormal;
mSceneID = 0;
mSceneData = 0 ;
mKey.mPrev = mKey.mNext = &mKey;
}
ActorInstance* addInstance( char*);
void ageAddEffectKey(AgeServer&);
void ageAddInstance(AgeServer&);
void ageChangeScene(AgeServer&);
void ageDeleteCut(AgeServer&);
void ageRefresh(AgeServer&);
void genCutSection(AgeServer&);
int countEKeys();
int mFlags;
int mStartFrame;
int mEndFrame;
int mSceneID;
SceneData* mSceneData;
ActorInstance mActorList;
AnimKey mKey;
CinematicPlayer* mParentPlayer;
};
class CineShapeObject : public CoreNode {
public:
CineShapeObject()
: CoreNode("")
{
mMgr = 0 ;
mAnimFilePath = mBundleFilePath = 0 ;
}
void init( char* modelPath, char* animPath, char* bundlePath);
Shape* mModel;
char* mAnimFilePath;
char* mBundleFilePath;
AnimContext mContext;
AnimMgr* mMgr;
};
class CinematicPlayer {
public:
CinematicPlayer( char* cinFilePath);
void init( char* cinFilePath);
void loadCin( char* cinFilePath);
void addScene(SceneData* scene);
SceneCut* addCut(int sceneID, int startFrame, int endFrame);
void addActor(CineShapeObject* actor);
void addActor( char* modelFilePath, char* animFilePath, char* bundleFilePath);
SceneCut* addSceneCut();
void skipScene(int sceneSkipFlag);
BOOL update();
void addLights(Graphics& gfx);
void refresh(Graphics& gfx);
SceneData* addScene( char* dskFilePath);
CineShapeObject* findActor( char* modFilePath)
{
for (CineShapeObject* actor = static_cast<CineShapeObject*>(mActorList.mChild); actor; actor = static_cast<CineShapeObject*>(actor->mNext))
{
if (!strcmp(actor->mName, modFilePath)) {
return actor;
}
}
return 0 ;
}
SceneData* findScene(int sceneID)
{
int i = 0;
for (SceneData* scene = static_cast<SceneData*>(mDataList.mChild); scene; scene = static_cast<SceneData*>(scene->mNext))
{
if (i == sceneID) {
return scene;
}
i++;
}
return 0 ;
}
void calcMaxFrames()
{
mTotalDuration = 0;
for (SceneCut* shape = static_cast<SceneCut*>(mSceneList.mChild); shape; shape = static_cast<SceneCut*>(shape->mNext))
{
mTotalDuration += abs(shape->mEndFrame - shape->mStartFrame);
}
if (mCurrentPlaybackTime >= (f32)mTotalDuration) {
mCurrentPlaybackTime = (f32)mTotalDuration - 1.0f;
}
}
u32 mFlags;
u32 mType;
Matrix4f mWorldMtx;
Creature* mTarget;
SceneData mDataList;
SceneData* mCurrentData;
CineShapeObject mActorList;
SceneCut mSceneList;
SceneCut* mCurrentScene;
SceneCut* mPreviousScene;
int mPlaybackMode;
f32 mCurrentSceneStartTime;
f32 mPlaybackSpeed;
f32 mCurrentPlaybackTime;
f32 mCurrentSceneFrame;
f32 mPreviousSceneFrame;
int mTotalDuration;
int mSceneSkipFlag;
Vector3f mCameraPosition;
Vector3f mCameraLookAt;
Vector3f mStaticLookAt;
f32 mCameraTargetFov;
f32 mCameraBlendRatio;
bool mUseStaticCamera;
bool mIsPlaying;
};
class Creature;
class Graphics;
class Vector3f;
class MovieListInfo {
public:
int mMovieID;
char* mCinFileName;
};
struct MovieTransInfo {
u32 mMovieID;
int* mTransTable;
};
class MovieInfo : public CoreNode {
public:
MovieInfo()
: CoreNode("")
{
mPlayer = 0 ;
}
bool update();
bool setCamera(Graphics&);
void refresh(Graphics&);
u32 mMovieIndex;
CinematicPlayer* mPlayer;
Matrix4f mRootTransform;
u32 mActorVisMask;
};
struct MoviePlayer {
MoviePlayer();
void resetMovieList();
void fixMovieList();
void initMovie(MovieInfo*, int);
void startMovie(int movieIdx, int, Creature* target, Vector3f* pos, Vector3f* rot, u32 p6, bool isPlaying);
void sndStartMovie(MovieInfo*);
void initMovieFlags(MovieInfo*);
void sndStopMovie(MovieInfo*);
void update();
void skipScene(int);
void getLookAtPos(Vector3f&);
bool setCamera(Graphics&);
void addLights(Graphics&);
void refresh(Graphics&);
MovieListInfo* findMovie(int);
int translateIndex(int, int);
void sndFrameMovie(MovieInfo*);
void nextFrame();
void backFrame();
void setGameCamInfo(bool isGameCam, f32 fov, Vector3f& camPos, Vector3f& targetPos)
{
mIsGameCam = isGameCam;
mPreCutsceneCamFov = fov;
mPreCutsceneCamPosition = camPos;
mPreCutsceneCamLookAt = targetPos;
}
MovieInfo mPlayInfoList;
MovieInfo mMovieInfoList;
MovieInfo mStackInfoList;
int mCurrentFrame;
bool mIsActive;
bool mIsPaused;
u32 mActorVisMask;
Vector3f mTargetViewpoint;
Vector3f mLookAtPos;
f32 mTargetFov;
Vector3f mPreCutsceneCamPosition;
Vector3f mPreCutsceneCamLookAt;
f32 mPreCutsceneCamFov;
f32 mInitialCamBlend;
f32 mCamTransitionFactor;
bool mIsGameCam;
u32 _170;
};
enum CinDemoIDs {
DEMOID_FINISHED = -1,
DEMOID_NULL = 0,
DEMOID_OpeningIntroPt1 = 1,
DEMOID_OpeningIntroPt2 = 2,
DEMOID_OlimarWakeUp = 3,
DEMOID_FindOnyon = 4,
DEMOID_FindRedOnyon = 4,
DEMOID_FindYellowOnyon = 5,
DEMOID_FindBlueOnyon = 6,
DEMOID_LookAtFirstSprout = 7,
DEMOID_WaitForFirstSprout = 8,
DEMOID_MeetPikmin = 9,
DEMOID_MeetRedPikmin = 9,
DEMOID_MeetYellowPikmin = 10,
DEMOID_MeetBluePikmin = 11,
DEMOID_Unk12 = 12,
DEMOID_Unk13 = 13,
DEMOID_CollectFirstPellet = 14,
DEMOID_PushFirstBox = 15,
DEMOID_DiscoverMainEngine = 16,
DEMOID_ShipUpgrade = 17,
DEMOID_ShipUpgradePractice = 17,
DEMOID_ShipUpgradeForest = 18,
DEMOID_ShipUpgradeCave = 19,
DEMOID_CollectPart = 79,
DEMOID_CollectFirstPartPractice = 20,
DEMOID_CollectPartForest = 21,
DEMOID_CollectPartCaveLast = 22,
DEMOID_CollectPartYakushima = 23,
DEMOID_Unk24 = 24,
DEMOID_ShipUpgradeYakushima = 25,
DEMOID_ShipUpgradeLast = 26,
DEMOID_DayEnd = 28,
DEMOID_DayEndPractice = 28,
DEMOID_DayEndForest = 29,
DEMOID_DayEndCaveLast = 30,
DEMOID_DayEndYakushima = 31,
DEMOID_ChalDayEnd = 32,
DEMOID_ChalDayEndPractice = 32,
DEMOID_ChalDayEndForest = 33,
DEMOID_ChalDayEndCave = 34,
DEMOID_ChalDayEndYakushima = 35,
DEMOID_EndOfDayResults = 36,
DEMOID_Unk37 = 37,
DEMOID_Unk38 = 38,
DEMOID_Unk39 = 39,
DEMOID_Landing = 40,
DEMOID_LandingPractice = 40,
DEMOID_LandingForest = 41,
DEMOID_LandingCaveLast = 42,
DEMOID_LandingYakushima = 43,
DEMOID_PikminInOnyon = 44,
DEMOID_PikminInOnyonPractice = 44,
DEMOID_PikminInOnyonForest = 45,
DEMOID_Extinction = 46,
DEMOID_ExtDayEnd = 47,
DEMOID_ExtDayEndPractice = 47,
DEMOID_ExtDayEndForest = 48,
DEMOID_ExtDayEndCaveLast = 49,
DEMOID_ExtDayEndYakushima = 50,
DEMOID_OlimarDown = 51,
DEMOID_OliDownDayEnd = 52,
DEMOID_OliDownDayEndPractice = 52,
DEMOID_OliDownDayEndForest = 53,
DEMOID_OliDownDayEndCaveLast = 54,
DEMOID_OliDownDayEndYakushima = 55,
DEMOID_TakeOff = 56,
DEMOID_TakeOffPractice = 56,
DEMOID_TakeOffForest = 57,
DEMOID_TakeOffCaveLast = 58,
DEMOID_TakeOffYakushima = 59,
DEMOID_Unk60Cat = 60,
DEMOID_Unk60 = 60,
DEMOID_Unk61 = 61,
DEMOID_Unk62 = 62,
DEMOID_Unk63 = 63,
DEMOID_Unk64Cat = 64,
DEMOID_Unk64 = 64,
DEMOID_Unk65 = 65,
DEMOID_Unk66 = 66,
DEMOID_Unk67 = 67,
DEMOID_YellowWithBomb = 68,
DEMOID_BadEnding = 69,
DEMOID_BadEndingPractice = 69,
DEMOID_BadEndingForest = 70,
DEMOID_BadEndingCaveLast = 71,
DEMOID_BadEndingYakushima = 72,
DEMOID_BadEndingFailEscape = 73,
DEMOID_BadEndingOlimin = 74,
DEMOID_GoodEndingWave = 75,
DEMOID_GoodEndingOnyons = 76,
DEMOID_EndingSpace = 77,
DEMOID_CollectRadar = 78,
DEMOID_CollectPartPractice = 79,
DEMOID_CHECK_BGM_CAT = 80,
DEMOID_Unk80 = 80,
DEMOID_EndOfDayRedOnyon = 84,
DEMOID_EndOfDayYellowOnyon = 85,
DEMOID_EndOfDayBlueOnyon = 86,
DEMOID_GenericDayEnd = 87,
DEMOID_ChalDayEndLast = 88,
DEMOID_GenericLanding = 89,
DEMOID_Unk90 = 90,
DEMOID_Unk91 = 91,
DEMOID_Unk92 = 92,
DEMOID_Unk93 = 93,
DEMOID_Unk94 = 94,
DEMOID_Unk100 = 100,
DEMOID_ShipUpgradeNonSparkling = 101,
DEMOID_GenericDayEndChal = 102,
DEMOID_DayEndTakeOffLast = 109,
DEMOID_GoodEndingTakeOff = 113,
DEMOID_NeutralEndingLeaveOK = 114,
DEMOID_COUNT,
};
class CreatureProp {
public:
struct Parms : public Parameters {
inline Parms()
: Parameters("Creature::Property")
, mFriction(this, 0.5f, 0.0f, 1.0f, "s00", 0 )
, mWallReflection(this, 0.5f, 0.0f, 1.0f, "s01", 0 )
, mFaceDirAdjust(this, 0.25f, 0.0f, 1.0f, "s02", 0 )
, mAcceleration(this, 0.1f, 0.01f, 2.0f, "s03", 0 )
, mBounceFactor(this, 0.3f, 0.01f, 2.0f, "s04", 0 )
{
}
Parm<f32> mFriction;
Parm<f32> mWallReflection;
Parm<f32> mFaceDirAdjust;
Parm<f32> mAcceleration;
Parm<f32> mBounceFactor;
};
CreatureProp() { }
Parms mCreatureProps;
virtual void read(RandomAccessStream& input) { mCreatureProps.read(input); };
};
class Pellet;
class Graphics;
class Matrix4f;
class PelletView {
public:
inline PelletView()
: mPellet(0 )
{
}
virtual void viewInit() { }
virtual void viewKill() = 0;
virtual void viewDraw(Graphics&, Matrix4f&) = 0;
virtual void viewStartTrembleMotion(f32) { }
virtual void viewStartExplodeMotion(f32) { }
virtual void viewSetMotionSpeed(f32) { }
virtual void viewFinishMotion() { }
virtual void viewDoAnimation() { }
virtual f32 viewGetBottomRadius() = 0;
virtual f32 viewGetHeight() = 0;
virtual Vector3f viewGetScale() { return Vector3f(1.0f, 1.0f, 1.0f); }
void becomePellet(u32, Vector3f & , f32);
Pellet* mPellet;
};
class CPlate;
struct BurnEffect;
struct RippleEffect;
struct PermanentEffect;
struct SlimeEffect;
struct Kontroller;
struct NaviDrawer;
struct NaviStateMachine;
class GoalItem;
class NaviState;
class Piki;
struct PikiHeadItem;
class Navi : public Creature, public PaniAnimKeyListener, public PelletView {
public:
struct Locus {
Locus() { mCanBeThrown = (1) ; };
void update();
Vector3f mPosition;
Vector3f mVelocity;
PermanentEffect mEffect;
int mCanBeThrown;
MapMgr* mMapMgr;
};
Navi(CreatureProp*, int);
virtual void viewKill();
virtual void viewDraw(Graphics&, Matrix4f&);
virtual f32 viewGetBottomRadius();
virtual f32 viewGetHeight();
virtual void viewStartTrembleMotion(f32);
virtual f32 getiMass();
virtual f32 getSize();
virtual bool isVisible();
virtual bool isBuried();
virtual bool isAtari();
virtual bool ignoreAtari(Creature*);
virtual bool stimulate( Interaction&);
virtual void sendMsg(Msg*);
virtual void collisionCallback( CollEvent&);
virtual void bounceCallback();
virtual void jumpCallback();
virtual void wallCallback( Plane&, DynCollObject*);
virtual void offwallCallback(DynCollObject*);
virtual void dump();
virtual bool isRopable();
virtual void update();
virtual void postUpdate(int unused, f32 deltaTime);
virtual void refresh(Graphics&);
virtual void refresh2d(Graphics&);
virtual void demoDraw(Graphics&, Matrix4f*);
virtual void doAI();
virtual void doKill();
virtual void animationKeyUpdated( PaniAnimKeyEvent&);
virtual bool mayIstick() { return false; }
virtual f32 getShadowSize() { return 20.0f; }
bool demoCheck();
bool isNuking();
void startMovieInf();
void incPlatePiki();
void decPlatePiki();
int getPlatePikis();
void startDayEnd();
void updateDayEnd( Vector3f&);
void enterAllPikis();
void startDamageEffect();
void finishDamage();
void startKontroller();
void rideUfo();
void reset();
void findNextThrowPiki();
void startMotion( PaniMotionInfo&, PaniMotionInfo&);
void enableMotionBlend();
void updateWalkAnimation();
void callPikis(f32);
void callDebugs(f32);
void releasePikis();
bool procActionButton();
void letPikiWork();
void reviseController(Vector3f&);
void makeVelocity(bool);
void makeCStick(bool);
void draw(Graphics&);
void renderCircle(Graphics&);
bool orimaDamaged();
void throwPiki(Piki*, Vector3f&);
void swapMotion( PaniMotionInfo&, PaniMotionInfo&);
void finishLook();
void updateLook();
void startMovie(bool);
bool movieMode();
bool startDamage();
bool doMotionBlend();
void doAttack();
bool insideOnyon();
void procDamage(f32);
void throwLocus( Vector3f& pos);
void renderParabola(Graphics&, f32, f32);
AState<Navi>* getCurrState() { return mCurrState; }
void setCurrState(AState<Navi>* state) { mCurrState = state; }
void setPellet(bool isPellet) { mIsPellet = isPellet; }
bool isPellet() { return mIsPellet; }
void forceFinishLook()
{
mLookAtPosPtr = 0 ;
mHeadYawOffsetRel = mHeadPitchOffset = 0.0f;
mLookTimer = 0;
}
void startLook( Vector3f* pos)
{
mLookAtPosPtr = pos;
mLookTimer = 0;
}
protected:
void updateHeadMatrix();
public:
OdoMeter mOdoMeter;
zen::particleGenerator* mDamageEfxA;
zen::particleGenerator* mDamageEfxB;
zen::particleGenerator* mDamageEfxC;
bool mIsRidingUfo;
bool mIsPellet;
Kontroller* mKontroller;
Camera* mNaviCamera;
Vector3f* mLookAtPosPtr;
u8 mLookTimer;
f32 mHeadYawOffsetRel;
f32 mHeadPitchOffset;
Creature* mCollidedWorkObj;
f32 mCollidedWorkObjTimer;
Pellet* mSelectedShipPart;
bool mIsInWater;
int mPluckCursorVisibilityTimer;
BOOL mIsCursorVisible;
BurnEffect* mBurnEffect;
RippleEffect* mRippleEffect;
SlimeEffect* mSlimeEffect;
NaviStateMachine* mStateMachine;
ShadowCaster mShadowCaster;
f32 mMotionSpeed;
int mIsDayEnd;
ShapeDynMaterials mAnimatedMaterials;
Vector3f mCursorPosition;
f32 mCursorNaviDist;
Vector3f mCursorTargetPosition;
Vector3f mCursorWorldPos;
int mPendingLowerMotionId;
int mLowerMotionCooldown;
f32 mFlickIntensity;
GoalItem* mGoalItem;
bool mWithinContainer;
CPlate* mPlateMgr;
f32 mPlateYaw;
bool mPlateDirLocked;
bool mRearrangePending;
int mFormationBand;
int mFormationBandStableTimer;
bool mIsCStickNeutral;
u8 _725[0x72C - 0x725];
u32 mSeedCollectionCount;
u32 _730;
int mCurrKeyCount;
f32 mNeutralTime;
u8 _73C[0x4];
Vector3f mPrevMainStick;
Vector3f mMainStick;
Vector3f mPrevCStick;
Vector3f mCStick;
u32 _770;
PermanentEffect* mNaviLightEfx;
PermanentEffect* mNaviLightGlowEfx;
PermanentEffect* _77C;
PermanentEffect* _780;
Vector3f mNaviLightPosition;
Vector3f mDayEndPosition;
Vector3f mWalkAnimPrevPos;
f32 mAiTickTimer;
Plane* mWallPlane;
DynCollObject* mWallCollObj;
int mAiHitWall;
int _7B8;
Piki* mPikiToPluck;
PikiHeadItem* mSproutToPluck;
Vector3f _7C4;
f32 _7D0;
u8 _7D4[0x7D8 - 0x7D4];
SmartPtr<Creature> mAttackTarget;
f32 mWalkAnimPrevDir;
int mPreBlendLowerMotionID;
bool mIsPlucking;
u8 mFastPluckKeyTaps;
u8 mNoPluckTimer;
u8 _7E7[0x7F0 - 0x7E7];
int mLociCount;
Locus* mLoci;
Piki* mNextThrowPiki;
bool _7FC;
f32 mThrowHoldTime;
f32 mThrowDistance;
f32 mThrowHeight;
int mFormationPriMode;
u32 _810;
f32 mPressedTimer;
f32 _818;
Vector3f _81C;
u32 _828;
PikiShapeObject* mNaviShapeObject;
bool mForcePikiDistCheck;
PaniPikiAnimMgr mNaviAnimMgr;
SearchData mNaviSearchData[6];
u32 _928;
int mNaviID;
bool _930;
int _934;
Vector3f mWhistleFxPosArr[32];
f32 mWhistleTimer;
int mWhistleCircleMode;
f32 mWhistleRadiusFrac;
f32 _AC4;
f32 mWhistleCircleRadius;
bool _ACC;
CollTriInfo* _AD0;
u8 _AD4[0x4];
f32 _AD8;
AState<Navi>* mCurrState;
};
struct NaviDrawer : public Node {
NaviDrawer(Navi* navi)
: Node("")
{
mNavi = navi;
}
virtual void draw(Graphics& gfx) { mNavi->draw(gfx); }
Navi* mNavi;
};
extern bool DelayPikiBirth;
struct NaviProp : public CreatureProp {
struct Parms : public Parameters {
inline Parms()
: Parameters("Navi::Parms")
, mActionRadius(this, 120.0f, 0.0f, 500.0f, "p00", "\203A\203N\203V\203\207\203\223\224\274\214a")
, mContinuousPluckDistance(this, 200.0f, 0.0f, 1000.0f, "p60", "\230A\221\261\224\262\202\253\213\227\227\243")
, mPluckDistanceOutsideOnyon(this, 15.0f, 0.0f, 500.0f, "p62", "\224\262\202\253\213\227\227\243(onyon\212O)")
, mWhistleMaxRadius(this, 100.0f, 0.0f, 500.0f, "p01", "\203s\203L\214\304\202\321\215\305\221\345\224\274\214a")
, mWhistleMinRadius(this, 5.0f, 0.0f, 500.0f, "p53", "\203s\203L\214\304\202\321\215\305\217\254\224\274\214a")
, mWhistleExpandTime(this, 0.2f, 0.0f, 500.0f, "p02", "\203s\203L\214\304\202\321\215\305\221\345\216\236\212\324")
, mWhistleHoldTime(this, 0.15f, 0.0f, 500.0f, "p03", "\203T\201[\203N\203\213\217\301\202\246\216\236\212\324")
, mMoveSpeed(this, 170.0f, 0.0f, 500.0f, "p04", "\210\332\223\256\221\254\223x")
, mRunSpeed(this, 210.0f, 0.0f, 500.0f, "p56", "\221\226\202\351\221\254\202\263\201i\215D\222\262\216\236\201j")
, mDisplayScale(this, 1.0f, 0.0f, 10.0f, "p38", "\225\\\216\246\203X\203P\201[\203\213")
, _FC(this, 0.001f, 0.0f, 1.0f, "p05", "Stick 0")
, _10C(this, 0.1f, 0.0f, 1.0f, "p20", "Stick 01")
, _11C(this, 0.8f, 0.0f, 1.0f, "p06", "Stick 1")
, _12C(this, 1.0f, 0.0f, 1.0f, "p07", "Stick 2")
, _13C(this, 120.0f, 90.0f, 180.0f, "p08", "\202\267\202\327\202\350\212p\223x")
, mThrowHoldMaxTime(this, 2.5f, 0.0f, 10.0f, "p09", "\223\212\202\260\202\275\202\337\214\300\212E\216\236\212\324")
, mThrowMaxDistance(this, 600.0f, 0.0f, 1000.0f, "p10", "\223\212\202\260\213\227\227\243(Max)")
, mThrowMinDistance(this, 150.0f, 0.0f, 500.0f, "p11", "\223\212\202\260\213\227\227\243(Min)")
, mThrowMaxHeight(this, 100.0f, 0.0f, 1000.0f, "p24", "\223\212\202\260\215\202\202\263(Max)")
, mThrowMinHeight(this, 80.0f, 0.0f, 1000.0f, "p25", "\223\212\202\260\215\202\202\263(min)")
, mYellowThrowHeight(this, 200.0f, 0.0f, 1000.0f, "p54", "\223\212\202\260\215\202\202\263(\211\251\220F)")
, mThrowFlightTime(this, 1.0f, 0.0f, 100.0f, "p26", "\222\205\222n\216\236\212\324")
, mPluckGrabRange(this, 80.0f, 0.0f, 200.0f, "p37", "\203s\203L\202\360\202\302\202\251\202\336\227L\214\370\224\315\210\315")
, mPluckLoopCount(this, 1, 0, 10, "p42", "\224\262\202\255\203\213\201[\203v\211\361\220\224")
, mPikiWaitRange(this, 30.0f, 0.0f, 200.0f, "p39", "\203s\203L\202\252\221\322\202\302\224\315\210\315")
, mPikiFormationChangeRange(this, 60.0f, 0.0f, 200.0f, "p40", "\203s\203L\202\252\203t\203H\201[\203\201\201[\203V\203\207\203\223\202\360\225\317\202\246\202\351\224\315\210\315")
, mBodyCollisionRadius(this, 15.0f, 0.0f, 100.0f, "p21", "\223\226\202\275\202\350\203T\203C\203Y")
, mGroundCollisionRadius(this, 16.0f, 0.0f, 100.0f, "p41", "\222n\226\312\223\226\202\275\202\350\203T\203C\203Y")
, mInverseMass(this, 4.0f, 0.0f, 2000.0f, "p22", "\217d\202\263\202\314\213t\220\224")
, _22C(this, 0.04f, 0.0f, 1.0f, "p23", "\203G\203C\203~\203\223\203O\211\361\223]\203X\203s\201[\203h")
, mAsibumiStartSpeed(this, 5.0f, 0.0f, 500.0f, "p14", "ASIBUMI \212J\216n\203X\203s\201[\203h")
, mWalkStartSpeed(this, 35.0f, 0.0f, 500.0f, "p15", "WALK \212J\216n\203X\203s\201[\203h")
, mRunStartSpeed(this, 70.0f, 0.0f, 500.0f, "p16", "RUN \212J\216n\203X\203s\201[\203h")
, mEscapeStartSpeed(this, 160.0f, 0.0f, 500.0f, "p17", "ESCAPE \212J\216n\203X\203s\201[\203h")
, mWalkAnimMinFrames(this, 30.0f, 0.0f, 300.0f, "p18", "WALK \215\304\220\266\203t\203\214\201[\203\200\220\224(min)")
, mWalkAnimMaxFrames(this, 60.0f, 0.0f, 300.0f, "p19", "WALK \215\304\220\266\203t\203\214\201[\203\200\220\224(max)")
, mRunAnimMinFrames(this, 30.0f, 0.0f, 300.0f, "p27", "RUN \215\304\220\266\203t\203\214\201[\203\200\220\224(min)")
, mRunAnimMaxFrames(this, 60.0f, 0.0f, 300.0f, "p28", "RUN \215\304\220\266\203t\203\214\201[\203\200\220\224(max)")
, mEscapeAnimMinFrames(this, 30.0f, 0.0f, 300.0f, "p29", "ESCAPE \215\304\220\266\203t\203\214\201[\203\200\220\224(min)")
, _2CC(this, 60.0f, 0.0f, 300.0f, "p30", "ESCAPE \215\304\220\266\203t\203\214\201[\203\200\220\224(max)")
, mPressedTotalTime(this, 3.0f, 0.0f, 10.0f, "p31", "\202\302\202\324\202\352\221\215\216\236\212\324")
, mPressedFlatTime(this, 1.0f, 0.0f, 10.0f, "p32", "\202\330\202\301\202\275\202\361\202\261\216\236\212\324")
, _2FC(this, 0.5f, 0.0f, 10.0f, "p33", "\211\237\202\265\212J\216n\216\236\212\324")
, _30C(this, 0.3f, 0.0f, 1.0f, "p34", "\211\237\202\265\212J\216n\203X\203e\203B\203b\203N\227\312")
, mShakePreventionAngle(this, 10.0f, 0.0f, 180.0f, "p35", "\216\350\202\324\202\352\226h\216~\212p\223x")
, _32C(this, 0.1f, 0.0f, 1.0f, "p36", "\216\350\202\324\202\352\226h\216~\221\345\202\253\202\263")
, mCursorMoveDelayTime(this, 2.0f, 0.0f, 60.0f, "p48", "\203J\201[\203\\\203\213\210\332\223\256\203X\203s\201[\203h")
, mPikiImpatienceTime(this, 8.0f, 0.0f, 60.0f, "p49", "\203s\203L\202\252\202\265\202\321\202\352\202\360\220\330\202\347\202\267\216\236\212\324")
, mNeutralStickThreshold(this, 0.1f, 0.0f, 1.0f, "p43", "\203j\203\205\201[\203g\203\211\203\213\203X\203e\203B\203b\203N")
, mCursorMoveStickThreshold(this, 0.75f, 0.0f, 1.0f, "p44", "\203J\201[\203\\\203\213\210\332\223\256\203X\203e\203B\203b\203N")
, mClampStickToMaxThreshold(this, 0.85f, 0.0f, 1.0f, "p48", "\203N\203\211\203\223\203v\203X\203e\203B\203b\203N")
, mCursorMinRadius(this, 50.0f, 0.0f, 1000.0f, "p45", "\203J\201[\203\\\203\213\210\332\223\256\215\305\217\254\224\274\214a")
, mCursorMaxRadius(this, 300.0f, 0.0f, 2000.0f, "p46", "\203J\201[\203\\\203\213\210\332\223\256\215\305\221\345\224\274\214a")
, mCursorMoveSpeed(this, 200.0f, 0.0f, 1000.0f, "p47", "\203J\201[\203\\\203\213\210\332\223\256\203X\203s\201[\203h")
, mHealth(this, 100.0f, 0.0f, 1000.0f, "p50", "\203\211\203C\203t")
, mPunchDamage(this, 1.0f, 0.0f, 1000.0f, "p51", "\215U\214\202\227\315")
, mPunchRadius(this, 10.0f, 0.0f, 100.0f, "p52", "\215U\214\202\224\315\210\315")
, mPluckCursorCount(this, 1, 0, 10, "p55", "\203J\201[\203\\\203\213\203J\203E\203\223\203g")
, mMinKinokoFlickActions(this, 4, 0, 16, "p57", "kinoko Flick Count")
, mBuryEscapeKeyCount(this, 3, 0, 16, "p58", "bury Key Count")
, mBuryEscapeSuccessCount(this, 3, 0, 16, "p59", "bury Exit Count")
, mPostPluckZoomOutTime(this, 100, 0, 1000, "p61", "\212\361\202\350\203J\203\201\203\211\203Y\201[\203\200\203A\203E\203g(frame)")
{
}
Parm<f32> mActionRadius;
Parm<f32> mContinuousPluckDistance;
Parm<f32> mPluckDistanceOutsideOnyon;
Parm<f32> mWhistleMaxRadius;
Parm<f32> mWhistleMinRadius;
Parm<f32> mWhistleExpandTime;
Parm<f32> mWhistleHoldTime;
Parm<f32> mMoveSpeed;
Parm<f32> mRunSpeed;
Parm<f32> mDisplayScale;
Parm<f32> _FC;
Parm<f32> _10C;
Parm<f32> _11C;
Parm<f32> _12C;
Parm<f32> _13C;
Parm<f32> mThrowHoldMaxTime;
Parm<f32> mThrowMaxDistance;
Parm<f32> mThrowMinDistance;
Parm<f32> mThrowMaxHeight;
Parm<f32> mThrowMinHeight;
Parm<f32> mYellowThrowHeight;
Parm<f32> mThrowFlightTime;
Parm<f32> mPluckGrabRange;
Parm<int> mPluckLoopCount;
Parm<f32> mPikiWaitRange;
Parm<f32> mPikiFormationChangeRange;
Parm<f32> mBodyCollisionRadius;
Parm<f32> mGroundCollisionRadius;
Parm<f32> mInverseMass;
Parm<f32> _22C;
Parm<f32> mAsibumiStartSpeed;
Parm<f32> mWalkStartSpeed;
Parm<f32> mRunStartSpeed;
Parm<f32> mEscapeStartSpeed;
Parm<f32> mWalkAnimMinFrames;
Parm<f32> mWalkAnimMaxFrames;
Parm<f32> mRunAnimMinFrames;
Parm<f32> mRunAnimMaxFrames;
Parm<f32> mEscapeAnimMinFrames;
Parm<f32> _2CC;
Parm<f32> mPressedTotalTime;
Parm<f32> mPressedFlatTime;
Parm<f32> _2FC;
Parm<f32> _30C;
Parm<f32> mShakePreventionAngle;
Parm<f32> _32C;
Parm<f32> mCursorMoveDelayTime;
Parm<f32> mPikiImpatienceTime;
Parm<f32> mNeutralStickThreshold;
Parm<f32> mCursorMoveStickThreshold;
Parm<f32> mClampStickToMaxThreshold;
Parm<f32> mCursorMinRadius;
Parm<f32> mCursorMaxRadius;
Parm<f32> mCursorMoveSpeed;
Parm<f32> mHealth;
Parm<f32> mPunchDamage;
Parm<f32> mPunchRadius;
Parm<int> mPluckCursorCount;
Parm<int> mMinKinokoFlickActions;
Parm<int> mBuryEscapeKeyCount;
Parm<int> mBuryEscapeSuccessCount;
Parm<int> mPostPluckZoomOutTime;
};
NaviProp();
virtual void read(RandomAccessStream& input)
{
mCreatureProps.read(input);
mNaviProps.read(input);
}
Parms mNaviProps;
};
class NaviMgr : public MonoObjectMgr {
public:
NaviMgr();
virtual ~NaviMgr() { }
virtual void update();
virtual Creature* createObject();
virtual void read(RandomAccessStream&);
Navi* getNavi();
Navi* getNavi(int);
void refresh2d(Graphics&);
void renderCircle(Graphics&);
void drawShadow(Graphics&);
void init();
u8 _3C[0x4];
Shape* mNaviShape;
u8 _44[0x4];
PikiShapeObject* mNaviShapeObject[2];
PaniMotionTable* mMotionTable;
int mNaviID;
NaviProp* mNaviParms;
};
extern NaviMgr* naviMgr;
class DynParticle;
struct DynCreature : public Creature {
public:
DynCreature();
virtual void update();
virtual void refresh(Graphics&);
virtual void doKill();
void enablePickOffset(f32);
void disablePickOffset();
void addParticle(f32, Vector3f&);
void releaseAllParticles();
void initialiseSystem();
void simulate(f32);
void applyTorque(int, f32);
void createInvInertiaTensor();
void calcModelMatrix(Matrix4f&);
void simulate2(f32);
f32 getPickOffset() { return mPickOffset; }
u8 getGroundFlag() { return mGroundFlag; }
void enableFriction() { setDynFlag(1); }
void disableFriction() { resetDynFlag(1); }
protected:
void setDynFlag(int flag) { mDynFlag |= flag; }
void resetDynFlag(int flag) { mDynFlag &= ~flag; }
bool isDynFlag(int flag) { return mDynFlag & flag; }
public:
Vector3f mAngularMomentum;
Vector3f mAngularVelocity;
f32 mPickOffset;
u16 mParticleCount;
DynParticle* mParticleList;
Vector3f mAngularImpulseAccum;
Vector3f mCenterOfMass;
f32 mMass;
Matrix4f mWorldInertiaTensor;
Matrix4f mWorldInvInertiaTensor;
Matrix4f mInertiaTensor;
Matrix4f mInvInertiaTensor;
Matrix4f _3F8;
u8 mDynFlag;
u8 mGroundFlag;
};
class ItemShapeObject;
class MapMgr;
struct DualCreature : public DynCreature {
public:
DualCreature();
virtual void update();
virtual void refresh(Graphics&);
virtual void doKill();
virtual bool onGround();
virtual void doRender(Graphics&, Matrix4f&) = 0;
virtual void doCreateColls(Graphics&) = 0;
bool isFrontFace();
f32 getY();
void useRealDynamics();
void useSimpleDynamics();
void rotateY(f32);
void createCollisions(Graphics&);
void setDynamicsSimpleFixed(bool isSimpleFixed) { mIsDynamicsSimpleFixed = isSimpleFixed; }
bool isRealDynamics() { return mIsRealDynamics; }
void invalidateCollisions() { mIsCollisionInitialised = false; }
protected:
bool mIsRealDynamics;
bool mIsCollisionInitialised;
bool _43E;
bool mIsDynamicsSimpleFixed;
};
struct PelCreature : public DualCreature {
public:
PelCreature(int, ItemShapeObject*, CreatureProp*, MapMgr*);
virtual void init( Vector3f&);
virtual void startAI(int);
virtual f32 getiMass();
virtual bool isAlive();
virtual void doRender(Graphics&, Matrix4f&);
virtual void doCreateColls(Graphics&);
protected:
PaniItemAnimator mItemAnimator;
ItemShapeObject* mItemShape;
CollInfo mItemCollInfo;
CollPart mItemParts[10];
u32 mPartIDs[10];
};
class PaniAnimKeyEvent;
class PaniMotionTable;
class PelletShapeObject;
struct PelletStateMachine;
class PelletView;
class Shape;
struct RippleEffect;
struct Suckable;
struct NumberPel {
int mPelletColor;
int mPelletType;
u32 mPelletID;
};
extern NumberPel numberPellets[13];
enum PelletType {
PELTYPE_Corpse = 0,
PELTYPE_Blue = 0,
PELTYPE_Red = 1,
PELTYPE_Yellow = 2,
PELTYPE_UfoPart = 3,
};
enum NumPelletType {
NUMPEL_NULL = -1,
NUMPEL_OnePellet = 0,
NUMPEL_FivePellet = 1,
NUMPEL_TenPellet = 2,
NUMPEL_TwentyPellet = 3,
};
enum PelletColor {
PELCOLOR_Part = -2,
PELCOLOR_NULL = -1,
PELCOLOR_Blue = 0,
PELCOLOR_Red = 1,
PELCOLOR_Yellow = 2,
PELCOLOR_MIN = PELCOLOR_Blue,
PELCOLOUR_MAX = PELCOLOR_Yellow,
PELCOLOUR_COUNT,
};
enum PelletAnimSoundID {
PELSOUND_NONE = -1,
PELSOUND_Other = 0,
PELSOUND_Engine = 1,
PELSOUND_Gear = 2,
PELSOUND_Rader = 3,
PELSOUND_Spring = 4,
PELSOUND_Battery = 5,
PELSOUND_Zenmai = 6,
PELSOUND_MoneyBox = 7,
};
enum PelletBounceSoundID {
PELBOUNCE_NONE = -1,
PELBOUNCE_NormalPellet = 0,
PELBOUNCE_NormalUfoPart = 1,
PELBOUNCE_SpringUfoPart = 2,
PELBOUNCE_MoneyBoxUfoPart = 3,
};
enum UfoPartIndex {
UFO_NOPART = -1,
UFO_Bowsprit = 0,
UFO_GluonDrive = 1,
UFO_AntiDioxinFilter = 2,
UFO_EternalFuelDynamo = 3,
UFO_MainEngine = 4,
UFO_WhimsicalRadar = 5,
UFO_InterstellarRadio = 6,
UFO_GuardSatellite = 7,
UFO_ChronosReactor = 8,
UFO_RadiationCanopy = 9,
UFO_GeigerCounter = 10,
UFO_Sagittarius = 11,
UFO_Libra = 12,
UFO_OmegaStabilizer = 13,
UFO_IoniumJet1 = 14,
UFO_IoniumJet2 = 15,
UFO_ShockAbsorber = 16,
UFO_GravityJumper = 17,
UFO_PilotSeat = 18,
UFO_NovaBlaster = 19,
UFO_AutomaticGear = 20,
UFO_ZirconiumRotor = 21,
UFO_ExtraordinaryBolt = 22,
UFO_RepairTypeBolt = 23,
UFO_SpaceFloat = 24,
UFO_MassageMachine = 25,
UFO_SecretSafe = 26,
UFO_PositronGenerator = 27,
UFO_AnalogComputer = 28,
UFO_UVLamp = 29,
UFO_COUNT,
UFO_UNDEF = UFO_COUNT,
};
enum UfoPartID {
UFOID_Bowsprit = 'ust1',
UFOID_GluonDrive = 'ust2',
UFOID_AntiDioxinFilter = 'ust3',
UFOID_EternalFuelDynamo = 'ust4',
UFOID_MainEngine = 'ust5',
UFOID_WhimsicalRadar = 'uf01',
UFOID_InterstellarRadio = 'uf02',
UFOID_GuardSatellite = 'uf03',
UFOID_ChronosReactor = 'uf04',
UFOID_RadiationCanopy = 'uf05',
UFOID_GeigerCounter = 'uf06',
UFOID_Sagittarius = 'uf07',
UFOID_Libra = 'uf08',
UFOID_OmegaStabilizer = 'uf09',
UFOID_IoniumJet1 = 'uf10',
UFOID_IoniumJet2 = 'uf11',
UFOID_ShockAbsorber = 'un01',
UFOID_GravityJumper = 'un02',
UFOID_PilotSeat = 'un03',
UFOID_NovaBlaster = 'un04',
UFOID_AutomaticGear = 'un05',
UFOID_ZirconiumRotor = 'un06',
UFOID_ExtraordinaryBolt = 'un07',
UFOID_RepairTypeBolt = 'un08',
UFOID_SpaceFloat = 'un09',
UFOID_MassageMachine = 'un10',
UFOID_SecretSafe = 'un11',
UFOID_PositronGenerator = 'un12',
UFOID_AnalogComputer = 'un13',
UFOID_UVLamp = 'un14',
UFOID_UNDEF = 'udef',
};
enum PelletMgrMovieFlags {
PELMOVIE_Unk1 = 1 << 0,
PELMOVIE_Unk2 = 1 << 1,
PELMOVIE_Unk3 = 1 << 2,
PELMOVIE_Unk4 = 1 << 3,
};
struct PelletMotionFlags { typedef
enum {
Unknown = 1 << 0,
UsePiston = 1 << 1,
} Type; } ;
struct PelletProp : public CreatureProp {
PelletProp() { mCreatureProps.mFriction(0.1f); }
};
class PelletShapeObject {
public:
PelletShapeObject( char*, Shape*, char*, char*, int);
bool isMotionFlag(u8 flag) { return mMotionFlag & flag; }
void setMotionFlag(u8 flag) { mMotionFlag |= flag; }
void genAge(AgeServer&);
Shape* mShape;
AnimMgr* mAnimMgr;
AnimContext mAnimatorA;
AnimContext mAnimatorB;
u8 mMotionFlag;
};
class PelletConfig : public Parameters, public CoreNode {
public:
PelletConfig();
Parm<String> mPelletName;
ID32 mModelId;
ID32 mUnusedId;
ID32 mPelletId;
Parm<int> mPelletType;
Parm<int> mPelletColor;
Parm<int> mCarryMinPikis;
Parm<int> mCarryMaxPikis;
Parm<int> mUseDynamicMotion;
Parm<f32> _A0;
Parm<f32> _B0;
Parm<int> _C0;
Parm<int> mMatchingOnyonSeeds;
Parm<int> mNonMatchingOnyonSeeds;
Parm<f32> mPelletScale;
Parm<f32> mCarryInfoHeight;
Parm<int> mAnimSoundID;
Parm<int> mBounceSoundID;
int mRepairAnimJointIndex;
virtual void read(RandomAccessStream&);
void removeSelf(AgeServer&);
};
class Pellet : public DualCreature, public PaniAnimKeyListener {
friend class PelletMgr;
public:
Pellet();
virtual void init( Vector3f&);
virtual void startAI(int);
virtual f32 getiMass();
virtual f32 getSize();
virtual f32 getCylinderHeight();
virtual void doSave(RandomAccessStream&);
virtual void doLoad(RandomAccessStream&);
virtual Vector3f getCentre();
virtual bool isVisible();
virtual bool isAtari();
virtual bool isAlive();
virtual bool ignoreAtari(Creature*);
virtual bool isFree();
virtual bool stimulate( Interaction&);
virtual void collisionCallback( CollEvent&);
virtual void bounceCallback();
virtual void startWaterEffect();
virtual void finishWaterEffect();
virtual void update();
virtual void postUpdate(int unused, f32 deltaTime);
virtual void refresh(Graphics&);
virtual void animationKeyUpdated( PaniAnimKeyEvent&);
int getState();
void setTrySound(bool);
void startPick();
void finishPick();
void startGoal();
void doCarry(Creature*, Vector3f&, u16);
f32 getBottomRadius();
bool startStickTeki(Creature*, f32);
void endStickTeki(Creature*);
bool winnable(int);
bool stickSlot(int);
void stickOffSlot(int);
int getMinFreeSlotIndex();
int getNearestFreeSlotIndex( Vector3f&);
int getRandomFreeSlotIndex();
Vector3f getSlotLocalPos(int, f32);
Vector3f getSlotGlobalPos(int, f32);
void startCarryMotion(f32);
void finishMotion();
void stopMotion();
void startAppear();
static bool isUfoPartsID(u32);
AState<Pellet>* getCurrState() { return mCurrentState; }
void setCurrState(AState<Pellet>* state) { mCurrentState = state; }
void setMotionFlag(u8 flag) { mMotionFlag |= flag; }
bool isMotionFlag(u8 flag) { return mMotionFlag & flag; }
BOOL isUfoParts()
{
if (mConfig) {
return (mConfig->mPelletType() == PELTYPE_UfoPart);
}
return false;
}
bool isSlotFree(int slot) { return !isSlotFlag(slot); }
int getNearestFreeSlotIndex();
protected:
virtual void doAnimation();
virtual void doKill();
virtual void doRender(Graphics&, Matrix4f&);
virtual void doCreateColls(Graphics&);
void initSlotFlags();
void setSlotFlag(int);
void resetSlotFlag(int);
bool isSlotFlag(int);
void initPellet(PelletShapeObject*, PelletConfig*);
void initPellet(PelletView*, PelletConfig*);
public:
Vector3f mSpawnPosition;
bool mUseSpawnPosition;
bool mIsPlayTrySound;
u8 mMotionFlag;
RippleEffect* mRippleEffect;
Suckable* mTargetGoal;
CollPart* mStuckMouthPart;
f32 mStuckAngle;
Vector3f mLastPosition;
PelletStateMachine* mStateMachine;
AState<Pellet>* mCurrentState;
Creature* mPikiCarrier;
Vector3f mCarryDirection;
u16 mCarrierCount;
f32 mTransitionTimer;
u16 mCarryState;
Vector3f mCurrentPelletPosition;
u16 _4A0;
f32 mCurrentPelletHeight;
PelletView* mPelletView;
PelletAnimator mAnimator;
PelletShapeObject* mShapeObject;
u8 _558[0x4];
PelletConfig* mConfig;
f32 mMotionSpeed;
int mSlotFlags[3];
u16 mCarrierCounter;
CollInfo* mPelletCollInfo;
SearchData mSearchData[4];
ShapeDynMaterials mAnimatedMaterials;
bool mIsAlive;
bool mIsAIActive;
};
class PelletMgr : public MonoObjectMgr {
friend class Pellet;
friend void PlayerState::registerUfoParts(int, u32, u32);
friend void PlayerState::UfoParts::initAnim(PelletShapeObject*);
public:
struct UseNode : public CoreNode {
UseNode() { initCore("useNode"); }
u32 mPelletID;
};
PelletMgr(MapMgr*);
virtual ~PelletMgr() { }
virtual void refresh(Graphics&);
virtual void read(RandomAccessStream&);
bool decomposeNumberPellet(u32, int&, int&);
void registerUfoParts();
Pellet* newNumberPellet(int, int);
Pellet* newPellet(u32, PelletView*);
void addUseList(u32);
void initShapeInfos();
int getConfigIndex(u32);
PelletConfig* getConfigFromIdx(int);
PelletConfig* getConfig(u32);
void readConfigs(RandomAccessStream&);
void readAnimInfos(RandomAccessStream&);
void initTekiNakaParts();
void createShapeObjects();
void refresh2d(Graphics&);
bool useShape(u32);
ID32 getConfigIdAt(int);
bool isMovieFlag(u16 flag) { return mMovieFlags & flag; }
void setMovieFlags(u16 flag) { mMovieFlags = flag; }
static int getUfoIndexFromID(u32 ufoID);
static u32 getUfoIDFromIndex(int);
int getNumConfigs() { return mConfigNum; }
void writeAnimInfos(RandomAccessStream&);
void writeConfigs(RandomAccessStream&);
void addAnimInfo(AgeServer&);
void addConfig(AgeServer&);
void animInfoRead(AgeServer&);
void animInfoWrite(AgeServer&);
void configRead(AgeServer&);
void configWrite(AgeServer&);
void removeAnimInfo(AgeServer&, PelletAnimInfo*);
void removeConfig(AgeServer&, PelletConfig*);
protected:
virtual Creature* createObject();
PelletShapeObject* getShapeObject(u32);
UseNode mUseList;
int mConfigNum;
PelletConfig mConfigList;
int mAnimInfoNum;
PelletAnimInfo mAnimInfoList;
PelletProp* mPelletProps;
PaniMotionTable* mUfoMotionTable;
int mReadStage;
u16 mMovieFlags;
};
extern PelletMgr* pelletMgr;
extern bool SmartTurnOver;
enum PikiSoundID {
SOUND_NULL = -1,
SE_BATTLE_START = 0x0,
SE_CHAPPY_WALK = 0x1,
SE_CHAPPY_DIE = 0x2,
SE_CHAPPY_SWING = 0x3,
SE_CHAPPY_SLEEP = 0x4,
SE_CHAPPY_BITE = 0x5,
SE_CHAPPY_EAT = 0x6,
SE_CHAPPY_DOWN = 0x7,
SE_CHAPPY_FOOTDAMAGE = 0x8,
SE_CHAPPY_BITE2 = 0x9,
SE_FLOG_WALK = 0xA,
SE_FLOG_DIE = 0xB,
SE_FLOG_FALL = 0xC,
SE_FLOG_HIJUMP = 0xD,
SE_FLOG_JUMP = 0xE,
SE_FLOG_DOWN = 0xF,
SE_FLOG_LAND = 0x10,
SE_FLOG_VOICE = 0x11,
SE_FLOG_ATTACK = 0x12,
SE_FLOG_EAT = 0x13,
SE_FLOG_WATERJUMP = 0x14,
SE_FLOG_WATERLAND = 0x15,
SE_PIKI_EATEN = 0x16,
SE_PIKI_ATTACK_VOICE = 0x17,
SE_MISSHIT = 0x18,
SE_PIKI_ATTACK_HIT = 0x19,
SE_PIKI_DAMAGED = 0x1A,
SE_PIKI_PRESSED = 0x1B,
SE_WALL_HIT = 0x1C,
SE_SOFTWALL_HIT = 0x1D,
SE_WALL_DOWN = 0x1E,
SE_BOMB = 0x1F,
SE_MINIC_WALK = 0x20,
SE_MINIC_FOOTDAMAGE = 0x21,
SE_MINIC_DIE = 0x22,
SE_MINIC_SWING = 0x23,
SE_MINIC_BITE = 0x24,
SE_MINIC_EAT = 0x25,
SE_MINIC_DOWN = 0x26,
SE_MINIC_ALERT = 0x27,
SE_SNAKE_APPEAR = 0x28,
SE_SPIDER_WALK = 0x29,
SE_SPIDER_LAND = 0x2A,
SE_SPIDER_SWING = 0x2B,
SE_SPIDER_DEAD = 0x2C,
SE_SPIDER_BOMB = 0x2D,
SE_FLOWER_DOWN = 0x2E,
SE_FLOWER_CONVULSION = 0x2F,
SE_FLOWER_GROW0 = 0x30,
SE_FLOWER_GROW1 = 0x31,
SE_FLOWER_GROW2 = 0x32,
SE_PIKI_DEAD = 0x33,
SE_SNAKE_DIG = 0x34,
SE_SNAKE_SHOUT = 0x35,
SE_SNAKE_EAT = 0x36,
SE_SNAKE_DRINK = 0x37,
SE_SNAKE_TURN = 0x38,
SE_SNAKE_MOGAKU = 0x39,
SE_SNAKE_DEAD1 = 0x3A,
SE_SNAKE_DEAD2 = 0x3B,
SE_TANK_FIRE = 0x3C,
SE_TANK_BREATH = 0x3D,
SE_TANK_WALK = 0x3E,
SE_TANK_SWING = 0x3F,
SE_TANK_DAMAGE = 0x40,
SE_TANK_DEAD1 = 0x41,
SE_TANK_DEAD2 = 0x42,
SE_MUSH_WALK = 0x43,
SE_MUSH_FLIP = 0x44,
SE_MUSH_TUMBLE = 0x45,
SE_MUSH_GETUP = 0x46,
SE_MUSH_LAND = 0x47,
SE_MUSH_TAME = 0x48,
SE_MUSH_SPORE = 0x49,
SE_MUSH_DAMAGE = 0x4A,
SE_MUSH_DEAD1 = 0x4B,
SE_MUSH_DEAD2 = 0x4C,
SE_KING_WALK = 0x4D,
SE_KING_READY = 0x4E,
SE_KING_BERO1 = 0x4F,
SE_KING_BERO2 = 0x50,
SE_KING_GEPPU = 0x51,
SE_KING_DRINK = 0x52,
SE_KING_EAT = 0x53,
SE_KING_CHEEK = 0x54,
SE_KING_NAME = 0x55,
SE_KING_HIP = 0x56,
SE_KING_DEAD1 = 0x57,
SE_KING_DEAD2 = 0x58,
SE_KING_APPEAR = 0x59,
SE_KING_SINK = 0x5A,
SE_KABUTO_BREATH = 0x5B,
SE_KABUTO_TUMARI = 0x5C,
SE_KABUTO_OPEN = 0x5D,
SE_KABUTO_SHOT = 0x5E,
SE_KABUTO_FLIP = 0x5F,
SE_KABUTO_WALK = 0x60,
SE_KABUTO_COOLDOWN = 0x61,
SE_KABUTO_OVERHEAT = 0x62,
SE_KABUTO_DEAD = 0x63,
SE_ROCK_ROLL = 0x64,
SE_ROCK_BREAK = 0x65,
SE_ROCK_GENERATOR = 0x66,
SE_SHELL_CLOSE = 0x67,
SE_SHELL_READY = 0x68,
SE_SHELL_TRESURE = 0x69,
SE_SHELL_OPEN = 0x6A,
SE_SHELL_EAT = 0x6B,
SE_KINOKOPIKI_MORPH = 0x6C,
SE_KINOKOPIKI_DANCE = 0x6D,
SE_COLLEC_BREATH = 0x6E,
SE_COLLEC_PULL = 0x6F,
SE_COLLEC_WALK = 0x70,
SE_COLLEC_SWING = 0x71,
SE_COLLEC_DEAD = 0x72,
SE_COLLEC_DOWN = 0x73,
SE_COLLEC_CRY = 0x74,
SE_COLLEC_DAMAGE = 0x75,
SE_KOGANE_WALK = 0x76,
SE_KOGANE_DAMAGE = 0x77,
SE_SARAI_HOVER = 0x78,
SE_SARAI_DAMAGE = 0x79,
SE_SARAI_ATTACK = 0x7A,
SE_SARAI_DEAD = 0x7B,
SE_WALLEAT_WALK = 0x7C,
SE_WALLEAT_NIP = 0x7D,
SE_WALLEAT_EAT = 0x7E,
SE_WALLEAT_APPEAR = 0x7F,
SE_MAR_FLY = 0x80,
SE_MAR_BREATH = 0x81,
SE_MAR_WIND = 0x82,
SE_MAR_DROP = 0x83,
SE_MAR_DEAD1 = 0x84,
SE_MAR_DEAD2 = 0x85,
SE_MIURIN_WALK = 0x86,
SE_MIURIN_PUNCH = 0x87,
SE_MIURIN_SING = 0x88,
SE_KURIONE_HIT = 0x89,
SE_KURIONE_ESCAPE = 0x8A,
SE_KURIONE_WATER = 0x8B,
SE_KURIONE_FLYING = 0x8C,
SE_SLIME_WALK = 0x8D,
SE_SLIME_HIT_SMALL = 0x8E,
SE_SLIME_HIT_MID = 0x8F,
SE_SLIME_HIT_LARGE = 0x90,
SE_SLIME_DEAD = 0x91,
SE_SLIME_EXT1 = 0x92,
SE_SLIME_EXT2 = 0x93,
SE_SLIME_EXT3 = 0x94,
SE_SLIME_DISAPPEAR = 0x95,
SE_DORORO_WALK = 0x96,
SE_DORORO_CRY = 0x97,
SE_DORORO_DEAD = 0x98,
SE_DORORO_SWING = 0x99,
SE_DORORO_EGG_CRASH = 0x9A,
SE_DORORO_CRASH = 0x9B,
SE_PONGASHI_THROWIN = 0x9C,
SE_PONGASHI_CLOSE = 0x9D,
SE_PONGASHI_EAT = 0x9E,
SE_PONGASHI_SHOT = 0x9F,
SE_PONGASHI_DEAD = 0xA0,
SE_PONGASHI_TOUCH = 0xA1,
SE_NAMAZU_WALK = 0xA2,
SE_NAMAZU_EAT = 0xA3,
SE_NAMAZU_DEAD = 0xA4,
SE_OTAMA_JUMP = 0xA5,
SE_OTAMA_DEAD = 0xA6,
SE_OTAMA_WATERJUMP = 0xA7,
SE_GEYSER_NORMAL = 0xA8,
SE_GEYSER_SPOUT = 0xA9,
SEB_SOFTWALL_HIT = 0xAA,
SEB_WALL_DOWN = 0xAB,
SEB_HARDESTWALL_HIT = 0xAC,
SEB_CONSTRUCTION = 0xAD,
SEB_BOXMOVE = 0xAE,
SEB_HARDWALL_HIT = 0xAF,
SEB_STONE_HIT = 0xB0,
SEB_STONE_BREAK = 0xB1,
SEB_GRASS_PULL = 0xB2,
SEB_BRIDGE_EXTEND = 0xB3,
SEW_PIKI_WATERDROP = 0xB4,
SEW_PIKI_DROWN = 0xB5,
SEW_PIKI_DEAD = 0xB6,
SEW_PIKI_SINK = 0xB7,
SE_LIFT_TRY = 0xB8,
SE_LIFT_MOVE = 0xB9,
SE_PIKI_LIFT = 0xBA,
SE_PELLET_BORN = 0xBB,
SE_PELLET_BOUND = 0xBC,
SE_UFOPARTS_BOUND = 0xBD,
SE_UFOPARTS_OTHER = 0xBE,
SE_UFOPARTS_ENGINE = 0xBF,
SE_UFOPARTS_GEAR = 0xC0,
SE_UFOPARTS_RADER = 0xC1,
SE_UFOPARTS_SPRING = 0xC2,
SE_UFOPARTS_BATTERY = 0xC3,
SE_UFOPARTS_ZENMAI = 0xC4,
SE_UFOPARTS_MONEYBOX = 0xC5,
SE_UFOPARTS_SOUNDTYPE = SE_UFOPARTS_OTHER,
dummy1 = 0xC6,
dummy2 = 0xC7,
dummy3 = 0xC8,
dummy4 = 0xC9,
dummy5 = 0xCA,
SE_CONTAINER_PELLETIN = 0xCB,
SE_CONTAINER_PIKIBORN = 0xCC,
SE_PIKI_GROW1 = 0xCD,
SE_PIKI_GROW2 = 0xCE,
SE_PIKI_GROW3 = 0xCF,
SE_PIKI_GROW4 = 0xD0,
SE_PIKI_GROW5 = 0xD1,
SE_PIKI_GOHOME = 0xD2,
SE_PIKI_OUTHOME = 0xD3,
SE_PIKI_GROW0 = 0xD4,
SE_PIKI_GROW0_WATER = 0xD5,
SE_CONTAINER_PELLETIN2 = 0xD6,
SE_CONTAINER_PIKI = 0xD7,
SE_CONTAINER_HANABI = 0xD8,
SE_CONTAINER_CLIMB = 0xD9,
SE_UFO_PARTSIN = 0xDA,
SE_UFO_PARTSSET1 = 0xDB,
SE_UFO_PARTSSET2 = 0xDC,
SE_UFO_PARTSSET3 = 0xDD,
SE_UFO_IDLING = 0xDE,
SE_UFO_SPARK = 0xDF,
SE_UFO_DESTROY = 0xE0,
SE_UFO_SATELLITE = 0xE1,
SE_UFO_LIGHT = 0xE2,
SE_UFO_ANTENNA = 0xE3,
SE_UFO_RADER = 0xE4,
SE_UFO_LIGHT2 = 0xE5,
SE_UFO_ENGINE = 0xE6,
SEF_PIKI_KINOKO2 = 0xE7,
SEF_PIKI_AKUBI = 0xE8,
SEF_PIKI_BURUBURU = 0xE9,
SEF_PIKI_CRASH = 0xEA,
SEF_PIKI_DEAD1 = 0xEB,
SEF_PIKI_DEAD2 = 0xEC,
SEF_PIKI_DEAD3 = 0xED,
SEF_PIKI_FALL = 0xEE,
SEF_PIKI_GAKKARI = 0xEF,
SEF_PIKI_HANG = 0xF0,
SEF_PIKI_JUMP1 = 0xF1,
SEF_PIKI_JUMP2 = 0xF2,
SEF_PIKI_JUMP3 = 0xF3,
SEF_PIKI_SNEEZE = 0xF4,
SEF_PIKI_SLEEP = 0xF5,
SEF_PIKI_NOBI = 0xF6,
SEF_PIKI_ANGRY1 = 0xF7,
SEF_PIKI_ANGRY2 = 0xF8,
SEF_PIKI_OTTOTTO = 0xF9,
SEF_PIKI_SKIP = 0xFA,
SEF_PIKI_SLIP1 = 0xFB,
SEF_PIKI_SLIP2 = 0xFC,
SEF_PIKI_LAND = 0xFD,
SEF_PIKI_YATTA = 0xFE,
SEF_PIKI_BREAKUP = 0xFF,
SEF_PIKI_CALLED = 0x100,
SEF_PIKI_FIND = 0x101,
SEF_PIKI_FIRED = 0x102,
SEF_PIKI_DRINK = 0x103,
SEF_PIKI_WATERED = 0x104,
SEF_PIKI_ATTACK_VOICE = 0x105,
SEF_PIKI_MISSHIT = 0x106,
SEF_PIKI_ATTACK_HIT = 0x107,
SEF_PIKI_DAMAGED = 0x108,
SEF_PIKI_GROW1 = 0x109,
SEF_PIKI_GROW2 = 0x10A,
SEF_PIKI_GROW3 = 0x10B,
SEF_PIKI_GROW4 = 0x10C,
SEF_PIKI_GROW5 = 0x10D,
SEF_PIKI_GROW0 = 0x10E,
SEF_PIKI_GROW0_WATER = 0x10F,
SYSSE_ALLSTOP = 0x110,
SYSSE_DECIDE1 = 0x111,
SYSSE_MOVE1 = 0x112,
SYSSE_PAUSE = 0x113,
SYSSE_EVENING_ALERT = 0x114,
SYSSE_COUNTDOWN = 0x115,
SYSSE_CMENU_ON = 0x116,
SYSSE_CMENU_OFF = 0x117,
SYSSE_CMENU_SELECT = 0x118,
SYSSE_CMENU_ERROR = 0x119,
SYSSE_ORIMA_LIFEDIM = 0x11A,
SYSSE_WORK_FINISH = 0x11B,
SYSSE_VIEW_CHANGE = 0x11C,
SYSSE_CANCEL = 0x11D,
SYSSE_TYPEWRITER = 0x11E,
SYSSE_UNPAUSE = 0x11F,
SYSSE_CONTAINER_OK = 0x120,
SYSSE_JUNGLE = 0x121,
SYSSE_PARTS_APPEAR = 0x122,
SYSSE_SELECT_MOVE = 0x123,
SYSSE_SELECT_DECIDE = 0x124,
SYSSE_TIME_SIGNAL = 0x125,
SYSSE_SELECT_COURSEOPEN = 0x126,
SYSSE_MESSAGE_CLOSE = 0x127,
SYSSE_CARDACCESS = 0x128,
SYSSE_CARDOK = 0x129,
SYSSE_CARDERROR = 0x12A,
SYSSE_TIME_SMALLSIGNAL = 0x12B,
SYSSE_CHG_HISCORE = 0x12C,
YMENU_ON = 0x12D,
YMENU_OFF = 0x12E,
YMENU_SELECT = 0x12F,
SYSSE_YMENU_ZOOMIN = 0x130,
SYSSE_YMENU_ZOOMOUT = 0x131,
SYSSE_YMENU_SCROLL = 0x132,
Sound_Config = 0x133,
YMENU_SELECT2 = 0x134,
SE_ORIMA_TOUCHPLANTS = 0x135,
SE_PIKI_PULLING = 0x136,
SE_PIKI_PULLED2 = 0x137,
SE_PLAYER_PUNCH = 0x138,
SE_THROW = 0x139,
SE_BREAKUP = 0x13A,
SE_GATHER = 0x13B,
SE_MOVEOBJ = 0x13C,
SE_DAMAGED = 0x13D,
SE_FIRED = 0x13E,
SE_PLAYER_DOWN = 0x13F,
SE_PLAYER_TOUCHHONEY = 0x140,
SE_THROWHIT = 0x141,
SE_PIKI_FLY = 0x142,
SE_BREAKUP_PIKI_VOICE = 0x143,
SE_PIKI_FLYREADY = 0x144,
SE_PIKI_CALLED = 0x145,
SE_PIKI_FIND = 0x146,
SE_PIKI_PULLED = 0x147,
SE_PIKI_WATERDROP = 0x148,
SE_PIKI_ATTACHENEMY = 0x149,
SE_KINOKOPIKI_ATTACK = 0x14A,
SE_COUNT,
};
class Graphics;
class RectArea;
class Texture;
class Vector2i;
enum GmWinState {
GMWIN_Opening = 0x1000,
GMWIN_Active = 0x1001,
GMWIN_Closing = 0x1002,
GMWIN_Inactive = 0x1003,
};
class GmWin : public CoreNode {
public:
struct CloseListener {
virtual void onCloseWindow() { }
};
GmWin();
virtual void open();
virtual void close();
virtual void update() { }
virtual void doRender(Graphics& gfx) { }
virtual void render(Graphics& gfx);
virtual void printStart(Graphics& gfx);
virtual void print(Graphics& gfx, int posX, int posY, char* message);
virtual void printcentre(Graphics& gfx, int posY, char* message);
virtual void printleft(Graphics& gfx, int posY, char* message);
virtual void printright(Graphics& gfx, int posY, char* message);
virtual void texture(Graphics& gfx, Texture* texture, int minX, int minY, int maxX, int maxY, RectArea area);
virtual void texturecentre(Graphics& gfx, Texture* texture, int minY, int width, int height, RectArea area);
virtual void textureleft(Graphics& gfx, Texture* texture, int minY, int width, int height, RectArea area);
virtual void textureright(Graphics& gfx, Texture* texture, int minY, int width, int height, RectArea area);
void placeCentre();
void setRect(int, int);
void moveHome(Vector2i&);
CloseListener* mCloseListener;
int mWidth;
int mHeight;
Vector2i mHome;
int mStatus;
ID32 mWindowId;
Colour mColourA;
Colour mAuxColourA;
Colour mColourB;
Colour mAuxColourB;
};
struct ContainerWin : public GmWin {
class Listener {
public:
virtual void informWin(int) = 0;
};
virtual void open();
virtual void close();
virtual void update();
virtual void doRender(Graphics&);
void setWin(int, int, Listener*);
Controller* mController;
Listener* mContainerListener;
int mAnimFramesRemaining;
int mUp;
f32 mScrollTime;
int mToContainer;
int _60;
int _64;
int _68;
bool mStickWasPushed;
};
struct ResultWin : public GmWin {
virtual void update();
virtual void doRender(Graphics&);
};
class GmWinMgr {
public:
GmWinMgr();
void addWindow(GmWin*);
void update();
void render(Graphics&);
GmWin* getWindow(u32);
GmWin mRoot;
};
extern GmWinMgr* gmWinMgr;
extern "C"{
typedef struct SVector_ {
f32 x;
f32 y;
f32 z;
} SVector_;
typedef enum JacEventType {
JACEVENT_System = -2,
JACEVENT_Player = -1,
JACEVENT_NULL = 0,
JACEVENT_Battle = 1,
JACEVENT_Pellet = 2,
JACEVENT_Onyon = 3,
JACEVENT_Build = 4,
JACEVENT_PikiWater = 5,
JACEVENT_Piki = 6,
JACEVENT_Ufo = 7,
JACEVENT_Dame = 8,
JACEVENT_COUNT,
} JacEventType;
void Jac_InitEventSystem(void);
void Jac_EventFrameCheck(void);
void Jac_UpdateCamera(struct SVector_* listenerPos, struct SVector_* listenerDir);
int Jac_CreateEvent(u32 eventType, struct SVector_* eventPos);
BOOL Jac_UpdateEventPosition(int idx, struct SVector_* eventPos);
BOOL Jac_PlayEventAction(int eventIdx, int actionId);
BOOL Jac_StopEventAction(int eventIdx, int actionId);
BOOL MML_StopEventAction(u8 idx, u8 statusSlot, u16 actionCmd);
void MML_StopEventAll(u8 idx, u16 activeMask);
BOOL Jac_DestroyEvent(s32 idx);
void Jac_InitAllEvent(void);
int Jac_CheckFreeEvents(void);
int Jac_GetActiveEvents(u32* outCount);
}
class Creature;
struct SeInfo {
int mJacPlayerSeID;
char* mSeName;
};
struct SeConstant : public Node {
struct Parms : public Parameters {
Parms()
: Parameters("SE::Parms")
, mSECutoffDist(this, 700.0f, 0.0f, 0.0f, "p00", "\203\214\203x\203\213\211\271\213\227\227\243")
, mBossBGMStartDist(this, 400.0f, 0.0f, 0.0f, "p01", "\203{\203X\202a\202f\202l\212J\216n\213\227\227\243")
, mBossBGMEndDist(this, 800.0f, 0.0f, 0.0f, "p02", "\203{\203X\202a\202f\202l\217I\227\271\213\227\227\243")
{
}
Parm<f32> mSECutoffDist;
Parm<f32> mBossBGMStartDist;
Parm<f32> mBossBGMEndDist;
};
SeConstant();
virtual void read(RandomAccessStream& input)
{
mParms.read(input);
}
Parms mParms;
};
class SeContext {
friend class SeSystem;
public:
SeContext();
SeContext(Creature* obj, int eventType);
void setContext(Creature* obj, int eventType);
void playSound(int soundID);
void stopSound(int soundID);
void update();
bool releaseEvent();
Vector3f getPos();
int getObjType();
void dump();
void setPosition( Vector3f& pos) { mSourcePosition = pos; }
protected:
void createEvent(int eventType);
u32 mClock;
Creature* mGameObj;
int mEventHandle;
u16 mEventType;
Vector3f mSourceListenerOffset;
Vector3f mSourcePosition;
};
class SeMgr : public Node {
public:
SeMgr();
virtual void update();
void playNaviSound(s32 stickX, s32 stickY);
void joinBattle();
void leaveBattle();
void setPikiNum(int pikiNum);
void playBGM(u32);
void stopBGM();
void stopSoundAll();
static void play(u32);
static void stop(u32 jacSeID);
int getSENum() { return mSENum; }
SeInfo* getIndexInfo(int idx) { return &mSeInfos[idx]; }
protected:
SeInfo* findInfo(int jacSeID);
void addInfo(int jacSeID, char* seName);
int mBattleCount;
int mSENum;
int mMaxInfos;
SeInfo* mSeInfos;
};
struct SeWin : public GmWin {
public:
virtual void open();
virtual void close();
virtual void update();
virtual void doRender(Graphics& gfx);
protected:
Controller* mController;
int mCurrSeIndex;
int mCurrJacSoundID;
int mAnimFramesRemaining;
int mUp;
f32 mScrollTime;
bool mStickWasPushed;
};
class SeSystem {
friend class SeContext;
public:
struct Event {
Event()
{
mHandle = -1;
mContext = 0 ;
}
int mHandle;
SeContext* mContext;
};
SeSystem();
void resetSystem();
void playPikiSound(int soundID, Vector3f& sourcePos);
void playSoundDirect(int eventType, int soundID, Vector3f& sourcePos);
void draw3d(Graphics& gfx);
void draw2d(Graphics& gfx);
void dumpEvents();
void update(Graphics& gfx, Vector3f& listenerPos);
void calcCameraPos( Vector3f& soundPos, Vector3f& normalisedOffsetDir);
int getJacID(int soundID);
void exitCourse();
char* getSoundName(int soundID);
int getEventType(int soundID);
bool isLoopType(int soundID);
static void playSysSe(int soundID);
static void stopSysSe(int soundID);
static void playPlayerSe(int soundID);
static void stopPlayerSe(int soundID);
protected:
void initEvent();
int createEvent(SeContext* context, int eventType, SVector_* soundOffset);
bool destroyEvent(SeContext* context, s32 handle);
int getEvent(s32 handle);
int getEvent(SeContext* context);
int mMaxSoundID;
Matrix4f mCameraMtx;
f32 mUnusedDistance;
Vector3f mListenerPosition;
int mCurrentContextCount;
int mMaxContextCount;
SeContext* mContexts;
SeConstant* mSoundParams;
u32 mClock;
int mCurrentEventCount;
int mMaxEventCount;
Event* mEvents;
bool mIsBossBGMActive;
bool mIsClosed;
};
extern SeSystem* seSystem;
extern SeMgr* seMgr;
struct Suckable : public ItemCreature {
inline Suckable(u16 id, CreatureProp* prop)
: ItemCreature(id, prop, 0 )
{
}
virtual Vector3f getGoalPos() = 0;
virtual f32 getGoalPosRadius() = 0;
virtual Vector3f getSuckPos() = 0;
virtual void suckMe(Pellet*) = 0;
virtual void finishSuck(Pellet*) { }
virtual int getRouteIndex() = 0;
};
class Piki;
class SimpleAI;
class UfoShapeObject {
public:
UfoShapeObject(Shape*);
Shape* mShape;
AnimMgr* mAnimMgr;
AnimContext* mAnimContexts;
};
struct UfoItemProp : public CreatureProp {
inline UfoItemProp()
{
mCreatureProps.mFriction.mValue = 0.1f;
mCreatureProps.mBounceFactor.mValue = 0.8f;
}
};
struct UfoAnimator {
public:
UfoAnimator();
void init(UfoShapeObject*, PaniMotionTable*);
void startMotion(int, PaniMotionInfo*);
void setMotionSpeed(int, f32);
int getMotionIndex(int);
void stopAllMotions();
void initFlagMotions(int);
void startFlagMotions(int);
void updateAnimation();
void updateContext();
f32 getMotionSpeed(int id) { return mAnimSpeeds[id]; }
protected:
void setMotionLastFrame(int);
PaniUfoAnimator* mAnims;
f32* mAnimSpeeds;
};
class UfoItem : public Suckable {
public:
struct LightAnimator {
LightAnimator();
void start(int);
void update();
void setSpeed(f32 speed) { mSpeed = speed; }
ShapeDynMaterials* mAnimatedMaterials;
f32 mFrame;
f32 mSpeed;
u16 mType;
};
struct Spot {
Spot() { }
Vector3f mPosition;
f32 mRadius;
f32 mAngleOffset;
f32 mRotationTime;
f32 _18;
};
UfoItem(CreatureProp*, UfoShapeObject*);
virtual bool insideSafeArea( Vector3f&);
virtual void startAI(int);
virtual f32 getiMass();
virtual f32 getSize();
virtual bool needShadow();
virtual bool ignoreAtari(Creature*);
virtual void update();
virtual void refresh(Graphics&);
virtual void demoDraw(Graphics&, Matrix4f*);
virtual void animationKeyUpdated( PaniAnimKeyEvent&);
virtual Vector3f getGoalPos();
virtual f32 getGoalPosRadius();
virtual Vector3f getSuckPos();
virtual void suckMe(Pellet*);
virtual void finishSuck(Pellet*);
virtual int getRouteIndex() { return mWaypointID; }
virtual bool isVisible() { return true; }
virtual bool isAlive() { return true; }
void setSpotTurn(bool);
void setSpotActive(bool);
void setTroubleEffect(bool);
void startTroubleEffectOne(int);
void updateTroubleEffect();
void startConeEffect(int);
void finishConeEffect();
void initLevelFlag(int);
void startLevelFlag(int);
void setJetEffect(int, bool);
void startYozora();
void startGalaxy();
void startTakeoff();
bool accessible();
void startAccess();
void finishAccess();
void setPca1Effect(bool);
void setPca2Effect(bool);
protected:
void lightLevelFlag(int);
public:
bool mIsMenuOpen;
bool mIsLightActive;
bool mShouldLightActivate;
zen::particleGenerator* mRingFx;
zen::particleGenerator* mSparkleFx;
Spot mSpots[3];
bool mIsTroubleFxEnabled;
f32 mTroubleFxTimer;
u32 mTroubleFxState;
Vector3f _434;
Vector3f _440;
Vector3f _44C;
Vector3f _458;
Vector3f _464;
Vector3f _470;
Vector3f mTroubleFxPositionList[6];
zen::particleGenerator* mTroubleFxGenList[6];
s16 mJetLevel;
zen::particleGenerator* mEngineParticleGenList[4][4];
u8 mShipUpgradeLevel;
UfoAnimator mAnimator;
int mConeEffectId;
Vector3f mPca1FxPosition;
Vector3f mPca2FxPosition;
bool mIsPca1FxActive;
bool mIsPca2FxActive;
Vector3f mSpotlightPosition;
int mWaypointID;
UfoShapeObject* mShipModel;
SeContext mShipSe;
ShapeDynMaterials* mAnimatedMaterialsList;
LightAnimator mLightAnims[4];
bool mNeedPathfindRefresh;
};
class BugPrintBuffer {
public:
BugPrintBuffer();
void clear(void);
void update(void);
void print( char*, int);
int getFrame(void) { return mFrame; }
protected:
int findLine(int);
char* mBuffer;
int mBufPos;
int mCapacity;
int mFrame;
};
extern BugPrintBuffer* bugPrintBuffer;
extern "C"{
void bugPrint( char* fmt, ...);
}
