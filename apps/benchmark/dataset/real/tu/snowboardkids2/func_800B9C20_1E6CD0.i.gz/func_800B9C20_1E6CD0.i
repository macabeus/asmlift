       
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef volatile unsigned char vu8;
typedef volatile unsigned short vu16;
typedef volatile unsigned long vu32;
typedef volatile unsigned long long vu64;
typedef volatile signed char vs8;
typedef volatile short vs16;
typedef volatile long vs32;
typedef volatile long long vs64;
typedef float f32;
typedef double f64;
typedef unsigned int size_t;
typedef s32 OSPri;
typedef s32 OSId;
typedef union {
    struct {
        f32 f_odd;
        f32 f_even;
    } f;
    f64 d;
} __OSfp;
typedef struct {
    u64 at, v0, v1, a0, a1, a2, a3;
    u64 t0, t1, t2, t3, t4, t5, t6, t7;
    u64 s0, s1, s2, s3, s4, s5, s6, s7;
    u64 t8, t9;
    u64 gp, sp, s8, ra;
    u64 lo, hi;
    u32 sr, pc, cause, badvaddr, rcp;
    u32 fpcsr;
    __OSfp fp0, fp2, fp4, fp6, fp8, fp10, fp12, fp14;
    __OSfp fp16, fp18, fp20, fp22, fp24, fp26, fp28, fp30;
} __OSThreadContext;
typedef struct {
    u32 flag;
    u32 count;
    u64 time;
} __OSThreadprofile_s;
typedef struct OSThread_s {
    struct OSThread_s *next;
    OSPri priority;
    struct OSThread_s **queue;
    struct OSThread_s *tlnext;
    u16 state;
    u16 flags;
    OSId id;
    int fp;
    __OSThreadprofile_s *thprof;
    __OSThreadContext context;
} OSThread;
extern void osCreateThread(OSThread *, OSId, void (*)(void *), void *, void *, OSPri);
extern void osDestroyThread(OSThread *);
extern void osYieldThread(void);
extern void osStartThread(OSThread *);
extern void osStopThread(OSThread *);
extern OSId osGetThreadId(OSThread *);
extern void osSetThreadPri(OSThread *, OSPri);
extern OSPri osGetThreadPri(OSThread *);
typedef u32 OSEvent;
typedef void *OSMesg;
typedef struct OSMesgQueue_s {
    OSThread *mtqueue;
    OSThread *fullqueue;
    s32 validCount;
    s32 first;
    s32 msgCount;
    OSMesg *msg;
} OSMesgQueue;
extern void osCreateMesgQueue(OSMesgQueue *, OSMesg *, s32);
extern s32 osSendMesg(OSMesgQueue *, OSMesg, s32);
extern s32 osJamMesg(OSMesgQueue *, OSMesg, s32);
extern s32 osRecvMesg(OSMesgQueue *, OSMesg *, s32);
extern void osSetEventMesg(OSEvent, OSMesgQueue *, OSMesg);
typedef u32 OSIntMask;
typedef u32 OSHWIntr;
extern OSIntMask osGetIntMask(void);
extern OSIntMask osSetIntMask(OSIntMask);
typedef u32 OSPageMask;
extern void osMapTLB(s32, OSPageMask, void *, u32, u32, s32);
extern void osMapTLBRdb(void);
extern void osUnmapTLB(s32);
extern void osUnmapTLBAll(void);
extern void osSetTLBASID(s32);
typedef struct {
    u32 errStatus;
    void *dramAddr;
    void *C2Addr;
    u32 sectorSize;
    u32 C1ErrNum;
    u32 C1ErrSector[4];
} __OSBlockInfo;
typedef struct {
    u32 cmdType;
    u16 transferMode;
    u16 blockNum;
    s32 sectorNum;
    u32 devAddr;
    u32 bmCtlShadow;
    u32 seqCtlShadow;
    __OSBlockInfo block[2];
} __OSTranxInfo;
typedef struct OSPiHandle_s {
    struct OSPiHandle_s *next;
    u8 type;
    u8 latency;
    u8 pageSize;
    u8 relDuration;
    u8 pulse;
    u8 domain;
    u32 baseAddress;
    u32 speed;
    __OSTranxInfo transferInfo;
} OSPiHandle;
typedef struct {
    u8 type;
    u32 address;
} OSPiInfo;
typedef struct {
    u16 type;
    u8 pri;
    u8 status;
    OSMesgQueue *retQueue;
} OSIoMesgHdr;
typedef struct {
    OSIoMesgHdr hdr;
    void *dramAddr;
    u32 devAddr;
    u32 size;
    OSPiHandle *piHandle;
} OSIoMesg;
typedef struct {
    s32 active;
    OSThread *thread;
    OSMesgQueue *cmdQueue;
    OSMesgQueue *evtQueue;
    OSMesgQueue *acsQueue;
    s32 (*dma)(s32, u32, void *, u32);
    s32 (*edma)(OSPiHandle *, s32, u32, void *, u32);
} OSDevMgr;
extern OSPiHandle *__osPiTable;
extern u32 osPiGetStatus(void);
extern s32 osPiGetDeviceType(void);
extern s32 osPiWriteIo(u32, u32);
extern s32 osPiReadIo(u32, u32 *);
extern s32 osPiStartDma(OSIoMesg *, s32, s32, u32, void *, u32, OSMesgQueue *);
extern void osCreatePiManager(OSPri, OSMesgQueue *, OSMesg *, s32);
extern OSPiHandle *osCartRomInit(void);
extern OSPiHandle *osLeoDiskInit(void);
extern OSPiHandle *osDriveRomInit(void);
extern s32 osEPiDeviceType(OSPiHandle *, OSPiInfo *);
extern s32 osEPiWriteIo(OSPiHandle *, u32 , u32 );
extern s32 osEPiReadIo(OSPiHandle *, u32 , u32 *);
extern s32 osEPiStartDma(OSPiHandle *, OSIoMesg *, s32);
extern s32 osEPiLinkHandle(OSPiHandle *);
typedef struct {
    u32 ctrl;
    u32 width;
    u32 burst;
    u32 vSync;
    u32 hSync;
    u32 leap;
    u32 hStart;
    u32 xScale;
    u32 vCurrent;
} OSViCommonRegs;
typedef struct {
    u32 origin;
    u32 yScale;
    u32 vStart;
    u32 vBurst;
    u32 vIntr;
} OSViFieldRegs;
typedef struct {
    u8 type;
    OSViCommonRegs comRegs;
    OSViFieldRegs fldRegs[2];
} OSViMode;
extern OSViMode osViModeTable[];
extern OSViMode osViModeNtscLpn1;
extern OSViMode osViModeNtscLpf1;
extern OSViMode osViModeNtscLan1;
extern OSViMode osViModeNtscLaf1;
extern OSViMode osViModeNtscLpn2;
extern OSViMode osViModeNtscLpf2;
extern OSViMode osViModeNtscLan2;
extern OSViMode osViModeNtscLaf2;
extern OSViMode osViModeNtscHpn1;
extern OSViMode osViModeNtscHpf1;
extern OSViMode osViModeNtscHan1;
extern OSViMode osViModeNtscHaf1;
extern OSViMode osViModeNtscHpn2;
extern OSViMode osViModeNtscHpf2;
extern OSViMode osViModePalLpn1;
extern OSViMode osViModePalLpf1;
extern OSViMode osViModePalLan1;
extern OSViMode osViModePalLaf1;
extern OSViMode osViModePalLpn2;
extern OSViMode osViModePalLpf2;
extern OSViMode osViModePalLan2;
extern OSViMode osViModePalLaf2;
extern OSViMode osViModePalHpn1;
extern OSViMode osViModePalHpf1;
extern OSViMode osViModePalHan1;
extern OSViMode osViModePalHaf1;
extern OSViMode osViModePalHpn2;
extern OSViMode osViModePalHpf2;
extern OSViMode osViModeMpalLpn1;
extern OSViMode osViModeMpalLpf1;
extern OSViMode osViModeMpalLan1;
extern OSViMode osViModeMpalLaf1;
extern OSViMode osViModeMpalLpn2;
extern OSViMode osViModeMpalLpf2;
extern OSViMode osViModeMpalLan2;
extern OSViMode osViModeMpalLaf2;
extern OSViMode osViModeMpalHpn1;
extern OSViMode osViModeMpalHpf1;
extern OSViMode osViModeMpalHan1;
extern OSViMode osViModeMpalHaf1;
extern OSViMode osViModeMpalHpn2;
extern OSViMode osViModeMpalHpf2;
extern OSViMode osViModeFpalLpn1;
extern OSViMode osViModeFpalLpf1;
extern OSViMode osViModeFpalLan1;
extern OSViMode osViModeFpalLaf1;
extern OSViMode osViModeFpalLpn2;
extern OSViMode osViModeFpalLpf2;
extern OSViMode osViModeFpalLan2;
extern OSViMode osViModeFpalLaf2;
extern OSViMode osViModeFpalHpn1;
extern OSViMode osViModeFpalHpf1;
extern OSViMode osViModeFpalHan1;
extern OSViMode osViModeFpalHaf1;
extern OSViMode osViModeFpalHpn2;
extern OSViMode osViModeFpalHpf2;
extern u32 osViGetStatus(void);
extern u32 osViGetCurrentMode(void);
extern u32 osViGetCurrentLine(void);
extern u32 osViGetCurrentField(void);
extern void *osViGetCurrentFramebuffer(void);
extern void *osViGetNextFramebuffer(void);
extern void osViSetXScale(f32);
extern void osViSetYScale(f32);
extern void osViExtendVStart(u32);
extern void osViSetSpecialFeatures(u32);
extern void osViSetMode(OSViMode *);
extern void osViSetEvent(OSMesgQueue *, OSMesg, u32);
extern void osViSwapBuffer(void *);
extern void osViBlack(u8);
extern void osViFade(u8, u16);
extern void osViRepeatLine(u8);
extern void osCreateViManager(OSPri);
extern u32 osAiGetStatus(void);
extern u32 osAiGetLength(void);
extern s32 osAiSetFrequency(u32);
extern s32 osAiSetNextBuffer(void *, u32);
typedef u64 OSTime;
typedef struct OSTimer_s {
 struct OSTimer_s *next;
 struct OSTimer_s *prev;
 OSTime interval;
 OSTime value;
 OSMesgQueue *mq;
 OSMesg msg;
} OSTimer;
extern OSTime osGetTime(void);
extern void osSetTime(OSTime);
extern int osSetTimer(OSTimer *, OSTime, OSTime,
       OSMesgQueue *, OSMesg);
extern int osStopTimer(OSTimer *);
typedef struct {
 u16 type;
 u8 status;
 u8 errno;
}OSContStatus;
typedef struct {
 u16 button;
 s8 stick_x;
 s8 stick_y;
 u8 errno;
} OSContPad;
typedef struct {
 void *address;
 u8 databuffer[32];
        u8 addressCrc;
 u8 dataCrc;
 u8 errno;
} OSContRamIo;
extern s32 osContInit(OSMesgQueue *, u8 *, OSContStatus *);
extern s32 osContReset(OSMesgQueue *, OSContStatus *);
extern s32 osContStartQuery(OSMesgQueue *);
extern s32 osContStartReadData(OSMesgQueue *);
extern s32 osContSetCh(u8);
extern void osContGetQuery(OSContStatus *);
extern void osContGetReadData(OSContPad *);
typedef struct {
 int status;
 OSMesgQueue *queue;
 int channel;
 u8 id[32];
 u8 label[32];
 int version;
 int dir_size;
 int inode_table;
 int minode_table;
 int dir_table;
 int inode_start_page;
 u8 banks;
 u8 activebank;
} OSPfs;
typedef struct {
 u32 file_size;
   u32 game_code;
   u16 company_code;
   char ext_name[4];
   char game_name[16];
} OSPfsState;
extern s32 osPfsInitPak(OSMesgQueue *, OSPfs *, int);
extern s32 osPfsRepairId(OSPfs *);
extern s32 osPfsInit(OSMesgQueue *, OSPfs *, int);
extern s32 osPfsReFormat(OSPfs *, OSMesgQueue *, int);
extern s32 osPfsChecker(OSPfs *);
extern s32 osPfsAllocateFile(OSPfs *, u16, u32, u8 *, u8 *, int, s32 *);
extern s32 osPfsFindFile(OSPfs *, u16, u32, u8 *, u8 *, s32 *);
extern s32 osPfsDeleteFile(OSPfs *, u16, u32, u8 *, u8 *);
extern s32 osPfsReadWriteFile(OSPfs *, s32, u8, int, int, u8 *);
extern s32 osPfsFileState(OSPfs *, s32, OSPfsState *);
extern s32 osPfsGetLabel(OSPfs *, u8 *, int *);
extern s32 osPfsSetLabel(OSPfs *, u8 *);
extern s32 osPfsIsPlug(OSMesgQueue *, u8 *);
extern s32 osPfsFreeBlocks(OSPfs *, s32 *);
extern s32 osPfsNumFiles(OSPfs *, s32 *, s32 *);
typedef struct {
  u16 fixed1;
  u16 start_address;
  u8 nintendo_chr[0x30];
  u8 game_title[16];
  u16 company_code;
  u8 body_code;
  u8 cart_type;
  u8 rom_size;
  u8 ram_size;
  u8 country_code;
  u8 fixed2;
  u8 version;
  u8 isum;
  u16 sum;
} OSGbpakId;
extern s32 osGbpakInit(OSMesgQueue *, OSPfs *, int);
extern s32 osGbpakPower(OSPfs *, s32);
extern s32 osGbpakGetStatus(OSPfs *, u8 *);
extern s32 osGbpakReadWrite(OSPfs *, u16, u16, u8 *, u16);
extern s32 osGbpakReadId(OSPfs *, OSGbpakId *, u8 *);
extern s32 osGbpakCheckConnector(OSPfs *, u8 *);
typedef struct {
  OSMesgQueue *__mq;
  int __channel;
  s32 __mode;
  u8 cmd_status;
} OSVoiceHandle;
typedef struct {
  u16 warning;
  u16 answer_num;
  u16 voice_level;
  u16 voice_sn;
  u16 voice_time;
  u16 answer[5];
  u16 distance[5];
} OSVoiceData;
extern s32 osVoiceInit(OSMesgQueue *, OSVoiceHandle *, int);
extern s32 osVoiceCheckWord(u8 *data);
extern s32 osVoiceClearDictionary(OSVoiceHandle *, u8);
extern s32 osVoiceControlGain(OSVoiceHandle *, s32, s32);
extern s32 osVoiceSetWord(OSVoiceHandle *, u8 *);
extern s32 osVoiceStartReadData(OSVoiceHandle *);
extern s32 osVoiceStopReadData(OSVoiceHandle *);
extern s32 osVoiceGetReadData(OSVoiceHandle *, OSVoiceData *);
extern s32 osVoiceMaskDictionary(OSVoiceHandle *, u8 *, int);
extern void osVoiceCountSyllables(u8 *, u32 *);
extern void osInvalDCache(void *, s32);
extern void osInvalICache(void *, s32);
extern void osWritebackDCache(void *, s32);
extern void osWritebackDCacheAll(void);
typedef struct {
 u16 *histo_base;
 u32 histo_size;
 u32 *text_start;
 u32 *text_end;
} OSProf;
extern void osProfileInit(OSProf *, u32 profcnt);
extern void osProfileStart(u32);
extern void osProfileFlush(void);
extern void osProfileStop(void);
extern void osThreadProfileClear(OSId);
extern void osThreadProfileInit(void);
extern void osThreadProfileStart(void);
extern void osThreadProfileStop(void);
extern u32 osThreadProfileReadCount(OSId);
extern u32 osThreadProfileReadCountTh(OSThread*);
extern OSTime osThreadProfileReadTime(OSId);
extern OSTime osThreadProfileReadTimeTh(OSThread*);
extern u32 osGetCount(void);
extern s32 osRomType;
extern void *osRomBase;
extern s32 osTvType;
extern s32 osResetType;
extern s32 osCicId;
extern s32 osVersion;
extern u32 osMemSize;
extern s32 osAppNMIBuffer[];
extern u64 osClockRate;
extern OSIntMask __OSGlobalIntMask;
extern void osInitialize(void);
extern void osExit(void);
extern u32 osGetMemSize(void);
extern s32 osAfterPreNMI(void);
extern s32 osEepromProbe(OSMesgQueue *);
extern s32 osEepromRead(OSMesgQueue *, u8, u8 *);
extern s32 osEepromWrite(OSMesgQueue *, u8, u8 *);
extern s32 osEepromLongRead(OSMesgQueue *, u8, u8 *, int);
extern s32 osEepromLongWrite(OSMesgQueue *, u8, u8 *, int);
extern OSPiHandle *osFlashReInit(u8 latency, u8 pulse,
                 u8 page_size, u8 rel_duration, u32 start);
extern OSPiHandle *osFlashInit(void);
extern void osFlashReadStatus(u8 *flash_status);
extern void osFlashReadId(u32 *flash_type, u32 *flash_maker);
extern void osFlashClearStatus(void);
extern s32 osFlashAllErase(void);
extern s32 osFlashSectorErase(u32 page_num);
extern s32 osFlashWriteBuffer(OSIoMesg *mb, s32 priority,
                void *dramAddr, OSMesgQueue *mq);
extern s32 osFlashWriteArray(u32 page_num);
extern s32 osFlashReadArray(OSIoMesg *mb, s32 priority, u32 page_num,
                void *dramAddr, u32 n_pages, OSMesgQueue *mq);
extern void osFlashChange(u32 flash_num);
extern void osFlashAllEraseThrough(void);
extern void osFlashSectorEraseThrough(u32 page_num);
extern s32 osFlashCheckEraseEnd(void);
extern void __osInitialize_common(void);
extern s32 osTestHost(void);
extern void osReadHost(void *, u32);
extern void osWriteHost(void *, u32);
extern void osAckRamromRead(void);
extern void osAckRamromWrite(void);
extern void osInitRdb(u8 *sendBuf, u32 sendSize);
extern u32 osVirtualToPhysical(void *);
extern void * osPhysicalToVirtual(u32);
extern u32 osDpGetStatus(void);
extern void osDpSetStatus(u32);
extern void osDpGetCounters(u32 *);
extern s32 osDpSetNextBuffer(void *, u64);
extern s32 osMotorInit(OSMesgQueue *, OSPfs *, int);
extern s32 __osMotorAccess(OSPfs *, s32);
extern void bcopy(const void *, void *, int);
extern int bcmp(const void *, const void *, int);
extern void bzero(void *, int);
extern int sprintf(char *s, const char *fmt, ...);
extern void osSyncPrintf(const char *fmt, ...);
typedef struct _Region_s {
 u8 *r_startBufferAddress;
 u8 *r_endAddress;
 s32 r_bufferSize;
 s32 r_bufferCount;
 u16 r_freeList;
 u16 r_alignSize;
} OSRegion;
extern void *osCreateRegion(void *, u32, u32, u32);
extern void *osMalloc(void *);
extern void osFree(void *, void *);
extern s32 osGetRegionBufCount(void *);
extern s32 osGetRegionBufSize(void *);
extern void rmonMain( void * );
extern void rmonPrintf( const char *, ... );
typedef struct {
 u32 type;
 u32 flags;
 u64 *ucode_boot;
 u32 ucode_boot_size;
 u64 *ucode;
 u32 ucode_size;
 u64 *ucode_data;
 u32 ucode_data_size;
 u64 *dram_stack;
 u32 dram_stack_size;
 u64 *output_buff;
 u64 *output_buff_size;
 u64 *data_ptr;
 u32 data_size;
 u64 *yield_data_ptr;
 u32 yield_data_size;
} OSTask_t;
typedef union {
    OSTask_t t;
    long long int force_structure_alignment;
} OSTask;
typedef u32 OSYieldResult;
extern void osSpTaskLoad(OSTask *tp);
extern void osSpTaskStartGo(OSTask *tp);
extern void osSpTaskYield(void);
extern OSYieldResult osSpTaskYielded(OSTask *tp);
typedef struct {
 short ob[3];
 unsigned short flag;
 short tc[2];
 unsigned char cn[4];
} Vtx_t;
typedef struct {
 short ob[3];
 unsigned short flag;
 short tc[2];
 signed char n[3];
 unsigned char a;
} Vtx_tn;
typedef union {
    Vtx_t v;
    Vtx_tn n;
    long long int force_structure_alignment;
} Vtx;
typedef struct {
  void *SourceImagePointer;
  void *TlutPointer;
  short Stride;
  short SubImageWidth;
  short SubImageHeight;
  char SourceImageType;
  char SourceImageBitSize;
  short SourceImageOffsetS;
  short SourceImageOffsetT;
  char dummy[4];
} uSprite_t;
typedef union {
  uSprite_t s;
  long long int force_structure_allignment[3];
} uSprite;
typedef struct {
 unsigned char flag;
 unsigned char v[3];
} Tri;
typedef long Mtx_t[4][4];
typedef union {
    Mtx_t m;
    long long int force_structure_alignment;
} Mtx;
typedef struct {
 short vscale[4];
 short vtrans[4];
} Vp_t;
typedef union {
    Vp_t vp;
    long long int force_structure_alignment;
} Vp;
typedef struct {
  unsigned char col[3];
  char pad1;
  unsigned char colc[3];
  char pad2;
  signed char dir[3];
  char pad3;
} Light_t;
typedef struct {
  unsigned char col[3];
  char pad1;
  unsigned char colc[3];
  char pad2;
} Ambient_t;
typedef struct {
  int x1,y1,x2,y2;
} Hilite_t;
typedef union {
    Light_t l;
    long long int force_structure_alignment[2];
} Light;
typedef union {
    Ambient_t l;
    long long int force_structure_alignment[1];
} Ambient;
typedef struct {
    Ambient a;
    Light l[7];
} Lightsn;
typedef struct {
    Ambient a;
    Light l[1];
} Lights0;
typedef struct {
    Ambient a;
    Light l[1];
} Lights1;
typedef struct {
    Ambient a;
    Light l[2];
} Lights2;
typedef struct {
    Ambient a;
    Light l[3];
} Lights3;
typedef struct {
    Ambient a;
    Light l[4];
} Lights4;
typedef struct {
    Ambient a;
    Light l[5];
} Lights5;
typedef struct {
    Ambient a;
    Light l[6];
} Lights6;
typedef struct {
    Ambient a;
    Light l[7];
} Lights7;
typedef struct {
    Light l[2];
} LookAt;
typedef union {
    Hilite_t h;
    long int force_structure_alignment[4];
} Hilite;
typedef struct {
 int cmd:8;
 unsigned int par:8;
 unsigned int len:16;
 unsigned int addr;
} Gdma;
typedef struct {
  int cmd:8;
  int pad:24;
  Tri tri;
} Gtri;
typedef struct {
  int cmd:8;
  int pad1:24;
  int pad2:24;
  unsigned char param:8;
} Gpopmtx;
typedef struct {
  int cmd:8;
  int pad0:8;
  int mw_index:8;
  int number:8;
  int pad1:8;
  int base:24;
} Gsegment;
typedef struct {
  int cmd:8;
  int pad0:8;
  int sft:8;
  int len:8;
  unsigned int data:32;
} GsetothermodeL;
typedef struct {
  int cmd:8;
  int pad0:8;
  int sft:8;
  int len:8;
  unsigned int data:32;
} GsetothermodeH;
typedef struct {
  unsigned char cmd;
  unsigned char lodscale;
  unsigned char tile;
  unsigned char on;
  unsigned short s;
  unsigned short t;
} Gtexture;
typedef struct {
  int cmd:8;
  int pad:24;
  Tri line;
} Gline3D;
typedef struct {
  int cmd:8;
  int pad1:24;
  short int pad2;
  short int scale;
} Gperspnorm;
typedef struct {
                int cmd:8;
                unsigned int fmt:3;
                unsigned int siz:2;
                unsigned int pad:7;
                unsigned int wd:12;
                unsigned int dram;
} Gsetimg;
typedef struct {
  int cmd:8;
  unsigned int muxs0:24;
  unsigned int muxs1:32;
} Gsetcombine;
typedef struct {
  int cmd:8;
  unsigned char pad;
  unsigned char prim_min_level;
  unsigned char prim_level;
  unsigned long color;
} Gsetcolor;
typedef struct {
  int cmd:8;
  int x0:10;
  int x0frac:2;
  int y0:10;
  int y0frac:2;
  unsigned int pad:8;
  int x1:10;
  int x1frac:2;
  int y1:10;
  int y1frac:2;
} Gfillrect;
typedef struct {
  int cmd:8;
  unsigned int fmt:3;
  unsigned int siz:2;
  unsigned int pad0:1;
  unsigned int line:9;
  unsigned int tmem:9;
  unsigned int pad1:5;
  unsigned int tile:3;
  unsigned int palette:4;
  unsigned int ct:1;
  unsigned int mt:1;
  unsigned int maskt:4;
  unsigned int shiftt:4;
  unsigned int cs:1;
  unsigned int ms:1;
  unsigned int masks:4;
  unsigned int shifts:4;
} Gsettile;
typedef struct {
  int cmd:8;
  unsigned int sl:12;
  unsigned int tl:12;
  int pad:5;
  unsigned int tile:3;
  unsigned int sh:12;
  unsigned int th:12;
} Gloadtile;
typedef Gloadtile Gloadblock;
typedef Gloadtile Gsettilesize;
typedef Gloadtile Gloadtlut;
typedef struct {
  unsigned int cmd:8;
  unsigned int xl:12;
  unsigned int yl:12;
  unsigned int pad1:5;
  unsigned int tile:3;
  unsigned int xh:12;
  unsigned int yh:12;
  unsigned int s:16;
  unsigned int t:16;
  unsigned int dsdx:16;
  unsigned int dtdy:16;
} Gtexrect;
typedef struct {
    unsigned long w0;
    unsigned long w1;
    unsigned long w2;
    unsigned long w3;
} TexRect;
typedef struct {
 unsigned int w0;
 unsigned int w1;
} Gwords;
typedef union {
 Gwords words;
 Gdma dma;
 Gtri tri;
 Gline3D line;
 Gpopmtx popmtx;
 Gsegment segment;
 GsetothermodeH setothermodeH;
 GsetothermodeL setothermodeL;
 Gtexture texture;
 Gperspnorm perspnorm;
 Gsetimg setimg;
 Gsetcombine setcombine;
 Gsetcolor setcolor;
 Gfillrect fillrect;
 Gsettile settile;
 Gloadtile loadtile;
 Gsettilesize settilesize;
 Gloadtlut loadtlut;
        long long int force_structure_alignment;
} Gfx;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int gain:16;
 unsigned int addr;
} Aadpcm;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int gain:16;
 unsigned int addr;
} Apolef;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pad1:16;
 unsigned int addr;
} Aenvelope;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:8;
 unsigned int dmem:16;
 unsigned int pad2:16;
 unsigned int count:16;
} Aclearbuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:8;
 unsigned int pad2:16;
 unsigned int inL:16;
        unsigned int inR:16;
} Ainterleave;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:24;
 unsigned int addr;
} Aloadbuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pad1:16;
 unsigned int addr;
} Aenvmixer;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int gain:16;
 unsigned int dmemi:16;
 unsigned int dmemo:16;
} Amixer;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int dmem2:16;
 unsigned int addr;
} Apan;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pitch:16;
 unsigned int addr;
} Aresample;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int pad1:16;
 unsigned int addr;
} Areverb;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:24;
 unsigned int addr;
} Asavebuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int pad1:24;
 unsigned int pad2:2;
 unsigned int number:4;
 unsigned int base:24;
} Asegment;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int dmemin:16;
 unsigned int dmemout:16;
 unsigned int count:16;
} Asetbuff;
typedef struct {
   unsigned int cmd:8;
 unsigned int flags:8;
 unsigned int vol:16;
 unsigned int voltgt:16;
 unsigned int volrate:16;
} Asetvol;
typedef struct {
    unsigned int cmd:8;
    unsigned int pad1:8;
    unsigned int dmemin:16;
    unsigned int dmemout:16;
    unsigned int count:16;
} Admemmove;
typedef struct {
    unsigned int cmd:8;
    unsigned int pad1:8;
    unsigned int count:16;
    unsigned int addr;
} Aloadadpcm;
typedef struct {
    unsigned int cmd:8;
    unsigned int pad1:8;
    unsigned int pad2:16;
    unsigned int addr;
} Asetloop;
typedef struct {
 unsigned int w0;
 unsigned int w1;
} Awords;
typedef union {
 Awords words;
 Aadpcm adpcm;
        Apolef polef;
 Aclearbuff clearbuff;
 Aenvelope envelope;
        Ainterleave interleave;
 Aloadbuff loadbuff;
        Aenvmixer envmixer;
 Aresample resample;
 Areverb reverb;
 Asavebuff savebuff;
 Asegment segment;
 Asetbuff setbuff;
 Asetvol setvol;
        Admemmove dmemmove;
        Aloadadpcm loadadpcm;
        Amixer mixer;
        Asetloop setloop;
        long long int force_union_align;
} Acmd;
typedef short ADPCM_STATE[16];
typedef short POLEF_STATE[4];
typedef short RESAMPLE_STATE[16];
typedef short ENVMIX_STATE[40];
typedef s32 ALMicroTime;
typedef u8 ALPan;
typedef struct ALLink_s {
    struct ALLink_s *next;
    struct ALLink_s *prev;
} ALLink;
void alUnlink(ALLink *element);
void alLink(ALLink *element, ALLink *after);
typedef s32 (*ALDMAproc)(s32 addr, s32 len, void *state);
typedef ALDMAproc (*ALDMANew)(void *state);
void alCopy(void *src, void *dest, s32 len);
typedef struct {
    u8 *base;
    u8 *cur;
    s32 len;
    s32 count;
} ALHeap;
void alHeapInit(ALHeap *hp, u8 *base, s32 len);
void *alHeapDBAlloc(u8 *file, s32 line, ALHeap *hp, s32 num, s32 size);
s32 alHeapCheck(ALHeap *hp);
typedef u8 ALFxId;
typedef void *ALFxRef;
enum {AL_ADPCM_WAVE = 0,
         AL_RAW16_WAVE};
typedef struct {
    s32 order;
    s32 npredictors;
    s16 book[1];
} ALADPCMBook;
typedef struct {
    u32 start;
    u32 end;
    u32 count;
    ADPCM_STATE state;
} ALADPCMloop;
typedef struct {
    u32 start;
    u32 end;
    u32 count;
} ALRawLoop;
typedef struct {
    ALMicroTime attackTime;
    ALMicroTime decayTime;
    ALMicroTime releaseTime;
    u8 attackVolume;
    u8 decayVolume;
} ALEnvelope;
typedef struct {
    u8 velocityMin;
    u8 velocityMax;
    u8 keyMin;
    u8 keyMax;
    u8 keyBase;
    s8 detune;
} ALKeyMap;
typedef struct {
    ALADPCMloop *loop;
    ALADPCMBook *book;
} ALADPCMWaveInfo;
typedef struct {
    ALRawLoop *loop;
} ALRAWWaveInfo;
typedef struct ALWaveTable_s {
    u8 *base;
    s32 len;
    u8 type;
    u8 flags;
    union {
        ALADPCMWaveInfo adpcmWave;
        ALRAWWaveInfo rawWave;
    } waveInfo;
} ALWaveTable;
typedef struct ALSound_s {
    ALEnvelope *envelope;
    ALKeyMap *keyMap;
    ALWaveTable *wavetable;
    ALPan samplePan;
    u8 sampleVolume;
    u8 flags;
} ALSound;
typedef struct {
    u8 volume;
    ALPan pan;
    u8 priority;
    u8 flags;
    u8 tremType;
    u8 tremRate;
    u8 tremDepth;
    u8 tremDelay;
    u8 vibType;
    u8 vibRate;
    u8 vibDepth;
    u8 vibDelay;
    s16 bendRange;
    s16 soundCount;
    ALSound *soundArray[1];
} ALInstrument;
typedef struct ALBank_s {
    s16 instCount;
    u8 flags;
    u8 pad;
    s32 sampleRate;
    ALInstrument *percussion;
    ALInstrument *instArray[1];
} ALBank;
typedef struct {
    s16 revision;
    s16 bankCount;
    ALBank *bankArray[1];
} ALBankFile;
void alBnkfNew(ALBankFile *f, u8 *table);
typedef struct {
    u8 *offset;
    s32 len;
} ALSeqData;
typedef struct {
    s16 revision;
    s16 seqCount;
    ALSeqData seqArray[1];
} ALSeqFile;
void alSeqFileNew(ALSeqFile *f, u8 *base);
typedef ALMicroTime (*ALVoiceHandler)(void *);
typedef struct {
    s32 maxVVoices;
    s32 maxPVoices;
    s32 maxUpdates;
    s32 maxFXbusses;
    void *dmaproc;
    ALHeap *heap;
    s32 outputRate;
    ALFxId fxType;
    s32 *params;
} ALSynConfig;
typedef struct ALPlayer_s {
    struct ALPlayer_s *next;
    void *clientData;
    ALVoiceHandler handler;
    ALMicroTime callTime;
    s32 samplesLeft;
} ALPlayer;
typedef struct ALVoice_s {
    ALLink node;
    struct PVoice_s *pvoice;
    ALWaveTable *table;
    void *clientPrivate;
    s16 state;
    s16 priority;
    s16 fxBus;
    s16 unityPitch;
} ALVoice;
typedef struct ALVoiceConfig_s {
    s16 priority;
    s16 fxBus;
    u8 unityPitch;
} ALVoiceConfig;
typedef struct {
    ALPlayer *head;
    ALLink pFreeList;
    ALLink pAllocList;
    ALLink pLameList;
    s32 paramSamples;
    s32 curSamples;
    ALDMANew dma;
    ALHeap *heap;
    struct ALParam_s *paramList;
    struct ALMainBus_s *mainBus;
    struct ALAuxBus_s *auxBus;
    struct ALFilter_s *outputFilter;
    s32 numPVoices;
    s32 maxAuxBusses;
    s32 outputRate;
    s32 maxOutSamples;
} ALSynth;
void alSynNew(ALSynth *s, ALSynConfig *config);
void alSynDelete(ALSynth *s);
void alSynAddPlayer(ALSynth *s, ALPlayer *client);
void alSynRemovePlayer(ALSynth *s, ALPlayer *client);
s32 alSynAllocVoice(ALSynth *s, ALVoice *v, ALVoiceConfig *vc);
void alSynFreeVoice(ALSynth *s, ALVoice *voice);
void alSynStartVoice(ALSynth *s, ALVoice *voice, ALWaveTable *w);
void alSynStartVoiceParams(ALSynth *s, ALVoice *voice, ALWaveTable *w,
                              f32 pitch, s16 vol, ALPan pan, u8 fxmix,
                              ALMicroTime t);
void alSynStopVoice(ALSynth *s, ALVoice *voice);
void alSynSetVol(ALSynth *s, ALVoice *v, s16 vol, ALMicroTime delta);
void alSynSetPitch(ALSynth *s, ALVoice *voice, f32 ratio);
void alSynSetPan(ALSynth *s, ALVoice *voice, ALPan pan);
void alSynSetFXMix(ALSynth *s, ALVoice *voice, u8 fxmix);
void alSynSetPriority(ALSynth *s, ALVoice *voice, s16 priority);
s16 alSynGetPriority(ALSynth *s, ALVoice *voice);
ALFxRef *alSynAllocFX(ALSynth *s, s16 bus, ALSynConfig *c, ALHeap *hp);
ALFxRef alSynGetFXRef(ALSynth *s, s16 bus, s16 index);
void alSynFreeFX(ALSynth *s, ALFxRef *fx);
void alSynSetFXParam(ALSynth *s, ALFxRef fx, s16 paramID, void *param);
typedef struct {
    ALSynth drvr;
} ALGlobals;
extern ALGlobals *alGlobals;
void alInit(ALGlobals *glob, ALSynConfig *c);
void alClose(ALGlobals *glob);
Acmd *alAudioFrame(Acmd *cmdList, s32 *cmdLen, s16 *outBuf, s32 outLen);
enum ALMsg {
    AL_SEQ_REF_EVT,
    AL_SEQ_MIDI_EVT,
    AL_SEQP_MIDI_EVT,
    AL_TEMPO_EVT,
    AL_SEQ_END_EVT,
    AL_NOTE_END_EVT,
    AL_SEQP_ENV_EVT,
    AL_SEQP_META_EVT,
    AL_SEQP_PROG_EVT,
    AL_SEQP_API_EVT,
    AL_SEQP_VOL_EVT,
    AL_SEQP_LOOP_EVT,
    AL_SEQP_PRIORITY_EVT,
    AL_SEQP_SEQ_EVT,
    AL_SEQP_BANK_EVT,
    AL_SEQP_PLAY_EVT,
    AL_SEQP_STOP_EVT,
    AL_SEQP_STOPPING_EVT,
    AL_TRACK_END,
    AL_CSP_LOOPSTART,
    AL_CSP_LOOPEND,
    AL_CSP_NOTEOFF_EVT,
    AL_TREM_OSC_EVT,
    AL_VIB_OSC_EVT
};
enum AL_MIDIstatus {
    AL_MIDI_ChannelMask = 0x0F,
    AL_MIDI_StatusMask = 0xF0,
    AL_MIDI_ChannelVoice = 0x80,
    AL_MIDI_NoteOff = 0x80,
    AL_MIDI_NoteOn = 0x90,
    AL_MIDI_PolyKeyPressure = 0xA0,
    AL_MIDI_ControlChange = 0xB0,
    AL_MIDI_ChannelModeSelect = 0xB0,
    AL_MIDI_ProgramChange = 0xC0,
    AL_MIDI_ChannelPressure = 0xD0,
    AL_MIDI_PitchBendChange = 0xE0,
    AL_MIDI_SysEx = 0xF0,
    AL_MIDI_SystemCommon = 0xF1,
    AL_MIDI_TimeCodeQuarterFrame = 0xF1,
    AL_MIDI_SongPositionPointer = 0xF2,
    AL_MIDI_SongSelect = 0xF3,
    AL_MIDI_Undefined1 = 0xF4,
    AL_MIDI_Undefined2 = 0xF5,
    AL_MIDI_TuneRequest = 0xF6,
    AL_MIDI_EOX = 0xF7,
    AL_MIDI_SystemRealTime = 0xF8,
    AL_MIDI_TimingClock = 0xF8,
    AL_MIDI_Undefined3 = 0xF9,
    AL_MIDI_Start = 0xFA,
    AL_MIDI_Continue = 0xFB,
    AL_MIDI_Stop = 0xFC,
    AL_MIDI_Undefined4 = 0xFD,
    AL_MIDI_ActiveSensing = 0xFE,
    AL_MIDI_SystemReset = 0xFF,
    AL_MIDI_Meta = 0xFF
};
enum AL_MIDIctrl {
    AL_MIDI_VOLUME_CTRL = 0x07,
    AL_MIDI_PAN_CTRL = 0x0A,
    AL_MIDI_PRIORITY_CTRL = 0x10,
    AL_MIDI_FX_CTRL_0 = 0x14,
    AL_MIDI_FX_CTRL_1 = 0x15,
    AL_MIDI_FX_CTRL_2 = 0x16,
    AL_MIDI_FX_CTRL_3 = 0x17,
    AL_MIDI_FX_CTRL_4 = 0x18,
    AL_MIDI_FX_CTRL_5 = 0x19,
    AL_MIDI_FX_CTRL_6 = 0x1A,
    AL_MIDI_FX_CTRL_7 = 0x1B,
    AL_MIDI_FX_CTRL_8 = 0x1C,
    AL_MIDI_FX_CTRL_9 = 0x1D,
    AL_MIDI_SUSTAIN_CTRL = 0x40,
    AL_MIDI_FX1_CTRL = 0x5B,
    AL_MIDI_FX3_CTRL = 0x5D
};
enum AL_MIDImeta {
    AL_MIDI_META_TEMPO = 0x51,
    AL_MIDI_META_EOT = 0x2f
};
typedef struct {
    u8 *curPtr;
    s32 lastTicks;
    s32 curTicks;
    s16 lastStatus;
} ALSeqMarker;
typedef struct {
    s32 ticks;
    u8 status;
    u8 byte1;
    u8 byte2;
    u32 duration;
} ALMIDIEvent;
typedef struct {
    s32 ticks;
    u8 status;
    u8 type;
    u8 len;
    u8 byte1;
    u8 byte2;
    u8 byte3;
} ALTempoEvent;
typedef struct {
    s32 ticks;
    u8 status;
    u8 type;
    u8 len;
} ALEndEvent;
typedef struct {
    struct ALVoice_s *voice;
} ALNoteEvent;
typedef struct {
    struct ALVoice_s *voice;
    ALMicroTime delta;
    u8 vol;
} ALVolumeEvent;
typedef struct {
    s16 vol;
} ALSeqpVolEvent;
typedef struct {
    ALSeqMarker *start;
    ALSeqMarker *end;
    s32 count;
} ALSeqpLoopEvent;
typedef struct {
    u8 chan;
    u8 priority;
} ALSeqpPriorityEvent;
typedef struct {
    void *seq;
} ALSeqpSeqEvent;
typedef struct {
    ALBank *bank;
} ALSeqpBankEvent;
typedef struct {
    struct ALVoiceState_s *vs;
    void *oscState;
    u8 chan;
} ALOscEvent;
typedef struct {
    s16 type;
    union {
        ALMIDIEvent midi;
        ALTempoEvent tempo;
        ALEndEvent end;
        ALNoteEvent note;
        ALVolumeEvent vol;
        ALSeqpLoopEvent loop;
        ALSeqpVolEvent spvol;
 ALSeqpPriorityEvent sppriority;
 ALSeqpSeqEvent spseq;
 ALSeqpBankEvent spbank;
        ALOscEvent osc;
    } msg;
} ALEvent;
typedef struct {
    ALLink node;
    ALMicroTime delta;
    ALEvent evt;
} ALEventListItem;
typedef struct {
    ALLink freeList;
    ALLink allocList;
    s32 eventCount;
} ALEventQueue;
void alEvtqNew(ALEventQueue *evtq, ALEventListItem *items,
                          s32 itemCount);
ALMicroTime alEvtqNextEvent(ALEventQueue *evtq, ALEvent *evt);
void alEvtqPostEvent(ALEventQueue *evtq, ALEvent *evt,
                                ALMicroTime delta);
void alEvtqFlush(ALEventQueue *evtq);
void alEvtqFlushType(ALEventQueue *evtq, s16 type);
typedef struct ALVoiceState_s {
    struct ALVoiceState_s *next;
    ALVoice voice;
    ALSound *sound;
    ALMicroTime envEndTime;
    f32 pitch;
    f32 vibrato;
    u8 envGain;
    u8 channel;
    u8 key;
    u8 velocity;
    u8 envPhase;
    u8 phase;
    u8 tremelo;
    u8 flags;
} ALVoiceState;
typedef struct {
    ALInstrument *instrument;
    s16 bendRange;
    ALFxId fxId;
    ALPan pan;
    u8 priority;
    u8 vol;
    u8 fxmix;
    u8 sustain;
    f32 pitchBend;
} ALChanState;
typedef struct ALSeq_s {
    u8 *base;
    u8 *trackStart;
    u8 *curPtr;
    s32 lastTicks;
    s32 len;
    f32 qnpt;
    s16 division;
    s16 lastStatus;
} ALSeq;
typedef struct {
    u32 trackOffset[16];
    u32 division;
} ALCMidiHdr;
typedef struct ALCSeq_s {
    ALCMidiHdr *base;
    u32 validTracks;
    f32 qnpt;
    u32 lastTicks;
    u32 lastDeltaTicks;
    u32 deltaFlag;
    u8 *curLoc[16];
    u8 *curBUPtr[16];
    u8 curBULen[16];
    u8 lastStatus[16];
    u32 evtDeltaTicks[16];
} ALCSeq;
typedef struct {
    u32 validTracks;
    s32 lastTicks;
    u32 lastDeltaTicks;
    u8 *curLoc[16];
    u8 *curBUPtr[16];
    u8 curBULen[16];
    u8 lastStatus[16];
    u32 evtDeltaTicks[16];
} ALCSeqMarker;
typedef struct {
    s32 maxVoices;
    s32 maxEvents;
    u8 maxChannels;
    u8 debugFlags;
    ALHeap *heap;
    void *initOsc;
    void *updateOsc;
    void *stopOsc;
} ALSeqpConfig;
typedef ALMicroTime (*ALOscInit)(void **oscState,f32 *initVal, u8 oscType,
                                   u8 oscRate, u8 oscDepth, u8 oscDelay);
typedef ALMicroTime (*ALOscUpdate)(void *oscState, f32 *updateVal);
typedef void (*ALOscStop)(void *oscState);
typedef struct {
    ALPlayer node;
    ALSynth *drvr;
    ALSeq *target;
    ALMicroTime curTime;
    ALBank *bank;
    s32 uspt;
    s32 nextDelta;
    s32 state;
    u16 chanMask;
    s16 vol;
    u8 maxChannels;
    u8 debugFlags;
    ALEvent nextEvent;
    ALEventQueue evtq;
    ALMicroTime frameTime;
    ALChanState *chanState;
    ALVoiceState *vAllocHead;
    ALVoiceState *vAllocTail;
    ALVoiceState *vFreeList;
    ALOscInit initOsc;
    ALOscUpdate updateOsc;
    ALOscStop stopOsc;
    ALSeqMarker *loopStart;
    ALSeqMarker *loopEnd;
    s32 loopCount;
} ALSeqPlayer;
typedef struct {
    ALPlayer node;
    ALSynth *drvr;
    ALCSeq *target;
    ALMicroTime curTime;
    ALBank *bank;
    s32 uspt;
    s32 nextDelta;
    s32 state;
    u16 chanMask;
    s16 vol;
    u8 maxChannels;
    u8 debugFlags;
    ALEvent nextEvent;
    ALEventQueue evtq;
    ALMicroTime frameTime;
    ALChanState *chanState;
    ALVoiceState *vAllocHead;
    ALVoiceState *vAllocTail;
    ALVoiceState *vFreeList;
    ALOscInit initOsc;
    ALOscUpdate updateOsc;
    ALOscStop stopOsc;
} ALCSPlayer;
void alSeqNew(ALSeq *seq, u8 *ptr, s32 len);
void alSeqNextEvent(ALSeq *seq, ALEvent *event);
s32 alSeqGetTicks(ALSeq *seq);
f32 alSeqTicksToSec(ALSeq *seq, s32 ticks, u32 tempo);
u32 alSeqSecToTicks(ALSeq *seq, f32 sec, u32 tempo);
void alSeqNewMarker(ALSeq *seq, ALSeqMarker *m, u32 ticks);
void alSeqSetLoc(ALSeq *seq, ALSeqMarker *marker);
void alSeqGetLoc(ALSeq *seq, ALSeqMarker *marker);
void alCSeqNew(ALCSeq *seq, u8 *ptr);
void alCSeqNextEvent(ALCSeq *seq,ALEvent *evt);
s32 alCSeqGetTicks(ALCSeq *seq);
f32 alCSeqTicksToSec(ALCSeq *seq, s32 ticks, u32 tempo);
u32 alCSeqSecToTicks(ALCSeq *seq, f32 sec, u32 tempo);
void alCSeqNewMarker(ALCSeq *seq, ALCSeqMarker *m, u32 ticks);
void alCSeqSetLoc(ALCSeq *seq, ALCSeqMarker *marker);
void alCSeqGetLoc(ALCSeq *seq, ALCSeqMarker *marker);
f32 alCents2Ratio(s32 cents);
void alSeqpNew(ALSeqPlayer *seqp, ALSeqpConfig *config);
void alSeqpDelete(ALSeqPlayer *seqp);
void alSeqpSetSeq(ALSeqPlayer *seqp, ALSeq *seq);
ALSeq *alSeqpGetSeq(ALSeqPlayer *seqp);
void alSeqpPlay(ALSeqPlayer *seqp);
void alSeqpStop(ALSeqPlayer *seqp);
s32 alSeqpGetState(ALSeqPlayer *seqp);
void alSeqpSetBank(ALSeqPlayer *seqp, ALBank *b);
void alSeqpSetTempo(ALSeqPlayer *seqp, s32 tempo);
s32 alSeqpGetTempo(ALSeqPlayer *seqp);
s16 alSeqpGetVol(ALSeqPlayer *seqp);
void alSeqpSetVol(ALSeqPlayer *seqp, s16 vol);
void alSeqpLoop(ALSeqPlayer *seqp, ALSeqMarker *start, ALSeqMarker *end, s32 count);
void alSeqpSetChlProgram(ALSeqPlayer *seqp, u8 chan, u8 prog);
s32 alSeqpGetChlProgram(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlFXMix(ALSeqPlayer *seqp, u8 chan, u8 fxmix);
u8 alSeqpGetChlFXMix(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlVol(ALSeqPlayer *seqp, u8 chan, u8 vol);
u8 alSeqpGetChlVol(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlPan(ALSeqPlayer *seqp, u8 chan, ALPan pan);
ALPan alSeqpGetChlPan(ALSeqPlayer *seqp, u8 chan);
void alSeqpSetChlPriority(ALSeqPlayer *seqp, u8 chan, u8 priority);
u8 alSeqpGetChlPriority(ALSeqPlayer *seqp, u8 chan);
void alSeqpSendMidi(ALSeqPlayer *seqp, s32 ticks, u8 status, u8 byte1, u8 byte2);
void alCSPNew(ALCSPlayer *seqp, ALSeqpConfig *config);
void alCSPDelete(ALCSPlayer *seqp);
void alCSPSetSeq(ALCSPlayer *seqp, ALCSeq *seq);
ALCSeq *alCSPGetSeq(ALCSPlayer *seqp);
void alCSPPlay(ALCSPlayer *seqp);
void alCSPStop(ALCSPlayer *seqp);
s32 alCSPGetState(ALCSPlayer *seqp);
void alCSPSetBank(ALCSPlayer *seqp, ALBank *b);
void alCSPSetTempo(ALCSPlayer *seqp, s32 tempo);
s32 alCSPGetTempo(ALCSPlayer *seqp);
s16 alCSPGetVol(ALCSPlayer *seqp);
void alCSPSetVol(ALCSPlayer *seqp, s16 vol);
void alCSPSetChlProgram(ALCSPlayer *seqp, u8 chan, u8 prog);
s32 alCSPGetChlProgram(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlFXMix(ALCSPlayer *seqp, u8 chan, u8 fxmix);
u8 alCSPGetChlFXMix(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlPan(ALCSPlayer *seqp, u8 chan, ALPan pan);
ALPan alCSPGetChlPan(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlVol(ALCSPlayer *seqp, u8 chan, u8 vol);
u8 alCSPGetChlVol(ALCSPlayer *seqp, u8 chan);
void alCSPSetChlPriority(ALCSPlayer *seqp, u8 chan, u8 priority);
u8 alCSPGetChlPriority(ALCSPlayer *seqp, u8 chan);
void alCSPSendMidi(ALCSPlayer *seqp, s32 ticks, u8 status,
                       u8 byte1, u8 byte2);
typedef struct {
    s32 maxSounds;
    s32 maxEvents;
    ALHeap *heap;
} ALSndpConfig;
typedef struct {
    ALPlayer node;
    ALEventQueue evtq;
    ALEvent nextEvent;
    ALSynth *drvr;
    s32 target;
    void *sndState;
    s32 maxSounds;
    ALMicroTime frameTime;
    ALMicroTime nextDelta;
    ALMicroTime curTime;
} ALSndPlayer;
typedef s16 ALSndId;
void alSndpNew(ALSndPlayer *sndp, ALSndpConfig *c);
void alSndpDelete(ALSndPlayer *sndp);
ALSndId alSndpAllocate(ALSndPlayer *sndp, ALSound *sound);
void alSndpDeallocate(ALSndPlayer *sndp, ALSndId id);
void alSndpSetSound(ALSndPlayer *sndp, ALSndId id);
ALSndId alSndpGetSound(ALSndPlayer *sndp);
void alSndpPlay(ALSndPlayer *sndp);
void alSndpPlayAt(ALSndPlayer *sndp, ALMicroTime delta);
void alSndpStop(ALSndPlayer *sndp);
void alSndpSetVol(ALSndPlayer *sndp, s16 vol);
void alSndpSetPitch(ALSndPlayer *sndp, f32 pitch);
void alSndpSetPan(ALSndPlayer *sndp, ALPan pan);
void alSndpSetPriority(ALSndPlayer *sndp, ALSndId id, u8 priority);
void alSndpSetFXMix(ALSndPlayer *sndp, u8 mix);
s32 alSndpGetState(ALSndPlayer *sndp);
typedef struct {
 unsigned char *base;
 int fmt, siz;
 int xsize, ysize;
 int lsize;
 int addr;
 int w, h;
 int s, t;
} Image;
typedef struct {
 float col[3];
 float pos[3];
 float a1, a2;
} PositionalLight;
extern int guLoadTextureBlockMipMap(Gfx **glist, unsigned char *tbuf, Image *im,
  unsigned char startTile, unsigned char pal, unsigned char cms,
  unsigned char cmt, unsigned char masks, unsigned char maskt,
  unsigned char shifts, unsigned char shiftt, unsigned char cfs,
  unsigned char cft);
extern int guGetDPLoadTextureTileSz (int ult, int lrt);
extern void guDPLoadTextureTile (Gfx *glistp, void *timg,
   int texl_fmt, int texl_size,
   int img_width, int img_height,
   int uls, int ult, int lrs, int lrt,
   int palette,
   int cms, int cmt,
   int masks, int maskt,
   int shifts, int shiftt);
extern void guMtxIdent(Mtx *m);
extern void guMtxIdentF(float mf[4][4]);
extern void guOrtho(Mtx *m, float l, float r, float b, float t,
      float n, float f, float scale);
extern void guOrthoF(float mf[4][4], float l, float r, float b, float t,
       float n, float f, float scale);
extern void guFrustum(Mtx *m, float l, float r, float b, float t,
        float n, float f, float scale);
extern void guFrustumF(float mf[4][4], float l, float r, float b, float t,
         float n, float f, float scale);
extern void guPerspective(Mtx *m, u16 *perspNorm, float fovy,
     float aspect, float near, float far, float scale);
extern void guPerspectiveF(float mf[4][4], u16 *perspNorm, float fovy,
      float aspect, float near, float far, float scale);
extern void guLookAt(Mtx *m,
   float xEye, float yEye, float zEye,
   float xAt, float yAt, float zAt,
   float xUp, float yUp, float zUp);
extern void guLookAtF(float mf[4][4], float xEye, float yEye, float zEye,
        float xAt, float yAt, float zAt,
        float xUp, float yUp, float zUp);
extern void guLookAtReflect(Mtx *m, LookAt *l,
   float xEye, float yEye, float zEye,
   float xAt, float yAt, float zAt,
   float xUp, float yUp, float zUp);
extern void guLookAtReflectF(float mf[4][4], LookAt *l,
        float xEye, float yEye, float zEye,
        float xAt, float yAt, float zAt,
        float xUp, float yUp, float zUp);
extern void guLookAtHilite(Mtx *m, LookAt *l, Hilite *h,
                float xEye, float yEye, float zEye,
                float xAt, float yAt, float zAt,
                float xUp, float yUp, float zUp,
                float xl1, float yl1, float zl1,
                float xl2, float yl2, float zl2,
  int twidth, int theight);
extern void guLookAtHiliteF(float mf[4][4], LookAt *l, Hilite *h,
  float xEye, float yEye, float zEye,
  float xAt, float yAt, float zAt,
  float xUp, float yUp, float zUp,
  float xl1, float yl1, float zl1,
  float xl2, float yl2, float zl2,
  int twidth, int theight);
extern void guLookAtStereo(Mtx *m,
   float xEye, float yEye, float zEye,
   float xAt, float yAt, float zAt,
   float xUp, float yUp, float zUp,
   float eyedist);
extern void guLookAtStereoF(float mf[4][4],
         float xEye, float yEye, float zEye,
         float xAt, float yAt, float zAt,
         float xUp, float yUp, float zUp,
   float eyedist);
extern void guRotate(Mtx *m, float a, float x, float y, float z);
extern void guRotateF(float mf[4][4], float a, float x, float y, float z);
extern void guRotateRPY(Mtx *m, float r, float p, float y);
extern void guRotateRPYF(float mf[4][4], float r, float p, float h);
extern void guAlign(Mtx *m, float a, float x, float y, float z);
extern void guAlignF(float mf[4][4], float a, float x, float y, float z);
extern void guScale(Mtx *m, float x, float y, float z);
extern void guScaleF(float mf[4][4], float x, float y, float z);
extern void guTranslate(Mtx *m, float x, float y, float z);
extern void guTranslateF(float mf[4][4], float x, float y, float z);
extern void guPosition(Mtx *m, float r, float p, float h, float s,
         float x, float y, float z);
extern void guPositionF(float mf[4][4], float r, float p, float h, float s,
   float x, float y, float z);
extern void guMtxF2L(float mf[4][4], Mtx *m);
extern void guMtxL2F(float mf[4][4], Mtx *m);
extern void guMtxCatF(float m[4][4], float n[4][4], float r[4][4]);
extern void guMtxCatL(Mtx *m, Mtx *n, Mtx *res);
extern void guMtxXFMF(float mf[4][4], float x, float y, float z,
        float *ox, float *oy, float *oz);
extern void guMtxXFML(Mtx *m, float x, float y, float z,
        float *ox, float *oy, float *oz);
extern void guNormalize(float *x, float *y, float *z);
void guPosLight(PositionalLight *pl, Light *l,
                float xOb, float yOb, float zOb);
void guPosLightHilite(PositionalLight *pl1, PositionalLight *pl2,
                Light *l1, Light *l2,
                LookAt *l, Hilite *h,
                float xEye, float yEye, float zEye,
                float xOb, float yOb, float zOb,
                float xUp, float yUp, float zUp,
                int twidth, int theight);
extern int guRandom(void);
extern float sinf(float angle);
extern float cosf(float angle);
extern signed short sins (unsigned short angle);
extern signed short coss (unsigned short angle);
extern float sqrtf(float value);
extern void guParseRdpDL(u64 *rdp_dl, u64 nbytes, u8 flags);
extern void guParseString(char *StringPointer, u64 nbytes);
extern void
guBlinkRdpDL(u64 *rdp_dl_in, u64 nbytes_in,
             u64 *rdp_dl_out, u64 *nbytes_out,
             u32 x, u32 y, u32 radius,
             u8 red, u8 green, u8 blue,
             u8 flags);
extern void guParseGbiDL(u64 *gbi_dl, u32 nbytes, u8 flags);
extern void guDumpGbiDL(OSTask *tp,u8 flags);
typedef struct {
    int dataSize;
    int dlType;
    int flags;
    u32 paddr;
} guDLPrintCB;
void guSprite2DInit(uSprite *SpritePointer,
      void *SourceImagePointer,
      void *TlutPointer,
      int Stride,
      int SubImageWidth,
      int SubImageHeight,
      int SourceImageType,
      int SourceImageBitSize,
      int SourceImageOffsetS,
      int SourceImageOffsetT);
typedef struct {
    long type;
    long length;
    long magic;
    char userdata[(((4096)*6)-(3*sizeof(long)))];
} RamRomBuffer;
struct bitmap {
 s16 width;
 s16 width_img;
 s16 s;
 s16 t;
 void *buf;
 s16 actualHeight;
 s16 LUToffset;
};
typedef struct bitmap Bitmap;
struct sprite {
 s16 x,y;
 s16 width, height;
 f32 scalex, scaley;
 s16 expx, expy;
 u16 attr;
 s16 zdepth;
 u8 red;
 u8 green;
 u8 blue;
 u8 alpha;
 s16 startTLUT;
 s16 nTLUT;
 int *LUT;
 s16 istart;
 s16 istep;
 s16 nbitmaps;
 s16 ndisplist;
 s16 bmheight;
 s16 bmHreal;
 u8 bmfmt;
 u8 bmsiz;
 Bitmap *bitmap;
 Gfx *rsp_dl;
 Gfx *rsp_dl_next;
 s16 frac_s,
  frac_t;
};
typedef struct sprite Sprite;
void spSetAttribute (Sprite *sp, s32 attr);
void spClearAttribute (Sprite *sp, s32 attr);
void spX2Move (Sprite *sp, s32 x, s32 y);
void spScale (Sprite *sp, f32 sx, f32 sy);
void spX2SetZ (Sprite *sp, s32 z );
void spColor (Sprite *sp, u8 red, u8 green, u8 blue, u8 alpha);
Gfx *spX2Draw (Sprite *sp);
void spX2Init( Gfx **glistp );
void spX2Scissor( s32 xmin, s32 xmax, s32 ymin, s32 ymax );
void spX2Finish( Gfx **glistp );
extern long long int rspbootTextStart[], rspbootTextEnd[];
extern long long int gspFast3DTextStart[], gspFast3DTextEnd[];
extern long long int gspFast3DDataStart[], gspFast3DDataEnd[];
extern long long int gspFast3D_dramTextStart[], gspFast3D_dramTextEnd[];
extern long long int gspFast3D_dramDataStart[], gspFast3D_dramDataEnd[];
extern long long int gspFast3D_fifoTextStart[], gspFast3D_fifoTextEnd[];
extern long long int gspFast3D_fifoDataStart[], gspFast3D_fifoDataEnd[];
extern long long int gspF3DNoNTextStart[], gspF3DNoNTextEnd[];
extern long long int gspF3DNoNDataStart[], gspF3DNoNDataEnd[];
extern long long int gspF3DNoN_dramTextStart[];
extern long long int gspF3DNoN_dramTextEnd[];
extern long long int gspF3DNoN_dramDataStart[];
extern long long int gspF3DNoN_dramDataEnd[];
extern long long int gspF3DNoN_fifoTextStart[];
extern long long int gspF3DNoN_fifoTextEnd[];
extern long long int gspF3DNoN_fifoDataStart[];
extern long long int gspF3DNoN_fifoDataEnd[];
extern long long int gspLine3DTextStart[], gspLine3DTextEnd[];
extern long long int gspLine3DDataStart[], gspLine3DDataEnd[];
extern long long int gspLine3D_dramTextStart[], gspLine3D_dramTextEnd[];
extern long long int gspLine3D_dramDataStart[], gspLine3D_dramDataEnd[];
extern long long int gspLine3D_fifoTextStart[], gspLine3D_fifoTextEnd[];
extern long long int gspLine3D_fifoDataStart[], gspLine3D_fifoDataEnd[];
extern long long int gspSprite2DTextStart[], gspSprite2DTextEnd[];
extern long long int gspSprite2DDataStart[], gspSprite2DDataEnd[];
extern long long int gspSprite2D_dramTextStart[], gspSprite2D_dramTextEnd[];
extern long long int gspSprite2D_dramDataStart[], gspSprite2D_dramDataEnd[];
extern long long int gspSprite2D_fifoTextStart[], gspSprite2D_fifoTextEnd[];
extern long long int gspSprite2D_fifoDataStart[], gspSprite2D_fifoDataEnd[];
extern long long int aspMainTextStart[], aspMainTextEnd[];
extern long long int aspMainDataStart[], aspMainDataEnd[];
extern long long int gspF3DEX_fifoTextStart[], gspF3DEX_fifoTextEnd[];
extern long long int gspF3DEX_fifoDataStart[], gspF3DEX_fifoDataEnd[];
extern long long int gspF3DEX_NoN_fifoTextStart[], gspF3DEX_NoN_fifoTextEnd[];
extern long long int gspF3DEX_NoN_fifoDataStart[], gspF3DEX_NoN_fifoDataEnd[];
extern long long int gspF3DLX_fifoTextStart[], gspF3DLX_fifoTextEnd[];
extern long long int gspF3DLX_fifoDataStart[], gspF3DLX_fifoDataEnd[];
extern long long int gspF3DLX_NoN_fifoTextStart[], gspF3DLX_NoN_fifoTextEnd[];
extern long long int gspF3DLX_NoN_fifoDataStart[], gspF3DLX_NoN_fifoDataEnd[];
extern long long int gspF3DLX_Rej_fifoTextStart[], gspF3DLX_Rej_fifoTextEnd[];
extern long long int gspF3DLX_Rej_fifoDataStart[], gspF3DLX_Rej_fifoDataEnd[];
extern long long int gspF3DLP_Rej_fifoTextStart[], gspF3DLP_Rej_fifoTextEnd[];
extern long long int gspF3DLP_Rej_fifoDataStart[], gspF3DLP_Rej_fifoDataEnd[];
extern long long int gspL3DEX_fifoTextStart[], gspL3DEX_fifoTextEnd[];
extern long long int gspL3DEX_fifoDataStart[], gspL3DEX_fifoDataEnd[];
extern long long int gspF3DEX2_fifoTextStart[], gspF3DEX2_fifoTextEnd[];
extern long long int gspF3DEX2_fifoDataStart[], gspF3DEX2_fifoDataEnd[];
extern long long int gspF3DEX2_NoN_fifoTextStart[],gspF3DEX2_NoN_fifoTextEnd[];
extern long long int gspF3DEX2_NoN_fifoDataStart[],gspF3DEX2_NoN_fifoDataEnd[];
extern long long int gspF3DEX2_Rej_fifoTextStart[],gspF3DEX2_Rej_fifoTextEnd[];
extern long long int gspF3DEX2_Rej_fifoDataStart[],gspF3DEX2_Rej_fifoDataEnd[];
extern long long int gspF3DLX2_Rej_fifoTextStart[],gspF3DLX2_Rej_fifoTextEnd[];
extern long long int gspF3DLX2_Rej_fifoDataStart[],gspF3DLX2_Rej_fifoDataEnd[];
extern long long int gspL3DEX2_fifoTextStart[], gspL3DEX2_fifoTextEnd[];
extern long long int gspL3DEX2_fifoDataStart[], gspL3DEX2_fifoDataEnd[];
extern long long int gspF3DEX2_xbusTextStart[], gspF3DEX2_xbusTextEnd[];
extern long long int gspF3DEX2_xbusDataStart[], gspF3DEX2_xbusDataEnd[];
extern long long int gspF3DEX2_NoN_xbusTextStart[],gspF3DEX2_NoN_xbusTextEnd[];
extern long long int gspF3DEX2_NoN_xbusDataStart[],gspF3DEX2_NoN_xbusDataEnd[];
extern long long int gspF3DEX2_Rej_xbusTextStart[],gspF3DEX2_Rej_xbusTextEnd[];
extern long long int gspF3DEX2_Rej_xbusDataStart[],gspF3DEX2_Rej_xbusDataEnd[];
extern long long int gspF3DLX2_Rej_xbusTextStart[],gspF3DLX2_Rej_xbusTextEnd[];
extern long long int gspF3DLX2_Rej_xbusDataStart[],gspF3DLX2_Rej_xbusDataEnd[];
extern long long int gspL3DEX2_xbusTextStart[], gspL3DEX2_xbusTextEnd[];
extern long long int gspL3DEX2_xbusDataStart[], gspL3DEX2_xbusDataEnd[];
typedef void (*OSErrorHandler)(s16, s16, ...);
OSErrorHandler osSetErrorHandler(OSErrorHandler);
typedef struct {
    u32 magic;
    u32 len;
    u32 *base;
    s32 startCount;
    s32 writeOffset;
} OSLog;
typedef struct {
    u32 magic;
    u32 timeStamp;
    u16 argCount;
    u16 eventID;
} OSLogItem;
typedef struct {
    u32 magic;
    u32 version;
} OSLogFileHdr;
void osCreateLog(OSLog *log, u32 *base, s32 len);
void osLogEvent(OSLog *log, s16 code, s16 numArgs, ...);
void osFlushLog(OSLog *log);
u32 osLogFloat(f32);
extern void osDelay(int count);
void *memcpy(void *, const void *, size_t);
       
       
       
typedef struct {
    s32 x;
    s32 y;
    s32 z;
} Vec3i;
typedef struct {
    s16 x;
    s16 y;
    s16 z;
} Vec3s;
typedef struct {
               s16 values[0xA];
               s32 position[3];
               s16 prev_position[0xA];
               s32 interpolated[3];
               s16 *animation_data;
               s16 *frame_data;
               u16 flags;
               u16 counter;
} func_8005E800_5F400_arg;
typedef struct {
    s16 m[9];
} Mat3x3;
typedef struct {
    s16 m[3][3];
    Vec3i translation;
} Transform3D;
void createYRotationMatrix(Transform3D *, u16 angle);
void createZRotationMatrix(Transform3D *, u16 angle);
void createXRotationMatrix(s16 matrix[3][3], u16 angle);
void func_8006BDBC_6C9BC(func_8005E800_5F400_arg *, void *, void *);
void func_8006B084_6BC84(void *, void *, void *);
void createCombinedRotationMatrix(void *, u16, u16);
void func_8006BEDC_6CADC(void *, s32, s32, s32, s32, s32, s32);
void func_8006BFB8_6CBB8(void *, void *);
void createRotationMatrixYX(Transform3D *matrix, u16 angleY, u16 angleX);
void createRotationMatrixXZ(Transform3D *matrix, u16 angleX, u16 angleZ);
void createRotationMatrixYZ(s16 *matrix, u16 angleY, u16 angleZ);
void matrixToEulerAngles(s32 *, s32 *, f32 *, f32 *, f32 *, f32 *, f32 *, f32 *);
void transformVector(s16 *, s16 *, void *);
void transformVector2(void *matrix, void *vector, s32 *output);
void transformVector3(s32 *, Transform3D *, s32 *);
void rotateVectorY(void *, s16, void *);
void scaleMatrix(Transform3D *matrix, s16 scaleX, s16 scaleY, s16 scaleZ);
s16 func_8006D21C_6DE1C(s32 arg0, s32 arg1, s32 arg2, s32 arg3);
s32 atan2Fixed(s32, s32);
s32 approximateSin(s16 inputAngle);
s32 approximateCos(s16 inputAngle);
s32 isqrt64(s64 val);
s32 distance_2d(s32 x, s32 y);
s32 distance_3d(s32 x, s32 y, s32 z);
s32 approximate_sqrt(u32 input);
void computeLookAtMatrix(void *arg0, void *arg1, void *arg2);
extern void transformVectorRelative(void *arg0, void *arg1, void *arg2);
typedef struct {
    u8 padding[0x8];
    u32 countOffset;
} func_8006097C_6157C_arg_item;
typedef struct {
    func_8006097C_6157C_arg_item data[0];
} func_8006097C_6157C_arg;
s32 func_8006097C_6157C(func_8006097C_6157C_arg *, s32);
void func_8005DE98_5EA98(void *animData, s32 tableIndex, s32 boneIndex, func_8005E800_5F400_arg *state);
void func_8005E800_5F400(func_8005E800_5F400_arg *entity, u16 param_2);
s32 func_8005ECB8_5F8B8(void *arg0, s32 arg1, s32 arg2, void *arg3);
s32 func_8005EFC4_5FBC4(void *arg0, s32 arg1, s32 arg2, void *arg3);
       
       
       
typedef struct {
               u32 data_offset;
               u16 index_offset;
               u16 field1;
               u16 field2;
    u8 padding[6];
} TableEntry_19E80;
typedef struct {
               u8 header[4];
               u32 index_table_offset;
               TableEntry_19E80 entries[1];
} DataTable_19E80;
typedef struct {
               u8 *data_ptr;
               TableEntry_19E80 *index_ptr;
               u16 field1;
               u16 field2;
} OutputStruct_19E80;
void getTableEntryByU16Index(DataTable_19E80 *, u16, OutputStruct_19E80 *);
void getTableEntryByIndex(DataTable_19E80 *table, u32 entry_index, u8 sub_index, OutputStruct_19E80 *output);
       
void func_80035FE0_36BE0(s32 *outX, s32 *outY, Vec3i *pos);
typedef struct {
    s32 unk0;
              Vec3i position;
} DisplayListObject_unk10;
typedef struct {
              u32 flags;
              Gfx *opaqueDisplayList;
              Gfx *transparentDisplayList;
              Gfx *overlayDisplayList;
} DisplayLists;
typedef struct {
    DisplayLists unk0;
    DisplayListObject_unk10 unk10;
    DisplayLists *unk20;
    void *unk24;
    void *unk28;
    void* unk2C;
    Mtx *unk30;
    u8 unk34;
    u8 unk35;
    u8 unk36;
    u8 unk37;
    u8 unk38;
    u8 unk39;
    u8 unk3A;
    u8 unk3B;
} DisplayListObject;
void enqueueDisplayListObject(s32 arg0, DisplayListObject *arg1);
typedef struct {
    u8 padding[0x20];
    s32 *unk20;
    u8 padding3[0x9];
    s32 unk30;
    u8 padding2[0x3];
    s8 unk37;
} enqueueMultiPartDisplayList_arg1;
void func_80064808_65408(s32 arg0, enqueueMultiPartDisplayList_arg1 *arg1, s32 arg2);
void enqueueMultiPartDisplayList(s32 arg0, enqueueMultiPartDisplayList_arg1 *arg1, s32 arg2);
typedef struct {
    u16 *dataStart;
    u16 *section1Data;
    u16 *section2Data;
    void *section3Data;
    u16 finalValue;
} GameDataLayout;
void parseGameDataLayout(GameDataLayout *gameData);
void initializeOverlaySystem(void);
typedef struct loadAssetMetadata_arg {
    struct loadAssetMetadata_arg *unk0;
    s32 unk4;
    s32 unk8;
    s32 unkC;
               u8 *data_ptr;
               TableEntry_19E80 *index_ptr;
    s8 unk18;
    s8 unk19;
    u8 unk1A;
} loadAssetMetadata_arg;
void loadAssetMetadata(loadAssetMetadata_arg *, void *, s32);
void enqueueDisplayListWithFrustumCull(s32, DisplayListObject *);
void buildDisplayListSegment(DisplayListObject *);
void func_800638C0_644C0(DisplayListObject *);
void func_80063580_64180(DisplayListObject *);
void func_80063534_64134(DisplayListObject *);
void func_800634E8_640E8(DisplayListObject *arg0);
void func_800630F0_63CF0(s32, void *);
void func_8006300C_63C0C(DisplayListObject *arg0);
void func_80063058_63C58(DisplayListObject *arg0);
void func_800630A4_63CA4(DisplayListObject *arg0);
typedef struct {
    s32 unk0;
    Vec3i unk4;
    u8 padding[0xC];
    s32 unk1C;
    u8 padding2[0x4];
    s32 unk24;
    s32 unk28;
    s32 unk2C;
    s16 unk30;
    s16 unk36;
} func_80066444_67044_arg1;
void func_80066444_67044(s32 arg0, func_80066444_67044_arg1 *arg1);
void func_800677C0_683C0(s32 arg0, loadAssetMetadata_arg *arg1);
void func_800670A4_67CA4(u16 arg0, func_80066444_67044_arg1 *arg1);
typedef struct {
    u8 padding0[4];
    s32 unk4;
    s32 unk8;
    s32 unkC;
               u8 *data_ptr;
               TableEntry_19E80 *index_ptr;
    s8 unk18;
    u8 unk19;
    u8 unk1A;
} loadAssetMetadataByIndex_arg;
void loadAssetMetadataByIndex(
    loadAssetMetadataByIndex_arg *arg0,
    DataTable_19E80 *table,
    s32 entry_index,
    s32 sub_index
);
void func_80067EDC_68ADC(s32, loadAssetMetadata_arg *);
void func_8006395C_6455C(DisplayListObject *arg0);
void func_800639F8_645F8(s32 arg0, DisplayListObject *arg1);
void func_8006417C_64D7C(s32 arg0, DisplayListObject *arg1);
void func_80065DA8_669A8(s32 arg0, DisplayListObject *arg1);
u16 func_800625A4_631A4(void *arg0, void *arg1);
u16 func_80060A3C_6163C(void *arg0, u16 arg1, void *arg2);
void func_80060CDC_618DC(void *arg0, u16 arg1, void *arg2, s32 arg3, s32 *arg4);
s32 func_80061A64_62664(void *arg0, u16 arg1, void *arg2);
s32 func_80061D6C_6296C(void *arg0, u16 arg1, void *arg2, s32 arg3);
s32 func_80062274_62E74(void *arg0, u16 arg1);
void func_80062918_63518(void *arg0, u16 arg1, void *arg2, void *arg3, void *arg4);
void func_800650B4_65CB4(u16 arg0, DisplayListObject *arg1);
u16 func_80062B1C_6371C(void *arg0, u16 arg1, void *arg2, void *arg3);
typedef struct {
    s16 unk0;
    u8 _pad[0x8];
    s16 unkA;
    u8 _pad2[0x18];
} func_80062C98_63898_arg;
s16 func_80062254_62E54(GameDataLayout *gameData, u16 index);
typedef struct {
    s32 unk0;
    s32 unk4;
    s32 unk8;
    s32 unkC;
} ScrollingTextureDisplayLists;
typedef struct {
    Transform3D unk0;
    ScrollingTextureDisplayLists *unk20;
    void *unk24;
    void *unk28;
    s32 unk2C;
    s32 unk30;
    u8 padding2[0x8];
    void *unk3C;
    s32 unk40;
    s16 unk44;
    s16 unk46;
    s16 unk48;
    s16 unk4A;
    s16 unk4C;
    s16 unk4E;
    s16 unk50;
    s16 unk52;
    s16 unk54;
    s16 unk56;
    s16 unk58;
} ScrollingTextureState;
void enqueueScrollingTextureRender(u16 renderLayer, DisplayListObject *displayListObj);
typedef struct {
               u8 _pad0[0x20];
               ScrollingTextureDisplayLists *unk20;
               void *unk24;
               void *unk28;
               s32 unk2C;
               s32 unk30;
               u8 _pad34[0x3B - 0x34];
               u8 unk3B;
               void *unk3C;
               s32 unk40;
               union {
        u16 unk44;
        u8 unk44_bytes[2];
    } unk44_union;
               union {
        u16 unk46;
        u8 unk46_bytes[2];
    } unk46_union;
               u16 unk48;
               u16 unk4A;
               s16 unk4C;
               s16 unk4E;
               s16 unk50;
               s16 unk52;
               u8 unk54[0x20];
               u16 unk74;
               s16 unk76;
               union {
        s32 unk78;
        s16 unk78_shorts[2];
    } unk78_union;
               s32 unk7C;
               s32 unk80;
               s8 unk84;
} func_800B5500_Task;
void enqueueTiledTextureRender(s32 arg0, func_800B5500_Task *arg1);
typedef struct {
               DataTable_19E80 *table;
    u8 _pad[0xC];
               u16 index;
} TableLookupContext;
typedef struct {
               u16 unk0;
               s16 command;
               u16 spriteFrame;
               u16 duration;
} AnimationEntry;
typedef struct {
               void *entries;
               u16 frameCount;
               u16 initialDelay;
} AnimSetEntry;
typedef struct {
               u32 unk0;
               u16 unk4;
               u16 unk6;
} AnimFrameEntry;
typedef struct {
               u8 pad0[0x4];
               s16 frameCount;
} AnimationHeader;
typedef struct {
               u8 pad0[0x8];
               AnimationHeader *header;
               AnimationEntry *entries;
               u16 unk10;
               s16 currentSpriteFrame;
               s16 frameIndex;
               s16 frameTimer;
} AnimationState;
typedef struct {
               void *spriteData;
               s16 assetIndex;
               u8 flags;
               u8 unk7;
               AnimSetEntry *unk8;
               AnimFrameEntry *unkC;
               s16 unk10;
               s16 unk12;
               s16 unk14;
               s16 unk16;
               u8 pad18[0x10];
               void *unk28;
               u8 pad2C[0x20];
} SpriteAssetState;
typedef struct {
               s8 unk0;
               s8 unk1;
               u8 pad2[2];
               u16 unk4;
               u8 pad6[2];
} SpriteEntry;
typedef struct {
               u8 pad0[0x0C];
               SpriteEntry *unkC;
               u8 pad10[4];
               s16 unk14;
               u8 pad16[2];
               void *unk18;
               s32 unk1C;
               s32 unk20;
               s32 unk24;
               DataTable_19E80 *unk28;
               u16 unk2C;
               u8 unk2E;
               u8 unk2F;
               u8 pad30[0x10];
               s32 unk40;
               s32 unk44;
               u16 unk48;
               u16 unk4A;
} SpriteState;
s32 loadSpriteAsset(SpriteAssetState *arg0, s16 arg1);
void *loadSpriteAssetData(s16 index);
void releaseNodeMemoryRef(void **ptr);
void setSpriteAnimation(void *arg0, s32 arg1, s32 arg2, s32 arg3);
s32 updateSpriteAnimation(void *arg0, s32 arg1);
void renderOpaqueSprite(void *arg0, s32 arg1, s32 arg2, s32 arg3, s32 arg4, s32 arg5, s32 arg6, s16 arg7, u8 arg8);
s32 getTableEntryValue(TableLookupContext *ctx);
typedef struct MemoryAllocatorNode {
               struct MemoryAllocatorNode *prev;
               struct MemoryAllocatorNode *next;
               s32 ownerID;
               s32 refCount;
               s32 size;
    s32 unk_14;
               s32 cleanupTimestamp;
    s32 unk1C;
} MemoryAllocatorNode;
extern MemoryAllocatorNode *gMemoryAllocatorHead;
extern MemoryAllocatorNode gMemoryHeapBase;
void *allocateMemoryNode(s32, u32, u8 *);
void *getNodeSequenceNumber(void *);
void setNodeSequenceNumber(void *, void *);
void markNodeAsLocked(void *);
s32 getNodeOwner(void *);
void *decrementNodeRefCount(void *node);
void unlockNodeWithInterruptDisable(s32 *);
void initializeMemoryAllocatorRegion(void);
void cleanupUnusedNodes(void);
typedef struct {
    void *displayListStart;
    void *displayListEnd;
    void *vertexDataStart;
    void *vertexDataEnd;
    u16 romBSize;
    u16 padding;
    void *unk14;
} Asset;
typedef struct {
               char name[8];
               void *displayListStart;
               void *displayListEnd;
               void *vertexDataStart;
               void *vertexDataEnd;
               s32 size;
               struct {
        u8 padding[0x10];
    } *unk1C;
               s8 numAssets;
               s8 assetGroupIndex;
    s16 unk22;
               void *asset3Start;
               void *asset3End;
               u32 asset3Size;
               s8 anotherAssetIndex;
               u8 unk31;
               void *soundSequenceDataStart;
               void *soundSequenceDataEnd;
               s32 soundSequenceDataSize;
               void *initCallback;
               Asset *Assets;
               s8 count;
} AssetGroup;
typedef struct {
    u8 padding[0x13];
    s8 animationCount;
} ModelAnimationData;
typedef struct {
    u8 padding[0x89];
    s8 unk89;
    s16 animFrameCount;
    u8 padding3[0x8];
    s8 animationIndex;
    u8 padding2[0x4];
    ModelAnimationData *unk9C;
} func_80001688_2288_arg;
typedef struct {
    s32 unk0;
    u8 padding[0x9];
    s16 unkE;
    struct {
        u8 padding[0x16];
        u16 unk16;
    } *unk10;
    u8 unk14[0x4];
               s16 matrix18[3][3];
    u8 padding2[0x3C - 0x2A];
    s8 isDestroyed;
    s8 actionMode;
    s8 unk3E;
    s8 displayEnabled;
    u8 padding3[0x88 - 0x40];
    s8 unk88;
    u8 padding4[0xF0 - 0x89];
    s16 unkF0[3][3];
    u8 _padUnk102[2];
    s32 unk104;
    s32 unk108;
    s32 unk10C;
} func_80002B50_3750_arg;
typedef struct {
    s32 unk0;
    s32 unk4;
    s32 unk8;
    s32 unkC;
    u8 padding[0x14];
    void *unk24;
    void *unk28;
    s32 unk2C;
    u8 padding2[0x3B0];
    s32 graphicsData;
    void *unk3E4;
    void *unk3E8;
    void *unk3EC;
    u8 padding3[0x2D];
    void *unk420;
    void *unk424;
} SceneModel_unk0;
typedef struct {
    u8 padding[0x24];
    void *unk24;
    void *unk28;
} SceneModel_unk98;
typedef struct {
    SceneModel_unk0 *unk0;
    func_8005E800_5F400_arg *unk4;
    void *unk8;
              s16 index;
    u8 paddingA[0x06];
    s16 unk14;
    s16 unk16;
    s32 unk18;
    u8 padding[0x10];
    s32 unk2C;
    u8 padding1B[0x8];
    s16 unk38;
    s16 unk3A;
    s8 isDestroyed;
    s8 actionMode;
    s8 unk3E;
    s8 displayEnabled;
    s32 unk40;
    s32 unk44;
    s32 unk48;
    s16 unk4C;
    s8 unk4E;
    s8 unk4F;
    u8 padding2[0x38];
    s8 unk88;
    s8 unk89;
    s16 animFrameCount;
    s16 unk8C;
    s16 unk8E;
    s32 unk90;
    s8 animationIndex;
    s8 unk95;
    s8 alpha;
    s8 shadowEnabled;
    SceneModel_unk98 *unk98;
    ModelAnimationData *unk9C;
    u8 unkA0[4];
    SpriteAssetState unkA4;
    s16 unkF0[3][3];
    u8 unkF4[0x8];
    s32 unk10C;
    s32 partDisplayFlags;
    void *unk114;
    void *unk118;
    void *unk11C;
    void *unk120;
    u8 padding4[0x34];
    s32 height;
    s8 renderEnabled;
} SceneModel;
void *createSceneModelEx(s32 assetGroupIndex, void *allocation, s8 assetPairIndex, s8 param4, s8 param5, s16 assetIndex);
void *loadAssetDataByMode(s16 groupIndex, s16 entityIndex, s16 mode);
void *loadAssetGroupSoundData(SceneModel *);
void *loadAssetGroupDisplayList(SceneModel *);
void *loadAssetGroupVertexData(SceneModel *);
void *createSceneModel(s32 assetGroupIndex, void *allocation);
void setModelAnimation(SceneModel *model, s16 animationIndex);
void updateModelGeometry(SceneModel *);
void setItemDisplayEnabled(SceneModel *arg0, s8 arg1);
void setItemFlags(SceneModel *arg0, s8 arg1);
void setModelPendingDestroy(SceneModel *arg0);
void clearModelPendingDestroy(SceneModel *arg0);
s8 getAnimationIndex(SceneModel *arg0);
void setModelHeight(SceneModel *arg0, s32 height);
typedef struct {
    u8 transformationMatrix[0x20];
    void *unk20;
    void *asset1;
    void *asset2;
    void *asset3;
    u8 padding2[0xC];
} AssetSlot;
typedef struct {
    AssetSlot *unk00;
    AssetSlot *unk04;
    AssetSlot *unk08;
    s16 unk0C;
    s16 unk0E;
    void *unk10;
    s16 unk14;
    s16 unk16;
    u8 transformationMatrix[0x20];
    s16 unk38;
    s16 unk3A;
    u8 isDestroyed;
    u8 actionMode;
    u8 unk3E;
    u8 displayEnabled;
    u32 unk40;
    s32 unk44;
    u32 unk48;
    s16 unk4C;
    u8 unk4E;
    u8 unk4F;
    u8 padding3[0x38];
    u8 unk88;
    u8 unk89;
    u8 padding4[4];
    s16 unk8E;
    u8 padding5[4];
    s8 animationIndex;
    u8 unk95;
    u8 alpha;
    u8 shadowEnabled;
    AssetSlot *unk98;
    void *unk9C;
    void *unkA0;
    SpriteAssetState unkA4;
    u8 asset2TransformationMatrix[0x20];
    u32 partDisplayFlags;
    void *unk114;
    void *unk118;
    void *soundData;
    void *unk120;
    void *unk124;
    u8 padding6[0xC];
    void *unk134;
    s16 unk138;
    u8 unk13A;
    u8 unk13B;
    u8 padding7[0x18];
    s16 unk154;
    s16 unk156;
    u32 height;
    u8 renderEnabled;
} GameEntity;
typedef struct {
    Transform3D unk0;
    union {
        SceneModel *unk20;
        s32 unk20_s32;
        s16 unk20_s16;
    } unk20_u;
} applyTransformToModel_arg1;
void applyTransformToModel(SceneModel *arg0, Transform3D *arg1);
void initializeGameEntity(void *, s32, void *, s8, s8, s8, s16);
SceneModel *destroySceneModel(SceneModel *arg0);
void *cleanupSceneModel(SceneModel *arg0);
s32 clearModelRotation(SceneModel *);
void setModelDisplayEnabled(SceneModel *arg0, s8 arg1);
void setModelVisibility(SceneModel *, s8);
s32 setModelRotation(SceneModel *, s16);
void setAnimationIndex(SceneModel *arg0, s8 arg1);
s8 getModelAnimationCount(SceneModel *arg0);
void disableEntityRendering(GameEntity *arg0);
void enableEntityRendering(SceneModel *arg0);
void enableModelShadow(SceneModel *arg0);
void disableModelShadow(SceneModel *arg0);
void setModelAnimationLooped(SceneModel *model, s16 animIndex, s16 transitionAnimIndex, s8 loopCount);
void setModelAnimationQueued(SceneModel *arg0, s16 arg1, s16 arg2, s8 arg3, s16 arg4);
void setModelAnimationEx(SceneModel *arg0, s16 arg1, s16 arg2, s8 arg3, short arg4, s8 arg5);
void setModelActionMode(SceneModel *model, s8 actionMode);
void setModelPartDisplayFlag(SceneModel *model, s32 partIndex);
void clearModelPartDisplayFlag(SceneModel *model, s32 partIndex);
s32 getWalkAnimationId(s16);
s32 getRunAnimationId(s16);
u8 getModelAlpha(SceneModel *arg0);
void setModelAlpha(SceneModel *arg0, u8 arg1);
void enqueueModelDisplayList(func_80002B50_3750_arg *arg0, DisplayListObject *arg1);
s32 isAssetGroupEmpty(s16);
       
typedef struct {
    u8 unk148;
    u8 unk149;
    u8 unk14A;
    u8 unk14B;
    u8 unk14C;
    u8 unk14D;
    u8 unk14E;
    u8 unk14F;
    u8 unk150;
    u8 unk151;
    u8 unk152;
    u8 padding[0x5];
} Node_70B00_ColorData;
typedef struct PoolEntry {
    struct PoolEntry *next;
    void *unk4;
    void *unk8;
    u8 _padC[3];
    u8 unkF;
} PoolEntry;
typedef struct Node_70B00 {
               union {
        struct Node_70B00 *next;
        u16 callback_selector;
    } unk0;
               struct Node_70B00 *prev;
               union {
        struct Node_70B00 *list2_next;
        u16 callback_selector;
    } unk8;
               struct Node_70B00 *list2_prev;
               struct Node_70B00 *list3_next;
    s8 unk14;
    s8 unk15;
               u16 slot_index;
               PoolEntry pool[7];
               void *unk88;
    u8 padding2[0x10];
               s32 unk9C;
               s16 unkA0;
               s16 unkA2;
               s16 unkA4;
               s16 unkA6;
               s16 unkA8;
               s16 unkAA;
               s16 unkAC;
               s16 unkAE;
               s16 unkB0;
               s16 unkB2;
               s16 unkB4;
               s16 unkB6;
    u8 padding2b[0x4];
               u8 unkBC;
    u8 unkBD;
    u8 unkBE;
    u8 unkBF;
    u8 unkC0;
    u8 unkC1;
    u8 padding8[0x6];
    s16 unkC8;
    s16 unkCA;
               s16 unkCC;
               s16 unkCE;
               s16 unkD0;
               s16 unkD2;
               s16 unkD4;
               s16 unkD6;
               u16 perspNorm;
               u16 id;
               Mtx perspectiveMatrix;
    u8 padding4[0x20];
    u16 unk140;
    u8 padding140[6];
    Node_70B00_ColorData unk148[1];
    u8 padding158[0x70];
    s16 unk1C8;
    s16 unk1CA;
    u8 unk1CC;
    u8 unk1CD;
    u8 unk1CE;
    u8 padding1CF;
    f32 unk1D0;
    u8 padding5[0x2];
} Node_70B00;
extern Node_70B00 D_800A3370_A3F70;
void func_8006FDA0_709A0(Node_70B00 *arg0, u8 arg1, u8 arg2);
void func_8006FDC8_709C8(u16 arg0, u8 arg1, u8 arg2);
void debugEnqueueCallback(u16 index, u8 arg1, void *arg2, void *arg3);
void *arenaAlloc16(s32 size);
void *advanceLinearAlloc(s32 size);
void func_8006E02C_6EC2C(void);
void func_8006E000_6EC00(s32 arg0);
void func_8006FE28_70A28(Node_70B00 *arg0, u8 arg1, u8 arg2, u8 arg3);
void func_8006FE48_70A48(u16 arg0, s16 arg1, s16 arg2, u8 arg3, u8 arg4, u8 arg5);
void func_8006F9BC_705BC(Node_70B00 *arg0, f32 arg1, f32 arg2);
void func_8006E054_6EC54(u16);
void func_8006DC40_6E840(void);
void func_8006FEF8_70AF8(Node_70B00 *, u16);
void func_8006FD3C_7093C(u16, void *);
void func_8006FAA4_706A4(Node_70B00 *, Node_70B00 *, s32, s32, s32);
void func_8006FA0C_7060C(Node_70B00 *, f32, f32, f32, f32);
void setModelCameraTransform(void *, s16, s16, s16, s16, s16, s16);
void unlinkNode(Node_70B00 *player);
void n_alSeqpDelete(Node_70B00 *arg0);
s32 func_8006FE10_70A10(Node_70B00 *);
s32 isObjectCulled(Vec3i *arg0);
typedef struct {
    u8 padding[0xB8];
    s8 unkB8;
} func_8006FEBC_70ABC_arg;
typedef struct {
    u8 padding[0xB8];
    s8 unkB8;
    s8 unkB9;
    s8 unkBA;
    s8 unkBB;
} func_8006FE94_70A94_arg;
void func_8006FEBC_70ABC(func_8006FEBC_70ABC_arg *arg0);
void func_8006FED8_70AD8(void *arg0);
void func_8006FE94_70A94(func_8006FE94_70A94_arg *arg0, s8 arg1, s8 arg2, s8 arg3);
typedef struct {
              u8 r;
              u8 g;
              u8 b;
              u8 pad;
              s8 r2;
              s8 g2;
              s8 b2;
              u8 pad2;
} ColorData;
void func_8006FC70_70870(u16 searchId, u16 colorCount, ColorData *srcColors, ColorData *finalColor);
       
typedef struct {
    s32 unk0;
    s32 unk4;
    s32 unk8;
} JointPosition;
typedef struct {
    loadAssetMetadata_arg asset;
    u8 padding[0x24];
} GameStateUnk44_Item;
typedef struct {
    u8 data[0x180];
} GameStateUnk44Unk2C0;
typedef struct {
    u8 padding[0x2C0];
    GameStateUnk44Unk2C0 unk2C0[8];
    u8 padding2[0x100];
    GameStateUnk44_Item unkFC0[3];
    GameStateUnk44_Item unk1080[3];
    u8 padding3[0x1FF];
    s32 unk1340;
    u8 padding4[0x3C];
    s32 unk1380;
} GameStateUnk44;
typedef struct {
    s32 unk0;
    s32 unk4;
} GameStateUnk28;
typedef struct {
    void *unk0;
    void *unk4;
    void *unk8;
    void *unkC;
    void *unk10;
    void *unk14;
    void *unk18;
    void *unk1C;
    void *unk20;
    void *unk24;
    void *unk28;
    void *unk2C;
    u8 padding30[0x8];
    s32 unk38;
    u8 padding3C[0x6C - 0x3C];
    u8 unk6C;
    u8 unk6D;
    u8 unk6E;
    u8 unk6F;
    u8 unk70;
    u8 unk71;
    u8 unk72;
    u8 padding73[0x164 - 0x73];
    s16 unk164[3];
    u8 padding16A[0x238 - 0x16A];
    s32 unk238;
    s32 unk23C;
    s32 unk240;
    u8 padding244[0x31C - 0x244];
    s32 unk31C;
    s32 unk320;
    s32 unk324;
    u8 padding_328[0xD0];
    s32 unk3F8;
    u8 padding1[0x38];
    Vec3i worldPos;
    s32 unk440;
    s32 unk444;
    s32 unk448;
    s32 unk44C;
    s32 unk450;
    s32 unk454;
    s32 unk458;
    s32 unk45C;
    s32 unk460;
    u8 padding2a_1[0x4];
    s32 unk468;
    s32 unk46C;
    void *unk470;
    s32 unk474;
    s32 unk478;
    s32 unk47C;
    s32 unk480;
    u8 padding2a_3[0x4EC];
    Transform3D unk970;
    Transform3D unk990;
    func_8005E800_5F400_arg unk9B0;
    u8 padding9FC[0x14];
    JointPosition jointPositions[9];
    s32 unkA7C;
    s32 _padA80;
    s32 unkA84;
    u8 _padA88[0x4];
    u16 unkA8C;
    s16 unkA8E;
    s16 unkA90;
    s16 unkA92;
    s16 unkA94;
    s16 unkA96;
    s16 unkA98;
    s16 unkA9A;
    u8 padding4a_1[0x2];
    s16 unkA9E;
    s32 unkAA0;
    s32 unkAA4;
    s32 unkAA8;
    s32 unkAAC;
    s32 unkAB0;
    s32 unkAB4;
    s32 unkAB8;
    s32 unkABC;
    u8 unkAC0;
    u8 unkAC1;
    s16 unkAC2;
    s16 unkAC4;
    u8 padding2b[0x2];
    s32 unkAC8;
    s32 unkACC;
    s32 unkAD0;
    s32 unkAD4[3];
    s32 unkAE0;
    Vec3i unkAE4[6];
    s32 unkB2C;
    u8 paddingB30[0xB40 - 0xB30];
    s32 unkB40;
    s32 unkB44;
    s32 unkB48;
    s32 unkB4C;
    u8 padding2c_2[0x1C];
    s32 unkB6C;
    s32 unkB70;
    u16 unkB74;
    u8 padding2c_3[0x2];
    s16 unkB78;
    s8 unkB7A;
    s8 unkB7B;
    s16 unkB7C;
    u16 unkB7E;
    s8 unkB80;
    s8 unkB81;
    u8 padding6c[0x2];
    s32 unkB84;
    s32 unkB88;
    s32 unkB8C;
    s32 unkB90;
    u16 unkB94;
    u8 _padB96[0x2];
    s16 unkB98;
    s16 unkB9A;
    s16 unkB9C;
    s16 unkB9E;
    u16 unkBA0;
    s16 unkBA2;
    u16 unkBA4;
    s16 unkBA6;
    u8 _padBA8[0x2];
    s16 unkBAA;
    s16 unkBAC;
    s16 unkBAE;
    u16 unkBB0;
    u16 unkBB2;
    u8 unkBB4;
    s8 unkBB5;
    u8 unkBB6;
    u8 unkBB7;
    u8 unkBB8;
    u8 unkBB9;
    u8 unkBBA;
    u8 unkBBB;
    u8 unkBBC;
    u8 unkBBD;
    u8 unkBBE;
    u8 unkBBF;
    u8 unkBC0;
    u8 unkBC1;
    u8 unkBC2;
    u8 unkBC3;
    u8 unkBC4;
    u8 unkBC5;
    u8 unkBC6;
    u8 unkBC7;
    u8 unkBC8;
    u8 unkBC9;
    u8 unkBCA;
    u8 unkBCB;
    u8 unkBCC;
    s8 unkBCD;
    u8 unkBCE;
    u8 unkBCF;
    u8 unkBD0;
    u8 unkBD1;
    u8 unkBD2;
    u8 unkBD3;
    u8 unkBD4;
    u8 unkBD5;
    u8 unkBD6;
    u8 unkBD7;
    u8 unkBD8;
    u8 unkBD9;
    u8 unkBDA;
    u8 unkBDB;
    u8 unkBDC;
    u8 unkBDD;
    u8 unkBDE;
    u8 unkBDF;
    u8 unkBE0;
    u8 unkBE1;
    u8 unkBE2;
    u8 unkBE3;
    u8 unkBE4;
    u8 unkBE5;
    u8 unkBE6;
    u8 unkBE7;
} Player;
typedef struct {
              Node_70B00 *audioPlayer0;
    Node_70B00 *unk4;
    Node_70B00 *unk8;
    Node_70B00 *unkC;
    Player *players;
    void *unk14;
    void *unk18;
    void *unk1C;
    void *unk20;
    u8 PAD_2[0x4];
    GameStateUnk28 *unk28;
    u8 PAD_3[0x4];
               GameDataLayout gameData;
    GameStateUnk44 *unk44;
    u8 *unk48;
    s32 unk4C;
    s32 unk50;
    u8 unk54;
    u8 unk55;
    u8 unk56;
    u8 unk57;
    u16 unk58;
    u8 unk5A;
    u8 unk5B;
    u8 memoryPoolId;
    u8 unk5D;
    u8 numPlayers;
    u8 unk5F;
    u8 unk60;
    u8 PAD_6[0x2];
    u8 unk63;
    u8 PAD_6B_2[0x10];
    u8 unk74;
    u8 PAD_6B[0x1];
    u8 gamePaused;
    u8 unk77;
    u8 unk78;
    u8 unk79;
    u8 unk7A;
    s8 unk7B;
    s8 unk7C;
    u8 unk7D;
    u8 unk7E;
    u8 PAD_7[0x4];
               u8 unk83;
               u8 unk84;
    u8 PAD_85[0x1];
    u8 unk86;
    u8 PAD_7B[0x53];
    u16 unkDA;
    u8 PAD_8[0xF9];
                ALPlayer *audioPlayer2;
    u8 PAD_9[0x4];
                ALPlayer *audioPlayer3;
    u8 PAD_A[0x2];
                u8 unk1E6;
    u8 PAD_A2[0x1C9];
                void *unk3B0;
                void *unk3B4;
                u16 unk3B8;
                u8 unk3BA;
                u8 unk3BB;
                u8 unk3BC;
                u8 unk3BD;
                u8 unk3BE;
                u8 partialUnlockCheatProgress;
                u8 unlockAllCheatProgress;
                u8 unk3C1;
    u8 PAD_C2[0xE];
    s32 unk3D0;
    s32 unk3D4;
    s32 unk3D8;
    void *unk3DC;
    void *unk3E0;
    void *unk3E4;
    s16 unk3E8;
    u8 PAD_D[0x2];
    s32 unk3EC;
    s32 unk3F0;
    s16 unk3F4;
    s32 unk3F8;
    u16 unk3FC;
    s16 unk3FE;
    u8 unk400;
    u8 PAD_E[0x2];
    u8 unk403;
    u8 PAD_0A_1[0x4];
    s32 unk408[2];
    s32 unk410[2];
    s16 unk418[2];
    s32 unk41C;
    u8 unk420;
    u8 unk421;
    u8 unk422;
    u8 unk423;
    u8 unk424;
    s8 unk425;
    u8 unk426;
    u8 unk427;
    u8 unk428;
    u8 unk429;
    u8 unk42A;
    u8 PAD_11[3];
    s8 unk42E;
    u8 PAD_12[0x158];
    s32 *unk588;
    s32 *unk58C;
    u16 unk590;
    u8 PAD_13[0x8];
    u8 unk59A[8];
    u8 PAD_13B[0xB];
    s8 unk5AD;
    s8 unk5AE;
    u8 unk5AF;
    u8 unk5B0;
    u8 unk5B1;
    s8 unk5B2;
    u8 unk5B3;
    u8 PAD_14[0x4];
    u8 unk5B8[8];
    u16 unk5C0;
    u8 PAD_14B[0x3];
    u8 unk5C5;
    u8 unk5C6;
    u8 unk5C7;
    s8 unk5C8;
    u8 unk5C9;
    u8 unk5CA[0xD];
    u8 unk5D7;
    u8 unk5D8;
    u8 PAD_15B[0x1A3];
    s16 unk77C;
    u8 PAD_16[0x6];
    u8 unk784[4];
    u8 PAD_16B[0x10];
    u8 unk798;
    u8 PAD_16C[2];
    u8 unk79B;
    u8 unk79C;
    u8 PAD_17[4];
    s8 unk7A1;
    u8 PAD_18[0x103E];
    s8 unk17E0;
    u8 PAD_19[0x17];
    Transform3D unk17F8[4];
    u8 PAD_19B[0x8];
    u16 unk1880[4];
    u16 unk1888[8];
    u16 unk1898[4];
    u8 PAD_20[0x8];
    u8 unk18A8[8];
    u8 unk18B0[8];
    u8 PAD_22[0x8];
    u8 unk18C0[8];
    u8 unk18C8[4];
    u8 unk18CC;
    u8 PAD_23[0x5];
    u8 unk18D2[8];
} GameState;
typedef struct {
    struct {
        s8 padding[0xD5];
        s32 unkDA;
    } *parent;
    void *modelData;
    void *textureData;
    f32 primaryMatrix[8];
    s32 displayConfig;
    void *activeModel;
    void *activeTexture;
    void *animState;
    s8 pad3C[12];
    float secondaryMatrix[8];
    s32 secondaryConfig;
    void *secondaryModel;
    void *secondaryTexture;
    void *unk74;
    s8 pad78[12];
    s16 configIndex;
    u8 isDisposed;
    u8 isVisible;
} ModelEntity;
void setupModelEntityLighting(ModelEntity *entity, ColorData *lightColors, ColorData *ambientColor);
s32 initModelEntity(ModelEntity *entity, s16 index, void *arg2);
typedef struct {
    struct {
        u8 padding[0x16];
        u16 slotIndex;
    } *parent;
    u8 padding[0x8];
    DisplayListObject primaryDisplayList;
    s32 secondaryDisplayList;
    u8 padding4[0x20];
    s32 hasSecondaryDisplayList;
    u8 padding5[0x17];
    s8 isVisible;
} ModelEntityRenderState;
void renderModelEntity(ModelEntityRenderState *);
typedef struct {
    s32 unk0;
    void *unk4;
    void *unk8;
    u8 padding[0x7A];
    s8 isDisposed;
} EffectState;
void freeEffectResources(EffectState *);
typedef struct {
    u8 padding[0x6];
    u16 unk6;
    s8 padding2[0x7F];
    s8 unk87;
} setModelRenderMode_arg;
void setModelRenderMode(setModelRenderMode_arg *arg0, s8 arg1);
typedef struct {
    u8 unk0;
    u8 unk1;
    u8 unk2;
    u8 unk3;
} PackedData;
typedef struct {
    union {
        struct {
            s16 unk0;
            PackedData unk2[2];
            u8 unkA;
        } One;
        struct {
            s32 unk0;
            s32 unk4;
            u8 unk8;
            u8 unk9;
            s8 unkA;
        } Two;
        struct {
            s32 unk0;
            s32 unk4;
            s16 unk8;
            s8 unkA;
        } CurtainPayload;
        struct {
            s16 unk0;
            s16 unk2;
        } TrickPayload;
        struct {
            s16 unk0;
            u8 padding[0xE];
            s32 unk10;
            s32 unk14;
            s32 unk18;
            s32 unk1C;
            s32 unk20;
            s32 unk24;
        } ChrPayload;
    } unk0;
    u8 padding[0x18];
    s8 unk40;
    u8 padding2[0x3];
    s8 unk44;
    u8 padding3[0xA7];
    s8 unkEC;
    u8 padding4[0x3];
    s32 unkF4;
} func_800B2A24_1DFAD4_arg_item;
typedef struct {
    Node_70B00 *unk0;
    u8 header[0xA4];
    func_800B2A24_1DFAD4_arg_item items[18];
    u8 padding[0x50];
    s32 unk1220;
} func_800B2A24_1DFAD4_arg;
typedef struct {
    u8 padding[0xFF7];
    s8 unkFF7;
} func_800B29F0_1DFAA0_arg;
typedef struct {
    void *start;
    void *end;
    u32 size;
    s8 unkC;
    u8 padding[3];
} D_800BA960_1E7A10_node;
typedef struct {
    s8 unk0;
    s8 unk1;
    s16 unk2;
    s32 unk4;
    u8 padding[0xDC];
    s16 unkE4;
} TaskData;
typedef struct {
    s16 unk0;
    s16 unk2;
    s16 unk4;
    s8 unk6;
    s8 unk7;
    s8 unk8;
    s8 unk9;
} StateEntryItem;
typedef struct {
    u8 pad[0x210];
    s32 unk210;
} Func8000C268Arg;
typedef struct StateEntry StateEntry;
struct StateEntry {
    u8 padding0[0xC];
              u16 current_index;
    u8 padding[0x2];
               u16 unk10;
               u8 unk12;
               u8 unk13;
               u16 unk14;
               s16 unk16;
               s16 unk18;
               s16 unk1A;
               u8 unk1C;
    u8 padding4[0x3];
    StateEntryItem items[2];
    s32 unk34;
               u16 next_index;
               u16 prev_index;
    s16 unk3C;
    u8 unk3E;
    u8 unk3F;
};
typedef struct {
    u8 padding[0x16];
    u16 unk16;
} UIResource;
typedef struct {
    union {
        s32 One;
        s8 Two;
        s8 bytes[4];
    } unk0;
    Transform3D unk04;
    union {
        SceneModel *unk20;
        s32 unk20_s32;
        s16 unk20_s16;
    } unk20_u;
               s32 unk28;
               s32 unk2C;
               s32 unk30;
               s32 unk34;
               s32 unk38;
               s32 unk3C;
               s32 unk40;
               s32 unk44;
               s32 unk48;
               s32 unk4C;
               s32 unk50;
               s32 unk54;
               s32 unk58;
               s32 unk5C;
               s32 unk60;
               s32 unk64;
               s32 unk68;
               s32 unk6C;
               s32 unk70;
               s32 unk74;
               s16 unk78;
               s16 unk7A;
               s16 unk7C;
               s16 unk7E;
               s16 unk80;
               s16 unk82;
               s16 unk84;
               s16 unk86;
               s16 unk88;
               s16 unk8A;
               s16 unk8C;
               s16 angle;
               s16 unk90;
               s16 unk92;
               s32 unk94;
               s32 unk98;
    union {
        s32 unk9C_s32;
        struct {
            s16 unk9C_low;
            s16 unk9E;
        } s;
    } unk9C_u;
               s32 unkA0;
               union {
        SceneModel *ptr;
        s8 byte;
    } unkA4;
} CutsceneSlotData;
typedef struct {
    union {
        struct {
            s16 unk0;
            PackedData unk2[2];
            u8 unkA;
        } One;
        struct {
            s32 unk0;
            s32 unk4;
            u8 unk8;
            u8 unk9;
            s8 unkA;
        } Two;
        struct {
            s32 unk0;
            s32 unk4;
            s16 unk8;
            s8 unkA;
        } CurtainPayload;
        struct {
            s16 unk0;
            s16 unk2;
        } TrickPayload;
        struct {
            s16 unk0;
            u8 padding[0xE];
            s32 unk10;
            s32 unk14;
            s32 unk18;
            s32 unk1C;
            s32 unk20;
            s32 unk24;
        } ChrPayload;
    } unk0;
    u8 padding[0x18];
               u16 unk40;
               u8 unk42;
               u8 unk43;
               u8 unk44;
               u8 padding3[0x3];
               SceneModel *model;
               CutsceneSlotData slotData;
} CutsceneSlot;
typedef struct {
              Node_70B00 *uiResource;
              s8 pad4[0x8];
              void *sceneContext;
               setModelRenderMode_arg unk10;
               u16 currentFrame;
               u16 maxFrame;
               u16 endFrame;
               s8 pad9E[0x2];
               s8 debugText[0x8];
               CutsceneSlot slots[16];
                void *textRenderer;
                s8 padFEC[0x8];
                s8 showDebugInfo;
                s8 enableTransparency;
                s8 unused_FF6;
                s8 skipAnimation;
                Func8000C268Arg unkFF8;
    u8 padding[0xC];
                 void *shadowModel;
                 void *reflectionModel;
                 s32 cameraAnimationTimer;
} CutsceneManager;
typedef struct {
    u8 padding[0xC];
    void *unkC;
    EffectState unk10;
    u8 padding2[0x20];
    s32 unkB8;
    u8 padding3[0x2C];
    u16 unkE8;
    u8 padding4[0x6];
    SceneModel *unkF0;
    u8 padding5[0x0];
} func_800B2C78_arg;
void func_800B29F0_1DFAA0(CutsceneManager *arg0);
void func_800B29FC_1DFAAC(CutsceneManager *arg0);
void func_800B2A24_1DFAD4(CutsceneManager *arg0, s16 arg1);
void func_800B2A50_1DFB00(CutsceneManager *arg0, s16 arg1);
CutsceneSlot *func_800B2A78_1DFB28(CutsceneManager *arg0, s16 arg1);
void func_800B2AA0(CutsceneManager *, Node_70B00 *arg1, void *arg2, void *arg3);
void func_800B2C78(func_800B2C78_arg *arg0);
void func_800B2D04(CutsceneSlot *arg0);
void func_800B2D68_1DFE18(CutsceneSlot *arg0);
void func_800B2DCC_1DFE7C(CutsceneSlot *arg0);
void func_800B2E48_1DFEF8(CutsceneManager *manager);
s32 processCutsceneFrame(CutsceneManager *uiManager);
s16 func_800B3360(s16, s16);
void *func_800B3420_1E04D0(void);
void *func_800B3430_1E04E0(void);
u16 func_800B3440_1E04F0(void);
u8 func_800B3450_1E0500(void);
u8 getCutsceneSlotCount(void);
u16 func_800B3470_1E0520(void);
u16 func_800B3480_1E0530(void);
s16 func_800B3490_1E0540(void);
void func_800B34A0_1E0550(s16 arg0);
StateEntryItem *func_800B34B0_1E0560(s32 arg0);
s16 func_800B34D0_1E0580(void);
void func_800B34E0_1E0590(s16 arg0);
u8 func_800B34F0(void);
void func_800B3500_1E05B0(u8 arg0);
s32 func_800B3510_1E05C0(void);
s32 func_800B3540_1E05F0(void);
s32 func_800B36C0(void *arg0);
s32 func_800B3790_1E0840(void);
u16 func_800B384C_1E08FC(void);
void resetScriptState(u8 *arg0);
void func_800B388C_1E093C(s32 arg0);
void func_800B3B40(void);
u16 func_800B3B68_1E0C18(u8 arg0, u16 arg1, s32 arg2);
s32 findEventAtFrame(u8 a0, u16 a1);
s32 func_800B3D24_1E0DD4(u8, u16);
void func_800B3E58_1E0F08(u16 entryIndex, u16 oldPrevIndex, u16 newPrevIndex);
StateEntry *getStateEntry(u16 arg0);
u16 func_800B41E0_1E1290(void);
u16 func_800B4258_1E1308(u8 arg0);
StateEntry *func_800B4288_1E1338(void);
u8 *func_800B4294_1E1344(void);
u16 func_800B42B0_1E1360(u16 arg0);
u16 func_800B42E8_1E1398(u16 arg0);
void func_800B4320_1E13D0(void);
void func_800B4378_1E1428(u8 slotIndex, s16 frameNumber);
void func_800B44A8_1E1558(u8 arg0, u16 arg1);
void func_800B4534_1E15E4(s32, s32);
void func_800B462C_1E16DC(u8 arg0, u16 arg1, s32 arg2);
void *func_800B4680_1E1730(s8 arg0);
void func_800B46E0(s32 arg0, s8 arg1, s16 arg2);
void func_800B477C_1E182C(void *);
void initializeCutsceneSystem(void *);
typedef struct {
    s16 rotation_y;
    s16 unk2;
    s16 grid_x;
    s16 grid_y;
    s8 unk8;
    s8 render_flags;
} cutsceneSys2Wipe_exec_arg0;
typedef struct {
    s32 x;
    s32 y;
    s32 z;
} Vec3;
typedef struct {
    s8 pad[0x70];
    Vec3 position;
    s8 pad2[0xF4 - 0x7C];
} cutsceneSys2Wipe_exec_arg1_slot;
typedef struct {
    s8 padding[0xA8];
    cutsceneSys2Wipe_exec_arg1_slot slots[5];
    u8 padding2[0xA8C];
                Func8000C268Arg matrix;
} cutsceneSys2Wipe_exec_arg1;
typedef struct {
    u16 unk0;
    u16 unk2;
    u16 unk4;
} cutsceneSys2Wait_exec_arg0;
typedef struct {
    s16 unk0;
    s16 unk2;
    void *unk4;
    s16 unk8;
    u16 unkA;
    u16 unkC;
    s16 unkE;
    s16 unk10;
    s8 unk12;
    s8 unk13;
    s8 unk14;
    u8 padding[3];
} cutsceneSys2WaitSlot;
typedef struct {
    void *unk0;
    s32 unk4;
    void *unk8;
    void *unkC;
    u16 unk10;
    u16 unk12;
    cutsceneSys2WaitSlot slots[4];
    s32 unk74;
    s32 unk78;
    s32 unk7C;
    s32 unk80;
    s16 unk84;
    s16 unk86;
    s16 unk88;
    s16 unk8A;
    s16 unk8C;
    s16 unk8E;
    void *unk90;
    void *unk94;
    s16 unk98;
    s16 unk9A;
    u8 unk9C;
    u8 unk9D;
    u8 padding3[0x2];
    void *unkA0;
    s16 unkA4;
    s16 unkA6;
    void *unkA8;
    s16 unkAC;
    u8 padding4[0x2];
} cutsceneSys2Wait_exec_asset;
void cutsceneSys2Wipe_init(void);
s32 cutsceneSys2Wipe_validate(void);
void cutsceneSys2Wipe_exec(cutsceneSys2Wipe_exec_arg0 *params, cutsceneSys2Wipe_exec_arg1 *state, s8 slot_index);
s32 cutsceneSys2Wipe_isDone(void);
void cutsceneSys2Wait_init(void);
s32 cutsceneSys2Wait_validate(void);
void cutsceneSys2Wait_exec(cutsceneSys2Wait_exec_arg0 *arg0, CutsceneManager *arg1, s8 arg2);
void func_800B993C_1E69EC(cutsceneSys2Wait_exec_asset *);
void *freeNodeMemory(void *);
void func_800B9C20_1E6CD0(cutsceneSys2Wait_exec_asset *arg0) {
    arg0->unkA0 = freeNodeMemory(arg0->unkA0);
    arg0->unk8 = freeNodeMemory(arg0->unk8);
    arg0->unkC = freeNodeMemory(arg0->unkC);
}
