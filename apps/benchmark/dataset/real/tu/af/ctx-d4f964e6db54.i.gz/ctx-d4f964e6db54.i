typedef unsigned char u8;
typedef struct { u8 r; u8 g; u8 b; u8 a; } Color_RGBA8;
