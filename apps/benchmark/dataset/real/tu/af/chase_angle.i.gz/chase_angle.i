typedef short s16;
typedef int s32;
typedef float f32;
extern f32 game_GameFrame_2F;
s32 chase_angle(s16* pValue, s16 target, s16 step) {
    if (step != 0) {
        f32 updateScale = game_GameFrame_2F;
        if ((s16)(*pValue - target) > 0) {
            step = -step;
        }
        *pValue += (s16)(step * updateScale);
        if (((s16)(*pValue - target) * step) >= 0) {
            *pValue = target;
            return 1;
        }
    } else if (*pValue == target) {
        return 1;
    }
    return 0;
}
