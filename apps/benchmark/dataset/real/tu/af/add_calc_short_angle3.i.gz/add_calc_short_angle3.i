typedef short s16;
typedef unsigned short u16;
typedef int s32;
typedef float f32;
s16 add_calc_short_angle3(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep) {
    f32 stepSize;
    s32 uTarget;
    s32 newValue;
    s32 uValue;
    if (target != *pValue) {
        uValue = (u16)*pValue;
        uTarget = (u16)target;
        if (uValue > uTarget) {
            uTarget += 0x10000;
        }
        stepSize = (uTarget - uValue) * fraction;
        if (stepSize > maxStep) {
            stepSize = maxStep;
        } else if (stepSize < minStep) {
            stepSize = minStep;
        }
        newValue = uValue + (s32)stepSize;
        if (newValue > uTarget) {
            newValue = uTarget;
        }
        *pValue = newValue;
    }
    return target - *pValue;
}
