typedef short s16;
typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
s16 atans_table(f32 x, f32 y);
