typedef struct ListAlloc {
    struct ListAlloc* prev;
    struct ListAlloc* next;
} ListAlloc;
ListAlloc* ListAlloc_Init(ListAlloc* this) {
    this->prev = ((void*)0);
    this->next = ((void*)0);
    return this;
}
