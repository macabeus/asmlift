typedef unsigned char u8;
typedef unsigned int size_t;
