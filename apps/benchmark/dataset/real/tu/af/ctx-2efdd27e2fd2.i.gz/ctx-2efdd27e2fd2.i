typedef int s32;
