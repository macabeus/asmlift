typedef float f32;
f32 limiter(f32 val, f32 max) {
    if (val < 0.0f) {
        return ((val) < (-max) ? (-max) : (val));
    } else {
        return ((val) > (max) ? (max) : (val));
    }
}
