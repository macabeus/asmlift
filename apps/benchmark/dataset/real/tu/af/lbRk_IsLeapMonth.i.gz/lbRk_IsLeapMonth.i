typedef int s32;
s32 lbRk_IsLeapMonth(s32 month) {
    if (month == 13) {
        return 1;
    }
    return 0;
}
