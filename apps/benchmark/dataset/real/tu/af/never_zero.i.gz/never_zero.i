typedef float f32;
f32 never_zero(f32 val, f32 min) {
    if (val < 0.0f) {
        return ((val) > (-min) ? (-min) : (val));
    } else {
        return ((val) < (min) ? (min) : (val));
    }
}
