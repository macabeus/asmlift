typedef short s16;
typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
s16 atans_table(f32 x, f32 y);
s16 search_position_angleY(xyz_t* subtrahend, xyz_t* minuend) {
    f32 diffX = minuend->x - subtrahend->x;
    f32 diffZ = minuend->z - subtrahend->z;
    return atans_table(diffZ, diffX);
}
