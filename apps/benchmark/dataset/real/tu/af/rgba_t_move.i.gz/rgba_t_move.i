typedef unsigned char u8;
typedef struct { u8 r; u8 g; u8 b; u8 a; } Color_RGBA8;
void rgba_t_move(Color_RGBA8* dest, Color_RGBA8* src) {
    dest->r = src->r;
    dest->g = src->g;
    dest->b = src->b;
    dest->a = src->a;
}
