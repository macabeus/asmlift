typedef short s16;
typedef int s32;
s32 chase_s(s16* pValue, s16 target, s16 step) {
    if (step) {
        if (*pValue > target) {
            step = -step;
        }
        *pValue += step;
        if ((step * (*pValue - target)) >= 0) {
            *pValue = target;
            return 1;
        }
    } else {
        if (*pValue == target) {
            return 1;
        }
    }
    return 0;
}
