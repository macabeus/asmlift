typedef unsigned char u8;
typedef unsigned int size_t;
void mem_clear(u8* ptr, size_t len, u8 value) {
    size_t i;
    for (i = 0; i < len; i++) {*ptr++ = value;}
}
