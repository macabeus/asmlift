typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef float f32;
typedef double f64;
typedef struct xyz_t {
              f32 x;
              f32 y;
              f32 z;
} xyz_t;
typedef float MtxF_t[4][4];
typedef union {
    MtxF_t mf;
    struct {
        float xx, yx, zx, wx, xy, yy, zy, wy, xz, yz, zz, wz, xw, yw, zw, ww;
    };
} MtxF;
typedef long Mtx_t[4][4];
typedef union {
    Mtx_t m;
    long long int force_structure_alignment;
} Mtx;
f32 add_calc_a(f32* pValue, f32 target, f32 fraction, f32 step, f32 minStep) {
    f32 stepSize = 0.0f;
    f32 diff = target - *pValue;
    if (target != *pValue) {
        if (diff > 180.0f) {
            diff = -(360.0f - diff);
        } else if (diff < -180.0f) {
            diff = 360.0f + diff;
        }
        stepSize = diff * fraction;
        if ((stepSize >= minStep) || (stepSize <= -minStep)) {
            if (step < stepSize) {
                stepSize = step;
            } else if (stepSize < -step) {
                stepSize = -step;
            }
            *pValue += stepSize;
            if (stepSize > 0.0f) {
                if (target < *pValue) {
                    *pValue = target;
                }
            } else if (*pValue < target) {
                *pValue = target;
            }
        } else {
            if (stepSize > 0.0f) {
                stepSize = minStep;
                *pValue += stepSize;
                if (target < *pValue) {
                    *pValue = target;
                }
            } else {
                stepSize = -minStep;
                *pValue += -minStep;
                if (*pValue < target) {
                    *pValue = target;
                }
            }
        }
    }
    if (*pValue >= 360.0f) {
        *pValue -= 360.0f;
    }
    if (*pValue < 0.0f) {
        *pValue += 360.0f;
    }
    return stepSize;
}
