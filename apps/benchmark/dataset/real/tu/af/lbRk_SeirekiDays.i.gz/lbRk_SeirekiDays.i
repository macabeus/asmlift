typedef unsigned char u8;
typedef int s32;
typedef u8 lbRTC_day_t;
extern lbRTC_day_t t_seiyo_days_tbl[2][13];
s32 lbRk_SeirekiDays(s32 year, s32 month) {
    s32 idx = 0;
    if ((year % 4) == 0) {
        idx = 1;
    }
    return t_seiyo_days_tbl[idx][month];
}
