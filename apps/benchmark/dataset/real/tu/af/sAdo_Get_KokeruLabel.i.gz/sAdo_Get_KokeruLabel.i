typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef float f32;
typedef double f64;
typedef struct xyz_t {
              f32 x;
              f32 y;
              f32 z;
} xyz_t;
typedef float MtxF_t[4][4];
typedef union {
    MtxF_t mf;
    struct {
        float xx, yx, zx, wx, xy, yy, zy, wy, xz, yz, zz, wz, xw, yw, zw, ww;
    };
} MtxF;
typedef long Mtx_t[4][4];
typedef union {
    Mtx_t m;
    long long int force_structure_alignment;
} Mtx;
u16 sAdo_Get_WalkLabel(s32 type);
s32 sAdo_Get_KokeruLabel(s32 type) {
    u16 label = sAdo_Get_WalkLabel(type);
    s32 ret;
    switch (label) {
        case 0x201:
            ret = 0xe;
            break;
        case 0x206:
            ret = 0x13;
            break;
        case 0x202:
            ret = 0xf;
            break;
        case 0x203:
            ret = 0x10;
            break;
        case 0x204:
            ret = 0x11;
            break;
        case 0x205:
            ret = 0x12;
            break;
        case 0x208:
            ret = 0x156;
            break;
        case 0x209:
            ret = 0x157;
            break;
        default:
            ret = 15;
            break;
    }
    return ret;
}
