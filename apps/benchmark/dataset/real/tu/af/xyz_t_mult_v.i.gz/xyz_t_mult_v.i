typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
void xyz_t_mult_v(xyz_t* multiplicand, f32 multiplier) {
    multiplicand->x *= multiplier;
    multiplicand->y *= multiplier;
    multiplicand->z *= multiplier;
}
