typedef int s32;
extern s32 l_lbRk_leapdays[33];
s32 lbRk_IsKyuurekiLeapYear(s32 year) {
    if (l_lbRk_leapdays[year - 2000] != 0) {
        return 1;
    };
    return 0;
}
