typedef struct { unsigned int w0; unsigned int w1; } Gfx;
Gfx* gfxopen(Gfx* gfxHead) {
    return gfxHead + 1;
}
