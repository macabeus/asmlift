typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
void xyz_t_sub(xyz_t* minuend, xyz_t* subtrahend, xyz_t* diff) {
    diff->x = minuend->x - subtrahend->x;
    diff->y = minuend->y - subtrahend->y;
    diff->z = minuend->z - subtrahend->z;
}
