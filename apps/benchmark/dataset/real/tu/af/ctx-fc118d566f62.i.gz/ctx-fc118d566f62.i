typedef long s32;
