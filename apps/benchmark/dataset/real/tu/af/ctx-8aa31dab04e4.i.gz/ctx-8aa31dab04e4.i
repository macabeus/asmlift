typedef unsigned char u8;
typedef int s32;
typedef u8 lbRTC_day_t;
extern lbRTC_day_t t_seiyo_days_tbl[2][13];
