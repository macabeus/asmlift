typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
void xyz_t_add(xyz_t* augend, xyz_t* addend, xyz_t* total) {
    total->x = augend->x + addend->x;
    total->y = augend->y + addend->y;
    total->z = augend->z + addend->z;
}
