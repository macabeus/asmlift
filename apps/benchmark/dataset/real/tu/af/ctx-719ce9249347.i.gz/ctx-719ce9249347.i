typedef unsigned char u8;
typedef unsigned int u32;
typedef short s16;
typedef int s32;
typedef struct { u32 cont: 1; u32 type: 4; u32 offset: 11; s32 value: 16; } ValueSet;
typedef struct s_xyz { s16 x; s16 y; s16 z; } s_xyz;
