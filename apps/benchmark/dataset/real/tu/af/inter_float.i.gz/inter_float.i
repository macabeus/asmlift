typedef int s32;
typedef float f32;
void inter_float(f32* pValue, f32 arg1, s32 stepCount) {
    if (stepCount <= 0) {
        *pValue = arg1;
    } else {
        f32 diff = arg1 - *pValue;
        *pValue += diff / stepCount;
    }
}
