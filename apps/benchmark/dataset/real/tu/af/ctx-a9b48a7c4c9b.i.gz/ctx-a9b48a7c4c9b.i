typedef int s32;
extern s32 l_lbRk_leapdays[33];
