typedef long s32;
s32 mPl_SceneNo2SoundRoomType(s32 arg0) {
    switch (arg0) {
        case 20:
            return 1;
        case 6:
        case 9:
        case 12:
        case 14:
        case 18:
        case 21:
        case 31:
            return 2;
        case 17:
        case 22:
        case 23:
        case 24:
        case 25:
        case 29:
            return 3;
        default:
            return 0;
    }
}
