typedef short s16;
typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
typedef struct s_xyz { s16 x; s16 y; s16 z; } s_xyz;
void xyz_t_sub_ss(xyz_t* dest, s_xyz* minuend, s_xyz* subtrahend) {
    dest->x = minuend->x - subtrahend->x;
    dest->y = minuend->y - subtrahend->y;
    dest->z = minuend->z - subtrahend->z;
}
