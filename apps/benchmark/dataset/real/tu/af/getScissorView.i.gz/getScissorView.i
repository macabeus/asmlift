typedef signed char s8;
typedef long s32;
typedef struct Viewport {
               s32 topY;
               s32 bottomY;
               s32 leftX;
               s32 rightX;
} Viewport;
typedef struct View {
                s32 unk_000;
                void* gfxCtx;
                Viewport viewport;
                s8 unk_018[0x110];
} View;
void getScissorView(View* view, Viewport* viewport) {
    *viewport = view->viewport;
}
