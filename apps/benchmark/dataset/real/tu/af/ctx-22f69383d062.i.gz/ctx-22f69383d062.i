typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
