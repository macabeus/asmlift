typedef short s16;
typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
typedef struct { f32 r; s16 pitch; s16 yaw; } VecSphGeo;
typedef VecSphGeo VecSph;
f32 cos_s(s16 angle);
f32 sin_s(s16 angle);
xyz_t spolar2world(VecSph* sph) {
    xyz_t v;
    f32 sinPitch;
    f32 cosPitch = cos_s(sph->pitch);
    f32 sinYaw;
    f32 cosYaw = cos_s(sph->yaw);
    sinPitch = sin_s(sph->pitch);
    sinYaw = sin_s(sph->yaw);
    v.x = sph->r * sinPitch * sinYaw;
    v.y = sph->r * cosPitch;
    v.z = sph->r * sinPitch * cosYaw;
    return v;
}
