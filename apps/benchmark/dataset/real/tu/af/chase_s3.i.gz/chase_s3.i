typedef short s16;
typedef int s32;
s32 chase_s3(s16* pValue, s16 target, s16 step) {
    if (step) {
        s32 diff = target - *pValue;
        if (diff < 0) {
            step = -step;
        }
        if (diff >= 0x8000) {
            step = -step;
            diff = -0xFFFF - -diff;
        } else if (diff <= -0x8000) {
            step = -step;
            diff += 0xFFFF;
        }
        *pValue += step;
        if ((diff * step) <= 0) {
            *pValue = target;
            return 1;
        }
    } else if (target == *pValue) {
        return 1;
    }
    return 0;
}
