typedef int s32;
typedef float f32;
s32 chase_f3(f32* pValue, f32 target, f32 incrStep, f32 decrStep) {
    f32 step = (target >= *pValue) ? incrStep : decrStep;
    if (step != 0.0f) {
        if (target < *pValue) {
            step = -step;
        }
        *pValue += step;
        if (((*pValue - target) * step) >= 0) {
            *pValue = target;
            return 1;
        }
    } else if (target == *pValue) {
        return 1;
    }
    return 0;
}
