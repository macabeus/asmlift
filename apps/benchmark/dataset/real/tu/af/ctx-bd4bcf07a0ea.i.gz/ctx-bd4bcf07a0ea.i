typedef short s16;
typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
typedef struct s_xyz { s16 x; s16 y; s16 z; } s_xyz;
