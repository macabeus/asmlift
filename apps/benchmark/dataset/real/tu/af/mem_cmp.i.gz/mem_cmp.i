typedef unsigned char u8;
typedef int s32;
typedef unsigned int size_t;
s32 mem_cmp(u8* ptr1, u8* ptr2, size_t len) {
    while (len != 0) {
        if (*ptr1 != *ptr2) {
            return 0;
        }
        ptr1++;
        ptr2++;
        len--;
    }
    return 1;
}
