typedef struct ListAlloc {
    struct ListAlloc* prev;
    struct ListAlloc* next;
} ListAlloc;
