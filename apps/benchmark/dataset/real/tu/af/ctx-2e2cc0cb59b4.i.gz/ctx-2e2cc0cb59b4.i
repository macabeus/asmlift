typedef unsigned char u8;
typedef unsigned short u16;
typedef int s32;
extern u8 mRmTp_ftr_size[];
