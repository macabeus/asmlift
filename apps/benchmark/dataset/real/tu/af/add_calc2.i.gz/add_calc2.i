typedef float f32;
void add_calc2(f32* pValue, f32 target, f32 fraction, f32 step) {
    f32 stepSize;
    if (*pValue != target) {
        stepSize = fraction * (target - *pValue);
        if (stepSize > step) {
            stepSize = step;
        } else if (stepSize < -step) {
            stepSize = -step;
        }
        *pValue += stepSize;
    }
}
