typedef unsigned char u8;
typedef unsigned int size_t;
void mem_copy(u8* dest, u8* src, size_t len) {
    while (len != 0) {
        *dest = *src;
        src++;
        dest++;
        len--;
    }
}
