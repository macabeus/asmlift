typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef float f32;
typedef double f64;
typedef struct xyz_t {
              f32 x;
              f32 y;
              f32 z;
} xyz_t;
typedef float MtxF_t[4][4];
typedef union {
    MtxF_t mf;
    struct {
        float xx, yx, zx, wx, xy, yy, zy, wy, xz, yz, zz, wz, xw, yw, zw, ww;
    };
} MtxF;
typedef long Mtx_t[4][4];
typedef union {
    Mtx_t m;
    long long int force_structure_alignment;
} Mtx;
f32 get_percent_forAccelBrake(f32 x, f32 min, f32 max, f32 accelRange, f32 brakeRange) {
    f32 percent;
    f32 range;
    f32 cur;
    f32 scale;
    if (x >= max) {
        return 1.0f;
    }
    if (x <= min) {
        return 0.0f;
    }
    cur = x - min;
    range = max - min;
    if (range < accelRange + brakeRange) {
        return 0.0f;
    }
    scale = 1.0f / (2.0f * range - accelRange - brakeRange);
    if (accelRange != 0.0f) {
        if (cur <= accelRange) {
            percent = scale * cur * cur;
            percent /= accelRange;
            return percent;
        } else {
            percent = scale * accelRange;
        }
    } else {
        percent = 0.0f;
    }
    if (cur <= range - brakeRange) {
        percent += (scale * 2.0f) * (cur - accelRange);
        return percent;
    }
    percent += 2.0f * scale * (range - accelRange - brakeRange);
    if (brakeRange != 0.0f) {
        percent += scale * brakeRange;
        if (cur < range) {
            f32 left = range - cur;
            percent -= scale * left * left / brakeRange;
        }
    }
    return percent;
}
