typedef unsigned char u8;
typedef unsigned short u16;
typedef int s32;
extern u8 mRmTp_ftr_size[];
s32 mRmTp_ItemNo2FtrSize(u16 name) {
    if (name >= 0x1000 && name < 0x1ECD) {
        s32 scoped;
        return mRmTp_ftr_size[(name - 0x1000) >> 2];
    }
    return 0;
}
