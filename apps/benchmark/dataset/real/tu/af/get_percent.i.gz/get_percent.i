typedef int s32;
typedef float f32;
f32 get_percent(s32 max, s32 min, s32 x) {
    f32 denom;
    f32 percent;
    percent = 1.0f;
    if (x < min) {
        percent = 0.0f;
    } else if (x < max) {
        denom = (f32)(max - min);
        if (denom != 0.0f) {
            percent = (f32)(x - min) / denom;
            if (percent > 1.0f) {
                percent = 1.0f;
            }
        }
    }
    return percent;
}
