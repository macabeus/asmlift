typedef short s16;
