typedef short s16;
typedef int s32;
s32 chase_s2(s16* pValue, s16 limit, s16 step) {
    s16 prev = *pValue;
    *pValue += step;
    if ((*pValue - limit) * (prev - limit) <= 0) {
        *pValue = limit;
        return 1;
    }
    return 0;
}
