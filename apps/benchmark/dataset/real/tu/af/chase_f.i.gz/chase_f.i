typedef int s32;
typedef float f32;
s32 chase_f(f32* pValue, f32 target, f32 step) {
    if (step) {
        if (*pValue > target) {
            step = -step;
        }
        *pValue += step;
        if ((step * (*pValue - target)) >= 0.0f) {
            *pValue = target;
            return 1;
        }
    } else {
        if (*pValue == target) {
            return 1;
        }
    }
    return 0;
}
