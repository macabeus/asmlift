typedef short s16;
typedef float f32;
typedef struct xyz_t { f32 x; f32 y; f32 z; } xyz_t;
typedef struct { f32 r; s16 pitch; s16 yaw; } VecSphGeo;
typedef VecSphGeo VecSph;
f32 cos_s(s16 angle);
f32 sin_s(s16 angle);
