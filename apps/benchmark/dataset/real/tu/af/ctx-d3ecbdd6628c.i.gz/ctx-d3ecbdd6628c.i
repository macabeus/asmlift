typedef short s16;
typedef unsigned short u16;
typedef int s32;
typedef float f32;
