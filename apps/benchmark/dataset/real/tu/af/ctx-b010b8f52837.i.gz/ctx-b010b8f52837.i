typedef unsigned char u8;
typedef int s32;
typedef unsigned int size_t;
