typedef short s16;
typedef int s32;
typedef float f32;
extern f32 game_GameFrame_2F;
