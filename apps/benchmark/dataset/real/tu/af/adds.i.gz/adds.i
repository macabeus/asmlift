typedef short s16;
void adds(s16* pValue, s16 target, s16 scale, s16 maxStep) {
    s16 diff = target - *pValue;
    diff /= scale;
    if (diff > maxStep) {
        *pValue += maxStep;
        return;
    }
    if (diff < -maxStep) {
        *pValue -= maxStep;
        return;
    }
    *pValue += diff;
}
