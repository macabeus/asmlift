
extern int signgam;
enum fdversion { fdlibm_ieee = -1, fdlibm_svid, fdlibm_xopen, fdlibm_posix };
extern enum fdversion _fdlib_version ;
struct exception {
int type;
char* name;
double arg1;
double arg2;
double retval;
};
extern double acos (double) ;
extern double asin (double) ;
extern double atan (double) ;
extern double atan2 (double, double) ;
extern double cos (double) ;
extern double sin (double) ;
extern double tan (double) ;
extern double cosh (double) ;
extern double sinh (double) ;
extern double tanh (double) ;
extern double exp (double) ;
extern double frexp (double, int*) ;
extern double ldexp (double, int) ;
extern double scalbn (double, int) ;
extern double log (double) ;
extern double log10 (double) ;
extern double modf (double, double*) ;
extern double pow (double, double) ;
extern double sqrt (double) ;
extern double ceil (double) ;
extern double fabs (double) ;
extern double fabs__Fd(double);
extern double floor (double) ;
extern double fmod (double, double) ;
extern double erf (double) ;
extern double erfc (double) ;
extern double gamma (double) ;
extern double hypot (double, double) ;
extern int isnan (double) ;
extern int finite (double) ;
extern double j0 (double) ;
extern double j1 (double) ;
extern double jn (int, double) ;
extern double lgamma (double) ;
extern double y0 (double) ;
extern double y1 (double) ;
extern double yn (int, double) ;
extern double acosh (double) ;
extern double asinh (double) ;
extern double atanh (double) ;
extern double cbrt (double) ;
extern double logb (double) ;
extern double nextafter (double, double) ;
extern double remainder (double, double) ;
extern double scalb (double, double) ;
extern int matherr (struct exception*) ;
extern double significand (double) ;
extern double copysign (double, double) ;
extern int ilogb (double) ;
extern double rint (double) ;
extern double scalbn (double, int) ;
extern double expm1 (double) ;
extern double log1p (double) ;
extern double __ieee754_sqrt (double) ;
extern double __ieee754_acos (double) ;
extern double __ieee754_acosh (double) ;
extern double __ieee754_log (double) ;
extern double __ieee754_atanh (double) ;
extern double __ieee754_asin (double) ;
extern double __ieee754_atan2 (double, double) ;
extern double __ieee754_exp (double) ;
extern double __ieee754_cosh (double) ;
extern double __ieee754_fmod (double, double) ;
extern double __ieee754_pow (double, double) ;
extern double __ieee754_lgamma_r (double, int*) ;
extern double __ieee754_gamma_r (double, int*) ;
extern double __ieee754_lgamma (double) ;
extern double __ieee754_gamma (double) ;
extern double __ieee754_log10 (double) ;
extern double __ieee754_sinh (double) ;
extern double __ieee754_hypot (double, double) ;
extern double __ieee754_j0 (double) ;
extern double __ieee754_j1 (double) ;
extern double __ieee754_y0 (double) ;
extern double __ieee754_y1 (double) ;
extern double __ieee754_jn (int, double) ;
extern double __ieee754_yn (int, double) ;
extern double __ieee754_remainder (double, double) ;
extern int __ieee754_rem_pio2 (double, double*) ;
extern double __ieee754_scalb (double, double) ;
extern double __kernel_standard (double, double, int) ;
extern double __kernel_sin (double, double, int) ;
extern double __kernel_cos (double, double) ;
extern double __kernel_tan (double, double, int) ;
extern int __kernel_rem_pio2 (double*, double*, int, int, int, const int*) ;
inline double fabs(double x);
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_max[];
extern unsigned long __float_epsilon[];
inline int __fpclassifyf(float __value);
inline int __fpclassifyd(double __value);
extern inline float sqrtf(float x);
inline float fabsf(float x);
extern inline double sqrt(double x);
typedef signed char s8;
typedef unsigned char u8;
typedef signed short int s16;
typedef unsigned short int u16;
typedef signed long s32;
typedef unsigned long u32;
typedef signed long long int s64;
typedef unsigned long long int u64;
typedef float f32;
typedef double f64;
typedef char *Ptr;
typedef unsigned int uintptr_t;
typedef int BOOL;
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, int type);
typedef unsigned long size_t;
typedef unsigned long __file_handle;
typedef unsigned long fpos_t;
typedef unsigned short wchar_t;
enum __file_kinds {
__closed_file,
__disk_file,
__console_file,
__string_file,
__unavailable_file = 3,
};
enum __file_orientation {
UNORIENTED,
CHAR_ORIENTED,
WIDE_ORIENTED,
};
typedef struct _file_modes {
unsigned int open_mode : 2;
unsigned int io_mode : 3;
unsigned int buffer_mode : 2;
unsigned int file_kind : 3;
unsigned int file_orientation : 2;
unsigned int binary_io : 1;
} file_modes;
enum __io_modes {
__read = 1,
__write = 2,
__read_write = 3,
__append = 4,
};
enum __io_states {
__neutral,
__writing,
__reading,
__rereading,
};
enum __io_results {
__no_io_error,
__io_error,
__io_EOF,
};
typedef struct _file_states {
unsigned int io_state : 3;
unsigned int free_buffer : 1;
unsigned char eof;
unsigned char error;
} file_states;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc idle_proc);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count, __idle_proc idle_proc);
typedef int (*__close_proc)(__file_handle file);
typedef struct _FILE {
__file_handle handle;
file_modes file_mode;
file_states file_state;
unsigned char char_buffer;
char char_buffer_overflow;
char ungetc_buffer[4];
wchar_t ungetc_wide_buffer[2];
unsigned long position;
unsigned char* buffer;
unsigned long buffer_size;
unsigned char* buffer_ptr;
unsigned long buffer_length;
unsigned long buffer_alignment;
unsigned long save_buffer_length;
unsigned long buffer_position;
__pos_proc position_fn;
__io_proc read_fn;
__io_proc write_fn;
__close_proc close_fn;
__idle_proc idle_fn;
void* next;
} FILE;
typedef struct _files {
FILE _stdin;
FILE _stdout;
FILE _stderr;
FILE _sentinel;
} files;
extern files __files;
int puts(const char *s);
int printf(const char *, ...);
int sprintf(char *s, const char *format, ...);
int vprintf(const char *format, va_list arg);
int vsprintf(char *s, const char *format, va_list arg);
size_t strlen(const char *s);
long strtol(const char *str, char **end, int base);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t num);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
char *strncat(char *dest, const char *src, size_t n);
char *strchr(const char *str, int c);
char* strrchr( char* str, int chr );
char* strstr(const char* str, const char* pat);
char* strcat(char* dst, const char* src);
int tolower(int c);
float powf(float x, float y);
float tanf(float);
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef unsigned int uint;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef void* unkptr;
typedef u32 unknown;
#pragma section RX "forcestrip"
typedef unsigned short wchar_t;
typedef float MtxF_t[4][4];
typedef union {
MtxF_t mf;
struct {
float xx, yx, zx, wx,
xy, yy, zy, wy,
xz, yz, zz, wz,
xw, yw, zw, ww;
};
} MtxF;
typedef struct {
f32 x, y, z;
} Vec3f;
typedef struct xy_s {
f32 x, y;
} xy_t;
typedef struct xz_s {
f32 x, z;
} xz_t;
typedef struct xyz_s {
f32 x, y, z;
} xyz_t;
typedef struct s_xyz_s {
s16 x, y, z;
} s_xyz;
typedef struct s_xz_s {
s16 x, z;
} s_xz;
typedef struct {
u32 r:8;
u32 g:8;
u32 b:8;
u32 a:8;
} rgba8888_t;
typedef union {
u32 rgba8888;
rgba8888_t c;
} rgba8888;
typedef union {
struct {
u8 r, g, b, a;
};
u32 rgba;
} Color_RGBA8_u32;
extern void Skin_Matrix_PrjMulVector(MtxF* mf, xyz_t* src, xyz_t* dst, f32* w);
extern void Skin_Matrix_MulMatrix(MtxF* mfA, MtxF* mfB, MtxF* dest);
extern void Skin_Matrix_SetScale(MtxF* mf, f32 x, f32 y, f32 z);
extern void Skin_Matrix_SetRotateXyz_s(MtxF* mf, s16 x, s16 y, s16 z);
extern void Skin_Matrix_SetTranslate(MtxF* mf, f32 x, f32 y, f32 z);
typedef struct game_play_s GAME_PLAY;
typedef u16 mActor_name_t;
typedef struct actor_s ACTOR;
typedef struct actor_profile_s ACTOR_PROFILE;
extern double sin(double deg);
extern double cos(double deg);
extern double tan(double deg);
float sinf(float);
float cosf(float);
inline float sinf(float x);
inline float cosf(float x);
extern double ceil(double);
u32 qrand(void);
void sqrand(u32);
f32 fqrand(void);
f32 fqrand2(void);
extern u16 U_GetAtanTable(f32 y, f32 x);
extern s16 atans_table(f32 x, f32 y);
extern f32 atanf_table(f32 x, f32 y);
extern void init_rnd();
extern f32 sinf_table(f32 x);
extern f32 cosf_table(f32 x);
typedef struct game_s GAME;
typedef struct {
size_t size;
char *buf_p;
char *head_p;
char *tail_p;
} TwoHeadArena_t;
typedef TwoHeadArena_t TwoHeadArena;
typedef TwoHeadArena_t THA;
extern void THA_ct(TwoHeadArena* tha, char* p, size_t n);
extern void THA_dt(TwoHeadArena* tha);
extern void* THA_getHeadPtr(TwoHeadArena* tha);
extern void THA_setHeadPtr(TwoHeadArena* tha, void* p);
extern void* THA_getTailPtr(TwoHeadArena* tha);
extern void* THA_nextPtrN(TwoHeadArena* tha, size_t n);
extern void* THA_nextPtr1(TwoHeadArena* tha);
extern void* THA_alloc(TwoHeadArena* tha, size_t siz);
extern void* THA_alloc16(TwoHeadArena* tha, size_t siz);
extern void* THA_allocAlign(TwoHeadArena* tha, size_t siz, int mask);
extern int THA_isCrash(TwoHeadArena* tha);
extern void THA_init(TwoHeadArena* tha);
extern int THA_getFreeBytes16(TwoHeadArena* tha);
extern int THA_getFreeBytes(TwoHeadArena* tha);
extern int THA_getFreeBytesAlign(TwoHeadArena* tha, int mask);
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef volatile unsigned char vu8;
typedef volatile unsigned short vu16;
typedef volatile unsigned long vu32;
typedef volatile unsigned long long vu64;
typedef volatile signed char vs8;
typedef volatile short vs16;
typedef volatile long vs32;
typedef volatile long long vs64;
typedef float f32;
typedef double f64;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
unsigned char cn[4];
} Vtx_t;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
signed char n[3];
unsigned char a;
} Vtx_tn;
typedef union {
Vtx_t v;
Vtx_tn n;
long long int force_structure_alignment;
} Vtx;
typedef struct {
void *SourceImagePointer;
void *TlutPointer;
short Stride;
short SubImageWidth;
short SubImageHeight;
char SourceImageType;
char SourceImageBitSize;
short SourceImageOffsetS;
short SourceImageOffsetT;
char dummy[4];
} uSprite_t;
typedef union {
uSprite_t s;
long long int force_structure_allignment[3];
} uSprite;
typedef struct {
unsigned char flag;
unsigned char v[3];
} Tri;
typedef long Mtx_t[4][4];
typedef union {
Mtx_t m;
long long int force_structure_alignment;
} Mtx;
typedef struct {
short vscale[4];
short vtrans[4];
} Vp_t;
typedef union {
Vp_t vp;
long long int force_structure_alignment;
} Vp;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
signed char dir[3];
char pad3;
} Light_t;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
} Ambient_t;
typedef struct {
int x1,y1,x2,y2;
} Hilite_t;
typedef union {
Light_t l;
long long int force_structure_alignment[2];
} Light;
typedef union {
Ambient_t l;
long long int force_structure_alignment[1];
} Ambient;
typedef struct {
Ambient a;
Light l[7];
} Lightsn;
typedef struct {
Ambient a;
Light l[1];
} Lights0;
typedef struct {
Ambient a;
Light l[1];
} Lights1;
typedef struct {
Ambient a;
Light l[2];
} Lights2;
typedef struct {
Ambient a;
Light l[3];
} Lights3;
typedef struct {
Ambient a;
Light l[4];
} Lights4;
typedef struct {
Ambient a;
Light l[5];
} Lights5;
typedef struct {
Ambient a;
Light l[6];
} Lights6;
typedef struct {
Ambient a;
Light l[7];
} Lights7;
typedef struct {
Light l[2];
} LookAt;
typedef union {
Hilite_t h;
long int force_structure_alignment[4];
} Hilite;
typedef struct {
int cmd:8;
unsigned int par:8;
unsigned int len:16;
unsigned int addr;
} Gdma;
typedef struct {
int cmd:8;
int pad:24;
Tri tri;
} Gtri;
typedef struct {
int cmd:8;
int pad1:24;
int pad2:24;
unsigned int param:8;
} Gpopmtx;
typedef struct {
int cmd:8;
int pad0:8;
int mw_index:8;
int number:8;
int pad1:8;
int base:24;
} Gsegment;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeL;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeH;
typedef struct {
unsigned char cmd;
unsigned char lodscale;
unsigned char tile;
unsigned char on;
unsigned short s;
unsigned short t;
} Gtexture;
typedef struct {
int cmd:8;
int pad:24;
Tri line;
} Gline3D;
typedef struct {
int cmd:8;
int pad1:24;
short int pad2;
short int scale;
} Gperspnorm;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad:7;
unsigned int wd:12;
unsigned int dram;
} Gsetimg;
typedef struct {
int cmd:8;
unsigned int muxs0:24;
unsigned int muxs1:32;
} Gsetcombine;
typedef struct {
int cmd:8;
unsigned char pad;
unsigned char prim_min_level;
unsigned char prim_level;
unsigned long color;
} Gsetcolor;
typedef struct {
int cmd:8;
int x0:10;
int x0frac:2;
int y0:10;
int y0frac:2;
unsigned int pad:8;
int x1:10;
int x1frac:2;
int y1:10;
int y1frac:2;
} Gfillrect;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad0:1;
unsigned int line:9;
unsigned int tmem:9;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int palette:4;
unsigned int ct:1;
unsigned int mt:1;
unsigned int maskt:4;
unsigned int shiftt:4;
unsigned int cs:1;
unsigned int ms:1;
unsigned int masks:4;
unsigned int shifts:4;
} Gsettile;
typedef struct {
int cmd:8;
unsigned int sl:12;
unsigned int tl:12;
int pad:5;
unsigned int tile:3;
unsigned int sh:12;
unsigned int th:12;
} Gloadtile;
typedef Gloadtile Gloadblock;
typedef Gloadtile Gsettilesize;
typedef Gloadtile Gloadtlut;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int s:16;
unsigned int t:16;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect;
typedef struct {
unsigned long w0;
unsigned long w1;
unsigned long w2;
unsigned long w3;
} TexRect;
typedef struct {
unsigned int w0;
unsigned int w1;
} Gwords;
typedef union {
Gwords words;
Gdma dma;
Gtri tri;
Gline3D line;
Gpopmtx popmtx;
Gsegment segment;
GsetothermodeH setothermodeH;
GsetothermodeL setothermodeL;
Gtexture texture;
Gperspnorm perspnorm;
Gsetimg setimg;
Gsetcombine setcombine;
Gsetcolor setcolor;
Gfillrect fillrect;
Gsettile settile;
Gloadtile loadtile;
Gsettilesize settilesize;
Gloadtlut loadtlut;
long long int force_structure_alignment;
} Gfx;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Aadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Apolef;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvelope;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmem:16;
unsigned int pad2:16;
unsigned int count:16;
} Aclearbuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int inL:16;
unsigned int inR:16;
} Ainterleave;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Aloadbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvmixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int dmemi:16;
unsigned int dmemo:16;
} Amixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmem2:16;
unsigned int addr;
} Apan;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pitch:16;
unsigned int addr;
} Aresample;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Areverb;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Asavebuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int pad2:2;
unsigned int number:4;
unsigned int base:24;
} Asegment;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Asetbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int vol:16;
unsigned int voltgt:16;
unsigned int volrate:16;
} Asetvol;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Admemmove;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int count:16;
unsigned int addr;
} Aloadadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int addr;
} Asetloop;
typedef struct {
unsigned int w0;
unsigned int w1;
} Awords;
typedef union {
Awords words;
Aadpcm adpcm;
Apolef polef;
Aclearbuff clearbuff;
Aenvelope envelope;
Ainterleave interleave;
Aloadbuff loadbuff;
Aenvmixer envmixer;
Aresample resample;
Areverb reverb;
Asavebuff savebuff;
Asegment segment;
Asetbuff setbuff;
Asetvol setvol;
Admemmove dmemmove;
Aloadadpcm loadadpcm;
Amixer mixer;
Asetloop setloop;
long long int force_union_align;
} Acmd;
typedef short ADPCM_STATE[16 ];
typedef short POLEF_STATE[4];
typedef short RESAMPLE_STATE[16];
typedef short ENVMIX_STATE[40];
typedef struct {
size_t size;
Gfx* buf_p;
Gfx* head_p;
Gfx* tail_p;
} TwoHeadArenaGfx_t;
typedef TwoHeadArenaGfx_t TwoHeadArenaGfx;
typedef union {
TwoHeadArena tha;
TwoHeadArenaGfx thaGfx;
} THA_GA_t;
typedef THA_GA_t THA_GA;
extern void THA_GA_ct(THA_GA* tha_ga, Gfx* p, size_t n);
extern void THA_GA_dt(THA_GA* tha_ga);
extern int THA_GA_isCrash(THA_GA* tha_ga);
extern void THA_GA_init(THA_GA* tha_ga);
extern int THA_GA_getFreeBytes(THA_GA* tha_ga);
extern void* THA_GA_getTailPtr(THA_GA* tha_ga);
extern void* THA_GA_nextPtrN(THA_GA* tha_ga, size_t n);
extern void* THA_GA_nextPtr1(THA_GA* tha_ga);
extern Gfx* THA_GA_NEXT_DISP(THA_GA* tha_ga);
extern void* THA_GA_getHeadPtr(THA_GA* tha_ga);
extern void THA_GA_setHeadPtr(THA_GA* tha_ga, void *p);
extern Mtx* THA_GA_alloc(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtxN(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtx1(THA_GA* tha_ga);
extern Vtx* THA_GA_allocVtxN(THA_GA* tha_ga, size_t n);
extern Vtx* THA_GA_allocVtx1(THA_GA* tha_ga);
typedef struct OSContext
{
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
u32 fpscr_pad;
u32 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
u32 OSGetStackPointer(void);
void OSDumpContext(OSContext *context);
void OSLoadContext(OSContext *context);
u32 OSSaveContext(OSContext *context);
void OSClearContext(OSContext *context);
OSContext *OSGetCurrentContext(void);
void OSSetCurrentContext(OSContext *context);
void OSLoadFPUContext(OSContext *fpuContext);
void OSSaveFPUContext(OSContext *fpuContext);
u32 OSSwitchStack(u32 newsp);
int OSSwitchFiber(u32 pc, u32 newsp);
void OSInitContext(OSContext *context, u32 pc, u32 newsp);
void OSFillFPUContext(OSContext *context);
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef s32 OSPriority;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef struct OSCond OSCond;
typedef void (*OSIdleFunction)(void *param);
struct OSThreadQueue
{
OSThread *head;
OSThread *tail;
};
struct OSThreadLink
{
OSThread *next;
OSThread *prev;
};
struct OSMutexQueue
{
OSMutex *head;
OSMutex *tail;
};
struct OSMutexLink
{
OSMutex *next;
OSMutex *prev;
};
struct OSThread
{
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void *val;
OSThreadQueue *queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex *mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8 *stackBase;
u32 *stackEnd;
};
enum OS_THREAD_STATE
{
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8
};
void OSInitThreadQueue(OSThreadQueue *queue);
OSThread *OSGetCurrentThread(void);
BOOL OSIsThreadSuspended(OSThread *thread);
BOOL OSIsThreadTerminated(OSThread *thread);
s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);
void OSYieldThread(void);
BOOL OSCreateThread(OSThread *thread,
void *(*func)(void *),
void *param,
void *stack,
u32 stackSize,
OSPriority priority,
u16 attr);
void OSExitThread(void *val);
void OSCancelThread(OSThread *thread);
BOOL OSJoinThread(OSThread *thread, void **val);
void OSDetachThread(OSThread *thread);
s32 OSResumeThread(OSThread *thread);
s32 OSSuspendThread(OSThread *thread);
BOOL OSSetThreadPriority(OSThread *thread, OSPriority priority);
OSPriority OSGetThreadPriority(OSThread *thread);
void OSSleepThread(OSThreadQueue *queue);
void OSWakeupThread(OSThreadQueue *queue);
OSThread *OSSetIdleFunction(OSIdleFunction idleFunction,
void *param,
void *stack,
u32 stackSize);
OSThread *OSGetIdleFunction(void);
long OSCheckActiveThreads(void);
typedef struct OSMessageQueue OSMessageQueue;
typedef void* OSMessage;
struct OSMessageQueue {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
int msgCount;
int firstIndex;
int usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, int msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, int flags);
typedef struct OSModuleHeader OSModuleHeader;
typedef u32 OSModuleID;
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
OSModuleQueue __OSModuleList : (0x800030C8) ;
void* __OSStringTable : (0x800030D0) ;
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u8 bssSection;
u32 prolog;
u32 epilog;
u32 unresolved;
u32 align;
u32 bssAlign;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSLinkFixed(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* module);
void OSSetStringTable(const void* string_table);
void __OSModuleInit(void);
typedef s64 OSTime;
typedef u32 OSTick;
OSTime OSGetTime(void);
OSTime __OSGetSystemTime(void);
OSTick OSGetTick(void);
typedef struct OSCalendarTime_s {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* td);
typedef struct boot_tbl_s {
const char* msg;
u16 param_upper;
u16 param_lower;
} boot_tbl_t;
extern u32 convert_partial_address(u32 partial_addr);
extern void HotResetIplMenu();
extern void* boot_copyDate;
extern void* HotStartEntry;
extern OSTime InitialStartTime;
extern u8 boot_sound_initializing;
typedef void(*HotStartProc)();
OSModuleHeader* BaseModule : (0x800030C8) ;
typedef enum {
GRAPH_DOING_ZERO = 0,
GRAPH_DOING_CT,
GRAPH_DOING_GAME_CT,
GRAPH_DOING_GAME_CT_FINISHED,
GRAPH_DOING_GAME_MAIN,
GRAPH_DOING_GAME_TIME,
GRAPH_DOING_GAME_TIME_FINISHED,
GRAPH_DOING_GAME_EXEC,
GRAPH_DOING_GAME_EXEC_FINISHED,
GRAPH_DOING_GAME_BGM,
GRAPH_DOING_GAME_BGM_FINISHED,
GRAPH_DOING_GAME_MAIN_FINISHED,
GRAPH_DOING_TASK_SET,
GRAPH_DOING_WAIT_TASK,
GRAPH_DOING_WAIT_TASK_FINISHED,
GRAPH_DOING_TASK_SET_FINISHED,
GRAPH_DOING_AUDIO,
GRAPH_DOING_AUDIO_FINISHED,
GRAPH_DOING_GAME_18,
GRAPH_DOING_GAME_DT,
GRAPH_DOING_GAME_DT_FINISHED,
GRAPH_DOING_DT,
GRAPH_DOING_END
} GRAPH_DOING_POINT;
typedef struct graph_s {
Gfx* Gfx_list00;
Gfx* Gfx_list01;
void* DepthBuffer;
Gfx* Gfx_list03;
Gfx* Gfx_list04;
Gfx* Gfx_list07;
Gfx* Gfx_list08;
Gfx* Gfx_list09;
Gfx* gfxsave;
u8 _unk24[32];
OSMessage graphReplyMesgBuf[8 ];
OSMessageQueue* schedMesgQueue;
OSMessageQueue graphReplyMesgQueue;
u8 _unused_ossctask00p[0x68];
u8 _unused_ossctask01p[0x68];
u8 _unused_ossctask02p[0x68];
Gfx* Gfx_list05;
THA_GA work_thaga;
u8 _unk1D4[0xBC];
void* scheduler;
void* vimode;
THA_GA line_opaque_thaga;
THA_GA line_translucent_thaga;
THA_GA overlay_thaga;
THA_GA polygon_opaque_thaga;
THA_GA polygon_translucent_thaga;
THA_GA font_thaga;
THA_GA shadow_thaga;
THA_GA light_thaga;
THA_GA bg_opaque_thaga;
THA_GA bg_translucent_thaga;
int frame_counter;
u16* frameBuffer;
u16* renderBuffer;
u32 vispecial;
u8 doing_point;
u8 _unk349;
u8 need_viupdate;
u8 cfb_bank;
void (*taskEndCallback)(struct graph_s*, void*);
void* taskEndData;
f32 vixscale;
f32 viyscale;
Gfx* last_dl;
Gfx* Gfx_list10;
Gfx* Gfx_list11;
} GRAPH __attribute__((aligned(8))) ;
extern void graph_proc(void* arg);
extern void graph_ct(GRAPH* graph);
extern void graph_dt(GRAPH* graph);
extern u8 SoftResetEnable;
extern GRAPH graph_class;
typedef struct gameAllocList_s {
struct gameAllocList_s* next;
struct gameAllocList_s* prev;
size_t alloc_size;
u32 pad;
} GameAllocList;
typedef struct gameAlloc_s {
GameAllocList head;
GameAllocList* tail;
} GameAlloc;
extern void* gamealloc_malloc(GameAlloc* gamealloc, size_t size);
extern void gamealloc_free(GameAlloc* gamealloc, void* ptr);
extern void gamealloc_cleanup(GameAlloc* gamealloc);
extern void gamealloc_init(GameAlloc* gamealloc);
typedef struct {
u16 type;
u8 status;
u8 errno;
} OSContStatus;
typedef struct {
u16 button;
s8 stick_x;
s8 stick_y;
u8 errno;
} OSContPad;
typedef struct {
OSContPad pad;
s8 substickX;
s8 substickY;
u8 triggerR;
u8 triggerL;
} OSContPadEx;
extern s32 osContInit(OSMessageQueue* mq, u8* pattern_p, OSContStatus* status);
extern s32 osContStartQuery(OSMessageQueue* mq);
extern s32 osContStartReadData(OSMessageQueue* mq);
extern void osContGetQuery(OSContStatus* status);
extern s32 osContSetCh(u8 num_controllers);
extern void osContGetReadData(OSContPad* pad);
extern void osContGetReadDataEx(OSContPadEx* pad);
typedef struct {
OSContPad now;
OSContPad last;
OSContPad on;
OSContPad off;
} pad_t;
int pad_physical_stick_x(pad_t*);
int pad_physical_stick_y(pad_t*);
void pad_set_logical_stick(pad_t*, int, int);
void pad_correct_stick(pad_t*);
typedef struct controller_s {
f32 move_pX;
f32 move_pY;
f32 move_pR;
s16 move_angle;
f32 last_move_pX;
f32 last_move_pY;
f32 last_move_pR;
s16 last_move_angle;
f32 adjusted_pX;
f32 adjusted_pY;
f32 adjusted_pR;
f32 last_adjusted_pX;
f32 last_adjusted_pY;
f32 last_adjusted_pR;
} MCON;
extern void mCon_ct();
extern void mCon_dt();
extern void mCon_calc(MCON* mcon, f32 stick_x, f32 stick_y);
extern void mCon_main(GAME* game);
extern int chkButton(u16 button);
extern u16 getButton();
extern int chkTrigger(u16 button);
extern u16 getTrigger();
extern int getJoystick_X();
extern int getJoystick_Y();
struct game_s {
GRAPH* graph;
void (*exec)(struct game_s* );
void (*cleanup)(struct game_s*);
void (*next_game_init)(struct game_s*);
size_t next_game_class_size;
pad_t pads[4 ];
int pad_initialized;
THA tha;
GameAlloc gamealloc;
u8 doing_point;
u8 doing_point_specific;
u8 disable_display;
u8 doing;
u32 frame_counter;
int disable_prenmi;
MCON mcon;
};
extern void game_debug_draw_last(GAME* game, GRAPH* graph);
extern void game_draw_last(GRAPH* graph);
extern void game_get_controller(GAME* game);
extern void SetGameFrame(int frame);
extern void game_main(GAME* game);
extern void game_resize_hyral(GAME* game, int size);
extern void game_ct(GAME* game, void (*init)(GAME*), GRAPH* graph);
extern void game_dt(GAME* game);
extern void (*game_get_next_game_init(GAME* game))(GAME*);
extern int game_is_doing(GAME* game);
extern int game_getFreeBytes(GAME* game);
extern void game_goto_next_game_play(GAME* game);
extern GAME* gamePT;
extern GAME* game_class_p;
extern u8 game_GameFrame;
extern float game_GameFrameF;
extern float game_GameFrame_2F;
extern float game_GameFrame__1F;
typedef struct rgba_t {
u8 r, g, b, a;
} rgba_t;
typedef struct rgb_t {
uint r, g, b;
} rgb_t;
typedef struct rgb8_t {
u8 r, g, b;
} rgb8_t;
typedef struct {
xyz_t position;
s_xyz angle;
} PositionAngle;
extern void mem_copy(u8* dst, u8* src, size_t size);
extern void mem_clear(u8* dst, size_t size, u8 val);
extern int mem_cmp(u8* p1, u8* p2, size_t size);
extern f32 cos_s(s16 angle);
extern f32 sin_s(s16 angle);
extern int chase_angle(s16* const pValue, const s16 target, s16 step);
extern int chase_s(s16* const pValue, const s16 target, s16 step);
extern int chase_f(f32* const pValue, const f32 target, f32 step);
extern f32 chase_xyz_t(xyz_t* const pValue, const xyz_t* const target, const f32 fraction);
extern int chase_angle2(s16* const pValue, const s16 limit, const s16 step);
extern void inter_float(f32* const pValue, const f32 arg1, const int step);
extern s16 get_random_timer(const s16 base, const s16 range);
extern void xyz_t_move(xyz_t* const dest, const xyz_t* const src);
extern void xyz_t_move_s_xyz(xyz_t* const dest, const s_xyz* const src);
extern void xyz_t_add(const xyz_t* const augend, const xyz_t* const addend, xyz_t* const total);
extern void xyz_t_sub(const xyz_t* const minuend, const xyz_t* const subtrahend, xyz_t* const diff);
extern void xyz_t_mult_v(xyz_t* const multiplicand, const f32 multiplier);
extern f32 search_position_distance(const xyz_t* const pos, const xyz_t* const target);
extern f32 search_position_distanceXZ(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleY(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleX(const xyz_t* const pos, const xyz_t* const target);
extern f32 add_calc(f32* pValue, f32 target, f32 fraction, f32 maxStep, f32 minStep);
extern void add_calc2(f32* pValue, f32 target, f32 fraction, f32 maxStep);
extern void add_calc0(f32* pValue, f32 fraction, f32 maxStep);
extern s16 add_calc_short_angle2(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern s16 add_calc_short_angle3(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern void rgba_t_move(rgba_t* dest, const rgba_t* const src);
extern int none_proc1();
extern void none_proc2(ACTOR* actor, GAME* game);
extern int _Game_play_isPause(GAME_PLAY* play);
extern f32 check_percent_abs(f32 x, f32 min, f32 max, f32 scale, int shift_by_min);
extern f32 get_percent_forAccelBrake(f32 now, f32 start, f32 end, f32 accelerateDist, f32 brakeDist);
extern void Game_play_Projection_Trans(GAME_PLAY* const play, xyz_t* world_pos, xyz_t* screen_pos);
extern f32 get_percent(const int max, const int min, const int x);
