
extern int signgam;
enum fdversion { fdlibm_ieee = -1, fdlibm_svid, fdlibm_xopen, fdlibm_posix };
extern enum fdversion _fdlib_version ;
struct exception {
int type;
char* name;
double arg1;
double arg2;
double retval;
};
extern double acos (double) ;
extern double asin (double) ;
extern double atan (double) ;
extern double atan2 (double, double) ;
extern double cos (double) ;
extern double sin (double) ;
extern double tan (double) ;
extern double cosh (double) ;
extern double sinh (double) ;
extern double tanh (double) ;
extern double exp (double) ;
extern double frexp (double, int*) ;
extern double ldexp (double, int) ;
extern double scalbn (double, int) ;
extern double log (double) ;
extern double log10 (double) ;
extern double modf (double, double*) ;
extern double pow (double, double) ;
extern double sqrt (double) ;
extern double ceil (double) ;
extern double fabs (double) ;
extern double fabs__Fd(double);
extern double floor (double) ;
extern double fmod (double, double) ;
extern double erf (double) ;
extern double erfc (double) ;
extern double gamma (double) ;
extern double hypot (double, double) ;
extern int isnan (double) ;
extern int finite (double) ;
extern double j0 (double) ;
extern double j1 (double) ;
extern double jn (int, double) ;
extern double lgamma (double) ;
extern double y0 (double) ;
extern double y1 (double) ;
extern double yn (int, double) ;
extern double acosh (double) ;
extern double asinh (double) ;
extern double atanh (double) ;
extern double cbrt (double) ;
extern double logb (double) ;
extern double nextafter (double, double) ;
extern double remainder (double, double) ;
extern double scalb (double, double) ;
extern int matherr (struct exception*) ;
extern double significand (double) ;
extern double copysign (double, double) ;
extern int ilogb (double) ;
extern double rint (double) ;
extern double scalbn (double, int) ;
extern double expm1 (double) ;
extern double log1p (double) ;
extern double __ieee754_sqrt (double) ;
extern double __ieee754_acos (double) ;
extern double __ieee754_acosh (double) ;
extern double __ieee754_log (double) ;
extern double __ieee754_atanh (double) ;
extern double __ieee754_asin (double) ;
extern double __ieee754_atan2 (double, double) ;
extern double __ieee754_exp (double) ;
extern double __ieee754_cosh (double) ;
extern double __ieee754_fmod (double, double) ;
extern double __ieee754_pow (double, double) ;
extern double __ieee754_lgamma_r (double, int*) ;
extern double __ieee754_gamma_r (double, int*) ;
extern double __ieee754_lgamma (double) ;
extern double __ieee754_gamma (double) ;
extern double __ieee754_log10 (double) ;
extern double __ieee754_sinh (double) ;
extern double __ieee754_hypot (double, double) ;
extern double __ieee754_j0 (double) ;
extern double __ieee754_j1 (double) ;
extern double __ieee754_y0 (double) ;
extern double __ieee754_y1 (double) ;
extern double __ieee754_jn (int, double) ;
extern double __ieee754_yn (int, double) ;
extern double __ieee754_remainder (double, double) ;
extern int __ieee754_rem_pio2 (double, double*) ;
extern double __ieee754_scalb (double, double) ;
extern double __kernel_standard (double, double, int) ;
extern double __kernel_sin (double, double, int) ;
extern double __kernel_cos (double, double) ;
extern double __kernel_tan (double, double, int) ;
extern int __kernel_rem_pio2 (double*, double*, int, int, int, const int*) ;
inline double fabs(double x);
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_max[];
extern unsigned long __float_epsilon[];
inline int __fpclassifyf(float __value);
inline int __fpclassifyd(double __value);
extern inline float sqrtf(float x);
inline float fabsf(float x);
extern inline double sqrt(double x);
typedef signed char s8;
typedef unsigned char u8;
typedef signed short int s16;
typedef unsigned short int u16;
typedef signed long s32;
typedef unsigned long u32;
typedef signed long long int s64;
typedef unsigned long long int u64;
typedef float f32;
typedef double f64;
typedef char *Ptr;
typedef unsigned int uintptr_t;
typedef int BOOL;
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, int type);
typedef unsigned long size_t;
typedef unsigned long __file_handle;
typedef unsigned long fpos_t;
typedef unsigned short wchar_t;
enum __file_kinds {
__closed_file,
__disk_file,
__console_file,
__string_file,
__unavailable_file = 3,
};
enum __file_orientation {
UNORIENTED,
CHAR_ORIENTED,
WIDE_ORIENTED,
};
typedef struct _file_modes {
unsigned int open_mode : 2;
unsigned int io_mode : 3;
unsigned int buffer_mode : 2;
unsigned int file_kind : 3;
unsigned int file_orientation : 2;
unsigned int binary_io : 1;
} file_modes;
enum __io_modes {
__read = 1,
__write = 2,
__read_write = 3,
__append = 4,
};
enum __io_states {
__neutral,
__writing,
__reading,
__rereading,
};
enum __io_results {
__no_io_error,
__io_error,
__io_EOF,
};
typedef struct _file_states {
unsigned int io_state : 3;
unsigned int free_buffer : 1;
unsigned char eof;
unsigned char error;
} file_states;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc idle_proc);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count, __idle_proc idle_proc);
typedef int (*__close_proc)(__file_handle file);
typedef struct _FILE {
__file_handle handle;
file_modes file_mode;
file_states file_state;
unsigned char char_buffer;
char char_buffer_overflow;
char ungetc_buffer[4];
wchar_t ungetc_wide_buffer[2];
unsigned long position;
unsigned char* buffer;
unsigned long buffer_size;
unsigned char* buffer_ptr;
unsigned long buffer_length;
unsigned long buffer_alignment;
unsigned long save_buffer_length;
unsigned long buffer_position;
__pos_proc position_fn;
__io_proc read_fn;
__io_proc write_fn;
__close_proc close_fn;
__idle_proc idle_fn;
void* next;
} FILE;
typedef struct _files {
FILE _stdin;
FILE _stdout;
FILE _stderr;
FILE _sentinel;
} files;
extern files __files;
int puts(const char *s);
int printf(const char *, ...);
int sprintf(char *s, const char *format, ...);
int vprintf(const char *format, va_list arg);
int vsprintf(char *s, const char *format, va_list arg);
size_t strlen(const char *s);
long strtol(const char *str, char **end, int base);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t num);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
char *strncat(char *dest, const char *src, size_t n);
char *strchr(const char *str, int c);
char* strrchr( char* str, int chr );
char* strstr(const char* str, const char* pat);
char* strcat(char* dst, const char* src);
int tolower(int c);
float powf(float x, float y);
float tanf(float);
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef unsigned int uint;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef void* unkptr;
typedef u32 unknown;
#pragma section RX "forcestrip"
typedef unsigned short wchar_t;
typedef s64 OSTime;
typedef u32 OSTick;
OSTime OSGetTime(void);
OSTime __OSGetSystemTime(void);
OSTick OSGetTick(void);
typedef struct OSCalendarTime_s {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* td);
typedef struct OSRTCTime {
u8 sec;
u8 min;
u8 hour;
u8 day;
u8 weekday;
u8 month;
u16 year;
} OSRTCTime;
typedef u8 lbRTC_sec_t;
typedef u8 lbRTC_min_t;
typedef u8 lbRTC_hour_t;
typedef u8 lbRTC_day_t;
typedef u8 lbRTC_weekday_t;
typedef u8 lbRTC_month_t;
typedef u16 lbRTC_year_t;
typedef OSRTCTime lbRTC_time_c;
typedef struct lbRTC_ymd_s {
lbRTC_year_t year;
lbRTC_month_t month;
lbRTC_day_t day;
} lbRTC_ymd_c;
enum WEEKDAYS {
lbRTC_WEEKDAYS_BEGIN = 0,
lbRTC_SUNDAY = lbRTC_WEEKDAYS_BEGIN,
lbRTC_MONDAY,
lbRTC_TUESDAY,
lbRTC_WEDNESDAY,
lbRTC_THURSDAY,
lbRTC_FRIDAY,
lbRTC_SATURDAY,
lbRTC_WEEK,
lbRTC_WEEKDAYS_MAX = lbRTC_WEEK
};
enum MONTHS {
lbRTC_MONTHS_BEGIN = 0,
lbRTC_JANUARY = 1,
lbRTC_FEBRUARY,
lbRTC_MARCH,
lbRTC_APRIL,
lbRTC_MAY,
lbRTC_JUNE,
lbRTC_JULY,
lbRTC_AUGUST,
lbRTC_SEPTEMBER,
lbRTC_OCTOBER,
lbRTC_NOVEMBER,
lbRTC_DECEMBER,
lbRTC_MONTHS_MAX = lbRTC_DECEMBER
};
enum RTC_EQUALITY {
lbRTC_LESS = -1,
lbRTC_EQUAL = 0,
lbRTC_OVER = 1
};
enum RTC_EQUALITY_FLAGS {
lbRTC_CHECK_NONE = 0,
lbRTC_CHECK_SECONDS = 1 << 0,
lbRTC_CHECK_MINUTES = 1 << 1,
lbRTC_CHECK_HOURS = 1 << 2,
lbRTC_CHECK_WEEKDAYS = 1 << 3,
lbRTC_CHECK_DAYS = 1 << 4,
lbRTC_CHECK_MONTHS = 1 << 5,
lbRTC_CHECK_YEARS = 1 << 6,
lbRTC_CHECK_ALL = lbRTC_CHECK_SECONDS |
lbRTC_CHECK_MINUTES |
lbRTC_CHECK_HOURS |
lbRTC_CHECK_WEEKDAYS |
lbRTC_CHECK_DAYS |
lbRTC_CHECK_MONTHS |
lbRTC_CHECK_YEARS
};
extern OSTime lbRTC_HardTime();
extern int lbRTC_IsAbnormal();
extern void lbRTC_Sampling();
extern void lbRTC_SetTime(lbRTC_time_c* time);
extern void lbRTC_GetTime(lbRTC_time_c* time);
extern lbRTC_day_t lbRTC_GetDaysByMonth(lbRTC_year_t year, lbRTC_month_t month);
extern int lbRTC_IsEqualDate(
lbRTC_year_t y0, lbRTC_month_t m0, lbRTC_day_t d0,
lbRTC_year_t y1, lbRTC_month_t m1, lbRTC_day_t d1
);
extern int lbRTC_IsEqualTime(const lbRTC_time_c* t0, const lbRTC_time_c* t1, int flags);
extern int lbRTC_IsOverTime(const lbRTC_time_c* t0, const lbRTC_time_c* t1);
extern int lbRTC_IsOverRTC(const lbRTC_time_c* time);
extern int lbRTC_IntervalTime(const lbRTC_time_c* time0, const lbRTC_time_c* time1);
extern int lbRTC_GetIntervalDays(const lbRTC_time_c* t0, const lbRTC_time_c* t1);
extern int lbRTC_GetIntervalDays2(lbRTC_ymd_c* ymd0, lbRTC_ymd_c* ymd1);
extern void lbRTC_Add_YY(lbRTC_time_c* time, int year);
extern void lbRTC_Add_MM(lbRTC_time_c* time, int month);
extern void lbRTC_Add_DD(lbRTC_time_c* time, int day);
extern void lbRTC_Add_hh(lbRTC_time_c* time, int hour);
extern void lbRTC_Add_mm(lbRTC_time_c* time, int min);
extern void lbRTC_Add_ss(lbRTC_time_c* time, int sec);
extern void lbRTC_Add_Date(lbRTC_time_c* time, const lbRTC_time_c* add_time);
extern void lbRTC_Sub_YY(lbRTC_time_c* time, int year);
extern void lbRTC_Sub_MM(lbRTC_time_c* time, int month);
extern void lbRTC_Sub_DD(lbRTC_time_c* time, int days);
extern void lbRTC_Sub_hh(lbRTC_time_c* time, int hour);
extern void lbRTC_Sub_mm(lbRTC_time_c* time, int min);
extern void lbRTC_Sub_ss(lbRTC_time_c* time, int sec);
extern lbRTC_weekday_t lbRTC_Week(lbRTC_year_t year, lbRTC_month_t month, lbRTC_day_t day);
extern void lbRTC_TimeCopy(lbRTC_time_c* dst, const lbRTC_time_c* src);
extern int lbRTC_IsValidTime(const lbRTC_time_c* time);
extern int lbRTC_time_c_save_data_check(const lbRTC_time_c* time);
extern int lbRTC_Weekly_day(lbRTC_year_t year, lbRTC_month_t month, int weeks, int weekday);
extern int lbRk_ToSeiyouReki(lbRTC_ymd_c* seiyo_ymd, lbRTC_ymd_c* kyuu_ymd);
extern int lbRk_ToKyuuReki(lbRTC_ymd_c* kyuu_ymd, lbRTC_ymd_c* seiyo_ymd);
extern int lbRk_VernalEquinoxDay(int year);
extern int lbRk_AutumnalEquinoxDay(int year);
extern void lbRk_HarvestMoonDay(lbRTC_ymd_c* harvest_moon_day, int year);
