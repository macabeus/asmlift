
extern int signgam;
enum fdversion { fdlibm_ieee = -1, fdlibm_svid, fdlibm_xopen, fdlibm_posix };
extern enum fdversion _fdlib_version ;
struct exception {
int type;
char* name;
double arg1;
double arg2;
double retval;
};
extern double acos (double) ;
extern double asin (double) ;
extern double atan (double) ;
extern double atan2 (double, double) ;
extern double cos (double) ;
extern double sin (double) ;
extern double tan (double) ;
extern double cosh (double) ;
extern double sinh (double) ;
extern double tanh (double) ;
extern double exp (double) ;
extern double frexp (double, int*) ;
extern double ldexp (double, int) ;
extern double scalbn (double, int) ;
extern double log (double) ;
extern double log10 (double) ;
extern double modf (double, double*) ;
extern double pow (double, double) ;
extern double sqrt (double) ;
extern double ceil (double) ;
extern double fabs (double) ;
extern double fabs__Fd(double);
extern double floor (double) ;
extern double fmod (double, double) ;
extern double erf (double) ;
extern double erfc (double) ;
extern double gamma (double) ;
extern double hypot (double, double) ;
extern int isnan (double) ;
extern int finite (double) ;
extern double j0 (double) ;
extern double j1 (double) ;
extern double jn (int, double) ;
extern double lgamma (double) ;
extern double y0 (double) ;
extern double y1 (double) ;
extern double yn (int, double) ;
extern double acosh (double) ;
extern double asinh (double) ;
extern double atanh (double) ;
extern double cbrt (double) ;
extern double logb (double) ;
extern double nextafter (double, double) ;
extern double remainder (double, double) ;
extern double scalb (double, double) ;
extern int matherr (struct exception*) ;
extern double significand (double) ;
extern double copysign (double, double) ;
extern int ilogb (double) ;
extern double rint (double) ;
extern double scalbn (double, int) ;
extern double expm1 (double) ;
extern double log1p (double) ;
extern double __ieee754_sqrt (double) ;
extern double __ieee754_acos (double) ;
extern double __ieee754_acosh (double) ;
extern double __ieee754_log (double) ;
extern double __ieee754_atanh (double) ;
extern double __ieee754_asin (double) ;
extern double __ieee754_atan2 (double, double) ;
extern double __ieee754_exp (double) ;
extern double __ieee754_cosh (double) ;
extern double __ieee754_fmod (double, double) ;
extern double __ieee754_pow (double, double) ;
extern double __ieee754_lgamma_r (double, int*) ;
extern double __ieee754_gamma_r (double, int*) ;
extern double __ieee754_lgamma (double) ;
extern double __ieee754_gamma (double) ;
extern double __ieee754_log10 (double) ;
extern double __ieee754_sinh (double) ;
extern double __ieee754_hypot (double, double) ;
extern double __ieee754_j0 (double) ;
extern double __ieee754_j1 (double) ;
extern double __ieee754_y0 (double) ;
extern double __ieee754_y1 (double) ;
extern double __ieee754_jn (int, double) ;
extern double __ieee754_yn (int, double) ;
extern double __ieee754_remainder (double, double) ;
extern int __ieee754_rem_pio2 (double, double*) ;
extern double __ieee754_scalb (double, double) ;
extern double __kernel_standard (double, double, int) ;
extern double __kernel_sin (double, double, int) ;
extern double __kernel_cos (double, double) ;
extern double __kernel_tan (double, double, int) ;
extern int __kernel_rem_pio2 (double*, double*, int, int, int, const int*) ;
inline double fabs(double x);
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_max[];
extern unsigned long __float_epsilon[];
inline int __fpclassifyf(float __value);
inline int __fpclassifyd(double __value);
extern inline float sqrtf(float x);
inline float fabsf(float x);
extern inline double sqrt(double x);
typedef signed char s8;
typedef unsigned char u8;
typedef signed short int s16;
typedef unsigned short int u16;
typedef signed long s32;
typedef unsigned long u32;
typedef signed long long int s64;
typedef unsigned long long int u64;
typedef float f32;
typedef double f64;
typedef char *Ptr;
typedef unsigned int uintptr_t;
typedef int BOOL;
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, int type);
typedef unsigned long size_t;
typedef unsigned long __file_handle;
typedef unsigned long fpos_t;
typedef unsigned short wchar_t;
enum __file_kinds {
__closed_file,
__disk_file,
__console_file,
__string_file,
__unavailable_file = 3,
};
enum __file_orientation {
UNORIENTED,
CHAR_ORIENTED,
WIDE_ORIENTED,
};
typedef struct _file_modes {
unsigned int open_mode : 2;
unsigned int io_mode : 3;
unsigned int buffer_mode : 2;
unsigned int file_kind : 3;
unsigned int file_orientation : 2;
unsigned int binary_io : 1;
} file_modes;
enum __io_modes {
__read = 1,
__write = 2,
__read_write = 3,
__append = 4,
};
enum __io_states {
__neutral,
__writing,
__reading,
__rereading,
};
enum __io_results {
__no_io_error,
__io_error,
__io_EOF,
};
typedef struct _file_states {
unsigned int io_state : 3;
unsigned int free_buffer : 1;
unsigned char eof;
unsigned char error;
} file_states;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc idle_proc);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count, __idle_proc idle_proc);
typedef int (*__close_proc)(__file_handle file);
typedef struct _FILE {
__file_handle handle;
file_modes file_mode;
file_states file_state;
unsigned char char_buffer;
char char_buffer_overflow;
char ungetc_buffer[4];
wchar_t ungetc_wide_buffer[2];
unsigned long position;
unsigned char* buffer;
unsigned long buffer_size;
unsigned char* buffer_ptr;
unsigned long buffer_length;
unsigned long buffer_alignment;
unsigned long save_buffer_length;
unsigned long buffer_position;
__pos_proc position_fn;
__io_proc read_fn;
__io_proc write_fn;
__close_proc close_fn;
__idle_proc idle_fn;
void* next;
} FILE;
typedef struct _files {
FILE _stdin;
FILE _stdout;
FILE _stderr;
FILE _sentinel;
} files;
extern files __files;
int puts(const char *s);
int printf(const char *, ...);
int sprintf(char *s, const char *format, ...);
int vprintf(const char *format, va_list arg);
int vsprintf(char *s, const char *format, va_list arg);
size_t strlen(const char *s);
long strtol(const char *str, char **end, int base);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t num);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
char *strncat(char *dest, const char *src, size_t n);
char *strchr(const char *str, int c);
char* strrchr( char* str, int chr );
char* strstr(const char* str, const char* pat);
char* strcat(char* dst, const char* src);
int tolower(int c);
float powf(float x, float y);
float tanf(float);
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef unsigned int uint;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef void* unkptr;
typedef u32 unknown;
#pragma section RX "forcestrip"
typedef unsigned short wchar_t;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef volatile unsigned char vu8;
typedef volatile unsigned short vu16;
typedef volatile unsigned long vu32;
typedef volatile unsigned long long vu64;
typedef volatile signed char vs8;
typedef volatile short vs16;
typedef volatile long vs32;
typedef volatile long long vs64;
typedef float f32;
typedef double f64;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
unsigned char cn[4];
} Vtx_t;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
signed char n[3];
unsigned char a;
} Vtx_tn;
typedef union {
Vtx_t v;
Vtx_tn n;
long long int force_structure_alignment;
} Vtx;
typedef struct {
void *SourceImagePointer;
void *TlutPointer;
short Stride;
short SubImageWidth;
short SubImageHeight;
char SourceImageType;
char SourceImageBitSize;
short SourceImageOffsetS;
short SourceImageOffsetT;
char dummy[4];
} uSprite_t;
typedef union {
uSprite_t s;
long long int force_structure_allignment[3];
} uSprite;
typedef struct {
unsigned char flag;
unsigned char v[3];
} Tri;
typedef long Mtx_t[4][4];
typedef union {
Mtx_t m;
long long int force_structure_alignment;
} Mtx;
typedef struct {
short vscale[4];
short vtrans[4];
} Vp_t;
typedef union {
Vp_t vp;
long long int force_structure_alignment;
} Vp;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
signed char dir[3];
char pad3;
} Light_t;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
} Ambient_t;
typedef struct {
int x1,y1,x2,y2;
} Hilite_t;
typedef union {
Light_t l;
long long int force_structure_alignment[2];
} Light;
typedef union {
Ambient_t l;
long long int force_structure_alignment[1];
} Ambient;
typedef struct {
Ambient a;
Light l[7];
} Lightsn;
typedef struct {
Ambient a;
Light l[1];
} Lights0;
typedef struct {
Ambient a;
Light l[1];
} Lights1;
typedef struct {
Ambient a;
Light l[2];
} Lights2;
typedef struct {
Ambient a;
Light l[3];
} Lights3;
typedef struct {
Ambient a;
Light l[4];
} Lights4;
typedef struct {
Ambient a;
Light l[5];
} Lights5;
typedef struct {
Ambient a;
Light l[6];
} Lights6;
typedef struct {
Ambient a;
Light l[7];
} Lights7;
typedef struct {
Light l[2];
} LookAt;
typedef union {
Hilite_t h;
long int force_structure_alignment[4];
} Hilite;
typedef struct {
int cmd:8;
unsigned int par:8;
unsigned int len:16;
unsigned int addr;
} Gdma;
typedef struct {
int cmd:8;
int pad:24;
Tri tri;
} Gtri;
typedef struct {
int cmd:8;
int pad1:24;
int pad2:24;
unsigned int param:8;
} Gpopmtx;
typedef struct {
int cmd:8;
int pad0:8;
int mw_index:8;
int number:8;
int pad1:8;
int base:24;
} Gsegment;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeL;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeH;
typedef struct {
unsigned char cmd;
unsigned char lodscale;
unsigned char tile;
unsigned char on;
unsigned short s;
unsigned short t;
} Gtexture;
typedef struct {
int cmd:8;
int pad:24;
Tri line;
} Gline3D;
typedef struct {
int cmd:8;
int pad1:24;
short int pad2;
short int scale;
} Gperspnorm;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad:7;
unsigned int wd:12;
unsigned int dram;
} Gsetimg;
typedef struct {
int cmd:8;
unsigned int muxs0:24;
unsigned int muxs1:32;
} Gsetcombine;
typedef struct {
int cmd:8;
unsigned char pad;
unsigned char prim_min_level;
unsigned char prim_level;
unsigned long color;
} Gsetcolor;
typedef struct {
int cmd:8;
int x0:10;
int x0frac:2;
int y0:10;
int y0frac:2;
unsigned int pad:8;
int x1:10;
int x1frac:2;
int y1:10;
int y1frac:2;
} Gfillrect;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad0:1;
unsigned int line:9;
unsigned int tmem:9;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int palette:4;
unsigned int ct:1;
unsigned int mt:1;
unsigned int maskt:4;
unsigned int shiftt:4;
unsigned int cs:1;
unsigned int ms:1;
unsigned int masks:4;
unsigned int shifts:4;
} Gsettile;
typedef struct {
int cmd:8;
unsigned int sl:12;
unsigned int tl:12;
int pad:5;
unsigned int tile:3;
unsigned int sh:12;
unsigned int th:12;
} Gloadtile;
typedef Gloadtile Gloadblock;
typedef Gloadtile Gsettilesize;
typedef Gloadtile Gloadtlut;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int s:16;
unsigned int t:16;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect;
typedef struct {
unsigned long w0;
unsigned long w1;
unsigned long w2;
unsigned long w3;
} TexRect;
typedef struct {
unsigned int w0;
unsigned int w1;
} Gwords;
typedef union {
Gwords words;
Gdma dma;
Gtri tri;
Gline3D line;
Gpopmtx popmtx;
Gsegment segment;
GsetothermodeH setothermodeH;
GsetothermodeL setothermodeL;
Gtexture texture;
Gperspnorm perspnorm;
Gsetimg setimg;
Gsetcombine setcombine;
Gsetcolor setcolor;
Gfillrect fillrect;
Gsettile settile;
Gloadtile loadtile;
Gsettilesize settilesize;
Gloadtlut loadtlut;
long long int force_structure_alignment;
} Gfx;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Aadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Apolef;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvelope;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmem:16;
unsigned int pad2:16;
unsigned int count:16;
} Aclearbuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int inL:16;
unsigned int inR:16;
} Ainterleave;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Aloadbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvmixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int dmemi:16;
unsigned int dmemo:16;
} Amixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmem2:16;
unsigned int addr;
} Apan;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pitch:16;
unsigned int addr;
} Aresample;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Areverb;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Asavebuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int pad2:2;
unsigned int number:4;
unsigned int base:24;
} Asegment;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Asetbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int vol:16;
unsigned int voltgt:16;
unsigned int volrate:16;
} Asetvol;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Admemmove;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int count:16;
unsigned int addr;
} Aloadadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int addr;
} Asetloop;
typedef struct {
unsigned int w0;
unsigned int w1;
} Awords;
typedef union {
Awords words;
Aadpcm adpcm;
Apolef polef;
Aclearbuff clearbuff;
Aenvelope envelope;
Ainterleave interleave;
Aloadbuff loadbuff;
Aenvmixer envmixer;
Aresample resample;
Areverb reverb;
Asavebuff savebuff;
Asegment segment;
Asetbuff setbuff;
Asetvol setvol;
Admemmove dmemmove;
Aloadadpcm loadadpcm;
Amixer mixer;
Asetloop setloop;
long long int force_union_align;
} Acmd;
typedef short ADPCM_STATE[16 ];
typedef short POLEF_STATE[4];
typedef short RESAMPLE_STATE[16];
typedef short ENVMIX_STATE[40];
extern void make_dl_nintendo_logo(Gfx** gpp, u32 alpha);
extern void initial_menu_init();
extern void initial_menu_cleanup();
typedef u8 GXBool;
typedef enum _GXProjectionType {
GX_PERSPECTIVE,
GX_ORTHOGRAPHIC,
} GXProjectionType;
typedef enum _GXCompare {
GX_NEVER,
GX_LESS,
GX_EQUAL,
GX_LEQUAL,
GX_GREATER,
GX_NEQUAL,
GX_GEQUAL,
GX_ALWAYS,
} GXCompare;
typedef enum _GXAlphaOp {
GX_AOP_AND,
GX_AOP_OR,
GX_AOP_XOR,
GX_AOP_XNOR,
GX_MAX_ALPHAOP,
} GXAlphaOp;
typedef enum _GXFBClamp {
GX_CLAMP_NONE,
GX_CLAMP_TOP,
GX_CLAMP_BOTTOM,
} GXFBClamp;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR,
GX_ZC_NEAR,
GX_ZC_MID,
GX_ZC_FAR,
} GXZFmt16;
typedef enum _GXGamma {
GX_GM_1_0,
GX_GM_1_7,
GX_GM_2_2,
} GXGamma;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24,
GX_PF_RGBA6_Z24,
GX_PF_RGB565_Z16,
GX_PF_Z24,
GX_PF_Y8,
GX_PF_U8,
GX_PF_V8,
GX_PF_YUV420,
} GXPixelFmt;
typedef enum _GXPrimitive {
GX_QUADS = 0x80,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xA0,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_POINTS = 0xB8,
} GXPrimitive;
typedef enum _GXVtxFmt {
GX_VTXFMT0,
GX_VTXFMT1,
GX_VTXFMT2,
GX_VTXFMT3,
GX_VTXFMT4,
GX_VTXFMT5,
GX_VTXFMT6,
GX_VTXFMT7,
GX_MAX_VTXFMT,
} GXVtxFmt;
typedef enum _GXAttr {
GX_VA_PNMTXIDX,
GX_VA_TEX0MTXIDX,
GX_VA_TEX1MTXIDX,
GX_VA_TEX2MTXIDX,
GX_VA_TEX3MTXIDX,
GX_VA_TEX4MTXIDX,
GX_VA_TEX5MTXIDX,
GX_VA_TEX6MTXIDX,
GX_VA_TEX7MTXIDX,
GX_VA_POS,
GX_VA_NRM,
GX_VA_CLR0,
GX_VA_CLR1,
GX_VA_TEX0,
GX_VA_TEX1,
GX_VA_TEX2,
GX_VA_TEX3,
GX_VA_TEX4,
GX_VA_TEX5,
GX_VA_TEX6,
GX_VA_TEX7,
GX_POS_MTX_ARRAY,
GX_NRM_MTX_ARRAY,
GX_TEX_MTX_ARRAY,
GX_LIGHT_ARRAY,
GX_VA_NBT,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF,
} GXAttr;
typedef enum _GXAttrType {
GX_NONE,
GX_DIRECT,
GX_INDEX8,
GX_INDEX16,
} GXAttrType;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_CTF_R4 = 0x0 | 0x20 ,
GX_CTF_RA4 = 0x2 | 0x20 ,
GX_CTF_RA8 = 0x3 | 0x20 ,
GX_CTF_YUVA8 = 0x6 | 0x20 ,
GX_CTF_A8 = 0x7 | 0x20 ,
GX_CTF_R8 = 0x8 | 0x20 ,
GX_CTF_G8 = 0x9 | 0x20 ,
GX_CTF_B8 = 0xA | 0x20 ,
GX_CTF_RG8 = 0xB | 0x20 ,
GX_CTF_GB8 = 0xC | 0x20 ,
GX_TF_Z8 = 0x1 | 0x10 ,
GX_TF_Z16 = 0x3 | 0x10 ,
GX_TF_Z24X8 = 0x6 | 0x10 ,
GX_CTF_Z4 = 0x0 | 0x10 | 0x20 ,
GX_CTF_Z8M = 0x9 | 0x10 | 0x20 ,
GX_CTF_Z8L = 0xA | 0x10 | 0x20 ,
GX_CTF_Z16L = 0xC | 0x10 | 0x20 ,
GX_TF_A8 = GX_CTF_A8,
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xa,
} GXCITexFmt;
typedef enum _GXTexWrapMode {
GX_CLAMP,
GX_REPEAT,
GX_MIRROR,
GX_MAX_TEXWRAPMODE,
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR,
GX_LINEAR,
GX_NEAR_MIP_NEAR,
GX_LIN_MIP_NEAR,
GX_NEAR_MIP_LIN,
GX_LIN_MIP_LIN,
} GXTexFilter;
typedef enum _GXAnisotropy {
GX_ANISO_1,
GX_ANISO_2,
GX_ANISO_4,
GX_MAX_ANISOTROPY,
} GXAnisotropy;
typedef enum _GXTexMapID {
GX_TEXMAP0,
GX_TEXMAP1,
GX_TEXMAP2,
GX_TEXMAP3,
GX_TEXMAP4,
GX_TEXMAP5,
GX_TEXMAP6,
GX_TEXMAP7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100,
} GXTexMapID;
typedef enum _GXTexCoordID {
GX_TEXCOORD0,
GX_TEXCOORD1,
GX_TEXCOORD2,
GX_TEXCOORD3,
GX_TEXCOORD4,
GX_TEXCOORD5,
GX_TEXCOORD6,
GX_TEXCOORD7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF,
} GXTexCoordID;
typedef enum _GXTevStageID {
GX_TEVSTAGE0,
GX_TEVSTAGE1,
GX_TEVSTAGE2,
GX_TEVSTAGE3,
GX_TEVSTAGE4,
GX_TEVSTAGE5,
GX_TEVSTAGE6,
GX_TEVSTAGE7,
GX_TEVSTAGE8,
GX_TEVSTAGE9,
GX_TEVSTAGE10,
GX_TEVSTAGE11,
GX_TEVSTAGE12,
GX_TEVSTAGE13,
GX_TEVSTAGE14,
GX_TEVSTAGE15,
GX_MAX_TEVSTAGE,
} GXTevStageID;
typedef enum _GXTevMode {
GX_MODULATE,
GX_DECAL,
GX_BLEND,
GX_REPLACE,
GX_PASSCLR,
} GXTevMode;
typedef enum _GXTexMtxType {
GX_MTX3x4,
GX_MTX2x4,
} GXTexMtxType;
typedef enum _GXTexGenType {
GX_TG_MTX3x4,
GX_TG_MTX2x4,
GX_TG_BUMP0,
GX_TG_BUMP1,
GX_TG_BUMP2,
GX_TG_BUMP3,
GX_TG_BUMP4,
GX_TG_BUMP5,
GX_TG_BUMP6,
GX_TG_BUMP7,
GX_TG_SRTG,
} GXTexGenType;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 0,
GX_PNMTX1 = 3,
GX_PNMTX2 = 6,
GX_PNMTX3 = 9,
GX_PNMTX4 = 12,
GX_PNMTX5 = 15,
GX_PNMTX6 = 18,
GX_PNMTX7 = 21,
GX_PNMTX8 = 24,
GX_PNMTX9 = 27,
} GXPosNrmMtx;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30,
GX_TEXMTX1 = 33,
GX_TEXMTX2 = 36,
GX_TEXMTX3 = 39,
GX_TEXMTX4 = 42,
GX_TEXMTX5 = 45,
GX_TEXMTX6 = 48,
GX_TEXMTX7 = 51,
GX_TEXMTX8 = 54,
GX_TEXMTX9 = 57,
GX_IDENTITY = 60,
} GXTexMtx;
typedef enum _GXChannelID {
GX_COLOR0,
GX_COLOR1,
GX_ALPHA0,
GX_ALPHA1,
GX_COLOR0A0,
GX_COLOR1A1,
GX_COLOR_ZERO,
GX_ALPHA_BUMP,
GX_ALPHA_BUMPN,
GX_COLOR_NULL = 0xFF,
} GXChannelID;
typedef enum _GXTexGenSrc {
GX_TG_POS,
GX_TG_NRM,
GX_TG_BINRM,
GX_TG_TANGENT,
GX_TG_TEX0,
GX_TG_TEX1,
GX_TG_TEX2,
GX_TG_TEX3,
GX_TG_TEX4,
GX_TG_TEX5,
GX_TG_TEX6,
GX_TG_TEX7,
GX_TG_TEXCOORD0,
GX_TG_TEXCOORD1,
GX_TG_TEXCOORD2,
GX_TG_TEXCOORD3,
GX_TG_TEXCOORD4,
GX_TG_TEXCOORD5,
GX_TG_TEXCOORD6,
GX_TG_COLOR0,
GX_TG_COLOR1,
GX_MAX_TEXGENSRC,
} GXTexGenSrc;
typedef enum _GXBlendMode {
GX_BM_NONE,
GX_BM_BLEND,
GX_BM_LOGIC,
GX_BM_SUBTRACT,
GX_MAX_BLENDMODE,
} GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO,
GX_BL_ONE,
GX_BL_SRCCLR,
GX_BL_INVSRCCLR,
GX_BL_SRCALPHA,
GX_BL_INVSRCALPHA,
GX_BL_DSTALPHA,
GX_BL_INVDSTALPHA,
GX_BL_DSTCLR = GX_BL_SRCCLR,
GX_BL_INVDSTCLR = GX_BL_INVSRCCLR,
} GXBlendFactor;
typedef enum _GXLogicOp {
GX_LO_CLEAR,
GX_LO_AND,
GX_LO_REVAND,
GX_LO_COPY,
GX_LO_INVAND,
GX_LO_NOOP,
GX_LO_XOR,
GX_LO_OR,
GX_LO_NOR,
GX_LO_EQUIV,
GX_LO_INV,
GX_LO_REVOR,
GX_LO_INVCOPY,
GX_LO_INVOR,
GX_LO_NAND,
GX_LO_SET,
} GXLogicOp;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1,
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5,
} GXCompType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64,
GX_PTTEXMTX1 = 67,
GX_PTTEXMTX2 = 70,
GX_PTTEXMTX3 = 73,
GX_PTTEXMTX4 = 76,
GX_PTTEXMTX5 = 79,
GX_PTTEXMTX6 = 82,
GX_PTTEXMTX7 = 85,
GX_PTTEXMTX8 = 88,
GX_PTTEXMTX9 = 91,
GX_PTTEXMTX10 = 94,
GX_PTTEXMTX11 = 97,
GX_PTTEXMTX12 = 100,
GX_PTTEXMTX13 = 103,
GX_PTTEXMTX14 = 106,
GX_PTTEXMTX15 = 109,
GX_PTTEXMTX16 = 112,
GX_PTTEXMTX17 = 115,
GX_PTTEXMTX18 = 118,
GX_PTTEXMTX19 = 121,
GX_PTIDENTITY = 125,
} GXPTTexMtx;
typedef enum _GXTevRegID {
GX_TEVPREV,
GX_TEVREG0,
GX_TEVREG1,
GX_TEVREG2,
GX_MAX_TEVREG,
} GXTevRegID;
typedef enum _GXDiffuseFn {
GX_DF_NONE,
GX_DF_SIGN,
GX_DF_CLAMP,
} GXDiffuseFn;
typedef enum _GXColorSrc {
GX_SRC_REG,
GX_SRC_VTX,
} GXColorSrc;
typedef enum _GXAttnFn {
GX_AF_SPEC,
GX_AF_SPOT,
GX_AF_NONE,
} GXAttnFn;
typedef enum _GXLightID {
GX_LIGHT0 = 0x001,
GX_LIGHT1 = 0x002,
GX_LIGHT2 = 0x004,
GX_LIGHT3 = 0x008,
GX_LIGHT4 = 0x010,
GX_LIGHT5 = 0x020,
GX_LIGHT6 = 0x040,
GX_LIGHT7 = 0x080,
GX_MAX_LIGHT = 0x100,
GX_LIGHT_NULL = 0,
} GXLightID;
typedef enum _GXTexOffset {
GX_TO_ZERO,
GX_TO_SIXTEENTH,
GX_TO_EIGHTH,
GX_TO_FOURTH,
GX_TO_HALF,
GX_TO_ONE,
GX_MAX_TEXOFFSET,
} GXTexOffset;
typedef enum _GXSpotFn {
GX_SP_OFF,
GX_SP_FLAT,
GX_SP_COS,
GX_SP_COS2,
GX_SP_SHARP,
GX_SP_RING1,
GX_SP_RING2,
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF,
GX_DA_GENTLE,
GX_DA_MEDIUM,
GX_DA_STEEP,
} GXDistAttnFn;
typedef enum _GXCullMode {
GX_CULL_NONE,
GX_CULL_FRONT,
GX_CULL_BACK,
GX_CULL_ALL,
} GXCullMode;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1,
GX_TEV_SWAP2,
GX_TEV_SWAP3,
GX_MAX_TEVSWAP,
} GXTevSwapSel;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN,
GX_CH_BLUE,
GX_CH_ALPHA,
} GXTevColorChan;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_PERSP_LIN = 2,
GX_FOG_PERSP_EXP = 4,
GX_FOG_PERSP_EXP2 = 5,
GX_FOG_PERSP_REVEXP = 6,
GX_FOG_PERSP_REVEXP2 = 7,
GX_FOG_ORTHO_LIN = 10,
GX_FOG_ORTHO_EXP = 12,
GX_FOG_ORTHO_EXP2 = 13,
GX_FOG_ORTHO_REVEXP = 14,
GX_FOG_ORTHO_REVEXP2 = 15,
GX_FOG_LIN = GX_FOG_PERSP_LIN,
GX_FOG_EXP = GX_FOG_PERSP_EXP,
GX_FOG_EXP2 = GX_FOG_PERSP_EXP2,
GX_FOG_REVEXP = GX_FOG_PERSP_REVEXP,
GX_FOG_REVEXP2 = GX_FOG_PERSP_REVEXP2,
} GXFogType;
typedef enum _GXTevColorArg {
GX_CC_CPREV,
GX_CC_APREV,
GX_CC_C0,
GX_CC_A0,
GX_CC_C1,
GX_CC_A1,
GX_CC_C2,
GX_CC_A2,
GX_CC_TEXC,
GX_CC_TEXA,
GX_CC_RASC,
GX_CC_RASA,
GX_CC_ONE,
GX_CC_HALF,
GX_CC_KONST,
GX_CC_ZERO,
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV,
GX_CA_A0,
GX_CA_A1,
GX_CA_A2,
GX_CA_TEXA,
GX_CA_RASA,
GX_CA_KONST,
GX_CA_ZERO,
} GXTevAlphaArg;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ,
} GXTevOp;
typedef enum _GXTevBias {
GX_TB_ZERO,
GX_TB_ADDHALF,
GX_TB_SUBHALF,
GX_MAX_TEVBIAS,
} GXTevBias;
typedef enum _GXTevScale {
GX_CS_SCALE_1,
GX_CS_SCALE_2,
GX_CS_SCALE_4,
GX_CS_DIVIDE_2,
GX_MAX_TEVSCALE,
} GXTevScale;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_8_8 = 0x00,
GX_TEV_KCSEL_7_8 = 0x01,
GX_TEV_KCSEL_6_8 = 0x02,
GX_TEV_KCSEL_5_8 = 0x03,
GX_TEV_KCSEL_4_8 = 0x04,
GX_TEV_KCSEL_3_8 = 0x05,
GX_TEV_KCSEL_2_8 = 0x06,
GX_TEV_KCSEL_1_8 = 0x07,
GX_TEV_KCSEL_1 = GX_TEV_KCSEL_8_8,
GX_TEV_KCSEL_3_4 = GX_TEV_KCSEL_6_8,
GX_TEV_KCSEL_1_2 = GX_TEV_KCSEL_4_8,
GX_TEV_KCSEL_1_4 = GX_TEV_KCSEL_2_8,
GX_TEV_KCSEL_K0 = 0x0C,
GX_TEV_KCSEL_K1 = 0x0D,
GX_TEV_KCSEL_K2 = 0x0E,
GX_TEV_KCSEL_K3 = 0x0F,
GX_TEV_KCSEL_K0_R = 0x10,
GX_TEV_KCSEL_K1_R = 0x11,
GX_TEV_KCSEL_K2_R = 0x12,
GX_TEV_KCSEL_K3_R = 0x13,
GX_TEV_KCSEL_K0_G = 0x14,
GX_TEV_KCSEL_K1_G = 0x15,
GX_TEV_KCSEL_K2_G = 0x16,
GX_TEV_KCSEL_K3_G = 0x17,
GX_TEV_KCSEL_K0_B = 0x18,
GX_TEV_KCSEL_K1_B = 0x19,
GX_TEV_KCSEL_K2_B = 0x1A,
GX_TEV_KCSEL_K3_B = 0x1B,
GX_TEV_KCSEL_K0_A = 0x1C,
GX_TEV_KCSEL_K1_A = 0x1D,
GX_TEV_KCSEL_K2_A = 0x1E,
GX_TEV_KCSEL_K3_A = 0x1F,
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_8_8 = 0x00,
GX_TEV_KASEL_7_8 = 0x01,
GX_TEV_KASEL_6_8 = 0x02,
GX_TEV_KASEL_5_8 = 0x03,
GX_TEV_KASEL_4_8 = 0x04,
GX_TEV_KASEL_3_8 = 0x05,
GX_TEV_KASEL_2_8 = 0x06,
GX_TEV_KASEL_1_8 = 0x07,
GX_TEV_KASEL_1 = GX_TEV_KASEL_8_8,
GX_TEV_KASEL_3_4 = GX_TEV_KASEL_6_8,
GX_TEV_KASEL_1_2 = GX_TEV_KASEL_4_8,
GX_TEV_KASEL_1_4 = GX_TEV_KASEL_2_8,
GX_TEV_KASEL_K0_R = 0x10,
GX_TEV_KASEL_K1_R = 0x11,
GX_TEV_KASEL_K2_R = 0x12,
GX_TEV_KASEL_K3_R = 0x13,
GX_TEV_KASEL_K0_G = 0x14,
GX_TEV_KASEL_K1_G = 0x15,
GX_TEV_KASEL_K2_G = 0x16,
GX_TEV_KASEL_K3_G = 0x17,
GX_TEV_KASEL_K0_B = 0x18,
GX_TEV_KASEL_K1_B = 0x19,
GX_TEV_KASEL_K2_B = 0x1A,
GX_TEV_KASEL_K3_B = 0x1B,
GX_TEV_KASEL_K0_A = 0x1C,
GX_TEV_KASEL_K1_A = 0x1D,
GX_TEV_KASEL_K2_A = 0x1E,
GX_TEV_KASEL_K3_A = 0x1F,
} GXTevKAlphaSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1,
GX_KCOLOR2,
GX_KCOLOR3,
GX_MAX_KCOLOR,
} GXTevKColorID;
typedef enum _GXZTexOp {
GX_ZT_DISABLE,
GX_ZT_ADD,
GX_ZT_REPLACE,
GX_MAX_ZTEXOP,
} GXZTexOp;
typedef enum _GXIndTexFormat {
GX_ITF_8,
GX_ITF_5,
GX_ITF_4,
GX_ITF_3,
GX_MAX_ITFORMAT,
} GXIndTexFormat;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE,
GX_ITB_S,
GX_ITB_T,
GX_ITB_ST,
GX_ITB_U,
GX_ITB_SU,
GX_ITB_TU,
GX_ITB_STU,
GX_MAX_ITBIAS,
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF,
GX_ITBA_S,
GX_ITBA_T,
GX_ITBA_U,
GX_MAX_ITBALPHA,
} GXIndTexAlphaSel;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF,
GX_ITM_0,
GX_ITM_1,
GX_ITM_2,
GX_ITM_S0 = 5,
GX_ITM_S1,
GX_ITM_S2,
GX_ITM_T0 = 9,
GX_ITM_T1,
GX_ITM_T2,
} GXIndTexMtxID;
typedef enum _GXIndTexWrap {
GX_ITW_OFF,
GX_ITW_256,
GX_ITW_128,
GX_ITW_64,
GX_ITW_32,
GX_ITW_16,
GX_ITW_0,
GX_MAX_ITWRAP,
} GXIndTexWrap;
typedef enum _GXIndTexStageID {
GX_INDTEXSTAGE0,
GX_INDTEXSTAGE1,
GX_INDTEXSTAGE2,
GX_INDTEXSTAGE3,
GX_MAX_INDTEXSTAGE,
} GXIndTexStageID;
typedef enum _GXIndTexScale {
GX_ITS_1,
GX_ITS_2,
GX_ITS_4,
GX_ITS_8,
GX_ITS_16,
GX_ITS_32,
GX_ITS_64,
GX_ITS_128,
GX_ITS_256,
GX_MAX_ITSCALE,
} GXIndTexScale;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1,
} GXClipMode;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19,
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8,
GX_TL_RGB565,
GX_TL_RGB5A3,
GX_MAX_TLUTFMT,
} GXTlutFmt;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3,
} GXMiscToken;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K,
GX_TEXCACHE_128K,
GX_TEXCACHE_512K,
GX_TEXCACHE_NONE
} GXTexCacheSize;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES,
GX_PERF0_CLIP_VTX,
GX_PERF0_CLIP_CLKS,
GX_PERF0_XF_WAIT_IN,
GX_PERF0_XF_WAIT_OUT,
GX_PERF0_XF_XFRM_CLKS,
GX_PERF0_XF_LIT_CLKS,
GX_PERF0_XF_BOT_CLKS,
GX_PERF0_XF_REGLD_CLKS,
GX_PERF0_XF_REGRD_CLKS,
GX_PERF0_CLIP_RATIO,
GX_PERF0_TRIANGLES,
GX_PERF0_TRIANGLES_CULLED,
GX_PERF0_TRIANGLES_PASSED,
GX_PERF0_TRIANGLES_SCISSORED,
GX_PERF0_TRIANGLES_0TEX,
GX_PERF0_TRIANGLES_1TEX,
GX_PERF0_TRIANGLES_2TEX,
GX_PERF0_TRIANGLES_3TEX,
GX_PERF0_TRIANGLES_4TEX,
GX_PERF0_TRIANGLES_5TEX,
GX_PERF0_TRIANGLES_6TEX,
GX_PERF0_TRIANGLES_7TEX,
GX_PERF0_TRIANGLES_8TEX,
GX_PERF0_TRIANGLES_0CLR,
GX_PERF0_TRIANGLES_1CLR,
GX_PERF0_TRIANGLES_2CLR,
GX_PERF0_QUAD_0CVG,
GX_PERF0_QUAD_NON0CVG,
GX_PERF0_QUAD_1CVG,
GX_PERF0_QUAD_2CVG,
GX_PERF0_QUAD_3CVG,
GX_PERF0_QUAD_4CVG,
GX_PERF0_AVG_QUAD_CNT,
GX_PERF0_CLOCKS,
GX_PERF0_NONE
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS,
GX_PERF1_TX_IDLE,
GX_PERF1_TX_REGS,
GX_PERF1_TX_MEMSTALL,
GX_PERF1_TC_CHECK1_2,
GX_PERF1_TC_CHECK3_4,
GX_PERF1_TC_CHECK5_6,
GX_PERF1_TC_CHECK7_8,
GX_PERF1_TC_MISS,
GX_PERF1_VC_ELEMQ_FULL,
GX_PERF1_VC_MISSQ_FULL,
GX_PERF1_VC_MEMREQ_FULL,
GX_PERF1_VC_STATUS7,
GX_PERF1_VC_MISSREP_FULL,
GX_PERF1_VC_STREAMBUF_LOW,
GX_PERF1_VC_ALL_STALLS,
GX_PERF1_VERTICES,
GX_PERF1_FIFO_REQ,
GX_PERF1_CALL_REQ,
GX_PERF1_VC_MISS_REQ,
GX_PERF1_CP_ALL_REQ,
GX_PERF1_CLOCKS,
GX_PERF1_NONE
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS,
GX_VC_NRM,
GX_VC_CLR0,
GX_VC_CLR1,
GX_VC_TEX0,
GX_VC_TEX1,
GX_VC_TEX2,
GX_VC_TEX3,
GX_VC_TEX4,
GX_VC_TEX5,
GX_VC_TEX6,
GX_VC_TEX7,
GX_VC_ALL = 0xf
} GXVCachePerf;
typedef enum _GXAlphaReadMode
{
GX_READ_00,
GX_READ_FF,
GX_READ_NONE,
} GXAlphaReadMode;
typedef enum _GXCopyMode
{
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3,
} GXCopyMode;
typedef enum _GXTlutSize
{
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024,
} GXTlutSize;
typedef enum
{
VI_TVMODE_NTSC_INT = (((0) << 2) + (0)) ,
VI_TVMODE_NTSC_DS = (((0) << 2) + (1)) ,
VI_TVMODE_NTSC_PROG = (((0) << 2) + (2)) ,
VI_TVMODE_3 = 3,
VI_TVMODE_PAL_INT = (((1) << 2) + (0)) ,
VI_TVMODE_PAL_DS = (((1) << 2) + (1)) ,
VI_TVMODE_EURGB60_INT = (((5) << 2) + (0)) ,
VI_TVMODE_EURGB60_DS = (((5) << 2) + (1)) ,
VI_TVMODE_MPAL_INT = (((2) << 2) + (0)) ,
VI_TVMODE_MPAL_DS = (((2) << 2) + (1)) ,
VI_TVMODE_DEBUG_INT = (((3) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_INT = (((4) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_DS = (((4) << 2) + (1))
} VITVMode;
typedef enum
{
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF
} VIXFBMode;
typedef void (*VIRetraceCallback)(u32 retraceCount);
void VIConfigure(const struct _GXRenderModeObj *rm);
void VISetBlack(BOOL);
void VIWaitForRetrace();
void VIConfigurePan(u16 x_origin, u16 y_origin, u16 width, u16 height);
u32 VIGetRetraceCount();
u32 VIGetDTVStatus();
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void* VIGetNextFrameBuffer();
void* VIGetCurrentFrameBuffer();
void VISetNextFrameBuffer(void* fb);
void VIInit();
void VIFlush();
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXColor {
u8 r;
u8 g;
u8 b;
u8 a;
} GXColor;
typedef struct _GXTexObj {
u32 dummy[8];
} GXTexObj;
typedef struct _GXTlutObj {
u32 dummy[3];
} GXTlutObj;
typedef struct _GXLightObj {
u32 dummy[16];
} GXLightObj;
typedef struct _GXColorS10 {
s16 r;
s16 g;
s16 b;
s16 a;
} GXColorS10;
typedef struct _GXTexRegion {
u32 dummy[4];
} GXTexRegion;
typedef struct _GXTlutRegion {
u32 dummy[4];
} GXTlutRegion;
typedef struct _GXFogAdjTable
{
u16 r[10];
} GXFogAdjTable;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt cnt;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
extern u16 *__memReg;
extern u16 *__peReg;
extern u16 *__cpReg;
extern u32 *__piReg;
inline u32 __GXReadCPCounterU32(u32 regAddrL, u32 regAddrH);
void GXSetTevDirect(GXTevStageID tev_stage);
void GXSetNumIndStages(u8 nIndStages);
void GXSetIndTexMtx(GXIndTexMtxID mtx_sel, f32 offset[2][3], s8 scale_exp);
void GXSetIndTexOrder(GXIndTexStageID ind_stage, GXTexCoordID tex_coord, GXTexMapID tex_map);
void GXSetTevIndirect(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXIndTexFormat format,
GXIndTexBiasSel bias_sel, GXIndTexMtxID matrix_sel, GXIndTexWrap wrap_s,
GXIndTexWrap wrap_t, GXBool add_prev, GXBool ind_lod,
GXIndTexAlphaSel alpha_sel);
void GXSetTevIndWarp(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXBool signed_offsets,
GXBool replace_mode, GXIndTexMtxID matrix_sel);
void GXSetIndTexCoordScale(GXIndTexStageID ind_state, GXIndTexScale scale_s, GXIndTexScale scale_t);
extern void __GXSetIndirectMask(u32 mask);
void GXSetScissor(u32 left, u32 top, u32 wd, u32 ht);
void GXSetCullMode(GXCullMode mode);
void GXSetCoPlanar(GXBool enable);
void GXBeginDisplayList(void* list, u32 size);
u32 GXEndDisplayList(void);
void GXCallDisplayList(void* list, u32 nbytes);
void GXDrawSphere(u8 numMajor, u8 numMinor);
typedef struct OSContext
{
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
u32 fpscr_pad;
u32 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
u32 OSGetStackPointer(void);
void OSDumpContext(OSContext *context);
void OSLoadContext(OSContext *context);
u32 OSSaveContext(OSContext *context);
void OSClearContext(OSContext *context);
OSContext *OSGetCurrentContext(void);
void OSSetCurrentContext(OSContext *context);
void OSLoadFPUContext(OSContext *fpuContext);
void OSSaveFPUContext(OSContext *fpuContext);
u32 OSSwitchStack(u32 newsp);
int OSSwitchFiber(u32 pc, u32 newsp);
void OSInitContext(OSContext *context, u32 pc, u32 newsp);
void OSFillFPUContext(OSContext *context);
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef s32 OSPriority;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef struct OSCond OSCond;
typedef void (*OSIdleFunction)(void *param);
struct OSThreadQueue
{
OSThread *head;
OSThread *tail;
};
struct OSThreadLink
{
OSThread *next;
OSThread *prev;
};
struct OSMutexQueue
{
OSMutex *head;
OSMutex *tail;
};
struct OSMutexLink
{
OSMutex *next;
OSMutex *prev;
};
struct OSThread
{
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void *val;
OSThreadQueue *queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex *mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8 *stackBase;
u32 *stackEnd;
};
enum OS_THREAD_STATE
{
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8
};
void OSInitThreadQueue(OSThreadQueue *queue);
OSThread *OSGetCurrentThread(void);
BOOL OSIsThreadSuspended(OSThread *thread);
BOOL OSIsThreadTerminated(OSThread *thread);
s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);
void OSYieldThread(void);
BOOL OSCreateThread(OSThread *thread,
void *(*func)(void *),
void *param,
void *stack,
u32 stackSize,
OSPriority priority,
u16 attr);
void OSExitThread(void *val);
void OSCancelThread(OSThread *thread);
BOOL OSJoinThread(OSThread *thread, void **val);
void OSDetachThread(OSThread *thread);
s32 OSResumeThread(OSThread *thread);
s32 OSSuspendThread(OSThread *thread);
BOOL OSSetThreadPriority(OSThread *thread, OSPriority priority);
OSPriority OSGetThreadPriority(OSThread *thread);
void OSSleepThread(OSThreadQueue *queue);
void OSWakeupThread(OSThreadQueue *queue);
OSThread *OSSetIdleFunction(OSIdleFunction idleFunction,
void *param,
void *stack,
u32 stackSize);
OSThread *OSGetIdleFunction(void);
long OSCheckActiveThreads(void);
typedef struct
{
u8 pad[128];
} GXFifoObj;
typedef void (*GXBreakPtCallback)(void);
void GXInitFifoBase(GXFifoObj *fifo, void *base, u32 size);
void GXInitFifoPtrs(GXFifoObj *fifo, void *readPtr, void *writePtr);
void GXInitFifoLimits(GXFifoObj *fifo, u32 hiWatermark, u32 loWatermark);
void GXSetCPUFifo(GXFifoObj *fifo);
void GXSetGPFifo(GXFifoObj *fifo);
void GXSaveCPUFifo(GXFifoObj *fifo);
void GXSaveGPFifo(GXFifoObj *fifo);
void GXGetGPStatus(GXBool *overhi, GXBool *underlow, GXBool *readIdle, GXBool *cmdIdle, GXBool *brkpt);
void GXGetFifoStatus(GXFifoObj *fifo, GXBool *overhi, GXBool *underflow, u32 *fifoCount, GXBool *cpuWrite, GXBool *gpRead, GXBool *fifowrap);
void GXGetFifoPtrs(GXFifoObj *fifo, void **readPtr, void **writePtr);
void *GXGetFifoBase(GXFifoObj *fifo);
u32 GXGetFifoSize(GXFifoObj *fifo);
void GXGetFifoLimits(GXFifoObj *fifo, u32 *hi, u32 *lo);
GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback cb);
void GXEnableBreakPt(void *break_pt);
void GXDisableBreakPt(void);
OSThread *GXSetCurrentGXThread(void);
OSThread *GXGetCurrentGXThread(void);
GXFifoObj *GXGetCPUFifo(void);
GXFifoObj *GXGetGPFifo(void);
u32 GXGetOverflowCount(void);
u32 GXResetOverflowCount(void);
volatile void *GXRedirectWriteGatherPipe(void *ptr);
void GXRestoreWriteGatherPipe(void);
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
void GXSetCopyClear(GXColor clear_clr, u32 clear_z);
void GXAdjustForOverscan(GXRenderModeObj* rmin, GXRenderModeObj* rmout, u16 hor, u16 ver);
void GXCopyDisp(void* dest, GXBool clear);
void GXSetDispCopyGamma(GXGamma gamma);
void GXSetDispCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetDispCopyDst(u16 wd, u16 ht);
f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
u32 GXSetDispCopyYScale(f32 vscale);
u16 GXGetNumXfbLines(u16 efbHeight, f32 yScale);
void GXSetCopyFilter(GXBool aa, const u8 sample_pattern[12][2], GXBool vf, const u8 vfilter[7]);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetTexCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetTexCopyDst(u16 wd, u16 ht, GXTexFmt fmt, GXBool mipmap);
void GXCopyTex(void* dest, GXBool clear);
void GXSetCopyClamp(GXFBClamp clamp);
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(const GXVtxDescList* list);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetNumTexGens(u8 nTexGens);
void GXBegin(GXPrimitive type, GXVtxFmt vtxfmt, u16 nverts);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx,
GXBool normalize, u32 postmtx);
void GXSetLineWidth(u8 width, GXTexOffset texOffsets);
void GXSetPointSize(u8 pointSize, GXTexOffset texOffsets);
void GXEnableTexOffsets(GXTexCoordID coord, GXBool line_enable, GXBool point_enable);
void GXSetArray(GXAttr attr, const void* data, u8 stride);
void GXInvalidateVtxCache(void);
static inline void GXSetTexCoordGen(GXTexCoordID dst_coord, GXTexGenType func,
GXTexGenSrc src_param, u32 mtx);
GXBool GXGetTexObjMipMap(const GXTexObj* obj);
GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
u16 GXGetTexObjHeight(const GXTexObj* obj);
u16 GXGetTexObjWidth(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapS(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapT(const GXTexObj* obj);
void* GXGetTexObjData(const GXTexObj* obj);
void GXGetProjectionv(f32* p);
void GXGetLightPos(GXLightObj* lt_obj, f32* x, f32* y, f32* z);
void GXGetLightColor(GXLightObj* lt_obj, GXColor* color);
void GXGetVtxAttrFmt(GXVtxFmt idx, GXAttr attr, GXCompCnt* compCnt, GXCompType* compType,
u8* shift);
void GXSetNumChans(u8 nChans);
void GXSetChanCtrl(GXChannelID chan, GXBool enable, GXColorSrc amb_src, GXColorSrc mat_src,
u32 light_mask, GXDiffuseFn diff_fn, GXAttnFn attn_fn);
void GXSetChanAmbColor(GXChannelID chan, GXColor amb_color);
void GXSetChanMatColor(GXChannelID chan, GXColor mat_color);
void GXInitLightSpot(GXLightObj* lt_obj, f32 cutoff, GXSpotFn spot_func);
void GXInitLightDistAttn(GXLightObj* lt_obj, f32 ref_distance, f32 ref_brightness,
GXDistAttnFn dist_func);
void GXInitLightPos(GXLightObj* lt_obj, f32 x, f32 y, f32 z);
void GXInitLightDir(GXLightObj* lt_obj, f32 nx, f32 ny, f32 nz);
void GXInitLightColor(GXLightObj* lt_obj, GXColor color);
void GXInitLightAttn(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
void GXInitLightAttnA(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2);
void GXInitLightAttnK(GXLightObj* lt_obj, f32 k0, f32 k1, f32 k2);
void GXLoadLightObjImm(GXLightObj* lt_obj, GXLightID light);
typedef void (*GXDrawSyncCallback)(u16 token);
typedef void (*GXDrawDoneCallback)(void);
BOOL IsWriteGatherBufferEmpty(void);
GXFifoObj *GXInit(void *base, u32 size);
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush(void);
void GXResetWriteGatherPipe(void);
void GXAbortFrame(void);
void GXSetDrawSync(u16 token);
u16 GXReadDrawSync(void);
void GXSetDrawDone(void);
void GXWaitDrawDone(void);
void GXDrawDone(void);
void GXPixModeSync(void);
void GXTexModeSync(void);
GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback cb);
GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback cb);
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush();
void GXResetWriteGatherPipe();
void GXAbortFrame();
void GXReadXfRasMetric(u32* xf_wait_in, u32* xf_wait_out, u32* ras_busy, u32* clocks);
void GXSetFog(GXFogType type, f32 startz, f32 endz, f32 nearz, f32 farz, GXColor color);
void GXInitFogAdjTable(GXFogAdjTable *table, u16 width, f32 projmtx[4][4]);
void GXSetFogRangeAdj(GXBool enable, u16 center, GXFogAdjTable *table);
void GXSetBlendMode(GXBlendMode type, GXBlendFactor src_factor, GXBlendFactor dst_factor, GXLogicOp op);
void GXSetColorUpdate(GXBool update_enable);
void GXSetAlphaUpdate(GXBool update_enable);
void GXSetZMode(GXBool compare_enable, GXCompare func, GXBool update_enable);
void GXSetZCompLoc(GXBool before_tex);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetDither(GXBool dither);
void GXSetDstAlpha(GXBool enable, u8 alpha);
void GXSetFieldMask(GXBool odd_mask, GXBool even_mask);
void GXSetFieldMode(GXBool field_mode, GXBool half_aspect_ratio);
void GXSetTevOp(GXTevStageID id, GXTevMode mode);
void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c,
GXTevColorArg d);
void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c,
GXTevAlphaArg d);
void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevColor(GXTevRegID id, GXColor color);
void GXSetTevColorS10(GXTevRegID id, GXColorS10 color);
void GXSetTevKColor(GXTevKColorID id, GXColor color);
void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel ras_sel, GXTevSwapSel tex_sel);
void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green,
GXTevColorChan blue, GXTevColorChan alpha);
void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
void GXSetZTexture(GXZTexOp op, GXTexFmt fmt, u32 bias);
void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
void GXSetNumTevStages(u8 nStages);
typedef GXTexRegion* (*GXTexRegionCallback)(const GXTexObj* obj, GXTexMapID id);
typedef GXTlutRegion* (*GXTlutRegionCallback)(u32 idx);
void GXInitTexObj(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap);
void GXInitTexObjCI(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap, u32 tlut_name);
void GXInitTexObjData(GXTexObj* obj, void* image_ptr);
void GXInitTexObjLOD(GXTexObj* obj, GXTexFilter min_filt, GXTexFilter mag_filt, f32 min_lod, f32 max_lod, f32 lod_bias,
GXBool bias_clamp, GXBool do_edge_lod, GXAnisotropy max_aniso);
void GXLoadTexObj(GXTexObj* obj, GXTexMapID id);
u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, GXBool mipmap, u8 max_lod);
void GXInvalidateTexAll();
void GXInitTexObjWrapMode(GXTexObj* obj, GXTexWrapMode s, GXTexWrapMode t);
void GXInitTlutObj(GXTlutObj* tlut_obj, void* lut, GXTlutFmt fmt, u16 n_entries);
void GXLoadTlut(GXTlutObj* obj, u32 idx);
void GXSetTexCoordScaleManually(GXTexCoordID coord, GXBool enable, u16 ss, u16 ts);
void GXInitTexCacheRegion(GXTexRegion* region, GXBool is_32b_mipmap, u32 tmem_even, GXTexCacheSize size_even,
u32 tmem_odd, GXTexCacheSize size_odd);
GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback callback);
void GXInvalidateTexRegion(GXTexRegion* region);
void GXInitTlutRegion(GXTlutRegion* region, u32 tmem_addr, GXTlutSize tlut_size);
void GXSetTexCoordBias(GXTexCoordID coord, u8 s_enable, u8 t_enable);
void GXSetProjection(f32 mtx[4][4], GXProjectionType type);
void GXLoadPosMtxImm(f32 mtx[3][4], u32 id);
void GXLoadNrmMtxImm(f32 mtx[3][4], u32 id);
void GXLoadTexMtxImm(f32 mtx[][4], u32 id, GXTexMtxType type);
void GXSetViewport(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz);
void GXSetCurrentMtx(u32 id);
void GXSetViewportJitter(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz, u32 field);
void GXSetScissorBoxOffset(s32 x_off, s32 y_off);
void GXSetClipMode(GXClipMode mode);
typedef enum {
GX_WARN_NONE,
GX_WARN_SEVERE,
GX_WARN_MEDIUM,
GX_WARN_ALL
} GXWarningLevel;
typedef void (*GXVerifyCallback)(GXWarningLevel level, u32 id, char *msg);
void GXSetVerifyLevel(GXWarningLevel level);
GXVerifyCallback GXSetVerifyCallback(GXVerifyCallback cb);
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
volatile PPCWGPipe GXWGFifo : (0xCC008000) ;
static inline void GXPosition2f32(f32 x, f32 y);
static inline void GXPosition3s16(s16 x, s16 y, s16 z);
static inline void GXPosition3f32(f32 x, f32 y, f32 z);
static inline void GXNormal3f32(f32 x, f32 y, f32 z);
static inline void GXColor1u32(u32 v);
static inline void GXColor4u8(u8 r, u8 g, u8 b, u8 a);
static inline void GXTexCoord2s16(s16 u, s16 v);
static inline void GXPosition2s16(s16 x, s16 y);
static inline void GXPosition2u16(u16 x, u16 y);
static inline void GXTexCoord2f32(f32 u, f32 v);
static inline void GXTexCoord2u8(u8 u, u8 v);
static inline void GXPosition1x8(u8 index);
static inline void GXTexCoord2u16(u16 s, u16 t);
static inline void GXEnd(void);
typedef struct {
unsigned int cmd:8;
unsigned int a0:4;
unsigned int c0:5;
unsigned int Aa0:3;
unsigned int Ac0:3;
unsigned int a1:4;
unsigned int c1:5;
unsigned int b0:4;
unsigned int b1:4;
unsigned int Aa1:3;
unsigned int Ac1:3;
unsigned int d0:3;
unsigned int Ab0:3;
unsigned int Ad0:3;
unsigned int d1:3;
unsigned int Ab1:3;
unsigned int Ad1:3;
} Gsetcombine_new;
typedef struct {
int cmd:8;
unsigned int Aa0:3;
unsigned int Ab0:3;
unsigned int Ac0:3;
unsigned int Ad0:3;
unsigned int Aa1:3;
unsigned int Ab1:3;
unsigned int Ac1:3;
unsigned int Ad1:3;
unsigned int a0:4;
unsigned int b0:4;
unsigned int c0:4;
unsigned int d0:4;
unsigned int a1:4;
unsigned int b1:4;
unsigned int c1:4;
unsigned int d1:4;
} Gsetcombine_tev;
typedef struct {
int cmd:8;
unsigned int upper0:8;
unsigned int lower0:16;
unsigned int upper1:16;
unsigned int lower1:16;
} Gsetcombine_raw;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int pad2:32;
unsigned int s:16;
unsigned int t:16;
unsigned int pad3:32;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect2;
typedef struct {
int cmd:8;
unsigned int dol_fmt:4;
unsigned int pad0:1;
unsigned int tile:3;
unsigned int tlut_name:4;
unsigned int wrap_s:2;
unsigned int wrap_t:2;
unsigned int shift_s:4;
unsigned int shift_t:4;
unsigned int pad1:32;
} Gsettile_dolphin;
typedef struct {
int cmd:8;
unsigned int sl:14;
unsigned int slen:10;
s8 isDolphin:1;
unsigned int pad:4;
unsigned int tile:3;
unsigned int tl:14;
unsigned int tlen:10;
} Gsettilesize_Dolphin;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int isDolphin:1;
unsigned int ht:8;
unsigned int wd:10;
unsigned int imgaddr:32;
} Gsetimg2;
typedef union {
Gsetimg setimg;
Gsetimg2 setimg2;
} Gsetimg_new;
typedef struct {
int cmd:8;
unsigned int type:2;
unsigned int pad0:2;
unsigned int tlut_name:4;
unsigned int pad1:2;
unsigned int count:14;
unsigned int tlut_addr:32;
} Gloadtlut_dolphin;
typedef struct {
unsigned int cmd:8;
unsigned int xparam:8;
unsigned int pad:2;
unsigned int level:3;
unsigned int tile:3;
unsigned int on:8;
unsigned short s;
unsigned short t;
} Gtexture_internal;
typedef struct {
unsigned int cmd:8;
unsigned int index:8;
unsigned int offset:16;
unsigned int data;
} Gmoveword;
typedef struct {
unsigned int cmd:8;
unsigned int length:8;
unsigned int offset:8;
unsigned int index:8;
unsigned int data;
} Gmovemem;
typedef struct Gsettexedgealpha {
unsigned int cmd:8;
unsigned int unused0:24;
unsigned int unused1:24;
unsigned int tex_edge_alpha:8;
} Gsettexedgealpha;
typedef struct {
int cmd:8;
unsigned int x0:10;
unsigned int x0frac:2;
unsigned int y0:10;
unsigned int y0frac:2;
unsigned int pad:8;
unsigned int x1:10;
unsigned int x1frac:2;
unsigned int y1:10;
unsigned int y1frac:2;
} Gscissor;
typedef struct {
int cmd:8;
unsigned int x0:10;
unsigned int x0frac:2;
unsigned int y0:10;
unsigned int y0frac:2;
unsigned int pad:8;
unsigned int x1:10;
unsigned int x1frac:2;
unsigned int y1:10;
unsigned int y1frac:2;
} Gfillrect2;
typedef struct Gnoop {
unsigned int cmd: 8;
unsigned int tag: 8;
unsigned int param0: 16;
unsigned int param1;
} Gnoop;
typedef struct Gmtx {
unsigned int cmd: 8;
unsigned int par: 8;
unsigned int pad: 8;
unsigned int type: 8;
unsigned int addr;
} Gmtx;
typedef struct Gvtx {
unsigned int cmd: 8;
unsigned int pad0: 4;
unsigned int n: 8;
unsigned int pad1: 4;
unsigned int vn:8;
unsigned int addr;
} Gvtx;
typedef struct Gline3D_new {
unsigned int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int wd: 8;
unsigned int pad;
} Gline3D_new;
typedef struct Gtri1 {
unsigned int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int v2: 8;
unsigned int pad;
} Gtri1;
typedef struct Gtri2 {
int cmd: 8;
unsigned int t0v0: 8;
unsigned int t0v1: 8;
unsigned int t0v2: 8;
unsigned int pad: 8;
unsigned int t1v0: 8;
unsigned int t1v1: 8;
unsigned int t1v2: 8;
} Gtri2;
typedef struct Gtrin_independ {
unsigned int cmd: 8;
unsigned int count: 7;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v2_1: 2;
unsigned int f1v2_0: 3;
unsigned int f1v1: 5;
unsigned int f1v0: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gtrin_independ;
typedef struct Gtrin {
unsigned int f3v2: 5;
unsigned int f3v1: 5;
unsigned int f3v0: 5;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v2_1: 2;
unsigned int f1v2_0: 3;
unsigned int f1v1: 5;
unsigned int f1v0: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gtrin;
typedef struct Gtrin_7b {
unsigned int f2v2: 7;
unsigned int f2v1: 7;
unsigned int f2v0: 7;
unsigned int f1v2: 7;
unsigned int f1v1_1: 4;
unsigned int f1v1_0: 3;
unsigned int f1v0: 7;
unsigned int f0v2: 7;
unsigned int f0v1: 7;
unsigned int f0v0: 7;
unsigned int is7bit: 1;
} Gtrin_7b;
typedef struct Gquad_independ {
unsigned int cmd: 8;
unsigned int count: 7;
unsigned int unused: 5;
unsigned int f1v3: 5;
unsigned int f1v2: 5;
unsigned int f1v1_1: 2;
unsigned int f1v1_0: 3;
unsigned int f1v0: 5;
unsigned int f0v3: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gquad_independ;
typedef struct Gquad {
unsigned int f2v3: 5;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v3: 5;
unsigned int f1v2: 5;
unsigned int f1v1_1: 2;
unsigned int f1v1_0: 3;
unsigned int f1v0: 5;
unsigned int f0v3: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gquad;
typedef struct Gquad_7b {
unsigned int f1v3: 7;
unsigned int f1v2: 7;
unsigned int f1v1: 7;
unsigned int f1v0_1: 4;
unsigned int f1v0_0: 3;
unsigned int pad: 4;
unsigned int f0v3: 7;
unsigned int f0v2: 7;
unsigned int f0v1: 7;
unsigned int f0v0: 7;
unsigned int pad0: 3;
unsigned int is7bit: 1;
} Gquad_7b;
typedef struct Gquad0 {
int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int v2: 8;
unsigned int pad: 24;
unsigned int v3: 8;
} Gquad0;
typedef struct Gculldl {
int cmd: 8;
unsigned int pad0: 8;
unsigned int vstart: 16;
unsigned int pad1: 16;
unsigned int vend: 16;
} Gculldl;
typedef struct Gspecial1 {
int cmd: 8;
int mode: 8;
unsigned int param0: 16;
unsigned int param1;
} Gspecial1;
typedef struct {
int cmd:8;
int pad0:8;
u32 sft:8;
u32 len:8;
unsigned int data:32;
} Gsetothermode_dolphin;
typedef struct {
unsigned char col[3];
unsigned char kc;
unsigned char colc[3];
unsigned char kl;
signed short pos[3];
unsigned char kq;
} Light_pos_t;
typedef union {
Light_t l;
Light_pos_t p;
long long int force_align[2];
} Light_new;
typedef struct {
u8 color0;
u8 color1;
u8 color2;
u8 color3;
} combiner_tev_color;
typedef struct {
u8 alpha0;
u8 alpha1;
} combiner_tev_alpha;
typedef s64 OSTime;
typedef u32 OSTick;
OSTime OSGetTime(void);
OSTime __OSGetSystemTime(void);
OSTick OSGetTick(void);
typedef struct OSCalendarTime_s {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* td);
void DCEnable(void);
void DCInvalidateRange(void*, u32);
void DCFlushRange(void*, u32);
void DCStoreRange(void*, u32);
void DCFlushRangeNoSync(void*, u32);
void DCStoreRangeNoSync(void*, u32);
void DCZeroRange(void*, u32);
void DCTouchRange(void*, u32 len);
void ICInvalidateRange(void*, u32);
void ICFlashInvalidate(void);
void ICEnable(void);
void LCDisable(void);
typedef float MtxF_t[4][4];
typedef union {
MtxF_t mf;
struct {
float xx, yx, zx, wx,
xy, yy, zy, wy,
xz, yz, zz, wz,
xw, yw, zw, ww;
};
} MtxF;
typedef struct {
f32 x, y, z;
} Vec3f;
void guMtxIdentF(float mf[4][4]);
inline void guTranslateF(float m[4][4], float x, float y, float z);
inline void guScaleF(float mf[4][4], float x, float y, float z);
void guMtxF2L(float mf[4][4], Mtx *m);
void guTranslate(Mtx *m, float x, float y, float z);
void guScale(Mtx *m, float x, float y, float z);
void guMtxIdent(Mtx *m);
void guNormalize(float* x, float* y, float* z);
void guOrtho(Mtx *m, float l, float r, float b, float t, float n, float f, float scale);
void guRotate(Mtx* m, float a, float x, float y, float z);
void guLookAt(Mtx *m,
float xEye, float yEye, float zEye,
float xAt, float yAt, float zAt,
float xUp, float yUp, float zUp);
void guPerspective(Mtx *m, u16 *perspNorm, float fovy,
float aspect, float near, float far, float scale);
void guLookAtHilite (Mtx *m, LookAt *l, Hilite *h,
float xEye, float yEye, float zEye,
float xAt, float yAt, float zAt,
float xUp, float yUp, float zUp,
float xl1, float yl1, float zl1,
float xl2, float yl2, float zl2,
int twidth, int theight);
extern signed short sins (unsigned short angle);
extern signed short coss (unsigned short angle);
typedef struct OSMessageQueue OSMessageQueue;
typedef void* OSMessage;
struct OSMessageQueue {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
int msgCount;
int firstIndex;
int usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, int msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, int flags);
typedef void* OSMesg;
typedef struct OSMesgQueue_s {
OSThread* mtqueue;
OSThread* fullqueue;
volatile int validCount;
int first;
int msgCount;
OSMesg* msg;
} OSMesgQueue;
extern void osCreateMesgQueue(OSMessageQueue* mq, OSMessage msg, int flags);
extern int osSendMesg(OSMessageQueue* mq, OSMessage msg, int flags);
extern int osRecvMesg(OSMessageQueue* mq, OSMessage* msg, int flags);
void osShutdownStart(int shutdown_type);
typedef struct OSAlarm OSAlarm;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm
{
OSAlarmHandler handler;
OSTime fire;
OSAlarm *prev;
OSAlarm *next;
OSTime period;
OSTime start;
};
void OSInitAlarm(void);
void OSSetAlarm(OSAlarm *alarm, OSTime tick, OSAlarmHandler handler);
void OSSetAbsAlarm(OSAlarm *alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm *alarm, OSTime start, OSTime period,
OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm *alarm);
void OSCancelAlarm(OSAlarm *alarm);
BOOL OSCheckAlarmQueue(void);
typedef struct OSTimer_s {
OSAlarm alarm;
struct OSTimer_s* next;
struct OSTimer_s* prev;
OSTime interval;
OSTime value;
OSMessageQueue* mq;
OSMessage msg;
} OSTimer;
extern int osSetTimer(OSTimer* t, OSTime countdown, OSTime interval, OSMessageQueue* mq, OSMessage msg);
extern void osStopTimerAll(void);
extern OSTimer* __osTimerList;
typedef s32 OSPri;
typedef s32 OSId;
OSId osGetThreadId(OSThread*);
extern void osCreateThread2(OSThread* t, OSId id, void(*entry)(void*), void* arg, void* stack_pointer, size_t stack_size, OSPriority priority);
extern void osStartThread(OSThread* t);
extern void osDestroyThread(OSThread* t);
typedef struct {
u32 errStatus;
void* dramAddr;
void* C2Addr;
u32 sectorSize;
u32 C1ErrNum;
u32 C1ErrSector[4];
} __OSBlockInfo;
typedef struct {
u32 cmdType;
u16 transferMode;
u16 blockNum;
s32 sectorNum;
uintptr_t devAddr;
u32 bmCtlShadow;
u32 seqCtlShadow;
__OSBlockInfo block[2];
} __OSTranxInfo;
typedef struct OSPiHandle {
struct OSPiHandle* next;
u8 type;
u8 latency;
u8 pageSize;
u8 relDuration;
u8 pulse;
u8 domain;
uintptr_t baseAddress;
u32 speed;
__OSTranxInfo transferInfo;
} OSPiHandle;
typedef struct {
u8 type;
uintptr_t address;
} OSPiInfo;
typedef struct {
u16 type;
u8 pri;
u8 status;
OSMesgQueue* retQueue;
} OSIoMesgHdr;
typedef struct {
OSIoMesgHdr hdr;
void* dramAddr;
uintptr_t devAddr;
size_t size;
OSPiHandle* piHandle;
} OSIoMesg;
extern void __osInitialize_common();
extern BOOL osIsEnableShutdown(void);
extern BOOL osIsDisableShutdown(void);
extern OSTime osGetDisableShutdownTime(void);
extern OSTime __osShutdownTime;
extern OSTime __osDisableShutdownTime;
extern int __osShutdownDisable;
s16 sins(u16);
s16 coss(u16);
f32 fatan2(f32, f32);
f32 fsqrt(f32);
f32 facos(f32);
typedef u64 Z_OSTime;
int bcmp(void* v1, void* v2, u32 size);
void bcopy(void* src, void* dst, size_t n);
void bzero(void* ptr, size_t size);
void osSyncPrintf(const char* fmt, ...);
void osWritebackDCache(void* vaddr, u32 nbytes);
u32 osGetCount(void);
OSTime osGetTime(void);
extern s32 osAppNMIBuffer[16];
extern int osShutdown;
extern u8 __osResetSwitchPressed;
typedef struct DVDCommandBlock DVDCommandBlock;
typedef struct DVDFileInfo DVDFileInfo;
typedef void (*DVDCallback)(s32 result, DVDFileInfo* fileInfo);
typedef void (*DVDCBCallback)(s32 result, DVDCommandBlock* block);
typedef void (*DVDLowCallback)(u32 intType);
typedef void (*DVDDoneReadCallback)(s32, DVDFileInfo*);
typedef void (*DVDOptionalCommandChecker)(DVDCommandBlock* block, DVDLowCallback callback);
typedef struct DVDDriveInfo {
u16 revisionLevel;
u16 deviceCode;
u32 releaseDate;
u8 padding[24];
} DVDDriveInfo;
typedef struct DVDDiskID {
char gameName[4];
char company[2];
u8 diskNumber;
u8 gameVersion;
u8 streaming;
u8 streamBufSize;
u8 padding[22];
} DVDDiskID;
struct DVDCommandBlock {
DVDCommandBlock* next;
DVDCommandBlock* prev;
u32 command;
s32 state;
u32 offset;
u32 length;
void* addr;
u32 currTransferSize;
u32 transferredSize;
DVDDiskID* id;
DVDCBCallback callback;
void* userData;
};
struct DVDFileInfo
{
DVDCommandBlock cb;
u32 startAddr;
u32 length;
DVDCallback callback;
};
typedef struct DVDDir {
u32 entryNum;
u32 location;
u32 next;
} DVDDir;
typedef struct DVDDirEntry {
u32 entryNum;
BOOL isDir;
char* name;
} DVDDirEntry;
typedef struct DVDQueue DVDQueue;
struct DVDQueue {
DVDQueue* mHead;
DVDQueue* mTail;
};
typedef struct DVDBB1 {
u32 appLoaderLength;
void* appLoaderFunc1;
void* appLoaderFunc2;
void* appLoaderFunc3;
} DVDBB1;
typedef struct DVDBB2 {
u32 bootFilePosition;
u32 FSTPosition;
u32 FSTLength;
u32 FSTMaxLength;
void* FSTAddress;
u32 userPosition;
u32 userLength;
u32 reserved_1C;
} DVDBB2;
void DVDInit();
BOOL DVDOpen(char* filename, DVDFileInfo* fileInfo);
BOOL DVDFastOpen(s32 entryNum, DVDFileInfo* fileInfo);
s32 DVDReadPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, s32 prio);
BOOL DVDReadAsyncPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, DVDCallback callback, s32 prio);
BOOL DVDClose(DVDFileInfo* fileInfo);
void DVDResume();
void DVDReset();
BOOL DVDCancelAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancel(volatile DVDCommandBlock* block);
s32 DVDChangeDisk(DVDCommandBlock* block, DVDDiskID* id);
BOOL DVDChangeDiskAsync(DVDCommandBlock* block, DVDDiskID* id, DVDCBCallback callback);
s32 DVDGetCommandBlockStatus(const DVDCommandBlock* block);
s32 DVDGetDriveStatus();
BOOL DVDSetAutoInvalidation(BOOL doAutoInval);
void* DVDGetFSTLocation();
BOOL DVDOpenDir(char* dirName, DVDDir* dir);
BOOL DVDReadDir(DVDDir* dir, DVDDirEntry* dirEntry);
BOOL DVDCloseDir(DVDDir* dir);
BOOL DVDGetCurrentDir(char* path, u32 maxLength);
BOOL DVDChangeDir(char* dirName);
s32 DVDConvertPathToEntrynum(char* path);
s32 DVDGetTransferredSize(DVDFileInfo* fileInfo);
DVDDiskID* DVDGetCurrentDiskID();
BOOL DVDCompareDiskID(DVDDiskID* id1, DVDDiskID* id2);
DVDLowCallback DVDLowClearCallback();
BOOL DVDPrepareStreamAsync(DVDFileInfo* fileInfo, u32 length, u32 offset, DVDCallback callback);
s32 DVDCancelStream(DVDCommandBlock* block);
BOOL DVDCheckDisk();
void DVDPause();
s32 DVDSeekPrio(DVDFileInfo* fileInfo, s32 offset, s32 prio);
BOOL DVDSeekAsyncPrio(DVDFileInfo* fileInfo, s32 offset, DVDCallback callback, s32 prio);
BOOL DVDFastOpenDir(s32 entryNum, DVDDir* dir);
BOOL DVDCancelAllAsync(DVDCBCallback callback);
s32 DVDCancelAll();
void DVDDumpWaitingQueue();
DVDDiskID DiskID : (0x80000000) ;
typedef void (*PADSamplingCallback)(void);
typedef struct PADStatus
{
u16 button;
s8 stickX;
s8 stickY;
s8 substickX;
s8 substickY;
u8 triggerLeft;
u8 triggerRight;
u8 analogA;
u8 analogB;
s8 err;
} PADStatus;
BOOL PADReset(u32 mask);
BOOL PADRecalibrate(u32 mask);
BOOL PADInit();
u32 PADRead(PADStatus* status);
void PADSetSamplingRate(u32 msec);
void __PADTestSamplingRate(u32 tvmode);
void PADControlAllMotors(const u32 *commandArray);
void PADControlMotor(s32 chan, u32 command);
void PADSetSpec(u32 spec);
u32 PADGetSpec();
BOOL PADGetType(s32 chan, u32* type);
BOOL PADSync(void);
void PADSetAnalogMode(u32 mode);
PADSamplingCallback PADSetSamplingCallback(PADSamplingCallback callback);
void PADClamp(PADStatus * status);
typedef enum JKRExpandSwitch {
EXPAND_SWITCH_DEFAULT,
EXPAND_SWITCH_DECOMPRESS,
EXPAND_SWITCH_NONE
} JKRExpandSwitch;
enum EButtons {
MAINSTICK_UP = 0x8000000,
MAINSTICK_DOWN = 0x4000000,
MAINSTICK_RIGHT = 0x2000000,
MAINSTICK_LEFT = 0x1000000,
CSTICK_UP = 0x80000,
CSTICK_DOWN = 0x40000,
CSTICK_RIGHT = 0x20000,
CSTICK_LEFT = 0x10000,
START = 0x1000,
Y = 0x800,
X = 0x400,
B = 0x200,
A = 0x100,
L = 0x40,
R = 0x20,
Z = 0x10,
DPAD_UP = 0x8,
DPAD_DOWN = 0x4,
DPAD_RIGHT = 0x2,
DPAD_LEFT = 0x1
};
typedef struct {
u16 mFileID;
u16 mHash;
u32 mFlag;
u32 mDataOffset;
u32 mSize;
void* mData;
} CSDIFileEntry;
extern void* JC_JUTVideo_getManager();
extern u32 JC_JUTVideo_getFbWidth(void* manager);
extern u32 JC_JUTVideo_getEfbHeight(void* manager);
extern void JC_JUTVideo_setRenderMode(void* manager, GXRenderModeObj* renderMode);
extern void JC_JKRAramHeap_dump(void* heap);
extern void* JC_JKRAram_getAramHeap();
extern u32 JC_JKRAramArchive_getAramAddress_byName(void* archive, u32 root_name, const char* res_name);
extern CSDIFileEntry* JC__JKRGetResourceEntry_byName(u32 root_name, const char* res_name, void* archive);
extern void* JC__JKRDvdToMainRam_byName(const char* name, u8* buf, JKRExpandSwitch expandSwitch);
extern void JC__JKRDetachResource(void* ptr);
extern int JC_JUTConsole_isVisible(void* console);
extern void JC_JUTConsole_setVisible(void* console, BOOL visible);
extern void JC_JUTConsole_clear(void* console);
extern void JC_JUTConsole_scroll(void* console, int scroll);
extern int JC_JUTConsole_getPositionX(void* console);
extern void JC_JUTConsole_setPosition(void* console, int x, int y);
extern int JC_JUTConsole_getOutput(void* console);
extern int JC_JUTConsole_getLineOffset(void* console);
extern void JC_JUTConsole_dumpToTerminal(void* console, int lines);
extern void JC_JUTConsole_setOutput(void* console, int output);
extern void JC_JUTConsole_scrollToLastLine(void* console);
extern void JC_JUTConsole_scrollToFirstLine(void* console);
extern void JC_JUTConsole_scroll(void* console, int amount);
extern u32 JC_JUTConsole_getHeight(void* console);
extern u32 JC_JUTConsole_getUsedLine(void* console);
extern void JC_JUTConsole_print_f_va(void* console, const char* fmt, va_list arg);
extern void JC_JUTConsole_print_f(void* console, const char* fmt, ...);
extern void* JC_JUTConsoleManager_getManager();
extern void JC_JUTConsoleManager_drawDirect(void* manager, int direct);
extern void* JC_JUTDbPrint_getManager();
extern void JC_JUTDbPrint_setVisible(void* dbprint, BOOL visible);
extern void* JC_JUTProcBar_getManager();
extern void JC_JUTProcBar_setVisible(void* procbar, BOOL visible);
extern void JC_JUTProcBar_setVisibleHeapBar(void* procbar, BOOL visible);
extern void* JC_JUTException_getManager();
extern void* JC_JUTException_getConsole();
extern BOOL JC_JUTException_isEnablePad(void* manager);
extern int JC_JUTException_readPad(void* mgr, u32* trigger, u32* button);
extern void JC_JUTException_waitTime(u32 time);
extern void JC_JUTException_enterAllPad(void* manager);
extern void JC_JUTException_setMapFile(const char* path);
extern void JC_JUTException_setPreUserCallback(void* callback);
extern void JC_JUTException_setPostUserCallback(void* callback);
extern void JC_JUTAssertion_changeDevice(int device);
extern void JC_JUTAssertion_changeDisplayTime(int displayTime);
extern void JC_JUTGamePad_read();
extern PADStatus JC_JUTGamePad_getPadStatus(u32 port);
extern u8 JC_JUTGamePad_recalibrate(u32 port);
extern void* JC_JFWDisplay_getManager();
extern int JC_JFWDisplay_startFadeIn(void* manager, int len);
extern void JC_JFWDisplay_setFrameRate(void* manager, u16 framerate);
extern void JC_JFWDisplay_endFrame(void* manager);
extern void JC_JFWDisplay_beginRender(void* manager);
extern void JC_JFWDisplay_endRender(void* manager);
extern void JC_JFWDisplay_setClearColor(void* manager, GXColor color);
extern int JC_JFWDisplay_startFadeOut(void* manager, int fadeout);
extern void JC_JFWDisplay_clearEfb(void* manager, GXColor color);
extern const GXRenderModeObj* JC_JFWDisplay_getRenderMode(void* manager);
extern void* JC_JFWDisplay_changeToSingleXfb(void* manager, int index);
extern void* JC_JFWDisplay_changeToDoubleXfb(void* manager);
extern int JC_JFWDisplay_getEfbWidth(void* manager);
extern int JC_JFWDisplay_getEfbHeight(void* manager);
extern void* JC_JFWDisplay_createManager_0(GXRenderModeObj* renderMode, void* heap, int exfbNumber, int enableAlpha);
extern void JC_JFWDisplay_setFader(void* manager, void* fader);
extern void JC_JFWDisplay_setGamma(void* manager, int gamma);
extern void JC_JFWDisplay_destroyManager();
extern void JC_JFWSystem_setMaxStdHeap(int max);
extern void JC_JFWSystem_setSysHeapSize(u32 size);
extern void JC_JFWSystem_setFifoBufSize(u32 size);
extern void JC_JFWSystem_setAramAudioBufSize(u32 size);
extern void JC_JFWSystem_setAramGraphBufSize(u32 size);
extern void JC_JFWSystem_init();
extern void* JC_JFWSystem_getSystemConsole();
extern void* JC_JFWSystem_getRootHeap();
extern void* JC_JFWSystem_getSystemHeap();
extern void* JC_J2DOrthoGraph_new();
extern void JC_J2DOrthoGraph_delete(void* orthograph);
extern void* JC_JUTFader_new(int ul_x, int ul_y, int br_x, int br_y, u32* color);
extern void JC_JUTFader_delete(void* fader);
extern void* JC__JKRGetResource(const char* resourceName);
extern void JC__JKRRemoveResource(void* res);
extern void JC_J2DOrthoGraph_setOrtho(void* orthograph, int ul_x, int ul_y, int br_x, int br_y);
extern void JC_J2DOrthoGraph_setPort(void* orthograph);
extern void* JC_JKRAramArchive_new();
extern BOOL JC__JKRMountFixedAramArchive(void* aram_archive, const char* file);
extern void JC__JKRUnmountFixedAramArchive(void* aram_archive);
extern void JC_JKRAramArchive_delete(void* aram_archive);
extern u32 JC_JKRHeap_getFreeSize(void* heap);
extern void* JC_JKRHeap_alloc(void* heap, u32 size, int align);
extern void JC_JKRHeap_free(void* heap, void* mem);
extern size_t JC_JKRHeap_getSize(void* heap, void* mem);
extern s32 JC_JKRHeap_resize(void* heap, void* ptr, s32 new_size);
extern int JC_JKRHeap_dump(void* heap);
extern s32 JC_JKRHeap_getTotalFreeSize(void* heap);
extern u32 JC__JKRGetMemBlockSize(void* heap, void* ptr);
extern u8 JC_JKRExpHeap_changeGroupID(void* expheap, u8 groupId);
extern void* JC__JKRAllocFromAram(size_t size);
extern u8* JC__JKRAramToMainRam_block(void* aramBlock, u8* ramDst, size_t size);
extern void* JC__JKRMainRamToAram_block(u8* ramAddr, void* aramBlock, size_t size);
extern void* JW_Alloc(size_t size, int align);
extern void JW_Free(void* ptr);
extern s32 JW_Resize(void* ptr, size_t new_size);
extern size_t JW_GetMemBlockSize(void* ptr);
extern void JW_JUTXfb_clearIndex(void);
extern void JW_JUTReport(int x, int y, int show_count, const char* fmt, ...);
extern int JC_JKRDecomp_checkCompressed(u8* bufp);
extern void JC_JKRDecomp_decode(u8* comp_bufp, u8* decomp_bufp, u32 decomp_buf_size, u32 skipCount);
extern void* JC__JKRMountArchive(const char* path, int mount_mode, void* heap, int mount_direction);
extern void* JC__JKRGetSystemHeap();
extern void* JC_JUTXfb_getManager();
extern void JC_JUTXfb_clearIndex(void* manager);
extern u32 JC_JKRAramBlock_getAddress(void* aramBlock);
typedef struct CResTIMG {
u8 mTextureFormat;
u8 mTransparency;
u16 mSizeX;
u16 mSizeY;
u8 mWrapS;
u8 mWrapT;
u8 mPaletteFormat;
u8 mColorFormat;
u16 mPaletteEntryCount;
u32 mPaletteOffset;
GXBool mIsMIPmapEnabled;
GXBool mDoEdgeLOD;
GXBool mIsBiasClamp;
GXBool mIsMaxAnisotropy;
u8 mMinFilterType;
u8 mMagFilterType;
s8 mMinLOD;
s8 mMaxLOD;
u8 mTotalImageCount;
u8 _19;
s16 mLODBias;
u32 mImageDataOffset;
} CResTIMG;
enum resource_index {
RESOURCE_FGDATA,
RESOURCE_MAIL,
RESOURCE_MAIL_TABLE,
RESOURCE_MAILA,
RESOURCE_MAILA_TABLE,
RESOURCE_MAILB,
RESOURCE_MAILB_TABLE,
RESOURCE_MAILC,
RESOURCE_MAILC_TABLE,
RESOURCE_PALLET_BOY,
RESOURCE_PS,
RESOURCE_PS_TABLE,
RESOURCE_PSZ,
RESOURCE_PSZ_TABLE,
RESOURCE_SELECT,
RESOURCE_SELECT_TABLE,
RESOURCE_STRING,
RESOURCE_STRING_TABLE,
RESOURCE_SUPERZ,
RESOURCE_SUPERZ_TABLE,
RESOURCE_SUPER,
RESOURCE_SUPER_TABLE,
RESOURCE_TEX_BOY,
RESOURCE_FACE_BOY,
RESOURCE_FGNPCDATA,
RESOURCE_MESSAGE,
RESOURCE_MESSAGE_TABLE,
RESOURCE_MY_ORIGINAL,
RESOURCE_NEEDLEWORK_JOYBOOT,
RESOURCE_PLAYER_ROOM_FLOOR,
RESOURCE_PLAYER_ROOM_WALL,
RESOURCE_NPC_NAME_STR_TABLE,
RESOURCE_D_OBJ_NPC_STOCK_SCH,
RESOURCE_D_OBJ_NPC_STOCK_SCL,
RESOURCE_TITLE,
RESOURCE_MURA_SPRING,
RESOURCE_MURA_SUMMER,
RESOURCE_MURA_FALL,
RESOURCE_MURA_WINTER,
RESOURCE_ODEKAKE,
RESOURCE_OMAKE,
RESOURCE_EKI1,
RESOURCE_EKI1_2,
RESOURCE_EKI1_3,
RESOURCE_EKI1_4,
RESOURCE_EKI1_5,
RESOURCE_EKI2,
RESOURCE_EKI2_2,
RESOURCE_EKI2_3,
RESOURCE_EKI2_4,
RESOURCE_EKI2_5,
RESOURCE_EKI3,
RESOURCE_EKI3_2,
RESOURCE_EKI3_3,
RESOURCE_EKI3_4,
RESOURCE_EKI3_5,
RESOURCE_TEGAMI,
RESOURCE_TEGAMI2,
RESOURCE_FAMIKON,
RESOURCE_BOY1,
RESOURCE_BOY2,
RESOURCE_BOY3,
RESOURCE_BOY4,
RESOURCE_BOY5,
RESOURCE_BOY6,
RESOURCE_BOY7,
RESOURCE_BOY8,
RESOURCE_GIRL1,
RESOURCE_GIRL2,
RESOURCE_GIRL3,
RESOURCE_GIRL4,
RESOURCE_GIRL5,
RESOURCE_GIRL6,
RESOURCE_GIRL7,
RESOURCE_GIRL8,
RESOURCE_D_BG_ISLAND_SCH,
RESOURCE_NUM
};
enum {
JUT_MAINSTICK_UP = 0x8000000,
JUT_MAINSTICK_DOWN = 0x4000000,
JUT_MAINSTICK_RIGHT = 0x2000000,
JUT_MAINSTICK_LEFT = 0x1000000,
JUT_CSTICK_UP = 0x80000,
JUT_CSTICK_DOWN = 0x40000,
JUT_CSTICK_RIGHT = 0x20000,
JUT_CSTICK_LEFT = 0x10000,
JUT_START = 0x1000,
JUT_Y = 0x800,
JUT_X = 0x400,
JUT_B = 0x200,
JUT_A = 0x100,
JUT_L = 0x40,
JUT_R = 0x20,
JUT_Z = 0x10,
JUT_DPAD_UP = 0x8,
JUT_DPAD_DOWN = 0x4,
JUT_DPAD_RIGHT = 0x2,
JUT_DPAD_LEFT = 0x1
};
extern void JW_UpdateVideoMode();
extern void JW_SetProgressiveMode(int enabled);
extern void JW_SetLowResoMode(int enabled);
extern void JW_SetFamicomMode(int enabled);
extern void JW_SetVideoPan(u16 origin_x, u16 origin_y, u16 width, u16 height);
extern void JW_SetLogoMode(int enabled);
extern void JW_JUTGamePad_read();
extern void JW_getPadStatus(PADStatus* padStatus);
extern int JW_JUTGamepad_getErrorStatus();
extern u32 JW_JUTGamepad_getButton();
extern u32 JW_JUTGamepad_getTrigger();
extern f32 JW_JUTGamepad_getSubStickValue();
extern s16 JW_JUTGamepad_getSubStickAngle();
extern void JW_BeginFrame();
extern void JW_EndFrame();
extern int JW_setClearColor(u8 r, u8 g, u8 b);
extern u32 JW_GetAramAddress(int res_no);
extern u8* _JW_GetResourceAram(u32 aram_addr, u8* dst, u32 size);
extern u32 JW_GetResSizeFileNo(int res_no);
extern void JW_Init();
extern void JW_Init2();
extern void JW_Init3();
extern void JW_Cleanup();
typedef struct OSModuleHeader OSModuleHeader;
typedef u32 OSModuleID;
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
OSModuleQueue __OSModuleList : (0x800030C8) ;
void* __OSStringTable : (0x800030D0) ;
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u8 bssSection;
u32 prolog;
u32 epilog;
u32 unresolved;
u32 align;
u32 bssAlign;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSLinkFixed(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* module);
void OSSetStringTable(const void* string_table);
void __OSModuleInit(void);
typedef struct boot_tbl_s {
const char* msg;
u16 param_upper;
u16 param_lower;
} boot_tbl_t;
extern u32 convert_partial_address(u32 partial_addr);
extern void HotResetIplMenu();
extern void* boot_copyDate;
extern void* HotStartEntry;
extern OSTime InitialStartTime;
extern u8 boot_sound_initializing;
typedef void(*HotStartProc)();
OSModuleHeader* BaseModule : (0x800030C8) ;
typedef struct OSFontHeader {
u16 fontType;
u16 firstChar;
u16 lastChar;
u16 invalChar;
u16 ascent;
u16 descent;
u16 width;
u16 leading;
u16 cellWidth;
u16 cellHeight;
u32 sheetSize;
u16 sheetFormat;
u16 sheetColumn;
u16 sheetRow;
u16 sheetWidth;
u16 sheetHeight;
u16 widthTable;
u32 sheetImage;
u32 sheetFullSize;
u8 c0;
u8 c1;
u8 c2;
u8 c3;
} OSFontHeader;
u16 OSGetFontEncode(void);
u16 OSSetFontEncode(u16 encode);
extern Gfx gam_win1_winT_model[];
extern Gfx gam_win2_winT_model[];
extern Gfx gam_win1_cursor_model[];
extern Gfx gam_win1_moji_model[];
extern Gfx gam_win1_moji2_model[];
extern Gfx gam_win1_moji3_model[];
extern Gfx gam_win2_moji_model[];
extern Gfx gam_win3_moji_model[];
extern u8 nintendo_376x104[];
extern Vtx logo_nin_v[];
extern Gfx logo_ninT_model[];
typedef struct ucode_info_s {
int type;
void* ucode_p;
} ucode_info;
extern long long int gspF3DZEX2_NoN_PosLight_fifoDataStart[];
extern long long int gspF3DZEX2_NoN_PosLight_fifoTextStart[];
extern unsigned long long gspS2DEX2_fifoDataStart[];
extern unsigned long long gspS2DEX2_fifoTextStart[];
extern long long int* ucode_GetPolyTextStart();
extern long long int* ucode_GetPolyDataStart();
extern unsigned long long* ucode_GetSpriteTextStart();
extern unsigned long long* ucode_GetSpriteDataStart();
extern u8 FrameCansel;
extern void emu64_set_ucode_info(int count, ucode_info* ucode_info);
extern void emu64_set_first_ucode(void* ucode);
extern void emu64_taskstart(Gfx* gfx);
extern void emu64_init();
extern void emu64_refresh();
extern void emu64_cleanup();
extern void emu64_texture_cache_data_entry_set(void* begin, void* end);
typedef void (*OSResetCallback)(void);
OSResetCallback OSSetResetCallback(OSResetCallback callback);
BOOL OSGetResetSwitchState(void);
BOOL OSGetResetButtonState(void);
struct OSResetFunctionQueue {
struct OSResetFunctionInfo* head;
struct OSResetFunctionInfo* tail;
};
typedef BOOL (*OSResetFunction)(BOOL final);
typedef struct OSResetFunctionInfo OSResetFunctionInfo;
struct OSResetFunctionInfo {
OSResetFunction func;
u32 priority;
OSResetFunctionInfo* next;
OSResetFunctionInfo* prev;
};
u32 OSGetResetCode();
void OSResetSystem(int reset, u32 resetCode, BOOL forceMenu);
BOOL OSGetResetSwitchState();
void OSGetSaveRegion(void** start, void** end);
void OSRegisterResetFunction(OSResetFunctionInfo* info);
typedef int OSHeapHandle;
extern volatile OSHeapHandle __OSCurrHeap;
void* OSAllocFromHeap(int heap, unsigned long size);
void* OSAllocFixed(void* rstart, void* rend);
void OSFreeToHeap(int heap, void* ptr);
int OSSetCurrentHeap(int heap);
void* OSInitAlloc(void* arenaStart, void* arenaEnd, int maxHeaps);
int OSCreateHeap(void* start, void* end);
void OSDestroyHeap(int heap);
void OSAddToHeap(int heap, void* start, void* end);
long OSCheckHeap(int heap);
unsigned long OSReferentSize(void* ptr);
void OSDumpHeap(int heap);
void OSVisitAllocated(void (*visitor)(void*, unsigned long));
void* OSGetArenaHi(void);
void* OSGetArenaLo(void);
void OSSetArenaHi(void*);
void OSSetArenaLo(void*);
typedef u16 OSError;
typedef void (*OSErrorHandler)(OSError error, OSContext *context, ...);
typedef void (*OSErrorHandlerEx)(OSError error, OSContext* context, ...);
OSErrorHandler OSSetErrorHandler(OSError error, OSErrorHandler handler);
extern OSErrorHandler __OSErrorTable[(15 + 1) ];
extern u32 __OSFpscrEnableBits;
typedef u8 __OSException;
typedef void (*__OSExceptionHandler)(__OSException exception, OSContext* context);
__OSExceptionHandler __OSSetExceptionHandler(__OSException exception, __OSExceptionHandler handler);
__OSExceptionHandler __OSGetExceptionHandler(__OSException exception);
typedef s16 __OSInterrupt;
typedef u32 OSInterruptMask;
typedef enum OSInterruptType {
OS_INTR_MEM_0,
OS_INTR_MEM_1,
OS_INTR_MEM_2,
OS_INTR_MEM_3,
OS_INTR_MEM_ADDRESS,
OS_INTR_DSP_AI,
OS_INTR_DSP_ARAM,
OS_INTR_DSP_DSP,
OS_INTR_AI_AI,
OS_INTR_EXI_0_EXI,
OS_INTR_EXI_0_TC,
OS_INTR_EXI_0_EXT,
OS_INTR_EXI_1_EXI,
OS_INTR_EXI_1_TC,
OS_INTR_EXI_1_EXT,
OS_INTR_EXI_2_EXI,
OS_INTR_EXI_2_TC,
OS_INTR_PI_CP,
OS_INTR_PI_PE_TOKEN,
OS_INTR_PI_PE_FINISH,
OS_INTR_PI_SI,
OS_INTR_PI_DI,
OS_INTR_PI_RSW,
OS_INTR_PI_ERROR,
OS_INTR_PI_VI,
OS_INTR_PI_DEBUG,
OS_INTR_PI_HSP,
OS_INTR_PI_ACR,
OS_INTR_28,
OS_INTR_29,
OS_INTR_30,
OS_INTR_31,
OS_INTR_MAX
} OSInterruptType;
typedef void (*__OSInterruptHandler)(__OSInterrupt, OSContext*);
extern volatile u32 __OSLastInterruptSrr0;
extern volatile s16 __OSLastInterrupt;
extern volatile s64 __OSLastInterruptTime;
void __RAS_OSDisableInterrupts_begin(void);
void __RAS_OSDisableInterrupts_end(void);
BOOL OSDisableInterrupts(void);
BOOL OSEnableInterrupts(void);
BOOL OSRestoreInterrupts(BOOL);
__OSInterruptHandler __OSSetInterruptHandler(__OSInterrupt, __OSInterruptHandler);
__OSInterruptHandler __OSGetInterruptHandler(__OSInterrupt);
void __OSInterruptInit(void);
u32 __OSMaskInterrupts(u32);
u32 __OSUnmaskInterrupts(u32);
u32 SetInterruptMask(OSInterruptMask mask, OSInterruptMask current);
void __OSDispatchInterrupt(__OSException exception, OSContext* context);
static void Config24MB();
static void Config48MB();
u32 OSGetConsoleSimulatedMemSize(void);
void OSProtectRange(u32 chan, void* addr, u32 nBytes, u32 control);
struct OSMutex
{
OSThreadQueue queue;
OSThread *thread;
s32 count;
OSMutexLink link;
};
struct OSCond
{
OSThreadQueue queue;
};
void OSInitMutex(OSMutex *mutex);
void OSLockMutex(OSMutex *mutex);
void OSUnlockMutex(OSMutex *mutex);
BOOL OSTryLockMutex(OSMutex *mutex);
void OSInitCond(OSCond *cond);
void OSWaitCond(OSCond *cond, OSMutex *mutex);
void OSSignalCond(OSCond *cond);
extern void my_fopen();
extern void my_fgets();
extern void my_fclose();
extern void print_section();
extern void* OSGetCallerPC();
extern void OSDumpStackTrace();
extern s32 OSGetActiveThreadID();
extern void OSReportMonopoly();
extern void OSReportDisable();
extern void OSReportEnable();
extern void OSChangeBootMode(u32 mode);
extern void OSDVDFatalError();
typedef enum {
EXI_STATE_DMA_ACCESS = (1 << 0),
EXI_STATE_IMM_ACCESS = (1 << 1),
EXI_STATE_SELECTED = (1 << 2),
EXI_STATE_ATTACHED = (1 << 3),
EXI_STATE_LOCKED = (1 << 4),
EXI_STATE_BUSY = EXI_STATE_DMA_ACCESS | EXI_STATE_IMM_ACCESS
} EXIState;
typedef enum {
EXI_CHAN_0,
EXI_CHAN_1,
EXI_CHAN_2,
EXI_MAX_CHAN
} EXIChannel;
typedef enum {
EXI_READ,
EXI_WRITE,
EXI_TYPE_2,
EXI_MAX_TYPE
} EXIType;
typedef void (*EXICallback)(s32 chan, OSContext *context);
EXICallback EXISetExiCallback(s32 channel, EXICallback callback);
void EXIInit(void);
BOOL EXILock(s32 channel, u32 device, EXICallback callback);
BOOL EXIUnlock(s32 channel);
BOOL EXISelect(s32 channel, u32 device, u32 frequency);
BOOL EXIDeselect(s32 channel);
BOOL EXIImm(s32 channel, void *buffer, s32 length, u32 type, EXICallback callback);
BOOL EXIImmEx(s32 channel, void *buffer, s32 length, u32 type);
BOOL EXIDma(s32 channel, void *buffer, s32 length, u32 type, EXICallback callback);
BOOL EXISync(s32 channel);
BOOL EXIProbe(s32 channel);
s32 EXIProbeEx(s32 channel);
BOOL EXIAttach(s32 channel, EXICallback callback);
BOOL EXIDetach(s32 channel);
u32 EXIGetState(s32 channel);
s32 EXIGetID(s32 channel, u32 device, u32* id);
void EXIProbeReset(void);
typedef struct OSSram {
u16 checkSum;
u16 checkSumInv;
u32 ead0;
u32 ead1;
u32 counterBias;
s8 displayOffsetH;
u8 ntd;
u8 language;
u8 flags;
} OSSram;
typedef struct OSSramEx {
u8 flashID[2][12];
u32 wirelessKeyboardID;
u16 wirelessPadID[4];
u8 dvdErrorCode;
u8 pad0;
u8 flashIDCheckSum[2];
u16 gbs;
u8 pad1[2];
} OSSramEx;
typedef struct SramControlBlock {
u8 sram[64 ];
u32 offset;
BOOL enabled;
BOOL locked;
BOOL sync;
void (*callback)(void);
} SramControlBlock;
static inline BOOL ReadSram(void* buffer);
static void WriteSramCallback(s32 chan, OSContext* ctx);
static BOOL WriteSram(void* buffer, u32 offset, u32 size);
extern void __OSInitSram();
static inline void* LockSram(u32 offset);
extern OSSram* __OSLockSram();
extern OSSramEx* __OSLockSramEx();
static BOOL UnlockSram(BOOL commit, u32 offset);
extern BOOL __OSSyncSram();
extern u32 OSGetSoundMode();
extern void OSSetSoundMode(u32 mode);
extern u32 OSGetProgressiveMode();
extern void OSSetProgressiveMode(u32 on);
extern void __OSSetBootMode(u8 mode);
extern u16 OSGetWirelessID(s32 chan);
extern void OSSetWirelessID(s32 chan, u16 id);
volatile u16 __VIRegs[59] : 0xCC002000;
volatile u32 __PIRegs[12] : 0xCC003000;
volatile u16 __MEMRegs[64] : 0xCC004000;
volatile u16 __DSPRegs[] : 0xCC005000;
volatile u32 __DIRegs[] : 0xCC006000;
volatile u32 __SIRegs[0x100] : 0xCC006400;
volatile u32 __EXIRegs[0x40] : 0xCC006800;
volatile u32 __AIRegs[8] : 0xCC006C00;
extern void __OSPSInit();
extern void __OSFPRInit();
extern void __OSCacheInit();
void OSPanic(const char* file, int line, const char* message, ...);
void OSVReport(const char* fmt, va_list list);
void OSReport(const char* fmt, ...);
extern void __OSPSInit();
extern void __OSCacheInit();
void OSInit(void);
u32 OSGetConsoleType();
typedef void (*OSExceptionHandler)(u8, OSContext*);
OSExceptionHandler __OSSetExceptionHandler(u8, OSExceptionHandler);
typedef struct OSBootInfo_s {
DVDDiskID DVDDiskID;
unsigned long magic;
unsigned long version;
unsigned long memorySize;
unsigned long consoleType;
void * arenaLo;
void * arenaHi;
void * FSTLocation;
unsigned long FSTMaxLength;
} OSBootInfo;
typedef struct BI2Debug {
s32 debugMonSize;
s32 simMemSize;
u32 argOffset;
u32 debugFlag;
int trackLocation;
int trackSize;
u32 countryCode;
u8 unk[8];
u32 padSpec;
} BI2Debug;
u32 __OSPhysicalMemSize : ((0x8000 << 16) | 0x0028);
volatile int __OSTVMode : ((0x8000 << 16) | 0x00CC);
OSThread *__gUnkThread1 : ((0x8000 << 16) | 0x00D8);
OSThreadQueue __OSActiveThreadQueue : ((0x8000 << 16) | 0x00DC);
OSThread *__gCurrentThread : ((0x8000 << 16) | 0x00E4);
u32 __OSSimulatedMemSize : ((0x8000 << 16) | 0x00F0);
u32 __OSBusClock : ((0x8000 << 16) | 0x00F8);
u32 __OSCoreClock : ((0x8000 << 16) | 0x00FC);
s32 __gUnknown800030C0[2] : ((0x8000 << 16) | 0x30C0);
u8 __gUnknown800030E3 : ((0x8000 << 16) | 0x30E3);
vu16 __OSDeviceCode : ((0x8000 << 16) | 0x30E6) ;
void *OSPhysicalToCached(u32 paddr);
void *OSPhysicalToUncached(u32 paddr);
u32 OSCachedToPhysical(void *caddr);
u32 OSUncachedToPhysical(void *ucaddr);
void *OSCachedToUncached(void *caddr);
void *OSUncachedToCached(void *ucaddr);
typedef struct game_s GAME;
typedef struct controller_s {
f32 move_pX;
f32 move_pY;
f32 move_pR;
s16 move_angle;
f32 last_move_pX;
f32 last_move_pY;
f32 last_move_pR;
s16 last_move_angle;
f32 adjusted_pX;
f32 adjusted_pY;
f32 adjusted_pR;
f32 last_adjusted_pX;
f32 last_adjusted_pY;
f32 last_adjusted_pR;
} MCON;
extern void mCon_ct();
extern void mCon_dt();
extern void mCon_calc(MCON* mcon, f32 stick_x, f32 stick_y);
extern void mCon_main(GAME* game);
extern int chkButton(u16 button);
extern u16 getButton();
extern int chkTrigger(u16 button);
extern u16 getTrigger();
extern int getJoystick_X();
extern int getJoystick_Y();
enum dvderr_state {
DVDERR_NONE = -1,
DVDERR_COVER_OPEN = 0,
DVDERR_NO_DISK,
DVDERR_WRONG_DISK,
DVDERR_RETRY,
DVDERR_FATAL,
DVDERR_NUM
};
typedef void (*DVDERR_DRAW_PROC)();
typedef struct dvderr_work_s {
Gfx gfx[100];
Gfx* gfx_p;
Mtx ortho;
Mtx projection;
Mtx modelview;
f32 scale;
DVDERR_DRAW_PROC draw_proc;
int now_error;
int next_error;
} dvderr_work;
extern int dvderr_draw();
extern void dvderr_init();
static Mtx model_cursor;
static u8 progressive_mode;
static Gfx gam_win1_cursor_setup[] = {
{{ (((unsigned int) (((unsigned int)(0xd7) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (3)) - 1)) << (11))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (3)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(((0))) & ((0x01 << (7)) - 1)) << (1)))), (((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))) }} ,
{{ ((unsigned int) (((unsigned int)(0xfc) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (20))) | ((unsigned int) (((unsigned int)((31)) & ((0x01 << (5)) - 1)) << (15))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (9)))) | (((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (5))) | ((unsigned int) (((unsigned int)((31)) & ((0x01 << (5)) - 1)) << (0))))) & ((0x01 << (24)) - 1)) << (0))), (unsigned int)((((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (28))) | ((unsigned int) (((unsigned int)((3)) & ((0x01 << (3)) - 1)) << (15))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((3)) & ((0x01 << (3)) - 1)) << (9)))) | (((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (21))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (18))) | ((unsigned int) (((unsigned int)((3)) & ((0x01 << (3)) - 1)) << (6))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (3))) | ((unsigned int) (((unsigned int)((3)) & ((0x01 << (3)) - 1)) << (0))))) }} ,
{{ ((unsigned int) (((unsigned int)(0xe2) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(32-(3)-(29)) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)((29)-1) & ((0x01 << (8)) - 1)) << (0))), (unsigned int)((0x8 | 0x40 | 0 | 0 | 0x2000 | (0) << 30 | (0) << 26 | (1) << 22 | (1) << 18) | (0x8 | 0x40 | 0 | 0 | 0x2000 | (0) << 28 | (0) << 24 | (1) << 20 | (1) << 16)) }} ,
{{ (((unsigned int) (((unsigned int)(0xd9) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(~(u32)(-1)) & ((0x01 << (24)) - 1)) << (0)))),(u32)((0x00000004 | 0x00200000)) }} ,
{{ ((unsigned int) (((unsigned int)(0xdf) & ((0x01 << (8)) - 1)) << (24))), 0 }} ,
};
static Gfx gam_win1_moji_setup[] = {
{{ (((unsigned int) (((unsigned int)(0xd7) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (3)) - 1)) << (11))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (3)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(((1))) & ((0x01 << (7)) - 1)) << (1)))), (((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))) }} ,
{{ ((unsigned int) (((unsigned int)(0xfc) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (20))) | ((unsigned int) (((unsigned int)((31)) & ((0x01 << (5)) - 1)) << (15))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (9)))) | (((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (5))) | ((unsigned int) (((unsigned int)((31)) & ((0x01 << (5)) - 1)) << (0))))) & ((0x01 << (24)) - 1)) << (0))), (unsigned int)((((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (28))) | ((unsigned int) (((unsigned int)((3)) & ((0x01 << (3)) - 1)) << (15))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((1)) & ((0x01 << (3)) - 1)) << (9)))) | (((unsigned int) (((unsigned int)((31)) & ((0x01 << (4)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (21))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (18))) | ((unsigned int) (((unsigned int)((3)) & ((0x01 << (3)) - 1)) << (6))) | ((unsigned int) (((unsigned int)((7)) & ((0x01 << (3)) - 1)) << (3))) | ((unsigned int) (((unsigned int)((1)) & ((0x01 << (3)) - 1)) << (0))))) }} ,
{{ ((unsigned int) (((unsigned int)(0xe2) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(32-(3)-(29)) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)((29)-1) & ((0x01 << (8)) - 1)) << (0))), (unsigned int)((0x40 | 0x200 | 0x4000 | 0 | (0) << 30 | (0) << 26 | (1) << 22 | (0) << 18) | (0x40 | 0x200 | 0x4000 | 0 | (0) << 28 | (0) << 24 | (1) << 20 | (0) << 16)) }} ,
{{ (((unsigned int) (((unsigned int)(0xd9) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(~(u32)(-1)) & ((0x01 << (24)) - 1)) << (0)))),(u32)((0x00000004 | 0x00200000)) }} ,
{{ ((unsigned int) (((unsigned int)(0xdf) & ((0x01 << (8)) - 1)) << (24))), 0 }} ,
};
static Vp viewport = {
1280, 960, 511, 0,
1280, 960, 511, 0
};
static Mtx projection = {
0x00000000, 0x00000000, 0x00000000, 0x00000000,
0x00000000, 0xFFFF0000, 0x00000000, 0xFFFF0001,
0x00CC0000, 0x00000000, 0x00000111, 0x00000000,
0x00000000, 0xFFFF0000, 0x00000000, 0x00000000
};
static Mtx lookat = {
0x10000, 0x00000, 0x00001, 0x00000,
0x00000, 0x10000, 0x00000, 0x00001,
0x00000, 0x00000, 0x00000, 0x00000,
0x00000, 0x00000, 0x00000, 0x00000
};
static Mtx default_model_scale = {
0x20000, 0x00000, 0x00002, 0x00000,
0x00000, 0x10000, 0x00000, 0x00001,
0x00000, 0x00000, 0x00000, 0x00000,
0x00000, 0x00000, 0x00000, 0x00000
};
static Mtx logo_projection = {
0x00000000, 0x00000000, 0x00000000, 0x00000000,
0x00000000, 0xFFFF0000, 0x00000000, 0x00000001,
0x00CC0000, 0x00000000, 0x000000F9, 0x00000000,
0x00000000, 0x00000000, 0x0000007C, 0x00000000
};
static Mtx logo_model_scale = {
0x10000, 0x00000, 0x00001, 0x00000,
0x00000, 0x10000, 0x00000, 0x00001,
0x00000, 0x00000, 0x00000, 0x00000,
0x00000, 0x00000, 0x00000, 0x00000
};
static Gfx initial_dl[] = {
{{ ((unsigned int) (((unsigned int)(0xed) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((int)((float)(0)*4.0F)) & ((0x01 << (12)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((int)((float)(0)*4.0F)) & ((0x01 << (12)) - 1)) << (0))), ((unsigned int) (((unsigned int)(0) & ((0x01 << (2)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((int)((float)(640)*4.0F)) & ((0x01 << (12)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((int)((float)(480)*4.0F)) & ((0x01 << (12)) - 1)) << (0))) }} ,
{{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x00000002) }}, {{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x0c)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x00000002) }}, {{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x14)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x0000fffe) }}, {{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x1c)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x0000fffe) }} ,
{{ (((unsigned int) (((unsigned int)((0xdc)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Vp))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)((8)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&viewport)) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x00 | 0x02 | 0x04)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&projection)) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x00 | 0x00 | 0x04)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&lookat)) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x00 | 0x02 | 0x00)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&default_model_scale)) }} ,
{{ ((unsigned int) (((unsigned int)(0xef) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)((3 << 4) | (3 << 6) | (0 << 8) | (6 << 9) | (2 << 12) | (0 << 14) | (0 << 16) | (0 << 17) | (1 << 19) | (0 << 20) | (0 << 23)) & ((0x01 << (24)) - 1)) << (0))), (unsigned int)((0 << 0) | (0 << 2) | (0) << 30 | (0) << 26 | (0) << 22 | (0) << 18 | (0) << 28 | (0) << 24 | (0) << 20 | (0) << 16) }} ,
{{ ((unsigned int) (((unsigned int)(0xdf) & ((0x01 << (8)) - 1)) << (24))), 0 }} ,
};
static Gfx logo_initial_dl[] = {
{{ ((unsigned int) (((unsigned int)(0xed) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((int)((float)(0)*4.0F)) & ((0x01 << (12)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((int)((float)(0)*4.0F)) & ((0x01 << (12)) - 1)) << (0))), ((unsigned int) (((unsigned int)(0) & ((0x01 << (2)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((int)((float)(640)*4.0F)) & ((0x01 << (12)) - 1)) << (12))) | ((unsigned int) (((unsigned int)((int)((float)(480)*4.0F)) & ((0x01 << (12)) - 1)) << (0))) }} ,
{{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x00000002) }}, {{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x0c)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x00000002) }}, {{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x14)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x0000fffe) }}, {{ (((unsigned int) (((unsigned int)((0xdb)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x04)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0x1c)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x0000fffe) }} ,
{{ (((unsigned int) (((unsigned int)((0xdc)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Vp))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)((8)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&viewport)) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x00 | 0x02 | 0x04)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&logo_projection)) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x00 | 0x00 | 0x04)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&lookat)) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x00 | 0x02 | 0x00)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&default_model_scale)) }} ,
{{ ((unsigned int) (((unsigned int)(0xef) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)((3 << 4) | (3 << 6) | (0 << 8) | (6 << 9) | (2 << 12) | (0 << 14) | (0 << 16) | (0 << 17) | (1 << 19) | (0 << 20) | (0 << 23)) & ((0x01 << (24)) - 1)) << (0))), (unsigned int)((0 << 0) | (0 << 2) | (0) << 30 | (0) << 26 | (0) << 22 | (0) << 18 | (0) << 28 | (0) << 24 | (0) << 20 | (0) << 16) }} ,
{{ ((unsigned int) (((unsigned int)(0xdf) & ((0x01 << (8)) - 1)) << (24))), 0 }} ,
};
static Gfx logo_draw_dl[] = {
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(logo_initial_dl) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win1_moji_setup) }} ,
{{ (((unsigned int) (((unsigned int)(0xfa) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))), (((unsigned int) (((unsigned int)(220) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x01 | 0x02 | 0x00)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&logo_model_scale)) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(logo_ninT_model) }} ,
{{ (((unsigned int) (((unsigned int)((0xd8)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((64)-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)((2)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((1)*64) }} ,
{{ ((unsigned int) (((unsigned int)(0xdf) & ((0x01 << (8)) - 1)) << (24))), 0 }} ,
};
static Gfx step1_draw_dl[] = {
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(initial_dl) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win1_moji_setup) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win1_winT_model) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win1_moji_model) }} ,
{{ (((unsigned int) (((unsigned int)(0xfa) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))), (((unsigned int) (((unsigned int)(90) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(90) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)(155) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x08000000) }} ,
{{ (((unsigned int) (((unsigned int)(0xfa) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))), (((unsigned int) (((unsigned int)(50) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(30) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)(150) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x09000000) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win1_cursor_setup) }} ,
{{ (((unsigned int) (((unsigned int)((0xda)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((sizeof(Mtx))-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)(((0x01 | 0x00 | 0x00)^0x01)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((&model_cursor)) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win1_cursor_model) }} ,
{{ (((unsigned int) (((unsigned int)((0xd8)) & ((0x01 << (8)) - 1)) << (24)))|((unsigned int) (((unsigned int)(((64)-1)/8) & ((0x01 << (5)) - 1)) << (19)))| ((unsigned int) (((unsigned int)((0)/8) & ((0x01 << (8)) - 1)) << (8)))|((unsigned int) (((unsigned int)((2)) & ((0x01 << (8)) - 1)) << (0)))), (unsigned int)((1)*64) }} ,
{{ ((unsigned int) (((unsigned int)(0xdf) & ((0x01 << (8)) - 1)) << (24))), 0 }} ,
};
static Gfx step2_draw_dl[] = {
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(initial_dl) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win1_moji_setup) }} ,
{{ (((unsigned int) (((unsigned int)(0xfa) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))), (((unsigned int) (((unsigned int)(225) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(gam_win2_winT_model) }} ,
{{ (((unsigned int) (((unsigned int)(0xfa) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(0) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))), (((unsigned int) (((unsigned int)(50) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)(50) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)(60) & ((0x01 << (8)) - 1)) << (8))) | ((unsigned int) (((unsigned int)(255) & ((0x01 << (8)) - 1)) << (0)))) }} ,
{{ (((unsigned int) (((unsigned int)((0xde)) & ((0x01 << (8)) - 1)) << (24))) | ((unsigned int) (((unsigned int)((0x00)) & ((0x01 << (8)) - 1)) << (16))) | ((unsigned int) (((unsigned int)((0)) & ((0x01 << (16)) - 1)) << (0)))), (unsigned int)(0x08000000) }} ,
{{ ((unsigned int) (((unsigned int)(0xdf) & ((0x01 << (8)) - 1)) << (24))), 0 }} ,
};
static int pad_good_frame_count = -1;
