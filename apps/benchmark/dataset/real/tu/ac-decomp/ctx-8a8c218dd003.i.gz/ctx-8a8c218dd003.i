
extern int signgam;
enum fdversion { fdlibm_ieee = -1, fdlibm_svid, fdlibm_xopen, fdlibm_posix };
extern enum fdversion _fdlib_version ;
struct exception {
int type;
char* name;
double arg1;
double arg2;
double retval;
};
extern double acos (double) ;
extern double asin (double) ;
extern double atan (double) ;
extern double atan2 (double, double) ;
extern double cos (double) ;
extern double sin (double) ;
extern double tan (double) ;
extern double cosh (double) ;
extern double sinh (double) ;
extern double tanh (double) ;
extern double exp (double) ;
extern double frexp (double, int*) ;
extern double ldexp (double, int) ;
extern double scalbn (double, int) ;
extern double log (double) ;
extern double log10 (double) ;
extern double modf (double, double*) ;
extern double pow (double, double) ;
extern double sqrt (double) ;
extern double ceil (double) ;
extern double fabs (double) ;
extern double fabs__Fd(double);
extern double floor (double) ;
extern double fmod (double, double) ;
extern double erf (double) ;
extern double erfc (double) ;
extern double gamma (double) ;
extern double hypot (double, double) ;
extern int isnan (double) ;
extern int finite (double) ;
extern double j0 (double) ;
extern double j1 (double) ;
extern double jn (int, double) ;
extern double lgamma (double) ;
extern double y0 (double) ;
extern double y1 (double) ;
extern double yn (int, double) ;
extern double acosh (double) ;
extern double asinh (double) ;
extern double atanh (double) ;
extern double cbrt (double) ;
extern double logb (double) ;
extern double nextafter (double, double) ;
extern double remainder (double, double) ;
extern double scalb (double, double) ;
extern int matherr (struct exception*) ;
extern double significand (double) ;
extern double copysign (double, double) ;
extern int ilogb (double) ;
extern double rint (double) ;
extern double scalbn (double, int) ;
extern double expm1 (double) ;
extern double log1p (double) ;
extern double __ieee754_sqrt (double) ;
extern double __ieee754_acos (double) ;
extern double __ieee754_acosh (double) ;
extern double __ieee754_log (double) ;
extern double __ieee754_atanh (double) ;
extern double __ieee754_asin (double) ;
extern double __ieee754_atan2 (double, double) ;
extern double __ieee754_exp (double) ;
extern double __ieee754_cosh (double) ;
extern double __ieee754_fmod (double, double) ;
extern double __ieee754_pow (double, double) ;
extern double __ieee754_lgamma_r (double, int*) ;
extern double __ieee754_gamma_r (double, int*) ;
extern double __ieee754_lgamma (double) ;
extern double __ieee754_gamma (double) ;
extern double __ieee754_log10 (double) ;
extern double __ieee754_sinh (double) ;
extern double __ieee754_hypot (double, double) ;
extern double __ieee754_j0 (double) ;
extern double __ieee754_j1 (double) ;
extern double __ieee754_y0 (double) ;
extern double __ieee754_y1 (double) ;
extern double __ieee754_jn (int, double) ;
extern double __ieee754_yn (int, double) ;
extern double __ieee754_remainder (double, double) ;
extern int __ieee754_rem_pio2 (double, double*) ;
extern double __ieee754_scalb (double, double) ;
extern double __kernel_standard (double, double, int) ;
extern double __kernel_sin (double, double, int) ;
extern double __kernel_cos (double, double) ;
extern double __kernel_tan (double, double, int) ;
extern int __kernel_rem_pio2 (double*, double*, int, int, int, const int*) ;
inline double fabs(double x);
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_max[];
extern unsigned long __float_epsilon[];
inline int __fpclassifyf(float __value);
inline int __fpclassifyd(double __value);
extern inline float sqrtf(float x);
inline float fabsf(float x);
extern inline double sqrt(double x);
typedef signed char s8;
typedef unsigned char u8;
typedef signed short int s16;
typedef unsigned short int u16;
typedef signed long s32;
typedef unsigned long u32;
typedef signed long long int s64;
typedef unsigned long long int u64;
typedef float f32;
typedef double f64;
typedef char *Ptr;
typedef unsigned int uintptr_t;
typedef int BOOL;
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, int type);
typedef unsigned long size_t;
typedef unsigned long __file_handle;
typedef unsigned long fpos_t;
typedef unsigned short wchar_t;
enum __file_kinds {
__closed_file,
__disk_file,
__console_file,
__string_file,
__unavailable_file = 3,
};
enum __file_orientation {
UNORIENTED,
CHAR_ORIENTED,
WIDE_ORIENTED,
};
typedef struct _file_modes {
unsigned int open_mode : 2;
unsigned int io_mode : 3;
unsigned int buffer_mode : 2;
unsigned int file_kind : 3;
unsigned int file_orientation : 2;
unsigned int binary_io : 1;
} file_modes;
enum __io_modes {
__read = 1,
__write = 2,
__read_write = 3,
__append = 4,
};
enum __io_states {
__neutral,
__writing,
__reading,
__rereading,
};
enum __io_results {
__no_io_error,
__io_error,
__io_EOF,
};
typedef struct _file_states {
unsigned int io_state : 3;
unsigned int free_buffer : 1;
unsigned char eof;
unsigned char error;
} file_states;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc idle_proc);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count, __idle_proc idle_proc);
typedef int (*__close_proc)(__file_handle file);
typedef struct _FILE {
__file_handle handle;
file_modes file_mode;
file_states file_state;
unsigned char char_buffer;
char char_buffer_overflow;
char ungetc_buffer[4];
wchar_t ungetc_wide_buffer[2];
unsigned long position;
unsigned char* buffer;
unsigned long buffer_size;
unsigned char* buffer_ptr;
unsigned long buffer_length;
unsigned long buffer_alignment;
unsigned long save_buffer_length;
unsigned long buffer_position;
__pos_proc position_fn;
__io_proc read_fn;
__io_proc write_fn;
__close_proc close_fn;
__idle_proc idle_fn;
void* next;
} FILE;
typedef struct _files {
FILE _stdin;
FILE _stdout;
FILE _stderr;
FILE _sentinel;
} files;
extern files __files;
int puts(const char *s);
int printf(const char *, ...);
int sprintf(char *s, const char *format, ...);
int vprintf(const char *format, va_list arg);
int vsprintf(char *s, const char *format, va_list arg);
size_t strlen(const char *s);
long strtol(const char *str, char **end, int base);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t num);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
char *strncat(char *dest, const char *src, size_t n);
char *strchr(const char *str, int c);
char* strrchr( char* str, int chr );
char* strstr(const char* str, const char* pat);
char* strcat(char* dst, const char* src);
int tolower(int c);
float powf(float x, float y);
float tanf(float);
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef unsigned int uint;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef void* unkptr;
typedef u32 unknown;
#pragma section RX "forcestrip"
typedef unsigned short wchar_t;
enum {
mMck_CASE_LOWER,
mMck_CASE_UPPER,
mMck_CASE_NUM
};
enum {
mMck_CHECK_KEY_TYPE_A,
mMck_CHECK_KEY_TYPE_B,
mMck_CHECK_KEY_TYPE_C,
mMck_CHECK_KEY_TYPE_D,
mMck_CHECK_KEY_TYPE_E,
mMck_CHECK_KEY_TYPE_F,
mMck_CHECK_KEY_TYPE_G,
mMck_CHECK_KEY_TYPE_NUM
};
extern int mMck_check_key_hit(int* len, u8* str);
extern int mMck_check_key_hit_nes(u8* str);
typedef struct land_info_s {
u8 name[8 ];
s8 exists;
u16 id;
} mLd_land_info_c;
typedef u16 mActor_name_t;
typedef struct actor_s ACTOR;
typedef struct actor_profile_s ACTOR_PROFILE;
typedef struct personal_id_s {
u8 player_name[8 ];
u8 land_name[8 ];
u16 player_id;
u16 land_id;
} PersonalID_c;
enum {
mNpc_LOOKS_GIRL,
mNpc_LOOKS_KO_GIRL,
mNpc_LOOKS_BOY,
mNpc_LOOKS_SPORT_MAN,
mNpc_LOOKS_GRIM_MAN,
mNpc_LOOKS_NANIWA_LADY,
mNpc_LOOKS_UNSET,
mNpc_LOOKS_NUM = mNpc_LOOKS_UNSET
};
typedef struct animal_personal_id_s {
mActor_name_t npc_id;
u16 land_id;
u8 land_name[8 ];
u8 name_id;
u8 looks;
} AnmPersonalID_c;
enum {
mMl_NAME_TYPE_PLAYER,
mMl_NAME_TYPE_NPC,
mMl_NAME_TYPE_MUSEUM,
mMl_NAME_TYPE_NUM,
mMl_NAME_TYPE_CLEAR = 0xFF
};
enum {
mMl_FONT_RECV,
mMl_FONT_SEND,
mMl_FONT_RECV_READ,
mMl_FONT_RECV_PLAYER_PRESENT,
mMl_FONT_RECV_PLAYER_PRESENT_READ,
mMl_FONT_NUM
};
enum {
mMl_DATA,
mMl_DATA2,
mMl_DATA_NUM
};
enum {
mMl_TYPE_MAIL,
mMl_TYPE_XMAS,
mMl_TYPE_SHOP_SALE_LEAFLET,
mMl_TYPE_BROKER_SALE_LEAFLET,
mMl_TYPE_MOTHER,
mMl_TYPE_OMIKUJI,
mMl_TYPE_HRA,
mMl_TYPE_SHOP,
mMl_TYPE_SNOWMAN,
mMl_TYPE_FISHING_CONTENST,
mMl_TYPE_POSTOFFICE,
mMl_TYPE_SPNPC_PASSWORD,
mMl_TYPE_NUM
};
typedef struct mail_nm_s {
PersonalID_c personalID;
u8 type;
} Mail_nm_c;
typedef struct mail_header_save_s {
s8 header_back_start;
u8 unknown;
u8 header[(32 - 8) ];
u8 footer[32 ];
} Mail_hs_c;
typedef struct mail_header_s {
Mail_nm_c recipient;
Mail_nm_c sender;
} Mail_hdr_c;
typedef struct mail_content_s {
u8 font;
u8 header_back_start;
u8 mail_type;
u8 paper_type;
u8 header[(32 - 8) ];
u8 body[192 ];
u8 footer[32 ];
} Mail_ct_c;
typedef struct mail_s {
Mail_hdr_c header;
mActor_name_t present;
Mail_ct_c content;
} Mail_c;
extern int mMl_strlen(u8* str, int size, u8 end_char);
extern int mMl_strlen2(int* found, u8* str, int size, u8 end_char);
extern void mMl_clear_mail_header(Mail_hdr_c* header);
extern void mMl_clear_mail(Mail_c* mail);
extern void mMl_clear_mail_box(Mail_c* mail, int num);
extern int mMl_check_not_used_mail(Mail_c* mail);
extern void mMl_copy_header_name(Mail_nm_c* dst, Mail_nm_c* src);
extern void mMl_set_to_plname(Mail_c* mail, PersonalID_c* pid);
extern void mMl_set_playername(Mail_c* mail, PersonalID_c* pid);
extern void mMl_init_mail(Mail_c* mail, PersonalID_c* pid);
extern int mMl_chk_mail_free_space(Mail_c* mail, int num);
extern int mMl_count_use_mail_space(Mail_c* mail, int num);
extern void mMl_copy_mail(Mail_c* dst, Mail_c* src);
extern void mMl_clear_mail_header_common(Mail_hs_c* header);
extern void mMl_set_mail_name_npcinfo(Mail_nm_c* name, AnmPersonalID_c* anm_pid);
extern int mMl_get_npcinfo_from_mail_name(AnmPersonalID_c* anm_pid, Mail_nm_c* name);
extern int mMl_hunt_for_send_address(Mail_c* mail);
extern int mMl_check_send_mail(Mail_c* mail);
extern int mMl_check_set_present_myself(Mail_c* mail);
extern int mMl_send_mail_box(PersonalID_c* recipient_pid, int player_no, Mail_c* mail, mActor_name_t present,
mActor_name_t paper, int mail_no, u8* sender_name, u32 proc_type);
extern int mMl_send_mail_postoffice(PersonalID_c* recipient_pid, int player_no, mActor_name_t present,
mActor_name_t paper, int mail_no, u8* sender_name, u32 proc_type, u8 mail_type);
extern int mMl_send_mail(PersonalID_c* recipient_pid, int player_no, mActor_name_t present, mActor_name_t paper,
int mail_no, u8* sender_name, u32 proc_type);
extern void mMl_start_send_mail();
typedef struct game_play_s GAME_PLAY;
extern double sin(double deg);
extern double cos(double deg);
extern double tan(double deg);
float sinf(float);
float cosf(float);
inline float sinf(float x);
inline float cosf(float x);
extern double ceil(double);
u32 qrand(void);
void sqrand(u32);
f32 fqrand(void);
f32 fqrand2(void);
extern u16 U_GetAtanTable(f32 y, f32 x);
extern s16 atans_table(f32 x, f32 y);
extern f32 atanf_table(f32 x, f32 y);
extern void init_rnd();
extern f32 sinf_table(f32 x);
extern f32 cosf_table(f32 x);
typedef struct xy_s {
f32 x, y;
} xy_t;
typedef struct xz_s {
f32 x, z;
} xz_t;
typedef struct xyz_s {
f32 x, y, z;
} xyz_t;
typedef struct s_xyz_s {
s16 x, y, z;
} s_xyz;
typedef struct s_xz_s {
s16 x, z;
} s_xz;
typedef struct {
u32 r:8;
u32 g:8;
u32 b:8;
u32 a:8;
} rgba8888_t;
typedef union {
u32 rgba8888;
rgba8888_t c;
} rgba8888;
typedef union {
struct {
u8 r, g, b, a;
};
u32 rgba;
} Color_RGBA8_u32;
typedef struct game_s GAME;
typedef struct {
size_t size;
char *buf_p;
char *head_p;
char *tail_p;
} TwoHeadArena_t;
typedef TwoHeadArena_t TwoHeadArena;
typedef TwoHeadArena_t THA;
extern void THA_ct(TwoHeadArena* tha, char* p, size_t n);
extern void THA_dt(TwoHeadArena* tha);
extern void* THA_getHeadPtr(TwoHeadArena* tha);
extern void THA_setHeadPtr(TwoHeadArena* tha, void* p);
extern void* THA_getTailPtr(TwoHeadArena* tha);
extern void* THA_nextPtrN(TwoHeadArena* tha, size_t n);
extern void* THA_nextPtr1(TwoHeadArena* tha);
extern void* THA_alloc(TwoHeadArena* tha, size_t siz);
extern void* THA_alloc16(TwoHeadArena* tha, size_t siz);
extern void* THA_allocAlign(TwoHeadArena* tha, size_t siz, int mask);
extern int THA_isCrash(TwoHeadArena* tha);
extern void THA_init(TwoHeadArena* tha);
extern int THA_getFreeBytes16(TwoHeadArena* tha);
extern int THA_getFreeBytes(TwoHeadArena* tha);
extern int THA_getFreeBytesAlign(TwoHeadArena* tha, int mask);
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef volatile unsigned char vu8;
typedef volatile unsigned short vu16;
typedef volatile unsigned long vu32;
typedef volatile unsigned long long vu64;
typedef volatile signed char vs8;
typedef volatile short vs16;
typedef volatile long vs32;
typedef volatile long long vs64;
typedef float f32;
typedef double f64;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
unsigned char cn[4];
} Vtx_t;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
signed char n[3];
unsigned char a;
} Vtx_tn;
typedef union {
Vtx_t v;
Vtx_tn n;
long long int force_structure_alignment;
} Vtx;
typedef struct {
void *SourceImagePointer;
void *TlutPointer;
short Stride;
short SubImageWidth;
short SubImageHeight;
char SourceImageType;
char SourceImageBitSize;
short SourceImageOffsetS;
short SourceImageOffsetT;
char dummy[4];
} uSprite_t;
typedef union {
uSprite_t s;
long long int force_structure_allignment[3];
} uSprite;
typedef struct {
unsigned char flag;
unsigned char v[3];
} Tri;
typedef long Mtx_t[4][4];
typedef union {
Mtx_t m;
long long int force_structure_alignment;
} Mtx;
typedef struct {
short vscale[4];
short vtrans[4];
} Vp_t;
typedef union {
Vp_t vp;
long long int force_structure_alignment;
} Vp;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
signed char dir[3];
char pad3;
} Light_t;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
} Ambient_t;
typedef struct {
int x1,y1,x2,y2;
} Hilite_t;
typedef union {
Light_t l;
long long int force_structure_alignment[2];
} Light;
typedef union {
Ambient_t l;
long long int force_structure_alignment[1];
} Ambient;
typedef struct {
Ambient a;
Light l[7];
} Lightsn;
typedef struct {
Ambient a;
Light l[1];
} Lights0;
typedef struct {
Ambient a;
Light l[1];
} Lights1;
typedef struct {
Ambient a;
Light l[2];
} Lights2;
typedef struct {
Ambient a;
Light l[3];
} Lights3;
typedef struct {
Ambient a;
Light l[4];
} Lights4;
typedef struct {
Ambient a;
Light l[5];
} Lights5;
typedef struct {
Ambient a;
Light l[6];
} Lights6;
typedef struct {
Ambient a;
Light l[7];
} Lights7;
typedef struct {
Light l[2];
} LookAt;
typedef union {
Hilite_t h;
long int force_structure_alignment[4];
} Hilite;
typedef struct {
int cmd:8;
unsigned int par:8;
unsigned int len:16;
unsigned int addr;
} Gdma;
typedef struct {
int cmd:8;
int pad:24;
Tri tri;
} Gtri;
typedef struct {
int cmd:8;
int pad1:24;
int pad2:24;
unsigned int param:8;
} Gpopmtx;
typedef struct {
int cmd:8;
int pad0:8;
int mw_index:8;
int number:8;
int pad1:8;
int base:24;
} Gsegment;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeL;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeH;
typedef struct {
unsigned char cmd;
unsigned char lodscale;
unsigned char tile;
unsigned char on;
unsigned short s;
unsigned short t;
} Gtexture;
typedef struct {
int cmd:8;
int pad:24;
Tri line;
} Gline3D;
typedef struct {
int cmd:8;
int pad1:24;
short int pad2;
short int scale;
} Gperspnorm;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad:7;
unsigned int wd:12;
unsigned int dram;
} Gsetimg;
typedef struct {
int cmd:8;
unsigned int muxs0:24;
unsigned int muxs1:32;
} Gsetcombine;
typedef struct {
int cmd:8;
unsigned char pad;
unsigned char prim_min_level;
unsigned char prim_level;
unsigned long color;
} Gsetcolor;
typedef struct {
int cmd:8;
int x0:10;
int x0frac:2;
int y0:10;
int y0frac:2;
unsigned int pad:8;
int x1:10;
int x1frac:2;
int y1:10;
int y1frac:2;
} Gfillrect;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad0:1;
unsigned int line:9;
unsigned int tmem:9;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int palette:4;
unsigned int ct:1;
unsigned int mt:1;
unsigned int maskt:4;
unsigned int shiftt:4;
unsigned int cs:1;
unsigned int ms:1;
unsigned int masks:4;
unsigned int shifts:4;
} Gsettile;
typedef struct {
int cmd:8;
unsigned int sl:12;
unsigned int tl:12;
int pad:5;
unsigned int tile:3;
unsigned int sh:12;
unsigned int th:12;
} Gloadtile;
typedef Gloadtile Gloadblock;
typedef Gloadtile Gsettilesize;
typedef Gloadtile Gloadtlut;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int s:16;
unsigned int t:16;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect;
typedef struct {
unsigned long w0;
unsigned long w1;
unsigned long w2;
unsigned long w3;
} TexRect;
typedef struct {
unsigned int w0;
unsigned int w1;
} Gwords;
typedef union {
Gwords words;
Gdma dma;
Gtri tri;
Gline3D line;
Gpopmtx popmtx;
Gsegment segment;
GsetothermodeH setothermodeH;
GsetothermodeL setothermodeL;
Gtexture texture;
Gperspnorm perspnorm;
Gsetimg setimg;
Gsetcombine setcombine;
Gsetcolor setcolor;
Gfillrect fillrect;
Gsettile settile;
Gloadtile loadtile;
Gsettilesize settilesize;
Gloadtlut loadtlut;
long long int force_structure_alignment;
} Gfx;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Aadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Apolef;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvelope;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmem:16;
unsigned int pad2:16;
unsigned int count:16;
} Aclearbuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int inL:16;
unsigned int inR:16;
} Ainterleave;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Aloadbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvmixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int dmemi:16;
unsigned int dmemo:16;
} Amixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmem2:16;
unsigned int addr;
} Apan;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pitch:16;
unsigned int addr;
} Aresample;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Areverb;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Asavebuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int pad2:2;
unsigned int number:4;
unsigned int base:24;
} Asegment;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Asetbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int vol:16;
unsigned int voltgt:16;
unsigned int volrate:16;
} Asetvol;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Admemmove;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int count:16;
unsigned int addr;
} Aloadadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int addr;
} Asetloop;
typedef struct {
unsigned int w0;
unsigned int w1;
} Awords;
typedef union {
Awords words;
Aadpcm adpcm;
Apolef polef;
Aclearbuff clearbuff;
Aenvelope envelope;
Ainterleave interleave;
Aloadbuff loadbuff;
Aenvmixer envmixer;
Aresample resample;
Areverb reverb;
Asavebuff savebuff;
Asegment segment;
Asetbuff setbuff;
Asetvol setvol;
Admemmove dmemmove;
Aloadadpcm loadadpcm;
Amixer mixer;
Asetloop setloop;
long long int force_union_align;
} Acmd;
typedef short ADPCM_STATE[16 ];
typedef short POLEF_STATE[4];
typedef short RESAMPLE_STATE[16];
typedef short ENVMIX_STATE[40];
typedef struct {
size_t size;
Gfx* buf_p;
Gfx* head_p;
Gfx* tail_p;
} TwoHeadArenaGfx_t;
typedef TwoHeadArenaGfx_t TwoHeadArenaGfx;
typedef union {
TwoHeadArena tha;
TwoHeadArenaGfx thaGfx;
} THA_GA_t;
typedef THA_GA_t THA_GA;
extern void THA_GA_ct(THA_GA* tha_ga, Gfx* p, size_t n);
extern void THA_GA_dt(THA_GA* tha_ga);
extern int THA_GA_isCrash(THA_GA* tha_ga);
extern void THA_GA_init(THA_GA* tha_ga);
extern int THA_GA_getFreeBytes(THA_GA* tha_ga);
extern void* THA_GA_getTailPtr(THA_GA* tha_ga);
extern void* THA_GA_nextPtrN(THA_GA* tha_ga, size_t n);
extern void* THA_GA_nextPtr1(THA_GA* tha_ga);
extern Gfx* THA_GA_NEXT_DISP(THA_GA* tha_ga);
extern void* THA_GA_getHeadPtr(THA_GA* tha_ga);
extern void THA_GA_setHeadPtr(THA_GA* tha_ga, void *p);
extern Mtx* THA_GA_alloc(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtxN(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtx1(THA_GA* tha_ga);
extern Vtx* THA_GA_allocVtxN(THA_GA* tha_ga, size_t n);
extern Vtx* THA_GA_allocVtx1(THA_GA* tha_ga);
typedef struct OSContext
{
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
u32 fpscr_pad;
u32 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
u32 OSGetStackPointer(void);
void OSDumpContext(OSContext *context);
void OSLoadContext(OSContext *context);
u32 OSSaveContext(OSContext *context);
void OSClearContext(OSContext *context);
OSContext *OSGetCurrentContext(void);
void OSSetCurrentContext(OSContext *context);
void OSLoadFPUContext(OSContext *fpuContext);
void OSSaveFPUContext(OSContext *fpuContext);
u32 OSSwitchStack(u32 newsp);
int OSSwitchFiber(u32 pc, u32 newsp);
void OSInitContext(OSContext *context, u32 pc, u32 newsp);
void OSFillFPUContext(OSContext *context);
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef s32 OSPriority;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef struct OSCond OSCond;
typedef void (*OSIdleFunction)(void *param);
struct OSThreadQueue
{
OSThread *head;
OSThread *tail;
};
struct OSThreadLink
{
OSThread *next;
OSThread *prev;
};
struct OSMutexQueue
{
OSMutex *head;
OSMutex *tail;
};
struct OSMutexLink
{
OSMutex *next;
OSMutex *prev;
};
struct OSThread
{
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void *val;
OSThreadQueue *queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex *mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8 *stackBase;
u32 *stackEnd;
};
enum OS_THREAD_STATE
{
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8
};
void OSInitThreadQueue(OSThreadQueue *queue);
OSThread *OSGetCurrentThread(void);
BOOL OSIsThreadSuspended(OSThread *thread);
BOOL OSIsThreadTerminated(OSThread *thread);
s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);
void OSYieldThread(void);
BOOL OSCreateThread(OSThread *thread,
void *(*func)(void *),
void *param,
void *stack,
u32 stackSize,
OSPriority priority,
u16 attr);
void OSExitThread(void *val);
void OSCancelThread(OSThread *thread);
BOOL OSJoinThread(OSThread *thread, void **val);
void OSDetachThread(OSThread *thread);
s32 OSResumeThread(OSThread *thread);
s32 OSSuspendThread(OSThread *thread);
BOOL OSSetThreadPriority(OSThread *thread, OSPriority priority);
OSPriority OSGetThreadPriority(OSThread *thread);
void OSSleepThread(OSThreadQueue *queue);
void OSWakeupThread(OSThreadQueue *queue);
OSThread *OSSetIdleFunction(OSIdleFunction idleFunction,
void *param,
void *stack,
u32 stackSize);
OSThread *OSGetIdleFunction(void);
long OSCheckActiveThreads(void);
typedef struct OSMessageQueue OSMessageQueue;
typedef void* OSMessage;
struct OSMessageQueue {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
int msgCount;
int firstIndex;
int usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, int msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, int flags);
typedef struct OSModuleHeader OSModuleHeader;
typedef u32 OSModuleID;
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
OSModuleQueue __OSModuleList : (0x800030C8) ;
void* __OSStringTable : (0x800030D0) ;
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u8 bssSection;
u32 prolog;
u32 epilog;
u32 unresolved;
u32 align;
u32 bssAlign;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSLinkFixed(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* module);
void OSSetStringTable(const void* string_table);
void __OSModuleInit(void);
typedef s64 OSTime;
typedef u32 OSTick;
OSTime OSGetTime(void);
OSTime __OSGetSystemTime(void);
OSTick OSGetTick(void);
typedef struct OSCalendarTime_s {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* td);
typedef struct boot_tbl_s {
const char* msg;
u16 param_upper;
u16 param_lower;
} boot_tbl_t;
extern u32 convert_partial_address(u32 partial_addr);
extern void HotResetIplMenu();
extern void* boot_copyDate;
extern void* HotStartEntry;
extern OSTime InitialStartTime;
extern u8 boot_sound_initializing;
typedef void(*HotStartProc)();
OSModuleHeader* BaseModule : (0x800030C8) ;
typedef enum {
GRAPH_DOING_ZERO = 0,
GRAPH_DOING_CT,
GRAPH_DOING_GAME_CT,
GRAPH_DOING_GAME_CT_FINISHED,
GRAPH_DOING_GAME_MAIN,
GRAPH_DOING_GAME_TIME,
GRAPH_DOING_GAME_TIME_FINISHED,
GRAPH_DOING_GAME_EXEC,
GRAPH_DOING_GAME_EXEC_FINISHED,
GRAPH_DOING_GAME_BGM,
GRAPH_DOING_GAME_BGM_FINISHED,
GRAPH_DOING_GAME_MAIN_FINISHED,
GRAPH_DOING_TASK_SET,
GRAPH_DOING_WAIT_TASK,
GRAPH_DOING_WAIT_TASK_FINISHED,
GRAPH_DOING_TASK_SET_FINISHED,
GRAPH_DOING_AUDIO,
GRAPH_DOING_AUDIO_FINISHED,
GRAPH_DOING_GAME_18,
GRAPH_DOING_GAME_DT,
GRAPH_DOING_GAME_DT_FINISHED,
GRAPH_DOING_DT,
GRAPH_DOING_END
} GRAPH_DOING_POINT;
typedef struct graph_s {
Gfx* Gfx_list00;
Gfx* Gfx_list01;
void* DepthBuffer;
Gfx* Gfx_list03;
Gfx* Gfx_list04;
Gfx* Gfx_list07;
Gfx* Gfx_list08;
Gfx* Gfx_list09;
Gfx* gfxsave;
u8 _unk24[32];
OSMessage graphReplyMesgBuf[8 ];
OSMessageQueue* schedMesgQueue;
OSMessageQueue graphReplyMesgQueue;
u8 _unused_ossctask00p[0x68];
u8 _unused_ossctask01p[0x68];
u8 _unused_ossctask02p[0x68];
Gfx* Gfx_list05;
THA_GA work_thaga;
u8 _unk1D4[0xBC];
void* scheduler;
void* vimode;
THA_GA line_opaque_thaga;
THA_GA line_translucent_thaga;
THA_GA overlay_thaga;
THA_GA polygon_opaque_thaga;
THA_GA polygon_translucent_thaga;
THA_GA font_thaga;
THA_GA shadow_thaga;
THA_GA light_thaga;
THA_GA bg_opaque_thaga;
THA_GA bg_translucent_thaga;
int frame_counter;
u16* frameBuffer;
u16* renderBuffer;
u32 vispecial;
u8 doing_point;
u8 _unk349;
u8 need_viupdate;
u8 cfb_bank;
void (*taskEndCallback)(struct graph_s*, void*);
void* taskEndData;
f32 vixscale;
f32 viyscale;
Gfx* last_dl;
Gfx* Gfx_list10;
Gfx* Gfx_list11;
} GRAPH __attribute__((aligned(8))) ;
extern void graph_proc(void* arg);
extern void graph_ct(GRAPH* graph);
extern void graph_dt(GRAPH* graph);
extern u8 SoftResetEnable;
extern GRAPH graph_class;
typedef struct gameAllocList_s {
struct gameAllocList_s* next;
struct gameAllocList_s* prev;
size_t alloc_size;
u32 pad;
} GameAllocList;
typedef struct gameAlloc_s {
GameAllocList head;
GameAllocList* tail;
} GameAlloc;
extern void* gamealloc_malloc(GameAlloc* gamealloc, size_t size);
extern void gamealloc_free(GameAlloc* gamealloc, void* ptr);
extern void gamealloc_cleanup(GameAlloc* gamealloc);
extern void gamealloc_init(GameAlloc* gamealloc);
typedef struct {
u16 type;
u8 status;
u8 errno;
} OSContStatus;
typedef struct {
u16 button;
s8 stick_x;
s8 stick_y;
u8 errno;
} OSContPad;
typedef struct {
OSContPad pad;
s8 substickX;
s8 substickY;
u8 triggerR;
u8 triggerL;
} OSContPadEx;
extern s32 osContInit(OSMessageQueue* mq, u8* pattern_p, OSContStatus* status);
extern s32 osContStartQuery(OSMessageQueue* mq);
extern s32 osContStartReadData(OSMessageQueue* mq);
extern void osContGetQuery(OSContStatus* status);
extern s32 osContSetCh(u8 num_controllers);
extern void osContGetReadData(OSContPad* pad);
extern void osContGetReadDataEx(OSContPadEx* pad);
typedef struct {
OSContPad now;
OSContPad last;
OSContPad on;
OSContPad off;
} pad_t;
int pad_physical_stick_x(pad_t*);
int pad_physical_stick_y(pad_t*);
void pad_set_logical_stick(pad_t*, int, int);
void pad_correct_stick(pad_t*);
typedef struct controller_s {
f32 move_pX;
f32 move_pY;
f32 move_pR;
s16 move_angle;
f32 last_move_pX;
f32 last_move_pY;
f32 last_move_pR;
s16 last_move_angle;
f32 adjusted_pX;
f32 adjusted_pY;
f32 adjusted_pR;
f32 last_adjusted_pX;
f32 last_adjusted_pY;
f32 last_adjusted_pR;
} MCON;
extern void mCon_ct();
extern void mCon_dt();
extern void mCon_calc(MCON* mcon, f32 stick_x, f32 stick_y);
extern void mCon_main(GAME* game);
extern int chkButton(u16 button);
extern u16 getButton();
extern int chkTrigger(u16 button);
extern u16 getTrigger();
extern int getJoystick_X();
extern int getJoystick_Y();
struct game_s {
GRAPH* graph;
void (*exec)(struct game_s* );
void (*cleanup)(struct game_s*);
void (*next_game_init)(struct game_s*);
size_t next_game_class_size;
pad_t pads[4 ];
int pad_initialized;
THA tha;
GameAlloc gamealloc;
u8 doing_point;
u8 doing_point_specific;
u8 disable_display;
u8 doing;
u32 frame_counter;
int disable_prenmi;
MCON mcon;
};
extern void game_debug_draw_last(GAME* game, GRAPH* graph);
extern void game_draw_last(GRAPH* graph);
extern void game_get_controller(GAME* game);
extern void SetGameFrame(int frame);
extern void game_main(GAME* game);
extern void game_resize_hyral(GAME* game, int size);
extern void game_ct(GAME* game, void (*init)(GAME*), GRAPH* graph);
extern void game_dt(GAME* game);
extern void (*game_get_next_game_init(GAME* game))(GAME*);
extern int game_is_doing(GAME* game);
extern int game_getFreeBytes(GAME* game);
extern void game_goto_next_game_play(GAME* game);
extern GAME* gamePT;
extern GAME* game_class_p;
extern u8 game_GameFrame;
extern float game_GameFrameF;
extern float game_GameFrame_2F;
extern float game_GameFrame__1F;
typedef struct rgba_t {
u8 r, g, b, a;
} rgba_t;
typedef struct rgb_t {
uint r, g, b;
} rgb_t;
typedef struct rgb8_t {
u8 r, g, b;
} rgb8_t;
typedef struct {
xyz_t position;
s_xyz angle;
} PositionAngle;
extern void mem_copy(u8* dst, u8* src, size_t size);
extern void mem_clear(u8* dst, size_t size, u8 val);
extern int mem_cmp(u8* p1, u8* p2, size_t size);
extern f32 cos_s(s16 angle);
extern f32 sin_s(s16 angle);
extern int chase_angle(s16* const pValue, const s16 target, s16 step);
extern int chase_s(s16* const pValue, const s16 target, s16 step);
extern int chase_f(f32* const pValue, const f32 target, f32 step);
extern f32 chase_xyz_t(xyz_t* const pValue, const xyz_t* const target, const f32 fraction);
extern int chase_angle2(s16* const pValue, const s16 limit, const s16 step);
extern void inter_float(f32* const pValue, const f32 arg1, const int step);
extern s16 get_random_timer(const s16 base, const s16 range);
extern void xyz_t_move(xyz_t* const dest, const xyz_t* const src);
extern void xyz_t_move_s_xyz(xyz_t* const dest, const s_xyz* const src);
extern void xyz_t_add(const xyz_t* const augend, const xyz_t* const addend, xyz_t* const total);
extern void xyz_t_sub(const xyz_t* const minuend, const xyz_t* const subtrahend, xyz_t* const diff);
extern void xyz_t_mult_v(xyz_t* const multiplicand, const f32 multiplier);
extern f32 search_position_distance(const xyz_t* const pos, const xyz_t* const target);
extern f32 search_position_distanceXZ(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleY(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleX(const xyz_t* const pos, const xyz_t* const target);
extern f32 add_calc(f32* pValue, f32 target, f32 fraction, f32 maxStep, f32 minStep);
extern void add_calc2(f32* pValue, f32 target, f32 fraction, f32 maxStep);
extern void add_calc0(f32* pValue, f32 fraction, f32 maxStep);
extern s16 add_calc_short_angle2(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern s16 add_calc_short_angle3(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern void rgba_t_move(rgba_t* dest, const rgba_t* const src);
extern int none_proc1();
extern void none_proc2(ACTOR* actor, GAME* game);
extern int _Game_play_isPause(GAME_PLAY* play);
extern f32 check_percent_abs(f32 x, f32 min, f32 max, f32 scale, int shift_by_min);
extern f32 get_percent_forAccelBrake(f32 now, f32 start, f32 end, f32 accelerateDist, f32 brakeDist);
extern void Game_play_Projection_Trans(GAME_PLAY* const play, xyz_t* world_pos, xyz_t* screen_pos);
extern f32 get_percent(const int max, const int min, const int x);
typedef u8 GXBool;
typedef enum _GXProjectionType {
GX_PERSPECTIVE,
GX_ORTHOGRAPHIC,
} GXProjectionType;
typedef enum _GXCompare {
GX_NEVER,
GX_LESS,
GX_EQUAL,
GX_LEQUAL,
GX_GREATER,
GX_NEQUAL,
GX_GEQUAL,
GX_ALWAYS,
} GXCompare;
typedef enum _GXAlphaOp {
GX_AOP_AND,
GX_AOP_OR,
GX_AOP_XOR,
GX_AOP_XNOR,
GX_MAX_ALPHAOP,
} GXAlphaOp;
typedef enum _GXFBClamp {
GX_CLAMP_NONE,
GX_CLAMP_TOP,
GX_CLAMP_BOTTOM,
} GXFBClamp;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR,
GX_ZC_NEAR,
GX_ZC_MID,
GX_ZC_FAR,
} GXZFmt16;
typedef enum _GXGamma {
GX_GM_1_0,
GX_GM_1_7,
GX_GM_2_2,
} GXGamma;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24,
GX_PF_RGBA6_Z24,
GX_PF_RGB565_Z16,
GX_PF_Z24,
GX_PF_Y8,
GX_PF_U8,
GX_PF_V8,
GX_PF_YUV420,
} GXPixelFmt;
typedef enum _GXPrimitive {
GX_QUADS = 0x80,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xA0,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_POINTS = 0xB8,
} GXPrimitive;
typedef enum _GXVtxFmt {
GX_VTXFMT0,
GX_VTXFMT1,
GX_VTXFMT2,
GX_VTXFMT3,
GX_VTXFMT4,
GX_VTXFMT5,
GX_VTXFMT6,
GX_VTXFMT7,
GX_MAX_VTXFMT,
} GXVtxFmt;
typedef enum _GXAttr {
GX_VA_PNMTXIDX,
GX_VA_TEX0MTXIDX,
GX_VA_TEX1MTXIDX,
GX_VA_TEX2MTXIDX,
GX_VA_TEX3MTXIDX,
GX_VA_TEX4MTXIDX,
GX_VA_TEX5MTXIDX,
GX_VA_TEX6MTXIDX,
GX_VA_TEX7MTXIDX,
GX_VA_POS,
GX_VA_NRM,
GX_VA_CLR0,
GX_VA_CLR1,
GX_VA_TEX0,
GX_VA_TEX1,
GX_VA_TEX2,
GX_VA_TEX3,
GX_VA_TEX4,
GX_VA_TEX5,
GX_VA_TEX6,
GX_VA_TEX7,
GX_POS_MTX_ARRAY,
GX_NRM_MTX_ARRAY,
GX_TEX_MTX_ARRAY,
GX_LIGHT_ARRAY,
GX_VA_NBT,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF,
} GXAttr;
typedef enum _GXAttrType {
GX_NONE,
GX_DIRECT,
GX_INDEX8,
GX_INDEX16,
} GXAttrType;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_CTF_R4 = 0x0 | 0x20 ,
GX_CTF_RA4 = 0x2 | 0x20 ,
GX_CTF_RA8 = 0x3 | 0x20 ,
GX_CTF_YUVA8 = 0x6 | 0x20 ,
GX_CTF_A8 = 0x7 | 0x20 ,
GX_CTF_R8 = 0x8 | 0x20 ,
GX_CTF_G8 = 0x9 | 0x20 ,
GX_CTF_B8 = 0xA | 0x20 ,
GX_CTF_RG8 = 0xB | 0x20 ,
GX_CTF_GB8 = 0xC | 0x20 ,
GX_TF_Z8 = 0x1 | 0x10 ,
GX_TF_Z16 = 0x3 | 0x10 ,
GX_TF_Z24X8 = 0x6 | 0x10 ,
GX_CTF_Z4 = 0x0 | 0x10 | 0x20 ,
GX_CTF_Z8M = 0x9 | 0x10 | 0x20 ,
GX_CTF_Z8L = 0xA | 0x10 | 0x20 ,
GX_CTF_Z16L = 0xC | 0x10 | 0x20 ,
GX_TF_A8 = GX_CTF_A8,
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xa,
} GXCITexFmt;
typedef enum _GXTexWrapMode {
GX_CLAMP,
GX_REPEAT,
GX_MIRROR,
GX_MAX_TEXWRAPMODE,
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR,
GX_LINEAR,
GX_NEAR_MIP_NEAR,
GX_LIN_MIP_NEAR,
GX_NEAR_MIP_LIN,
GX_LIN_MIP_LIN,
} GXTexFilter;
typedef enum _GXAnisotropy {
GX_ANISO_1,
GX_ANISO_2,
GX_ANISO_4,
GX_MAX_ANISOTROPY,
} GXAnisotropy;
typedef enum _GXTexMapID {
GX_TEXMAP0,
GX_TEXMAP1,
GX_TEXMAP2,
GX_TEXMAP3,
GX_TEXMAP4,
GX_TEXMAP5,
GX_TEXMAP6,
GX_TEXMAP7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100,
} GXTexMapID;
typedef enum _GXTexCoordID {
GX_TEXCOORD0,
GX_TEXCOORD1,
GX_TEXCOORD2,
GX_TEXCOORD3,
GX_TEXCOORD4,
GX_TEXCOORD5,
GX_TEXCOORD6,
GX_TEXCOORD7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF,
} GXTexCoordID;
typedef enum _GXTevStageID {
GX_TEVSTAGE0,
GX_TEVSTAGE1,
GX_TEVSTAGE2,
GX_TEVSTAGE3,
GX_TEVSTAGE4,
GX_TEVSTAGE5,
GX_TEVSTAGE6,
GX_TEVSTAGE7,
GX_TEVSTAGE8,
GX_TEVSTAGE9,
GX_TEVSTAGE10,
GX_TEVSTAGE11,
GX_TEVSTAGE12,
GX_TEVSTAGE13,
GX_TEVSTAGE14,
GX_TEVSTAGE15,
GX_MAX_TEVSTAGE,
} GXTevStageID;
typedef enum _GXTevMode {
GX_MODULATE,
GX_DECAL,
GX_BLEND,
GX_REPLACE,
GX_PASSCLR,
} GXTevMode;
typedef enum _GXTexMtxType {
GX_MTX3x4,
GX_MTX2x4,
} GXTexMtxType;
typedef enum _GXTexGenType {
GX_TG_MTX3x4,
GX_TG_MTX2x4,
GX_TG_BUMP0,
GX_TG_BUMP1,
GX_TG_BUMP2,
GX_TG_BUMP3,
GX_TG_BUMP4,
GX_TG_BUMP5,
GX_TG_BUMP6,
GX_TG_BUMP7,
GX_TG_SRTG,
} GXTexGenType;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 0,
GX_PNMTX1 = 3,
GX_PNMTX2 = 6,
GX_PNMTX3 = 9,
GX_PNMTX4 = 12,
GX_PNMTX5 = 15,
GX_PNMTX6 = 18,
GX_PNMTX7 = 21,
GX_PNMTX8 = 24,
GX_PNMTX9 = 27,
} GXPosNrmMtx;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30,
GX_TEXMTX1 = 33,
GX_TEXMTX2 = 36,
GX_TEXMTX3 = 39,
GX_TEXMTX4 = 42,
GX_TEXMTX5 = 45,
GX_TEXMTX6 = 48,
GX_TEXMTX7 = 51,
GX_TEXMTX8 = 54,
GX_TEXMTX9 = 57,
GX_IDENTITY = 60,
} GXTexMtx;
typedef enum _GXChannelID {
GX_COLOR0,
GX_COLOR1,
GX_ALPHA0,
GX_ALPHA1,
GX_COLOR0A0,
GX_COLOR1A1,
GX_COLOR_ZERO,
GX_ALPHA_BUMP,
GX_ALPHA_BUMPN,
GX_COLOR_NULL = 0xFF,
} GXChannelID;
typedef enum _GXTexGenSrc {
GX_TG_POS,
GX_TG_NRM,
GX_TG_BINRM,
GX_TG_TANGENT,
GX_TG_TEX0,
GX_TG_TEX1,
GX_TG_TEX2,
GX_TG_TEX3,
GX_TG_TEX4,
GX_TG_TEX5,
GX_TG_TEX6,
GX_TG_TEX7,
GX_TG_TEXCOORD0,
GX_TG_TEXCOORD1,
GX_TG_TEXCOORD2,
GX_TG_TEXCOORD3,
GX_TG_TEXCOORD4,
GX_TG_TEXCOORD5,
GX_TG_TEXCOORD6,
GX_TG_COLOR0,
GX_TG_COLOR1,
GX_MAX_TEXGENSRC,
} GXTexGenSrc;
typedef enum _GXBlendMode {
GX_BM_NONE,
GX_BM_BLEND,
GX_BM_LOGIC,
GX_BM_SUBTRACT,
GX_MAX_BLENDMODE,
} GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO,
GX_BL_ONE,
GX_BL_SRCCLR,
GX_BL_INVSRCCLR,
GX_BL_SRCALPHA,
GX_BL_INVSRCALPHA,
GX_BL_DSTALPHA,
GX_BL_INVDSTALPHA,
GX_BL_DSTCLR = GX_BL_SRCCLR,
GX_BL_INVDSTCLR = GX_BL_INVSRCCLR,
} GXBlendFactor;
typedef enum _GXLogicOp {
GX_LO_CLEAR,
GX_LO_AND,
GX_LO_REVAND,
GX_LO_COPY,
GX_LO_INVAND,
GX_LO_NOOP,
GX_LO_XOR,
GX_LO_OR,
GX_LO_NOR,
GX_LO_EQUIV,
GX_LO_INV,
GX_LO_REVOR,
GX_LO_INVCOPY,
GX_LO_INVOR,
GX_LO_NAND,
GX_LO_SET,
} GXLogicOp;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1,
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5,
} GXCompType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64,
GX_PTTEXMTX1 = 67,
GX_PTTEXMTX2 = 70,
GX_PTTEXMTX3 = 73,
GX_PTTEXMTX4 = 76,
GX_PTTEXMTX5 = 79,
GX_PTTEXMTX6 = 82,
GX_PTTEXMTX7 = 85,
GX_PTTEXMTX8 = 88,
GX_PTTEXMTX9 = 91,
GX_PTTEXMTX10 = 94,
GX_PTTEXMTX11 = 97,
GX_PTTEXMTX12 = 100,
GX_PTTEXMTX13 = 103,
GX_PTTEXMTX14 = 106,
GX_PTTEXMTX15 = 109,
GX_PTTEXMTX16 = 112,
GX_PTTEXMTX17 = 115,
GX_PTTEXMTX18 = 118,
GX_PTTEXMTX19 = 121,
GX_PTIDENTITY = 125,
} GXPTTexMtx;
typedef enum _GXTevRegID {
GX_TEVPREV,
GX_TEVREG0,
GX_TEVREG1,
GX_TEVREG2,
GX_MAX_TEVREG,
} GXTevRegID;
typedef enum _GXDiffuseFn {
GX_DF_NONE,
GX_DF_SIGN,
GX_DF_CLAMP,
} GXDiffuseFn;
typedef enum _GXColorSrc {
GX_SRC_REG,
GX_SRC_VTX,
} GXColorSrc;
typedef enum _GXAttnFn {
GX_AF_SPEC,
GX_AF_SPOT,
GX_AF_NONE,
} GXAttnFn;
typedef enum _GXLightID {
GX_LIGHT0 = 0x001,
GX_LIGHT1 = 0x002,
GX_LIGHT2 = 0x004,
GX_LIGHT3 = 0x008,
GX_LIGHT4 = 0x010,
GX_LIGHT5 = 0x020,
GX_LIGHT6 = 0x040,
GX_LIGHT7 = 0x080,
GX_MAX_LIGHT = 0x100,
GX_LIGHT_NULL = 0,
} GXLightID;
typedef enum _GXTexOffset {
GX_TO_ZERO,
GX_TO_SIXTEENTH,
GX_TO_EIGHTH,
GX_TO_FOURTH,
GX_TO_HALF,
GX_TO_ONE,
GX_MAX_TEXOFFSET,
} GXTexOffset;
typedef enum _GXSpotFn {
GX_SP_OFF,
GX_SP_FLAT,
GX_SP_COS,
GX_SP_COS2,
GX_SP_SHARP,
GX_SP_RING1,
GX_SP_RING2,
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF,
GX_DA_GENTLE,
GX_DA_MEDIUM,
GX_DA_STEEP,
} GXDistAttnFn;
typedef enum _GXCullMode {
GX_CULL_NONE,
GX_CULL_FRONT,
GX_CULL_BACK,
GX_CULL_ALL,
} GXCullMode;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1,
GX_TEV_SWAP2,
GX_TEV_SWAP3,
GX_MAX_TEVSWAP,
} GXTevSwapSel;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN,
GX_CH_BLUE,
GX_CH_ALPHA,
} GXTevColorChan;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_PERSP_LIN = 2,
GX_FOG_PERSP_EXP = 4,
GX_FOG_PERSP_EXP2 = 5,
GX_FOG_PERSP_REVEXP = 6,
GX_FOG_PERSP_REVEXP2 = 7,
GX_FOG_ORTHO_LIN = 10,
GX_FOG_ORTHO_EXP = 12,
GX_FOG_ORTHO_EXP2 = 13,
GX_FOG_ORTHO_REVEXP = 14,
GX_FOG_ORTHO_REVEXP2 = 15,
GX_FOG_LIN = GX_FOG_PERSP_LIN,
GX_FOG_EXP = GX_FOG_PERSP_EXP,
GX_FOG_EXP2 = GX_FOG_PERSP_EXP2,
GX_FOG_REVEXP = GX_FOG_PERSP_REVEXP,
GX_FOG_REVEXP2 = GX_FOG_PERSP_REVEXP2,
} GXFogType;
typedef enum _GXTevColorArg {
GX_CC_CPREV,
GX_CC_APREV,
GX_CC_C0,
GX_CC_A0,
GX_CC_C1,
GX_CC_A1,
GX_CC_C2,
GX_CC_A2,
GX_CC_TEXC,
GX_CC_TEXA,
GX_CC_RASC,
GX_CC_RASA,
GX_CC_ONE,
GX_CC_HALF,
GX_CC_KONST,
GX_CC_ZERO,
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV,
GX_CA_A0,
GX_CA_A1,
GX_CA_A2,
GX_CA_TEXA,
GX_CA_RASA,
GX_CA_KONST,
GX_CA_ZERO,
} GXTevAlphaArg;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ,
} GXTevOp;
typedef enum _GXTevBias {
GX_TB_ZERO,
GX_TB_ADDHALF,
GX_TB_SUBHALF,
GX_MAX_TEVBIAS,
} GXTevBias;
typedef enum _GXTevScale {
GX_CS_SCALE_1,
GX_CS_SCALE_2,
GX_CS_SCALE_4,
GX_CS_DIVIDE_2,
GX_MAX_TEVSCALE,
} GXTevScale;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_8_8 = 0x00,
GX_TEV_KCSEL_7_8 = 0x01,
GX_TEV_KCSEL_6_8 = 0x02,
GX_TEV_KCSEL_5_8 = 0x03,
GX_TEV_KCSEL_4_8 = 0x04,
GX_TEV_KCSEL_3_8 = 0x05,
GX_TEV_KCSEL_2_8 = 0x06,
GX_TEV_KCSEL_1_8 = 0x07,
GX_TEV_KCSEL_1 = GX_TEV_KCSEL_8_8,
GX_TEV_KCSEL_3_4 = GX_TEV_KCSEL_6_8,
GX_TEV_KCSEL_1_2 = GX_TEV_KCSEL_4_8,
GX_TEV_KCSEL_1_4 = GX_TEV_KCSEL_2_8,
GX_TEV_KCSEL_K0 = 0x0C,
GX_TEV_KCSEL_K1 = 0x0D,
GX_TEV_KCSEL_K2 = 0x0E,
GX_TEV_KCSEL_K3 = 0x0F,
GX_TEV_KCSEL_K0_R = 0x10,
GX_TEV_KCSEL_K1_R = 0x11,
GX_TEV_KCSEL_K2_R = 0x12,
GX_TEV_KCSEL_K3_R = 0x13,
GX_TEV_KCSEL_K0_G = 0x14,
GX_TEV_KCSEL_K1_G = 0x15,
GX_TEV_KCSEL_K2_G = 0x16,
GX_TEV_KCSEL_K3_G = 0x17,
GX_TEV_KCSEL_K0_B = 0x18,
GX_TEV_KCSEL_K1_B = 0x19,
GX_TEV_KCSEL_K2_B = 0x1A,
GX_TEV_KCSEL_K3_B = 0x1B,
GX_TEV_KCSEL_K0_A = 0x1C,
GX_TEV_KCSEL_K1_A = 0x1D,
GX_TEV_KCSEL_K2_A = 0x1E,
GX_TEV_KCSEL_K3_A = 0x1F,
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_8_8 = 0x00,
GX_TEV_KASEL_7_8 = 0x01,
GX_TEV_KASEL_6_8 = 0x02,
GX_TEV_KASEL_5_8 = 0x03,
GX_TEV_KASEL_4_8 = 0x04,
GX_TEV_KASEL_3_8 = 0x05,
GX_TEV_KASEL_2_8 = 0x06,
GX_TEV_KASEL_1_8 = 0x07,
GX_TEV_KASEL_1 = GX_TEV_KASEL_8_8,
GX_TEV_KASEL_3_4 = GX_TEV_KASEL_6_8,
GX_TEV_KASEL_1_2 = GX_TEV_KASEL_4_8,
GX_TEV_KASEL_1_4 = GX_TEV_KASEL_2_8,
GX_TEV_KASEL_K0_R = 0x10,
GX_TEV_KASEL_K1_R = 0x11,
GX_TEV_KASEL_K2_R = 0x12,
GX_TEV_KASEL_K3_R = 0x13,
GX_TEV_KASEL_K0_G = 0x14,
GX_TEV_KASEL_K1_G = 0x15,
GX_TEV_KASEL_K2_G = 0x16,
GX_TEV_KASEL_K3_G = 0x17,
GX_TEV_KASEL_K0_B = 0x18,
GX_TEV_KASEL_K1_B = 0x19,
GX_TEV_KASEL_K2_B = 0x1A,
GX_TEV_KASEL_K3_B = 0x1B,
GX_TEV_KASEL_K0_A = 0x1C,
GX_TEV_KASEL_K1_A = 0x1D,
GX_TEV_KASEL_K2_A = 0x1E,
GX_TEV_KASEL_K3_A = 0x1F,
} GXTevKAlphaSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1,
GX_KCOLOR2,
GX_KCOLOR3,
GX_MAX_KCOLOR,
} GXTevKColorID;
typedef enum _GXZTexOp {
GX_ZT_DISABLE,
GX_ZT_ADD,
GX_ZT_REPLACE,
GX_MAX_ZTEXOP,
} GXZTexOp;
typedef enum _GXIndTexFormat {
GX_ITF_8,
GX_ITF_5,
GX_ITF_4,
GX_ITF_3,
GX_MAX_ITFORMAT,
} GXIndTexFormat;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE,
GX_ITB_S,
GX_ITB_T,
GX_ITB_ST,
GX_ITB_U,
GX_ITB_SU,
GX_ITB_TU,
GX_ITB_STU,
GX_MAX_ITBIAS,
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF,
GX_ITBA_S,
GX_ITBA_T,
GX_ITBA_U,
GX_MAX_ITBALPHA,
} GXIndTexAlphaSel;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF,
GX_ITM_0,
GX_ITM_1,
GX_ITM_2,
GX_ITM_S0 = 5,
GX_ITM_S1,
GX_ITM_S2,
GX_ITM_T0 = 9,
GX_ITM_T1,
GX_ITM_T2,
} GXIndTexMtxID;
typedef enum _GXIndTexWrap {
GX_ITW_OFF,
GX_ITW_256,
GX_ITW_128,
GX_ITW_64,
GX_ITW_32,
GX_ITW_16,
GX_ITW_0,
GX_MAX_ITWRAP,
} GXIndTexWrap;
typedef enum _GXIndTexStageID {
GX_INDTEXSTAGE0,
GX_INDTEXSTAGE1,
GX_INDTEXSTAGE2,
GX_INDTEXSTAGE3,
GX_MAX_INDTEXSTAGE,
} GXIndTexStageID;
typedef enum _GXIndTexScale {
GX_ITS_1,
GX_ITS_2,
GX_ITS_4,
GX_ITS_8,
GX_ITS_16,
GX_ITS_32,
GX_ITS_64,
GX_ITS_128,
GX_ITS_256,
GX_MAX_ITSCALE,
} GXIndTexScale;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1,
} GXClipMode;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19,
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8,
GX_TL_RGB565,
GX_TL_RGB5A3,
GX_MAX_TLUTFMT,
} GXTlutFmt;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3,
} GXMiscToken;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K,
GX_TEXCACHE_128K,
GX_TEXCACHE_512K,
GX_TEXCACHE_NONE
} GXTexCacheSize;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES,
GX_PERF0_CLIP_VTX,
GX_PERF0_CLIP_CLKS,
GX_PERF0_XF_WAIT_IN,
GX_PERF0_XF_WAIT_OUT,
GX_PERF0_XF_XFRM_CLKS,
GX_PERF0_XF_LIT_CLKS,
GX_PERF0_XF_BOT_CLKS,
GX_PERF0_XF_REGLD_CLKS,
GX_PERF0_XF_REGRD_CLKS,
GX_PERF0_CLIP_RATIO,
GX_PERF0_TRIANGLES,
GX_PERF0_TRIANGLES_CULLED,
GX_PERF0_TRIANGLES_PASSED,
GX_PERF0_TRIANGLES_SCISSORED,
GX_PERF0_TRIANGLES_0TEX,
GX_PERF0_TRIANGLES_1TEX,
GX_PERF0_TRIANGLES_2TEX,
GX_PERF0_TRIANGLES_3TEX,
GX_PERF0_TRIANGLES_4TEX,
GX_PERF0_TRIANGLES_5TEX,
GX_PERF0_TRIANGLES_6TEX,
GX_PERF0_TRIANGLES_7TEX,
GX_PERF0_TRIANGLES_8TEX,
GX_PERF0_TRIANGLES_0CLR,
GX_PERF0_TRIANGLES_1CLR,
GX_PERF0_TRIANGLES_2CLR,
GX_PERF0_QUAD_0CVG,
GX_PERF0_QUAD_NON0CVG,
GX_PERF0_QUAD_1CVG,
GX_PERF0_QUAD_2CVG,
GX_PERF0_QUAD_3CVG,
GX_PERF0_QUAD_4CVG,
GX_PERF0_AVG_QUAD_CNT,
GX_PERF0_CLOCKS,
GX_PERF0_NONE
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS,
GX_PERF1_TX_IDLE,
GX_PERF1_TX_REGS,
GX_PERF1_TX_MEMSTALL,
GX_PERF1_TC_CHECK1_2,
GX_PERF1_TC_CHECK3_4,
GX_PERF1_TC_CHECK5_6,
GX_PERF1_TC_CHECK7_8,
GX_PERF1_TC_MISS,
GX_PERF1_VC_ELEMQ_FULL,
GX_PERF1_VC_MISSQ_FULL,
GX_PERF1_VC_MEMREQ_FULL,
GX_PERF1_VC_STATUS7,
GX_PERF1_VC_MISSREP_FULL,
GX_PERF1_VC_STREAMBUF_LOW,
GX_PERF1_VC_ALL_STALLS,
GX_PERF1_VERTICES,
GX_PERF1_FIFO_REQ,
GX_PERF1_CALL_REQ,
GX_PERF1_VC_MISS_REQ,
GX_PERF1_CP_ALL_REQ,
GX_PERF1_CLOCKS,
GX_PERF1_NONE
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS,
GX_VC_NRM,
GX_VC_CLR0,
GX_VC_CLR1,
GX_VC_TEX0,
GX_VC_TEX1,
GX_VC_TEX2,
GX_VC_TEX3,
GX_VC_TEX4,
GX_VC_TEX5,
GX_VC_TEX6,
GX_VC_TEX7,
GX_VC_ALL = 0xf
} GXVCachePerf;
typedef enum _GXAlphaReadMode
{
GX_READ_00,
GX_READ_FF,
GX_READ_NONE,
} GXAlphaReadMode;
typedef enum _GXCopyMode
{
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3,
} GXCopyMode;
typedef enum _GXTlutSize
{
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024,
} GXTlutSize;
typedef enum
{
VI_TVMODE_NTSC_INT = (((0) << 2) + (0)) ,
VI_TVMODE_NTSC_DS = (((0) << 2) + (1)) ,
VI_TVMODE_NTSC_PROG = (((0) << 2) + (2)) ,
VI_TVMODE_3 = 3,
VI_TVMODE_PAL_INT = (((1) << 2) + (0)) ,
VI_TVMODE_PAL_DS = (((1) << 2) + (1)) ,
VI_TVMODE_EURGB60_INT = (((5) << 2) + (0)) ,
VI_TVMODE_EURGB60_DS = (((5) << 2) + (1)) ,
VI_TVMODE_MPAL_INT = (((2) << 2) + (0)) ,
VI_TVMODE_MPAL_DS = (((2) << 2) + (1)) ,
VI_TVMODE_DEBUG_INT = (((3) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_INT = (((4) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_DS = (((4) << 2) + (1))
} VITVMode;
typedef enum
{
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF
} VIXFBMode;
typedef void (*VIRetraceCallback)(u32 retraceCount);
void VIConfigure(const struct _GXRenderModeObj *rm);
void VISetBlack(BOOL);
void VIWaitForRetrace();
void VIConfigurePan(u16 x_origin, u16 y_origin, u16 width, u16 height);
u32 VIGetRetraceCount();
u32 VIGetDTVStatus();
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void* VIGetNextFrameBuffer();
void* VIGetCurrentFrameBuffer();
void VISetNextFrameBuffer(void* fb);
void VIInit();
void VIFlush();
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXColor {
u8 r;
u8 g;
u8 b;
u8 a;
} GXColor;
typedef struct _GXTexObj {
u32 dummy[8];
} GXTexObj;
typedef struct _GXTlutObj {
u32 dummy[3];
} GXTlutObj;
typedef struct _GXLightObj {
u32 dummy[16];
} GXLightObj;
typedef struct _GXColorS10 {
s16 r;
s16 g;
s16 b;
s16 a;
} GXColorS10;
typedef struct _GXTexRegion {
u32 dummy[4];
} GXTexRegion;
typedef struct _GXTlutRegion {
u32 dummy[4];
} GXTlutRegion;
typedef struct _GXFogAdjTable
{
u16 r[10];
} GXFogAdjTable;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt cnt;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
extern u16 *__memReg;
extern u16 *__peReg;
extern u16 *__cpReg;
extern u32 *__piReg;
inline u32 __GXReadCPCounterU32(u32 regAddrL, u32 regAddrH);
void GXSetTevDirect(GXTevStageID tev_stage);
void GXSetNumIndStages(u8 nIndStages);
void GXSetIndTexMtx(GXIndTexMtxID mtx_sel, f32 offset[2][3], s8 scale_exp);
void GXSetIndTexOrder(GXIndTexStageID ind_stage, GXTexCoordID tex_coord, GXTexMapID tex_map);
void GXSetTevIndirect(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXIndTexFormat format,
GXIndTexBiasSel bias_sel, GXIndTexMtxID matrix_sel, GXIndTexWrap wrap_s,
GXIndTexWrap wrap_t, GXBool add_prev, GXBool ind_lod,
GXIndTexAlphaSel alpha_sel);
void GXSetTevIndWarp(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXBool signed_offsets,
GXBool replace_mode, GXIndTexMtxID matrix_sel);
void GXSetIndTexCoordScale(GXIndTexStageID ind_state, GXIndTexScale scale_s, GXIndTexScale scale_t);
extern void __GXSetIndirectMask(u32 mask);
void GXSetScissor(u32 left, u32 top, u32 wd, u32 ht);
void GXSetCullMode(GXCullMode mode);
void GXSetCoPlanar(GXBool enable);
void GXBeginDisplayList(void* list, u32 size);
u32 GXEndDisplayList(void);
void GXCallDisplayList(void* list, u32 nbytes);
void GXDrawSphere(u8 numMajor, u8 numMinor);
typedef struct
{
u8 pad[128];
} GXFifoObj;
typedef void (*GXBreakPtCallback)(void);
void GXInitFifoBase(GXFifoObj *fifo, void *base, u32 size);
void GXInitFifoPtrs(GXFifoObj *fifo, void *readPtr, void *writePtr);
void GXInitFifoLimits(GXFifoObj *fifo, u32 hiWatermark, u32 loWatermark);
void GXSetCPUFifo(GXFifoObj *fifo);
void GXSetGPFifo(GXFifoObj *fifo);
void GXSaveCPUFifo(GXFifoObj *fifo);
void GXSaveGPFifo(GXFifoObj *fifo);
void GXGetGPStatus(GXBool *overhi, GXBool *underlow, GXBool *readIdle, GXBool *cmdIdle, GXBool *brkpt);
void GXGetFifoStatus(GXFifoObj *fifo, GXBool *overhi, GXBool *underflow, u32 *fifoCount, GXBool *cpuWrite, GXBool *gpRead, GXBool *fifowrap);
void GXGetFifoPtrs(GXFifoObj *fifo, void **readPtr, void **writePtr);
void *GXGetFifoBase(GXFifoObj *fifo);
u32 GXGetFifoSize(GXFifoObj *fifo);
void GXGetFifoLimits(GXFifoObj *fifo, u32 *hi, u32 *lo);
GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback cb);
void GXEnableBreakPt(void *break_pt);
void GXDisableBreakPt(void);
OSThread *GXSetCurrentGXThread(void);
OSThread *GXGetCurrentGXThread(void);
GXFifoObj *GXGetCPUFifo(void);
GXFifoObj *GXGetGPFifo(void);
u32 GXGetOverflowCount(void);
u32 GXResetOverflowCount(void);
volatile void *GXRedirectWriteGatherPipe(void *ptr);
void GXRestoreWriteGatherPipe(void);
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
void GXSetCopyClear(GXColor clear_clr, u32 clear_z);
void GXAdjustForOverscan(GXRenderModeObj* rmin, GXRenderModeObj* rmout, u16 hor, u16 ver);
void GXCopyDisp(void* dest, GXBool clear);
void GXSetDispCopyGamma(GXGamma gamma);
void GXSetDispCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetDispCopyDst(u16 wd, u16 ht);
f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
u32 GXSetDispCopyYScale(f32 vscale);
u16 GXGetNumXfbLines(u16 efbHeight, f32 yScale);
void GXSetCopyFilter(GXBool aa, const u8 sample_pattern[12][2], GXBool vf, const u8 vfilter[7]);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetTexCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetTexCopyDst(u16 wd, u16 ht, GXTexFmt fmt, GXBool mipmap);
void GXCopyTex(void* dest, GXBool clear);
void GXSetCopyClamp(GXFBClamp clamp);
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(const GXVtxDescList* list);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetNumTexGens(u8 nTexGens);
void GXBegin(GXPrimitive type, GXVtxFmt vtxfmt, u16 nverts);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx,
GXBool normalize, u32 postmtx);
void GXSetLineWidth(u8 width, GXTexOffset texOffsets);
void GXSetPointSize(u8 pointSize, GXTexOffset texOffsets);
void GXEnableTexOffsets(GXTexCoordID coord, GXBool line_enable, GXBool point_enable);
void GXSetArray(GXAttr attr, const void* data, u8 stride);
void GXInvalidateVtxCache(void);
static inline void GXSetTexCoordGen(GXTexCoordID dst_coord, GXTexGenType func,
GXTexGenSrc src_param, u32 mtx);
GXBool GXGetTexObjMipMap(const GXTexObj* obj);
GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
u16 GXGetTexObjHeight(const GXTexObj* obj);
u16 GXGetTexObjWidth(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapS(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapT(const GXTexObj* obj);
void* GXGetTexObjData(const GXTexObj* obj);
void GXGetProjectionv(f32* p);
void GXGetLightPos(GXLightObj* lt_obj, f32* x, f32* y, f32* z);
void GXGetLightColor(GXLightObj* lt_obj, GXColor* color);
void GXGetVtxAttrFmt(GXVtxFmt idx, GXAttr attr, GXCompCnt* compCnt, GXCompType* compType,
u8* shift);
void GXSetNumChans(u8 nChans);
void GXSetChanCtrl(GXChannelID chan, GXBool enable, GXColorSrc amb_src, GXColorSrc mat_src,
u32 light_mask, GXDiffuseFn diff_fn, GXAttnFn attn_fn);
void GXSetChanAmbColor(GXChannelID chan, GXColor amb_color);
void GXSetChanMatColor(GXChannelID chan, GXColor mat_color);
void GXInitLightSpot(GXLightObj* lt_obj, f32 cutoff, GXSpotFn spot_func);
void GXInitLightDistAttn(GXLightObj* lt_obj, f32 ref_distance, f32 ref_brightness,
GXDistAttnFn dist_func);
void GXInitLightPos(GXLightObj* lt_obj, f32 x, f32 y, f32 z);
void GXInitLightDir(GXLightObj* lt_obj, f32 nx, f32 ny, f32 nz);
void GXInitLightColor(GXLightObj* lt_obj, GXColor color);
void GXInitLightAttn(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
void GXInitLightAttnA(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2);
void GXInitLightAttnK(GXLightObj* lt_obj, f32 k0, f32 k1, f32 k2);
void GXLoadLightObjImm(GXLightObj* lt_obj, GXLightID light);
typedef void (*GXDrawSyncCallback)(u16 token);
typedef void (*GXDrawDoneCallback)(void);
BOOL IsWriteGatherBufferEmpty(void);
GXFifoObj *GXInit(void *base, u32 size);
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush(void);
void GXResetWriteGatherPipe(void);
void GXAbortFrame(void);
void GXSetDrawSync(u16 token);
u16 GXReadDrawSync(void);
void GXSetDrawDone(void);
void GXWaitDrawDone(void);
void GXDrawDone(void);
void GXPixModeSync(void);
void GXTexModeSync(void);
GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback cb);
GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback cb);
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush();
void GXResetWriteGatherPipe();
void GXAbortFrame();
void GXReadXfRasMetric(u32* xf_wait_in, u32* xf_wait_out, u32* ras_busy, u32* clocks);
void GXSetFog(GXFogType type, f32 startz, f32 endz, f32 nearz, f32 farz, GXColor color);
void GXInitFogAdjTable(GXFogAdjTable *table, u16 width, f32 projmtx[4][4]);
void GXSetFogRangeAdj(GXBool enable, u16 center, GXFogAdjTable *table);
void GXSetBlendMode(GXBlendMode type, GXBlendFactor src_factor, GXBlendFactor dst_factor, GXLogicOp op);
void GXSetColorUpdate(GXBool update_enable);
void GXSetAlphaUpdate(GXBool update_enable);
void GXSetZMode(GXBool compare_enable, GXCompare func, GXBool update_enable);
void GXSetZCompLoc(GXBool before_tex);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetDither(GXBool dither);
void GXSetDstAlpha(GXBool enable, u8 alpha);
void GXSetFieldMask(GXBool odd_mask, GXBool even_mask);
void GXSetFieldMode(GXBool field_mode, GXBool half_aspect_ratio);
void GXSetTevOp(GXTevStageID id, GXTevMode mode);
void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c,
GXTevColorArg d);
void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c,
GXTevAlphaArg d);
void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevColor(GXTevRegID id, GXColor color);
void GXSetTevColorS10(GXTevRegID id, GXColorS10 color);
void GXSetTevKColor(GXTevKColorID id, GXColor color);
void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel ras_sel, GXTevSwapSel tex_sel);
void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green,
GXTevColorChan blue, GXTevColorChan alpha);
void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
void GXSetZTexture(GXZTexOp op, GXTexFmt fmt, u32 bias);
void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
void GXSetNumTevStages(u8 nStages);
typedef GXTexRegion* (*GXTexRegionCallback)(const GXTexObj* obj, GXTexMapID id);
typedef GXTlutRegion* (*GXTlutRegionCallback)(u32 idx);
void GXInitTexObj(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap);
void GXInitTexObjCI(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap, u32 tlut_name);
void GXInitTexObjData(GXTexObj* obj, void* image_ptr);
void GXInitTexObjLOD(GXTexObj* obj, GXTexFilter min_filt, GXTexFilter mag_filt, f32 min_lod, f32 max_lod, f32 lod_bias,
GXBool bias_clamp, GXBool do_edge_lod, GXAnisotropy max_aniso);
void GXLoadTexObj(GXTexObj* obj, GXTexMapID id);
u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, GXBool mipmap, u8 max_lod);
void GXInvalidateTexAll();
void GXInitTexObjWrapMode(GXTexObj* obj, GXTexWrapMode s, GXTexWrapMode t);
void GXInitTlutObj(GXTlutObj* tlut_obj, void* lut, GXTlutFmt fmt, u16 n_entries);
void GXLoadTlut(GXTlutObj* obj, u32 idx);
void GXSetTexCoordScaleManually(GXTexCoordID coord, GXBool enable, u16 ss, u16 ts);
void GXInitTexCacheRegion(GXTexRegion* region, GXBool is_32b_mipmap, u32 tmem_even, GXTexCacheSize size_even,
u32 tmem_odd, GXTexCacheSize size_odd);
GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback callback);
void GXInvalidateTexRegion(GXTexRegion* region);
void GXInitTlutRegion(GXTlutRegion* region, u32 tmem_addr, GXTlutSize tlut_size);
void GXSetTexCoordBias(GXTexCoordID coord, u8 s_enable, u8 t_enable);
void GXSetProjection(f32 mtx[4][4], GXProjectionType type);
void GXLoadPosMtxImm(f32 mtx[3][4], u32 id);
void GXLoadNrmMtxImm(f32 mtx[3][4], u32 id);
void GXLoadTexMtxImm(f32 mtx[][4], u32 id, GXTexMtxType type);
void GXSetViewport(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz);
void GXSetCurrentMtx(u32 id);
void GXSetViewportJitter(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz, u32 field);
void GXSetScissorBoxOffset(s32 x_off, s32 y_off);
void GXSetClipMode(GXClipMode mode);
typedef enum {
GX_WARN_NONE,
GX_WARN_SEVERE,
GX_WARN_MEDIUM,
GX_WARN_ALL
} GXWarningLevel;
typedef void (*GXVerifyCallback)(GXWarningLevel level, u32 id, char *msg);
void GXSetVerifyLevel(GXWarningLevel level);
GXVerifyCallback GXSetVerifyCallback(GXVerifyCallback cb);
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
volatile PPCWGPipe GXWGFifo : (0xCC008000) ;
static inline void GXPosition2f32(f32 x, f32 y);
static inline void GXPosition3s16(s16 x, s16 y, s16 z);
static inline void GXPosition3f32(f32 x, f32 y, f32 z);
static inline void GXNormal3f32(f32 x, f32 y, f32 z);
static inline void GXColor1u32(u32 v);
static inline void GXColor4u8(u8 r, u8 g, u8 b, u8 a);
static inline void GXTexCoord2s16(s16 u, s16 v);
static inline void GXPosition2s16(s16 x, s16 y);
static inline void GXPosition2u16(u16 x, u16 y);
static inline void GXTexCoord2f32(f32 u, f32 v);
static inline void GXTexCoord2u8(u8 u, u8 v);
static inline void GXPosition1x8(u8 index);
static inline void GXTexCoord2u16(u16 s, u16 t);
static inline void GXEnd(void);
typedef struct {
unsigned int cmd:8;
unsigned int a0:4;
unsigned int c0:5;
unsigned int Aa0:3;
unsigned int Ac0:3;
unsigned int a1:4;
unsigned int c1:5;
unsigned int b0:4;
unsigned int b1:4;
unsigned int Aa1:3;
unsigned int Ac1:3;
unsigned int d0:3;
unsigned int Ab0:3;
unsigned int Ad0:3;
unsigned int d1:3;
unsigned int Ab1:3;
unsigned int Ad1:3;
} Gsetcombine_new;
typedef struct {
int cmd:8;
unsigned int Aa0:3;
unsigned int Ab0:3;
unsigned int Ac0:3;
unsigned int Ad0:3;
unsigned int Aa1:3;
unsigned int Ab1:3;
unsigned int Ac1:3;
unsigned int Ad1:3;
unsigned int a0:4;
unsigned int b0:4;
unsigned int c0:4;
unsigned int d0:4;
unsigned int a1:4;
unsigned int b1:4;
unsigned int c1:4;
unsigned int d1:4;
} Gsetcombine_tev;
typedef struct {
int cmd:8;
unsigned int upper0:8;
unsigned int lower0:16;
unsigned int upper1:16;
unsigned int lower1:16;
} Gsetcombine_raw;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int pad2:32;
unsigned int s:16;
unsigned int t:16;
unsigned int pad3:32;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect2;
typedef struct {
int cmd:8;
unsigned int dol_fmt:4;
unsigned int pad0:1;
unsigned int tile:3;
unsigned int tlut_name:4;
unsigned int wrap_s:2;
unsigned int wrap_t:2;
unsigned int shift_s:4;
unsigned int shift_t:4;
unsigned int pad1:32;
} Gsettile_dolphin;
typedef struct {
int cmd:8;
unsigned int sl:14;
unsigned int slen:10;
s8 isDolphin:1;
unsigned int pad:4;
unsigned int tile:3;
unsigned int tl:14;
unsigned int tlen:10;
} Gsettilesize_Dolphin;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int isDolphin:1;
unsigned int ht:8;
unsigned int wd:10;
unsigned int imgaddr:32;
} Gsetimg2;
typedef union {
Gsetimg setimg;
Gsetimg2 setimg2;
} Gsetimg_new;
typedef struct {
int cmd:8;
unsigned int type:2;
unsigned int pad0:2;
unsigned int tlut_name:4;
unsigned int pad1:2;
unsigned int count:14;
unsigned int tlut_addr:32;
} Gloadtlut_dolphin;
typedef struct {
unsigned int cmd:8;
unsigned int xparam:8;
unsigned int pad:2;
unsigned int level:3;
unsigned int tile:3;
unsigned int on:8;
unsigned short s;
unsigned short t;
} Gtexture_internal;
typedef struct {
unsigned int cmd:8;
unsigned int index:8;
unsigned int offset:16;
unsigned int data;
} Gmoveword;
typedef struct {
unsigned int cmd:8;
unsigned int length:8;
unsigned int offset:8;
unsigned int index:8;
unsigned int data;
} Gmovemem;
typedef struct Gsettexedgealpha {
unsigned int cmd:8;
unsigned int unused0:24;
unsigned int unused1:24;
unsigned int tex_edge_alpha:8;
} Gsettexedgealpha;
typedef struct {
int cmd:8;
unsigned int x0:10;
unsigned int x0frac:2;
unsigned int y0:10;
unsigned int y0frac:2;
unsigned int pad:8;
unsigned int x1:10;
unsigned int x1frac:2;
unsigned int y1:10;
unsigned int y1frac:2;
} Gscissor;
typedef struct {
int cmd:8;
unsigned int x0:10;
unsigned int x0frac:2;
unsigned int y0:10;
unsigned int y0frac:2;
unsigned int pad:8;
unsigned int x1:10;
unsigned int x1frac:2;
unsigned int y1:10;
unsigned int y1frac:2;
} Gfillrect2;
typedef struct Gnoop {
unsigned int cmd: 8;
unsigned int tag: 8;
unsigned int param0: 16;
unsigned int param1;
} Gnoop;
typedef struct Gmtx {
unsigned int cmd: 8;
unsigned int par: 8;
unsigned int pad: 8;
unsigned int type: 8;
unsigned int addr;
} Gmtx;
typedef struct Gvtx {
unsigned int cmd: 8;
unsigned int pad0: 4;
unsigned int n: 8;
unsigned int pad1: 4;
unsigned int vn:8;
unsigned int addr;
} Gvtx;
typedef struct Gline3D_new {
unsigned int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int wd: 8;
unsigned int pad;
} Gline3D_new;
typedef struct Gtri1 {
unsigned int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int v2: 8;
unsigned int pad;
} Gtri1;
typedef struct Gtri2 {
int cmd: 8;
unsigned int t0v0: 8;
unsigned int t0v1: 8;
unsigned int t0v2: 8;
unsigned int pad: 8;
unsigned int t1v0: 8;
unsigned int t1v1: 8;
unsigned int t1v2: 8;
} Gtri2;
typedef struct Gtrin_independ {
unsigned int cmd: 8;
unsigned int count: 7;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v2_1: 2;
unsigned int f1v2_0: 3;
unsigned int f1v1: 5;
unsigned int f1v0: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gtrin_independ;
typedef struct Gtrin {
unsigned int f3v2: 5;
unsigned int f3v1: 5;
unsigned int f3v0: 5;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v2_1: 2;
unsigned int f1v2_0: 3;
unsigned int f1v1: 5;
unsigned int f1v0: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gtrin;
typedef struct Gtrin_7b {
unsigned int f2v2: 7;
unsigned int f2v1: 7;
unsigned int f2v0: 7;
unsigned int f1v2: 7;
unsigned int f1v1_1: 4;
unsigned int f1v1_0: 3;
unsigned int f1v0: 7;
unsigned int f0v2: 7;
unsigned int f0v1: 7;
unsigned int f0v0: 7;
unsigned int is7bit: 1;
} Gtrin_7b;
typedef struct Gquad_independ {
unsigned int cmd: 8;
unsigned int count: 7;
unsigned int unused: 5;
unsigned int f1v3: 5;
unsigned int f1v2: 5;
unsigned int f1v1_1: 2;
unsigned int f1v1_0: 3;
unsigned int f1v0: 5;
unsigned int f0v3: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gquad_independ;
typedef struct Gquad {
unsigned int f2v3: 5;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v3: 5;
unsigned int f1v2: 5;
unsigned int f1v1_1: 2;
unsigned int f1v1_0: 3;
unsigned int f1v0: 5;
unsigned int f0v3: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gquad;
typedef struct Gquad_7b {
unsigned int f1v3: 7;
unsigned int f1v2: 7;
unsigned int f1v1: 7;
unsigned int f1v0_1: 4;
unsigned int f1v0_0: 3;
unsigned int pad: 4;
unsigned int f0v3: 7;
unsigned int f0v2: 7;
unsigned int f0v1: 7;
unsigned int f0v0: 7;
unsigned int pad0: 3;
unsigned int is7bit: 1;
} Gquad_7b;
typedef struct Gquad0 {
int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int v2: 8;
unsigned int pad: 24;
unsigned int v3: 8;
} Gquad0;
typedef struct Gculldl {
int cmd: 8;
unsigned int pad0: 8;
unsigned int vstart: 16;
unsigned int pad1: 16;
unsigned int vend: 16;
} Gculldl;
typedef struct Gspecial1 {
int cmd: 8;
int mode: 8;
unsigned int param0: 16;
unsigned int param1;
} Gspecial1;
typedef struct {
int cmd:8;
int pad0:8;
u32 sft:8;
u32 len:8;
unsigned int data:32;
} Gsetothermode_dolphin;
typedef struct {
unsigned char col[3];
unsigned char kc;
unsigned char colc[3];
unsigned char kl;
signed short pos[3];
unsigned char kq;
} Light_pos_t;
typedef union {
Light_t l;
Light_pos_t p;
long long int force_align[2];
} Light_new;
typedef struct {
u8 color0;
u8 color1;
u8 color2;
u8 color3;
} combiner_tev_color;
typedef struct {
u8 alpha0;
u8 alpha1;
} combiner_tev_alpha;
enum {
mFont_CONT_CODE_BEGIN = 0,
mFont_CONT_CODE_LAST = mFont_CONT_CODE_BEGIN,
mFont_CONT_CODE_CONTINUE,
mFont_CONT_CODE_CLEAR,
mFont_CONT_CODE_CURSOR_SET_TIME,
mFont_CONT_CODE_BUTTON,
mFont_CONT_CODE_COLOR,
mFont_CONT_CODE_ABLE_CANCEL,
mFont_CONT_CODE_UNABLE_CANCEL,
mFont_CONT_CODE_SET_DEMO_ORDER_PLAYER,
mFont_CONT_CODE_SET_DEMO_ORDER_NPC0,
mFont_CONT_CODE_SET_DEMO_ORDER_NPC1,
mFont_CONT_CODE_SET_DEMO_ORDER_NPC2,
mFont_CONT_CODE_SET_DEMO_ORDER_QUEST,
mFont_CONT_CODE_SET_SELECT_WINDOW,
mFont_CONT_CODE_SET_NEXT_MESSAGE_F,
mFont_CONT_CODE_SET_NEXT_MESSAGE_0,
mFont_CONT_CODE_SET_NEXT_MESSAGE_1,
mFont_CONT_CODE_SET_NEXT_MESSAGE_2,
mFont_CONT_CODE_SET_NEXT_MESSAGE_3,
mFont_CONT_CODE_SET_NEXT_MESSAGE_RANDOM_2,
mFont_CONT_CODE_SET_NEXT_MESSAGE_RANDOM_3,
mFont_CONT_CODE_SET_NEXT_MESSAGE_RANDOM_4,
mFont_CONT_CODE_SET_SELECT_STRING_2,
mFont_CONT_CODE_SET_SELECT_STRING_3,
mFont_CONT_CODE_SET_SELECT_STRING_4,
mFont_CONT_CODE_SET_FORCE_NEXT,
mFont_CONT_CODE_PUT_STRING_PLAYER_NAME,
mFont_CONT_CODE_PUT_STRING_TALK_NAME,
mFont_CONT_CODE_PUT_STRING_TAIL,
mFont_CONT_CODE_PUT_STRING_YEAR,
mFont_CONT_CODE_PUT_STRING_MONTH,
mFont_CONT_CODE_PUT_STRING_WEEK,
mFont_CONT_CODE_PUT_STRING_DAY,
mFont_CONT_CODE_PUT_STRING_HOUR,
mFont_CONT_CODE_PUT_STRING_MIN,
mFont_CONT_CODE_PUT_STRING_SEC,
mFont_CONT_CODE_PUT_STRING_FREE0,
mFont_CONT_CODE_PUT_STRING_FREE1,
mFont_CONT_CODE_PUT_STRING_FREE2,
mFont_CONT_CODE_PUT_STRING_FREE3,
mFont_CONT_CODE_PUT_STRING_FREE4,
mFont_CONT_CODE_PUT_STRING_FREE5,
mFont_CONT_CODE_PUT_STRING_FREE6,
mFont_CONT_CODE_PUT_STRING_FREE7,
mFont_CONT_CODE_PUT_STRING_FREE8,
mFont_CONT_CODE_PUT_STRING_FREE9,
mFont_CONT_CODE_PUT_STRING_DETERMINATION,
mFont_CONT_CODE_PUT_STRING_COUNTRY_NAME,
mFont_CONT_CODE_PUT_STRING_RANDOM_NUMBER_2,
mFont_CONT_CODE_PUT_STRING_ITEM0,
mFont_CONT_CODE_PUT_STRING_ITEM1,
mFont_CONT_CODE_PUT_STRING_ITEM2,
mFont_CONT_CODE_PUT_STRING_ITEM3,
mFont_CONT_CODE_PUT_STRING_ITEM4,
mFont_CONT_CODE_PUT_STRING_FREE10,
mFont_CONT_CODE_PUT_STRING_FREE11,
mFont_CONT_CODE_PUT_STRING_FREE12,
mFont_CONT_CODE_PUT_STRING_FREE13,
mFont_CONT_CODE_PUT_STRING_FREE14,
mFont_CONT_CODE_PUT_STRING_FREE15,
mFont_CONT_CODE_PUT_STRING_FREE16,
mFont_CONT_CODE_PUT_STRING_FREE17,
mFont_CONT_CODE_PUT_STRING_FREE18,
mFont_CONT_CODE_PUT_STRING_FREE19,
mFont_CONT_CODE_PUT_STRING_MAIL,
mFont_CONT_CODE_SET_PLAYER_DESTINY0,
mFont_CONT_CODE_SET_PLAYER_DESTINY1,
mFont_CONT_CODE_SET_PLAYER_DESTINY2,
mFont_CONT_CODE_SET_PLAYER_DESTINY3,
mFont_CONT_CODE_SET_PLAYER_DESTINY4,
mFont_CONT_CODE_SET_PLAYER_DESTINY5,
mFont_CONT_CODE_SET_PLAYER_DESTINY6,
mFont_CONT_CODE_SET_PLAYER_DESTINY7,
mFont_CONT_CODE_SET_PLAYER_DESTINY8,
mFont_CONT_CODE_SET_PLAYER_DESTINY9,
mFont_CONT_CODE_SET_MESSAGE_CONTENTS_NORMAL,
mFont_CONT_CODE_SET_MESSAGE_CONTENTS_ANGRY,
mFont_CONT_CODE_SET_MESSAGE_CONTENTS_SAD,
mFont_CONT_CODE_SET_MESSAGE_CONTENTS_FUN,
mFont_CONT_CODE_SET_MESSAGE_CONTENTS_SLEEPY,
mFont_CONT_CODE_SET_COLOR_CHAR,
mFont_CONT_CODE_SOUND_CUT,
mFont_CONT_CODE_SET_LINE_OFFSET,
mFont_CONT_CODE_SET_LINE_TYPE,
mFont_CONT_CODE_SET_CHAR_SCALE,
mFont_CONT_CODE_BUTTON2,
mFont_CONT_CODE_BGM_MAKE,
mFont_CONT_CODE_BGM_DELETE,
mFont_CONT_CODE_MSG_TIME_END,
mFont_CONT_CODE_SOUND_TRG_SYS,
mFont_CONT_CODE_SET_LINE_SCALE,
mFont_CONT_CODE_SOUND_NO_PAGE,
mFont_CONT_CODE_VOICE_TRUE,
mFont_CONT_CODE_VOICE_FALSE,
mFont_CONT_CODE_SELECT_NO_B,
mFont_CONT_CODE_GIVE_OPEN,
mFont_CONT_CODE_GIVE_CLOSE,
mFont_CONT_CODE_SET_MESSAGE_CONTENTS_GLOOMY,
mFont_CONT_CODE_SELECT_NO_B_CLOSE,
mFont_CONT_CODE_SET_NEXT_MESSAGE_RANDOM_SECTION,
mFont_CONT_CODE_AGB_DUMMY0,
mFont_CONT_CODE_AGB_DUMMY1,
mFont_CONT_CODE_AGB_DUMMY2,
mFont_CONT_CODE_SPACE,
mFont_CONT_CODE_AGB_DUMMY3,
mFont_CONT_CODE_AGB_DUMMY4,
mFont_CONT_CODE_AGB_MALE_FEMALE_CHECK,
mFont_CONT_CODE_AGB_DUMMY5,
mFont_CONT_CODE_AGB_DUMMY6,
mFont_CONT_CODE_AGB_DUMMY7,
mFont_CONT_CODE_AGB_DUMMY8,
mFont_CONT_CODE_AGB_DUMMY9,
mFont_CONT_CODE_AGB_DUMMY10,
mFont_CONT_CODE_PUT_STRING_ISLAND_NAME,
mFont_CONT_CODE_SET_CURSOR_JUST,
mFont_CONT_CODE_CLR_CURSOR_JUST,
mFont_CONT_CODE_CUT_ARTICLE,
mFont_CONT_CODE_CAPITAL_LETTER,
mFont_CONT_CODE_PUT_STRING_AM_PM,
mFont_CONT_CODE_SET_NEXT_MESSAGE_4,
mFont_CONT_CODE_SET_NEXT_MESSAGE_5,
mFont_CONT_CODE_SET_SELECT_STRING_5,
mFont_CONT_CODE_SET_SELECT_STRING_6,
mFont_CONT_CODE_NUM,
mFont_CONT_CODE_END = 256
};
enum {
mFont_CONT_ATTRIBUTE_0,
mFont_CONT_ATTRIBUTE_DEMO,
mFont_CONT_ATTRIBUTE_STRING,
mFont_CONT_ATTRIBUTE_3,
mFont_CONT_ATTRIBUTE_SENTENCE,
mFont_CONT_ATTRIBUTE_CHARACTER,
mFont_CONT_ATTRIBUTE_BGM,
mFont_CONT_ATTRIBUTE_SE,
mFont_CONT_ATTRIBUTE_AGB_DUMMY,
mFont_CONT_ATTRIBUTE_END
};
enum {
mFont_LineType_Top,
mFont_LineType_Center,
mFont_LineType_Bottom,
mFont_LineType_End
};
enum {
mFont_BGM_QUIET,
mFont_BGM_NUM = 9
};
enum {
mFont_BGM_STOP_TYPE_NORMAL,
mFont_BGM_STOP_TYPE_QUICK,
mFont_BGM_STOP_TYPE_RESETTI,
mFont_BGM_STOP_TYPE_NUM
};
enum {
mFont_SE_0,
mFont_SE_NUM = 7
};
typedef struct font_char_s {
u8* char_p;
s8 len;
u8 flags;
u8 pad0[2];
xy_t position;
xy_t scale;
xy_t inv_scale;
xy_t scaled_size;
xy_t inv_scaled_size;
f32 ofs_y;
rgba_t color;
u8 color_ctr;
u8 pad1[3];
f32 width;
} mFontChar;
typedef struct font_sentence_s {
u8* sentence_p;
int len;
u32 flags;
xy_t position;
int line_type;
rgba_t color;
xy_t scale;
xy_t inv_scale;
int now_idx;
f32 offset;
f32 width;
f32 line_scale;
f32 inv_line_scale;
int se_pos;
s16 se_character_id;
u8 voice_idx;
u8 voice2_idx;
u8 voice3_idx;
u8 pad[3];
mFontChar character;
} mFontSentence;
typedef void (*mFont_ControlCodeCharFunc)(mFontChar*, Gfx**);
typedef void (*mFont_ControlCodeSentenceFunc)(mFontSentence*, Gfx**);
extern void mFont_ct();
extern int mFont_UnintToString(u8* str, int figure, u32 num, int figure_start, int left_cut, int fill_zero, int separator);
extern int mFont_char_save_data_check(u8 c);
extern u8 mFont_small_to_capital(u8 small);
extern int mFont_GetCodeWidth(u8 c, int cut);
extern int mFont_GetStringWidth(u8* str, int len, int cut);
extern int mFont_GetStringWidth2(u8* str, int len, int cut);
extern int mFont_CodeSize_get(u8* str);
extern int mFont_CodeSize_idx_get(u8* str, int idx);
extern int mFont_cont_attr_get(int cont_code);
extern void mFont_gppSetMode(Gfx** gfx_pp);
extern void mFont_SetMode(GRAPH* graph, int mode);
extern void mFont_SetPrimColor(GRAPH* graph, int r, int g, int b, int a, int mode);
extern void mFont_SetCombineMode(GRAPH* graph, int revert_flag, int mode);
extern f32 mFont_SetVertexRectangle(GAME* game, f32 x, f32 y, int s, int t, f32 scale_x, f32 scale_y, int mode);
extern f32 mFont_SetLineStrings_AndSpace(GAME* game, u8* str, int len, f32 x, f32 y, int r, int g, int b, int a, int flag_revert, int flag_cut, int unused, f32 scale_x, f32 scale_y, int mode);
extern f32 mFont_SetLineStrings(GAME* game, u8* str, int len, f32 x, f32 y, int r, int g, int b, int a, int flag_revert, int flag_cut, f32 scale_x, f32 scale_y, int mode);
extern void mFont_CulcOrthoMatrix(Mtx* m);
extern void mFont_SetMatrix(GRAPH* graph, int mode);
extern void mFont_UnSetMatrix(GRAPH* graph, int mode);
extern void mFont_Main_start(GRAPH* graph);
extern void mFontSentence_set(mFontSentence* this, u8* sentence_p, int len, u32 flags, xy_t* pos, int line_type, xy_t* scale, rgba_t* color, int se_voice_pos, u8 voice_idx, u8 voice2_idx, u8 voice3_idx, s16 voice_se_character_idx);
extern void mFontSentence_gppDraw(mFontSentence* this, GAME* game, Gfx** gfx_pp);
extern f32 mFont_SetMarkChar(GAME* game, u8 mark_type, f32 x, f32 y, int r, int g, int b, int a, int revert_flag, f32 scale_x, f32 scale_y, int mode);
extern void mFont_gppSetRectMode(Gfx** gfx_pp);
typedef void* (*PrintCallback)(void*, const char*, int);
typedef struct gfxprint_obj {
PrintCallback prout_func;
Gfx* glistp;
u16 position_x;
u16 position_y;
u16 offset_x;
u8 offset_y;
u8 flags;
rgba8888 color;
u8 dummy[28];
} gfxprint_t;
extern u8 __gfxprint_default_flags;
extern u16 gfxprint_moji_tlut[];
extern u8 gfxprint_font[];
static void gfxprint_setup(gfxprint_t* this);
static void gfxprint_putc1(gfxprint_t* this, char c);
static void* gfxprint_prout(void* this, const char* buffer, int n);
extern void gfxprint_color(gfxprint_t* this, u32 r, u32 g, u32 b, u32 a);
extern void gfxprint_locate(gfxprint_t* this, int x, int y);
extern void gfxprint_locate8x8(gfxprint_t* this, int x, int y);
extern void gfxprint_setoffset(gfxprint_t* this, int x, int y);
extern void gfxprint_putc(gfxprint_t* this, char c);
extern void gfxprint_write(gfxprint_t* this, const void* buffer, size_t size, size_t n);
extern void gfxprint_puts(gfxprint_t* this, char* string);
extern void gfxprint_init(gfxprint_t* this);
extern void gfxprint_cleanup(gfxprint_t* this);
extern void gfxprint_open(gfxprint_t* this, Gfx* glistp);
extern Gfx* gfxprint_close(gfxprint_t* this);
extern int gfxprint_vprintf(gfxprint_t* this, const char* fmt, va_list ap);
extern int gfxprint_printf(gfxprint_t* this, const char* fmt, ...);
typedef struct choice_s mChoice_c;
typedef struct choice_data_s mChoice_Data_c;
enum choice {
mChoice_CHOICE0,
mChoice_CHOICE1,
mChoice_CHOICE2,
mChoice_CHOICE3,
mChoice_CHOICE4,
mChoice_CHOICE5,
mChoice_CHOICE_NUM
};
enum {
mChoice_AUTOMOVE_STOPPED,
mChoice_AUTOMOVE_INCREMENT_WAIT,
mChoice_AUTOMOVE_INCREMENT,
mChoice_AUTOMOVE_DECREMENT_WAIT,
mChoice_AUTOMOVE_DECREMENT,
mChoice_AUTOMOVE_NUM
};
enum {
mChoice_MAIN_HIDE,
mChoice_MAIN_APPEAR,
mChoice_MAIN_NORMAL,
mChoice_MAIN_DISAPPEAR,
mChoice_MAIN_INDEX_NUM
};
struct choice_data_s {
u8 strings[mChoice_CHOICE_NUM][16 ];
int string_lens[mChoice_CHOICE_NUM];
u8 determination_string[16 ];
int determination_len;
int choice_num;
int selected_choice_idx;
};
struct choice_s {
f32 center_x;
f32 center_y;
f32 center_x_begin;
f32 center_y_begin;
f32 center_x_target;
f32 center_y_target;
rgba_t text_color;
f32 text_scale_x;
f32 text_scale_y;
f32 text_x;
f32 text_y;
f32 scale_x;
f32 scale_y;
mChoice_Data_c data;
int selected_choice_idx;
rgba_t selected_choice_text_color;
rgba_t background_color;
f32 _D4;
f32 _D8;
f32 scale;
int main_index;
int requested_main_index;
int window_visible_flag;
int font_visible_flag;
int choice_automove_type;
f32 choice_automove_timer;
f32 timer;
u8 no_b_flag;
u8 no_close_flag;
};
extern void mChoice_Main(mChoice_c* choice, GAME* game);
extern void mChoice_Draw(mChoice_c* choice, GAME* game, int mode);
extern void mChoice_aram_init();
extern void mChoice_ct(mChoice_c* choice, GAME* game);
extern void mChoice_dt(mChoice_c* choice, GAME* game);
extern mChoice_c* mChoice_Get_base_window_p();
extern void mChoice_Change_request_main_index(mChoice_c* choice, int request_main_index);
extern int mChoice_check_main_index(mChoice_c* choice);
extern int mChoice_check_main_normal(mChoice_c* choice);
extern void mChoice_Set_choice_data(mChoice_c* choice, u8* str0, int str0_len, u8* str1, int str1_len, u8* str2,
int str2_len, u8* str3, int str3_len, u8* str4, int str4_len, u8* str5,
int str5_len);
extern int mChoice_Get_ChoseNum(mChoice_c* choice);
extern void mChoice_Clear_ChoseNum(mChoice_c* choice);
extern void mChoice_Load_ChoseStringFromRom(mChoice_c* choice, u8* str, int str_no, ACTOR* actor);
extern void mChoice_no_b_set(mChoice_c* choice);
extern void mChoice_no_b_close_set(mChoice_c* choice);
extern u8 itemName_paper[];
extern u8 itemName_money[];
extern u8 itemName_tool[];
extern u8 itemName_fish[];
extern u8 itemName_cloth[];
extern u8 itemName_etc[];
extern u8 itemName_carpet[];
extern u8 itemName_wall[];
extern u8 itemName_fruit[];
extern u8 itemName_plant[];
extern u8 itemName_minidisk[];
extern u8 itemName_dummy[];
extern u8 itemName_ticket[];
extern u8 itemName_insect[];
extern u8 itemName_hukubukuro[];
extern u8 itemName_kabu[];
extern u8 ftrName_table[];
extern u8 ftrName2_table[];
enum item_article {
mIN_ARTICLE_NONE,
mIN_ARTICLE_A,
mIN_ARTICLE_AN,
mIN_ARTICLE_THE,
mIN_ARTICLE_SOME,
mIN_ARTICLE_NUM
};
extern void mIN_copy_name_str(u8* str, mActor_name_t item_no);
extern int mIN_get_item_article(mActor_name_t item_no);
enum {
ROOM_TYPE_OTHER,
ROOM_TYPE_SMALL,
ROOM_TYPE_MEDIUM,
ROOM_TYPE_LARGE,
ROOM_TYPE_NUM
};
typedef enum audio_sound_effects {
NA_SE_START,
NA_SE_CURSOL,
NA_SE_MENU_EXIT,
NA_SE_3 = 3,
NA_SE_ZOOMUP = 4,
NA_SE_ZOOMDOWN_SHORT,
NA_SE_6 = 0x6,
NA_SE_7 = 0x7,
NA_SE_8 = 0x8,
NA_SE_9 = 0x9,
NA_SE_A = 0xA,
NA_SE_PAGE_OKURI = 0xB,
NA_SE_SENTAKU_OPEN,
NA_SE_SENTAKU_KETTEI,
NA_SE_TUMBLE_GRASS,
NA_SE_TUMBLE_SOIL,
NA_SE_TUMBLE_STONE,
NA_SE_TUMBLE_WOOD,
NA_SE_TUMBLE_BUSH,
NA_SE_TUMBLE_SNOW,
NA_SE_ZOOMDOWN_LONG = 0x15,
NA_SE_LIGHT_ON,
NA_SE_LIGHT_OFF,
NA_SE_19 = 0x19,
NA_SE_24 = 0x24,
NA_SE_25 = 0x25,
NA_SE_26 = 0x26,
NA_SE_27 = 0x27,
NA_SE_2A = 0x2A,
NA_SE_2C = 0x2C,
NA_SE_2F = 0x2F,
NA_SE_MENU_PAUSE = 0x30,
NA_SE_31 = 0x31,
NA_SE_32 = 0x32,
NA_SE_33 = 0x33,
NA_SE_34 = 0x34,
NA_SE_35 = 0x35,
NA_SE_37 = 0x37,
NA_SE_DRAWER_SHUT = 0x3A,
NA_SE_3B = 0x3B,
NA_SE_ITEM_GET = 0x40,
NA_SE_MOLE_CRICKET_HIDE = 0x44,
NA_SE_MOLE_CRICKET_OUT = 0x45,
NA_SE_NOTE_G_LOW = ((0x42) | 0x1000) ,
NA_SE_NOTE_A_LOW = ((0x43) | 0x1000) ,
NA_SE_NOTE_B_LOW = ((0x44) | 0x1000) ,
NA_SE_NOTE_C_LOW = ((0x45) | 0x1000) ,
NA_SE_NOTE_D_LOW = ((0x46) | 0x1000) ,
NA_SE_NOTE_E_LOW = ((0x47) | 0x1000) ,
NA_SE_NOTE_F_LOW = ((0x48) | 0x1000) ,
NA_SE_NOTE_G = ((0x49) | 0x1000) ,
NA_SE_NOTE_A = ((0x4A) | 0x1000) ,
NA_SE_NOTE_B = ((0x4B) | 0x1000) ,
NA_SE_NOTE_C = ((0x4C) | 0x1000) ,
NA_SE_NOTE_D = ((0x4D) | 0x1000) ,
NA_SE_NOTE_E = ((0x4E) | 0x1000) ,
NA_SE_NOTE_RANDOM = ((0x4F) | 0x1000) ,
NA_SE_47 = 0x47,
NA_SE_COIN = 0x4C,
NA_SE_TEMOCHI_KAZAGURUMA,
NA_SE_REGISTER = 0x50,
NA_SE_51 = 0x51,
NA_SE_52 = 0x52,
NA_SE_53 = 0x53,
NA_SE_KOKORO_TOGURU = 0x54,
NA_SE_ITEM_HORIDASHI = 0x57,
NA_SE_CLEAN_UP_FTR = 0x58,
NA_SE_TOOL_FURI = 0x5A,
NA_SE_GOKI_DEAD = 0x5B,
NA_SE_AMI_HIT = 0x5C,
NA_SE_TOOL_GET,
NA_SE_5E = 0x5E,
NA_SE_5F = 0x5F,
NA_SE_60 = 0x60,
NA_SE_61 = 0x61,
NA_SE_63 = 0x63,
NA_SE_64 = 0x64,
NA_SE_65 = 0x65,
NA_SE_66 = 0x66,
NA_SE_67 = 0x67,
NA_SE_68 = 0x68,
NA_SE_GASAGOSO = 0x69,
NA_SE_6A = 0x6A,
NA_SE_6E = 0x6E,
NA_SE_6F = 0x6F,
NA_SE_70 = 0x70,
NA_SE_71 = 0x71,
NA_SE_TOILE_CHAIR_STANDUP = 0x72,
NA_SE_TOOL_BROKEN1 = 0x74,
NA_SE_TOOL_BROKEN2,
NA_SE_TOOL_BROKEN3,
NA_SE_78 = 0x78,
NA_SE_STONECOIN_ROLL = 0x7D,
NA_SE_STONECOIN_DRAG = 0x7E,
NA_SE_7F = 0x7F,
NA_SE_TRAIN_RIDE = 0x8D,
NA_SE_SEMI0_CRY = 0x97,
NA_SE_SEMI1_CRY = 0x98,
NA_SE_SEMI2_CRY = 0x9A,
NA_SE_SEMI3_CRY = 0x9B,
NA_SE_GOKI_MOVE = 0xA8,
NA_SE_B0 = 0xB0,
NA_SE_KA_BUZZ = 0xCF,
NA_SE_104 = 0x104,
NA_SE_106 = 0x106,
NA_SE_107 = 0x107,
NA_SE_108 = 0x108,
NA_SE_ROD_STROKE = 0x109,
NA_SE_ROD_BACK,
NA_SE_10B,
NA_SE_10C,
NA_SE_HANABI0 = ((0x10F) | 0x2000) ,
NA_SE_HANABI1 = ((0x110) | 0x2000) ,
NA_SE_HANABI2 = ((0x111) | 0x2000) ,
NA_SE_HANABI3 = ((0x112) | 0x2000) ,
NA_SE_EAT = 0x113,
NA_SE_114 = 0x114,
NA_SE_SEMI_ESCAPE = 0x115,
NA_SE_116 = 0x116,
NA_SE_11A = 0x11A,
NA_SE_11B = 0x11B,
NA_SE_WEAR = 0x11C,
NA_SE_SCOOP1 = 0x11E,
NA_SE_SCOOP_UMERU = 0x120,
NA_SE_SCOOP_HIT,
NA_SE_122 = 0x122,
NA_SE_123 = 0x123,
NA_SE_124 = 0x124,
NA_SE_125 = 0x125,
NA_SE_126 = 0x126,
NA_SE_12D = 0x12D,
NA_SE_GOKI_JUMP_AWAY = 0x132,
NA_SE_TREE_TOUCH = 0x134,
NA_SE_TREE_YURASU,
NA_SE_KAZE = 0x13A,
NA_SE_PUN_YUGE = 0x13B,
NA_SE_DOYON = 0x13F,
NA_SE_KIRIBASU_SCOOP = 0x148,
NA_SE_KIRIBASU_OUT,
NA_SE_SOUND_KNOCK,
NA_SE_TUMBLE_SAND = 0x156,
NA_SE_TUMBLE_WAVE,
NA_SE_ARAIIKI_BOY = 0x158,
NA_SE_ARAIIKI_OTHER = 0x159,
NA_SE_ARAIIKI_GIRL = 0x15A,
NA_SE_AMI_HIT_WATER = 0x15C,
NA_SE_15D = 0x15D,
NA_SE_15E = 0x15E,
NA_SE_ZASSOU_NUKU = 0x15F,
NA_SE_HACHI_SASARERU,
NA_SE_166 = 0x166,
NA_SE_UCHIWA = 0x167,
NA_SE_16A = 0x16A,
NA_SE_16E = 0x16E,
NA_SE_16F = 0x16F,
NA_SE_LAWNMOWER = 0x177,
NA_SE_17C = 0x17C,
NA_SE_17D = 0x17D,
NA_SE_207 = 0x207,
NA_SE_SCOOP_SHIGEMI = 0x401,
NA_SE_40B = 0x40B,
NA_SE_CAMERA_MOVE1 = 0x40D,
NA_SE_CAMERA_MOVE2,
NA_SE_TOILE_CHAIR_SIT = 0x410,
NA_SE_TRAINDOOR0 = 0x412,
NA_SE_TRAINDOOR1,
NA_SE_BED_IN = 0x415,
NA_SE_BED_NEGAERI,
NA_SE_BED_OUT,
NA_SE_ROTATE = 0x41A,
NA_SE_41C = 0x41C,
NA_SE_AXE_HIT,
NA_SE_AXE_CUT,
NA_SE_SOFT_CHAIR_SIT,
NA_SE_HARD_CHAIR_SIT,
NA_SE_BUBU_CHAIR_SIT,
NA_SE_SOFT_CHAIR_STANDUP,
NA_SE_HARD_CHAIR_STANDUP,
NA_SE_424 = 0x424,
NA_SE_426 = 0x426,
NA_SE_BUBU_CHAIR_STANDUP = 0x429,
NA_SE_JUMP,
NA_SE_LANDING,
NA_SE_FTR_DOOR_OPEN = 0x42C,
NA_SE_FTR_DOOR_CLOSE = 0x42D,
NA_SE_DRAWER_OPEN = 0x42E,
NA_SE_DRAWER_CLOSE = 0x42F,
NA_SE_DAI_UE_KAKUNOU = 0x430,
NA_SE_UMBRELLA_ROTATE = 0x432,
NA_SE_435 = 0x435,
NA_SE_436 = 0x436,
NA_SE_437 = 0x437,
NA_SE_438 = 0x438,
NA_SE_KARABURI = 0x43A,
NA_SE_43B = 0x43B,
NA_SE_43D = 0x43D,
NA_SE_43E = 0x43E,
NA_SE_43F = 0x43F,
NA_SE_ROD_STROKE_SMALL = 0x445,
NA_SE_446 = 0x446,
NA_SE_SCOOP_TREE_HIT = 0x448,
NA_SE_SCOOP_ITEM_HIT,
NA_SE_AXE_BALL_HIT,
NA_SE_44B = 0x44B,
NA_SE_44C = 0x44C,
NA_SE_45E = 0x45E,
NA_SE_45F = 0x45F,
NA_SE_461 = 0x461,
NA_SE_COIN_GASAGOSO = 0x465,
NA_SE_501 = 0x501,
NA_SE_505 = 0x505,
NA_SE_509 = 0x509,
NA_SE_50D = 0x50D,
NA_SE_511 = 0x511,
NA_SE_515 = 0x515,
NA_SE_519 = 0x519,
NA_SE_51D = 0x51D,
NA_SE_521 = 0x521,
NA_SE_525 = 0x525,
NA_SE_529 = 0x529,
NA_SE_531 = 0x531,
NA_SE_539 = 0x539,
NA_SE_53D = 0x53D,
NA_SE_BEBE = ((0x6D) | 0x1000) ,
NA_SE_4028 = ((0x28) | 0x4000) ,
NA_SE_FOOTSTEP_BEGIN = ((0x200) | 0x4000) ,
NA_SE_FOOTSTEP_GRASS,
NA_SE_FOOTSTEP_SOIL,
NA_SE_FOOTSTEP_STONE,
NA_SE_FOOTSTEP_WOOD,
NA_SE_FOOTSTEP_BUSH,
NA_SE_FOOTSTEP_SNOW,
NA_SE_FOOTSTEP_7,
NA_SE_FOOTSTEP_SAND,
NA_SE_FOOTSTEP_WAVE,
NA_SE_FOOTSTEP_PLUSSBRIDGE,
NA_SE_FLOOR_SE_START = ((0x2E6) | 0x4000) ,
} AudioSE;
typedef enum bgm_e {
BGM_SILENCE,
BGM_FIELD_00,
BGM_FIELD_01,
BGM_FIELD_02,
BGM_FIELD_03,
BGM_FIELD_04,
BGM_FIELD_05,
BGM_FIELD_06,
BGM_FIELD_07,
BGM_FIELD_08,
BGM_FIELD_09,
BGM_FIELD_10,
BGM_FIELD_11,
BGM_FIELD_12,
BGM_FIELD_13,
BGM_FIELD_14,
BGM_FIELD_15,
BGM_FIELD_16,
BGM_FIELD_17,
BGM_FIELD_18,
BGM_FIELD_19,
BGM_FIELD_20,
BGM_FIELD_21,
BGM_FIELD_22,
BGM_FIELD_23,
BGM_BROKERS_SHOP,
BGM_FORTUNE_TELLER,
BGM_SPORTSFAIR_AEROBICS,
BGM_SPORTSFAIR_FOOTRACE,
BGM_SPORTSFAIR_BALLTOSS,
BGM_HARVEST_MOON,
BGM_NEW_YEARS_1HR,
BGM_NEW_YEARS_30MIN,
BGM_NEW_YEARS_10MIN,
BGM_NEW_YEARS_5MIN,
BGM_NEW_YEARS_NOW,
BGM_NEW_YEARS_DAY,
BGM_SHOP1,
BGM_SHOP2,
BGM_SHOP3,
BGM_DIG_ITEM,
BGM_POST_OFFICE0,
BGM_INTRO_TRAIN,
BGM_INTRO_KK,
BGM_SHOP0,
BGM_POLICE_BOX,
BGM_SAVE,
BGM_INTRO_ARRIVE,
BGM_INTRO_RCN_GUIDE,
BGM_INTRO_SELECT_HOUSE,
BGM_INTRO_SELECT_HOUSE2,
BGM_INTRO_FIND_SHOP,
BGM_INTRO_CHORES,
BGM_HALLOWEEN,
BGM_XMAS_EVE,
BGM_FIREWORKS_FESTIVAL,
BGM_CHERRY_BLOSSOM_FESTIVAL,
BGM_NEW_YEARS_PARTY,
BGM_KK_HAZURE0,
BGM_NEW_YEARS_WISH,
BGM_SPORTSFAIR_TUGOFWAR,
BGM_NEW_YEARS_MORNING,
BGM_POST_OFFICE1,
BGM_TRAIN_PULL_INTO_TOWN,
BGM_TRAIN_BOARD,
BGM_ENTER_HOUSE,
BGM_RESET,
BGM_BEE_CHASE,
BGM_BEE_STUNG,
BGM_RAIN,
BGM_TITLE,
BGM_TRAIN_ARRIVAL_WAIT,
BGM_INTRO_NEW_TOWN,
BGM_INTRO_CHORES_COMPLETE,
BGM_DEBT_PAID,
BGM_ALL_INSECTS,
BGM_ALL_FISH,
BGM_KAMAKURA,
BGM_RESET2,
BGM_SHOP0_LATE,
BGM_SHOP1_LATE,
BGM_SHOP2_LATE,
BGM_SHOP3_LATE,
BGM_NINTENDO0,
BGM_NINTENDO1,
BGM_NINTENDO2,
BGM_NINTENDO3,
BGM_NINTENDO4,
BGM_MUSEUM,
BGM_TAILORS,
BGM_90,
BGM_ISLAND,
BGM_KAPPA_SONG0,
BGM_KAPPA_SONG1,
BGM_KAPPA_SONG2,
BGM_KAPPA_SONG3,
BGM_KAPPA_SONG4,
BGM_KAPPA_SONG5,
BGM_KAPPA_SONG6,
BGM_KAPPA_SONG7,
BGM_KAPPA_SONG8,
BGM_KAPPA_SONG9,
BGM_KAPPA_SONG10,
BGM_KAPPA_SONG11,
BGM_KAPPA_SONG12,
BGM_KAPPA_SONG13,
BGM_KAPPA_SONG14,
BGM_KAPPA_SONG15,
BGM_108,
BGM_109,
BGM_110,
BGM_111,
BGM_112,
BGM_113,
BGM_114,
BGM_115,
BGM_116,
BGM_117,
BGM_118,
BGM_119,
BGM_120,
BGM_121,
BGM_122,
BGM_123,
BGM_124,
BGM_125,
BGM_126,
BGM_127,
BGM_MD0,
BGM_MD1,
BGM_MD2,
BGM_MD3,
BGM_MD4,
BGM_MD5,
BGM_MD6,
BGM_MD7,
BGM_MD8,
BGM_MD9,
BGM_MD10,
BGM_MD11,
BGM_MD12,
BGM_MD13,
BGM_MD14,
BGM_MD15,
BGM_MD16,
BGM_MD17,
BGM_MD18,
BGM_MD19,
BGM_MD20,
BGM_MD21,
BGM_MD22,
BGM_MD23,
BGM_MD24,
BGM_MD25,
BGM_MD26,
BGM_MD27,
BGM_MD28,
BGM_MD29,
BGM_MD30,
BGM_MD31,
BGM_MD32,
BGM_MD33,
BGM_MD34,
BGM_MD35,
BGM_MD36,
BGM_MD37,
BGM_MD38,
BGM_MD39,
BGM_MD40,
BGM_MD41,
BGM_MD42,
BGM_MD43,
BGM_MD44,
BGM_MD45,
BGM_MD46,
BGM_MD47,
BGM_MD48,
BGM_MD49,
BGM_MD50,
BGM_MD51,
BGM_MD52,
BGM_MD53,
BGM_MD54,
BGM_TOTAKEKE_LIVE0 = 192,
} BGM_e;
typedef struct audio_tempo_beat_s {
u8 tempo;
s8 beat;
} TempoBeat_c;
typedef struct audio_staffroll_info_s {
s16 staffroll_part;
s16 _01;
f64 percent;
s8 mouth_num;
s8 blink_flag;
s8 beat;
} StaffRollInfo_c;
typedef struct radio_s {
s8 measure;
f32 measure_progress;
u16 tempo;
} Radio_c;
enum {
STAFFROLL_PART_START,
STAFFROLL_PART_INTRO,
STAFFROLL_PART_MAIN,
STAFFROLL_PART_FADEOUT,
STAFFROLL_PART_FINISH,
STAFFROLL_PART_NUM
};
enum {
VOICE_STATUS_NORMAL,
VOICE_STATUS_ANGRY,
VOICE_STATUS_SAD,
VOICE_STATUS_FUN,
VOICE_STATUS_SLEEPY,
VOICE_STATUS_GLOOMY,
VOICE_STATUS_NUM
};
extern void sAdo_Calc_MicPosition_forTrig(f32* fcalc, u16* scalc, const xyz_t* pos);
extern void sAdo_Calc_MicPosition_forLevel(f32* fcalc, u16* scalc, const xyz_t* pos);
extern void sAdo_GameFrame();
extern void sAdo_BgmStart(u8 id);
extern void sAdo_BgmStop(u16 id);
extern void sAdo_SysTrgStart(u16 id);
extern void sAdo_PlyWalkSe(u16 walk, const xyz_t* pos);
extern void sAdo_PlyWalkSeRoom(u8 walk, const xyz_t* pos);
extern void sAdo_NpcWalkSe(u16 se_no, const xyz_t* pos);
extern void sAdo_NpcWalkSeRoom(u8 se_no, const xyz_t* pos);
extern void sAdo_PlayerStatusLevel(u8 dash, f32 speed);
extern void sAdo_VoiceSe(u8 num, u8 num2, u8 num3, s16 character_idx, u8 scale, u8 mode);
extern void sAdo_Inst(u16 num, u8* p);
extern void sAdo_MessageStatus(u8 status);
extern void sAdo_MessageSpeed(u8 speed);
extern u8 sAdo_MessageSpeedGet();
extern void sAdo_SysLevStop(u8 id);
extern void sAdo_SysLevStart(u8 id);
extern void sAdo_OngenPos(u32 p1, u8 p2, const xyz_t* pos);
extern void sAdo_OngenTrgStart(u16 id, const xyz_t* pos);
extern void sAdo_SetOutMode(u8 mode);
extern void sAdo_SetVoiceMode(u8 mode);
extern void sAdo_FloorTrgStart(u8 id, const xyz_t* pos);
extern void sAdo_RhythmStart(u32 id, s8 type, s8 wait);
extern void sAdo_RhythmStop(u32 id);
extern void sAdo_RhythmAllStop();
extern void sAdo_FurnitureInst(u32 id, u8 inst, u8* melody, const xyz_t* pos);
extern void sAdo_Pause(u8 mode);
extern f32 sAdo_GetRhythmAnimCounter(u32 id);
extern s8 sAdo_GetRhythmDelay(u32 id);
extern void sAdo_GetRhythmInfo(TempoBeat_c* rhythm);
extern void sAdo_SetRhythmInfo(TempoBeat_c* rhythm);
extern s8 sAdo_InstCountGet();
extern void sAdo_RhythmPos(u32 id, u8 haniwa_id, const xyz_t* pos);
extern void sAdo_SpecChange(int spec);
extern void sAdo_MDPlayerPos(const xyz_t* pos, u16 s1, u16 s2, u32 p);
extern void sAdo_BGMVolume(f32 f, u16 volume);
extern void sAdo_BgmCrossfadeStart(u8 b);
extern void sAdo_SubGameStart();
extern void sAdo_SubGameEnd();
extern int sAdo_SubGameOK();
extern void sAdo_Tenki(u8 mode);
extern void sAdos_KishaStatusTrg(u8 state);
extern void sAdos_KishaStatusLevel(f32 speed, u32 ongenNum1, f32 distance1, u16 angle1, u32 ongenNum2,
f32 distance2, u16 angle2);
extern int sAdos_GetRadioCounter(Radio_c* radio);
extern void sAdos_GetKappaCounter(void* p);
extern void sAdos_GetStaffRollInfo(StaffRollInfo_c* info);
extern void sAdos_TTKK_ARM(u8 mode);
extern void sAdo_OngenTrgStartSpeed(f32 speed, u16 s1, const xyz_t* pos);
extern void sAdo_TrgSeEcho(u8 b);
extern void sAdo_LevSeEcho(u8 b);
extern u8 sAdo_BgmFadeoutCheck();
extern u8 sAdo_SeFadeoutCheck();
extern void sAdo_RoomType(u8 type);
extern void sAdo_Museum(u8 type);
extern void sAdo_SoftReset();
extern u16 sAdo_Get_WalkLabel(int type);
extern u16 sAdo_Get_KokeruLabel(int type);
extern void sAdo_SceneMode(u8 mode);
extern u8 sAdo_RoomIncectPos(u32 f, u8 u, const xyz_t* pos);
extern void sAdo_FurnitureInstPos(u32 id, const xyz_t* pos);
extern void sAdo_Set_ongenpos_refuse_fg(int state);
extern int sAdo_GameframeEnd_Check();
extern u32 sAdo_GetSoundFrameCounter();
extern int sAdo_CheckOnPlussBridge(const xyz_t* pos, u32 atr);
extern void sAdo_RegistPlussBridge(const xyz_t* pos);
extern void sAdo_DeletePlussBridge();
extern void sAdo_kazagurumaLevel(f32 level);
enum {
mMsg_INDEX_HIDE,
mMsg_INDEX_APPEAR,
mMsg_INDEX_NORMAL,
mMsg_INDEX_CURSOL,
mMsg_INDEX_DISAPPEAR,
mMsg_INDEX_APPEAR_WAIT,
mMsg_INDEX_WAIT,
mMsg_INDEX_DISAPPEAR_WAIT,
mMsg_INDEX_NUM
};
enum {
mMsg_FREE_STR0,
mMsg_FREE_STR1,
mMsg_FREE_STR2,
mMsg_FREE_STR3,
mMsg_FREE_STR4,
mMsg_FREE_STR5,
mMsg_FREE_STR6,
mMsg_FREE_STR7,
mMsg_FREE_STR8,
mMsg_FREE_STR9,
mMsg_FREE_STR10,
mMsg_FREE_STR11,
mMsg_FREE_STR12,
mMsg_FREE_STR13,
mMsg_FREE_STR14,
mMsg_FREE_STR15,
mMsg_FREE_STR16,
mMsg_FREE_STR17,
mMsg_FREE_STR18,
mMsg_FREE_STR19,
mMsg_FREE_STR_NUM
};
enum {
mMsg_ITEM_STR0,
mMsg_ITEM_STR1,
mMsg_ITEM_STR2,
mMsg_ITEM_STR3,
mMsg_ITEM_STR4,
mMsg_ITEM_STR_NUM
};
enum {
mMsg_MAIL_STR0,
mMsg_MAIL_STR_NUM
};
enum {
mMsg_RESULT_VOID,
mMsg_RESULT_FALSE,
mMsg_RESULT_TRUE,
mMsg_RESULT_NUM
};
typedef struct message_window_s mMsg_Window_c;
typedef struct message_data_s mMsg_Data_c;
typedef struct {
int saved_main_index;
} mMsg_MainAppearWait_Data_c;
typedef struct {
int saved_main_index;
} mMsg_MainDisappearWait_Data_c;
typedef struct {
int last_main_index;
} mMsg_MainWait_Data_c;
typedef union {
mMsg_MainAppearWait_Data_c main_appear_wait;
mMsg_MainDisappearWait_Data_c main_disappear_wait;
mMsg_MainWait_Data_c main_wait;
u64 align;
} mMsg_Main_Data_c;
typedef struct {
ACTOR* speaker_actor;
int msg_no;
int name_shown_flag;
rgba_t window_color;
} mMsg_Request_MainAppear_Data_c;
typedef struct {
int last_main_index;
u32 setup_flag;
} mMsg_Request_MainAppearWait_Data_c;
typedef struct {
int wait_flag;
} mMsg_Request_MainCursor_Data_c;
typedef struct {
int last_main_index;
} mMsg_Request_MainDisappearWait_Data_c;
typedef struct {
int wait_flag;
} mMsg_Request_MainNormal_Data_c;
typedef struct {
int last_main_index;
} mMsg_Request_MainWait_Data_c;
typedef union {
mMsg_Request_MainAppear_Data_c request_main_appear;
mMsg_Request_MainAppearWait_Data_c request_main_appear_wait;
mMsg_Request_MainCursor_Data_c request_main_cursor;
mMsg_Request_MainDisappearWait_Data_c request_main_disappear_wait;
mMsg_Request_MainNormal_Data_c request_main_normal;
mMsg_Request_MainWait_Data_c request_main_wait;
u64 align;
} mMsg_Request_Data_c;
typedef union {
u8 data[1600 ] __attribute__((aligned(32))) ;
u64 align;
} mMsg_MsgBuf_c;
struct message_data_s {
int data_loaded;
int msg_no;
int msg_len;
int cut;
mMsg_MsgBuf_c text_buf;
};
struct message_window_s {
int data_loaded;
int msg_no;
int _008;
mMsg_Data_c* msg_data;
f32 center_x;
f32 center_y;
f32 width;
f32 height;
ACTOR* client_actor_p;
int show_actor_name;
int client_name_len;
f32 nameplate_x;
f32 nameplate_y;
int show_continue_button;
u8 free_str[mMsg_FREE_STR_NUM][16 ];
int free_str_article[mMsg_FREE_STR_NUM];
u8 item_str[mMsg_ITEM_STR_NUM][16 ];
int item_str_article[mMsg_ITEM_STR_NUM];
u8 mail_str[mMsg_MAIL_STR_NUM][132 ];
rgba_t name_text_color;
rgba_t name_background_color;
rgba_t window_background_color;
rgba_t font_color[4 ];
rgba_t continue_button_color;
f32 font_scale_x;
f32 font_scale_y;
int _2D8;
int _2DC;
int text_lines;
int now_display_line;
mChoice_c choice_window;
int _3E8;
u16 end_timer;
s16 animal_voice_idx;
int voice_sfx_idx;
u8 voice_idx;
u8 voice2_idx;
u8 voice3_idx;
s8 hide_choice_window_timer;
u8 force_voice_enable_flag;
int spec;
u8 free_str_color_idx[4];
u8 _404[8];
u32 status_flags;
f32 timer;
f32 cursor_timer;
f32 continue_button_timer;
int start_text_cursor_idx;
int end_text_cursor_idx;
f32 window_scale;
f32 text_scale;
int requested_main_index;
int requested_priority;
int main_index;
int draw_flag;
int cancel_flag;
int cancelable_flag;
int continue_msg_no;
int continue_cancel_flag;
int force_next;
int lock_continue;
u8 now_utter;
mMsg_Main_Data_c main_data;
mMsg_Request_Data_c request_data;
};
extern void mMsg_aram_init();
extern void mMsg_aram_init2();
extern void mMsg_ct(GAME* game);
extern void mMsg_dt(GAME* game);
extern void mMsg_debug_draw(gfxprint_t* gfxprint);
extern void mMsg_Main(GAME* game);
extern void mMsg_Draw(GAME* game);
extern mMsg_Window_c* mMsg_Get_base_window_p();
extern int mMsg_Check_request_priority(mMsg_Window_c* msg_p, int request_priority);
extern int mMsg_Check_main_index(mMsg_Window_c* msg_p, int main_index);
extern int mMsg_Check_main_wait(mMsg_Window_c* msg_p);
extern int mMsg_Check_not_series_main_wait(mMsg_Window_c* msg_p);
extern int mMsg_Check_main_hide(mMsg_Window_c* msg_p);
extern int mMsg_request_main_forceoff();
extern int mMsg_request_main_disappear(mMsg_Window_c* msg_p);
extern int mMsg_request_main_appear(mMsg_Window_c* msg_p, ACTOR* client_actor_p, int show_name, rgba_t* window_color,
int msg_no, int request_priority);
extern int mMsg_request_main_disappear_wait_type1(mMsg_Window_c* msg_p);
extern int mMsg_request_main_disappear_wait_type2(mMsg_Window_c* msg_p);
extern int mMsg_request_main_appear_wait_type2(mMsg_Window_c* msg_p, int clear_flag);
extern int mMsg_request_main_appear_wait_type1(mMsg_Window_c* msg_p);
extern void mMsg_Set_free_str(mMsg_Window_c* msg_p, int free_str_no, u8* str, int str_len);
extern void mMsg_Set_free_str_cl(mMsg_Window_c* msg_p, int str_no, u8* str_p, int str_len, int cl_id);
extern void mMsg_Set_free_str_art(mMsg_Window_c* msg_p, int str_no, u8* str_p, int str_len, int article);
extern void mMsg_Set_free_str_cl_art(mMsg_Window_c* msg_p, int str_no, u8* str_p, int str_len, int cl_id, int article);
extern void mMsg_Set_item_str(mMsg_Window_c* msg_p, int item_str_no, u8* str, int str_len);
extern void mMsg_Set_item_str_art(mMsg_Window_c* msg_p, int item_str_no, u8* str, int str_len, int article);
extern void mMsg_Set_mail_str(mMsg_Window_c* msg_p, int mail_str_no, u8* str, int str_len);
extern void mMsg_Set_continue_msg_num(mMsg_Window_c* msg_p, int msg_no);
extern int mMsg_Get_msg_num(mMsg_Window_c* msg_p);
extern void mMsg_Get_BodyParam(u32 table_addr, u32 data_addr, int index, u32* addr, u32* size);
extern int mMsg_ChangeMsgData(mMsg_Window_c* msg_p, int index);
extern int mMsg_Check_NowUtter();
extern int mMsg_Get_Length_String(u8* str, int str_len);
extern int mMsg_Check_MainNormalContinue(mMsg_Window_c* msg_p);
extern int mMsg_Check_MainNormal(mMsg_Window_c* msg_p);
extern int mMsg_Check_MainHide(mMsg_Window_c* msg_p);
extern int mMsg_Check_MainDisappear(mMsg_Window_c* msg_p);
extern void mMsg_Set_CancelNormalContinue(mMsg_Window_c* msg_p);
extern void mMsg_Unset_CancelNormalContinue(mMsg_Window_c* msg_p);
extern void mMsg_Set_ForceNext(mMsg_Window_c* msg_p);
extern void mMsg_Unset_ForceNext(mMsg_Window_c* msg_p);
extern void mMsg_Set_LockContinue(mMsg_Window_c* msg_p);
extern void mMsg_Unset_LockContinue(mMsg_Window_c* msg_p);
extern void mMsg_Set_idling_req(mMsg_Window_c* msg_p);
extern int mMsg_Check_idling_now(mMsg_Window_c* msg_p);
extern int mMsg_MoveDataCut(u8* data, int dst_idx, int src_idx, int len, int space_flag);
extern int mMsg_CopyPlayerName(u8* data, int start_idx, int len, u32 capitalize);
extern int mMsg_CopyTalkName(ACTOR* actor_p, u8* data, int start_idx, int len, u32 capitalize);
extern int mMsg_CopyTail(ACTOR* actor_p, u8* data, int start_idx, int len, u32 capitalize);
extern int mMsg_CopyYear(u8* data, int start_idx, int len);
extern int mMsg_CopyMonth(u8* data, int start_idx, int len);
extern int mMsg_CopyWeek(u8* data, int start_idx, int len);
extern int mMsg_CopyDay(u8* data, int start_idx, int len);
extern int mMsg_CopyHour(u8* data, int start_idx, int len);
extern int mMsg_CopyMin(u8* data, int start_idx, int len);
extern int mMsg_CopySec(u8* data, int start_idx, int len);
extern int mMsg_CopyFree(mMsg_Window_c* msg_p, int str_no, u8* data, int start_idx, int len, int article,
u32 capitalize);
extern int mMsg_CopyDetermination(mMsg_Window_c* msg_p, u8* data, int start_idx, int len);
extern int mMsg_CopyCountryName(u8* data, int start_idx, int len, u32 capitalize);
extern int mMsg_CopyIslandName(u8* data, int start_idx, int len, u32 capitalize);
extern int mMsg_CopyAmPm(mMsg_Window_c* msg_p, u8* data, int start_idx, int len);
extern int mMsg_CopyRamdomNumber2(u8* data, int start_idx, int len);
extern int mMsg_CopyItem(mMsg_Window_c* msg_p, int str_no, u8* data, int start_idx, int len, int article,
u32 capitalize);
extern int mMsg_CopyMail(mMsg_Window_c* msg_p, int str_no, u8* data, int start_idx, int len, u32 capitalize);
extern int mMsg_sound_voice_get(int code);
extern int mMsg_sound_voice_get_for_editor(int code);
extern void mMsg_sound_spec_change_voice_force(mMsg_Window_c* msg_p);
extern int mMsg_sound_spec_change_voice(mMsg_Window_c* msg_p);
extern void mMsg_sound_set_voice_click(mMsg_Window_c* msg_p);
extern void mMsg_sound_set_voice_silent(mMsg_Window_c* msg_p, int update_mode);
extern void mMsg_sound_unset_voice_silent(mMsg_Window_c* msg_p, int update_mode);
static int mMck_cmp_sep(u8 c);
