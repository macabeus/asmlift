
extern int signgam;
enum fdversion { fdlibm_ieee = -1, fdlibm_svid, fdlibm_xopen, fdlibm_posix };
extern enum fdversion _fdlib_version ;
struct exception {
int type;
char* name;
double arg1;
double arg2;
double retval;
};
extern double acos (double) ;
extern double asin (double) ;
extern double atan (double) ;
extern double atan2 (double, double) ;
extern double cos (double) ;
extern double sin (double) ;
extern double tan (double) ;
extern double cosh (double) ;
extern double sinh (double) ;
extern double tanh (double) ;
extern double exp (double) ;
extern double frexp (double, int*) ;
extern double ldexp (double, int) ;
extern double scalbn (double, int) ;
extern double log (double) ;
extern double log10 (double) ;
extern double modf (double, double*) ;
extern double pow (double, double) ;
extern double sqrt (double) ;
extern double ceil (double) ;
extern double fabs (double) ;
extern double fabs__Fd(double);
extern double floor (double) ;
extern double fmod (double, double) ;
extern double erf (double) ;
extern double erfc (double) ;
extern double gamma (double) ;
extern double hypot (double, double) ;
extern int isnan (double) ;
extern int finite (double) ;
extern double j0 (double) ;
extern double j1 (double) ;
extern double jn (int, double) ;
extern double lgamma (double) ;
extern double y0 (double) ;
extern double y1 (double) ;
extern double yn (int, double) ;
extern double acosh (double) ;
extern double asinh (double) ;
extern double atanh (double) ;
extern double cbrt (double) ;
extern double logb (double) ;
extern double nextafter (double, double) ;
extern double remainder (double, double) ;
extern double scalb (double, double) ;
extern int matherr (struct exception*) ;
extern double significand (double) ;
extern double copysign (double, double) ;
extern int ilogb (double) ;
extern double rint (double) ;
extern double scalbn (double, int) ;
extern double expm1 (double) ;
extern double log1p (double) ;
extern double __ieee754_sqrt (double) ;
extern double __ieee754_acos (double) ;
extern double __ieee754_acosh (double) ;
extern double __ieee754_log (double) ;
extern double __ieee754_atanh (double) ;
extern double __ieee754_asin (double) ;
extern double __ieee754_atan2 (double, double) ;
extern double __ieee754_exp (double) ;
extern double __ieee754_cosh (double) ;
extern double __ieee754_fmod (double, double) ;
extern double __ieee754_pow (double, double) ;
extern double __ieee754_lgamma_r (double, int*) ;
extern double __ieee754_gamma_r (double, int*) ;
extern double __ieee754_lgamma (double) ;
extern double __ieee754_gamma (double) ;
extern double __ieee754_log10 (double) ;
extern double __ieee754_sinh (double) ;
extern double __ieee754_hypot (double, double) ;
extern double __ieee754_j0 (double) ;
extern double __ieee754_j1 (double) ;
extern double __ieee754_y0 (double) ;
extern double __ieee754_y1 (double) ;
extern double __ieee754_jn (int, double) ;
extern double __ieee754_yn (int, double) ;
extern double __ieee754_remainder (double, double) ;
extern int __ieee754_rem_pio2 (double, double*) ;
extern double __ieee754_scalb (double, double) ;
extern double __kernel_standard (double, double, int) ;
extern double __kernel_sin (double, double, int) ;
extern double __kernel_cos (double, double) ;
extern double __kernel_tan (double, double, int) ;
extern int __kernel_rem_pio2 (double*, double*, int, int, int, const int*) ;
inline double fabs(double x) {
return __fabs(x);
}
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_max[];
extern unsigned long __float_epsilon[];
inline int __fpclassifyf(float __value)
{
unsigned long integer = *(unsigned long*)&__value;
switch (integer & 0x7f800000) {
case 0x7f800000:
if ((integer & 0x7fffff) != 0) {
return 1 ;
}
return 2 ;
case 0:
if ((integer & 0x7fffff) != 0) {
return 5 ;
}
return 3 ;
}
return 4 ;
}
inline int __fpclassifyd(double __value)
{
switch (*(int*)&__value & 0x7ff00000) {
case 0x7ff00000: {
if ((*(int*)&__value & 0x000fffff) || (*(1 + (int*)&__value) & 0xffffffff))
return 1 ;
else
return 2 ;
break;
}
case 0: {
if ((*(int*)&__value & 0x000fffff) || (*(1 + (int*)&__value) & 0xffffffff))
return 5 ;
else
return 3 ;
break;
}
}
return 4 ;
}
extern inline float sqrtf(float x) {
static const double _half = .5;
static const double _three = 3.0;
volatile float y;
if (x > 0.0f) {
double guess = __frsqrte((double)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (float)(x * guess);
return y;
}
return x;
}
inline float fabsf(float x) {
return (float)fabs((double)x);
}
extern inline double sqrt(double x) {
if (x > 0.0) {
double guess = __frsqrte(x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
return x * guess;
} else if (x == 0.0f) {
return 0.0;
} else if (x) {
return (*(float*)__float_nan) ;
}
return (*(float*)__float_huge) ;
}
typedef signed char s8;
typedef unsigned char u8;
typedef signed short int s16;
typedef unsigned short int u16;
typedef signed long s32;
typedef unsigned long u32;
typedef signed long long int s64;
typedef unsigned long long int u64;
typedef float f32;
typedef double f64;
typedef char *Ptr;
typedef unsigned int uintptr_t;
typedef int BOOL;
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, int type);
typedef unsigned long size_t;
typedef unsigned long __file_handle;
typedef unsigned long fpos_t;
typedef unsigned short wchar_t;
enum __file_kinds {
__closed_file,
__disk_file,
__console_file,
__string_file,
__unavailable_file = 3,
};
enum __file_orientation {
UNORIENTED,
CHAR_ORIENTED,
WIDE_ORIENTED,
};
typedef struct _file_modes {
unsigned int open_mode : 2;
unsigned int io_mode : 3;
unsigned int buffer_mode : 2;
unsigned int file_kind : 3;
unsigned int file_orientation : 2;
unsigned int binary_io : 1;
} file_modes;
enum __io_modes {
__read = 1,
__write = 2,
__read_write = 3,
__append = 4,
};
enum __io_states {
__neutral,
__writing,
__reading,
__rereading,
};
enum __io_results {
__no_io_error,
__io_error,
__io_EOF,
};
typedef struct _file_states {
unsigned int io_state : 3;
unsigned int free_buffer : 1;
unsigned char eof;
unsigned char error;
} file_states;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc idle_proc);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count, __idle_proc idle_proc);
typedef int (*__close_proc)(__file_handle file);
typedef struct _FILE {
__file_handle handle;
file_modes file_mode;
file_states file_state;
unsigned char char_buffer;
char char_buffer_overflow;
char ungetc_buffer[4];
wchar_t ungetc_wide_buffer[2];
unsigned long position;
unsigned char* buffer;
unsigned long buffer_size;
unsigned char* buffer_ptr;
unsigned long buffer_length;
unsigned long buffer_alignment;
unsigned long save_buffer_length;
unsigned long buffer_position;
__pos_proc position_fn;
__io_proc read_fn;
__io_proc write_fn;
__close_proc close_fn;
__idle_proc idle_fn;
void* next;
} FILE;
typedef struct _files {
FILE _stdin;
FILE _stdout;
FILE _stderr;
FILE _sentinel;
} files;
extern files __files;
int puts(const char *s);
int printf(const char *, ...);
int sprintf(char *s, const char *format, ...);
int vprintf(const char *format, va_list arg);
int vsprintf(char *s, const char *format, va_list arg);
size_t strlen(const char *s);
long strtol(const char *str, char **end, int base);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t num);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
char *strncat(char *dest, const char *src, size_t n);
char *strchr(const char *str, int c);
char* strrchr( char* str, int chr );
char* strstr(const char* str, const char* pat);
char* strcat(char* dst, const char* src);
int tolower(int c);
float powf(float x, float y);
float tanf(float);
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef unsigned int uint;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef void* unkptr;
typedef u32 unknown;
#pragma section RX "forcestrip"
typedef unsigned short wchar_t;
typedef void (*GBACallback)(s32 chan, s32 ret);
void GBAInit(void);
s32 GBAGetStatus(s32 chan, u8* status);
s32 GBAGetStatusAsync(s32 chan, u8* status, GBACallback callback);
s32 GBAReset(s32 chan, u8* status);
s32 GBAResetAsync(s32 chan, u8* status, GBACallback callback);
s32 GBAGetProcessStatus(s32 chan, u8* percentp);
s32 GBARead(s32 chan, u8* dst, u8* status);
s32 GBAReadAsync(s32 chan, u8* dst, u8* status, GBACallback callback);
s32 GBAWrite(s32 chan, u8* src, u8* status);
s32 GBAWriteAsync(s32 chan, u8* src, u8* status, GBACallback callback);
s32 GBAJoyBoot(s32 chan, s32 palette_color, s32 palette_speed, u8* programp, s32 length,
u8* status);
s32 GBAJoyBootAsync(s32 chan, s32 palette_color, s32 palette_speed, u8* programp, s32 length,
u8* status, GBACallback callback);
enum eappli_type {
GBA2_EAPPLI_TYPE_NEEDLEWORK,
GBA2_EAPPLI_TYPE_MUSICSCORE,
GBA2_EAPPLI_TYPE_PTERMINAL,
GBA2_EAPPLI_TYPE_NUM
};
enum send_eappli_state {
SEND_EAPPLI_STATE_WAIT_FOR_GBA,
SEND_EAPPLI_STATE_GC_ACKNOWLEDGE_TO_GBA,
SEND_EAPPLI_STATE_2,
SEND_EAPPLI_STATE_GC_SEND_EAPPLI_SIZE_TO_GBA,
SEND_EAPPLI_STATE_WAIT_FOR_GBA_ACKNOWLEDGED_EAPPLI_SIZE,
SEND_EAPPLI_STATE_GC_SEND_EAPPLI_DATA_TO_GBA,
SEND_EAPPLI_STATE_GC_OPEN_JOY_SIO_CONNECTION,
SEND_EAPPLI_STATE_JOY_SIO_CONNECTION_OPEN
};
enum send_eappli_status {
SEND_EAPPLI_STATUS_SUCCESS,
SEND_EAPPLI_STATUS_FAILED_GBA_NOT_DETECTED,
SEND_EAPPLI_STATUS_FAILED_TRANSMISSION_ERROR,
SEND_EAPPLI_STATUS_SENDING
};
enum gba_gc_device {
GBA2_DEVICE_NONE,
GBA2_DEVICE_GC,
GBA2_DEVICE_GBA
};
enum gba_gc_command {
GBA2_CMD_CHECK_STATE = 1,
GBA2_CMD_WRITE = 2,
GBA2_CMD_START_RECV = 4,
GBA2_CMD_VALID_CHKSUM = 6,
GBA2_CMD_INVALID_CHKSUM = 7,
GBA2_CMD_READY_FOR_XFER = 8,
GBA2_CMD_XFER_START = 9,
GBA2_CMD_XFER_FINISHED = 10,
};
typedef struct gba2_joywork_s {
int unused0;
u32 packet_block_checksum;
u32 total_xfer_checksum;
int packets_processed;
int readwrite_ofs;
int unused14;
int cmd_attempts;
u8 unused1C;
u8 checksum_valid;
u8 checksum_invalid;
u8 unused1F;
u8 status;
u8 cmd_stage;
u8 recv_state;
u8 send_state;
u8 port_connection_states[4 ];
u8 scan_state;
u8 gba_awaiting_ack;
int recv_wait;
} Joy_wrk_c;
extern int Port;
extern void mGcgba_Init();
extern void mGcgba_InitVar();
extern void mGcgba_EndComm();
extern int mGcgba_ConnectEnabled();
extern int mGcgba_Boot(u8* data_buf, size_t buf_size);
extern int mGcgba_IsEditor();
extern int mGcgba_IsIsland();
extern int mGcgba_Recv(u8* recv_bufp, size_t recv_buf_size);
extern int mGcgba_Read(u8* read_buf, size_t read_buf_size, u8 prog_type);
extern int mGcgba_CheckRecv(u8* recv_bufp, size_t recv_buf_size);
extern int mGcgba_Send(u8* send_bufp, size_t send_buf_size);
extern int mGcgba_send_eAppri(u8* eappli_p, size_t eappli_size);
#pragma section code_type ".init"
void * memcpy(void * dst, const void * src, size_t n);
void * memset(void * dst, int val, size_t n);
int memcmp(const void* src1, const void* src2, size_t n);
void __fill_mem(void * dst, int val, unsigned long n);
#pragma section code_type
extern int vprintf(const char*, va_list);
extern int vsprintf(char*, const char*, va_list);
extern int vsnprintf(char*, size_t, const char*, va_list);
extern int printf(const char*, ...);
int snprintf(char* s, size_t n, const char* format, ...);
static u32 mJOYSIO_ConvData(u8* data);
