
extern "C"{
extern int signgam;
enum fdversion { fdlibm_ieee = -1, fdlibm_svid, fdlibm_xopen, fdlibm_posix };
extern enum fdversion _fdlib_version ;
struct exception {
int type;
char* name;
double arg1;
double arg2;
double retval;
};
extern double acos (double) ;
extern double asin (double) ;
extern double atan (double) ;
extern double atan2 (double, double) ;
extern double cos (double) ;
extern double sin (double) ;
extern double tan (double) ;
extern double cosh (double) ;
extern double sinh (double) ;
extern double tanh (double) ;
extern double exp (double) ;
extern double frexp (double, int*) ;
extern double ldexp (double, int) ;
extern double scalbn (double, int) ;
extern double log (double) ;
extern double log10 (double) ;
extern double modf (double, double*) ;
extern double pow (double, double) ;
extern double sqrt (double) ;
extern double ceil (double) ;
extern double fabs (double) ;
extern double fabs__Fd(double);
extern double floor (double) ;
extern double fmod (double, double) ;
extern double erf (double) ;
extern double erfc (double) ;
extern double gamma (double) ;
extern double hypot (double, double) ;
extern int isnan (double) ;
extern int finite (double) ;
extern double j0 (double) ;
extern double j1 (double) ;
extern double jn (int, double) ;
extern double lgamma (double) ;
extern double y0 (double) ;
extern double y1 (double) ;
extern double yn (int, double) ;
extern double acosh (double) ;
extern double asinh (double) ;
extern double atanh (double) ;
extern double cbrt (double) ;
extern double logb (double) ;
extern double nextafter (double, double) ;
extern double remainder (double, double) ;
extern double scalb (double, double) ;
extern int matherr (struct exception*) ;
extern double significand (double) ;
extern double copysign (double, double) ;
extern int ilogb (double) ;
extern double rint (double) ;
extern double scalbn (double, int) ;
extern double expm1 (double) ;
extern double log1p (double) ;
extern double __ieee754_sqrt (double) ;
extern double __ieee754_acos (double) ;
extern double __ieee754_acosh (double) ;
extern double __ieee754_log (double) ;
extern double __ieee754_atanh (double) ;
extern double __ieee754_asin (double) ;
extern double __ieee754_atan2 (double, double) ;
extern double __ieee754_exp (double) ;
extern double __ieee754_cosh (double) ;
extern double __ieee754_fmod (double, double) ;
extern double __ieee754_pow (double, double) ;
extern double __ieee754_lgamma_r (double, int*) ;
extern double __ieee754_gamma_r (double, int*) ;
extern double __ieee754_lgamma (double) ;
extern double __ieee754_gamma (double) ;
extern double __ieee754_log10 (double) ;
extern double __ieee754_sinh (double) ;
extern double __ieee754_hypot (double, double) ;
extern double __ieee754_j0 (double) ;
extern double __ieee754_j1 (double) ;
extern double __ieee754_y0 (double) ;
extern double __ieee754_y1 (double) ;
extern double __ieee754_jn (int, double) ;
extern double __ieee754_yn (int, double) ;
extern double __ieee754_remainder (double, double) ;
extern int __ieee754_rem_pio2 (double, double*) ;
extern double __ieee754_scalb (double, double) ;
extern double __kernel_standard (double, double, int) ;
extern double __kernel_sin (double, double, int) ;
extern double __kernel_cos (double, double) ;
extern double __kernel_tan (double, double, int) ;
extern int __kernel_rem_pio2 (double*, double*, int, int, int, const int*) ;
inline double fabs(double x) {
return __fabs(x);
}
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
};
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_max[];
extern unsigned long __float_epsilon[];
inline int __fpclassifyf(float __value)
{
unsigned long integer = *(unsigned long*)&__value;
switch (integer & 0x7f800000) {
case 0x7f800000:
if ((integer & 0x7fffff) != 0) {
return 1 ;
}
return 2 ;
case 0:
if ((integer & 0x7fffff) != 0) {
return 5 ;
}
return 3 ;
}
return 4 ;
}
inline int __fpclassifyd(double __value)
{
switch (*(int*)&__value & 0x7ff00000) {
case 0x7ff00000: {
if ((*(int*)&__value & 0x000fffff) || (*(1 + (int*)&__value) & 0xffffffff))
return 1 ;
else
return 2 ;
break;
}
case 0: {
if ((*(int*)&__value & 0x000fffff) || (*(1 + (int*)&__value) & 0xffffffff))
return 5 ;
else
return 3 ;
break;
}
}
return 4 ;
}
extern inline float sqrtf(float x) {
static const double _half = .5;
static const double _three = 3.0;
volatile float y;
if (x > 0.0f) {
double guess = __frsqrte((double)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (float)(x * guess);
return y;
}
return x;
}
inline float fabsf(float x) {
return (float)fabs((double)x);
}
extern inline double sqrt(double x) {
if (x > 0.0) {
double guess = __frsqrte(x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
return x * guess;
} else if (x == 0.0f) {
return 0.0;
} else if (x) {
return (*(float*)__float_nan) ;
}
return (*(float*)__float_huge) ;
}
extern "C"{
}
typedef signed char s8;
typedef unsigned char u8;
typedef signed short int s16;
typedef unsigned short int u16;
typedef signed long s32;
typedef unsigned long u32;
typedef signed long long int s64;
typedef unsigned long long int u64;
typedef float f32;
typedef double f64;
typedef char *Ptr;
typedef unsigned int uintptr_t;
typedef int BOOL;
extern "C"{
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, int type);
}
extern "C"{
typedef unsigned long size_t;
extern "C"{
typedef unsigned long __file_handle;
typedef unsigned long fpos_t;
enum __file_kinds {
__closed_file,
__disk_file,
__console_file,
__string_file,
__unavailable_file = 3,
};
enum __file_orientation {
UNORIENTED,
CHAR_ORIENTED,
WIDE_ORIENTED,
};
typedef struct _file_modes {
unsigned int open_mode : 2;
unsigned int io_mode : 3;
unsigned int buffer_mode : 2;
unsigned int file_kind : 3;
unsigned int file_orientation : 2;
unsigned int binary_io : 1;
} file_modes;
enum __io_modes {
__read = 1,
__write = 2,
__read_write = 3,
__append = 4,
};
enum __io_states {
__neutral,
__writing,
__reading,
__rereading,
};
enum __io_results {
__no_io_error,
__io_error,
__io_EOF,
};
typedef struct _file_states {
unsigned int io_state : 3;
unsigned int free_buffer : 1;
unsigned char eof;
unsigned char error;
} file_states;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc idle_proc);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count, __idle_proc idle_proc);
typedef int (*__close_proc)(__file_handle file);
typedef struct _FILE {
__file_handle handle;
file_modes file_mode;
file_states file_state;
unsigned char char_buffer;
char char_buffer_overflow;
char ungetc_buffer[4];
wchar_t ungetc_wide_buffer[2];
unsigned long position;
unsigned char* buffer;
unsigned long buffer_size;
unsigned char* buffer_ptr;
unsigned long buffer_length;
unsigned long buffer_alignment;
unsigned long save_buffer_length;
unsigned long buffer_position;
__pos_proc position_fn;
__io_proc read_fn;
__io_proc write_fn;
__close_proc close_fn;
__idle_proc idle_fn;
void* next;
} FILE;
typedef struct _files {
FILE _stdin;
FILE _stdout;
FILE _stderr;
FILE _sentinel;
} files;
extern files __files;
};
int puts(const char *s);
int printf(const char *, ...);
int sprintf(char *s, const char *format, ...);
int vprintf(const char *format, va_list arg);
int vsprintf(char *s, const char *format, va_list arg);
}
extern "C"{
size_t strlen(const char *s);
long strtol(const char *str, char **end, int base);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t num);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
char *strncat(char *dest, const char *src, size_t n);
char *strchr(const char *str, int c);
char* strrchr( char* str, int chr );
char* strstr(const char* str, const char* pat);
char* strcat(char* dst, const char* src);
}
extern "C"{
int tolower(int c);
}
float powf(float x, float y);
float tanf(float);
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef unsigned int uint;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef void* unkptr;
typedef u32 unknown;
#pragma section RX "forcestrip"
extern "C"{
typedef void (*PADSamplingCallback)(void);
typedef struct PADStatus
{
u16 button;
s8 stickX;
s8 stickY;
s8 substickX;
s8 substickY;
u8 triggerLeft;
u8 triggerRight;
u8 analogA;
u8 analogB;
s8 err;
} PADStatus;
BOOL PADReset(u32 mask);
BOOL PADRecalibrate(u32 mask);
BOOL PADInit();
u32 PADRead(PADStatus* status);
void PADSetSamplingRate(u32 msec);
void __PADTestSamplingRate(u32 tvmode);
void PADControlAllMotors(const u32 *commandArray);
void PADControlMotor(s32 chan, u32 command);
void PADSetSpec(u32 spec);
u32 PADGetSpec();
BOOL PADGetType(s32 chan, u32* type);
BOOL PADSync(void);
void PADSetAnalogMode(u32 mode);
PADSamplingCallback PADSetSamplingCallback(PADSamplingCallback callback);
void PADClamp(PADStatus * status);
}
extern "C"{
typedef enum JKRExpandSwitch {
EXPAND_SWITCH_DEFAULT,
EXPAND_SWITCH_DECOMPRESS,
EXPAND_SWITCH_NONE
} JKRExpandSwitch;
}
extern "C"{
enum EButtons {
MAINSTICK_UP = 0x8000000,
MAINSTICK_DOWN = 0x4000000,
MAINSTICK_RIGHT = 0x2000000,
MAINSTICK_LEFT = 0x1000000,
CSTICK_UP = 0x80000,
CSTICK_DOWN = 0x40000,
CSTICK_RIGHT = 0x20000,
CSTICK_LEFT = 0x10000,
START = 0x1000,
Y = 0x800,
X = 0x400,
B = 0x200,
A = 0x100,
L = 0x40,
R = 0x20,
Z = 0x10,
DPAD_UP = 0x8,
DPAD_DOWN = 0x4,
DPAD_RIGHT = 0x2,
DPAD_LEFT = 0x1
};
}
extern "C"{
extern "C"{
typedef u8 GXBool;
typedef enum _GXProjectionType {
GX_PERSPECTIVE,
GX_ORTHOGRAPHIC,
} GXProjectionType;
typedef enum _GXCompare {
GX_NEVER,
GX_LESS,
GX_EQUAL,
GX_LEQUAL,
GX_GREATER,
GX_NEQUAL,
GX_GEQUAL,
GX_ALWAYS,
} GXCompare;
typedef enum _GXAlphaOp {
GX_AOP_AND,
GX_AOP_OR,
GX_AOP_XOR,
GX_AOP_XNOR,
GX_MAX_ALPHAOP,
} GXAlphaOp;
typedef enum _GXFBClamp {
GX_CLAMP_NONE,
GX_CLAMP_TOP,
GX_CLAMP_BOTTOM,
} GXFBClamp;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR,
GX_ZC_NEAR,
GX_ZC_MID,
GX_ZC_FAR,
} GXZFmt16;
typedef enum _GXGamma {
GX_GM_1_0,
GX_GM_1_7,
GX_GM_2_2,
} GXGamma;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24,
GX_PF_RGBA6_Z24,
GX_PF_RGB565_Z16,
GX_PF_Z24,
GX_PF_Y8,
GX_PF_U8,
GX_PF_V8,
GX_PF_YUV420,
} GXPixelFmt;
typedef enum _GXPrimitive {
GX_QUADS = 0x80,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xA0,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_POINTS = 0xB8,
} GXPrimitive;
typedef enum _GXVtxFmt {
GX_VTXFMT0,
GX_VTXFMT1,
GX_VTXFMT2,
GX_VTXFMT3,
GX_VTXFMT4,
GX_VTXFMT5,
GX_VTXFMT6,
GX_VTXFMT7,
GX_MAX_VTXFMT,
} GXVtxFmt;
typedef enum _GXAttr {
GX_VA_PNMTXIDX,
GX_VA_TEX0MTXIDX,
GX_VA_TEX1MTXIDX,
GX_VA_TEX2MTXIDX,
GX_VA_TEX3MTXIDX,
GX_VA_TEX4MTXIDX,
GX_VA_TEX5MTXIDX,
GX_VA_TEX6MTXIDX,
GX_VA_TEX7MTXIDX,
GX_VA_POS,
GX_VA_NRM,
GX_VA_CLR0,
GX_VA_CLR1,
GX_VA_TEX0,
GX_VA_TEX1,
GX_VA_TEX2,
GX_VA_TEX3,
GX_VA_TEX4,
GX_VA_TEX5,
GX_VA_TEX6,
GX_VA_TEX7,
GX_POS_MTX_ARRAY,
GX_NRM_MTX_ARRAY,
GX_TEX_MTX_ARRAY,
GX_LIGHT_ARRAY,
GX_VA_NBT,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF,
} GXAttr;
typedef enum _GXAttrType {
GX_NONE,
GX_DIRECT,
GX_INDEX8,
GX_INDEX16,
} GXAttrType;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_CTF_R4 = 0x0 | 0x20 ,
GX_CTF_RA4 = 0x2 | 0x20 ,
GX_CTF_RA8 = 0x3 | 0x20 ,
GX_CTF_YUVA8 = 0x6 | 0x20 ,
GX_CTF_A8 = 0x7 | 0x20 ,
GX_CTF_R8 = 0x8 | 0x20 ,
GX_CTF_G8 = 0x9 | 0x20 ,
GX_CTF_B8 = 0xA | 0x20 ,
GX_CTF_RG8 = 0xB | 0x20 ,
GX_CTF_GB8 = 0xC | 0x20 ,
GX_TF_Z8 = 0x1 | 0x10 ,
GX_TF_Z16 = 0x3 | 0x10 ,
GX_TF_Z24X8 = 0x6 | 0x10 ,
GX_CTF_Z4 = 0x0 | 0x10 | 0x20 ,
GX_CTF_Z8M = 0x9 | 0x10 | 0x20 ,
GX_CTF_Z8L = 0xA | 0x10 | 0x20 ,
GX_CTF_Z16L = 0xC | 0x10 | 0x20 ,
GX_TF_A8 = GX_CTF_A8,
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xa,
} GXCITexFmt;
typedef enum _GXTexWrapMode {
GX_CLAMP,
GX_REPEAT,
GX_MIRROR,
GX_MAX_TEXWRAPMODE,
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR,
GX_LINEAR,
GX_NEAR_MIP_NEAR,
GX_LIN_MIP_NEAR,
GX_NEAR_MIP_LIN,
GX_LIN_MIP_LIN,
} GXTexFilter;
typedef enum _GXAnisotropy {
GX_ANISO_1,
GX_ANISO_2,
GX_ANISO_4,
GX_MAX_ANISOTROPY,
} GXAnisotropy;
typedef enum _GXTexMapID {
GX_TEXMAP0,
GX_TEXMAP1,
GX_TEXMAP2,
GX_TEXMAP3,
GX_TEXMAP4,
GX_TEXMAP5,
GX_TEXMAP6,
GX_TEXMAP7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100,
} GXTexMapID;
typedef enum _GXTexCoordID {
GX_TEXCOORD0,
GX_TEXCOORD1,
GX_TEXCOORD2,
GX_TEXCOORD3,
GX_TEXCOORD4,
GX_TEXCOORD5,
GX_TEXCOORD6,
GX_TEXCOORD7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF,
} GXTexCoordID;
typedef enum _GXTevStageID {
GX_TEVSTAGE0,
GX_TEVSTAGE1,
GX_TEVSTAGE2,
GX_TEVSTAGE3,
GX_TEVSTAGE4,
GX_TEVSTAGE5,
GX_TEVSTAGE6,
GX_TEVSTAGE7,
GX_TEVSTAGE8,
GX_TEVSTAGE9,
GX_TEVSTAGE10,
GX_TEVSTAGE11,
GX_TEVSTAGE12,
GX_TEVSTAGE13,
GX_TEVSTAGE14,
GX_TEVSTAGE15,
GX_MAX_TEVSTAGE,
} GXTevStageID;
typedef enum _GXTevMode {
GX_MODULATE,
GX_DECAL,
GX_BLEND,
GX_REPLACE,
GX_PASSCLR,
} GXTevMode;
typedef enum _GXTexMtxType {
GX_MTX3x4,
GX_MTX2x4,
} GXTexMtxType;
typedef enum _GXTexGenType {
GX_TG_MTX3x4,
GX_TG_MTX2x4,
GX_TG_BUMP0,
GX_TG_BUMP1,
GX_TG_BUMP2,
GX_TG_BUMP3,
GX_TG_BUMP4,
GX_TG_BUMP5,
GX_TG_BUMP6,
GX_TG_BUMP7,
GX_TG_SRTG,
} GXTexGenType;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 0,
GX_PNMTX1 = 3,
GX_PNMTX2 = 6,
GX_PNMTX3 = 9,
GX_PNMTX4 = 12,
GX_PNMTX5 = 15,
GX_PNMTX6 = 18,
GX_PNMTX7 = 21,
GX_PNMTX8 = 24,
GX_PNMTX9 = 27,
} GXPosNrmMtx;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30,
GX_TEXMTX1 = 33,
GX_TEXMTX2 = 36,
GX_TEXMTX3 = 39,
GX_TEXMTX4 = 42,
GX_TEXMTX5 = 45,
GX_TEXMTX6 = 48,
GX_TEXMTX7 = 51,
GX_TEXMTX8 = 54,
GX_TEXMTX9 = 57,
GX_IDENTITY = 60,
} GXTexMtx;
typedef enum _GXChannelID {
GX_COLOR0,
GX_COLOR1,
GX_ALPHA0,
GX_ALPHA1,
GX_COLOR0A0,
GX_COLOR1A1,
GX_COLOR_ZERO,
GX_ALPHA_BUMP,
GX_ALPHA_BUMPN,
GX_COLOR_NULL = 0xFF,
} GXChannelID;
typedef enum _GXTexGenSrc {
GX_TG_POS,
GX_TG_NRM,
GX_TG_BINRM,
GX_TG_TANGENT,
GX_TG_TEX0,
GX_TG_TEX1,
GX_TG_TEX2,
GX_TG_TEX3,
GX_TG_TEX4,
GX_TG_TEX5,
GX_TG_TEX6,
GX_TG_TEX7,
GX_TG_TEXCOORD0,
GX_TG_TEXCOORD1,
GX_TG_TEXCOORD2,
GX_TG_TEXCOORD3,
GX_TG_TEXCOORD4,
GX_TG_TEXCOORD5,
GX_TG_TEXCOORD6,
GX_TG_COLOR0,
GX_TG_COLOR1,
GX_MAX_TEXGENSRC,
} GXTexGenSrc;
typedef enum _GXBlendMode {
GX_BM_NONE,
GX_BM_BLEND,
GX_BM_LOGIC,
GX_BM_SUBTRACT,
GX_MAX_BLENDMODE,
} GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO,
GX_BL_ONE,
GX_BL_SRCCLR,
GX_BL_INVSRCCLR,
GX_BL_SRCALPHA,
GX_BL_INVSRCALPHA,
GX_BL_DSTALPHA,
GX_BL_INVDSTALPHA,
GX_BL_DSTCLR = GX_BL_SRCCLR,
GX_BL_INVDSTCLR = GX_BL_INVSRCCLR,
} GXBlendFactor;
typedef enum _GXLogicOp {
GX_LO_CLEAR,
GX_LO_AND,
GX_LO_REVAND,
GX_LO_COPY,
GX_LO_INVAND,
GX_LO_NOOP,
GX_LO_XOR,
GX_LO_OR,
GX_LO_NOR,
GX_LO_EQUIV,
GX_LO_INV,
GX_LO_REVOR,
GX_LO_INVCOPY,
GX_LO_INVOR,
GX_LO_NAND,
GX_LO_SET,
} GXLogicOp;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1,
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5,
} GXCompType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64,
GX_PTTEXMTX1 = 67,
GX_PTTEXMTX2 = 70,
GX_PTTEXMTX3 = 73,
GX_PTTEXMTX4 = 76,
GX_PTTEXMTX5 = 79,
GX_PTTEXMTX6 = 82,
GX_PTTEXMTX7 = 85,
GX_PTTEXMTX8 = 88,
GX_PTTEXMTX9 = 91,
GX_PTTEXMTX10 = 94,
GX_PTTEXMTX11 = 97,
GX_PTTEXMTX12 = 100,
GX_PTTEXMTX13 = 103,
GX_PTTEXMTX14 = 106,
GX_PTTEXMTX15 = 109,
GX_PTTEXMTX16 = 112,
GX_PTTEXMTX17 = 115,
GX_PTTEXMTX18 = 118,
GX_PTTEXMTX19 = 121,
GX_PTIDENTITY = 125,
} GXPTTexMtx;
typedef enum _GXTevRegID {
GX_TEVPREV,
GX_TEVREG0,
GX_TEVREG1,
GX_TEVREG2,
GX_MAX_TEVREG,
} GXTevRegID;
typedef enum _GXDiffuseFn {
GX_DF_NONE,
GX_DF_SIGN,
GX_DF_CLAMP,
} GXDiffuseFn;
typedef enum _GXColorSrc {
GX_SRC_REG,
GX_SRC_VTX,
} GXColorSrc;
typedef enum _GXAttnFn {
GX_AF_SPEC,
GX_AF_SPOT,
GX_AF_NONE,
} GXAttnFn;
typedef enum _GXLightID {
GX_LIGHT0 = 0x001,
GX_LIGHT1 = 0x002,
GX_LIGHT2 = 0x004,
GX_LIGHT3 = 0x008,
GX_LIGHT4 = 0x010,
GX_LIGHT5 = 0x020,
GX_LIGHT6 = 0x040,
GX_LIGHT7 = 0x080,
GX_MAX_LIGHT = 0x100,
GX_LIGHT_NULL = 0,
} GXLightID;
typedef enum _GXTexOffset {
GX_TO_ZERO,
GX_TO_SIXTEENTH,
GX_TO_EIGHTH,
GX_TO_FOURTH,
GX_TO_HALF,
GX_TO_ONE,
GX_MAX_TEXOFFSET,
} GXTexOffset;
typedef enum _GXSpotFn {
GX_SP_OFF,
GX_SP_FLAT,
GX_SP_COS,
GX_SP_COS2,
GX_SP_SHARP,
GX_SP_RING1,
GX_SP_RING2,
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF,
GX_DA_GENTLE,
GX_DA_MEDIUM,
GX_DA_STEEP,
} GXDistAttnFn;
typedef enum _GXCullMode {
GX_CULL_NONE,
GX_CULL_FRONT,
GX_CULL_BACK,
GX_CULL_ALL,
} GXCullMode;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1,
GX_TEV_SWAP2,
GX_TEV_SWAP3,
GX_MAX_TEVSWAP,
} GXTevSwapSel;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN,
GX_CH_BLUE,
GX_CH_ALPHA,
} GXTevColorChan;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_PERSP_LIN = 2,
GX_FOG_PERSP_EXP = 4,
GX_FOG_PERSP_EXP2 = 5,
GX_FOG_PERSP_REVEXP = 6,
GX_FOG_PERSP_REVEXP2 = 7,
GX_FOG_ORTHO_LIN = 10,
GX_FOG_ORTHO_EXP = 12,
GX_FOG_ORTHO_EXP2 = 13,
GX_FOG_ORTHO_REVEXP = 14,
GX_FOG_ORTHO_REVEXP2 = 15,
GX_FOG_LIN = GX_FOG_PERSP_LIN,
GX_FOG_EXP = GX_FOG_PERSP_EXP,
GX_FOG_EXP2 = GX_FOG_PERSP_EXP2,
GX_FOG_REVEXP = GX_FOG_PERSP_REVEXP,
GX_FOG_REVEXP2 = GX_FOG_PERSP_REVEXP2,
} GXFogType;
typedef enum _GXTevColorArg {
GX_CC_CPREV,
GX_CC_APREV,
GX_CC_C0,
GX_CC_A0,
GX_CC_C1,
GX_CC_A1,
GX_CC_C2,
GX_CC_A2,
GX_CC_TEXC,
GX_CC_TEXA,
GX_CC_RASC,
GX_CC_RASA,
GX_CC_ONE,
GX_CC_HALF,
GX_CC_KONST,
GX_CC_ZERO,
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV,
GX_CA_A0,
GX_CA_A1,
GX_CA_A2,
GX_CA_TEXA,
GX_CA_RASA,
GX_CA_KONST,
GX_CA_ZERO,
} GXTevAlphaArg;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ,
} GXTevOp;
typedef enum _GXTevBias {
GX_TB_ZERO,
GX_TB_ADDHALF,
GX_TB_SUBHALF,
GX_MAX_TEVBIAS,
} GXTevBias;
typedef enum _GXTevScale {
GX_CS_SCALE_1,
GX_CS_SCALE_2,
GX_CS_SCALE_4,
GX_CS_DIVIDE_2,
GX_MAX_TEVSCALE,
} GXTevScale;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_8_8 = 0x00,
GX_TEV_KCSEL_7_8 = 0x01,
GX_TEV_KCSEL_6_8 = 0x02,
GX_TEV_KCSEL_5_8 = 0x03,
GX_TEV_KCSEL_4_8 = 0x04,
GX_TEV_KCSEL_3_8 = 0x05,
GX_TEV_KCSEL_2_8 = 0x06,
GX_TEV_KCSEL_1_8 = 0x07,
GX_TEV_KCSEL_1 = GX_TEV_KCSEL_8_8,
GX_TEV_KCSEL_3_4 = GX_TEV_KCSEL_6_8,
GX_TEV_KCSEL_1_2 = GX_TEV_KCSEL_4_8,
GX_TEV_KCSEL_1_4 = GX_TEV_KCSEL_2_8,
GX_TEV_KCSEL_K0 = 0x0C,
GX_TEV_KCSEL_K1 = 0x0D,
GX_TEV_KCSEL_K2 = 0x0E,
GX_TEV_KCSEL_K3 = 0x0F,
GX_TEV_KCSEL_K0_R = 0x10,
GX_TEV_KCSEL_K1_R = 0x11,
GX_TEV_KCSEL_K2_R = 0x12,
GX_TEV_KCSEL_K3_R = 0x13,
GX_TEV_KCSEL_K0_G = 0x14,
GX_TEV_KCSEL_K1_G = 0x15,
GX_TEV_KCSEL_K2_G = 0x16,
GX_TEV_KCSEL_K3_G = 0x17,
GX_TEV_KCSEL_K0_B = 0x18,
GX_TEV_KCSEL_K1_B = 0x19,
GX_TEV_KCSEL_K2_B = 0x1A,
GX_TEV_KCSEL_K3_B = 0x1B,
GX_TEV_KCSEL_K0_A = 0x1C,
GX_TEV_KCSEL_K1_A = 0x1D,
GX_TEV_KCSEL_K2_A = 0x1E,
GX_TEV_KCSEL_K3_A = 0x1F,
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_8_8 = 0x00,
GX_TEV_KASEL_7_8 = 0x01,
GX_TEV_KASEL_6_8 = 0x02,
GX_TEV_KASEL_5_8 = 0x03,
GX_TEV_KASEL_4_8 = 0x04,
GX_TEV_KASEL_3_8 = 0x05,
GX_TEV_KASEL_2_8 = 0x06,
GX_TEV_KASEL_1_8 = 0x07,
GX_TEV_KASEL_1 = GX_TEV_KASEL_8_8,
GX_TEV_KASEL_3_4 = GX_TEV_KASEL_6_8,
GX_TEV_KASEL_1_2 = GX_TEV_KASEL_4_8,
GX_TEV_KASEL_1_4 = GX_TEV_KASEL_2_8,
GX_TEV_KASEL_K0_R = 0x10,
GX_TEV_KASEL_K1_R = 0x11,
GX_TEV_KASEL_K2_R = 0x12,
GX_TEV_KASEL_K3_R = 0x13,
GX_TEV_KASEL_K0_G = 0x14,
GX_TEV_KASEL_K1_G = 0x15,
GX_TEV_KASEL_K2_G = 0x16,
GX_TEV_KASEL_K3_G = 0x17,
GX_TEV_KASEL_K0_B = 0x18,
GX_TEV_KASEL_K1_B = 0x19,
GX_TEV_KASEL_K2_B = 0x1A,
GX_TEV_KASEL_K3_B = 0x1B,
GX_TEV_KASEL_K0_A = 0x1C,
GX_TEV_KASEL_K1_A = 0x1D,
GX_TEV_KASEL_K2_A = 0x1E,
GX_TEV_KASEL_K3_A = 0x1F,
} GXTevKAlphaSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1,
GX_KCOLOR2,
GX_KCOLOR3,
GX_MAX_KCOLOR,
} GXTevKColorID;
typedef enum _GXZTexOp {
GX_ZT_DISABLE,
GX_ZT_ADD,
GX_ZT_REPLACE,
GX_MAX_ZTEXOP,
} GXZTexOp;
typedef enum _GXIndTexFormat {
GX_ITF_8,
GX_ITF_5,
GX_ITF_4,
GX_ITF_3,
GX_MAX_ITFORMAT,
} GXIndTexFormat;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE,
GX_ITB_S,
GX_ITB_T,
GX_ITB_ST,
GX_ITB_U,
GX_ITB_SU,
GX_ITB_TU,
GX_ITB_STU,
GX_MAX_ITBIAS,
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF,
GX_ITBA_S,
GX_ITBA_T,
GX_ITBA_U,
GX_MAX_ITBALPHA,
} GXIndTexAlphaSel;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF,
GX_ITM_0,
GX_ITM_1,
GX_ITM_2,
GX_ITM_S0 = 5,
GX_ITM_S1,
GX_ITM_S2,
GX_ITM_T0 = 9,
GX_ITM_T1,
GX_ITM_T2,
} GXIndTexMtxID;
typedef enum _GXIndTexWrap {
GX_ITW_OFF,
GX_ITW_256,
GX_ITW_128,
GX_ITW_64,
GX_ITW_32,
GX_ITW_16,
GX_ITW_0,
GX_MAX_ITWRAP,
} GXIndTexWrap;
typedef enum _GXIndTexStageID {
GX_INDTEXSTAGE0,
GX_INDTEXSTAGE1,
GX_INDTEXSTAGE2,
GX_INDTEXSTAGE3,
GX_MAX_INDTEXSTAGE,
} GXIndTexStageID;
typedef enum _GXIndTexScale {
GX_ITS_1,
GX_ITS_2,
GX_ITS_4,
GX_ITS_8,
GX_ITS_16,
GX_ITS_32,
GX_ITS_64,
GX_ITS_128,
GX_ITS_256,
GX_MAX_ITSCALE,
} GXIndTexScale;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1,
} GXClipMode;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19,
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8,
GX_TL_RGB565,
GX_TL_RGB5A3,
GX_MAX_TLUTFMT,
} GXTlutFmt;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3,
} GXMiscToken;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K,
GX_TEXCACHE_128K,
GX_TEXCACHE_512K,
GX_TEXCACHE_NONE
} GXTexCacheSize;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES,
GX_PERF0_CLIP_VTX,
GX_PERF0_CLIP_CLKS,
GX_PERF0_XF_WAIT_IN,
GX_PERF0_XF_WAIT_OUT,
GX_PERF0_XF_XFRM_CLKS,
GX_PERF0_XF_LIT_CLKS,
GX_PERF0_XF_BOT_CLKS,
GX_PERF0_XF_REGLD_CLKS,
GX_PERF0_XF_REGRD_CLKS,
GX_PERF0_CLIP_RATIO,
GX_PERF0_TRIANGLES,
GX_PERF0_TRIANGLES_CULLED,
GX_PERF0_TRIANGLES_PASSED,
GX_PERF0_TRIANGLES_SCISSORED,
GX_PERF0_TRIANGLES_0TEX,
GX_PERF0_TRIANGLES_1TEX,
GX_PERF0_TRIANGLES_2TEX,
GX_PERF0_TRIANGLES_3TEX,
GX_PERF0_TRIANGLES_4TEX,
GX_PERF0_TRIANGLES_5TEX,
GX_PERF0_TRIANGLES_6TEX,
GX_PERF0_TRIANGLES_7TEX,
GX_PERF0_TRIANGLES_8TEX,
GX_PERF0_TRIANGLES_0CLR,
GX_PERF0_TRIANGLES_1CLR,
GX_PERF0_TRIANGLES_2CLR,
GX_PERF0_QUAD_0CVG,
GX_PERF0_QUAD_NON0CVG,
GX_PERF0_QUAD_1CVG,
GX_PERF0_QUAD_2CVG,
GX_PERF0_QUAD_3CVG,
GX_PERF0_QUAD_4CVG,
GX_PERF0_AVG_QUAD_CNT,
GX_PERF0_CLOCKS,
GX_PERF0_NONE
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS,
GX_PERF1_TX_IDLE,
GX_PERF1_TX_REGS,
GX_PERF1_TX_MEMSTALL,
GX_PERF1_TC_CHECK1_2,
GX_PERF1_TC_CHECK3_4,
GX_PERF1_TC_CHECK5_6,
GX_PERF1_TC_CHECK7_8,
GX_PERF1_TC_MISS,
GX_PERF1_VC_ELEMQ_FULL,
GX_PERF1_VC_MISSQ_FULL,
GX_PERF1_VC_MEMREQ_FULL,
GX_PERF1_VC_STATUS7,
GX_PERF1_VC_MISSREP_FULL,
GX_PERF1_VC_STREAMBUF_LOW,
GX_PERF1_VC_ALL_STALLS,
GX_PERF1_VERTICES,
GX_PERF1_FIFO_REQ,
GX_PERF1_CALL_REQ,
GX_PERF1_VC_MISS_REQ,
GX_PERF1_CP_ALL_REQ,
GX_PERF1_CLOCKS,
GX_PERF1_NONE
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS,
GX_VC_NRM,
GX_VC_CLR0,
GX_VC_CLR1,
GX_VC_TEX0,
GX_VC_TEX1,
GX_VC_TEX2,
GX_VC_TEX3,
GX_VC_TEX4,
GX_VC_TEX5,
GX_VC_TEX6,
GX_VC_TEX7,
GX_VC_ALL = 0xf
} GXVCachePerf;
typedef enum _GXAlphaReadMode
{
GX_READ_00,
GX_READ_FF,
GX_READ_NONE,
} GXAlphaReadMode;
typedef enum _GXCopyMode
{
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3,
} GXCopyMode;
typedef enum _GXTlutSize
{
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024,
} GXTlutSize;
}
extern "C"{
typedef enum
{
VI_TVMODE_NTSC_INT = (((0) << 2) + (0)) ,
VI_TVMODE_NTSC_DS = (((0) << 2) + (1)) ,
VI_TVMODE_NTSC_PROG = (((0) << 2) + (2)) ,
VI_TVMODE_3 = 3,
VI_TVMODE_PAL_INT = (((1) << 2) + (0)) ,
VI_TVMODE_PAL_DS = (((1) << 2) + (1)) ,
VI_TVMODE_EURGB60_INT = (((5) << 2) + (0)) ,
VI_TVMODE_EURGB60_DS = (((5) << 2) + (1)) ,
VI_TVMODE_MPAL_INT = (((2) << 2) + (0)) ,
VI_TVMODE_MPAL_DS = (((2) << 2) + (1)) ,
VI_TVMODE_DEBUG_INT = (((3) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_INT = (((4) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_DS = (((4) << 2) + (1))
} VITVMode;
typedef enum
{
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF
} VIXFBMode;
typedef void (*VIRetraceCallback)(u32 retraceCount);
void VIConfigure(const struct _GXRenderModeObj *rm);
void VISetBlack(BOOL);
void VIWaitForRetrace();
void VIConfigurePan(u16 x_origin, u16 y_origin, u16 width, u16 height);
u32 VIGetRetraceCount();
u32 VIGetDTVStatus();
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void* VIGetNextFrameBuffer();
void* VIGetCurrentFrameBuffer();
void VISetNextFrameBuffer(void* fb);
void VIInit();
void VIFlush();
};
extern "C"{
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXColor {
u8 r;
u8 g;
u8 b;
u8 a;
} GXColor;
typedef struct _GXTexObj {
u32 dummy[8];
} GXTexObj;
typedef struct _GXTlutObj {
u32 dummy[3];
} GXTlutObj;
typedef struct _GXLightObj {
u32 dummy[16];
} GXLightObj;
typedef struct _GXColorS10 {
s16 r;
s16 g;
s16 b;
s16 a;
} GXColorS10;
typedef struct _GXTexRegion {
u32 dummy[4];
} GXTexRegion;
typedef struct _GXTlutRegion {
u32 dummy[4];
} GXTlutRegion;
typedef struct _GXFogAdjTable
{
u16 r[10];
} GXFogAdjTable;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt cnt;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
}
extern "C"{
extern u16 *__memReg;
extern u16 *__peReg;
extern u16 *__cpReg;
extern u32 *__piReg;
inline u32 __GXReadCPCounterU32(u32 regAddrL, u32 regAddrH)
{
u32 ctrH0;
u32 ctrH1;
u32 ctrL;
ctrH0 = (*(volatile u16*)((__cpReg) + (regAddrH))) ;
while (1 ) {
ctrH1 = ctrH0;
ctrL = (*(volatile u16*)((__cpReg) + (regAddrL))) ;
ctrH0 = (*(volatile u16*)((__cpReg) + (regAddrH))) ;
if (ctrH0 == ctrH1) {
break;
}
}
return (ctrH0 << 16) | (ctrL);
}
}
extern "C"{
void GXSetTevDirect(GXTevStageID tev_stage);
void GXSetNumIndStages(u8 nIndStages);
void GXSetIndTexMtx(GXIndTexMtxID mtx_sel, f32 offset[2][3], s8 scale_exp);
void GXSetIndTexOrder(GXIndTexStageID ind_stage, GXTexCoordID tex_coord, GXTexMapID tex_map);
void GXSetTevIndirect(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXIndTexFormat format,
GXIndTexBiasSel bias_sel, GXIndTexMtxID matrix_sel, GXIndTexWrap wrap_s,
GXIndTexWrap wrap_t, GXBool add_prev, GXBool ind_lod,
GXIndTexAlphaSel alpha_sel);
void GXSetTevIndWarp(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXBool signed_offsets,
GXBool replace_mode, GXIndTexMtxID matrix_sel);
void GXSetIndTexCoordScale(GXIndTexStageID ind_state, GXIndTexScale scale_s, GXIndTexScale scale_t);
extern void __GXSetIndirectMask(u32 mask);
}
extern "C"{
}
extern "C"{
void GXSetScissor(u32 left, u32 top, u32 wd, u32 ht);
void GXSetCullMode(GXCullMode mode);
void GXSetCoPlanar(GXBool enable);
}
extern "C"{
void GXBeginDisplayList(void* list, u32 size);
u32 GXEndDisplayList(void);
void GXCallDisplayList(void* list, u32 nbytes);
}
extern "C"{
void GXDrawSphere(u8 numMajor, u8 numMinor);
}
extern
"C"{
extern "C"{
typedef struct OSContext
{
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
u32 fpscr_pad;
u32 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
u32 OSGetStackPointer(void);
void OSDumpContext(OSContext *context);
void OSLoadContext(OSContext *context);
u32 OSSaveContext(OSContext *context);
void OSClearContext(OSContext *context);
OSContext *OSGetCurrentContext(void);
void OSSetCurrentContext(OSContext *context);
void OSLoadFPUContext(OSContext *fpuContext);
void OSSaveFPUContext(OSContext *fpuContext);
u32 OSSwitchStack(u32 newsp);
int OSSwitchFiber(u32 pc, u32 newsp);
void OSInitContext(OSContext *context, u32 pc, u32 newsp);
void OSFillFPUContext(OSContext *context);
}
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef s32 OSPriority;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef struct OSCond OSCond;
typedef void (*OSIdleFunction)(void *param);
struct OSThreadQueue
{
OSThread *head;
OSThread *tail;
};
struct OSThreadLink
{
OSThread *next;
OSThread *prev;
};
struct OSMutexQueue
{
OSMutex *head;
OSMutex *tail;
};
struct OSMutexLink
{
OSMutex *next;
OSMutex *prev;
};
struct OSThread
{
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void *val;
OSThreadQueue *queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex *mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8 *stackBase;
u32 *stackEnd;
};
enum OS_THREAD_STATE
{
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8
};
void OSInitThreadQueue(OSThreadQueue *queue);
OSThread *OSGetCurrentThread(void);
BOOL OSIsThreadSuspended(OSThread *thread);
BOOL OSIsThreadTerminated(OSThread *thread);
s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);
void OSYieldThread(void);
BOOL OSCreateThread(OSThread *thread,
void *(*func)(void *),
void *param,
void *stack,
u32 stackSize,
OSPriority priority,
u16 attr);
void OSExitThread(void *val);
void OSCancelThread(OSThread *thread);
BOOL OSJoinThread(OSThread *thread, void **val);
void OSDetachThread(OSThread *thread);
s32 OSResumeThread(OSThread *thread);
s32 OSSuspendThread(OSThread *thread);
BOOL OSSetThreadPriority(OSThread *thread, OSPriority priority);
OSPriority OSGetThreadPriority(OSThread *thread);
void OSSleepThread(OSThreadQueue *queue);
void OSWakeupThread(OSThreadQueue *queue);
OSThread *OSSetIdleFunction(OSIdleFunction idleFunction,
void *param,
void *stack,
u32 stackSize);
OSThread *OSGetIdleFunction(void);
long OSCheckActiveThreads(void);
}
extern "C"{
typedef struct
{
u8 pad[128];
} GXFifoObj;
typedef void (*GXBreakPtCallback)(void);
void GXInitFifoBase(GXFifoObj *fifo, void *base, u32 size);
void GXInitFifoPtrs(GXFifoObj *fifo, void *readPtr, void *writePtr);
void GXInitFifoLimits(GXFifoObj *fifo, u32 hiWatermark, u32 loWatermark);
void GXSetCPUFifo(GXFifoObj *fifo);
void GXSetGPFifo(GXFifoObj *fifo);
void GXSaveCPUFifo(GXFifoObj *fifo);
void GXSaveGPFifo(GXFifoObj *fifo);
void GXGetGPStatus(GXBool *overhi, GXBool *underlow, GXBool *readIdle, GXBool *cmdIdle, GXBool *brkpt);
void GXGetFifoStatus(GXFifoObj *fifo, GXBool *overhi, GXBool *underflow, u32 *fifoCount, GXBool *cpuWrite, GXBool *gpRead, GXBool *fifowrap);
void GXGetFifoPtrs(GXFifoObj *fifo, void **readPtr, void **writePtr);
void *GXGetFifoBase(GXFifoObj *fifo);
u32 GXGetFifoSize(GXFifoObj *fifo);
void GXGetFifoLimits(GXFifoObj *fifo, u32 *hi, u32 *lo);
GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback cb);
void GXEnableBreakPt(void *break_pt);
void GXDisableBreakPt(void);
OSThread *GXSetCurrentGXThread(void);
OSThread *GXGetCurrentGXThread(void);
GXFifoObj *GXGetCPUFifo(void);
GXFifoObj *GXGetGPFifo(void);
u32 GXGetOverflowCount(void);
u32 GXResetOverflowCount(void);
volatile void *GXRedirectWriteGatherPipe(void *ptr);
void GXRestoreWriteGatherPipe(void);
}
extern "C"{
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
void GXSetCopyClear(GXColor clear_clr, u32 clear_z);
void GXAdjustForOverscan(GXRenderModeObj* rmin, GXRenderModeObj* rmout, u16 hor, u16 ver);
void GXCopyDisp(void* dest, GXBool clear);
void GXSetDispCopyGamma(GXGamma gamma);
void GXSetDispCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetDispCopyDst(u16 wd, u16 ht);
f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
u32 GXSetDispCopyYScale(f32 vscale);
u16 GXGetNumXfbLines(u16 efbHeight, f32 yScale);
void GXSetCopyFilter(GXBool aa, const u8 sample_pattern[12][2], GXBool vf, const u8 vfilter[7]);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetTexCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetTexCopyDst(u16 wd, u16 ht, GXTexFmt fmt, GXBool mipmap);
void GXCopyTex(void* dest, GXBool clear);
void GXSetCopyClamp(GXFBClamp clamp);
}
extern "C"{
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(const GXVtxDescList* list);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetNumTexGens(u8 nTexGens);
void GXBegin(GXPrimitive type, GXVtxFmt vtxfmt, u16 nverts);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx,
GXBool normalize, u32 postmtx);
void GXSetLineWidth(u8 width, GXTexOffset texOffsets);
void GXSetPointSize(u8 pointSize, GXTexOffset texOffsets);
void GXEnableTexOffsets(GXTexCoordID coord, GXBool line_enable, GXBool point_enable);
void GXSetArray(GXAttr attr, const void* data, u8 stride);
void GXInvalidateVtxCache(void);
static inline void GXSetTexCoordGen(GXTexCoordID dst_coord, GXTexGenType func,
GXTexGenSrc src_param, u32 mtx) {
GXSetTexCoordGen2(dst_coord, func, src_param, mtx, ((GXBool)0) , GX_PTIDENTITY);
}
}
extern "C"{
GXBool GXGetTexObjMipMap(const GXTexObj* obj);
GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
u16 GXGetTexObjHeight(const GXTexObj* obj);
u16 GXGetTexObjWidth(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapS(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapT(const GXTexObj* obj);
void* GXGetTexObjData(const GXTexObj* obj);
void GXGetProjectionv(f32* p);
void GXGetLightPos(GXLightObj* lt_obj, f32* x, f32* y, f32* z);
void GXGetLightColor(GXLightObj* lt_obj, GXColor* color);
void GXGetVtxAttrFmt(GXVtxFmt idx, GXAttr attr, GXCompCnt* compCnt, GXCompType* compType,
u8* shift);
}
extern "C"{
void GXSetNumChans(u8 nChans);
void GXSetChanCtrl(GXChannelID chan, GXBool enable, GXColorSrc amb_src, GXColorSrc mat_src,
u32 light_mask, GXDiffuseFn diff_fn, GXAttnFn attn_fn);
void GXSetChanAmbColor(GXChannelID chan, GXColor amb_color);
void GXSetChanMatColor(GXChannelID chan, GXColor mat_color);
void GXInitLightSpot(GXLightObj* lt_obj, f32 cutoff, GXSpotFn spot_func);
void GXInitLightDistAttn(GXLightObj* lt_obj, f32 ref_distance, f32 ref_brightness,
GXDistAttnFn dist_func);
void GXInitLightPos(GXLightObj* lt_obj, f32 x, f32 y, f32 z);
void GXInitLightDir(GXLightObj* lt_obj, f32 nx, f32 ny, f32 nz);
void GXInitLightColor(GXLightObj* lt_obj, GXColor color);
void GXInitLightAttn(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
void GXInitLightAttnA(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2);
void GXInitLightAttnK(GXLightObj* lt_obj, f32 k0, f32 k1, f32 k2);
void GXLoadLightObjImm(GXLightObj* lt_obj, GXLightID light);
}
extern "C"{
typedef void (*GXDrawSyncCallback)(u16 token);
typedef void (*GXDrawDoneCallback)(void);
BOOL IsWriteGatherBufferEmpty(void);
GXFifoObj *GXInit(void *base, u32 size);
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush(void);
void GXResetWriteGatherPipe(void);
void GXAbortFrame(void);
void GXSetDrawSync(u16 token);
u16 GXReadDrawSync(void);
void GXSetDrawDone(void);
void GXWaitDrawDone(void);
void GXDrawDone(void);
void GXPixModeSync(void);
void GXTexModeSync(void);
GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback cb);
GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback cb);
}
extern
"C"{
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush();
void GXResetWriteGatherPipe();
void GXAbortFrame();
}
extern "C"{
void GXReadXfRasMetric(u32* xf_wait_in, u32* xf_wait_out, u32* ras_busy, u32* clocks);
}
extern "C"{
void GXSetFog(GXFogType type, f32 startz, f32 endz, f32 nearz, f32 farz, GXColor color);
void GXInitFogAdjTable(GXFogAdjTable *table, u16 width, f32 projmtx[4][4]);
void GXSetFogRangeAdj(GXBool enable, u16 center, GXFogAdjTable *table);
void GXSetBlendMode(GXBlendMode type, GXBlendFactor src_factor, GXBlendFactor dst_factor, GXLogicOp op);
void GXSetColorUpdate(GXBool update_enable);
void GXSetAlphaUpdate(GXBool update_enable);
void GXSetZMode(GXBool compare_enable, GXCompare func, GXBool update_enable);
void GXSetZCompLoc(GXBool before_tex);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetDither(GXBool dither);
void GXSetDstAlpha(GXBool enable, u8 alpha);
void GXSetFieldMask(GXBool odd_mask, GXBool even_mask);
void GXSetFieldMode(GXBool field_mode, GXBool half_aspect_ratio);
}
extern "C"{
void GXSetTevOp(GXTevStageID id, GXTevMode mode);
void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c,
GXTevColorArg d);
void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c,
GXTevAlphaArg d);
void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevColor(GXTevRegID id, GXColor color);
void GXSetTevColorS10(GXTevRegID id, GXColorS10 color);
void GXSetTevKColor(GXTevKColorID id, GXColor color);
void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel ras_sel, GXTevSwapSel tex_sel);
void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green,
GXTevColorChan blue, GXTevColorChan alpha);
void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
void GXSetZTexture(GXZTexOp op, GXTexFmt fmt, u32 bias);
void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
void GXSetNumTevStages(u8 nStages);
}
extern "C"{
typedef GXTexRegion* (*GXTexRegionCallback)(const GXTexObj* obj, GXTexMapID id);
typedef GXTlutRegion* (*GXTlutRegionCallback)(u32 idx);
void GXInitTexObj(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap);
void GXInitTexObjCI(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap, u32 tlut_name);
void GXInitTexObjData(GXTexObj* obj, void* image_ptr);
void GXInitTexObjLOD(GXTexObj* obj, GXTexFilter min_filt, GXTexFilter mag_filt, f32 min_lod, f32 max_lod, f32 lod_bias,
GXBool bias_clamp, GXBool do_edge_lod, GXAnisotropy max_aniso);
void GXLoadTexObj(GXTexObj* obj, GXTexMapID id);
u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, GXBool mipmap, u8 max_lod);
void GXInvalidateTexAll();
void GXInitTexObjWrapMode(GXTexObj* obj, GXTexWrapMode s, GXTexWrapMode t);
void GXInitTlutObj(GXTlutObj* tlut_obj, void* lut, GXTlutFmt fmt, u16 n_entries);
void GXLoadTlut(GXTlutObj* obj, u32 idx);
void GXSetTexCoordScaleManually(GXTexCoordID coord, GXBool enable, u16 ss, u16 ts);
void GXInitTexCacheRegion(GXTexRegion* region, GXBool is_32b_mipmap, u32 tmem_even, GXTexCacheSize size_even,
u32 tmem_odd, GXTexCacheSize size_odd);
GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback callback);
void GXInvalidateTexRegion(GXTexRegion* region);
void GXInitTlutRegion(GXTlutRegion* region, u32 tmem_addr, GXTlutSize tlut_size);
void GXSetTexCoordBias(GXTexCoordID coord, u8 s_enable, u8 t_enable);
}
extern "C"{
void GXSetProjection(f32 mtx[4][4], GXProjectionType type);
void GXLoadPosMtxImm(f32 mtx[3][4], u32 id);
void GXLoadNrmMtxImm(f32 mtx[3][4], u32 id);
void GXLoadTexMtxImm(f32 mtx[][4], u32 id, GXTexMtxType type);
void GXSetViewport(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz);
void GXSetCurrentMtx(u32 id);
void GXSetViewportJitter(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz, u32 field);
void GXSetScissorBoxOffset(s32 x_off, s32 y_off);
void GXSetClipMode(GXClipMode mode);
}
typedef enum {
GX_WARN_NONE,
GX_WARN_SEVERE,
GX_WARN_MEDIUM,
GX_WARN_ALL
} GXWarningLevel;
typedef void (*GXVerifyCallback)(GXWarningLevel level, u32 id, char *msg);
void GXSetVerifyLevel(GXWarningLevel level);
GXVerifyCallback GXSetVerifyCallback(GXVerifyCallback cb);
extern "C"{
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
volatile PPCWGPipe GXWGFifo : (0xCC008000) ;
static inline void GXPosition2f32(f32 x, f32 y) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
}
static inline void GXPosition3s16(s16 x, s16 y, s16 z) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXPosition3f32(f32 x, f32 y, f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXNormal3f32(f32 x, f32 y, f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXColor1u32(u32 v) {
GXWGFifo.u32 = v;
}
static inline void GXColor4u8(u8 r, u8 g, u8 b, u8 a) {
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
GXWGFifo.u8 = a;
}
static inline void GXTexCoord2s16(s16 u, s16 v) {
GXWGFifo.s16 = u;
GXWGFifo.s16 = v;
}
static inline void GXPosition2s16(s16 x, s16 y)
{
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
}
static inline void GXPosition2u16(u16 x, u16 y)
{
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
}
static inline void GXTexCoord2f32(f32 u, f32 v) {
GXWGFifo.f32 = u;
GXWGFifo.f32 = v;
}
static inline void GXTexCoord2u8(u8 u, u8 v)
{
GXWGFifo.u8 = u;
GXWGFifo.u8 = v;
}
static inline void GXPosition1x8(u8 index) {
GXWGFifo.u8 = index;
}
static inline void GXTexCoord2u16(u16 s, u16 t) {
GXWGFifo.u16 = s;
GXWGFifo.u16 = t;
}
static inline void GXEnd(void) {}
}
}
extern "C"{
typedef struct {
u16 mFileID;
u16 mHash;
u32 mFlag;
u32 mDataOffset;
u32 mSize;
void* mData;
} CSDIFileEntry;
extern void* JC_JUTVideo_getManager();
extern u32 JC_JUTVideo_getFbWidth(void* manager);
extern u32 JC_JUTVideo_getEfbHeight(void* manager);
extern void JC_JUTVideo_setRenderMode(void* manager, GXRenderModeObj* renderMode);
extern void JC_JKRAramHeap_dump(void* heap);
extern void* JC_JKRAram_getAramHeap();
extern u32 JC_JKRAramArchive_getAramAddress_byName(void* archive, u32 root_name, const char* res_name);
extern CSDIFileEntry* JC__JKRGetResourceEntry_byName(u32 root_name, const char* res_name, void* archive);
extern void* JC__JKRDvdToMainRam_byName(const char* name, u8* buf, JKRExpandSwitch expandSwitch);
extern void JC__JKRDetachResource(void* ptr);
extern int JC_JUTConsole_isVisible(void* console);
extern void JC_JUTConsole_setVisible(void* console, BOOL visible);
extern void JC_JUTConsole_clear(void* console);
extern void JC_JUTConsole_scroll(void* console, int scroll);
extern int JC_JUTConsole_getPositionX(void* console);
extern void JC_JUTConsole_setPosition(void* console, int x, int y);
extern int JC_JUTConsole_getOutput(void* console);
extern int JC_JUTConsole_getLineOffset(void* console);
extern void JC_JUTConsole_dumpToTerminal(void* console, int lines);
extern void JC_JUTConsole_setOutput(void* console, int output);
extern void JC_JUTConsole_scrollToLastLine(void* console);
extern void JC_JUTConsole_scrollToFirstLine(void* console);
extern void JC_JUTConsole_scroll(void* console, int amount);
extern u32 JC_JUTConsole_getHeight(void* console);
extern u32 JC_JUTConsole_getUsedLine(void* console);
extern void JC_JUTConsole_print_f_va(void* console, const char* fmt, va_list arg);
extern void JC_JUTConsole_print_f(void* console, const char* fmt, ...);
extern void* JC_JUTConsoleManager_getManager();
extern void JC_JUTConsoleManager_drawDirect(void* manager, int direct);
extern void* JC_JUTDbPrint_getManager();
extern void JC_JUTDbPrint_setVisible(void* dbprint, BOOL visible);
extern void* JC_JUTProcBar_getManager();
extern void JC_JUTProcBar_setVisible(void* procbar, BOOL visible);
extern void JC_JUTProcBar_setVisibleHeapBar(void* procbar, BOOL visible);
extern void* JC_JUTException_getManager();
extern void* JC_JUTException_getConsole();
extern BOOL JC_JUTException_isEnablePad(void* manager);
extern int JC_JUTException_readPad(void* mgr, u32* trigger, u32* button);
extern void JC_JUTException_waitTime(u32 time);
extern void JC_JUTException_enterAllPad(void* manager);
extern void JC_JUTException_setMapFile(const char* path);
extern void JC_JUTException_setPreUserCallback(void* callback);
extern void JC_JUTException_setPostUserCallback(void* callback);
extern void JC_JUTAssertion_changeDevice(int device);
extern void JC_JUTAssertion_changeDisplayTime(int displayTime);
extern void JC_JUTGamePad_read();
extern PADStatus JC_JUTGamePad_getPadStatus(u32 port);
extern u8 JC_JUTGamePad_recalibrate(u32 port);
extern void* JC_JFWDisplay_getManager();
extern int JC_JFWDisplay_startFadeIn(void* manager, int len);
extern void JC_JFWDisplay_setFrameRate(void* manager, u16 framerate);
extern void JC_JFWDisplay_endFrame(void* manager);
extern void JC_JFWDisplay_beginRender(void* manager);
extern void JC_JFWDisplay_endRender(void* manager);
extern void JC_JFWDisplay_setClearColor(void* manager, GXColor color);
extern int JC_JFWDisplay_startFadeOut(void* manager, int fadeout);
extern void JC_JFWDisplay_clearEfb(void* manager, GXColor color);
extern const GXRenderModeObj* JC_JFWDisplay_getRenderMode(void* manager);
extern void* JC_JFWDisplay_changeToSingleXfb(void* manager, int index);
extern void* JC_JFWDisplay_changeToDoubleXfb(void* manager);
extern int JC_JFWDisplay_getEfbWidth(void* manager);
extern int JC_JFWDisplay_getEfbHeight(void* manager);
extern void* JC_JFWDisplay_createManager_0(GXRenderModeObj* renderMode, void* heap, int exfbNumber, int enableAlpha);
extern void JC_JFWDisplay_setFader(void* manager, void* fader);
extern void JC_JFWDisplay_setGamma(void* manager, int gamma);
extern void JC_JFWDisplay_destroyManager();
extern void JC_JFWSystem_setMaxStdHeap(int max);
extern void JC_JFWSystem_setSysHeapSize(u32 size);
extern void JC_JFWSystem_setFifoBufSize(u32 size);
extern void JC_JFWSystem_setAramAudioBufSize(u32 size);
extern void JC_JFWSystem_setAramGraphBufSize(u32 size);
extern void JC_JFWSystem_init();
extern void* JC_JFWSystem_getSystemConsole();
extern void* JC_JFWSystem_getRootHeap();
extern void* JC_JFWSystem_getSystemHeap();
extern void* JC_J2DOrthoGraph_new();
extern void JC_J2DOrthoGraph_delete(void* orthograph);
extern void* JC_JUTFader_new(int ul_x, int ul_y, int br_x, int br_y, u32* color);
extern void JC_JUTFader_delete(void* fader);
extern void* JC__JKRGetResource(const char* resourceName);
extern void JC__JKRRemoveResource(void* res);
extern void JC_J2DOrthoGraph_setOrtho(void* orthograph, int ul_x, int ul_y, int br_x, int br_y);
extern void JC_J2DOrthoGraph_setPort(void* orthograph);
extern void* JC_JKRAramArchive_new();
extern BOOL JC__JKRMountFixedAramArchive(void* aram_archive, const char* file);
extern void JC__JKRUnmountFixedAramArchive(void* aram_archive);
extern void JC_JKRAramArchive_delete(void* aram_archive);
extern u32 JC_JKRHeap_getFreeSize(void* heap);
extern void* JC_JKRHeap_alloc(void* heap, u32 size, int align);
extern void JC_JKRHeap_free(void* heap, void* mem);
extern size_t JC_JKRHeap_getSize(void* heap, void* mem);
extern s32 JC_JKRHeap_resize(void* heap, void* ptr, s32 new_size);
extern int JC_JKRHeap_dump(void* heap);
extern s32 JC_JKRHeap_getTotalFreeSize(void* heap);
extern u32 JC__JKRGetMemBlockSize(void* heap, void* ptr);
extern u8 JC_JKRExpHeap_changeGroupID(void* expheap, u8 groupId);
extern void* JC__JKRAllocFromAram(size_t size);
extern u8* JC__JKRAramToMainRam_block(void* aramBlock, u8* ramDst, size_t size);
extern void* JC__JKRMainRamToAram_block(u8* ramAddr, void* aramBlock, size_t size);
extern void* JW_Alloc(size_t size, int align);
extern void JW_Free(void* ptr);
extern s32 JW_Resize(void* ptr, size_t new_size);
extern size_t JW_GetMemBlockSize(void* ptr);
extern void JW_JUTXfb_clearIndex(void);
extern void JW_JUTReport(int x, int y, int show_count, const char* fmt, ...);
extern int JC_JKRDecomp_checkCompressed(u8* bufp);
extern void JC_JKRDecomp_decode(u8* comp_bufp, u8* decomp_bufp, u32 decomp_buf_size, u32 skipCount);
extern void* JC__JKRMountArchive(const char* path, int mount_mode, void* heap, int mount_direction);
extern void* JC__JKRGetSystemHeap();
extern void* JC_JUTXfb_getManager();
extern void JC_JUTXfb_clearIndex(void* manager);
extern u32 JC_JKRAramBlock_getAddress(void* aramBlock);
}
extern "C"{
typedef struct DVDCommandBlock DVDCommandBlock;
typedef struct DVDFileInfo DVDFileInfo;
typedef void (*DVDCallback)(s32 result, DVDFileInfo* fileInfo);
typedef void (*DVDCBCallback)(s32 result, DVDCommandBlock* block);
typedef void (*DVDLowCallback)(u32 intType);
typedef void (*DVDDoneReadCallback)(s32, DVDFileInfo*);
typedef void (*DVDOptionalCommandChecker)(DVDCommandBlock* block, DVDLowCallback callback);
typedef struct DVDDriveInfo {
u16 revisionLevel;
u16 deviceCode;
u32 releaseDate;
u8 padding[24];
} DVDDriveInfo;
typedef struct DVDDiskID {
char gameName[4];
char company[2];
u8 diskNumber;
u8 gameVersion;
u8 streaming;
u8 streamBufSize;
u8 padding[22];
} DVDDiskID;
struct DVDCommandBlock {
DVDCommandBlock* next;
DVDCommandBlock* prev;
u32 command;
s32 state;
u32 offset;
u32 length;
void* addr;
u32 currTransferSize;
u32 transferredSize;
DVDDiskID* id;
DVDCBCallback callback;
void* userData;
};
struct DVDFileInfo
{
DVDCommandBlock cb;
u32 startAddr;
u32 length;
DVDCallback callback;
};
typedef struct DVDDir {
u32 entryNum;
u32 location;
u32 next;
} DVDDir;
typedef struct DVDDirEntry {
u32 entryNum;
BOOL isDir;
char* name;
} DVDDirEntry;
typedef struct DVDQueue DVDQueue;
struct DVDQueue {
DVDQueue* mHead;
DVDQueue* mTail;
};
typedef struct DVDBB1 {
u32 appLoaderLength;
void* appLoaderFunc1;
void* appLoaderFunc2;
void* appLoaderFunc3;
} DVDBB1;
typedef struct DVDBB2 {
u32 bootFilePosition;
u32 FSTPosition;
u32 FSTLength;
u32 FSTMaxLength;
void* FSTAddress;
u32 userPosition;
u32 userLength;
u32 reserved_1C;
} DVDBB2;
void DVDInit();
BOOL DVDOpen(char* filename, DVDFileInfo* fileInfo);
BOOL DVDFastOpen(s32 entryNum, DVDFileInfo* fileInfo);
s32 DVDReadPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, s32 prio);
BOOL DVDReadAsyncPrio(DVDFileInfo* fileInfo, void* addr, s32 length, s32 offset, DVDCallback callback, s32 prio);
BOOL DVDClose(DVDFileInfo* fileInfo);
void DVDResume();
void DVDReset();
BOOL DVDCancelAsync(DVDCommandBlock* block, DVDCBCallback callback);
s32 DVDCancel(volatile DVDCommandBlock* block);
s32 DVDChangeDisk(DVDCommandBlock* block, DVDDiskID* id);
BOOL DVDChangeDiskAsync(DVDCommandBlock* block, DVDDiskID* id, DVDCBCallback callback);
s32 DVDGetCommandBlockStatus(const DVDCommandBlock* block);
s32 DVDGetDriveStatus();
BOOL DVDSetAutoInvalidation(BOOL doAutoInval);
void* DVDGetFSTLocation();
BOOL DVDOpenDir(char* dirName, DVDDir* dir);
BOOL DVDReadDir(DVDDir* dir, DVDDirEntry* dirEntry);
BOOL DVDCloseDir(DVDDir* dir);
BOOL DVDGetCurrentDir(char* path, u32 maxLength);
BOOL DVDChangeDir(char* dirName);
s32 DVDConvertPathToEntrynum(char* path);
s32 DVDGetTransferredSize(DVDFileInfo* fileInfo);
DVDDiskID* DVDGetCurrentDiskID();
BOOL DVDCompareDiskID(DVDDiskID* id1, DVDDiskID* id2);
DVDLowCallback DVDLowClearCallback();
BOOL DVDPrepareStreamAsync(DVDFileInfo* fileInfo, u32 length, u32 offset, DVDCallback callback);
s32 DVDCancelStream(DVDCommandBlock* block);
BOOL DVDCheckDisk();
void DVDPause();
s32 DVDSeekPrio(DVDFileInfo* fileInfo, s32 offset, s32 prio);
BOOL DVDSeekAsyncPrio(DVDFileInfo* fileInfo, s32 offset, DVDCallback callback, s32 prio);
BOOL DVDFastOpenDir(s32 entryNum, DVDDir* dir);
BOOL DVDCancelAllAsync(DVDCBCallback callback);
s32 DVDCancelAll();
void DVDDumpWaitingQueue();
DVDDiskID DiskID : (0x80000000) ;
};
extern "C"{
typedef struct CResTIMG {
u8 mTextureFormat;
u8 mTransparency;
u16 mSizeX;
u16 mSizeY;
u8 mWrapS;
u8 mWrapT;
u8 mPaletteFormat;
u8 mColorFormat;
u16 mPaletteEntryCount;
u32 mPaletteOffset;
GXBool mIsMIPmapEnabled;
GXBool mDoEdgeLOD;
GXBool mIsBiasClamp;
GXBool mIsMaxAnisotropy;
u8 mMinFilterType;
u8 mMagFilterType;
s8 mMinLOD;
s8 mMaxLOD;
u8 mTotalImageCount;
u8 _19;
s16 mLODBias;
u32 mImageDataOffset;
} CResTIMG;
enum resource_index {
RESOURCE_FGDATA,
RESOURCE_MAIL,
RESOURCE_MAIL_TABLE,
RESOURCE_MAILA,
RESOURCE_MAILA_TABLE,
RESOURCE_MAILB,
RESOURCE_MAILB_TABLE,
RESOURCE_MAILC,
RESOURCE_MAILC_TABLE,
RESOURCE_PALLET_BOY,
RESOURCE_PS,
RESOURCE_PS_TABLE,
RESOURCE_PSZ,
RESOURCE_PSZ_TABLE,
RESOURCE_SELECT,
RESOURCE_SELECT_TABLE,
RESOURCE_STRING,
RESOURCE_STRING_TABLE,
RESOURCE_SUPERZ,
RESOURCE_SUPERZ_TABLE,
RESOURCE_SUPER,
RESOURCE_SUPER_TABLE,
RESOURCE_TEX_BOY,
RESOURCE_FACE_BOY,
RESOURCE_FGNPCDATA,
RESOURCE_MESSAGE,
RESOURCE_MESSAGE_TABLE,
RESOURCE_MY_ORIGINAL,
RESOURCE_NEEDLEWORK_JOYBOOT,
RESOURCE_PLAYER_ROOM_FLOOR,
RESOURCE_PLAYER_ROOM_WALL,
RESOURCE_NPC_NAME_STR_TABLE,
RESOURCE_D_OBJ_NPC_STOCK_SCH,
RESOURCE_D_OBJ_NPC_STOCK_SCL,
RESOURCE_TITLE,
RESOURCE_MURA_SPRING,
RESOURCE_MURA_SUMMER,
RESOURCE_MURA_FALL,
RESOURCE_MURA_WINTER,
RESOURCE_ODEKAKE,
RESOURCE_OMAKE,
RESOURCE_EKI1,
RESOURCE_EKI1_2,
RESOURCE_EKI1_3,
RESOURCE_EKI1_4,
RESOURCE_EKI1_5,
RESOURCE_EKI2,
RESOURCE_EKI2_2,
RESOURCE_EKI2_3,
RESOURCE_EKI2_4,
RESOURCE_EKI2_5,
RESOURCE_EKI3,
RESOURCE_EKI3_2,
RESOURCE_EKI3_3,
RESOURCE_EKI3_4,
RESOURCE_EKI3_5,
RESOURCE_TEGAMI,
RESOURCE_TEGAMI2,
RESOURCE_FAMIKON,
RESOURCE_BOY1,
RESOURCE_BOY2,
RESOURCE_BOY3,
RESOURCE_BOY4,
RESOURCE_BOY5,
RESOURCE_BOY6,
RESOURCE_BOY7,
RESOURCE_BOY8,
RESOURCE_GIRL1,
RESOURCE_GIRL2,
RESOURCE_GIRL3,
RESOURCE_GIRL4,
RESOURCE_GIRL5,
RESOURCE_GIRL6,
RESOURCE_GIRL7,
RESOURCE_GIRL8,
RESOURCE_D_BG_ISLAND_SCH,
RESOURCE_NUM
};
enum {
JUT_MAINSTICK_UP = 0x8000000,
JUT_MAINSTICK_DOWN = 0x4000000,
JUT_MAINSTICK_RIGHT = 0x2000000,
JUT_MAINSTICK_LEFT = 0x1000000,
JUT_CSTICK_UP = 0x80000,
JUT_CSTICK_DOWN = 0x40000,
JUT_CSTICK_RIGHT = 0x20000,
JUT_CSTICK_LEFT = 0x10000,
JUT_START = 0x1000,
JUT_Y = 0x800,
JUT_X = 0x400,
JUT_B = 0x200,
JUT_A = 0x100,
JUT_L = 0x40,
JUT_R = 0x20,
JUT_Z = 0x10,
JUT_DPAD_UP = 0x8,
JUT_DPAD_DOWN = 0x4,
JUT_DPAD_RIGHT = 0x2,
JUT_DPAD_LEFT = 0x1
};
extern void JW_UpdateVideoMode();
extern void JW_SetProgressiveMode(int enabled);
extern void JW_SetLowResoMode(int enabled);
extern void JW_SetFamicomMode(int enabled);
extern void JW_SetVideoPan(u16 origin_x, u16 origin_y, u16 width, u16 height);
extern void JW_SetLogoMode(int enabled);
extern void JW_JUTGamePad_read();
extern void JW_getPadStatus(PADStatus* padStatus);
extern int JW_JUTGamepad_getErrorStatus();
extern u32 JW_JUTGamepad_getButton();
extern u32 JW_JUTGamepad_getTrigger();
extern f32 JW_JUTGamepad_getSubStickValue();
extern s16 JW_JUTGamepad_getSubStickAngle();
extern void JW_BeginFrame();
extern void JW_EndFrame();
extern int JW_setClearColor(u8 r, u8 g, u8 b);
extern u32 JW_GetAramAddress(int res_no);
extern u8* _JW_GetResourceAram(u32 aram_addr, u8* dst, u32 size);
extern u32 JW_GetResSizeFileNo(int res_no);
extern void JW_Init();
extern void JW_Init2();
extern void JW_Init3();
extern void JW_Cleanup();
}
extern "C"{
typedef int OSHeapHandle;
extern volatile OSHeapHandle __OSCurrHeap;
void* OSAllocFromHeap(int heap, unsigned long size);
void* OSAllocFixed(void* rstart, void* rend);
void OSFreeToHeap(int heap, void* ptr);
int OSSetCurrentHeap(int heap);
void* OSInitAlloc(void* arenaStart, void* arenaEnd, int maxHeaps);
int OSCreateHeap(void* start, void* end);
void OSDestroyHeap(int heap);
void OSAddToHeap(int heap, void* start, void* end);
long OSCheckHeap(int heap);
unsigned long OSReferentSize(void* ptr);
void OSDumpHeap(int heap);
void OSVisitAllocated(void (*visitor)(void*, unsigned long));
}
extern "C"{
void* OSGetArenaHi(void);
void* OSGetArenaLo(void);
void OSSetArenaHi(void*);
void OSSetArenaLo(void*);
}
extern "C"{
void DCEnable(void);
void DCInvalidateRange(void*, u32);
void DCFlushRange(void*, u32);
void DCStoreRange(void*, u32);
void DCFlushRangeNoSync(void*, u32);
void DCStoreRangeNoSync(void*, u32);
void DCZeroRange(void*, u32);
void DCTouchRange(void*, u32 len);
void ICInvalidateRange(void*, u32);
void ICFlashInvalidate(void);
void ICEnable(void);
void LCDisable(void);
}
extern "C"{
typedef u16 OSError;
typedef void (*OSErrorHandler)(OSError error, OSContext *context, ...);
typedef void (*OSErrorHandlerEx)(OSError error, OSContext* context, ...);
OSErrorHandler OSSetErrorHandler(OSError error, OSErrorHandler handler);
extern OSErrorHandler __OSErrorTable[(15 + 1) ];
extern u32 __OSFpscrEnableBits;
}
extern "C"{
typedef u8 __OSException;
typedef void (*__OSExceptionHandler)(__OSException exception, OSContext* context);
__OSExceptionHandler __OSSetExceptionHandler(__OSException exception, __OSExceptionHandler handler);
__OSExceptionHandler __OSGetExceptionHandler(__OSException exception);
}
extern "C"{
typedef s16 __OSInterrupt;
typedef u32 OSInterruptMask;
typedef enum OSInterruptType {
OS_INTR_MEM_0,
OS_INTR_MEM_1,
OS_INTR_MEM_2,
OS_INTR_MEM_3,
OS_INTR_MEM_ADDRESS,
OS_INTR_DSP_AI,
OS_INTR_DSP_ARAM,
OS_INTR_DSP_DSP,
OS_INTR_AI_AI,
OS_INTR_EXI_0_EXI,
OS_INTR_EXI_0_TC,
OS_INTR_EXI_0_EXT,
OS_INTR_EXI_1_EXI,
OS_INTR_EXI_1_TC,
OS_INTR_EXI_1_EXT,
OS_INTR_EXI_2_EXI,
OS_INTR_EXI_2_TC,
OS_INTR_PI_CP,
OS_INTR_PI_PE_TOKEN,
OS_INTR_PI_PE_FINISH,
OS_INTR_PI_SI,
OS_INTR_PI_DI,
OS_INTR_PI_RSW,
OS_INTR_PI_ERROR,
OS_INTR_PI_VI,
OS_INTR_PI_DEBUG,
OS_INTR_PI_HSP,
OS_INTR_PI_ACR,
OS_INTR_28,
OS_INTR_29,
OS_INTR_30,
OS_INTR_31,
OS_INTR_MAX
} OSInterruptType;
typedef void (*__OSInterruptHandler)(__OSInterrupt, OSContext*);
extern volatile u32 __OSLastInterruptSrr0;
extern volatile s16 __OSLastInterrupt;
extern volatile s64 __OSLastInterruptTime;
void __RAS_OSDisableInterrupts_begin(void);
void __RAS_OSDisableInterrupts_end(void);
BOOL OSDisableInterrupts(void);
BOOL OSEnableInterrupts(void);
BOOL OSRestoreInterrupts(BOOL);
__OSInterruptHandler __OSSetInterruptHandler(__OSInterrupt, __OSInterruptHandler);
__OSInterruptHandler __OSGetInterruptHandler(__OSInterrupt);
void __OSInterruptInit(void);
u32 __OSMaskInterrupts(u32);
u32 __OSUnmaskInterrupts(u32);
u32 SetInterruptMask(OSInterruptMask mask, OSInterruptMask current);
void __OSDispatchInterrupt(__OSException exception, OSContext* context);
}
extern "C"{
}
extern
"C"{
};
extern "C"{
typedef struct OSModuleHeader OSModuleHeader;
typedef u32 OSModuleID;
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
OSModuleQueue __OSModuleList : (0x800030C8) ;
void* __OSStringTable : (0x800030D0) ;
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u8 bssSection;
u32 prolog;
u32 epilog;
u32 unresolved;
u32 align;
u32 bssAlign;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSLinkFixed(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* module);
void OSSetStringTable(const void* string_table);
void __OSModuleInit(void);
};
extern "C"{
static void Config24MB();
static void Config48MB();
u32 OSGetConsoleSimulatedMemSize(void);
void OSProtectRange(u32 chan, void* addr, u32 nBytes, u32 control);
}
extern "C"{
typedef struct OSMessageQueue OSMessageQueue;
typedef void* OSMessage;
struct OSMessageQueue {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
int msgCount;
int firstIndex;
int usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, int msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, int flags);
};
extern
"C"{
struct OSMutex
{
OSThreadQueue queue;
OSThread *thread;
s32 count;
OSMutexLink link;
};
struct OSCond
{
OSThreadQueue queue;
};
void OSInitMutex(OSMutex *mutex);
void OSLockMutex(OSMutex *mutex);
void OSUnlockMutex(OSMutex *mutex);
BOOL OSTryLockMutex(OSMutex *mutex);
void OSInitCond(OSCond *cond);
void OSWaitCond(OSCond *cond, OSMutex *mutex);
void OSSignalCond(OSCond *cond);
}
extern "C"{
extern void my_fopen();
extern void my_fgets();
extern void my_fclose();
extern void print_section();
extern void* OSGetCallerPC();
extern void OSDumpStackTrace();
extern s32 OSGetActiveThreadID();
extern void OSReportMonopoly();
extern void OSReportDisable();
extern void OSReportEnable();
extern void OSChangeBootMode(u32 mode);
extern void OSDVDFatalError();
}
extern "C"{
struct OSResetFunctionQueue {
struct OSResetFunctionInfo* head;
struct OSResetFunctionInfo* tail;
};
typedef BOOL (*OSResetFunction)(BOOL final);
typedef struct OSResetFunctionInfo OSResetFunctionInfo;
struct OSResetFunctionInfo {
OSResetFunction func;
u32 priority;
OSResetFunctionInfo* next;
OSResetFunctionInfo* prev;
};
u32 OSGetResetCode();
void OSResetSystem(int reset, u32 resetCode, BOOL forceMenu);
BOOL OSGetResetSwitchState();
void OSGetSaveRegion(void** start, void** end);
void OSRegisterResetFunction(OSResetFunctionInfo* info);
}
extern "C"{
typedef struct OSFontHeader {
u16 fontType;
u16 firstChar;
u16 lastChar;
u16 invalChar;
u16 ascent;
u16 descent;
u16 width;
u16 leading;
u16 cellWidth;
u16 cellHeight;
u32 sheetSize;
u16 sheetFormat;
u16 sheetColumn;
u16 sheetRow;
u16 sheetWidth;
u16 sheetHeight;
u16 widthTable;
u32 sheetImage;
u32 sheetFullSize;
u8 c0;
u8 c1;
u8 c2;
u8 c3;
} OSFontHeader;
u16 OSGetFontEncode(void);
u16 OSSetFontEncode(u16 encode);
}
extern "C"{
typedef s64 OSTime;
typedef u32 OSTick;
OSTime OSGetTime(void);
OSTime __OSGetSystemTime(void);
OSTick OSGetTick(void);
typedef struct OSCalendarTime_s {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* td);
}
extern "C"{
typedef struct OSAlarm OSAlarm;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm
{
OSAlarmHandler handler;
OSTime fire;
OSAlarm *prev;
OSAlarm *next;
OSTime period;
OSTime start;
};
void OSInitAlarm(void);
void OSSetAlarm(OSAlarm *alarm, OSTime tick, OSAlarmHandler handler);
void OSSetAbsAlarm(OSAlarm *alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm *alarm, OSTime start, OSTime period,
OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm *alarm);
void OSCancelAlarm(OSAlarm *alarm);
BOOL OSCheckAlarmQueue(void);
}
extern "C"{
typedef enum {
EXI_STATE_DMA_ACCESS = (1 << 0),
EXI_STATE_IMM_ACCESS = (1 << 1),
EXI_STATE_SELECTED = (1 << 2),
EXI_STATE_ATTACHED = (1 << 3),
EXI_STATE_LOCKED = (1 << 4),
EXI_STATE_BUSY = EXI_STATE_DMA_ACCESS | EXI_STATE_IMM_ACCESS
} EXIState;
typedef enum {
EXI_CHAN_0,
EXI_CHAN_1,
EXI_CHAN_2,
EXI_MAX_CHAN
} EXIChannel;
typedef enum {
EXI_READ,
EXI_WRITE,
EXI_TYPE_2,
EXI_MAX_TYPE
} EXIType;
typedef void (*EXICallback)(s32 chan, OSContext *context);
EXICallback EXISetExiCallback(s32 channel, EXICallback callback);
void EXIInit(void);
BOOL EXILock(s32 channel, u32 device, EXICallback callback);
BOOL EXIUnlock(s32 channel);
BOOL EXISelect(s32 channel, u32 device, u32 frequency);
BOOL EXIDeselect(s32 channel);
BOOL EXIImm(s32 channel, void *buffer, s32 length, u32 type, EXICallback callback);
BOOL EXIImmEx(s32 channel, void *buffer, s32 length, u32 type);
BOOL EXIDma(s32 channel, void *buffer, s32 length, u32 type, EXICallback callback);
BOOL EXISync(s32 channel);
BOOL EXIProbe(s32 channel);
s32 EXIProbeEx(s32 channel);
BOOL EXIAttach(s32 channel, EXICallback callback);
BOOL EXIDetach(s32 channel);
u32 EXIGetState(s32 channel);
s32 EXIGetID(s32 channel, u32 device, u32* id);
void EXIProbeReset(void);
}
extern "C"{
typedef struct OSSram {
u16 checkSum;
u16 checkSumInv;
u32 ead0;
u32 ead1;
u32 counterBias;
s8 displayOffsetH;
u8 ntd;
u8 language;
u8 flags;
} OSSram;
typedef struct OSSramEx {
u8 flashID[2][12];
u32 wirelessKeyboardID;
u16 wirelessPadID[4];
u8 dvdErrorCode;
u8 pad0;
u8 flashIDCheckSum[2];
u16 gbs;
u8 pad1[2];
} OSSramEx;
typedef struct SramControlBlock {
u8 sram[64 ];
u32 offset;
BOOL enabled;
BOOL locked;
BOOL sync;
void (*callback)(void);
} SramControlBlock;
static inline BOOL ReadSram(void* buffer);
static void WriteSramCallback(s32 chan, OSContext* ctx);
static BOOL WriteSram(void* buffer, u32 offset, u32 size);
extern void __OSInitSram();
static inline void* LockSram(u32 offset);
extern OSSram* __OSLockSram();
extern OSSramEx* __OSLockSramEx();
static BOOL UnlockSram(BOOL commit, u32 offset);
extern BOOL __OSSyncSram();
extern u32 OSGetSoundMode();
extern void OSSetSoundMode(u32 mode);
extern u32 OSGetProgressiveMode();
extern void OSSetProgressiveMode(u32 on);
extern void __OSSetBootMode(u8 mode);
extern u16 OSGetWirelessID(s32 chan);
extern void OSSetWirelessID(s32 chan, u16 id);
}
volatile u16 __VIRegs[59] : 0xCC002000;
volatile u32 __PIRegs[12] : 0xCC003000;
volatile u16 __MEMRegs[64] : 0xCC004000;
volatile u16 __DSPRegs[] : 0xCC005000;
volatile u32 __DIRegs[] : 0xCC006000;
volatile u32 __SIRegs[0x100] : 0xCC006400;
volatile u32 __EXIRegs[0x40] : 0xCC006800;
volatile u32 __AIRegs[8] : 0xCC006C00;
extern "C"{
extern void __OSPSInit();
extern void __OSFPRInit();
extern void __OSCacheInit();
void OSPanic(const char* file, int line, const char* message, ...);
void OSVReport(const char* fmt, va_list list);
void OSReport(const char* fmt, ...);
extern void __OSPSInit();
extern void __OSCacheInit();
void OSInit(void);
u32 OSGetConsoleType();
typedef void (*OSExceptionHandler)(u8, OSContext*);
OSExceptionHandler __OSSetExceptionHandler(u8, OSExceptionHandler);
typedef struct OSBootInfo_s {
DVDDiskID DVDDiskID;
unsigned long magic;
unsigned long version;
unsigned long memorySize;
unsigned long consoleType;
void * arenaLo;
void * arenaHi;
void * FSTLocation;
unsigned long FSTMaxLength;
} OSBootInfo;
typedef struct BI2Debug {
s32 debugMonSize;
s32 simMemSize;
u32 argOffset;
u32 debugFlag;
int trackLocation;
int trackSize;
u32 countryCode;
u8 unk[8];
u32 padSpec;
} BI2Debug;
u32 __OSPhysicalMemSize : ((0x8000 << 16) | 0x0028);
volatile int __OSTVMode : ((0x8000 << 16) | 0x00CC);
OSThread *__gUnkThread1 : ((0x8000 << 16) | 0x00D8);
OSThreadQueue __OSActiveThreadQueue : ((0x8000 << 16) | 0x00DC);
OSThread *__gCurrentThread : ((0x8000 << 16) | 0x00E4);
u32 __OSSimulatedMemSize : ((0x8000 << 16) | 0x00F0);
u32 __OSBusClock : ((0x8000 << 16) | 0x00F8);
u32 __OSCoreClock : ((0x8000 << 16) | 0x00FC);
s32 __gUnknown800030C0[2] : ((0x8000 << 16) | 0x30C0);
u8 __gUnknown800030E3 : ((0x8000 << 16) | 0x30E3);
vu16 __OSDeviceCode : ((0x8000 << 16) | 0x30E6) ;
void *OSPhysicalToCached(u32 paddr);
void *OSPhysicalToUncached(u32 paddr);
u32 OSCachedToPhysical(void *caddr);
u32 OSUncachedToPhysical(void *ucaddr);
void *OSCachedToUncached(void *caddr);
void *OSUncachedToCached(void *ucaddr);
}
class JSUPtrLink;
class JSUPtrList {
public:
JSUPtrList() {
initiate();
}
JSUPtrList(bool);
~JSUPtrList();
void initiate();
void setFirst(JSUPtrLink*);
bool append(JSUPtrLink*);
bool prepend(JSUPtrLink*);
bool insert(JSUPtrLink*, JSUPtrLink*);
bool remove(JSUPtrLink*);
JSUPtrLink* getNthLink(u32 idx) const;
JSUPtrLink* getFirstLink() const {
return mHead;
}
JSUPtrLink* getLastLink() const {
return mTail;
}
u32 getNumLinks() const {
return mLinkCount;
}
JSUPtrLink* mHead;
JSUPtrLink* mTail;
u32 mLinkCount;
};
class JSUPtrLink {
public:
JSUPtrLink(void*);
~JSUPtrLink();
void* getObjectPtr() const {
return mData;
}
JSUPtrList* getList() const {
return mPtrList;
}
JSUPtrLink* getNext() const {
return mNext;
}
JSUPtrLink* getPrev() const {
return mPrev;
}
void* mData;
JSUPtrList* mPtrList;
JSUPtrLink* mPrev;
JSUPtrLink* mNext;
};
template <class T> class JSULink;
template <class T> class JSUList : public JSUPtrList {
public:
JSUList(bool thing) : JSUPtrList(thing) {
}
JSUList() : JSUPtrList() {
}
bool append(JSULink<T>* link) {
return JSUPtrList::append((JSUPtrLink*)link);
}
bool prepend(JSULink<T>* link) {
return JSUPtrList::prepend((JSUPtrLink*)link);
}
bool insert(JSULink<T>* before, JSULink<T>* link) {
return JSUPtrList::insert((JSUPtrLink*)before, (JSUPtrLink*)link);
}
bool remove(JSULink<T>* link) {
return JSUPtrList::remove((JSUPtrLink*)link);
}
JSULink<T>* getFirst() const {
return (JSULink<T>*)getFirstLink();
}
JSULink<T>* getLast() const {
return (JSULink<T>*)getLastLink();
}
JSULink<T>* getEnd() const {
return 0 ;
}
u32 getNumLinks() const {
return mLinkCount;
}
};
template <typename T> class JSUListIterator {
public:
JSUListIterator() : mLink(0 ) {
}
JSUListIterator(JSULink<T>* link) : mLink(link) {
}
JSUListIterator(JSUList<T>* list) : mLink(list->getFirst()) {
}
JSUListIterator<T>& operator=(JSULink<T>* link) {
this->mLink = link;
return *this;
}
T* getObject() {
return this->mLink->getObject();
}
bool operator==(JSULink<T> const* other) const {
return this->mLink == other;
}
bool operator!=(JSULink<T> const* other) const {
return this->mLink != other;
}
bool operator==(JSUListIterator<T> const& other) const {
return this->mLink == other.mLink;
}
bool operator!=(JSUListIterator<T> const& other) const {
return this->mLink != other.mLink;
}
JSUListIterator<T> operator++(int) {
JSUListIterator<T> prev = *this;
this->mLink = this->mLink->getNext();
return prev;
}
JSUListIterator<T>& operator++() {
this->mLink = this->mLink->getNext();
return *this;
}
JSUListIterator<T> operator--(int) {
JSUListIterator<T> prev = *this;
this->mLink = this->mLink->getPrev();
return prev;
}
JSUListIterator<T>& operator--() {
this->mLink = this->mLink->getPrev();
return *this;
}
T& operator*() {
return *this->getObject();
}
T* operator->() {
return this->getObject();
}
JSULink<T>* mLink;
};
template <class T> class JSULink : public JSUPtrLink {
public:
JSULink(void* pData) : JSUPtrLink(pData) {
}
T* getObject() const {
return (T*)mData;
}
JSUList<T>* getList() const {
return (JSUList<T>*)JSUPtrLink::getList();
}
JSULink<T>* getNext() const {
return (JSULink<T>*)JSUPtrLink::getNext();
}
JSULink<T>* getPrev() const {
return (JSULink<T>*)JSUPtrLink::getPrev();
}
~JSULink() {
}
};
template <typename T>
class JSUTree : public JSUList<T>, public JSULink<T> {
public:
JSUTree(T* owner) : JSUList<T>(), JSULink<T>(owner) {
}
~JSUTree() {
}
bool appendChild(JSUTree<T>* child) {
return this->append(child);
}
bool prependChild(JSUTree<T>* child) {
return this->prepend(child);
}
bool removeChild(JSUTree<T>* child) {
return this->remove(child);
}
bool insertChild(JSUTree<T>* before, JSUTree<T>* child) {
return this->insert(before, child);
}
JSUTree<T>* getEndChild() const {
return 0 ;
}
JSUTree<T>* getFirstChild() const {
return (JSUTree<T>*)this->getFirstLink();
}
JSUTree<T>* getLastChild() const {
return (JSUTree<T>*)this->getLast();
}
JSUTree<T>* getNextChild() const {
return (JSUTree<T>*)this->mNext;
}
JSUTree<T>* getPrevChild() const {
return (JSUTree<T>*)this->getPrev();
}
u32 getNumChildren() const {
return this->mLinkCount;
}
T* getObject() const {
return (T*)this->mData;
}
JSUTree<T>* getParent() const {
return (JSUTree<T>*)this->mPtrList;
}
};
template <typename T> class JSUTreeIterator {
public:
JSUTreeIterator() : mTree(0 ) {
}
JSUTreeIterator(JSUTree<T>* tree) : mTree(tree) {
}
JSUTreeIterator<T>& operator=(JSUTree<T>* tree) {
this->mTree = tree;
return *this;
}
T* getObject() const {
return mTree->getObject();
}
bool operator==(JSUTree<T>* other) {
return this->mTree == other;
}
bool operator!=(const JSUTree<T>* other) const {
return this->mTree != other;
}
JSUTreeIterator<T> operator++(int) {
JSUTreeIterator<T> prev = *this;
this->mTree = this->mTree->getNextChild();
return prev;
}
JSUTreeIterator<T>& operator++() {
this->mTree = this->mTree->getNextChild();
return *this;
}
T& operator*() {
return *this->getObject();
}
T* operator->() const {
return mTree->getObject();
}
private:
JSUTree<T>* mTree;
};
extern "C"{
class JKRHeap;
class JKRDisposer {
public:
JKRDisposer();
virtual ~JKRDisposer();
public:
JKRHeap* mRootHeap;
JSULink<JKRDisposer> mPointerLinks;
};
}
extern "C"{
namespace JUTAssertion {
void create();
void flushMessage();
void flushMessage_dbPrint();
u32 getSDevice(void);
void changeDisplayTime(u32 time);
void changeDevice(u32 device);
void showAssert_f(u32 device, char const* file, int line, char const* errormsg, ...);
inline void showAssert(u32 device, char const* file, int line, char const* errormsg) {
showAssert_f(device, file, line, "%s", errormsg);
}
void setConfirmMessage(u32 device, char* file, int line, bool condition, const char* msg);
void setWarningMessage_f(u32 device, char* file, int line, char const*, ...);
inline void setWarningMessage(u32 device, char* file, int line, char const* errormsg) {
setWarningMessage_f(device, file, line, "%s", errormsg);
}
void setLogMessage_f(u32 device, char* file, int line, char const* fmt, ...);
extern "C"{
void showAssert_f_va(u32 device, const char* file, int line, const char* fmt, va_list vl);
void setWarningMessage_f_va(u32 device, char* file, int line, const char* fmt, va_list vl);
void setLogMessage_f_va(u32 device, char* file, int line, const char* fmt, va_list vl);
}
}
}
extern "C"{
class JUTGamePadRecordBase {
public:
JUTGamePadRecordBase();
virtual ~JUTGamePadRecordBase();
virtual void read(PADStatus* status) = 0;
virtual void write(PADStatus* status) = 0;
bool mActive;
bool isActive() {
return this->mActive;
}
};
typedef void (*JUTResetBtnCb)(int, void*);
class JUTGamePad : public JKRDisposer {
public:
enum EPadPort { Port_unknown = -999, Port_Invalid = -1, Port1 = 0, Port2, Port3, Port4, PortRecorder };
enum EButtons {
MAINSTICK_UP = 0x8000000,
MAINSTICK_DOWN = 0x4000000,
MAINSTICK_RIGHT = 0x2000000,
MAINSTICK_LEFT = 0x1000000,
CSTICK_UP = 0x80000,
CSTICK_DOWN = 0x40000,
CSTICK_RIGHT = 0x20000,
CSTICK_LEFT = 0x10000,
START = 0x1000,
Y = 0x800,
X = 0x400,
B = 0x200,
A = 0x100,
L = 0x40,
R = 0x20,
Z = 0x10,
DPAD_UP = 0x8,
DPAD_DOWN = 0x4,
DPAD_RIGHT = 0x2,
DPAD_LEFT = 0x1
};
enum EStickMode { NonClamped, Clamped };
enum EClampMode { NoClamp, Clamp, ClampCircle };
enum EWhichStick { WhichStick_MainStick, WhichStick_SubStick };
JUTGamePad();
JUTGamePad(EPadPort port);
virtual ~JUTGamePad();
void assign();
void checkResetCallback(OSTime time);
void clearForReset();
static void init();
void initList();
static void read();
static bool recalibrate(u32);
void setButtonRepeat(u32, u32, u32);
void update();
void clear();
static void checkResetSwitch();
static bool mListInitialized;
static u8 mPadAssign[4 ];
static u32 mSuppressPadReset;
static u32 sAnalogMode;
static void setAnalogMode(u32 mode) {
JUTGamePad::sAnalogMode = mode;
PADSetAnalogMode(mode);
}
static void setResetCallback(JUTResetBtnCb callback, void* arg) {
C3ButtonReset::sCallback = callback;
C3ButtonReset::sCallbackArg = arg;
}
static void clearResetOccurred() {
C3ButtonReset::sResetOccurred = false;
}
static EClampMode getClampMode() {
return JUTGamePad::sClampMode;
}
static s8 getPortStatus(EPadPort port)
{
;
return mPadStatus[port].err;
}
bool isPushing3ButtonReset() const {
bool pushing = false;
if (this->mPortNum != -1 && this->mButtonReset.mReset != false) {
pushing = true;
}
return pushing;
}
int getErrorStatus() const {
return this->mErrorStatus;
}
u8 getAnalogR() const {
return this->mButtons.mAnalogR;
}
f32 getAnalogRf() const {
return this->mButtons.mAnalogRf;
}
u8 getAnalogL() const {
return this->mButtons.mAnalogL;
}
f32 getAnalogLf() const {
return this->mButtons.mAnalogLf;
}
u8 getAnalogB() const {
return this->mButtons.mAnalogB;
}
u8 getAnalogA() const {
return this->mButtons.mAnalogA;
}
int getSubStickAngle() const {
return this->mSubStick.mAngle;
}
f32 getSubStickValue() const {
return this->mSubStick.mValue;
}
f32 getSubStickY() const {
return this->mSubStick.mY;
}
f32 getSubStickX() const {
return this->mSubStick.mX;
}
int getMainStickAngle() const {
return this->mMainStick.mAngle;
}
f32 getMainStickValue() const {
return this->mMainStick.mValue;
}
f32 getMainStickY() const {
return this->mMainStick.mY;
}
f32 getMainStickX() const {
return this->mMainStick.mX;
}
u32 getTrigger() const {
return this->mButtons.mTrigger;
}
u32 getButton() const {
return this->mButtons.mButton;
}
u32 getRelease() const {
return this->mButtons.mRelease;
}
u32 getRepeat() const {
return this->mButtons.mRepeat;
}
bool testButton(u32 mask) const {
return this->mButtons.mButton & mask;
}
bool testTrigger(u32 mask) const {
return this->mButtons.mTrigger & mask;
}
s16 getPortNum() const {
return this->mPortNum;
}
JUTGamePadRecordBase* getPadRecord() const {
return this->mPadRecord;
}
JUTGamePadRecordBase* getPadReplay() const {
return this->mPadReplay;
}
class CButton {
public:
CButton() {
this->clear();
};
void clear();
void update(const PADStatus* padStatus, u32 buttons);
void setRepeat(u32 mask, u32 delay, u32 frequency);
u32 mButton;
u32 mTrigger;
u32 mRelease;
u8 mAnalogA;
u8 mAnalogB;
u8 mAnalogL;
u8 mAnalogR;
f32 mAnalogLf;
f32 mAnalogRf;
u32 mRepeat;
u32 mRepeatTimer;
u32 mRepeatLastButton;
u32 mRepeatMask;
u32 mRepeatDelay;
u32 mRepeatFrequency;
};
class CStick {
public:
CStick() {
this->clear();
}
void clear();
u32 update(s8 x, s8 y, JUTGamePad::EStickMode, JUTGamePad::EWhichStick);
u32 getButton();
f32 mX;
f32 mY;
f32 mValue;
s16 mAngle;
};
class CRumble {
public:
enum ERumble { Rumble0, Rumble1, Rumble2 };
CRumble(JUTGamePad* gamePad) {
this->clear(gamePad);
}
static u8 mStatus[4 ];
static u32 mEnabled;
static void startMotor(int port);
static void stopMotor(int port);
static void stopMotorHard(int port);
static bool isEnabled(u32 channel) {
return (JUTGamePad::CRumble::mEnabled & channel) != 0;
}
void clear();
void clear(JUTGamePad* gamePad);
void update(s16);
void setEnable(u32);
u32 mFrame;
u32 mLength;
u8* mData;
u32 mFrameCount;
};
class C3ButtonReset {
public:
C3ButtonReset() {
mReset = false;
}
static u32 sResetPattern;
static u32 sResetMaskPattern;
static JUTResetBtnCb sCallback;
static void* sCallbackArg;
static OSTime sThreshold;
static bool sResetSwitchPushing;
static bool sResetOccurred;
static s32 sResetOccurredPort;
bool mReset;
};
static PADStatus* getPadStatus(int idx) {
return &mPadStatus[idx];
}
static JSUList<JUTGamePad> mPadList;
static CButton mPadButton[4 ];
static CStick mPadMStick[4 ];
static CStick mPadSStick[4 ];
static EStickMode sStickMode;
static EClampMode sClampMode;
static f32 sPressPoint;
static f32 sReleasePoint;
static PADStatus mPadStatus[4 ];
CButton mButtons;
CStick mMainStick;
CStick mSubStick;
CRumble mRumble;
s16 mPortNum;
s8 mErrorStatus;
JSULink<JUTGamePad> mLink;
JUTGamePadRecordBase* mPadRecord;
JUTGamePadRecordBase* mPadReplay;
u32 _94;
C3ButtonReset mButtonReset;
OSTime mResetTime;
};
}
extern "C"{
extern JUTGamePad gamePad[];
}
extern "C"{
typedef struct ARQRequest ARQRequest;
typedef void (*ARCallback)(void);
typedef void (*ARQCallback)(u32 ptrToRequest);
struct ARQRequest {
ARQRequest* next;
u32 owner;
u32 type;
u32 priority;
u32 source;
u32 dest;
u32 length;
ARQCallback callback;
};
void ARQInit();
void ARQPostRequest(ARQRequest* task, u32 owner, u32 type, u32 priority, u32 source, u32 dest, u32 length, ARQCallback callback);
ARQCallback ARRegisterDMACallback(ARQCallback callback);
u32 ARGetDMAStatus();
void ARStartDMA(u32 type, u32 mainmem_addr, u32 aram_addr, u32 length);
u32 ARAlloc(u32 length);
u32 ARInit(u32* stack_index_addr, u32 num_entries);
u32 ARGetBaseAddress();
u32 ARGetSize();
u32 ARFree(u32* length);
BOOL ARCheckInit();
void ARReset();
void ARSetSize();
u32 ARGetInternalSize();
void ARClear(u32 flag);
};
typedef void JKRHeapErrorHandler(void*, u32, int);
class JKRHeap : public JKRDisposer {
public:
enum EAllocMode {
HEAPALLOC_Unk1 = 1,
};
struct TState {
struct TLocation {
TLocation() : _00(0 ), _04(-1) {
}
void* _00;
int _04;
};
struct TArgument {
TArgument(const JKRHeap* heap, u32 p2, bool p3)
: mHeap((heap) ? heap : JKRHeap::sCurrentHeap), mId(p2), mIsCompareOnDestructed(p3) {
}
const JKRHeap* mHeap;
u32 mId;
bool mIsCompareOnDestructed;
};
TState(const JKRHeap* heap, u32 id, bool isCompareOnDestructed)
: mUsedSize(0), mCheckCode(0), mArgument(heap, id, isCompareOnDestructed) {
mArgument.mHeap->state_register(this, mArgument.mId);
}
TState(JKRHeap* heap) : mUsedSize(0), mCheckCode(0), mArgument(heap, 0xFFFFFFFF, true) {
}
~TState();
void dump() const {
mArgument.mHeap->state_dump(*this);
}
bool isVerbose() {
return bVerbose_;
};
bool isCompareOnDestructed() const {
return mArgument.mIsCompareOnDestructed;
};
u32 getUsedSize() const {
return mUsedSize;
}
u32 getCheckCode() const {
return mCheckCode;
}
const JKRHeap* getHeap() const {
return mArgument.mHeap;
}
u32 getId() const {
return mArgument.mId;
}
TState(const JKRHeap::TState::TArgument& arg, const JKRHeap::TState::TLocation& location);
TState(const JKRHeap::TState& other, bool p2);
TState(const JKRHeap::TState& other, const JKRHeap::TState::TLocation& location, bool p3);
static bool bVerbose_;
u32 mUsedSize;
u32 mCheckCode;
u32 mBuf;
u8 _0C[0x4];
TArgument mArgument;
TLocation mLocation;
};
public:
JKRHeap(void*, u32, JKRHeap*, bool);
bool setErrorFlag(bool errorFlag);
bool isSubHeap(JKRHeap* heap) const;
virtual ~JKRHeap();
virtual void callAllDisposer();
virtual void* do_alloc(u32, int) = 0;
virtual void do_free(void*) = 0;
virtual void do_freeAll() = 0;
virtual void do_freeTail() = 0;
virtual s32 do_resize(void*, u32) = 0;
virtual s32 do_getSize(void*) = 0;
virtual s32 do_getFreeSize() = 0;
virtual s32 do_getTotalFreeSize() = 0;
virtual u32 getHeapType() = 0;
virtual bool check() = 0;
virtual bool dump_sort() {
return true;
}
virtual bool dump() = 0;
virtual s32 do_changeGroupID(u8 newGroupID) {
return 0;
}
virtual u8 do_getCurrentGroupId() {
return 0;
}
virtual void state_register(JKRHeap::TState*, u32) const;
virtual bool state_compare(JKRHeap::TState const&, JKRHeap::TState const&) const;
virtual void state_dump(JKRHeap::TState const&) const;
JKRHeap* becomeSystemHeap();
JKRHeap* becomeCurrentHeap();
void destroy();
void* alloc(u32, int);
void free(void*);
void freeAll();
void freeTail();
void fillFreeArea();
s32 resize(void*, u32);
static s32 getSize(void*, JKRHeap*);
s32 getSize(void* ptr);
s32 getFreeSize();
void* getMaxFreeBlock();
s32 getTotalFreeSize();
u8 getCurrentGroupId();
s32 changeGroupID(u8 newGroupId);
u32 getMaxAllocatableSize(int alignment);
JKRHeap* find(void*) const;
JKRHeap* findAllHeap(void*) const;
void dispose_subroutine(u32 begin, u32 end);
bool dispose(void*, u32);
void dispose(void*, void*);
void dispose();
void appendDisposer(JKRDisposer* disposer) {
mDisposerList.append(&disposer->mPointerLinks);
}
void removeDisposer(JKRDisposer* disposer) {
mDisposerList.remove(&disposer->mPointerLinks);
}
void setDebugFill(bool debugFill) {
mDebugFill = debugFill;
}
bool getDebugFill() const {
return mDebugFill;
}
void* getStartAddr() const {
return (void*)mStart;
}
void* getEndAddr() const {
return (void*)mEnd;
}
u32 getHeapSize() const {
return mSize;
}
bool getErrorFlag() const {
return mErrorFlag;
}
void callErrorHandler(JKRHeap* heap, u32 size, int alignment) {
if (mErrorHandler) {
(*mErrorHandler)(heap, size, alignment);
}
}
static u32 getState_buf_(TState* state) {
return state->mBuf;
}
static void setState_u32ID_(TState* state, u32 id) {
state->mArgument.mId = id;
}
static void setState_uUsedSize_(TState* state, u32 usedSize) {
state->mUsedSize = usedSize;
}
static void setState_u32CheckCode_(TState* state, u32 checkCode) {
state->mCheckCode = checkCode;
}
void lock() const {
OSLockMutex(const_cast<OSMutex*>(&mMutex));
}
void unlock() const {
OSUnlockMutex(const_cast<OSMutex*>(&mMutex));
}
JKRHeap* getParent() {
return mChildTree.getParent()->getObject();
}
const JSUTree<JKRHeap>& getHeapTree() {
return mChildTree;
}
void checkMemoryFilled(u8*, u32 size, u8);
static void destroy(JKRHeap* heap);
static bool initArena(char**, u32*, int);
static void* alloc(u32, int, JKRHeap*);
static void copyMemory(void*, void*, u32);
static void free(void*, JKRHeap*);
static void state_dumpDifference(const TState&, const TState&);
static JKRHeap* findFromRoot(void*);
static JKRHeapErrorHandler* setErrorHandler(JKRHeapErrorHandler*);
static void* getCodeStart() {
return mCodeStart;
}
static void* getCodeEnd() {
return mCodeEnd;
}
static void* getUserRamStart() {
return mUserRamStart;
}
static void* getUserRamEnd() {
return mUserRamEnd;
}
static u32 getMemorySize() {
return mMemorySize;
}
static JKRHeap* getCurrentHeap() {
return sCurrentHeap;
}
static JKRHeap* getRootHeap() {
return sRootHeap;
}
static JKRHeap* getSystemHeap() {
return sSystemHeap;
}
static void* mCodeStart;
static void* mCodeEnd;
static void* mUserRamStart;
static void* mUserRamEnd;
static u32 mMemorySize;
static JKRHeap* sSystemHeap;
static JKRHeap* sCurrentHeap;
static JKRHeap* sRootHeap;
static bool sDefaultFillFlag;
static bool sDefaultFillCheckFlag;
static JKRHeapErrorHandler* mErrorHandler;
protected:
OSMutex mMutex;
void* mStart;
void* mEnd;
u32 mSize;
bool mDebugFill;
bool mCheckMemoryFilled;
u8 mAllocationMode;
u8 mGroupId;
JSUTree<JKRHeap> mChildTree;
JSUList<JKRDisposer> mDisposerList;
bool mErrorFlag;
bool mInitFlag;
u8 padding_0x6a[2];
};
inline JKRHeap* JKRGetCurrentHeap() {
return JKRHeap::getCurrentHeap();
}
inline JKRHeap* JKRGetSystemHeap() {
return JKRHeap::getSystemHeap();
}
inline JKRHeap* JKRGetRootHeap() {
return JKRHeap::getRootHeap();
}
inline void* JKRAllocFromSysHeap(u32 size, int alignment) {
return JKRHeap::getSystemHeap()->alloc(size, alignment);
}
inline void* JKRAllocFromHeap(JKRHeap* heap, u32 size, int alignment) {
return JKRHeap::alloc(size, alignment, heap);
}
inline void JKRFree(void* pBuf) {
JKRHeap::free(pBuf, 0 );
}
inline void JKRFreeToHeap(JKRHeap* heap, void* ptr) {
JKRHeap::free(ptr, heap);
}
inline void JKRFreeToSysHeap(void* buf) {
JKRHeap::getSystemHeap()->free(buf);
}
void JKRDefaultMemoryErrorRoutine(void*, u32, int);
void* operator new(size_t);
void* operator new(size_t, s32);
void* operator new(size_t, JKRHeap*, int);
inline void* operator new(size_t, void* buf) {
return buf;
}
void* operator new[](size_t);
void* operator new[](size_t, s32);
void* operator new[](size_t, JKRHeap*, int);
void operator delete(void*);
void operator delete[](void*);
extern "C"{
class JGadget_outMessage {
public:
typedef void (*MessageFunc)(const char*, int, const char*);
static void warning(const char*, int, const char*);
JGadget_outMessage(MessageFunc fn, const char* file, int line);
~JGadget_outMessage();
JGadget_outMessage& operator<<(const char* str);
private:
MessageFunc mMsgFunc;
char mBuffer[256];
char* mWrite_p;
char* mFile;
int mLine;
};
}
namespace JGadget {
namespace {
template <typename T>
class TPRIsEqual_pointer_ {
public:
TPRIsEqual_pointer_<T>(const T* p) { this->p_ = p; }
bool operator()(const T& rSrc) const {
return &rSrc == this->p_;
}
private:
const T* p_;
};
}
class TLinkListNode {
public:
TLinkListNode() {
this->pNext_ = 0 ;
this->pPrev_ = 0 ;
}
~TLinkListNode() {
}
TLinkListNode* getNext() const {
return this->pNext_;
}
TLinkListNode* getPrev() const {
return this->pPrev_;
}
void clear_() {
this->pNext_ = 0 ;
this->pPrev_ = 0 ;
}
TLinkListNode* pNext_;
TLinkListNode* pPrev_;
};
class TNodeLinkList {
public:
TNodeLinkList() : oNode_() { Initialize_(); }
~TNodeLinkList();
class const_iterator;
class iterator {
public:
friend class TNodeLinkList::const_iterator;
friend class TNodeLinkList;
iterator() { this->p_ = 0 ; }
iterator(TLinkListNode* node) { this->p_ = node; }
friend bool operator==(TNodeLinkList::iterator lhs, TNodeLinkList::iterator rhs) { return lhs.p_ == rhs.p_; }
friend bool operator!=(TNodeLinkList::iterator lhs, TNodeLinkList::iterator rhs) { return !(lhs == rhs); }
iterator& operator++() {
this->p_ = this->p_->getNext();
return *this;
}
iterator& operator--() {
this->p_ = this->p_->getPrev();
return *this;
}
TLinkListNode& operator*() const {
return *this->p_;
}
TLinkListNode* operator->() const { return this->p_; }
private:
TLinkListNode* p_;
};
class const_iterator {
public:
friend class TNodeLinkList;
const_iterator(const TLinkListNode* node) { this->p_ = node; }
const_iterator(iterator it) { this->p_ = it.p_; }
friend bool operator==(TNodeLinkList::const_iterator lhs, TNodeLinkList::const_iterator rhs) { return lhs.p_ == rhs.p_; }
friend bool operator!=(TNodeLinkList::const_iterator lhs, TNodeLinkList::const_iterator rhs) { return !(lhs == rhs); }
const const_iterator& operator++() {
this->p_ = this->p_->getNext();
return *this;
}
const const_iterator& operator--() {
this->p_ = this->p_->getPrev();
return *this;
}
const TLinkListNode* operator->() const { return this->p_; }
private:
const TLinkListNode* p_;
};
bool Confirm() const;
bool Confirm_iterator(const_iterator it) const;
iterator Erase(TLinkListNode* node);
iterator Find(const TLinkListNode* node);
iterator Insert(iterator it, TLinkListNode* node);
void Remove(TLinkListNode* node);
template <typename Predicate> void Remove_if(Predicate predicate, TNodeLinkList& tList) {
iterator it = this->begin();
while(!Iterator_isEnd_(it)) {
if (predicate(*it)) {
iterator itPrev = it;
++it;
tList.splice(tList.end(), *this, itPrev);
}
else {
++it;
}
}
}
u32 size() const { return this->size_; }
bool empty() const { return this->size() == 0; }
void clear() { this->erase(this->begin(), this->end()); }
iterator erase(iterator itStart, iterator itEnd);
iterator erase(iterator it);
template <typename Predicate> void remove_if(Predicate predicate) {
TNodeLinkList list;
this->Remove_if(predicate, list);
}
void splice(iterator it, TNodeLinkList& rSrc, iterator itBegin, iterator itEnd);
void splice(iterator it, TNodeLinkList& rSrc);
void splice(iterator it, TNodeLinkList& rSrc, iterator otherIt);
iterator pop_back() { return this->erase(--this->end()); }
iterator pop_font() { return this->erase(++this->begin()); }
iterator begin() { return this->oNode_.getNext(); }
const_iterator begin() const { return this->oNode_.getNext(); }
iterator end() { return &this->oNode_; }
const_iterator end() const { return &this->oNode_; }
private:
void Initialize_() {
this->size_ = 0;
this->oNode_.pNext_ = &this->oNode_;
this->oNode_.pPrev_ = &this->oNode_;
}
bool Iterator_isEnd_(const_iterator it) const { return it.p_ == &this->oNode_; }
u32 size_;
TLinkListNode oNode_;
};
#pragma push
#pragma sym off /* required to prevent messing up other TU layouts */
template <typename T, int O>
class TLinkList: public TNodeLinkList {
public:
class iterator {
public:
friend class TLinkList;
friend class TLinkList<T, O>::const_iterator;
iterator(TNodeLinkList::iterator it) : mIt(it) { }
friend bool operator==(iterator lhs, iterator rhs) { return (lhs.mIt == rhs.mIt); }
friend bool operator!=(iterator lhs, iterator rhs) { return !(lhs == rhs); }
iterator& operator++() {
++mIt;
return *this;
}
iterator& operator--() {
--mIt;
return *this;
}
T* operator->() const { return TLinkList::Element_toValue(mIt.operator->()); }
T& operator*() const {
T* p = this->operator->();
;
return *p;
}
private:
TNodeLinkList::iterator mIt;
};
class const_iterator {
public:
const_iterator(TNodeLinkList::const_iterator it) : mIt(it) { }
const_iterator(iterator it) : mIt(it.mIt) {}
friend bool operator==(const_iterator lhs, const_iterator rhs) { return (lhs.mIt == rhs.mIt); }
friend bool operator!=(const_iterator lhs, const_iterator rhs) { return !(lhs == rhs); }
const_iterator& operator++() {
++mIt;
return *this;
}
const_iterator& operator--() {
--mIt;
return *this;
}
const T* operator->() const { return TLinkList::Element_toValue(mIt.operator->()); }
const T& operator*() const {
const T* p = this->operator->();
;
return *p;
}
private:
TNodeLinkList::const_iterator mIt;
};
iterator begin() { return TNodeLinkList::begin(); }
const_iterator begin() const { return const_cast<TLinkList*>(this)->begin(); }
iterator end() { return TNodeLinkList::end(); }
const_iterator end() const { return const_cast<TLinkList*>(this)->end(); }
iterator Find(const T* p) { return TNodeLinkList::Find(TLinkList::Element_toNode(p)); }
iterator Erase(T* p) { return TNodeLinkList::Erase(Element_toNode(p)); }
iterator Insert(iterator it, T *p) { return TNodeLinkList::Insert(it.mIt, TLinkList::Element_toNode(p)); }
void Remove(T* p) { TNodeLinkList::Remove(TLinkList::Element_toNode(p)); }
void Push_front(T* p) { Insert(begin(), p); }
void Push_back(T* p) { Insert(end(), p); }
T& front() {
;
return *begin();
}
T& back() {
;
return *--end();
}
static TLinkListNode* Element_toNode(T* p) {
;
return (TLinkListNode*)((char*)p - O);
}
static const TLinkListNode* Element_toNode(const T* p) {
;
return (const TLinkListNode*)((const char*)p - O);
}
static T* Element_toValue(TLinkListNode* p) {
;
return (T*)((char*)p + O);
}
static const T* Element_toValue(const TLinkListNode* p) {
;
return (const T*)((const char*)p + O);
}
};
#pragma pop
}
extern "C"{
};
extern "C"{
namespace JUtility {
struct TColor : public GXColor {
TColor() {
set(0xFFFFFFFF);
}
TColor(u8 _r, u8 _g, u8 _b, u8 _a) {
set(_r, _g, _b, _a);
}
TColor(u32 u32Color) {
set(u32Color);
}
TColor(GXColor color) {
set(color);
}
TColor& operator=(const TColor& other) {
((GXColor*)this)->operator=(other);
return *this;
}
TColor& operator=(const GXColorS10& other) {
r = other.r;
g = other.g;
b = other.b;
a = other.a;
return *this;
}
operator u32() const {
return toUInt32();
}
u32 toUInt32() const {
return *(u32*)&r;
}
void set(u8 cR, u8 cG, u8 cB, u8 cA) {
r = cR;
g = cG;
b = cB;
a = cA;
}
void set(u32 u32Color) {
*(u32*)&r = u32Color;
}
void set(GXColor gxColor) {
*(GXColor*)&r = gxColor;
}
void set(TColor color) {
*this = color;
}
void setRGB(u8 cR, u8 cG, u8 cB) {
r = cR;
g = cG;
b = cB;
}
void setRGB(const TColor& other) {
setRGB(other.r, other.g, other.b);
}
void setRGBA(const TColor& other) {
r = other.r;
g = other.g;
b = other.b;
a = other.a;
}
};
}
}
struct JKRAramBlock;
struct JKRHeap;
struct ResFONT;
struct JUTFont {
typedef bool (*IsLeadByte)(int);
struct TWidth {
u8 w0;
u8 w1;
const TWidth& operator=(const TWidth& other) {
w0 = other.w0;
w1 = other.w1;
return *this;
}
};
JUTFont();
virtual ~JUTFont() {
}
virtual void setGX() = 0;
virtual void setGX(JUtility::TColor, JUtility::TColor) {
setGX();
};
virtual f32 drawChar_scale(f32, f32, f32, f32, int, bool) = 0;
virtual int getLeading() const = 0;
virtual int getAscent() const = 0;
virtual int getDescent() const = 0;
virtual int getHeight() const = 0;
virtual int getWidth() const = 0;
virtual void getWidthEntry(int, JUTFont::TWidth*) const = 0;
virtual int getCellWidth() const {
return getWidth();
};
virtual int getCellHeight() const {
return getHeight();
};
virtual int getFontType() const = 0;
virtual const ResFONT* getResFont() const = 0;
virtual bool isLeadByte(int) const = 0;
void initialize_state();
void setCharColor(JUtility::TColor);
void setGradColor(JUtility::TColor, JUtility::TColor);
f32 drawString_size_scale(f32, f32, f32, f32, const char*, u32, bool);
void drawString(int posX, int posY, const char* str, bool visible) {
drawString_size(posX, posY, str, strlen(str), visible);
}
void drawString_size(int posX, int posY, const char* str, u32 len, bool visible) {
drawString_size_scale(posX, posY, getWidth(), getHeight(), str, len, visible);
}
void drawString_scale(f32 posX, f32 posY, f32 width, f32 height, const char* str, bool visible) {
drawString_size_scale(posX, posY, width, height, str, strlen(str), visible);
}
int getWidth(int i_no) const {
TWidth width;
getWidthEntry(i_no, &width);
return width.w0;
}
void setFixedWidth(bool fixed, int width) {
mFixed = fixed;
mFixedWidth = width;
}
bool isValid() const {
return mValid;
}
static bool isLeadByte_1Byte(int c) {
return false;
}
static bool isLeadByte_2Byte(int c) {
return true;
}
static bool isLeadByte_ShiftJIS(int c) {
return ((c >= 0x81) && (c <= 0x9F)) || ((c >= 0xE0) && (c <= 0xFC));
}
bool mValid;
bool mFixed;
int mFixedWidth;
JUtility::TColor mColor1;
JUtility::TColor mColor2;
JUtility::TColor mColor3;
JUtility::TColor mColor4;
};
struct JUTRomFont : public JUTFont {
struct AboutEncoding {
u32 mFontType;
u32 mDataSize;
IsLeadByte mIsLeadByteFunction;
};
JUTRomFont();
JUTRomFont(JKRHeap*);
virtual ~JUTRomFont();
virtual void setGX();
virtual f32 drawChar_scale(f32, f32, f32, f32, int, bool);
virtual int getWidth() const {
return spFontHeader_->width;
};
virtual int getLeading() const {
return spFontHeader_->leading;
};
virtual int getAscent() const {
return spFontHeader_->ascent;
};
virtual int getDescent() const {
return spFontHeader_->descent;
};
virtual int getHeight() const {
return getAscent() + getDescent();
};
virtual void getWidthEntry(int, JUTFont::TWidth*) const;
virtual int getCellWidth() const {
return spFontHeader_->cellWidth;
};
virtual int getCellHeight() const {
return spFontHeader_->cellHeight;
};
virtual ResFONT* getResFont() const {
return 0 ;
};
virtual int getFontType() const {
return spAboutEncoding_->mFontType;
};
virtual bool isLeadByte(int) const;
void initiate(JKRHeap*);
void loadImage(JKRHeap*);
static AboutEncoding* spAboutEncoding_;
static OSFontHeader* spFontHeader_;
static u32 suFontHeaderRefered_;
static AboutEncoding saoAboutEncoding_[2];
};
struct BlockHeader {
const BlockHeader* getNext() const {
return reinterpret_cast<const BlockHeader*>(reinterpret_cast<const u8*>(this) + this->mSize);
}
inline static void advance(const BlockHeader** iterator) {
*iterator = reinterpret_cast<const BlockHeader*>(reinterpret_cast<const u8*>(*iterator) + (*iterator)->mSize);
}
u32 mMagic;
u32 mSize;
};
struct ResFONT {
struct InfoBlock : public BlockHeader {
u16 mFontType;
u16 mAscent;
u16 mDescent;
u16 mWidth;
u16 mLeading;
u16 mDefaultCode;
};
struct WidthBlock : public BlockHeader {
u16 mStartCode;
u16 mEndCode;
JUTFont::TWidth mChunkNum[2];
};
struct MapBlock : public BlockHeader {
u16 mMappingMethod;
u16 mStartCode;
u16 mEndCode;
u16 mNumEntries;
u16 mLeading;
};
struct GlyphBlock : public BlockHeader {
u16 mStartCode;
u16 mEndCode;
u16 mCellWidth;
u16 mCellHeight;
u32 mTextureSize;
u16 mTextureFormat;
u16 mNumRows;
u16 mNumColumns;
u16 mTextureWidth;
u16 mTextureHeight;
u16 mPadding;
u8 mData[];
};
u64 mMagic;
u32 mFileSize;
u32 mNumBlocks;
u8 mPadding[0x10];
u8 mData[];
};
struct JUTResFont : public JUTFont {
JUTResFont();
JUTResFont(const ResFONT*, JKRHeap*);
virtual ~JUTResFont();
virtual void setGX();
virtual void setGX(JUtility::TColor, JUtility::TColor);
virtual f32 drawChar_scale(f32, f32, f32, f32, int, bool);
virtual int getDescent() const {
return mInfoBlock->mDescent;
};
virtual int getHeight() const {
return getAscent() + getDescent();
};
virtual int getAscent() const {
return mInfoBlock->mAscent;
};
virtual int getWidth() const {
return mInfoBlock->mWidth;
};
virtual void getWidthEntry(int, JUTFont::TWidth*) const;
virtual int getCellWidth() const;
virtual int getCellHeight() const;
virtual int getFontType() const {
return mInfoBlock->mFontType;
};
virtual const ResFONT* getResFont() const {
return mResource;
};
virtual int getLeading() const {
return mInfoBlock->mLeading;
};
virtual bool isLeadByte(int) const;
virtual void loadImage(int, GXTexMapID);
virtual void setBlock();
int convertSjis(int, u16*) const;
void countBlock();
void deleteMemBlocks_ResFont();
int getFontCode(int) const;
void initialize_state();
bool initiate(const ResFONT*, JKRHeap*);
void loadFont(int, GXTexMapID, TWidth*);
bool protected_initiate(const ResFONT*, JKRHeap*);
inline void delete_and_initialize() {
deleteMemBlocks_ResFont();
initialize_state();
}
static IsLeadByte const saoAboutEncoding_[3];
int mWidth;
int mHeight;
GXTexObj _24;
int _44;
const ResFONT* mResource;
ResFONT::InfoBlock* mInfoBlock;
void** mMemBlocks;
ResFONT::WidthBlock** mWidthBlocks;
ResFONT::GlyphBlock** mGlyphBlocks;
ResFONT::MapBlock** mMapBlocks;
u16 mWidthBlockCount;
u16 mGlyphBlockCount;
u16 mMapBlockCount;
u16 _66;
u16 mMaxCode;
IsLeadByte* mIsLeadByte;
};
struct JUTCacheFont : public JUTResFont {
enum EPagingType {
CFPAGETYPE_Unk0 = 0,
CFPAGETYPE_Unk1 = 1,
};
struct TGlyphCacheInfo {
TGlyphCacheInfo* mPrev;
TGlyphCacheInfo* mNext;
u8 _08[4];
u16 _0C;
u16 _0E;
u8 _10[4];
u16 _14;
u16 _16;
u8 _18[8];
GXTexObj mGxTexObj;
};
struct TCachePage {
u8 _00[0x8];
s16 _08;
u16 _0A;
u8 _0C[0x4];
u8* _10;
u16 _14;
u16 _18;
u16 _1C;
u16 _20;
u16 _24;
u16 _28;
};
JUTCacheFont();
JUTCacheFont(const ResFONT*, void*, u32, JKRHeap*);
JUTCacheFont(const ResFONT*, u32, JKRHeap*);
virtual ~JUTCacheFont();
virtual void loadImage(int, _GXTexMapID);
virtual void setBlock();
bool allocArea(void*, u32, JKRHeap*);
bool allocArray(JKRHeap*);
void deleteMemBlocks_CacheFont();
bool getMemorySize(const ResFONT*, u16*, u32*, u16*, u32*, u16*, u32*, u32*);
void initialize_state();
bool initiate(const ResFONT*, void*, u32, JKRHeap*);
bool internal_initiate(const ResFONT*, void*, u32, JKRHeap*);
void invalidiateAllCache();
TGlyphCacheInfo* loadCache_char_subroutine(int*, bool);
void loadCache_string(const char*, bool);
void prepend(TGlyphCacheInfo*);
void unlink(TGlyphCacheInfo*);
void determineBlankPage();
void getGlyphFromAram(TGlyphCacheInfo*, TCachePage*, int*, int*);
void loadCache_char(int, bool);
void loadCache_string_size(const char*, u32, bool);
void unlockCache_all();
void unlockCache_char(int);
void unlockCache_string(const char*);
void unlockCache_string_size(const char*, u32);
void setPagingType(EPagingType type) {
mPagingType = type;
}
static u32 calcCacheSize(u32 param_0, int param_1) {
return (((param_0 + (0x20 - 1)) & (~(0x20 - 1))) + 0x40) * param_1;
}
u32 mWidthBlocksSize;
u32 mGlyphBlocksSize;
u32 mMapBlocksSize;
void* _7C;
void* _80;
void* _84;
u32 mMaxSheetSize;
EPagingType mPagingType;
void* mCacheBuffer;
u32 _94;
u32 mCachePage;
TGlyphCacheInfo* _9C;
TGlyphCacheInfo* _A0;
void* _A4;
u32 _A8;
JKRAramBlock* mAramBlock;
u8 _B0;
int _B4;
};
extern const ResFONT JUTResFONT_Ascfont_fix12;
inline s32 colorCheck(s32 diff, s32 t) {
s32 ret = diff - t;
return ret + 1;
}
class JUTConsole : JKRDisposer {
public:
enum EConsoleType {
CONSOLE_TYPE_0 = 0,
CONSOLE_TYPE_1 = 1,
CONSOLE_TYPE_2 = 2,
};
enum OutputFlag {
OUTPUT_NONE,
OUTPUT_OSREPORT,
OUTPUT_CONSOLE,
OUTPUT_OSR_AND_CONSOLE,
};
virtual ~JUTConsole();
static JUTConsole* create(uint, uint, JKRHeap*);
static JUTConsole* create(uint, void*, u32);
static void destroy(JUTConsole*);
JUTConsole(uint, uint, bool);
static size_t getObjectSizeFromBufferSize(uint, uint);
static size_t getLineFromObjectSize(u32, uint);
void clear();
void doDraw(JUTConsole::EConsoleType) const;
void print_f(char const*, ...);
void print(char const*);
void dumpToTerminal(uint);
void scroll(int);
int getUsedLine() const;
int getLineOffset() const;
void setOutput(uint output) {
mOutput = output;
}
void setPosition(int x, int y) {
mPositionX = x;
mPositionY = y;
}
void setFontSize(f32 x, f32 y) {
mFontSizeX = x;
mFontSizeY = y;
}
void setHeight(u32 height) {
mHeight = height;
if (mHeight > mMaxLines) {
mHeight = mMaxLines;
}
}
void setFont(JUTFont* p_font) {
mFont = p_font;
setFontSize(p_font->getWidth(), p_font->getHeight());
}
int nextIndex(int index) const {
return ++index >= (int)mMaxLines ? 0 : index;
}
u32 getOutput() const {
return mOutput;
}
int getPositionY() const {
return mPositionY;
}
int getPositionX() const {
return mPositionX;
}
u32 getHeight() const {
return mHeight;
}
bool isVisible() const {
return mIsVisible;
}
void setVisible(bool visible) {
mIsVisible = visible;
}
void setLineAttr(int param_0, u8 param_1) {
mBuf[(_20 + 2) * param_0] = param_1;
}
u8* getLinePtr(int param_0) const {
return &mBuf[(_20 + 2) * param_0] + 1;
}
int diffIndex(int param_0, int param_1) const {
int diff = param_1 - param_0;
if (diff >= 0) {
return diff;
}
return diff += mMaxLines;
}
u8 getLineAttr(int i) const {
return mBuf[(_20 + 2) * i];
}
int prevIndex(int n) const {
return (--n < 0) ? mMaxLines - 1 : n;
}
void scrollToLastLine() {
scroll(mMaxLines);
}
void scrollToFirstLine() {
scroll(-mMaxLines);
}
JGadget::TLinkListNode mNode;
u32 _20;
u32 mMaxLines;
u8* mBuf;
bool _2C;
int _30;
int _34;
int _38;
int _3C;
int mPositionX;
int mPositionY;
u32 mHeight;
JUTFont* mFont;
f32 mFontSizeX;
f32 mFontSizeY;
u32 mOutput;
JUtility::TColor _5C;
JUtility::TColor _60;
bool mIsVisible;
bool _65;
bool _66;
};
class JUTConsoleManager {
public:
JUTConsoleManager();
static JUTConsoleManager* createManager(JKRHeap*);
void appendConsole(JUTConsole* console);
void removeConsole(JUTConsole* console);
void draw() const;
void drawDirect(bool) const;
void setDirectConsole(JUTConsole*);
static JUTConsoleManager* getManager() {
return sManager;
}
static JUTConsoleManager* sManager;
private:
JGadget::TLinkList<JUTConsole, -24> soLink_;
JUTConsole* mActiveConsole;
JUTConsole* mDirectConsole;
};
extern "C"{
void JUTConsole_print_f_va_(JUTConsole*, const char*, va_list);
JUTConsole* JUTGetReportConsole();
void JUTSetReportConsole(JUTConsole*);
JUTConsole* JUTGetWarningConsole();
void JUTSetWarningConsole(JUTConsole*);
void JUTReportConsole(const char*);
void JUTReportConsole_f(const char*, ...);
void JUTReportConsole_f_va(const char*, va_list);
void JUTWarningConsole(const char*);
void JUTWarningConsole_f(const char*, ...);
void JUTWarningConsole_f_va(const char*, va_list);
};
struct JKRThread;
struct JKRThreadName_ {
s32 id;
char* name;
};
typedef void (*JKRThreadSwitch_PreCallback)(OSThread* current, OSThread* next);
typedef void (*JKRThreadSwitch_PostCallback)(OSThread* current, OSThread* next);
class JKRThreadSwitch {
public:
JKRThreadSwitch(JKRHeap*);
virtual void draw(JKRThreadName_* param_1, JUTConsole* param_2);
virtual void draw(JKRThreadName_* param_1);
virtual ~JKRThreadSwitch();
static JKRThreadSwitch* createManager(JKRHeap* heap);
JKRThread* enter(JKRThread* param_1, int param_2);
static void callback(OSThread* param_1, OSThread* param_2);
static u32 getTotalCount() {
return sTotalCount;
}
private:
static JKRThreadSwitch* sManager;
static u32 sTotalCount;
static u64 sTotalStart;
static JKRThreadSwitch_PreCallback mUserPreCallback;
static JKRThreadSwitch_PostCallback mUserPostCallback;
private:
JKRHeap* mHeap;
bool mSetNextHeap;
u8 _09[3];
u32 _0C;
u32 _10;
u8 _14[4];
s64 _18;
JUTConsole* mConsole;
JKRThreadName_* mThreadName;
};
class JKRThread : public JKRDisposer {
public:
JKRThread(u32 stackSize, int msgCount, int threadPrio);
JKRThread(OSThread* osThread, int msgCount);
virtual ~JKRThread();
virtual void* run() {
return 0 ;
}
static void* start(void* param);
static JSUList<JKRThread>* getList() {
return &JKRThread::sThreadList;
}
OSThread* getThreadRecord() const {
return this->mThreadRecord;
}
void* getStack() const {
return this->mStackMemory;
}
void resume() {
OSResumeThread(this->mThreadRecord);
}
void jamMessageBlock(OSMessage msg) {
OSJamMessage(&this->mMesgQueue, msg, (1) );
}
void sendMessage(OSMessage msg) {
OSSendMessage(&this->mMesgQueue, msg, (0) );
}
OSMessage waitMessage(int* received) {
OSMessage mesg;
BOOL retrieved = OSReceiveMessage(&this->mMesgQueue, &mesg, (0) );
if (received != 0 ) {
*received = retrieved;
}
return mesg;
}
OSMessage waitMeessageBlock() {
OSMessage mesg;
OSReceiveMessage(&this->mMesgQueue, &mesg, (1) );
return mesg;
}
static JSUList<JKRThread> sThreadList;
protected:
JSULink<JKRThread> mLink;
JKRHeap* mHeap;
OSThread* mThreadRecord;
OSMessageQueue mMesgQueue;
OSMessage* mMesgBuffer;
int mMesgCount;
void* mStackMemory;
u32 mStackSize;
};
class JKRTask : public JKRThread {
typedef void (*RequestCallback)(void*);
struct Request {
RequestCallback mCb;
void* mArg;
void* mMsg;
};
JKRTask();
virtual ~JKRTask();
virtual void* run();
bool request(RequestCallback, void*, void*);
static JKRTask* create();
Request* searchBlank();
void requestJam(RequestCallback, void*, void*);
void cancelAll();
void createTaskEndMessageQueue(int, JKRHeap*);
void destroyTaskEndMessageQueue();
void waitQueueMessageBlock(OSMessageQueue*, int*);
void waitQueueMessage(OSMessageQueue*, int*);
OSMessage waitMessageBlock() {
OSMessage msg;
OSReceiveMessage(&mMesgQueue, &msg, (1) );
return msg;
}
void destroy();
static OSMessage* sEndMesgBuffer;
static u32 sEndMesgBufSize;
Request* mRequest;
u32 mRequestCnt;
OSMessageQueue* mTaskMsgQueue;
static JSUList<JKRTask> sTaskList;
static u8 sEndMesgQueue[32];
};
struct JKRIdleThread : public JKRThread {
virtual ~JKRIdleThread() {};
virtual void* run()
{
while (true) {}
};
virtual void destroy() {
}
static void create(JKRHeap*, int, u32);
static JKRIdleThread* sThread;
};
enum JSUStreamSeekFrom { SEEK_SET = 0, SEEK_CUR = 1, SEEK_END = 2 };
enum EIoState { GOOD = 0, EOF = 1 };
class JSUIosBase {
public:
inline JSUIosBase() : mState(GOOD) {
}
virtual ~JSUIosBase() {
}
bool isGood() {
return !this->mState;
}
void clrState(EIoState ioState) {
this->mState &= ~ioState;
}
void setState(EIoState ioState) {
this->mState |= ioState;
}
u8 mState;
};
class JSUInputStream : public JSUIosBase {
public:
virtual ~JSUInputStream();
virtual int getAvailable() const = 0;
virtual int skip(s32 amount);
virtual int readData(void* buf, s32 size) = 0;
int read(void* buf, s32 size);
char* read(char* buf);
char* readString();
char* readString(char* buf, u16 len);
int read(s8& p) {
return this->read(&p, sizeof(s8));
}
int read(u8& p) {
return this->read(&p, sizeof(u8));
}
int read(bool& p) {
return this->read(&p, sizeof(bool));
}
int read(s16& p) {
return this->read(&p, sizeof(s16));
}
int read(u16& p) {
return this->read(&p, sizeof(u16));
}
int read(s32& p) {
return this->read(&p, sizeof(s32));
}
int read(u32& p) {
return this->read(&p, sizeof(u32));
}
int read(s64& p) {
return this->read(&p, sizeof(s64));
}
int read(u64& p) {
return this->read(&p, sizeof(u64));
}
u8 read8b() {
u8 b;
this->read(&b, sizeof(u8));
return b;
}
u16 read16b() {
u16 s;
this->read(&s, sizeof(u16));
return s;
}
u32 read32b() {
u32 i;
this->read(&i, sizeof(u32));
return i;
}
s8 readS8() {
s8 b;
this->read(&b, sizeof(s8));
return b;
}
u8 readU8() {
u8 b;
this->read(&b, sizeof(u8));
return b;
}
s16 readS16() {
s16 s;
this->read(&s, sizeof(s16));
return s;
}
u16 readU16() {
u16 s;
this->read(&s, sizeof(u16));
return s;
}
s32 readS32() {
s32 i;
this->read(&i, sizeof(s32));
return i;
}
u32 readU32() {
u32 i;
this->read(&i, sizeof(u32));
return i;
}
JSUInputStream& operator>>(s8& p) {
this->read(&p, sizeof(s8));
return *this;
}
JSUInputStream& operator>>(u8& p) {
this->read(&p, sizeof(u8));
return *this;
}
JSUInputStream& operator>>(s16& p) {
this->read(&p, sizeof(s16));
return *this;
}
JSUInputStream& operator>>(u16& p) {
this->read(&p, sizeof(u16));
return *this;
}
JSUInputStream& operator>>(u32& p) {
this->read(&p, sizeof(u32));
return *this;
}
};
class JSUOutputStream : protected JSUIosBase {
public:
virtual ~JSUOutputStream();
virtual int getAvailable() const = 0;
virtual int skip(s32 amount);
virtual int readData(void* buf, s32 size) = 0;
};
class JKRFile : public JKRDisposer {
public:
inline JKRFile() : JKRDisposer(), mFileOpen(false) {
}
virtual ~JKRFile() {
}
virtual bool open(const char* path) = 0;
virtual bool close() = 0;
virtual int readData(void* data, s32 length, s32 ofs) = 0;
virtual int writeData(const void* data, s32 length, s32 ofs) = 0;
virtual u32 getFileSize() const = 0;
void read(void* data, s32 length, s32 ofs);
bool isAvailable() {
return this->mFileOpen;
}
protected:
bool mFileOpen;
};
class JSURandomInputStream : public JSUInputStream {
public:
virtual ~JSURandomInputStream() {
}
virtual int getAvailable() const {
return this->getLength() - this->getPosition();
}
virtual int skip(s32 amount);
virtual int readData(void* buf, s32 count) = 0;
virtual int getLength() const = 0;
virtual int getPosition() const = 0;
virtual int seekPos(s32 offset, JSUStreamSeekFrom from) = 0;
int align(s32 alignment);
int peek(void* buf, s32 len);
int seek(s32 offset, JSUStreamSeekFrom from);
};
class JSURandomOutputStream : public JSUOutputStream {
public:
virtual ~JSURandomOutputStream() {
}
virtual int getAvailable() const;
virtual int skip(s32 amount);
virtual int readData(void* buf, s32 count) = 0;
virtual int getLength() const = 0;
virtual int getPosition() const = 0;
virtual int seekPos(s32 offset, JSUStreamSeekFrom from) = 0;
int align(s32 alignment);
int peek(void* buf, s32 len);
int seek(s32 offset, JSUStreamSeekFrom from);
};
class JSUFileInputStream : public JSURandomInputStream {
public:
JSUFileInputStream(JKRFile* file);
virtual int readData(void* buf, s32 len);
virtual int getLength() const {
return ((JKRFile*)this->mObject)->getFileSize();
}
virtual int getPosition() const {
return this->mPosition;
}
virtual int seekPos(s32 offset, JSUStreamSeekFrom from);
protected:
const void* mObject;
s32 mPosition;
};
class JSUFileOutputStream : public JSURandomOutputStream {
public:
JSUFileOutputStream(JKRFile*);
};
class JKRAramHeap;
class JKRDecompCommand;
class JKRAMCommand;
class JKRAramBlock {
public:
JKRAramBlock(u32 address, u32 size, u32 freeSize, u8 groupID, bool tempMemory);
virtual ~JKRAramBlock();
JKRAramBlock* allocHead(u32 size, u8 groupID, JKRAramHeap* heap);
JKRAramBlock* allocTail(u32 size, u8 groupID, JKRAramHeap* heap);
u32 getAddress() const {
return this->mAddress;
}
u32 getSize() const {
return this->mSize;
}
u32 getFreeSize() const {
return this->mFreeSize;
}
bool isTempMemory() const {
return this->mIsTempMemory;
}
void newGroupID(u8 groupID) {
this->mGroupID = groupID;
}
JSULink<JKRAramBlock> mLink;
u32 mAddress;
u32 mSize;
u32 mFreeSize;
u8 mGroupID;
bool mIsTempMemory;
friend class JKRAramHeap;
};
class JKRAramHeap : public JKRDisposer {
public:
enum EAllocMode { Head = 0, Tail = 1 };
JKRAramHeap(u32 baseAddress, u32 size);
virtual ~JKRAramHeap();
JKRAramBlock* alloc(u32 size, EAllocMode mode);
void free(JKRAramBlock* block);
JKRAramBlock* allocFromHead(u32 size);
JKRAramBlock* allocFromTail(u32 size);
u32 getFreeSize();
u32 getTotalFreeSize();
u32 getUsedSize(u8 groupID);
void dump();
u8 getCurrentGroupID() const {
return this->mGroupID;
}
JKRHeap* getMgrHeap() const {
return this->mHeap;
}
void lock() {
OSLockMutex(&this->mMutex);
}
void unlock() {
OSUnlockMutex(&this->mMutex);
}
static JSUList<JKRAramBlock> sAramList;
OSMutex mMutex;
JKRHeap* mHeap;
u32 mHeadAddress;
u32 mTailAddress;
u32 mSize;
u8 mGroupID;
friend class JKRAramBlock;
};
class JKRAram : public JKRThread {
public:
JKRAram(u32, u32, long);
virtual ~JKRAram();
virtual void* run();
static bool checkOkAddress(u8* addr, u32 size, JKRAramBlock* block, u32 param_4);
static void changeGroupIdIfNeed(u8* data, int groupId);
static JKRAram* create(u32, u32, long, long, long);
static JKRAramBlock* mainRamToAram(u8*, u32, u32, JKRExpandSwitch, u32, JKRHeap*, int);
static JKRAramBlock* mainRamToAram(u8*, JKRAramBlock* block, u32, JKRExpandSwitch, u32, JKRHeap*, int);
static u8* aramToMainRam(u32, u8*, u32, JKRExpandSwitch, u32, JKRHeap*, int, u32*);
static u8* aramToMainRam(JKRAramBlock*, u8*, u32, u32, JKRExpandSwitch, u32, JKRHeap*, int, u32*);
void aramSync(JKRAMCommand*, int);
u32 getAudioMemory() const {
return mAudioMemoryPtr;
}
u32 getAudioMemSize() const {
return mAudioMemorySize;
}
static u32 getSZSBufferSize() {
return sSZSBufferSize;
}
static JKRAramHeap* getAramHeap() {
return sAramObject->mAramHeap;
}
static JKRAram* getManager() {
return sAramObject;
}
static u8 decideAramGroupId(int id) {
if (id < 0)
return getAramHeap()->getCurrentGroupID();
else
return id;
}
static u32 sSZSBufferSize;
static JKRAram* sAramObject;
static OSMessage sMessageBuffer[4];
static OSMessageQueue sMessageQueue;
static JSUList<JKRAMCommand> sAramCommandList;
u32 mAudioMemoryPtr;
u32 mAudioMemorySize;
u32 mGraphMemoryPtr;
u32 mGraphMemorySize;
u32 mUserMemoryPtr;
u32 mUserMemorySize;
JKRAramHeap* mAramHeap;
u32 mStackArray[3];
};
class JKRAMCommand : public ARQRequest {
public:
typedef void (*AMCommandCallback)(u32);
JKRAMCommand();
~JKRAMCommand();
JSULink<JKRAMCommand> mAramPieceCommandLink;
JSULink<JKRAMCommand> mLink30;
s32 mDirection;
u32 mLength;
u32 mSource;
u32 mDestination;
JKRAramBlock* mAramBlock;
u8 _54[4];
AMCommandCallback mCallback;
OSMessageQueue* mCompletedMesgQueue;
s32 mCallbackType;
JKRDecompCommand* mDecompCommand;
OSMessageQueue mMesgQueue;
OSMessage mMesgBuffer[1];
void* _8C;
void* _90;
void* _94;
};
class JKRAramCommand {
public:
inline void setting(BOOL active, void* arg) {
this->mActive = active;
this->mArg = arg;
}
BOOL mActive;
void* mArg;
};
class JKRAramPiece {
public:
static JKRAMCommand* prepareCommand(int direction, u32 source, u32 destination, u32 length, JKRAramBlock* aramBlock,
JKRAMCommand::AMCommandCallback callback);
static void sendCommand(JKRAMCommand* cmd);
static JKRAMCommand* orderAsync(int direction, u32 source, u32 destination, u32 length, JKRAramBlock* aramBlock,
JKRAMCommand::AMCommandCallback callback);
static bool sync(JKRAMCommand* cmd, BOOL noBlock);
static bool orderSync(int direction, u32 source, u32 destination, u32 length, JKRAramBlock* aramBlock);
static void startDMA(JKRAMCommand* cmd);
static void doneDMA(u32 arg);
static OSMutex mMutex;
static JSUList<JKRAMCommand> sAramPieceCommandList;
private:
static void lock() {
OSLockMutex(&mMutex);
}
static void unlock() {
OSUnlockMutex(&mMutex);
}
};
class JKRAramStreamCommand {
public:
enum ECommandType {
ECT_UNK = 0,
ECT_READ = 1,
ECT_WRITE = 2,
};
JKRAramStreamCommand();
ECommandType type;
u32 mAddress;
u32 mSize;
u32 _0C;
JSUFileInputStream* mStream;
u32 mOffset;
u8* mTransferBuffer;
u32 mTransferBufferSize;
JKRHeap* mHeap;
bool mAllocatedTransferBuffer;
u32 _28;
OSMessageQueue mMessageQueue;
void* mMessage;
u32 _50;
u32 _54;
};
class JKRAramStream : public JKRThread {
public:
JKRAramStream(long);
virtual ~JKRAramStream();
virtual void* run();
static JKRAramStream* create(s32);
static u32 readFromAram();
static s32 writeToAram(JKRAramStreamCommand*);
static JKRAramStreamCommand* write_StreamToAram_Async(JSUFileInputStream*, JKRAramBlock*, u32, u32);
static JKRAramStreamCommand* write_StreamToAram_Async(JSUFileInputStream*, u32, u32, u32);
static JKRAramStreamCommand* sync(JKRAramStreamCommand*, BOOL);
static void setTransBuffer(u8*, u32, JKRHeap*);
static JKRAramStream* sAramStreamObject;
static OSMessage sMessageBuffer[4];
static OSMessageQueue sMessageQueue;
static u8* transBuffer;
static JKRHeap* transHeap;
static u32 transSize;
};
inline JKRAramBlock* JKRAllocFromAram(u32 size, JKRAramHeap::EAllocMode allocMode) {
return JKRAram::getAramHeap()->alloc(size, allocMode);
}
inline void JKRFreeToAram(JKRAramBlock* block) {
JKRAram::getAramHeap()->free(block);
}
inline u8* JKRAramToMainRam(u32 address, u8* buf, u32 bufSize, JKRExpandSwitch expandSwitch, u32 p5, JKRHeap* heap,
int id, u32* pSize) {
return JKRAram::aramToMainRam(address, buf, bufSize, expandSwitch, p5, heap, id, pSize);
}
inline JKRAramBlock* JKRMainRamToAram(u8* buf, u32 bufSize, u32 alignedSize, JKRExpandSwitch expandSwitch, u32 fileSize,
JKRHeap* heap, int id, u32) {
return JKRAram::mainRamToAram(buf, bufSize, alignedSize, expandSwitch, fileSize, heap, id);
}
inline JKRAramStream* JKRCreateAramStreamManager(s32 priority) {
return JKRAramStream::create(priority);
}
inline bool JKRAramPcs(int direction, u32 source, u32 destination, u32 length, JKRAramBlock* block) {
return JKRAramPiece::orderSync(direction, source, destination, length, block);
}
inline void JKRAramPcs_SendCommand(JKRAMCommand* cmd) {
JKRAramPiece::sendCommand(cmd);
}
class JKRFileFinder;
class JKRFileLoader : public JKRDisposer {
public:
JKRFileLoader();
virtual ~JKRFileLoader();
virtual void unmount();
virtual bool becomeCurrent(const char*) = 0;
virtual void* getResource(const char* path) = 0;
virtual void* getResource(u32 type, const char* name) = 0;
virtual size_t readResource(void* resourceBuffer, u32 bufferSize, const char* path,
JKRExpandSwitch expandSwitch) = 0;
virtual size_t readResource(void* resourceBuffer, u32 bufferSize, u32 type, const char* name) = 0;
virtual void removeResourceAll() = 0;
virtual bool removeResource(void*) = 0;
virtual bool detachResource(void*) = 0;
virtual long getResSize(const void*) const = 0;
virtual u32 countFile(const char*) const = 0;
virtual JKRFileFinder* getFirstFile(const char*) const = 0;
bool isMounted() const {
return mIsMounted;
}
u32 getVolumeType() const {
return mVolumeType;
}
static void changeDirectory(const char* dir);
static void* getGlbResource(const char*);
static void* getGlbResource(const char*, JKRFileLoader* fileLoader);
static size_t readGlbResource(void* resourceBuffer, u32 bufferSize, const char* path, JKRExpandSwitch expandSwitch);
static bool removeResource(void* resourceBuffer, JKRFileLoader* fileLoader);
static bool detachResource(void* resourceBuffer, JKRFileLoader* fileLoader);
static JKRFileLoader* findVolume(const char**);
static JKRFileFinder* findFirstFile(const char*);
static const char* fetchVolumeName(char*, long, const char*);
static JKRFileLoader* getCurrentVolume() {
return sCurrentVolume;
}
static void setCurrentVolume(JKRFileLoader* fileLoader) {
sCurrentVolume = fileLoader;
}
static JSUList<JKRFileLoader>& getVolumeList() {
return sVolumeList;
}
static JKRFileLoader* sCurrentVolume;
static JSUList<JKRFileLoader> sVolumeList;
protected:
JSULink<JKRFileLoader> mFileLoaderLink;
const char* mVolumeName;
u32 mVolumeType;
bool mIsMounted;
u32 mMountCount;
};
class JKRDvdFile;
struct JKRDvdFileInfo : public DVDFileInfo {
JKRDvdFile* mFile;
};
class JKRDvdFile : public JKRFile {
public:
JKRDvdFile();
JKRDvdFile(const char* filename);
JKRDvdFile(s32 entrynum);
virtual ~JKRDvdFile();
virtual bool open(const char* filename);
virtual bool close();
virtual int readData(void* data, s32 length, s32 ofs);
virtual int writeData(const void* data, s32 length, s32 ofs);
virtual u32 getFileSize() const {
return this->mDvdFileInfo.length;
}
virtual bool open(s32 entrynum);
inline DVDFileInfo* getFileInfo() {
return &this->mDvdFileInfo;
}
inline int readDataAsync(void* addr, s32 length, s32 offset) {
OSLockMutex(&this->mDvdMutex);
s32 retAddr;
if (this->mDvdThread != 0 ) {
OSUnlockMutex(&this->mDvdMutex);
retAddr = -1;
} else {
this->mDvdThread = OSGetCurrentThread();
retAddr = -1;
if (DVDReadAsyncPrio((&this->mDvdFileInfo), (addr), (length), (offset), (JKRDvdFile::doneProcess), 2) ) {
retAddr = this->sync();
}
this->mDvdThread = 0 ;
OSUnlockMutex(&this->mDvdMutex);
}
return retAddr;
}
inline int writeDataAsync(const void* data, s32 length, s32 offset) {
return -1;
}
void initiate();
s32 sync();
static void doneProcess(s32 result, DVDFileInfo* info);
static JSUList<JKRDvdFile> sDvdList;
public:
OSMutex mDvdMutex;
OSMutex mAramMutex;
JKRAramBlock* mAramBlock;
OSThread* mAramThread;
JSUFileInputStream* mInputStream;
u32 _58;
JKRDvdFileInfo mDvdFileInfo;
OSMessageQueue mAramMessageQueue;
OSMessage mAramMessage;
OSMessageQueue mDvdMessageQueue;
OSMessage mDvdMessage;
JSULink<JKRDvdFile> mLink;
OSThread* mDvdThread;
};
inline u32 read_big_endian_u32(void* ptr) {
u8* uptr = (u8*)ptr;
return ((u32)uptr[0] << 0x18) | ((u32)uptr[1] << 0x10) | ((u32)uptr[2] << 8) | (u32)uptr[3];
}
class JKRArchive : public JKRFileLoader {
public:
enum EMountMode {
UNKNOWN_MOUNT_MODE = 0,
MOUNT_MEM = 1,
MOUNT_ARAM = 2,
MOUNT_DVD = 3,
MOUNT_COMP = 4,
};
enum EMountDirection {
UNKNOWN_MOUNT_DIRECTION = 0,
MOUNT_DIRECTION_HEAD = 1,
MOUNT_DIRECTION_TAIL = 2,
};
class CArcName {
public:
CArcName(const char** p1, char p2) {
p1[0] = store(p1[0], p2);
}
const char* getString() const {
return mString;
}
u16 getHash() const {
return mHash;
}
void store(const char*);
const char* store(const char*, char);
CArcName() {
}
CArcName(const char* data) {
store(data);
}
u16 mHash;
u16 _02;
char mString[256];
u8 _104[4];
};
struct SDIFileEntry {
u16 getNameHash() const {
return mHash;
}
u32 getNameOffset() const {
return mFlag & 0xFFFFFF;
}
u32 getFlags() const {
return mFlag >> 24;
}
u32 getAttr() const {
return getFlags();
}
u32 getSize() {
return mSize;
}
u16 getFileID() const {
return mFileID;
}
bool isDirectory() const {
return (getFlags() & 0x02) != 0;
}
bool isCompressed() const {
return (getFlags() & 0x04) != 0;
}
u8 getCompressFlag() const {
return (getFlags() & 0x04);
}
bool isYAZ0Compressed() const {
return (getFlags() & 0x80) != 0;
}
bool getFlag01() const {
return (getFlags() & 0x01) != 0;
}
bool getFlag04() {
return mFlag >> 0x18 & 0x04;
}
bool getFlag10() {
return mFlag >> 0x18 & 0x10;
}
bool getFlag80() {
return mFlag >> 0x18 & 0x80;
}
u16 mFileID;
u16 mHash;
u32 mFlag;
u32 mDataOffset;
u32 mSize;
void* mData;
};
struct SDirEntry {
u8 mFlags;
u8 _01;
u16 mID;
char* mName;
};
struct SDIDirEntry {
u32 mType;
u32 mOffset;
u16 _08;
u16 mNum;
u32 mFirstIdx;
};
struct SArcDataInfo {
u32 num_nodes;
u32 node_offset;
u32 num_file_entries;
u32 file_entry_offset;
u32 string_table_length;
u32 string_table_offset;
u16 nextFreeFileID;
bool isSyncIDs;
u8 _1B[5];
};
struct SArcHeader {
u32 signature;
u32 file_length;
u32 header_length;
u32 file_data_offset;
u32 file_data_length;
u32 _14;
u32 _18;
u32 _1C;
};
public:
virtual bool becomeCurrent(const char*);
virtual void* getResource(const char* path);
virtual void* getResource(u32 type, const char* name);
virtual size_t readResource(void* resourceBuffer, u32 bufferSize, const char* path,
JKRExpandSwitch expandSwitch);
virtual size_t readResource(void* resourceBuffer, u32 bufferSize, u32 type, const char* name);
virtual void removeResourceAll();
virtual bool removeResource(void*);
virtual bool detachResource(void*);
virtual s32 getResSize(const void*) const;
virtual u32 countFile(const char*) const;
virtual JKRFileFinder* getFirstFile(const char*) const;
virtual void* fetchResource(SDIFileEntry* entry, u32* outSize) = 0;
virtual void* fetchResource(void* resourceBuffer, u32 bufferSize, SDIFileEntry* entry, u32* resSize,
JKRExpandSwitch expandSwitch) = 0;
JKRArchive(s32, EMountMode);
JKRArchive();
JKRArchive(const char* p1, EMountMode mountMode);
~JKRArchive();
SDIDirEntry* findDirectory(const char*, u32) const;
SDIFileEntry* findFsResource(const char*, u32) const;
SDIFileEntry* findIdResource(u16) const;
SDIFileEntry* findIdxResource(u32) const;
SDIFileEntry* findNameResource(const char*) const;
SDIFileEntry* findPtrResource(const void*) const;
SDIFileEntry* findTypeResource(u32, const char*) const;
bool isSameName(CArcName&, u32, u16) const;
bool getDirEntry(SDirEntry*, u32) const;
void* getIdxResource(u32 index);
size_t readResource(void* resourceBuffer, u32 bufferSize, u16 id);
static JKRArchive* mount(char const*, EMountMode, JKRHeap*, EMountDirection);
static JKRArchive* mount(void*, JKRHeap*, EMountDirection);
static JKRArchive* mount(s32, EMountMode, JKRHeap*, EMountDirection);
static void* getGlbResource(u32 type, const char* name, JKRArchive* archive);
static JKRArchive* check_mount_already(s32);
static JKRArchive* check_mount_already(s32, JKRHeap*);
SDIDirEntry* findResType(u32) const;
SDIFileEntry* findTypeResource(u32, u32) const;
static int convertAttrToCompressionType(int attr) {
int compression;
if ((((attr) & (0x04)) == 0) )
compression = 0 ;
else if (!(((attr) & (0x80)) == 0) )
compression = 2 ;
else
compression = 1 ;
return compression;
}
u32 getMountMode() const {
return mMountMode;
}
u32 countFile() const {
return mArcInfoBlock->num_file_entries;
}
int countDirectory() const {
return mArcInfoBlock->num_nodes;
}
static u32 getCurrentDirID() {
return sCurrentDirID;
}
static void setCurrentDirID(u32 dirID) {
sCurrentDirID = dirID;
}
static u32 sCurrentDirID;
protected:
JKRHeap* mHeap;
u8 mMountMode;
s32 mEntryNum;
SArcDataInfo* mArcInfoBlock;
SDIDirEntry* mDirectories;
SDIFileEntry* mFileEntries;
const char* mStrTable;
int _54;
int mCompression;
EMountDirection mMountDirection;
};
enum JKRMemBreakFlag { MBF_0 = 0, MBF_1 = 1 };
class JKRAramArchive : public JKRArchive {
public:
JKRAramArchive();
JKRAramArchive(s32, EMountDirection);
virtual ~JKRAramArchive();
virtual void* fetchResource(SDIFileEntry*, u32*);
virtual void* fetchResource(void*, u32, SDIFileEntry*, u32*, JKRExpandSwitch expandSwitch);
bool open(s32);
u32 getAramAddress_Entry(SDIFileEntry* fileEntry);
u32 getAramAddress(u32, const char* file);
static u32 fetchResource_subroutine(u32, u32, u8*, u32, int);
static u32 fetchResource_subroutine(u32, u32, JKRHeap*, int, u8**);
void fixedInit(s32 entryNum, EMountDirection direction);
bool mountFixed(s32 entryNum, EMountDirection direction);
bool mountFixed(const char* path, EMountDirection direction);
void unmountFixed();
JKRAramBlock* mBlock;
JKRFile* mDvdFile;
};
struct JKRCompArchive : public JKRArchive {
JKRCompArchive(s32, EMountDirection);
virtual ~JKRCompArchive();
virtual void removeResourceAll();
virtual bool removeResource(void*);
virtual void* fetchResource(SDIFileEntry* entry, u32* outSize);
virtual void* fetchResource(void* resourceBuffer, u32 bufferSize, SDIFileEntry* entry, u32* resSize,
JKRExpandSwitch expandSwitch);
bool open(s32);
void fixedInit(s32);
void mountFixed(s32);
void mountFixed(const char*);
void unmountFixed();
u32 _60;
JKRAramBlock* mAramPart;
u32 _68;
JKRFile* mDvdFile;
u32 mSizeOfMemPart;
u32 mSizeOfAramPart;
u32 _78;
};
struct JKRDvdArchive : public JKRArchive {
JKRDvdArchive();
JKRDvdArchive(s32, JKRArchive::EMountDirection);
virtual ~JKRDvdArchive();
virtual void* fetchResource(SDIFileEntry* entry, u32* outSize);
virtual void* fetchResource(void* resourceBuffer, u32 bufferSize, SDIFileEntry* entry, u32* resSize,
JKRExpandSwitch expandSwitch);
bool open(s32);
static u32 fetchResource_subroutine(s32, u32, u32, u8*, u32, int, int);
static u32 fetchResource_subroutine(s32, u32, u32, JKRHeap*, int, int, u8**);
unknown fixedInit(s32, EMountDirection);
unknown mountFixed(s32, EMountDirection);
unknown mountFixed(const char*, EMountDirection);
unknown unmountFixed();
int _60;
JKRFile* mDvdFile;
};
struct JKRMemArchive : public JKRArchive {
JKRMemArchive();
JKRMemArchive(s32, EMountDirection);
JKRMemArchive(void*, u32, JKRMemBreakFlag);
JKRMemArchive(const char*, EMountDirection);
virtual ~JKRMemArchive();
virtual void removeResourceAll();
virtual bool removeResource(void*);
virtual void* fetchResource(SDIFileEntry* entry, u32* outSize);
virtual void* fetchResource(void* resourceBuffer, u32 bufferSize, SDIFileEntry* entry, u32* resSize,
JKRExpandSwitch expandSwitch);
bool open(s32, EMountDirection);
bool open(void*, u32, JKRMemBreakFlag);
static u32 fetchResource_subroutine(u8*, u32, u8*, u32, int);
void fixedInit(s32);
void mountFixed(s32, EMountDirection);
void mountFixed(const char*, EMountDirection);
void mountFixed(void*, JKRMemBreakFlag);
void unmountFixed();
void open(const char*, EMountDirection);
SArcHeader* mArcHeader;
u8* mArchiveData;
bool mIsOpen;
};
inline int JKRConvertAttrToCompressionType(int attr) {
return JKRArchive::convertAttrToCompressionType(attr);
}
inline JKRArchive* JKRMountArchive(const char* path, JKRArchive::EMountMode mountMode, JKRHeap* heap,
JKRArchive::EMountDirection mountDirection) {
return JKRArchive::mount(path, mountMode, heap, mountDirection);
}
inline JKRArchive* JKRMountArchive(void* inBuf, JKRHeap* heap, JKRArchive::EMountDirection mountDirection) {
return JKRArchive::mount(inBuf, heap, mountDirection);
}
struct JUTExternalFB {
JUTExternalFB(GXRenderModeObj*, GXGamma, void*, u32);
GXRenderModeObj* mRenderModeObj;
u32 mSize;
u8 _08[4];
u16 _0C;
u16 mGamma;
bool _10;
};
class JUTXfb {
public:
enum EXfbNumber { Unset = 0, SingleBuffer = 1, DoubleBuffer = 2, TripleBuffer = 3 };
void clearIndex();
void common_init(int);
JUTXfb(const GXRenderModeObj*, JKRHeap*, JUTXfb::EXfbNumber);
~JUTXfb();
void delXfb(int);
static JUTXfb* createManager(const GXRenderModeObj* rmode, JKRHeap*, JUTXfb::EXfbNumber);
static void destroyManager();
void initiate(u16, u16, JKRHeap*, JUTXfb::EXfbNumber);
u32 accumeXfbSize();
int getBufferNum() const {
return mBufferNum;
}
int getDrawnXfbIndex() const {
return mDrawnXfbIndex;
}
s16 getDrawingXfbIndex() const {
return mDrawingXfbIndex;
}
s16 getDisplayingXfbIndex() const {
return mDisplayingXfbIndex;
}
int getSDrawingFlag() const {
return mSDrawingFlag;
}
void* getXfb(int index) const {
return mBuffer[index];
}
void* getDrawnXfb() const {
return (mDrawnXfbIndex >= 0) ? mBuffer[mDrawnXfbIndex] : 0 ;
}
void* getDrawingXfb() const {
return (mDrawingXfbIndex >= 0) ? mBuffer[mDrawingXfbIndex] : 0 ;
}
void* getDisplayingXfb() const {
return (mDisplayingXfbIndex >= 0) ? mBuffer[mDisplayingXfbIndex] : 0 ;
}
void setBufferNum(int num) {
mBufferNum = num;
}
void setDisplayingXfbIndex(s16 index) {
mDisplayingXfbIndex = index;
}
void setSDrawingFlag(s32 flag) {
mSDrawingFlag = flag;
}
void setDrawnXfbIndex(s16 index) {
mDrawnXfbIndex = index;
}
void setDrawingXfbIndex(s16 index) {
mDrawingXfbIndex = index;
}
static JUTXfb* getManager() {
return sManager;
}
private:
static JUTXfb* sManager;
private:
void* mBuffer[3];
bool mXfbAllocated[3];
int mBufferNum;
s16 mDrawingXfbIndex;
s16 mDrawnXfbIndex;
s16 mDisplayingXfbIndex;
s32 mSDrawingFlag;
};
struct JUTConsole;
struct JUTDirectPrint;
typedef void (*JUTErrorHandler)(OSError error, OSContext* context, u32 dsisr, u32 dar);
enum ExPrintFlags {
EXPRINTFLAG_GPR = 0x1,
EXPRINTFLAG_GPRMap = 0x2,
EXPRINTFLAG_Float = 0x4,
EXPRINTFLAG_Stack = 0x8,
EXPRINTFLAG_All = 0xFF,
};
struct JUTException : public JKRThread {
enum EInfoPage {
INFOPAGE_GPR = 1,
INFOPAGE_Float = 2,
INFOPAGE_Stack = 3,
INFOPAGE_GPRMap = 4,
};
struct JUTExMapFile {
inline JUTExMapFile(const char* fileName) : mLink(this) {
mFileName = (char*)fileName;
}
char* mFileName;
JSULink<JUTExMapFile> mLink;
};
struct ExCallbackObject {
JUTErrorHandler mErrorHandler;
s32 mError;
OSContext* mContext;
u32 _0C;
u32 _10;
};
JUTException(JUTDirectPrint*);
virtual ~JUTException() {};
virtual void* run();
void showFloat(OSContext*);
void showStack(OSContext*);
void showMainInfo(u16, OSContext*, u32, u32);
bool showMapInfo_subroutine(u32, bool);
void showGPRMap(OSContext*);
void printDebugInfo(JUTException::EInfoPage, u16, OSContext*, u32, u32);
bool readPad(u32*, u32*);
void printContext(u16, OSContext*, u32, u32);
void createFB();
static void waitTime(long);
static JUTErrorHandler setPreUserCallback(JUTErrorHandler);
static void appendMapFile(const char*);
static bool queryMapAddress(char*, u32, long, u32*, u32*, char*, u32, bool, bool);
static bool queryMapAddress_single(char*, u32, long, u32*, u32*, char*, u32, bool, bool);
static JUTException* create(JUTDirectPrint*);
static void createConsole(void* buffer, u32 bufferSize);
static void panic_f(const char* file, int line, const char* msg, ...);
static void errorHandler(u16, OSContext*, u32, u32);
static void setFPException(u32);
static bool searchPartialModule(u32, u32*, u32*, u32*, u32*);
static void panic_f_va(const char*, int, const char*, va_list);
static JUTErrorHandler setPostUserCallback(JUTErrorHandler);
static void panic(const char* file, int line, const char* msg) {
panic_f(file, line, "%s", msg);
}
void showFloatSub(int, f32);
void showGPR(OSContext*);
void showSRR0Map(OSContext*);
bool isEnablePad() const;
static u32 getFpscr();
void setFpscr(u32);
void enableFpuException();
void disableFpuException();
JUTExternalFB* getFrameMemory() const {
return mFrameMemory;
}
void setTraceSuppress(u32 supress) {
mTraceSuppress = supress;
}
void setGamePad(JUTGamePad* gamePad) {
mGamePad = gamePad;
mPadPort = JUTGamePad::Port_Invalid;
}
void enterAllPad() {
setGamePad((JUTGamePad*)-1);
}
static JUTException* getManager() {
return sErrorManager;
}
static JUTConsole* getConsole() {
return sConsole;
}
static JUTConsole* sConsole;
static void* sConsoleBuffer;
static size_t sConsoleBufferSize;
static JUTException* sErrorManager;
static OSMessageQueue sMessageQueue;
static void* sMessageBuffer[1];
static JUTErrorHandler sPreUserCallback;
static JUTErrorHandler sPostUserCallback;
static u32 msr;
static u32 fpscr;
static const char* sCpuExpName[16];
static JSUList<JUTExMapFile> sMapFileList;
JUTExternalFB* mFrameMemory;
JUTDirectPrint* mDirectPrint;
JUTGamePad* mGamePad;
JUTGamePad::EPadPort mPadPort;
int mPrintWaitTime0;
int mPrintWaitTime1;
u32 mTraceSuppress;
u32 _98;
u32 mPrintFlags;
};
static inline void* JKRGetResource(const char* resourceName) {
return JKRFileLoader::getGlbResource(resourceName);
}
static inline void JKRRemoveResource(void* resource) {
JKRFileLoader::removeResource(resource, 0 );
}
static inline BOOL JKRDetachResource(void* resource) {
return JKRFileLoader::detachResource(resource, 0 );
}
static inline void* JKRGetResourceEntry_byName(u32 root_name, const char* res_name, JKRArchive* archive) {
return archive->findTypeResource(root_name, res_name);
}
extern "C"{
extern u8 FrameCansel;
extern void emu64_set_aflags(int idx, int value);
extern int emu64_get_aflags(int idx);
}
extern "C"{
#pragma section code_type ".init"
void * memcpy(void * dst, const void * src, size_t n);
void * memset(void * dst, int val, size_t n);
int memcmp(const void* src1, const void* src2, size_t n);
void __fill_mem(void * dst, int val, unsigned long n);
#pragma section code_type
};
extern "C"{
typedef struct game_play_s GAME_PLAY;
}
extern "C"{
typedef u16 mActor_name_t;
typedef struct actor_s ACTOR;
typedef struct actor_profile_s ACTOR_PROFILE;
}
extern "C"{
extern double sin(double deg);
extern double cos(double deg);
extern double tan(double deg);
float sinf(float);
float cosf(float);
inline float sinf(float x) {
return (float)sin((double)x);
}
inline float cosf(float x) {
return (float)cos((double)x);
}
extern double ceil(double);
}
u32 qrand(void);
void sqrand(u32);
f32 fqrand(void);
f32 fqrand2(void);
extern "C"{
extern u16 U_GetAtanTable(f32 y, f32 x);
extern s16 atans_table(f32 x, f32 y);
extern f32 atanf_table(f32 x, f32 y);
extern void init_rnd();
extern f32 sinf_table(f32 x);
extern f32 cosf_table(f32 x);
}
extern "C"{
typedef struct xy_s {
f32 x, y;
} xy_t;
typedef struct xz_s {
f32 x, z;
} xz_t;
typedef struct xyz_s {
f32 x, y, z;
} xyz_t;
typedef struct s_xyz_s {
s16 x, y, z;
} s_xyz;
typedef struct s_xz_s {
s16 x, z;
} s_xz;
typedef struct {
u32 r:8;
u32 g:8;
u32 b:8;
u32 a:8;
} rgba8888_t;
typedef union {
u32 rgba8888;
rgba8888_t c;
} rgba8888;
typedef union {
struct {
u8 r, g, b, a;
};
u32 rgba;
} Color_RGBA8_u32;
}
extern "C"{
typedef struct game_s GAME;
}
extern "C"{
typedef struct {
size_t size;
char *buf_p;
char *head_p;
char *tail_p;
} TwoHeadArena_t;
typedef TwoHeadArena_t TwoHeadArena;
typedef TwoHeadArena_t THA;
extern void THA_ct(TwoHeadArena* tha, char* p, size_t n);
extern void THA_dt(TwoHeadArena* tha);
extern void* THA_getHeadPtr(TwoHeadArena* tha);
extern void THA_setHeadPtr(TwoHeadArena* tha, void* p);
extern void* THA_getTailPtr(TwoHeadArena* tha);
extern void* THA_nextPtrN(TwoHeadArena* tha, size_t n);
extern void* THA_nextPtr1(TwoHeadArena* tha);
extern void* THA_alloc(TwoHeadArena* tha, size_t siz);
extern void* THA_alloc16(TwoHeadArena* tha, size_t siz);
extern void* THA_allocAlign(TwoHeadArena* tha, size_t siz, int mask);
extern int THA_isCrash(TwoHeadArena* tha);
extern void THA_init(TwoHeadArena* tha);
extern int THA_getFreeBytes16(TwoHeadArena* tha);
extern int THA_getFreeBytes(TwoHeadArena* tha);
extern int THA_getFreeBytesAlign(TwoHeadArena* tha, int mask);
};
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef volatile unsigned char vu8;
typedef volatile unsigned short vu16;
typedef volatile unsigned long vu32;
typedef volatile unsigned long long vu64;
typedef volatile signed char vs8;
typedef volatile short vs16;
typedef volatile long vs32;
typedef volatile long long vs64;
typedef float f32;
typedef double f64;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
unsigned char cn[4];
} Vtx_t;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
signed char n[3];
unsigned char a;
} Vtx_tn;
typedef union {
Vtx_t v;
Vtx_tn n;
long long int force_structure_alignment;
} Vtx;
typedef struct {
void *SourceImagePointer;
void *TlutPointer;
short Stride;
short SubImageWidth;
short SubImageHeight;
char SourceImageType;
char SourceImageBitSize;
short SourceImageOffsetS;
short SourceImageOffsetT;
char dummy[4];
} uSprite_t;
typedef union {
uSprite_t s;
long long int force_structure_allignment[3];
} uSprite;
typedef struct {
unsigned char flag;
unsigned char v[3];
} Tri;
typedef long Mtx_t[4][4];
typedef union {
Mtx_t m;
long long int force_structure_alignment;
} Mtx;
typedef struct {
short vscale[4];
short vtrans[4];
} Vp_t;
typedef union {
Vp_t vp;
long long int force_structure_alignment;
} Vp;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
signed char dir[3];
char pad3;
} Light_t;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
} Ambient_t;
typedef struct {
int x1,y1,x2,y2;
} Hilite_t;
typedef union {
Light_t l;
long long int force_structure_alignment[2];
} Light;
typedef union {
Ambient_t l;
long long int force_structure_alignment[1];
} Ambient;
typedef struct {
Ambient a;
Light l[7];
} Lightsn;
typedef struct {
Ambient a;
Light l[1];
} Lights0;
typedef struct {
Ambient a;
Light l[1];
} Lights1;
typedef struct {
Ambient a;
Light l[2];
} Lights2;
typedef struct {
Ambient a;
Light l[3];
} Lights3;
typedef struct {
Ambient a;
Light l[4];
} Lights4;
typedef struct {
Ambient a;
Light l[5];
} Lights5;
typedef struct {
Ambient a;
Light l[6];
} Lights6;
typedef struct {
Ambient a;
Light l[7];
} Lights7;
typedef struct {
Light l[2];
} LookAt;
typedef union {
Hilite_t h;
long int force_structure_alignment[4];
} Hilite;
typedef struct {
int cmd:8;
unsigned int par:8;
unsigned int len:16;
unsigned int addr;
} Gdma;
typedef struct {
int cmd:8;
int pad:24;
Tri tri;
} Gtri;
typedef struct {
int cmd:8;
int pad1:24;
int pad2:24;
unsigned int param:8;
} Gpopmtx;
typedef struct {
int cmd:8;
int pad0:8;
int mw_index:8;
int number:8;
int pad1:8;
int base:24;
} Gsegment;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeL;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeH;
typedef struct {
unsigned char cmd;
unsigned char lodscale;
unsigned char tile;
unsigned char on;
unsigned short s;
unsigned short t;
} Gtexture;
typedef struct {
int cmd:8;
int pad:24;
Tri line;
} Gline3D;
typedef struct {
int cmd:8;
int pad1:24;
short int pad2;
short int scale;
} Gperspnorm;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad:7;
unsigned int wd:12;
unsigned int dram;
} Gsetimg;
typedef struct {
int cmd:8;
unsigned int muxs0:24;
unsigned int muxs1:32;
} Gsetcombine;
typedef struct {
int cmd:8;
unsigned char pad;
unsigned char prim_min_level;
unsigned char prim_level;
unsigned long color;
} Gsetcolor;
typedef struct {
int cmd:8;
int x0:10;
int x0frac:2;
int y0:10;
int y0frac:2;
unsigned int pad:8;
int x1:10;
int x1frac:2;
int y1:10;
int y1frac:2;
} Gfillrect;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad0:1;
unsigned int line:9;
unsigned int tmem:9;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int palette:4;
unsigned int ct:1;
unsigned int mt:1;
unsigned int maskt:4;
unsigned int shiftt:4;
unsigned int cs:1;
unsigned int ms:1;
unsigned int masks:4;
unsigned int shifts:4;
} Gsettile;
typedef struct {
int cmd:8;
unsigned int sl:12;
unsigned int tl:12;
int pad:5;
unsigned int tile:3;
unsigned int sh:12;
unsigned int th:12;
} Gloadtile;
typedef Gloadtile Gloadblock;
typedef Gloadtile Gsettilesize;
typedef Gloadtile Gloadtlut;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int s:16;
unsigned int t:16;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect;
typedef struct {
unsigned long w0;
unsigned long w1;
unsigned long w2;
unsigned long w3;
} TexRect;
typedef struct {
unsigned int w0;
unsigned int w1;
} Gwords;
typedef union {
Gwords words;
Gdma dma;
Gtri tri;
Gline3D line;
Gpopmtx popmtx;
Gsegment segment;
GsetothermodeH setothermodeH;
GsetothermodeL setothermodeL;
Gtexture texture;
Gperspnorm perspnorm;
Gsetimg setimg;
Gsetcombine setcombine;
Gsetcolor setcolor;
Gfillrect fillrect;
Gsettile settile;
Gloadtile loadtile;
Gsettilesize settilesize;
Gloadtlut loadtlut;
long long int force_structure_alignment;
} Gfx;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Aadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Apolef;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvelope;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmem:16;
unsigned int pad2:16;
unsigned int count:16;
} Aclearbuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int inL:16;
unsigned int inR:16;
} Ainterleave;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Aloadbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvmixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int dmemi:16;
unsigned int dmemo:16;
} Amixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmem2:16;
unsigned int addr;
} Apan;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pitch:16;
unsigned int addr;
} Aresample;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Areverb;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Asavebuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int pad2:2;
unsigned int number:4;
unsigned int base:24;
} Asegment;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Asetbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int vol:16;
unsigned int voltgt:16;
unsigned int volrate:16;
} Asetvol;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Admemmove;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int count:16;
unsigned int addr;
} Aloadadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int addr;
} Asetloop;
typedef struct {
unsigned int w0;
unsigned int w1;
} Awords;
typedef union {
Awords words;
Aadpcm adpcm;
Apolef polef;
Aclearbuff clearbuff;
Aenvelope envelope;
Ainterleave interleave;
Aloadbuff loadbuff;
Aenvmixer envmixer;
Aresample resample;
Areverb reverb;
Asavebuff savebuff;
Asegment segment;
Asetbuff setbuff;
Asetvol setvol;
Admemmove dmemmove;
Aloadadpcm loadadpcm;
Amixer mixer;
Asetloop setloop;
long long int force_union_align;
} Acmd;
typedef short ADPCM_STATE[16 ];
typedef short POLEF_STATE[4];
typedef short RESAMPLE_STATE[16];
typedef short ENVMIX_STATE[40];
extern "C"{
typedef struct {
size_t size;
Gfx* buf_p;
Gfx* head_p;
Gfx* tail_p;
} TwoHeadArenaGfx_t;
typedef TwoHeadArenaGfx_t TwoHeadArenaGfx;
typedef union {
TwoHeadArena tha;
TwoHeadArenaGfx thaGfx;
} THA_GA_t;
typedef THA_GA_t THA_GA;
extern void THA_GA_ct(THA_GA* tha_ga, Gfx* p, size_t n);
extern void THA_GA_dt(THA_GA* tha_ga);
extern int THA_GA_isCrash(THA_GA* tha_ga);
extern void THA_GA_init(THA_GA* tha_ga);
extern int THA_GA_getFreeBytes(THA_GA* tha_ga);
extern void* THA_GA_getTailPtr(THA_GA* tha_ga);
extern void* THA_GA_nextPtrN(THA_GA* tha_ga, size_t n);
extern void* THA_GA_nextPtr1(THA_GA* tha_ga);
extern Gfx* THA_GA_NEXT_DISP(THA_GA* tha_ga);
extern void* THA_GA_getHeadPtr(THA_GA* tha_ga);
extern void THA_GA_setHeadPtr(THA_GA* tha_ga, void *p);
extern Mtx* THA_GA_alloc(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtxN(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtx1(THA_GA* tha_ga);
extern Vtx* THA_GA_allocVtxN(THA_GA* tha_ga, size_t n);
extern Vtx* THA_GA_allocVtx1(THA_GA* tha_ga);
};
extern "C"{
typedef struct boot_tbl_s {
const char* msg;
u16 param_upper;
u16 param_lower;
} boot_tbl_t;
extern u32 convert_partial_address(u32 partial_addr);
extern void HotResetIplMenu();
extern void* boot_copyDate;
extern void* HotStartEntry;
extern OSTime InitialStartTime;
extern u8 boot_sound_initializing;
typedef void(*HotStartProc)();
OSModuleHeader* BaseModule : (0x800030C8) ;
}
extern "C"{
typedef enum {
GRAPH_DOING_ZERO = 0,
GRAPH_DOING_CT,
GRAPH_DOING_GAME_CT,
GRAPH_DOING_GAME_CT_FINISHED,
GRAPH_DOING_GAME_MAIN,
GRAPH_DOING_GAME_TIME,
GRAPH_DOING_GAME_TIME_FINISHED,
GRAPH_DOING_GAME_EXEC,
GRAPH_DOING_GAME_EXEC_FINISHED,
GRAPH_DOING_GAME_BGM,
GRAPH_DOING_GAME_BGM_FINISHED,
GRAPH_DOING_GAME_MAIN_FINISHED,
GRAPH_DOING_TASK_SET,
GRAPH_DOING_WAIT_TASK,
GRAPH_DOING_WAIT_TASK_FINISHED,
GRAPH_DOING_TASK_SET_FINISHED,
GRAPH_DOING_AUDIO,
GRAPH_DOING_AUDIO_FINISHED,
GRAPH_DOING_GAME_18,
GRAPH_DOING_GAME_DT,
GRAPH_DOING_GAME_DT_FINISHED,
GRAPH_DOING_DT,
GRAPH_DOING_END
} GRAPH_DOING_POINT;
typedef struct graph_s {
Gfx* Gfx_list00;
Gfx* Gfx_list01;
void* DepthBuffer;
Gfx* Gfx_list03;
Gfx* Gfx_list04;
Gfx* Gfx_list07;
Gfx* Gfx_list08;
Gfx* Gfx_list09;
Gfx* gfxsave;
u8 _unk24[32];
OSMessage graphReplyMesgBuf[8 ];
OSMessageQueue* schedMesgQueue;
OSMessageQueue graphReplyMesgQueue;
u8 _unused_ossctask00p[0x68];
u8 _unused_ossctask01p[0x68];
u8 _unused_ossctask02p[0x68];
Gfx* Gfx_list05;
THA_GA work_thaga;
u8 _unk1D4[0xBC];
void* scheduler;
void* vimode;
THA_GA line_opaque_thaga;
THA_GA line_translucent_thaga;
THA_GA overlay_thaga;
THA_GA polygon_opaque_thaga;
THA_GA polygon_translucent_thaga;
THA_GA font_thaga;
THA_GA shadow_thaga;
THA_GA light_thaga;
THA_GA bg_opaque_thaga;
THA_GA bg_translucent_thaga;
int frame_counter;
u16* frameBuffer;
u16* renderBuffer;
u32 vispecial;
u8 doing_point;
u8 _unk349;
u8 need_viupdate;
u8 cfb_bank;
void (*taskEndCallback)(struct graph_s*, void*);
void* taskEndData;
f32 vixscale;
f32 viyscale;
Gfx* last_dl;
Gfx* Gfx_list10;
Gfx* Gfx_list11;
} GRAPH __attribute__((aligned(8))) ;
extern void graph_proc(void* arg);
extern void graph_ct(GRAPH* graph);
extern void graph_dt(GRAPH* graph);
extern u8 SoftResetEnable;
extern GRAPH graph_class;
};
extern "C"{
typedef struct gameAllocList_s {
struct gameAllocList_s* next;
struct gameAllocList_s* prev;
size_t alloc_size;
u32 pad;
} GameAllocList;
typedef struct gameAlloc_s {
GameAllocList head;
GameAllocList* tail;
} GameAlloc;
extern void* gamealloc_malloc(GameAlloc* gamealloc, size_t size);
extern void gamealloc_free(GameAlloc* gamealloc, void* ptr);
extern void gamealloc_cleanup(GameAlloc* gamealloc);
extern void gamealloc_init(GameAlloc* gamealloc);
};
extern "C"{
}
extern "C"{
typedef struct {
u16 type;
u8 status;
u8 errno;
} OSContStatus;
typedef struct {
u16 button;
s8 stick_x;
s8 stick_y;
u8 errno;
} OSContPad;
typedef struct {
OSContPad pad;
s8 substickX;
s8 substickY;
u8 triggerR;
u8 triggerL;
} OSContPadEx;
extern s32 osContInit(OSMessageQueue* mq, u8* pattern_p, OSContStatus* status);
extern s32 osContStartQuery(OSMessageQueue* mq);
extern s32 osContStartReadData(OSMessageQueue* mq);
extern void osContGetQuery(OSContStatus* status);
extern s32 osContSetCh(u8 num_controllers);
extern void osContGetReadData(OSContPad* pad);
extern void osContGetReadDataEx(OSContPadEx* pad);
}
extern "C"{
typedef struct {
OSContPad now;
OSContPad last;
OSContPad on;
OSContPad off;
} pad_t;
int pad_physical_stick_x(pad_t*);
int pad_physical_stick_y(pad_t*);
void pad_set_logical_stick(pad_t*, int, int);
void pad_correct_stick(pad_t*);
}
extern "C"{
typedef struct controller_s {
f32 move_pX;
f32 move_pY;
f32 move_pR;
s16 move_angle;
f32 last_move_pX;
f32 last_move_pY;
f32 last_move_pR;
s16 last_move_angle;
f32 adjusted_pX;
f32 adjusted_pY;
f32 adjusted_pR;
f32 last_adjusted_pX;
f32 last_adjusted_pY;
f32 last_adjusted_pR;
} MCON;
extern void mCon_ct();
extern void mCon_dt();
extern void mCon_calc(MCON* mcon, f32 stick_x, f32 stick_y);
extern void mCon_main(GAME* game);
extern int chkButton(u16 button);
extern u16 getButton();
extern int chkTrigger(u16 button);
extern u16 getTrigger();
extern int getJoystick_X();
extern int getJoystick_Y();
}
extern "C"{
struct game_s {
GRAPH* graph;
void (*exec)(struct game_s* );
void (*cleanup)(struct game_s*);
void (*next_game_init)(struct game_s*);
size_t next_game_class_size;
pad_t pads[4 ];
int pad_initialized;
THA tha;
GameAlloc gamealloc;
u8 doing_point;
u8 doing_point_specific;
u8 disable_display;
u8 doing;
u32 frame_counter;
int disable_prenmi;
MCON mcon;
};
extern void game_debug_draw_last(GAME* game, GRAPH* graph);
extern void game_draw_last(GRAPH* graph);
extern void game_get_controller(GAME* game);
extern void SetGameFrame(int frame);
extern void game_main(GAME* game);
extern void game_resize_hyral(GAME* game, int size);
extern void game_ct(GAME* game, void (*init)(GAME*), GRAPH* graph);
extern void game_dt(GAME* game);
extern void (*game_get_next_game_init(GAME* game))(GAME*);
extern int game_is_doing(GAME* game);
extern int game_getFreeBytes(GAME* game);
extern void game_goto_next_game_play(GAME* game);
extern GAME* gamePT;
extern GAME* game_class_p;
extern u8 game_GameFrame;
extern float game_GameFrameF;
extern float game_GameFrame_2F;
extern float game_GameFrame__1F;
};
extern "C"{
typedef struct rgba_t {
u8 r, g, b, a;
} rgba_t;
typedef struct rgb_t {
uint r, g, b;
} rgb_t;
typedef struct rgb8_t {
u8 r, g, b;
} rgb8_t;
typedef struct {
xyz_t position;
s_xyz angle;
} PositionAngle;
extern void mem_copy(u8* dst, u8* src, size_t size);
extern void mem_clear(u8* dst, size_t size, u8 val);
extern int mem_cmp(u8* p1, u8* p2, size_t size);
extern f32 cos_s(s16 angle);
extern f32 sin_s(s16 angle);
extern int chase_angle(s16* const pValue, const s16 target, s16 step);
extern int chase_s(s16* const pValue, const s16 target, s16 step);
extern int chase_f(f32* const pValue, const f32 target, f32 step);
extern f32 chase_xyz_t(xyz_t* const pValue, const xyz_t* const target, const f32 fraction);
extern int chase_angle2(s16* const pValue, const s16 limit, const s16 step);
extern void inter_float(f32* const pValue, const f32 arg1, const int step);
extern s16 get_random_timer(const s16 base, const s16 range);
extern void xyz_t_move(xyz_t* const dest, const xyz_t* const src);
extern void xyz_t_move_s_xyz(xyz_t* const dest, const s_xyz* const src);
extern void xyz_t_add(const xyz_t* const augend, const xyz_t* const addend, xyz_t* const total);
extern void xyz_t_sub(const xyz_t* const minuend, const xyz_t* const subtrahend, xyz_t* const diff);
extern void xyz_t_mult_v(xyz_t* const multiplicand, const f32 multiplier);
extern f32 search_position_distance(const xyz_t* const pos, const xyz_t* const target);
extern f32 search_position_distanceXZ(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleY(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleX(const xyz_t* const pos, const xyz_t* const target);
extern f32 add_calc(f32* pValue, f32 target, f32 fraction, f32 maxStep, f32 minStep);
extern void add_calc2(f32* pValue, f32 target, f32 fraction, f32 maxStep);
extern void add_calc0(f32* pValue, f32 fraction, f32 maxStep);
extern s16 add_calc_short_angle2(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern s16 add_calc_short_angle3(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern void rgba_t_move(rgba_t* dest, const rgba_t* const src);
extern int none_proc1();
extern void none_proc2(ACTOR* actor, GAME* game);
extern int _Game_play_isPause(GAME_PLAY* play);
extern f32 check_percent_abs(f32 x, f32 min, f32 max, f32 scale, int shift_by_min);
extern f32 get_percent_forAccelBrake(f32 now, f32 start, f32 end, f32 accelerateDist, f32 brakeDist);
extern void Game_play_Projection_Trans(GAME_PLAY* const play, xyz_t* world_pos, xyz_t* screen_pos);
extern f32 get_percent(const int max, const int min, const int x);
}
extern "C"{
extern void* malloc(size_t size);
extern void free(void* ptr);
extern void MallocInit(void* base, size_t len);
extern void MallocCleanup();
extern int MallocIsInitalized();
extern void GetFreeArena(size_t* max_size, size_t* free_size, size_t* alloc_size);
extern int CheckArena();
extern void DisplayArena();
}
extern void JW_JUTGamePad_read() {
static OSTime last_pad_read;
OSTime now = OSGetTime();
if (now > last_pad_read + ((16) * ((__OSBusClock/4) / 1000)) || now < last_pad_read) {
last_pad_read = now;
JC_JUTGamePad_read();
}
}
