
extern int signgam;
enum fdversion { fdlibm_ieee = -1, fdlibm_svid, fdlibm_xopen, fdlibm_posix };
extern enum fdversion _fdlib_version ;
struct exception {
int type;
char* name;
double arg1;
double arg2;
double retval;
};
extern double acos (double) ;
extern double asin (double) ;
extern double atan (double) ;
extern double atan2 (double, double) ;
extern double cos (double) ;
extern double sin (double) ;
extern double tan (double) ;
extern double cosh (double) ;
extern double sinh (double) ;
extern double tanh (double) ;
extern double exp (double) ;
extern double frexp (double, int*) ;
extern double ldexp (double, int) ;
extern double scalbn (double, int) ;
extern double log (double) ;
extern double log10 (double) ;
extern double modf (double, double*) ;
extern double pow (double, double) ;
extern double sqrt (double) ;
extern double ceil (double) ;
extern double fabs (double) ;
extern double fabs__Fd(double);
extern double floor (double) ;
extern double fmod (double, double) ;
extern double erf (double) ;
extern double erfc (double) ;
extern double gamma (double) ;
extern double hypot (double, double) ;
extern int isnan (double) ;
extern int finite (double) ;
extern double j0 (double) ;
extern double j1 (double) ;
extern double jn (int, double) ;
extern double lgamma (double) ;
extern double y0 (double) ;
extern double y1 (double) ;
extern double yn (int, double) ;
extern double acosh (double) ;
extern double asinh (double) ;
extern double atanh (double) ;
extern double cbrt (double) ;
extern double logb (double) ;
extern double nextafter (double, double) ;
extern double remainder (double, double) ;
extern double scalb (double, double) ;
extern int matherr (struct exception*) ;
extern double significand (double) ;
extern double copysign (double, double) ;
extern int ilogb (double) ;
extern double rint (double) ;
extern double scalbn (double, int) ;
extern double expm1 (double) ;
extern double log1p (double) ;
extern double __ieee754_sqrt (double) ;
extern double __ieee754_acos (double) ;
extern double __ieee754_acosh (double) ;
extern double __ieee754_log (double) ;
extern double __ieee754_atanh (double) ;
extern double __ieee754_asin (double) ;
extern double __ieee754_atan2 (double, double) ;
extern double __ieee754_exp (double) ;
extern double __ieee754_cosh (double) ;
extern double __ieee754_fmod (double, double) ;
extern double __ieee754_pow (double, double) ;
extern double __ieee754_lgamma_r (double, int*) ;
extern double __ieee754_gamma_r (double, int*) ;
extern double __ieee754_lgamma (double) ;
extern double __ieee754_gamma (double) ;
extern double __ieee754_log10 (double) ;
extern double __ieee754_sinh (double) ;
extern double __ieee754_hypot (double, double) ;
extern double __ieee754_j0 (double) ;
extern double __ieee754_j1 (double) ;
extern double __ieee754_y0 (double) ;
extern double __ieee754_y1 (double) ;
extern double __ieee754_jn (int, double) ;
extern double __ieee754_yn (int, double) ;
extern double __ieee754_remainder (double, double) ;
extern int __ieee754_rem_pio2 (double, double*) ;
extern double __ieee754_scalb (double, double) ;
extern double __kernel_standard (double, double, int) ;
extern double __kernel_sin (double, double, int) ;
extern double __kernel_cos (double, double) ;
extern double __kernel_tan (double, double, int) ;
extern int __kernel_rem_pio2 (double*, double*, int, int, int, const int*) ;
inline double fabs(double x) {
return __fabs(x);
}
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_nan[];
extern unsigned long __float_huge[];
extern unsigned long __float_max[];
extern unsigned long __float_epsilon[];
inline int __fpclassifyf(float __value)
{
unsigned long integer = *(unsigned long*)&__value;
switch (integer & 0x7f800000) {
case 0x7f800000:
if ((integer & 0x7fffff) != 0) {
return 1 ;
}
return 2 ;
case 0:
if ((integer & 0x7fffff) != 0) {
return 5 ;
}
return 3 ;
}
return 4 ;
}
inline int __fpclassifyd(double __value)
{
switch (*(int*)&__value & 0x7ff00000) {
case 0x7ff00000: {
if ((*(int*)&__value & 0x000fffff) || (*(1 + (int*)&__value) & 0xffffffff))
return 1 ;
else
return 2 ;
break;
}
case 0: {
if ((*(int*)&__value & 0x000fffff) || (*(1 + (int*)&__value) & 0xffffffff))
return 5 ;
else
return 3 ;
break;
}
}
return 4 ;
}
extern inline float sqrtf(float x) {
static const double _half = .5;
static const double _three = 3.0;
volatile float y;
if (x > 0.0f) {
double guess = __frsqrte((double)x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
guess = _half * guess * (_three - guess * guess * x);
y = (float)(x * guess);
return y;
}
return x;
}
inline float fabsf(float x) {
return (float)fabs((double)x);
}
extern inline double sqrt(double x) {
if (x > 0.0) {
double guess = __frsqrte(x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
guess = .5 * guess * (3.0 - guess * guess * x);
return x * guess;
} else if (x == 0.0f) {
return 0.0;
} else if (x) {
return (*(float*)__float_nan) ;
}
return (*(float*)__float_huge) ;
}
typedef signed char s8;
typedef unsigned char u8;
typedef signed short int s16;
typedef unsigned short int u16;
typedef signed long s32;
typedef unsigned long u32;
typedef signed long long int s64;
typedef unsigned long long int u64;
typedef float f32;
typedef double f64;
typedef char *Ptr;
typedef unsigned int uintptr_t;
typedef int BOOL;
typedef struct {
char gpr;
char fpr;
char reserved[2];
char* input_arg_area;
char* reg_save_area;
} __va_list[1];
typedef __va_list va_list;
void* __va_arg(va_list v_list, int type);
typedef unsigned long size_t;
typedef unsigned long __file_handle;
typedef unsigned long fpos_t;
typedef unsigned short wchar_t;
enum __file_kinds {
__closed_file,
__disk_file,
__console_file,
__string_file,
__unavailable_file = 3,
};
enum __file_orientation {
UNORIENTED,
CHAR_ORIENTED,
WIDE_ORIENTED,
};
typedef struct _file_modes {
unsigned int open_mode : 2;
unsigned int io_mode : 3;
unsigned int buffer_mode : 2;
unsigned int file_kind : 3;
unsigned int file_orientation : 2;
unsigned int binary_io : 1;
} file_modes;
enum __io_modes {
__read = 1,
__write = 2,
__read_write = 3,
__append = 4,
};
enum __io_states {
__neutral,
__writing,
__reading,
__rereading,
};
enum __io_results {
__no_io_error,
__io_error,
__io_EOF,
};
typedef struct _file_states {
unsigned int io_state : 3;
unsigned int free_buffer : 1;
unsigned char eof;
unsigned char error;
} file_states;
typedef void (*__idle_proc)(void);
typedef int (*__pos_proc)(__file_handle file, fpos_t* position, int mode, __idle_proc idle_proc);
typedef int (*__io_proc)(__file_handle file, unsigned char* buff, size_t* count, __idle_proc idle_proc);
typedef int (*__close_proc)(__file_handle file);
typedef struct _FILE {
__file_handle handle;
file_modes file_mode;
file_states file_state;
unsigned char char_buffer;
char char_buffer_overflow;
char ungetc_buffer[4];
wchar_t ungetc_wide_buffer[2];
unsigned long position;
unsigned char* buffer;
unsigned long buffer_size;
unsigned char* buffer_ptr;
unsigned long buffer_length;
unsigned long buffer_alignment;
unsigned long save_buffer_length;
unsigned long buffer_position;
__pos_proc position_fn;
__io_proc read_fn;
__io_proc write_fn;
__close_proc close_fn;
__idle_proc idle_fn;
void* next;
} FILE;
typedef struct _files {
FILE _stdin;
FILE _stdout;
FILE _stderr;
FILE _sentinel;
} files;
extern files __files;
int puts(const char *s);
int printf(const char *, ...);
int sprintf(char *s, const char *format, ...);
int vprintf(const char *format, va_list arg);
int vsprintf(char *s, const char *format, va_list arg);
size_t strlen(const char *s);
long strtol(const char *str, char **end, int base);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t num);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
char *strncat(char *dest, const char *src, size_t n);
char *strchr(const char *str, int c);
char* strrchr( char* str, int chr );
char* strstr(const char* str, const char* pat);
char* strcat(char* dst, const char* src);
int tolower(int c);
float powf(float x, float y);
float tanf(float);
typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long s64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef unsigned int uint;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;
typedef int BOOL;
typedef void* unkptr;
typedef u32 unknown;
#pragma section RX "forcestrip"
typedef unsigned short wchar_t;
typedef struct game_play_s GAME_PLAY;
typedef u16 mActor_name_t;
typedef struct actor_s ACTOR;
typedef struct actor_profile_s ACTOR_PROFILE;
extern double sin(double deg);
extern double cos(double deg);
extern double tan(double deg);
float sinf(float);
float cosf(float);
inline float sinf(float x) {
return (float)sin((double)x);
}
inline float cosf(float x) {
return (float)cos((double)x);
}
extern double ceil(double);
u32 qrand(void);
void sqrand(u32);
f32 fqrand(void);
f32 fqrand2(void);
extern u16 U_GetAtanTable(f32 y, f32 x);
extern s16 atans_table(f32 x, f32 y);
extern f32 atanf_table(f32 x, f32 y);
extern void init_rnd();
extern f32 sinf_table(f32 x);
extern f32 cosf_table(f32 x);
typedef struct xy_s {
f32 x, y;
} xy_t;
typedef struct xz_s {
f32 x, z;
} xz_t;
typedef struct xyz_s {
f32 x, y, z;
} xyz_t;
typedef struct s_xyz_s {
s16 x, y, z;
} s_xyz;
typedef struct s_xz_s {
s16 x, z;
} s_xz;
typedef struct {
u32 r:8;
u32 g:8;
u32 b:8;
u32 a:8;
} rgba8888_t;
typedef union {
u32 rgba8888;
rgba8888_t c;
} rgba8888;
typedef union {
struct {
u8 r, g, b, a;
};
u32 rgba;
} Color_RGBA8_u32;
typedef struct game_s GAME;
typedef struct {
size_t size;
char *buf_p;
char *head_p;
char *tail_p;
} TwoHeadArena_t;
typedef TwoHeadArena_t TwoHeadArena;
typedef TwoHeadArena_t THA;
extern void THA_ct(TwoHeadArena* tha, char* p, size_t n);
extern void THA_dt(TwoHeadArena* tha);
extern void* THA_getHeadPtr(TwoHeadArena* tha);
extern void THA_setHeadPtr(TwoHeadArena* tha, void* p);
extern void* THA_getTailPtr(TwoHeadArena* tha);
extern void* THA_nextPtrN(TwoHeadArena* tha, size_t n);
extern void* THA_nextPtr1(TwoHeadArena* tha);
extern void* THA_alloc(TwoHeadArena* tha, size_t siz);
extern void* THA_alloc16(TwoHeadArena* tha, size_t siz);
extern void* THA_allocAlign(TwoHeadArena* tha, size_t siz, int mask);
extern int THA_isCrash(TwoHeadArena* tha);
extern void THA_init(TwoHeadArena* tha);
extern int THA_getFreeBytes16(TwoHeadArena* tha);
extern int THA_getFreeBytes(TwoHeadArena* tha);
extern int THA_getFreeBytesAlign(TwoHeadArena* tha, int mask);
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;
typedef signed char s8;
typedef short s16;
typedef long s32;
typedef long long s64;
typedef volatile unsigned char vu8;
typedef volatile unsigned short vu16;
typedef volatile unsigned long vu32;
typedef volatile unsigned long long vu64;
typedef volatile signed char vs8;
typedef volatile short vs16;
typedef volatile long vs32;
typedef volatile long long vs64;
typedef float f32;
typedef double f64;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
unsigned char cn[4];
} Vtx_t;
typedef struct {
short ob[3];
unsigned short flag;
short tc[2];
signed char n[3];
unsigned char a;
} Vtx_tn;
typedef union {
Vtx_t v;
Vtx_tn n;
long long int force_structure_alignment;
} Vtx;
typedef struct {
void *SourceImagePointer;
void *TlutPointer;
short Stride;
short SubImageWidth;
short SubImageHeight;
char SourceImageType;
char SourceImageBitSize;
short SourceImageOffsetS;
short SourceImageOffsetT;
char dummy[4];
} uSprite_t;
typedef union {
uSprite_t s;
long long int force_structure_allignment[3];
} uSprite;
typedef struct {
unsigned char flag;
unsigned char v[3];
} Tri;
typedef long Mtx_t[4][4];
typedef union {
Mtx_t m;
long long int force_structure_alignment;
} Mtx;
typedef struct {
short vscale[4];
short vtrans[4];
} Vp_t;
typedef union {
Vp_t vp;
long long int force_structure_alignment;
} Vp;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
signed char dir[3];
char pad3;
} Light_t;
typedef struct {
unsigned char col[3];
char pad1;
unsigned char colc[3];
char pad2;
} Ambient_t;
typedef struct {
int x1,y1,x2,y2;
} Hilite_t;
typedef union {
Light_t l;
long long int force_structure_alignment[2];
} Light;
typedef union {
Ambient_t l;
long long int force_structure_alignment[1];
} Ambient;
typedef struct {
Ambient a;
Light l[7];
} Lightsn;
typedef struct {
Ambient a;
Light l[1];
} Lights0;
typedef struct {
Ambient a;
Light l[1];
} Lights1;
typedef struct {
Ambient a;
Light l[2];
} Lights2;
typedef struct {
Ambient a;
Light l[3];
} Lights3;
typedef struct {
Ambient a;
Light l[4];
} Lights4;
typedef struct {
Ambient a;
Light l[5];
} Lights5;
typedef struct {
Ambient a;
Light l[6];
} Lights6;
typedef struct {
Ambient a;
Light l[7];
} Lights7;
typedef struct {
Light l[2];
} LookAt;
typedef union {
Hilite_t h;
long int force_structure_alignment[4];
} Hilite;
typedef struct {
int cmd:8;
unsigned int par:8;
unsigned int len:16;
unsigned int addr;
} Gdma;
typedef struct {
int cmd:8;
int pad:24;
Tri tri;
} Gtri;
typedef struct {
int cmd:8;
int pad1:24;
int pad2:24;
unsigned int param:8;
} Gpopmtx;
typedef struct {
int cmd:8;
int pad0:8;
int mw_index:8;
int number:8;
int pad1:8;
int base:24;
} Gsegment;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeL;
typedef struct {
int cmd:8;
int pad0:8;
int sft:8;
int len:8;
unsigned int data:32;
} GsetothermodeH;
typedef struct {
unsigned char cmd;
unsigned char lodscale;
unsigned char tile;
unsigned char on;
unsigned short s;
unsigned short t;
} Gtexture;
typedef struct {
int cmd:8;
int pad:24;
Tri line;
} Gline3D;
typedef struct {
int cmd:8;
int pad1:24;
short int pad2;
short int scale;
} Gperspnorm;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad:7;
unsigned int wd:12;
unsigned int dram;
} Gsetimg;
typedef struct {
int cmd:8;
unsigned int muxs0:24;
unsigned int muxs1:32;
} Gsetcombine;
typedef struct {
int cmd:8;
unsigned char pad;
unsigned char prim_min_level;
unsigned char prim_level;
unsigned long color;
} Gsetcolor;
typedef struct {
int cmd:8;
int x0:10;
int x0frac:2;
int y0:10;
int y0frac:2;
unsigned int pad:8;
int x1:10;
int x1frac:2;
int y1:10;
int y1frac:2;
} Gfillrect;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int pad0:1;
unsigned int line:9;
unsigned int tmem:9;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int palette:4;
unsigned int ct:1;
unsigned int mt:1;
unsigned int maskt:4;
unsigned int shiftt:4;
unsigned int cs:1;
unsigned int ms:1;
unsigned int masks:4;
unsigned int shifts:4;
} Gsettile;
typedef struct {
int cmd:8;
unsigned int sl:12;
unsigned int tl:12;
int pad:5;
unsigned int tile:3;
unsigned int sh:12;
unsigned int th:12;
} Gloadtile;
typedef Gloadtile Gloadblock;
typedef Gloadtile Gsettilesize;
typedef Gloadtile Gloadtlut;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int s:16;
unsigned int t:16;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect;
typedef struct {
unsigned long w0;
unsigned long w1;
unsigned long w2;
unsigned long w3;
} TexRect;
typedef struct {
unsigned int w0;
unsigned int w1;
} Gwords;
typedef union {
Gwords words;
Gdma dma;
Gtri tri;
Gline3D line;
Gpopmtx popmtx;
Gsegment segment;
GsetothermodeH setothermodeH;
GsetothermodeL setothermodeL;
Gtexture texture;
Gperspnorm perspnorm;
Gsetimg setimg;
Gsetcombine setcombine;
Gsetcolor setcolor;
Gfillrect fillrect;
Gsettile settile;
Gloadtile loadtile;
Gsettilesize settilesize;
Gloadtlut loadtlut;
long long int force_structure_alignment;
} Gfx;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Aadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int addr;
} Apolef;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvelope;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmem:16;
unsigned int pad2:16;
unsigned int count:16;
} Aclearbuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int inL:16;
unsigned int inR:16;
} Ainterleave;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Aloadbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Aenvmixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int gain:16;
unsigned int dmemi:16;
unsigned int dmemo:16;
} Amixer;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmem2:16;
unsigned int addr;
} Apan;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pitch:16;
unsigned int addr;
} Aresample;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int pad1:16;
unsigned int addr;
} Areverb;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int addr;
} Asavebuff;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:24;
unsigned int pad2:2;
unsigned int number:4;
unsigned int base:24;
} Asegment;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Asetbuff;
typedef struct {
unsigned int cmd:8;
unsigned int flags:8;
unsigned int vol:16;
unsigned int voltgt:16;
unsigned int volrate:16;
} Asetvol;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int dmemin:16;
unsigned int dmemout:16;
unsigned int count:16;
} Admemmove;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int count:16;
unsigned int addr;
} Aloadadpcm;
typedef struct {
unsigned int cmd:8;
unsigned int pad1:8;
unsigned int pad2:16;
unsigned int addr;
} Asetloop;
typedef struct {
unsigned int w0;
unsigned int w1;
} Awords;
typedef union {
Awords words;
Aadpcm adpcm;
Apolef polef;
Aclearbuff clearbuff;
Aenvelope envelope;
Ainterleave interleave;
Aloadbuff loadbuff;
Aenvmixer envmixer;
Aresample resample;
Areverb reverb;
Asavebuff savebuff;
Asegment segment;
Asetbuff setbuff;
Asetvol setvol;
Admemmove dmemmove;
Aloadadpcm loadadpcm;
Amixer mixer;
Asetloop setloop;
long long int force_union_align;
} Acmd;
typedef short ADPCM_STATE[16 ];
typedef short POLEF_STATE[4];
typedef short RESAMPLE_STATE[16];
typedef short ENVMIX_STATE[40];
typedef struct {
size_t size;
Gfx* buf_p;
Gfx* head_p;
Gfx* tail_p;
} TwoHeadArenaGfx_t;
typedef TwoHeadArenaGfx_t TwoHeadArenaGfx;
typedef union {
TwoHeadArena tha;
TwoHeadArenaGfx thaGfx;
} THA_GA_t;
typedef THA_GA_t THA_GA;
extern void THA_GA_ct(THA_GA* tha_ga, Gfx* p, size_t n);
extern void THA_GA_dt(THA_GA* tha_ga);
extern int THA_GA_isCrash(THA_GA* tha_ga);
extern void THA_GA_init(THA_GA* tha_ga);
extern int THA_GA_getFreeBytes(THA_GA* tha_ga);
extern void* THA_GA_getTailPtr(THA_GA* tha_ga);
extern void* THA_GA_nextPtrN(THA_GA* tha_ga, size_t n);
extern void* THA_GA_nextPtr1(THA_GA* tha_ga);
extern Gfx* THA_GA_NEXT_DISP(THA_GA* tha_ga);
extern void* THA_GA_getHeadPtr(THA_GA* tha_ga);
extern void THA_GA_setHeadPtr(THA_GA* tha_ga, void *p);
extern Mtx* THA_GA_alloc(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtxN(THA_GA* tha_ga, size_t n);
extern Mtx* THA_GA_allocMtx1(THA_GA* tha_ga);
extern Vtx* THA_GA_allocVtxN(THA_GA* tha_ga, size_t n);
extern Vtx* THA_GA_allocVtx1(THA_GA* tha_ga);
typedef struct OSContext
{
u32 gpr[32];
u32 cr;
u32 lr;
u32 ctr;
u32 xer;
f64 fpr[32];
u32 fpscr_pad;
u32 fpscr;
u32 srr0;
u32 srr1;
u16 mode;
u16 state;
u32 gqr[8];
f64 psf[32];
} OSContext;
u32 OSGetStackPointer(void);
void OSDumpContext(OSContext *context);
void OSLoadContext(OSContext *context);
u32 OSSaveContext(OSContext *context);
void OSClearContext(OSContext *context);
OSContext *OSGetCurrentContext(void);
void OSSetCurrentContext(OSContext *context);
void OSLoadFPUContext(OSContext *fpuContext);
void OSSaveFPUContext(OSContext *fpuContext);
u32 OSSwitchStack(u32 newsp);
int OSSwitchFiber(u32 pc, u32 newsp);
void OSInitContext(OSContext *context, u32 pc, u32 newsp);
void OSFillFPUContext(OSContext *context);
typedef struct OSThread OSThread;
typedef struct OSThreadQueue OSThreadQueue;
typedef struct OSThreadLink OSThreadLink;
typedef s32 OSPriority;
typedef struct OSMutex OSMutex;
typedef struct OSMutexQueue OSMutexQueue;
typedef struct OSMutexLink OSMutexLink;
typedef struct OSCond OSCond;
typedef void (*OSIdleFunction)(void *param);
struct OSThreadQueue
{
OSThread *head;
OSThread *tail;
};
struct OSThreadLink
{
OSThread *next;
OSThread *prev;
};
struct OSMutexQueue
{
OSMutex *head;
OSMutex *tail;
};
struct OSMutexLink
{
OSMutex *next;
OSMutex *prev;
};
struct OSThread
{
OSContext context;
u16 state;
u16 attr;
s32 suspend;
OSPriority priority;
OSPriority base;
void *val;
OSThreadQueue *queue;
OSThreadLink link;
OSThreadQueue queueJoin;
OSMutex *mutex;
OSMutexQueue queueMutex;
OSThreadLink linkActive;
u8 *stackBase;
u32 *stackEnd;
};
enum OS_THREAD_STATE
{
OS_THREAD_STATE_READY = 1,
OS_THREAD_STATE_RUNNING = 2,
OS_THREAD_STATE_WAITING = 4,
OS_THREAD_STATE_MORIBUND = 8
};
void OSInitThreadQueue(OSThreadQueue *queue);
OSThread *OSGetCurrentThread(void);
BOOL OSIsThreadSuspended(OSThread *thread);
BOOL OSIsThreadTerminated(OSThread *thread);
s32 OSDisableScheduler(void);
s32 OSEnableScheduler(void);
void OSYieldThread(void);
BOOL OSCreateThread(OSThread *thread,
void *(*func)(void *),
void *param,
void *stack,
u32 stackSize,
OSPriority priority,
u16 attr);
void OSExitThread(void *val);
void OSCancelThread(OSThread *thread);
BOOL OSJoinThread(OSThread *thread, void **val);
void OSDetachThread(OSThread *thread);
s32 OSResumeThread(OSThread *thread);
s32 OSSuspendThread(OSThread *thread);
BOOL OSSetThreadPriority(OSThread *thread, OSPriority priority);
OSPriority OSGetThreadPriority(OSThread *thread);
void OSSleepThread(OSThreadQueue *queue);
void OSWakeupThread(OSThreadQueue *queue);
OSThread *OSSetIdleFunction(OSIdleFunction idleFunction,
void *param,
void *stack,
u32 stackSize);
OSThread *OSGetIdleFunction(void);
long OSCheckActiveThreads(void);
typedef struct OSMessageQueue OSMessageQueue;
typedef void* OSMessage;
struct OSMessageQueue {
OSThreadQueue queueSend;
OSThreadQueue queueReceive;
OSMessage* msgArray;
int msgCount;
int firstIndex;
int usedCount;
};
typedef enum {
OS_MSG_PERSISTENT = (1 << 0),
} OSMessageFlags;
void OSInitMessageQueue(OSMessageQueue* queue, OSMessage* msgArray, int msgCount);
BOOL OSSendMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSJamMessage(OSMessageQueue* queue, OSMessage msg, int flags);
BOOL OSReceiveMessage(OSMessageQueue* queue, OSMessage* msgPtr, int flags);
typedef struct OSModuleHeader OSModuleHeader;
typedef u32 OSModuleID;
typedef struct OSModuleQueue OSModuleQueue;
typedef struct OSModuleLink OSModuleLink;
typedef struct OSModuleInfo OSModuleInfo;
typedef struct OSSectionInfo OSSectionInfo;
typedef struct OSImportInfo OSImportInfo;
typedef struct OSRel OSRel;
struct OSModuleQueue {
OSModuleInfo* head;
OSModuleInfo* tail;
};
OSModuleQueue __OSModuleList : (0x800030C8) ;
void* __OSStringTable : (0x800030D0) ;
struct OSModuleLink {
OSModuleInfo* next;
OSModuleInfo* prev;
};
struct OSSectionInfo {
u32 offset;
u32 size;
};
struct OSModuleInfo {
OSModuleID id;
OSModuleLink link;
u32 numSections;
u32 sectionInfoOffset;
u32 nameOffset;
u32 nameSize;
u32 version;
};
struct OSModuleHeader {
OSModuleInfo info;
u32 bssSize;
u32 relOffset;
u32 impOffset;
u32 impSize;
u8 prologSection;
u8 epilogSection;
u8 unresolvedSection;
u8 bssSection;
u32 prolog;
u32 epilog;
u32 unresolved;
u32 align;
u32 bssAlign;
};
struct OSImportInfo {
OSModuleID id;
u32 offset;
};
struct OSRel {
u16 offset;
u8 type;
u8 section;
u32 addend;
};
BOOL OSLink(OSModuleInfo* newModule, void* bss);
BOOL OSLinkFixed(OSModuleInfo* newModule, void* bss);
BOOL OSUnlink(OSModuleInfo* module);
void OSSetStringTable(const void* string_table);
void __OSModuleInit(void);
typedef s64 OSTime;
typedef u32 OSTick;
OSTime OSGetTime(void);
OSTime __OSGetSystemTime(void);
OSTick OSGetTick(void);
typedef struct OSCalendarTime_s {
int sec;
int min;
int hour;
int mday;
int mon;
int year;
int wday;
int yday;
int msec;
int usec;
} OSCalendarTime;
OSTime OSCalendarTimeToTicks(OSCalendarTime* td);
void OSTicksToCalendarTime(OSTime ticks, OSCalendarTime* td);
typedef struct boot_tbl_s {
const char* msg;
u16 param_upper;
u16 param_lower;
} boot_tbl_t;
extern u32 convert_partial_address(u32 partial_addr);
extern void HotResetIplMenu();
extern void* boot_copyDate;
extern void* HotStartEntry;
extern OSTime InitialStartTime;
extern u8 boot_sound_initializing;
typedef void(*HotStartProc)();
OSModuleHeader* BaseModule : (0x800030C8) ;
typedef enum {
GRAPH_DOING_ZERO = 0,
GRAPH_DOING_CT,
GRAPH_DOING_GAME_CT,
GRAPH_DOING_GAME_CT_FINISHED,
GRAPH_DOING_GAME_MAIN,
GRAPH_DOING_GAME_TIME,
GRAPH_DOING_GAME_TIME_FINISHED,
GRAPH_DOING_GAME_EXEC,
GRAPH_DOING_GAME_EXEC_FINISHED,
GRAPH_DOING_GAME_BGM,
GRAPH_DOING_GAME_BGM_FINISHED,
GRAPH_DOING_GAME_MAIN_FINISHED,
GRAPH_DOING_TASK_SET,
GRAPH_DOING_WAIT_TASK,
GRAPH_DOING_WAIT_TASK_FINISHED,
GRAPH_DOING_TASK_SET_FINISHED,
GRAPH_DOING_AUDIO,
GRAPH_DOING_AUDIO_FINISHED,
GRAPH_DOING_GAME_18,
GRAPH_DOING_GAME_DT,
GRAPH_DOING_GAME_DT_FINISHED,
GRAPH_DOING_DT,
GRAPH_DOING_END
} GRAPH_DOING_POINT;
typedef struct graph_s {
Gfx* Gfx_list00;
Gfx* Gfx_list01;
void* DepthBuffer;
Gfx* Gfx_list03;
Gfx* Gfx_list04;
Gfx* Gfx_list07;
Gfx* Gfx_list08;
Gfx* Gfx_list09;
Gfx* gfxsave;
u8 _unk24[32];
OSMessage graphReplyMesgBuf[8 ];
OSMessageQueue* schedMesgQueue;
OSMessageQueue graphReplyMesgQueue;
u8 _unused_ossctask00p[0x68];
u8 _unused_ossctask01p[0x68];
u8 _unused_ossctask02p[0x68];
Gfx* Gfx_list05;
THA_GA work_thaga;
u8 _unk1D4[0xBC];
void* scheduler;
void* vimode;
THA_GA line_opaque_thaga;
THA_GA line_translucent_thaga;
THA_GA overlay_thaga;
THA_GA polygon_opaque_thaga;
THA_GA polygon_translucent_thaga;
THA_GA font_thaga;
THA_GA shadow_thaga;
THA_GA light_thaga;
THA_GA bg_opaque_thaga;
THA_GA bg_translucent_thaga;
int frame_counter;
u16* frameBuffer;
u16* renderBuffer;
u32 vispecial;
u8 doing_point;
u8 _unk349;
u8 need_viupdate;
u8 cfb_bank;
void (*taskEndCallback)(struct graph_s*, void*);
void* taskEndData;
f32 vixscale;
f32 viyscale;
Gfx* last_dl;
Gfx* Gfx_list10;
Gfx* Gfx_list11;
} GRAPH __attribute__((aligned(8))) ;
extern void graph_proc(void* arg);
extern void graph_ct(GRAPH* graph);
extern void graph_dt(GRAPH* graph);
extern u8 SoftResetEnable;
extern GRAPH graph_class;
typedef struct gameAllocList_s {
struct gameAllocList_s* next;
struct gameAllocList_s* prev;
size_t alloc_size;
u32 pad;
} GameAllocList;
typedef struct gameAlloc_s {
GameAllocList head;
GameAllocList* tail;
} GameAlloc;
extern void* gamealloc_malloc(GameAlloc* gamealloc, size_t size);
extern void gamealloc_free(GameAlloc* gamealloc, void* ptr);
extern void gamealloc_cleanup(GameAlloc* gamealloc);
extern void gamealloc_init(GameAlloc* gamealloc);
typedef struct {
u16 type;
u8 status;
u8 errno;
} OSContStatus;
typedef struct {
u16 button;
s8 stick_x;
s8 stick_y;
u8 errno;
} OSContPad;
typedef struct {
OSContPad pad;
s8 substickX;
s8 substickY;
u8 triggerR;
u8 triggerL;
} OSContPadEx;
extern s32 osContInit(OSMessageQueue* mq, u8* pattern_p, OSContStatus* status);
extern s32 osContStartQuery(OSMessageQueue* mq);
extern s32 osContStartReadData(OSMessageQueue* mq);
extern void osContGetQuery(OSContStatus* status);
extern s32 osContSetCh(u8 num_controllers);
extern void osContGetReadData(OSContPad* pad);
extern void osContGetReadDataEx(OSContPadEx* pad);
typedef struct {
OSContPad now;
OSContPad last;
OSContPad on;
OSContPad off;
} pad_t;
int pad_physical_stick_x(pad_t*);
int pad_physical_stick_y(pad_t*);
void pad_set_logical_stick(pad_t*, int, int);
void pad_correct_stick(pad_t*);
typedef struct controller_s {
f32 move_pX;
f32 move_pY;
f32 move_pR;
s16 move_angle;
f32 last_move_pX;
f32 last_move_pY;
f32 last_move_pR;
s16 last_move_angle;
f32 adjusted_pX;
f32 adjusted_pY;
f32 adjusted_pR;
f32 last_adjusted_pX;
f32 last_adjusted_pY;
f32 last_adjusted_pR;
} MCON;
extern void mCon_ct();
extern void mCon_dt();
extern void mCon_calc(MCON* mcon, f32 stick_x, f32 stick_y);
extern void mCon_main(GAME* game);
extern int chkButton(u16 button);
extern u16 getButton();
extern int chkTrigger(u16 button);
extern u16 getTrigger();
extern int getJoystick_X();
extern int getJoystick_Y();
struct game_s {
GRAPH* graph;
void (*exec)(struct game_s* );
void (*cleanup)(struct game_s*);
void (*next_game_init)(struct game_s*);
size_t next_game_class_size;
pad_t pads[4 ];
int pad_initialized;
THA tha;
GameAlloc gamealloc;
u8 doing_point;
u8 doing_point_specific;
u8 disable_display;
u8 doing;
u32 frame_counter;
int disable_prenmi;
MCON mcon;
};
extern void game_debug_draw_last(GAME* game, GRAPH* graph);
extern void game_draw_last(GRAPH* graph);
extern void game_get_controller(GAME* game);
extern void SetGameFrame(int frame);
extern void game_main(GAME* game);
extern void game_resize_hyral(GAME* game, int size);
extern void game_ct(GAME* game, void (*init)(GAME*), GRAPH* graph);
extern void game_dt(GAME* game);
extern void (*game_get_next_game_init(GAME* game))(GAME*);
extern int game_is_doing(GAME* game);
extern int game_getFreeBytes(GAME* game);
extern void game_goto_next_game_play(GAME* game);
extern GAME* gamePT;
extern GAME* game_class_p;
extern u8 game_GameFrame;
extern float game_GameFrameF;
extern float game_GameFrame_2F;
extern float game_GameFrame__1F;
typedef struct rgba_t {
u8 r, g, b, a;
} rgba_t;
typedef struct rgb_t {
uint r, g, b;
} rgb_t;
typedef struct rgb8_t {
u8 r, g, b;
} rgb8_t;
typedef struct {
xyz_t position;
s_xyz angle;
} PositionAngle;
extern void mem_copy(u8* dst, u8* src, size_t size);
extern void mem_clear(u8* dst, size_t size, u8 val);
extern int mem_cmp(u8* p1, u8* p2, size_t size);
extern f32 cos_s(s16 angle);
extern f32 sin_s(s16 angle);
extern int chase_angle(s16* const pValue, const s16 target, s16 step);
extern int chase_s(s16* const pValue, const s16 target, s16 step);
extern int chase_f(f32* const pValue, const f32 target, f32 step);
extern f32 chase_xyz_t(xyz_t* const pValue, const xyz_t* const target, const f32 fraction);
extern int chase_angle2(s16* const pValue, const s16 limit, const s16 step);
extern void inter_float(f32* const pValue, const f32 arg1, const int step);
extern s16 get_random_timer(const s16 base, const s16 range);
extern void xyz_t_move(xyz_t* const dest, const xyz_t* const src);
extern void xyz_t_move_s_xyz(xyz_t* const dest, const s_xyz* const src);
extern void xyz_t_add(const xyz_t* const augend, const xyz_t* const addend, xyz_t* const total);
extern void xyz_t_sub(const xyz_t* const minuend, const xyz_t* const subtrahend, xyz_t* const diff);
extern void xyz_t_mult_v(xyz_t* const multiplicand, const f32 multiplier);
extern f32 search_position_distance(const xyz_t* const pos, const xyz_t* const target);
extern f32 search_position_distanceXZ(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleY(const xyz_t* const pos, const xyz_t* const target);
extern s16 search_position_angleX(const xyz_t* const pos, const xyz_t* const target);
extern f32 add_calc(f32* pValue, f32 target, f32 fraction, f32 maxStep, f32 minStep);
extern void add_calc2(f32* pValue, f32 target, f32 fraction, f32 maxStep);
extern void add_calc0(f32* pValue, f32 fraction, f32 maxStep);
extern s16 add_calc_short_angle2(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern s16 add_calc_short_angle3(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep);
extern void rgba_t_move(rgba_t* dest, const rgba_t* const src);
extern int none_proc1();
extern void none_proc2(ACTOR* actor, GAME* game);
extern int _Game_play_isPause(GAME_PLAY* play);
extern f32 check_percent_abs(f32 x, f32 min, f32 max, f32 scale, int shift_by_min);
extern f32 get_percent_forAccelBrake(f32 now, f32 start, f32 end, f32 accelerateDist, f32 brakeDist);
extern void Game_play_Projection_Trans(GAME_PLAY* const play, xyz_t* world_pos, xyz_t* screen_pos);
extern f32 get_percent(const int max, const int min, const int x);
typedef u8 GXBool;
typedef enum _GXProjectionType {
GX_PERSPECTIVE,
GX_ORTHOGRAPHIC,
} GXProjectionType;
typedef enum _GXCompare {
GX_NEVER,
GX_LESS,
GX_EQUAL,
GX_LEQUAL,
GX_GREATER,
GX_NEQUAL,
GX_GEQUAL,
GX_ALWAYS,
} GXCompare;
typedef enum _GXAlphaOp {
GX_AOP_AND,
GX_AOP_OR,
GX_AOP_XOR,
GX_AOP_XNOR,
GX_MAX_ALPHAOP,
} GXAlphaOp;
typedef enum _GXFBClamp {
GX_CLAMP_NONE,
GX_CLAMP_TOP,
GX_CLAMP_BOTTOM,
} GXFBClamp;
typedef enum _GXZFmt16 {
GX_ZC_LINEAR,
GX_ZC_NEAR,
GX_ZC_MID,
GX_ZC_FAR,
} GXZFmt16;
typedef enum _GXGamma {
GX_GM_1_0,
GX_GM_1_7,
GX_GM_2_2,
} GXGamma;
typedef enum _GXPixelFmt {
GX_PF_RGB8_Z24,
GX_PF_RGBA6_Z24,
GX_PF_RGB565_Z16,
GX_PF_Z24,
GX_PF_Y8,
GX_PF_U8,
GX_PF_V8,
GX_PF_YUV420,
} GXPixelFmt;
typedef enum _GXPrimitive {
GX_QUADS = 0x80,
GX_TRIANGLES = 0x90,
GX_TRIANGLESTRIP = 0x98,
GX_TRIANGLEFAN = 0xA0,
GX_LINES = 0xA8,
GX_LINESTRIP = 0xB0,
GX_POINTS = 0xB8,
} GXPrimitive;
typedef enum _GXVtxFmt {
GX_VTXFMT0,
GX_VTXFMT1,
GX_VTXFMT2,
GX_VTXFMT3,
GX_VTXFMT4,
GX_VTXFMT5,
GX_VTXFMT6,
GX_VTXFMT7,
GX_MAX_VTXFMT,
} GXVtxFmt;
typedef enum _GXAttr {
GX_VA_PNMTXIDX,
GX_VA_TEX0MTXIDX,
GX_VA_TEX1MTXIDX,
GX_VA_TEX2MTXIDX,
GX_VA_TEX3MTXIDX,
GX_VA_TEX4MTXIDX,
GX_VA_TEX5MTXIDX,
GX_VA_TEX6MTXIDX,
GX_VA_TEX7MTXIDX,
GX_VA_POS,
GX_VA_NRM,
GX_VA_CLR0,
GX_VA_CLR1,
GX_VA_TEX0,
GX_VA_TEX1,
GX_VA_TEX2,
GX_VA_TEX3,
GX_VA_TEX4,
GX_VA_TEX5,
GX_VA_TEX6,
GX_VA_TEX7,
GX_POS_MTX_ARRAY,
GX_NRM_MTX_ARRAY,
GX_TEX_MTX_ARRAY,
GX_LIGHT_ARRAY,
GX_VA_NBT,
GX_VA_MAX_ATTR,
GX_VA_NULL = 0xFF,
} GXAttr;
typedef enum _GXAttrType {
GX_NONE,
GX_DIRECT,
GX_INDEX8,
GX_INDEX16,
} GXAttrType;
typedef enum _GXTexFmt {
GX_TF_I4 = 0x0,
GX_TF_I8 = 0x1,
GX_TF_IA4 = 0x2,
GX_TF_IA8 = 0x3,
GX_TF_RGB565 = 0x4,
GX_TF_RGB5A3 = 0x5,
GX_TF_RGBA8 = 0x6,
GX_TF_CMPR = 0xE,
GX_CTF_R4 = 0x0 | 0x20 ,
GX_CTF_RA4 = 0x2 | 0x20 ,
GX_CTF_RA8 = 0x3 | 0x20 ,
GX_CTF_YUVA8 = 0x6 | 0x20 ,
GX_CTF_A8 = 0x7 | 0x20 ,
GX_CTF_R8 = 0x8 | 0x20 ,
GX_CTF_G8 = 0x9 | 0x20 ,
GX_CTF_B8 = 0xA | 0x20 ,
GX_CTF_RG8 = 0xB | 0x20 ,
GX_CTF_GB8 = 0xC | 0x20 ,
GX_TF_Z8 = 0x1 | 0x10 ,
GX_TF_Z16 = 0x3 | 0x10 ,
GX_TF_Z24X8 = 0x6 | 0x10 ,
GX_CTF_Z4 = 0x0 | 0x10 | 0x20 ,
GX_CTF_Z8M = 0x9 | 0x10 | 0x20 ,
GX_CTF_Z8L = 0xA | 0x10 | 0x20 ,
GX_CTF_Z16L = 0xC | 0x10 | 0x20 ,
GX_TF_A8 = GX_CTF_A8,
} GXTexFmt;
typedef enum _GXCITexFmt {
GX_TF_C4 = 0x8,
GX_TF_C8 = 0x9,
GX_TF_C14X2 = 0xa,
} GXCITexFmt;
typedef enum _GXTexWrapMode {
GX_CLAMP,
GX_REPEAT,
GX_MIRROR,
GX_MAX_TEXWRAPMODE,
} GXTexWrapMode;
typedef enum _GXTexFilter {
GX_NEAR,
GX_LINEAR,
GX_NEAR_MIP_NEAR,
GX_LIN_MIP_NEAR,
GX_NEAR_MIP_LIN,
GX_LIN_MIP_LIN,
} GXTexFilter;
typedef enum _GXAnisotropy {
GX_ANISO_1,
GX_ANISO_2,
GX_ANISO_4,
GX_MAX_ANISOTROPY,
} GXAnisotropy;
typedef enum _GXTexMapID {
GX_TEXMAP0,
GX_TEXMAP1,
GX_TEXMAP2,
GX_TEXMAP3,
GX_TEXMAP4,
GX_TEXMAP5,
GX_TEXMAP6,
GX_TEXMAP7,
GX_MAX_TEXMAP,
GX_TEXMAP_NULL = 0xFF,
GX_TEX_DISABLE = 0x100,
} GXTexMapID;
typedef enum _GXTexCoordID {
GX_TEXCOORD0,
GX_TEXCOORD1,
GX_TEXCOORD2,
GX_TEXCOORD3,
GX_TEXCOORD4,
GX_TEXCOORD5,
GX_TEXCOORD6,
GX_TEXCOORD7,
GX_MAX_TEXCOORD,
GX_TEXCOORD_NULL = 0xFF,
} GXTexCoordID;
typedef enum _GXTevStageID {
GX_TEVSTAGE0,
GX_TEVSTAGE1,
GX_TEVSTAGE2,
GX_TEVSTAGE3,
GX_TEVSTAGE4,
GX_TEVSTAGE5,
GX_TEVSTAGE6,
GX_TEVSTAGE7,
GX_TEVSTAGE8,
GX_TEVSTAGE9,
GX_TEVSTAGE10,
GX_TEVSTAGE11,
GX_TEVSTAGE12,
GX_TEVSTAGE13,
GX_TEVSTAGE14,
GX_TEVSTAGE15,
GX_MAX_TEVSTAGE,
} GXTevStageID;
typedef enum _GXTevMode {
GX_MODULATE,
GX_DECAL,
GX_BLEND,
GX_REPLACE,
GX_PASSCLR,
} GXTevMode;
typedef enum _GXTexMtxType {
GX_MTX3x4,
GX_MTX2x4,
} GXTexMtxType;
typedef enum _GXTexGenType {
GX_TG_MTX3x4,
GX_TG_MTX2x4,
GX_TG_BUMP0,
GX_TG_BUMP1,
GX_TG_BUMP2,
GX_TG_BUMP3,
GX_TG_BUMP4,
GX_TG_BUMP5,
GX_TG_BUMP6,
GX_TG_BUMP7,
GX_TG_SRTG,
} GXTexGenType;
typedef enum _GXPosNrmMtx {
GX_PNMTX0 = 0,
GX_PNMTX1 = 3,
GX_PNMTX2 = 6,
GX_PNMTX3 = 9,
GX_PNMTX4 = 12,
GX_PNMTX5 = 15,
GX_PNMTX6 = 18,
GX_PNMTX7 = 21,
GX_PNMTX8 = 24,
GX_PNMTX9 = 27,
} GXPosNrmMtx;
typedef enum _GXTexMtx {
GX_TEXMTX0 = 30,
GX_TEXMTX1 = 33,
GX_TEXMTX2 = 36,
GX_TEXMTX3 = 39,
GX_TEXMTX4 = 42,
GX_TEXMTX5 = 45,
GX_TEXMTX6 = 48,
GX_TEXMTX7 = 51,
GX_TEXMTX8 = 54,
GX_TEXMTX9 = 57,
GX_IDENTITY = 60,
} GXTexMtx;
typedef enum _GXChannelID {
GX_COLOR0,
GX_COLOR1,
GX_ALPHA0,
GX_ALPHA1,
GX_COLOR0A0,
GX_COLOR1A1,
GX_COLOR_ZERO,
GX_ALPHA_BUMP,
GX_ALPHA_BUMPN,
GX_COLOR_NULL = 0xFF,
} GXChannelID;
typedef enum _GXTexGenSrc {
GX_TG_POS,
GX_TG_NRM,
GX_TG_BINRM,
GX_TG_TANGENT,
GX_TG_TEX0,
GX_TG_TEX1,
GX_TG_TEX2,
GX_TG_TEX3,
GX_TG_TEX4,
GX_TG_TEX5,
GX_TG_TEX6,
GX_TG_TEX7,
GX_TG_TEXCOORD0,
GX_TG_TEXCOORD1,
GX_TG_TEXCOORD2,
GX_TG_TEXCOORD3,
GX_TG_TEXCOORD4,
GX_TG_TEXCOORD5,
GX_TG_TEXCOORD6,
GX_TG_COLOR0,
GX_TG_COLOR1,
GX_MAX_TEXGENSRC,
} GXTexGenSrc;
typedef enum _GXBlendMode {
GX_BM_NONE,
GX_BM_BLEND,
GX_BM_LOGIC,
GX_BM_SUBTRACT,
GX_MAX_BLENDMODE,
} GXBlendMode;
typedef enum _GXBlendFactor {
GX_BL_ZERO,
GX_BL_ONE,
GX_BL_SRCCLR,
GX_BL_INVSRCCLR,
GX_BL_SRCALPHA,
GX_BL_INVSRCALPHA,
GX_BL_DSTALPHA,
GX_BL_INVDSTALPHA,
GX_BL_DSTCLR = GX_BL_SRCCLR,
GX_BL_INVDSTCLR = GX_BL_INVSRCCLR,
} GXBlendFactor;
typedef enum _GXLogicOp {
GX_LO_CLEAR,
GX_LO_AND,
GX_LO_REVAND,
GX_LO_COPY,
GX_LO_INVAND,
GX_LO_NOOP,
GX_LO_XOR,
GX_LO_OR,
GX_LO_NOR,
GX_LO_EQUIV,
GX_LO_INV,
GX_LO_REVOR,
GX_LO_INVCOPY,
GX_LO_INVOR,
GX_LO_NAND,
GX_LO_SET,
} GXLogicOp;
typedef enum _GXCompCnt {
GX_POS_XY = 0,
GX_POS_XYZ = 1,
GX_NRM_XYZ = 0,
GX_NRM_NBT = 1,
GX_NRM_NBT3 = 2,
GX_CLR_RGB = 0,
GX_CLR_RGBA = 1,
GX_TEX_S = 0,
GX_TEX_ST = 1,
} GXCompCnt;
typedef enum _GXCompType {
GX_U8 = 0,
GX_S8 = 1,
GX_U16 = 2,
GX_S16 = 3,
GX_F32 = 4,
GX_RGB565 = 0,
GX_RGB8 = 1,
GX_RGBX8 = 2,
GX_RGBA4 = 3,
GX_RGBA6 = 4,
GX_RGBA8 = 5,
} GXCompType;
typedef enum _GXPTTexMtx {
GX_PTTEXMTX0 = 64,
GX_PTTEXMTX1 = 67,
GX_PTTEXMTX2 = 70,
GX_PTTEXMTX3 = 73,
GX_PTTEXMTX4 = 76,
GX_PTTEXMTX5 = 79,
GX_PTTEXMTX6 = 82,
GX_PTTEXMTX7 = 85,
GX_PTTEXMTX8 = 88,
GX_PTTEXMTX9 = 91,
GX_PTTEXMTX10 = 94,
GX_PTTEXMTX11 = 97,
GX_PTTEXMTX12 = 100,
GX_PTTEXMTX13 = 103,
GX_PTTEXMTX14 = 106,
GX_PTTEXMTX15 = 109,
GX_PTTEXMTX16 = 112,
GX_PTTEXMTX17 = 115,
GX_PTTEXMTX18 = 118,
GX_PTTEXMTX19 = 121,
GX_PTIDENTITY = 125,
} GXPTTexMtx;
typedef enum _GXTevRegID {
GX_TEVPREV,
GX_TEVREG0,
GX_TEVREG1,
GX_TEVREG2,
GX_MAX_TEVREG,
} GXTevRegID;
typedef enum _GXDiffuseFn {
GX_DF_NONE,
GX_DF_SIGN,
GX_DF_CLAMP,
} GXDiffuseFn;
typedef enum _GXColorSrc {
GX_SRC_REG,
GX_SRC_VTX,
} GXColorSrc;
typedef enum _GXAttnFn {
GX_AF_SPEC,
GX_AF_SPOT,
GX_AF_NONE,
} GXAttnFn;
typedef enum _GXLightID {
GX_LIGHT0 = 0x001,
GX_LIGHT1 = 0x002,
GX_LIGHT2 = 0x004,
GX_LIGHT3 = 0x008,
GX_LIGHT4 = 0x010,
GX_LIGHT5 = 0x020,
GX_LIGHT6 = 0x040,
GX_LIGHT7 = 0x080,
GX_MAX_LIGHT = 0x100,
GX_LIGHT_NULL = 0,
} GXLightID;
typedef enum _GXTexOffset {
GX_TO_ZERO,
GX_TO_SIXTEENTH,
GX_TO_EIGHTH,
GX_TO_FOURTH,
GX_TO_HALF,
GX_TO_ONE,
GX_MAX_TEXOFFSET,
} GXTexOffset;
typedef enum _GXSpotFn {
GX_SP_OFF,
GX_SP_FLAT,
GX_SP_COS,
GX_SP_COS2,
GX_SP_SHARP,
GX_SP_RING1,
GX_SP_RING2,
} GXSpotFn;
typedef enum _GXDistAttnFn {
GX_DA_OFF,
GX_DA_GENTLE,
GX_DA_MEDIUM,
GX_DA_STEEP,
} GXDistAttnFn;
typedef enum _GXCullMode {
GX_CULL_NONE,
GX_CULL_FRONT,
GX_CULL_BACK,
GX_CULL_ALL,
} GXCullMode;
typedef enum _GXTevSwapSel {
GX_TEV_SWAP0 = 0,
GX_TEV_SWAP1,
GX_TEV_SWAP2,
GX_TEV_SWAP3,
GX_MAX_TEVSWAP,
} GXTevSwapSel;
typedef enum _GXTevColorChan {
GX_CH_RED = 0,
GX_CH_GREEN,
GX_CH_BLUE,
GX_CH_ALPHA,
} GXTevColorChan;
typedef enum _GXFogType {
GX_FOG_NONE = 0,
GX_FOG_PERSP_LIN = 2,
GX_FOG_PERSP_EXP = 4,
GX_FOG_PERSP_EXP2 = 5,
GX_FOG_PERSP_REVEXP = 6,
GX_FOG_PERSP_REVEXP2 = 7,
GX_FOG_ORTHO_LIN = 10,
GX_FOG_ORTHO_EXP = 12,
GX_FOG_ORTHO_EXP2 = 13,
GX_FOG_ORTHO_REVEXP = 14,
GX_FOG_ORTHO_REVEXP2 = 15,
GX_FOG_LIN = GX_FOG_PERSP_LIN,
GX_FOG_EXP = GX_FOG_PERSP_EXP,
GX_FOG_EXP2 = GX_FOG_PERSP_EXP2,
GX_FOG_REVEXP = GX_FOG_PERSP_REVEXP,
GX_FOG_REVEXP2 = GX_FOG_PERSP_REVEXP2,
} GXFogType;
typedef enum _GXTevColorArg {
GX_CC_CPREV,
GX_CC_APREV,
GX_CC_C0,
GX_CC_A0,
GX_CC_C1,
GX_CC_A1,
GX_CC_C2,
GX_CC_A2,
GX_CC_TEXC,
GX_CC_TEXA,
GX_CC_RASC,
GX_CC_RASA,
GX_CC_ONE,
GX_CC_HALF,
GX_CC_KONST,
GX_CC_ZERO,
} GXTevColorArg;
typedef enum _GXTevAlphaArg {
GX_CA_APREV,
GX_CA_A0,
GX_CA_A1,
GX_CA_A2,
GX_CA_TEXA,
GX_CA_RASA,
GX_CA_KONST,
GX_CA_ZERO,
} GXTevAlphaArg;
typedef enum _GXTevOp {
GX_TEV_ADD = 0,
GX_TEV_SUB = 1,
GX_TEV_COMP_R8_GT = 8,
GX_TEV_COMP_R8_EQ = 9,
GX_TEV_COMP_GR16_GT = 10,
GX_TEV_COMP_GR16_EQ = 11,
GX_TEV_COMP_BGR24_GT = 12,
GX_TEV_COMP_BGR24_EQ = 13,
GX_TEV_COMP_RGB8_GT = 14,
GX_TEV_COMP_RGB8_EQ = 15,
GX_TEV_COMP_A8_GT = GX_TEV_COMP_RGB8_GT,
GX_TEV_COMP_A8_EQ = GX_TEV_COMP_RGB8_EQ,
} GXTevOp;
typedef enum _GXTevBias {
GX_TB_ZERO,
GX_TB_ADDHALF,
GX_TB_SUBHALF,
GX_MAX_TEVBIAS,
} GXTevBias;
typedef enum _GXTevScale {
GX_CS_SCALE_1,
GX_CS_SCALE_2,
GX_CS_SCALE_4,
GX_CS_DIVIDE_2,
GX_MAX_TEVSCALE,
} GXTevScale;
typedef enum _GXTevKColorSel {
GX_TEV_KCSEL_8_8 = 0x00,
GX_TEV_KCSEL_7_8 = 0x01,
GX_TEV_KCSEL_6_8 = 0x02,
GX_TEV_KCSEL_5_8 = 0x03,
GX_TEV_KCSEL_4_8 = 0x04,
GX_TEV_KCSEL_3_8 = 0x05,
GX_TEV_KCSEL_2_8 = 0x06,
GX_TEV_KCSEL_1_8 = 0x07,
GX_TEV_KCSEL_1 = GX_TEV_KCSEL_8_8,
GX_TEV_KCSEL_3_4 = GX_TEV_KCSEL_6_8,
GX_TEV_KCSEL_1_2 = GX_TEV_KCSEL_4_8,
GX_TEV_KCSEL_1_4 = GX_TEV_KCSEL_2_8,
GX_TEV_KCSEL_K0 = 0x0C,
GX_TEV_KCSEL_K1 = 0x0D,
GX_TEV_KCSEL_K2 = 0x0E,
GX_TEV_KCSEL_K3 = 0x0F,
GX_TEV_KCSEL_K0_R = 0x10,
GX_TEV_KCSEL_K1_R = 0x11,
GX_TEV_KCSEL_K2_R = 0x12,
GX_TEV_KCSEL_K3_R = 0x13,
GX_TEV_KCSEL_K0_G = 0x14,
GX_TEV_KCSEL_K1_G = 0x15,
GX_TEV_KCSEL_K2_G = 0x16,
GX_TEV_KCSEL_K3_G = 0x17,
GX_TEV_KCSEL_K0_B = 0x18,
GX_TEV_KCSEL_K1_B = 0x19,
GX_TEV_KCSEL_K2_B = 0x1A,
GX_TEV_KCSEL_K3_B = 0x1B,
GX_TEV_KCSEL_K0_A = 0x1C,
GX_TEV_KCSEL_K1_A = 0x1D,
GX_TEV_KCSEL_K2_A = 0x1E,
GX_TEV_KCSEL_K3_A = 0x1F,
} GXTevKColorSel;
typedef enum _GXTevKAlphaSel {
GX_TEV_KASEL_8_8 = 0x00,
GX_TEV_KASEL_7_8 = 0x01,
GX_TEV_KASEL_6_8 = 0x02,
GX_TEV_KASEL_5_8 = 0x03,
GX_TEV_KASEL_4_8 = 0x04,
GX_TEV_KASEL_3_8 = 0x05,
GX_TEV_KASEL_2_8 = 0x06,
GX_TEV_KASEL_1_8 = 0x07,
GX_TEV_KASEL_1 = GX_TEV_KASEL_8_8,
GX_TEV_KASEL_3_4 = GX_TEV_KASEL_6_8,
GX_TEV_KASEL_1_2 = GX_TEV_KASEL_4_8,
GX_TEV_KASEL_1_4 = GX_TEV_KASEL_2_8,
GX_TEV_KASEL_K0_R = 0x10,
GX_TEV_KASEL_K1_R = 0x11,
GX_TEV_KASEL_K2_R = 0x12,
GX_TEV_KASEL_K3_R = 0x13,
GX_TEV_KASEL_K0_G = 0x14,
GX_TEV_KASEL_K1_G = 0x15,
GX_TEV_KASEL_K2_G = 0x16,
GX_TEV_KASEL_K3_G = 0x17,
GX_TEV_KASEL_K0_B = 0x18,
GX_TEV_KASEL_K1_B = 0x19,
GX_TEV_KASEL_K2_B = 0x1A,
GX_TEV_KASEL_K3_B = 0x1B,
GX_TEV_KASEL_K0_A = 0x1C,
GX_TEV_KASEL_K1_A = 0x1D,
GX_TEV_KASEL_K2_A = 0x1E,
GX_TEV_KASEL_K3_A = 0x1F,
} GXTevKAlphaSel;
typedef enum _GXTevKColorID {
GX_KCOLOR0 = 0,
GX_KCOLOR1,
GX_KCOLOR2,
GX_KCOLOR3,
GX_MAX_KCOLOR,
} GXTevKColorID;
typedef enum _GXZTexOp {
GX_ZT_DISABLE,
GX_ZT_ADD,
GX_ZT_REPLACE,
GX_MAX_ZTEXOP,
} GXZTexOp;
typedef enum _GXIndTexFormat {
GX_ITF_8,
GX_ITF_5,
GX_ITF_4,
GX_ITF_3,
GX_MAX_ITFORMAT,
} GXIndTexFormat;
typedef enum _GXIndTexBiasSel {
GX_ITB_NONE,
GX_ITB_S,
GX_ITB_T,
GX_ITB_ST,
GX_ITB_U,
GX_ITB_SU,
GX_ITB_TU,
GX_ITB_STU,
GX_MAX_ITBIAS,
} GXIndTexBiasSel;
typedef enum _GXIndTexAlphaSel {
GX_ITBA_OFF,
GX_ITBA_S,
GX_ITBA_T,
GX_ITBA_U,
GX_MAX_ITBALPHA,
} GXIndTexAlphaSel;
typedef enum _GXIndTexMtxID {
GX_ITM_OFF,
GX_ITM_0,
GX_ITM_1,
GX_ITM_2,
GX_ITM_S0 = 5,
GX_ITM_S1,
GX_ITM_S2,
GX_ITM_T0 = 9,
GX_ITM_T1,
GX_ITM_T2,
} GXIndTexMtxID;
typedef enum _GXIndTexWrap {
GX_ITW_OFF,
GX_ITW_256,
GX_ITW_128,
GX_ITW_64,
GX_ITW_32,
GX_ITW_16,
GX_ITW_0,
GX_MAX_ITWRAP,
} GXIndTexWrap;
typedef enum _GXIndTexStageID {
GX_INDTEXSTAGE0,
GX_INDTEXSTAGE1,
GX_INDTEXSTAGE2,
GX_INDTEXSTAGE3,
GX_MAX_INDTEXSTAGE,
} GXIndTexStageID;
typedef enum _GXIndTexScale {
GX_ITS_1,
GX_ITS_2,
GX_ITS_4,
GX_ITS_8,
GX_ITS_16,
GX_ITS_32,
GX_ITS_64,
GX_ITS_128,
GX_ITS_256,
GX_MAX_ITSCALE,
} GXIndTexScale;
typedef enum _GXClipMode {
GX_CLIP_ENABLE = 0,
GX_CLIP_DISABLE = 1,
} GXClipMode;
typedef enum _GXTlut {
GX_TLUT0 = 0,
GX_TLUT1 = 1,
GX_TLUT2 = 2,
GX_TLUT3 = 3,
GX_TLUT4 = 4,
GX_TLUT5 = 5,
GX_TLUT6 = 6,
GX_TLUT7 = 7,
GX_TLUT8 = 8,
GX_TLUT9 = 9,
GX_TLUT10 = 10,
GX_TLUT11 = 11,
GX_TLUT12 = 12,
GX_TLUT13 = 13,
GX_TLUT14 = 14,
GX_TLUT15 = 15,
GX_BIGTLUT0 = 16,
GX_BIGTLUT1 = 17,
GX_BIGTLUT2 = 18,
GX_BIGTLUT3 = 19,
} GXTlut;
typedef enum _GXTlutFmt {
GX_TL_IA8,
GX_TL_RGB565,
GX_TL_RGB5A3,
GX_MAX_TLUTFMT,
} GXTlutFmt;
typedef enum _GXMiscToken {
GX_MT_NULL = 0,
GX_MT_XF_FLUSH = 1,
GX_MT_DL_SAVE_CONTEXT = 2,
GX_MT_ABORT_WAIT_COPYOUT = 3,
} GXMiscToken;
typedef enum _GXTexCacheSize {
GX_TEXCACHE_32K,
GX_TEXCACHE_128K,
GX_TEXCACHE_512K,
GX_TEXCACHE_NONE
} GXTexCacheSize;
typedef enum _GXPerf0 {
GX_PERF0_VERTICES,
GX_PERF0_CLIP_VTX,
GX_PERF0_CLIP_CLKS,
GX_PERF0_XF_WAIT_IN,
GX_PERF0_XF_WAIT_OUT,
GX_PERF0_XF_XFRM_CLKS,
GX_PERF0_XF_LIT_CLKS,
GX_PERF0_XF_BOT_CLKS,
GX_PERF0_XF_REGLD_CLKS,
GX_PERF0_XF_REGRD_CLKS,
GX_PERF0_CLIP_RATIO,
GX_PERF0_TRIANGLES,
GX_PERF0_TRIANGLES_CULLED,
GX_PERF0_TRIANGLES_PASSED,
GX_PERF0_TRIANGLES_SCISSORED,
GX_PERF0_TRIANGLES_0TEX,
GX_PERF0_TRIANGLES_1TEX,
GX_PERF0_TRIANGLES_2TEX,
GX_PERF0_TRIANGLES_3TEX,
GX_PERF0_TRIANGLES_4TEX,
GX_PERF0_TRIANGLES_5TEX,
GX_PERF0_TRIANGLES_6TEX,
GX_PERF0_TRIANGLES_7TEX,
GX_PERF0_TRIANGLES_8TEX,
GX_PERF0_TRIANGLES_0CLR,
GX_PERF0_TRIANGLES_1CLR,
GX_PERF0_TRIANGLES_2CLR,
GX_PERF0_QUAD_0CVG,
GX_PERF0_QUAD_NON0CVG,
GX_PERF0_QUAD_1CVG,
GX_PERF0_QUAD_2CVG,
GX_PERF0_QUAD_3CVG,
GX_PERF0_QUAD_4CVG,
GX_PERF0_AVG_QUAD_CNT,
GX_PERF0_CLOCKS,
GX_PERF0_NONE
} GXPerf0;
typedef enum _GXPerf1 {
GX_PERF1_TEXELS,
GX_PERF1_TX_IDLE,
GX_PERF1_TX_REGS,
GX_PERF1_TX_MEMSTALL,
GX_PERF1_TC_CHECK1_2,
GX_PERF1_TC_CHECK3_4,
GX_PERF1_TC_CHECK5_6,
GX_PERF1_TC_CHECK7_8,
GX_PERF1_TC_MISS,
GX_PERF1_VC_ELEMQ_FULL,
GX_PERF1_VC_MISSQ_FULL,
GX_PERF1_VC_MEMREQ_FULL,
GX_PERF1_VC_STATUS7,
GX_PERF1_VC_MISSREP_FULL,
GX_PERF1_VC_STREAMBUF_LOW,
GX_PERF1_VC_ALL_STALLS,
GX_PERF1_VERTICES,
GX_PERF1_FIFO_REQ,
GX_PERF1_CALL_REQ,
GX_PERF1_VC_MISS_REQ,
GX_PERF1_CP_ALL_REQ,
GX_PERF1_CLOCKS,
GX_PERF1_NONE
} GXPerf1;
typedef enum _GXVCachePerf {
GX_VC_POS,
GX_VC_NRM,
GX_VC_CLR0,
GX_VC_CLR1,
GX_VC_TEX0,
GX_VC_TEX1,
GX_VC_TEX2,
GX_VC_TEX3,
GX_VC_TEX4,
GX_VC_TEX5,
GX_VC_TEX6,
GX_VC_TEX7,
GX_VC_ALL = 0xf
} GXVCachePerf;
typedef enum _GXAlphaReadMode
{
GX_READ_00,
GX_READ_FF,
GX_READ_NONE,
} GXAlphaReadMode;
typedef enum _GXCopyMode
{
GX_COPY_PROGRESSIVE = 0,
GX_COPY_INTLC_EVEN = 2,
GX_COPY_INTLC_ODD = 3,
} GXCopyMode;
typedef enum _GXTlutSize
{
GX_TLUT_16 = 1,
GX_TLUT_32 = 2,
GX_TLUT_64 = 4,
GX_TLUT_128 = 8,
GX_TLUT_256 = 16,
GX_TLUT_512 = 32,
GX_TLUT_1K = 64,
GX_TLUT_2K = 128,
GX_TLUT_4K = 256,
GX_TLUT_8K = 512,
GX_TLUT_16K = 1024,
} GXTlutSize;
typedef enum
{
VI_TVMODE_NTSC_INT = (((0) << 2) + (0)) ,
VI_TVMODE_NTSC_DS = (((0) << 2) + (1)) ,
VI_TVMODE_NTSC_PROG = (((0) << 2) + (2)) ,
VI_TVMODE_3 = 3,
VI_TVMODE_PAL_INT = (((1) << 2) + (0)) ,
VI_TVMODE_PAL_DS = (((1) << 2) + (1)) ,
VI_TVMODE_EURGB60_INT = (((5) << 2) + (0)) ,
VI_TVMODE_EURGB60_DS = (((5) << 2) + (1)) ,
VI_TVMODE_MPAL_INT = (((2) << 2) + (0)) ,
VI_TVMODE_MPAL_DS = (((2) << 2) + (1)) ,
VI_TVMODE_DEBUG_INT = (((3) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_INT = (((4) << 2) + (0)) ,
VI_TVMODE_DEBUG_PAL_DS = (((4) << 2) + (1))
} VITVMode;
typedef enum
{
VI_XFBMODE_SF = 0,
VI_XFBMODE_DF
} VIXFBMode;
typedef void (*VIRetraceCallback)(u32 retraceCount);
void VIConfigure(const struct _GXRenderModeObj *rm);
void VISetBlack(BOOL);
void VIWaitForRetrace();
void VIConfigurePan(u16 x_origin, u16 y_origin, u16 width, u16 height);
u32 VIGetRetraceCount();
u32 VIGetDTVStatus();
VIRetraceCallback VISetPreRetraceCallback(VIRetraceCallback callback);
VIRetraceCallback VISetPostRetraceCallback(VIRetraceCallback callback);
void* VIGetNextFrameBuffer();
void* VIGetCurrentFrameBuffer();
void VISetNextFrameBuffer(void* fb);
void VIInit();
void VIFlush();
typedef struct _GXRenderModeObj {
VITVMode viTVmode;
u16 fbWidth;
u16 efbHeight;
u16 xfbHeight;
u16 viXOrigin;
u16 viYOrigin;
u16 viWidth;
u16 viHeight;
VIXFBMode xFBmode;
u8 field_rendering;
u8 aa;
u8 sample_pattern[12][2];
u8 vfilter[7];
} GXRenderModeObj;
typedef struct _GXColor {
u8 r;
u8 g;
u8 b;
u8 a;
} GXColor;
typedef struct _GXTexObj {
u32 dummy[8];
} GXTexObj;
typedef struct _GXTlutObj {
u32 dummy[3];
} GXTlutObj;
typedef struct _GXLightObj {
u32 dummy[16];
} GXLightObj;
typedef struct _GXColorS10 {
s16 r;
s16 g;
s16 b;
s16 a;
} GXColorS10;
typedef struct _GXTexRegion {
u32 dummy[4];
} GXTexRegion;
typedef struct _GXTlutRegion {
u32 dummy[4];
} GXTlutRegion;
typedef struct _GXFogAdjTable
{
u16 r[10];
} GXFogAdjTable;
typedef struct _GXVtxDescList {
GXAttr attr;
GXAttrType type;
} GXVtxDescList;
typedef struct _GXVtxAttrFmtList {
GXAttr attr;
GXCompCnt cnt;
GXCompType type;
u8 frac;
} GXVtxAttrFmtList;
extern u16 *__memReg;
extern u16 *__peReg;
extern u16 *__cpReg;
extern u32 *__piReg;
inline u32 __GXReadCPCounterU32(u32 regAddrL, u32 regAddrH)
{
u32 ctrH0;
u32 ctrH1;
u32 ctrL;
ctrH0 = (*(volatile u16*)((__cpReg) + (regAddrH))) ;
while (1 ) {
ctrH1 = ctrH0;
ctrL = (*(volatile u16*)((__cpReg) + (regAddrL))) ;
ctrH0 = (*(volatile u16*)((__cpReg) + (regAddrH))) ;
if (ctrH0 == ctrH1) {
break;
}
}
return (ctrH0 << 16) | (ctrL);
}
void GXSetTevDirect(GXTevStageID tev_stage);
void GXSetNumIndStages(u8 nIndStages);
void GXSetIndTexMtx(GXIndTexMtxID mtx_sel, f32 offset[2][3], s8 scale_exp);
void GXSetIndTexOrder(GXIndTexStageID ind_stage, GXTexCoordID tex_coord, GXTexMapID tex_map);
void GXSetTevIndirect(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXIndTexFormat format,
GXIndTexBiasSel bias_sel, GXIndTexMtxID matrix_sel, GXIndTexWrap wrap_s,
GXIndTexWrap wrap_t, GXBool add_prev, GXBool ind_lod,
GXIndTexAlphaSel alpha_sel);
void GXSetTevIndWarp(GXTevStageID tev_stage, GXIndTexStageID ind_stage, GXBool signed_offsets,
GXBool replace_mode, GXIndTexMtxID matrix_sel);
void GXSetIndTexCoordScale(GXIndTexStageID ind_state, GXIndTexScale scale_s, GXIndTexScale scale_t);
extern void __GXSetIndirectMask(u32 mask);
void GXSetScissor(u32 left, u32 top, u32 wd, u32 ht);
void GXSetCullMode(GXCullMode mode);
void GXSetCoPlanar(GXBool enable);
void GXBeginDisplayList(void* list, u32 size);
u32 GXEndDisplayList(void);
void GXCallDisplayList(void* list, u32 nbytes);
void GXDrawSphere(u8 numMajor, u8 numMinor);
typedef struct
{
u8 pad[128];
} GXFifoObj;
typedef void (*GXBreakPtCallback)(void);
void GXInitFifoBase(GXFifoObj *fifo, void *base, u32 size);
void GXInitFifoPtrs(GXFifoObj *fifo, void *readPtr, void *writePtr);
void GXInitFifoLimits(GXFifoObj *fifo, u32 hiWatermark, u32 loWatermark);
void GXSetCPUFifo(GXFifoObj *fifo);
void GXSetGPFifo(GXFifoObj *fifo);
void GXSaveCPUFifo(GXFifoObj *fifo);
void GXSaveGPFifo(GXFifoObj *fifo);
void GXGetGPStatus(GXBool *overhi, GXBool *underlow, GXBool *readIdle, GXBool *cmdIdle, GXBool *brkpt);
void GXGetFifoStatus(GXFifoObj *fifo, GXBool *overhi, GXBool *underflow, u32 *fifoCount, GXBool *cpuWrite, GXBool *gpRead, GXBool *fifowrap);
void GXGetFifoPtrs(GXFifoObj *fifo, void **readPtr, void **writePtr);
void *GXGetFifoBase(GXFifoObj *fifo);
u32 GXGetFifoSize(GXFifoObj *fifo);
void GXGetFifoLimits(GXFifoObj *fifo, u32 *hi, u32 *lo);
GXBreakPtCallback GXSetBreakPtCallback(GXBreakPtCallback cb);
void GXEnableBreakPt(void *break_pt);
void GXDisableBreakPt(void);
OSThread *GXSetCurrentGXThread(void);
OSThread *GXGetCurrentGXThread(void);
GXFifoObj *GXGetCPUFifo(void);
GXFifoObj *GXGetGPFifo(void);
u32 GXGetOverflowCount(void);
u32 GXResetOverflowCount(void);
volatile void *GXRedirectWriteGatherPipe(void *ptr);
void GXRestoreWriteGatherPipe(void);
extern GXRenderModeObj GXNtsc480IntDf;
extern GXRenderModeObj GXNtsc480Int;
extern GXRenderModeObj GXMpal480IntDf;
extern GXRenderModeObj GXPal528IntDf;
extern GXRenderModeObj GXEurgb60Hz480IntDf;
void GXSetCopyClear(GXColor clear_clr, u32 clear_z);
void GXAdjustForOverscan(GXRenderModeObj* rmin, GXRenderModeObj* rmout, u16 hor, u16 ver);
void GXCopyDisp(void* dest, GXBool clear);
void GXSetDispCopyGamma(GXGamma gamma);
void GXSetDispCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetDispCopyDst(u16 wd, u16 ht);
f32 GXGetYScaleFactor(u16 efbHeight, u16 xfbHeight);
u32 GXSetDispCopyYScale(f32 vscale);
u16 GXGetNumXfbLines(u16 efbHeight, f32 yScale);
void GXSetCopyFilter(GXBool aa, const u8 sample_pattern[12][2], GXBool vf, const u8 vfilter[7]);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetTexCopySrc(u16 left, u16 top, u16 wd, u16 ht);
void GXSetTexCopyDst(u16 wd, u16 ht, GXTexFmt fmt, GXBool mipmap);
void GXCopyTex(void* dest, GXBool clear);
void GXSetCopyClamp(GXFBClamp clamp);
void GXSetVtxDesc(GXAttr attr, GXAttrType type);
void GXSetVtxDescv(const GXVtxDescList* list);
void GXClearVtxDesc(void);
void GXSetVtxAttrFmt(GXVtxFmt vtxfmt, GXAttr attr, GXCompCnt cnt, GXCompType type, u8 frac);
void GXSetNumTexGens(u8 nTexGens);
void GXBegin(GXPrimitive type, GXVtxFmt vtxfmt, u16 nverts);
void GXSetTexCoordGen2(GXTexCoordID dst_coord, GXTexGenType func, GXTexGenSrc src_param, u32 mtx,
GXBool normalize, u32 postmtx);
void GXSetLineWidth(u8 width, GXTexOffset texOffsets);
void GXSetPointSize(u8 pointSize, GXTexOffset texOffsets);
void GXEnableTexOffsets(GXTexCoordID coord, GXBool line_enable, GXBool point_enable);
void GXSetArray(GXAttr attr, const void* data, u8 stride);
void GXInvalidateVtxCache(void);
static inline void GXSetTexCoordGen(GXTexCoordID dst_coord, GXTexGenType func,
GXTexGenSrc src_param, u32 mtx) {
GXSetTexCoordGen2(dst_coord, func, src_param, mtx, ((GXBool)0) , GX_PTIDENTITY);
}
GXBool GXGetTexObjMipMap(const GXTexObj* obj);
GXTexFmt GXGetTexObjFmt(const GXTexObj* obj);
u16 GXGetTexObjHeight(const GXTexObj* obj);
u16 GXGetTexObjWidth(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapS(const GXTexObj* obj);
GXTexWrapMode GXGetTexObjWrapT(const GXTexObj* obj);
void* GXGetTexObjData(const GXTexObj* obj);
void GXGetProjectionv(f32* p);
void GXGetLightPos(GXLightObj* lt_obj, f32* x, f32* y, f32* z);
void GXGetLightColor(GXLightObj* lt_obj, GXColor* color);
void GXGetVtxAttrFmt(GXVtxFmt idx, GXAttr attr, GXCompCnt* compCnt, GXCompType* compType,
u8* shift);
void GXSetNumChans(u8 nChans);
void GXSetChanCtrl(GXChannelID chan, GXBool enable, GXColorSrc amb_src, GXColorSrc mat_src,
u32 light_mask, GXDiffuseFn diff_fn, GXAttnFn attn_fn);
void GXSetChanAmbColor(GXChannelID chan, GXColor amb_color);
void GXSetChanMatColor(GXChannelID chan, GXColor mat_color);
void GXInitLightSpot(GXLightObj* lt_obj, f32 cutoff, GXSpotFn spot_func);
void GXInitLightDistAttn(GXLightObj* lt_obj, f32 ref_distance, f32 ref_brightness,
GXDistAttnFn dist_func);
void GXInitLightPos(GXLightObj* lt_obj, f32 x, f32 y, f32 z);
void GXInitLightDir(GXLightObj* lt_obj, f32 nx, f32 ny, f32 nz);
void GXInitLightColor(GXLightObj* lt_obj, GXColor color);
void GXInitLightAttn(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2, f32 k0, f32 k1, f32 k2);
void GXInitLightAttnA(GXLightObj* lt_obj, f32 a0, f32 a1, f32 a2);
void GXInitLightAttnK(GXLightObj* lt_obj, f32 k0, f32 k1, f32 k2);
void GXLoadLightObjImm(GXLightObj* lt_obj, GXLightID light);
typedef void (*GXDrawSyncCallback)(u16 token);
typedef void (*GXDrawDoneCallback)(void);
BOOL IsWriteGatherBufferEmpty(void);
GXFifoObj *GXInit(void *base, u32 size);
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush(void);
void GXResetWriteGatherPipe(void);
void GXAbortFrame(void);
void GXSetDrawSync(u16 token);
u16 GXReadDrawSync(void);
void GXSetDrawDone(void);
void GXWaitDrawDone(void);
void GXDrawDone(void);
void GXPixModeSync(void);
void GXTexModeSync(void);
GXDrawSyncCallback GXSetDrawSyncCallback(GXDrawSyncCallback cb);
GXDrawDoneCallback GXSetDrawDoneCallback(GXDrawDoneCallback cb);
void GXSetMisc(GXMiscToken token, u32 val);
void GXFlush();
void GXResetWriteGatherPipe();
void GXAbortFrame();
void GXReadXfRasMetric(u32* xf_wait_in, u32* xf_wait_out, u32* ras_busy, u32* clocks);
void GXSetFog(GXFogType type, f32 startz, f32 endz, f32 nearz, f32 farz, GXColor color);
void GXInitFogAdjTable(GXFogAdjTable *table, u16 width, f32 projmtx[4][4]);
void GXSetFogRangeAdj(GXBool enable, u16 center, GXFogAdjTable *table);
void GXSetBlendMode(GXBlendMode type, GXBlendFactor src_factor, GXBlendFactor dst_factor, GXLogicOp op);
void GXSetColorUpdate(GXBool update_enable);
void GXSetAlphaUpdate(GXBool update_enable);
void GXSetZMode(GXBool compare_enable, GXCompare func, GXBool update_enable);
void GXSetZCompLoc(GXBool before_tex);
void GXSetPixelFmt(GXPixelFmt pix_fmt, GXZFmt16 z_fmt);
void GXSetDither(GXBool dither);
void GXSetDstAlpha(GXBool enable, u8 alpha);
void GXSetFieldMask(GXBool odd_mask, GXBool even_mask);
void GXSetFieldMode(GXBool field_mode, GXBool half_aspect_ratio);
void GXSetTevOp(GXTevStageID id, GXTevMode mode);
void GXSetTevColorIn(GXTevStageID stage, GXTevColorArg a, GXTevColorArg b, GXTevColorArg c,
GXTevColorArg d);
void GXSetTevAlphaIn(GXTevStageID stage, GXTevAlphaArg a, GXTevAlphaArg b, GXTevAlphaArg c,
GXTevAlphaArg d);
void GXSetTevColorOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevAlphaOp(GXTevStageID stage, GXTevOp op, GXTevBias bias, GXTevScale scale, GXBool clamp,
GXTevRegID out_reg);
void GXSetTevColor(GXTevRegID id, GXColor color);
void GXSetTevColorS10(GXTevRegID id, GXColorS10 color);
void GXSetTevKColor(GXTevKColorID id, GXColor color);
void GXSetTevKColorSel(GXTevStageID stage, GXTevKColorSel sel);
void GXSetTevKAlphaSel(GXTevStageID stage, GXTevKAlphaSel sel);
void GXSetTevSwapMode(GXTevStageID stage, GXTevSwapSel ras_sel, GXTevSwapSel tex_sel);
void GXSetTevSwapModeTable(GXTevSwapSel table, GXTevColorChan red, GXTevColorChan green,
GXTevColorChan blue, GXTevColorChan alpha);
void GXSetAlphaCompare(GXCompare comp0, u8 ref0, GXAlphaOp op, GXCompare comp1, u8 ref1);
void GXSetZTexture(GXZTexOp op, GXTexFmt fmt, u32 bias);
void GXSetTevOrder(GXTevStageID stage, GXTexCoordID coord, GXTexMapID map, GXChannelID color);
void GXSetNumTevStages(u8 nStages);
typedef GXTexRegion* (*GXTexRegionCallback)(const GXTexObj* obj, GXTexMapID id);
typedef GXTlutRegion* (*GXTlutRegionCallback)(u32 idx);
void GXInitTexObj(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXTexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap);
void GXInitTexObjCI(GXTexObj* obj, void* image_ptr, u16 width, u16 height, GXCITexFmt format, GXTexWrapMode wrap_s,
GXTexWrapMode wrap_t, u8 mipmap, u32 tlut_name);
void GXInitTexObjData(GXTexObj* obj, void* image_ptr);
void GXInitTexObjLOD(GXTexObj* obj, GXTexFilter min_filt, GXTexFilter mag_filt, f32 min_lod, f32 max_lod, f32 lod_bias,
GXBool bias_clamp, GXBool do_edge_lod, GXAnisotropy max_aniso);
void GXLoadTexObj(GXTexObj* obj, GXTexMapID id);
u32 GXGetTexBufferSize(u16 width, u16 height, u32 format, GXBool mipmap, u8 max_lod);
void GXInvalidateTexAll();
void GXInitTexObjWrapMode(GXTexObj* obj, GXTexWrapMode s, GXTexWrapMode t);
void GXInitTlutObj(GXTlutObj* tlut_obj, void* lut, GXTlutFmt fmt, u16 n_entries);
void GXLoadTlut(GXTlutObj* obj, u32 idx);
void GXSetTexCoordScaleManually(GXTexCoordID coord, GXBool enable, u16 ss, u16 ts);
void GXInitTexCacheRegion(GXTexRegion* region, GXBool is_32b_mipmap, u32 tmem_even, GXTexCacheSize size_even,
u32 tmem_odd, GXTexCacheSize size_odd);
GXTexRegionCallback GXSetTexRegionCallback(GXTexRegionCallback callback);
void GXInvalidateTexRegion(GXTexRegion* region);
void GXInitTlutRegion(GXTlutRegion* region, u32 tmem_addr, GXTlutSize tlut_size);
void GXSetTexCoordBias(GXTexCoordID coord, u8 s_enable, u8 t_enable);
void GXSetProjection(f32 mtx[4][4], GXProjectionType type);
void GXLoadPosMtxImm(f32 mtx[3][4], u32 id);
void GXLoadNrmMtxImm(f32 mtx[3][4], u32 id);
void GXLoadTexMtxImm(f32 mtx[][4], u32 id, GXTexMtxType type);
void GXSetViewport(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz);
void GXSetCurrentMtx(u32 id);
void GXSetViewportJitter(f32 left, f32 top, f32 wd, f32 ht, f32 nearz, f32 farz, u32 field);
void GXSetScissorBoxOffset(s32 x_off, s32 y_off);
void GXSetClipMode(GXClipMode mode);
typedef enum {
GX_WARN_NONE,
GX_WARN_SEVERE,
GX_WARN_MEDIUM,
GX_WARN_ALL
} GXWarningLevel;
typedef void (*GXVerifyCallback)(GXWarningLevel level, u32 id, char *msg);
void GXSetVerifyLevel(GXWarningLevel level);
GXVerifyCallback GXSetVerifyCallback(GXVerifyCallback cb);
typedef union {
u8 u8;
u16 u16;
u32 u32;
u64 u64;
s8 s8;
s16 s16;
s32 s32;
s64 s64;
f32 f32;
f64 f64;
} PPCWGPipe;
volatile PPCWGPipe GXWGFifo : (0xCC008000) ;
static inline void GXPosition2f32(f32 x, f32 y) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
}
static inline void GXPosition3s16(s16 x, s16 y, s16 z) {
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
GXWGFifo.s16 = z;
}
static inline void GXPosition3f32(f32 x, f32 y, f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXNormal3f32(f32 x, f32 y, f32 z) {
GXWGFifo.f32 = x;
GXWGFifo.f32 = y;
GXWGFifo.f32 = z;
}
static inline void GXColor1u32(u32 v) {
GXWGFifo.u32 = v;
}
static inline void GXColor4u8(u8 r, u8 g, u8 b, u8 a) {
GXWGFifo.u8 = r;
GXWGFifo.u8 = g;
GXWGFifo.u8 = b;
GXWGFifo.u8 = a;
}
static inline void GXTexCoord2s16(s16 u, s16 v) {
GXWGFifo.s16 = u;
GXWGFifo.s16 = v;
}
static inline void GXPosition2s16(s16 x, s16 y)
{
GXWGFifo.s16 = x;
GXWGFifo.s16 = y;
}
static inline void GXPosition2u16(u16 x, u16 y)
{
GXWGFifo.u16 = x;
GXWGFifo.u16 = y;
}
static inline void GXTexCoord2f32(f32 u, f32 v) {
GXWGFifo.f32 = u;
GXWGFifo.f32 = v;
}
static inline void GXTexCoord2u8(u8 u, u8 v)
{
GXWGFifo.u8 = u;
GXWGFifo.u8 = v;
}
static inline void GXPosition1x8(u8 index) {
GXWGFifo.u8 = index;
}
static inline void GXTexCoord2u16(u16 s, u16 t) {
GXWGFifo.u16 = s;
GXWGFifo.u16 = t;
}
static inline void GXEnd(void) {}
typedef struct {
unsigned int cmd:8;
unsigned int a0:4;
unsigned int c0:5;
unsigned int Aa0:3;
unsigned int Ac0:3;
unsigned int a1:4;
unsigned int c1:5;
unsigned int b0:4;
unsigned int b1:4;
unsigned int Aa1:3;
unsigned int Ac1:3;
unsigned int d0:3;
unsigned int Ab0:3;
unsigned int Ad0:3;
unsigned int d1:3;
unsigned int Ab1:3;
unsigned int Ad1:3;
} Gsetcombine_new;
typedef struct {
int cmd:8;
unsigned int Aa0:3;
unsigned int Ab0:3;
unsigned int Ac0:3;
unsigned int Ad0:3;
unsigned int Aa1:3;
unsigned int Ab1:3;
unsigned int Ac1:3;
unsigned int Ad1:3;
unsigned int a0:4;
unsigned int b0:4;
unsigned int c0:4;
unsigned int d0:4;
unsigned int a1:4;
unsigned int b1:4;
unsigned int c1:4;
unsigned int d1:4;
} Gsetcombine_tev;
typedef struct {
int cmd:8;
unsigned int upper0:8;
unsigned int lower0:16;
unsigned int upper1:16;
unsigned int lower1:16;
} Gsetcombine_raw;
typedef struct {
unsigned int cmd:8;
unsigned int xl:12;
unsigned int yl:12;
unsigned int pad1:5;
unsigned int tile:3;
unsigned int xh:12;
unsigned int yh:12;
unsigned int pad2:32;
unsigned int s:16;
unsigned int t:16;
unsigned int pad3:32;
unsigned int dsdx:16;
unsigned int dtdy:16;
} Gtexrect2;
typedef struct {
int cmd:8;
unsigned int dol_fmt:4;
unsigned int pad0:1;
unsigned int tile:3;
unsigned int tlut_name:4;
unsigned int wrap_s:2;
unsigned int wrap_t:2;
unsigned int shift_s:4;
unsigned int shift_t:4;
unsigned int pad1:32;
} Gsettile_dolphin;
typedef struct {
int cmd:8;
unsigned int sl:14;
unsigned int slen:10;
s8 isDolphin:1;
unsigned int pad:4;
unsigned int tile:3;
unsigned int tl:14;
unsigned int tlen:10;
} Gsettilesize_Dolphin;
typedef struct {
int cmd:8;
unsigned int fmt:3;
unsigned int siz:2;
unsigned int isDolphin:1;
unsigned int ht:8;
unsigned int wd:10;
unsigned int imgaddr:32;
} Gsetimg2;
typedef union {
Gsetimg setimg;
Gsetimg2 setimg2;
} Gsetimg_new;
typedef struct {
int cmd:8;
unsigned int type:2;
unsigned int pad0:2;
unsigned int tlut_name:4;
unsigned int pad1:2;
unsigned int count:14;
unsigned int tlut_addr:32;
} Gloadtlut_dolphin;
typedef struct {
unsigned int cmd:8;
unsigned int xparam:8;
unsigned int pad:2;
unsigned int level:3;
unsigned int tile:3;
unsigned int on:8;
unsigned short s;
unsigned short t;
} Gtexture_internal;
typedef struct {
unsigned int cmd:8;
unsigned int index:8;
unsigned int offset:16;
unsigned int data;
} Gmoveword;
typedef struct {
unsigned int cmd:8;
unsigned int length:8;
unsigned int offset:8;
unsigned int index:8;
unsigned int data;
} Gmovemem;
typedef struct Gsettexedgealpha {
unsigned int cmd:8;
unsigned int unused0:24;
unsigned int unused1:24;
unsigned int tex_edge_alpha:8;
} Gsettexedgealpha;
typedef struct {
int cmd:8;
unsigned int x0:10;
unsigned int x0frac:2;
unsigned int y0:10;
unsigned int y0frac:2;
unsigned int pad:8;
unsigned int x1:10;
unsigned int x1frac:2;
unsigned int y1:10;
unsigned int y1frac:2;
} Gscissor;
typedef struct {
int cmd:8;
unsigned int x0:10;
unsigned int x0frac:2;
unsigned int y0:10;
unsigned int y0frac:2;
unsigned int pad:8;
unsigned int x1:10;
unsigned int x1frac:2;
unsigned int y1:10;
unsigned int y1frac:2;
} Gfillrect2;
typedef struct Gnoop {
unsigned int cmd: 8;
unsigned int tag: 8;
unsigned int param0: 16;
unsigned int param1;
} Gnoop;
typedef struct Gmtx {
unsigned int cmd: 8;
unsigned int par: 8;
unsigned int pad: 8;
unsigned int type: 8;
unsigned int addr;
} Gmtx;
typedef struct Gvtx {
unsigned int cmd: 8;
unsigned int pad0: 4;
unsigned int n: 8;
unsigned int pad1: 4;
unsigned int vn:8;
unsigned int addr;
} Gvtx;
typedef struct Gline3D_new {
unsigned int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int wd: 8;
unsigned int pad;
} Gline3D_new;
typedef struct Gtri1 {
unsigned int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int v2: 8;
unsigned int pad;
} Gtri1;
typedef struct Gtri2 {
int cmd: 8;
unsigned int t0v0: 8;
unsigned int t0v1: 8;
unsigned int t0v2: 8;
unsigned int pad: 8;
unsigned int t1v0: 8;
unsigned int t1v1: 8;
unsigned int t1v2: 8;
} Gtri2;
typedef struct Gtrin_independ {
unsigned int cmd: 8;
unsigned int count: 7;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v2_1: 2;
unsigned int f1v2_0: 3;
unsigned int f1v1: 5;
unsigned int f1v0: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gtrin_independ;
typedef struct Gtrin {
unsigned int f3v2: 5;
unsigned int f3v1: 5;
unsigned int f3v0: 5;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v2_1: 2;
unsigned int f1v2_0: 3;
unsigned int f1v1: 5;
unsigned int f1v0: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gtrin;
typedef struct Gtrin_7b {
unsigned int f2v2: 7;
unsigned int f2v1: 7;
unsigned int f2v0: 7;
unsigned int f1v2: 7;
unsigned int f1v1_1: 4;
unsigned int f1v1_0: 3;
unsigned int f1v0: 7;
unsigned int f0v2: 7;
unsigned int f0v1: 7;
unsigned int f0v0: 7;
unsigned int is7bit: 1;
} Gtrin_7b;
typedef struct Gquad_independ {
unsigned int cmd: 8;
unsigned int count: 7;
unsigned int unused: 5;
unsigned int f1v3: 5;
unsigned int f1v2: 5;
unsigned int f1v1_1: 2;
unsigned int f1v1_0: 3;
unsigned int f1v0: 5;
unsigned int f0v3: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gquad_independ;
typedef struct Gquad {
unsigned int f2v3: 5;
unsigned int f2v2: 5;
unsigned int f2v1: 5;
unsigned int f2v0: 5;
unsigned int f1v3: 5;
unsigned int f1v2: 5;
unsigned int f1v1_1: 2;
unsigned int f1v1_0: 3;
unsigned int f1v0: 5;
unsigned int f0v3: 5;
unsigned int f0v2: 5;
unsigned int f0v1: 5;
unsigned int f0v0: 5;
unsigned int pad: 3;
unsigned int is7bit: 1;
} Gquad;
typedef struct Gquad_7b {
unsigned int f1v3: 7;
unsigned int f1v2: 7;
unsigned int f1v1: 7;
unsigned int f1v0_1: 4;
unsigned int f1v0_0: 3;
unsigned int pad: 4;
unsigned int f0v3: 7;
unsigned int f0v2: 7;
unsigned int f0v1: 7;
unsigned int f0v0: 7;
unsigned int pad0: 3;
unsigned int is7bit: 1;
} Gquad_7b;
typedef struct Gquad0 {
int cmd: 8;
unsigned int v0: 8;
unsigned int v1: 8;
unsigned int v2: 8;
unsigned int pad: 24;
unsigned int v3: 8;
} Gquad0;
typedef struct Gculldl {
int cmd: 8;
unsigned int pad0: 8;
unsigned int vstart: 16;
unsigned int pad1: 16;
unsigned int vend: 16;
} Gculldl;
typedef struct Gspecial1 {
int cmd: 8;
int mode: 8;
unsigned int param0: 16;
unsigned int param1;
} Gspecial1;
typedef struct {
int cmd:8;
int pad0:8;
u32 sft:8;
u32 len:8;
unsigned int data:32;
} Gsetothermode_dolphin;
typedef struct {
unsigned char col[3];
unsigned char kc;
unsigned char colc[3];
unsigned char kl;
signed short pos[3];
unsigned char kq;
} Light_pos_t;
typedef union {
Light_t l;
Light_pos_t p;
long long int force_align[2];
} Light_new;
typedef struct {
u8 color0;
u8 color1;
u8 color2;
u8 color3;
} combiner_tev_color;
typedef struct {
u8 alpha0;
u8 alpha1;
} combiner_tev_alpha;
typedef struct {
s16 x;
s16 y;
s16 z;
u8 color[3];
u8 drawGlow;
s16 radius;
} LightPoint;
typedef struct {
s8 x;
s8 y;
s8 z;
u8 color[3];
} LightDiffuse;
typedef union {
LightPoint point;
LightDiffuse diffuse;
} LightParams;
typedef struct lights_s {
u8 type;
LightParams lights;
} Lights;
typedef struct light_list {
Lights* info;
struct light_list* prev;
struct light_list* next;
} Light_list;
typedef struct light_buf_s {
int current;
int idx;
Light_list lights[32];
} Light_buffer;
typedef struct lightsn_s {
u8 diffuse_count;
Ambient a;
Light_new l[7];
} LightsN;
typedef struct global_light_s {
Light_list* list;
u8 ambientColor[3];
u8 fogColor[3];
s16 fogNear;
s16 fogFar;
} Global_light;
typedef void (*light_point_proc)(LightsN*, LightParams*, xyz_t*);
typedef void (*light_P_point_proc)(LightsN*, LightParams*, xyz_t*);
extern void Light_point_ct(Lights* lights, s16 x, s16 y, s16 z, u8 r, u8 g, u8 b, s16 radius);
extern void Light_diffuse_ct(Lights* lights, s8 x, s8 y, s8 z, u8 r, u8 g, u8 b);
extern void LightsN_disp_BG(LightsN* lights, GRAPH* graph);
extern void LightsN_disp(LightsN* lights, GRAPH* graph);
extern void LightsN_list_check(LightsN* lights, Light_list* node, xyz_t* pos);
extern void Global_light_ct(Global_light* glight);
extern LightsN* Global_light_read(Global_light* glight, GRAPH* graph);
extern Light_list* Global_light_list_new(GAME* game, Global_light* glight, Lights* light);
extern void Global_light_list_delete(Global_light* glight, Light_list* light);
extern void Light_list_point_draw(GAME_PLAY* play);
enum {
mCoBG_PLANT0 = 0,
mCoBG_PLANT1 = 1,
mCoBG_PLANT2 = 2,
mCoBG_PLANT3 = 3,
mCoBG_PLANT4 = 4,
mCoBG_KILL_PLANT = 7
};
enum field_layer {
mCoBG_LAYER0,
mCoBG_LAYER1,
mCoBG_LAYER2,
mCoBG_LAYER3,
mCoBG_LAYER_NUM
};
enum {
mCoBG_FTR_TYPEA,
mCoBG_FTR_TYPEB_0,
mCoBG_FTR_TYPEB_180,
mCoBG_FTR_TYPEB_270,
mCoBG_FTR_TYPEB_90,
mCoBG_FTR_TYPEC,
mCoBG_FTR_TYPE_NUM
};
enum background_attribute {
mCoBG_ATTRIBUTE_GRASS0,
mCoBG_ATTRIBUTE_GRASS1,
mCoBG_ATTRIBUTE_GRASS2,
mCoBG_ATTRIBUTE_GRASS3,
mCoBG_ATTRIBUTE_SOIL0,
mCoBG_ATTRIBUTE_SOIL1,
mCoBG_ATTRIBUTE_SOIL2,
mCoBG_ATTRIBUTE_STONE,
mCoBG_ATTRIBUTE_FLOOR,
mCoBG_ATTRIBUTE_BUSH,
mCoBG_ATTRIBUTE_HOLE,
mCoBG_ATTRIBUTE_WAVE,
mCoBG_ATTRIBUTE_WATER,
mCoBG_ATTRIBUTE_WATERFALL,
mCoBG_ATTRIBUTE_RIVER_N,
mCoBG_ATTRIBUTE_RIVER_NW,
mCoBG_ATTRIBUTE_RIVER_W,
mCoBG_ATTRIBUTE_RIVER_SW,
mCoBG_ATTRIBUTE_RIVER_S,
mCoBG_ATTRIBUTE_RIVER_SE,
mCoBG_ATTRIBUTE_RIVER_E,
mCoBG_ATTRIBUTE_RIVER_NE,
mCoBG_ATTRIBUTE_SAND,
mCoBG_ATTRIBUTE_WOOD,
mCoBG_ATTRIBUTE_SEA,
mCoBG_ATTRIBUTE_25,
mCoBG_ATTRIBUTE_26,
mCoBG_ATTRIBUTE_27,
mCoBG_ATTRIBUTE_28,
mCoBG_ATTRIBUTE_29,
mCoBG_ATTRIBUTE_30,
mCoBG_ATTRIBUTE_31,
mCoBG_ATTRIBUTE_32,
mCoBG_ATTRIBUTE_33,
mCoBG_ATTRIBUTE_34,
mCoBG_ATTRIBUTE_35,
mCoBG_ATTRIBUTE_36,
mCoBG_ATTRIBUTE_37,
mCoBG_ATTRIBUTE_38,
mCoBG_ATTRIBUTE_39,
mCoBG_ATTRIBUTE_40,
mCoBG_ATTRIBUTE_41,
mCoBG_ATTRIBUTE_42,
mCoBG_ATTRIBUTE_43,
mCoBG_ATTRIBUTE_44,
mCoBG_ATTRIBUTE_45,
mCoBG_ATTRIBUTE_46,
mCoBG_ATTRIBUTE_47,
mCoBG_ATTRIBUTE_48,
mCoBG_ATTRIBUTE_49,
mCoBG_ATTRIBUTE_50,
mCoBG_ATTRIBUTE_51,
mCoBG_ATTRIBUTE_52,
mCoBG_ATTRIBUTE_53,
mCoBG_ATTRIBUTE_54,
mCoBG_ATTRIBUTE_55,
mCoBG_ATTRIBUTE_56,
mCoBG_ATTRIBUTE_57,
mCoBG_ATTRIBUTE_58,
mCoBG_ATTRIBUTE_59,
mCoBG_ATTRIBUTE_60,
mCoBG_ATTRIBUTE_61,
mCoBG_ATTRIBUTE_62,
mCoBG_ATTRIBUTE_63,
mCoBG_ATTRIBUTE_NONE = 100
};
enum {
mCoBG_DIM_XY,
mCoBG_DIM_XZ,
mCoBG_DIM_YZ,
mCoBG_DIM_ALL,
mCoBG_DIM_NUM
};
enum {
mCoBG_DIRECT_N,
mCoBG_DIRECT_W,
mCoBG_DIRECT_S,
mCoBG_DIRECT_E,
mCoBG_DIRECT_NW,
mCoBG_DIRECT_NE,
mCoBG_DIRECT_SE,
mCoBG_DIRECT_SW,
mCoBG_DIRECT_NUM
};
enum {
mCoBG_AREA_N,
mCoBG_AREA_W,
mCoBG_AREA_S,
mCoBG_AREA_E,
mCoBG_AREA_NUM
};
enum {
mCoBG_BLOCK_BGCHECK_MODE_NORMAL,
mCoBG_BLOCK_BGCHECK_MODE_INTRO_DEMO,
mCoBG_BLOCK_BGCHECK_MODE_NUM
};
extern int mCoBG_block_bgcheck_mode;
typedef struct collision_bg_data_s {
u32 slate_flag : 1;
u32 center : 5;
u32 top_left : 5;
u32 bot_left : 5;
u32 bot_right : 5;
u32 top_right : 5;
u32 unit_attribute : 6;
} mCoBG_CollisionData_c;
typedef union collision_bg_u {
mCoBG_CollisionData_c data;
u32 raw;
} mCoBG_Collision_u;
typedef struct collision_unit_info_s {
mCoBG_Collision_u* collision;
f32 leftUp_offset;
f32 leftDown_offset;
f32 rightDown_offset;
f32 rightUp_offset;
f32 base_height;
f32 unit_pos[2];
int ut_x;
int ut_z;
u32 slate_flag;
u8 attribute;
mActor_name_t item;
} mCoBG_UnitInfo_c;
typedef struct collision_bg_check_result_s {
u32 on_ground : 1;
u32 hit_attribute_wall : 5;
u32 hit_wall : 5;
u32 hit_wall_count : 3;
u32 jump_flag : 1;
u32 unit_attribute : 6;
u32 is_on_move_bg_obj : 1;
u32 is_in_water : 1;
u32 unk_flag1 : 1;
u32 unk_flag2 : 1;
u32 unk_flag3 : 1;
u32 unk_flag4 : 1;
u32 unk_flag5 : 1;
u32 unk_flag6 : 4;
} mCoBG_CheckResult_c;
typedef struct wall_info_s {
s16 angleY;
s16 type;
} mCoBG_WallInfo_c;
enum {
mCoBG_WALL_TYPE0,
mCoBG_WALL_TYPE1,
mCoBG_WALL_TYPE_NUM
};
enum {
mCoBG_WALL_UP,
mCoBG_WALL_LEFT,
mCoBG_WALL_DOWN,
mCoBG_WALL_RIGHT,
mCoBG_WALL_SLATE_UP,
mCoBG_WALL_SLATE_DOWN,
mCoBG_WALL_NUM
};
enum {
mCoBG_NORM_DIRECT_UP,
mCoBG_NORM_DIRECT_LEFT,
mCoBG_NORM_DIRECT_DOWN,
mCoBG_NORM_DIRECT_RIGHT,
mCoBG_NORM_DIRECT_NUM
};
typedef struct collision_bg_check_s {
mCoBG_Collision_u collision_units[5];
mCoBG_CheckResult_c result;
f32 wall_top_y;
f32 wall_bottom_y;
f32 ground_y;
mCoBG_WallInfo_c wall_info[2];
s16 in_front_wall_angle_y;
} mCoBG_Check_c;
typedef struct bg_side_contact_s {
s16 name;
s16 angle;
} mCoBG_side_contact_c;
typedef struct bg_on_contact_s {
s16 name;
} mCoBG_on_contact_c;
typedef struct bg_on_contact_inf_s {
mCoBG_on_contact_c contact[5];
int count;
} mCoBG_on_contact_info_c;
typedef struct bg_contact_s {
mCoBG_side_contact_c side_contact[5];
int side_count;
mCoBG_on_contact_info_c on_contact;
} mCoBG_bg_contact_c;
typedef struct bg_size_s {
f32 right_size;
f32 left_size;
f32 up_size;
f32 down_size;
} mCoBG_bg_size_c;
typedef struct bg_register_s {
xyz_t* wpos;
xyz_t* last_wpos;
s16* angle_y;
mCoBG_bg_contact_c* contact;
mCoBG_bg_size_c* bg_size;
xyz_t* base_ofs;
f32 height;
u32 attribute;
f32 active_dist;
f32* scale_percent;
} mCoBG_bg_regist_c;
typedef struct bg_mgr_s {
mCoBG_bg_regist_c* regist_p[64 ];
int count;
} mCoBG_mBgMgr_c;
typedef struct collision_offset_table_s {
u8 unit_attribute;
s8 centerRight_offset;
s8 leftUp_offset;
s8 leftDown_offset;
s8 rightDown_offset;
s8 rightUp_offset;
s8 shape;
} mCoBG_OffsetTable_c;
typedef struct wall_height_s {
f32 top;
f32 bot;
} mCoBG_WallHeight_c;
typedef struct collision_actor_info_s {
s16 name;
u8 check_type;
u8 old_on_ground;
u8 _04;
u8 old_in_water;
mCoBG_CheckResult_c* check_res_p;
f32 speed_xz0[2];
f32 speed_xz1[2];
xyz_t center_pos;
xyz_t old_center_pos;
xyz_t rev_pos;
f32 range;
f32 ground_dist;
f32 old_ground_y;
f32 ground_y;
mCoBG_WallHeight_c wall_height;
mCoBG_WallInfo_c wall_info[2 ];
s16 ut_count;
u32 _64;
int _68;
int _6C;
} mCoBG_ActorInf_c;
enum {
mCoBG_UNIT_RADIAN,
mCoBG_UNIT_DEGREE,
mCoBG_UNIT_SHORT,
mCoBG_UNIT_NUM
};
enum {
mCoBG_CHECK_TYPE_NORMAL,
mCoBG_CHECK_TYPE_PLAYER,
mCoBG_CHECK_TYPE_NUM
};
enum {
mCoBG_REVERSE_TYPE_REVERSE,
mCoBG_REVERSE_TYPE_NO_REVERSE,
mCoBG_REVERSE_TYPE_NUM
};
typedef int (*mCoBG_COLUMN_CHECK_ITEM_TYPE_PROC)(mActor_name_t item);
extern u32 mCoBG_Wpos2Attribute(xyz_t pos, s8* cant_dig);
extern void mCoBG_InitBgCheckResult(mCoBG_CheckResult_c* result);
extern void mCoBG_BgCheckControll_RemoveDirectedUnitColumn(xyz_t* actor_revpos, ACTOR* actorx, f32 range, f32 ground_dist, s16 attr_wall, s16 rev_type, s16 check_type, int ux, int uz);
extern void mCoBG_BgCheckControll(xyz_t* actor_revpos, ACTOR* actorx, f32 range, f32 ground_dist, s16 attr_wall, s16 rev_type, s16 check_type);
extern void mCoBG_WallCheckOnly(xyz_t* actor_revpos, ACTOR* actorx, f32 range, f32 ground_dist, s16 rev_type, s16 check_type);
extern void mCoBG_GroundCheckOnly(xyz_t* actor_revpos, ACTOR* actorx, f32 range, f32 ground_dist, s16 rev_type);
extern void mCoBG_VirtualBGCheck(xyz_t* rev_pos_p, mCoBG_Check_c* bg_check, const xyz_t* start_pos_p,
const xyz_t* end_pos_p, s16 angle_y, s16 water_flag, s16 ground_flag, f32 range,
f32 ground_dist, s16 attr_wall, s16 rev_type, s16 check_type);
extern void mCoBG_RotateY(f32* pos, f32 rad);
extern f32 mCoBG_GetVectorProductin2D(f32* vec0_xz, f32* vec1_xz);
extern int mCoBG_JudgeCrossTriangleAndLine2D(xyz_t v0, xyz_t v1, xyz_t v2, xyz_t p, int dim);
extern int mCoBG_GetDimension2Idx(f32 p0, f32 p1, f32 p2);
extern int mCoBG_GetCrossTriangleAndLine3D(xyz_t* cross, xyz_t v0, xyz_t v1, xyz_t v2, xyz_t line0, xyz_t line1);
extern f32 mCoBG_GetVectorScalar2D(f32* v0, f32* v1);
extern int mCoBG_GetCrossJudge_2Vector(f32* vec0_p0, f32* vec0_p1, f32* vec1_p0, f32* vec1_p1);
extern void mCoBG_GetCross2Line(f32* cross, f32* line0_p0, f32* line0_p1, f32* line1_p0, f32* line1_p1);
extern f32 mCoBG_Get2VectorAngleF(f32* v0, f32* v1, u8 unit);
extern s16 mCoBG_Get2VectorAngleS(f32* v0, f32* v1);
extern int mCoBG_GetCrossLineAndPerpendicular(f32* cross, f32* p0, f32* p1, f32* target);
extern int mCoBG_GetPointInfoFrontLine(f32* start, f32* point, f32* normal);
extern int mCoBG_GetDistPointAndLine2D(f32* dist, f32* line0, f32* line1, f32* point);
extern int mCoBG_GetDistPointAndLine2D_Norm(f32* dist, f32* line0, f32* line1, f32* normal, f32* point);
extern int mCoBG_GetCrossCircleAndLine2Dvector(f32* cross0, f32* cross1, f32* point, f32* vec, f32* center, f32 radius);
extern int mCoBG_GetCrossCircleAndLine2D(f32* cross0, f32* cross1, f32* p0, f32* p1, f32* center, f32 radius);
extern void mCoBG_GetReverseVector2D(f32* vec);
extern void mCoBG_GetUnitVector2D(f32* vec);
extern int mCoBG_JudgePointInCircle_Xyz(const xyz_t* p, const xyz_t* center, f32 radius);
extern int mCoBG_JudgePointInCircle(f32* p, f32* center, f32 radius);
extern f32 mCoBG_GetAbsBiggerF(f32 a, f32 b);
extern void mCoBG_GetNorm_By2Vector(f32* v0, f32* v1, xyz_t* normal);
extern void mCoBG_GetNorm_By3Point(xyz_t* normal, f32* v0, f32* v1, f32* v2);
extern int mCoBG_RangeCheckLinePoint(f32* start, f32* end, f32* point);
extern void mCoBG_CalcTimerDecalCircle(void);
extern int mCoBG_RegistDecalCircle(const xyz_t* pos, f32 start_radius, f32 end_radius, s16 timer);
extern void mCoBG_InitDecalCircle(void);
extern void mCoBG_CrossOffDecalCircle(int idx);
extern int mCoBG_JudgeMoveBgGroundCheck(f32* point, f32* goal, f32 dist);
extern int mCoBG_GetMoveBgHeight(f32* move_bg_height, xyz_t* pos_p);
extern void mCoBG_InitMoveBgContact(mCoBG_bg_contact_c* contact);
extern int mCoBG_RegistMoveBg(mCoBG_bg_regist_c* regist, xyz_t* wpos, xyz_t* old_wpos, s16* angleY, f32 height,
mCoBG_bg_size_c* size, f32* scale_percent, mCoBG_bg_contact_c* contact, xyz_t* base_ofs,
int type, u32 attribute, f32 check_dist);
extern mCoBG_bg_regist_c* mCoBG_Idx2RegistPointer(int move_bg_idx);
extern void mCoBG_CrossOffMoveBg(int move_bg_idx);
extern void mCoBG_InitMoveBgData(void);
extern void mCoBG_InitBoatCollision(void);
extern void mCoBG_MakeBoatCollision(ACTOR* actor, xyz_t* pos, s16* angle_y);
extern void mCoBG_DeleteBoatCollision(ACTOR* actor);
extern void mCoBG_GetSlopeSlideVector(xyz_t* vec, xyz_t pos);
extern f32 mCoBG_GetBgY_AngleS_FromWpos(s_xyz* ground_angle, xyz_t pos, f32 ground_dist);
extern f32 mCoBG_GetBgY_OnlyCenter_FromWpos(xyz_t pos, f32 ground_dist);
extern f32 mCoBG_Wpos2BgUtCenterHeight_AddColumn(xyz_t pos);
extern f32 mCoBG_GetBgY_OnlyCenter_FromWpos2(xyz_t pos, f32 ground_dist);
extern void mCoBG_GetBgNorm_FromWpos(xyz_t* norm, xyz_t wpos);
extern int mCoBG_ScrollCheck(xyz_t start, xyz_t end, f32 radius);
extern int mCoBG_CheckPlace(xyz_t pos);
extern int mCoBG_UtCheckPlace(int ux, int uz);
extern int mCoBG_Attribute2CheckPlant(u32 attr, const xyz_t* pos);
extern int mCoBG_CheckPlant(xyz_t pos);
extern int mCoBG_Unit2CheckNpc(int ux, int uz);
extern int mCoBG_Wpos2CheckNpc(xyz_t pos);
extern int mCoBG_Attr2CheckPoorGround(u32 attr);
extern int mCoBG_Attr2CheckPlaceNpc(u32 attr);
extern int mCoBG_UtNum2BgAttr(int ux, int uz);
extern f32 mCoBG_UtNum2UtCenterY(int ux, int uz);
extern f32 mCoBG_UtNum2UtCenterY_Keep(int ux, int uz);
extern u32 mCoBG_Wpos2BgAttribute_Original(xyz_t pos);
extern int mCoBG_GetHoleNumber_ClData(mCoBG_Collision_u* col);
extern int mCoBG_GetHoleNumber(xyz_t pos);
extern int mCoBG_BnumUnum2HoleNumber(int bx, int bz, int b_ux, int b_uz);
extern int mCoBG_CheckHole_OrgAttr(u32 attr);
extern int mCoBG_CheckSandUt_ForFish(xyz_t* pos);
extern int mCoBG_CheckSandHole_ClData(mCoBG_Collision_u* col);
extern int mCoBG_BnumUnum2SandHole(int bx, int bz, int b_ux, int b_uz);
extern int mCoBG_CheckHole(xyz_t pos);
extern int mCoBG_CheckSkySwing(xyz_t pos);
extern int mCoBG_CheckGrassX_ClData(mCoBG_Collision_u* col);
extern int mCoBG_CheckGrassX(const xyz_t* pos);
extern int mCoBG_CheckWave_ClData(mCoBG_Collision_u* col);
extern int mCoBG_CheckWave(const xyz_t* pos);
extern int mCoBG_CheckAcceptDesignSign(const xyz_t* pos_p);
extern f32 mCoBG_GetBgHeightGapBetweenNowDefault(xyz_t pos);
extern int mCoBG_ExistHeightGap_KeepAndNow(xyz_t pos);
extern int mCoBG_SearchWaterLimitDistN(xyz_t* water_pos, xyz_t pos, s16 angle, f32 dist_limit, int divide);
extern int mCoBG_CheckRoughPathInRoom(const xyz_t* pos);
extern f32 mCoBG_GetBalloonGroundY(const xyz_t* pos);
extern int mCoBG_CheckAttribute_BallRolling(s16* angle, const xyz_t* pos);
extern f32 mCoBG_CheckBallRollingArea(s16 angle, const xyz_t* pos);
extern f32 mCoBG_Wpos2GroundCheckOnly(const xyz_t* pos, f32 ground_dist);
extern int mCoBG_ExistHeightGap_KeepAndNow_Detail(xyz_t pos);
extern int mCoBG_Wpos2CheckSlateCol(const xyz_t* pos, int check_attr);
extern int mCoBG_WoodSoundEffect(const xyz_t* pos);
extern int mCoBG_CheckCliffAttr(u32 attr);
extern f32 mCoBG_GetShadowBgY_AngleS_FromWpos(s_xyz* ground_angle, xyz_t pos, f32 ground_dist);
extern int mCoBG_CheckUtFlat(const xyz_t* pos);
extern int mCoBG_Height2GetLayer(f32 height);
extern int mCoBG_GetLayer(const xyz_t* pos);
extern void mCoBG_InitBlockBgCheckMode(void);
extern int mCoBG_ChangeBlockBgCheckMode(int mode);
extern int mCoBG_GetBlockBgCheckMode(void);
extern xyz_t mCoBG_UniqueWallCheck(ACTOR* actorx, f32 range, f32 y_ofs);
extern xyz_t mCoBG_ScopeWallCheck(ACTOR* actorx, const xyz_t* base_pos, f32 x, f32 z, f32 range, f32 y_ofs);
extern void mCoBG_Ut2SetPlussOffset(int ux, int uz, s16 change_ofs, s16 attr);
extern void mCoBG_SetPlussOffset(xyz_t wpos, s16 change_ofs, s16 attr);
extern void mCoBG_SetAttribute(xyz_t pos, s16 attr);
extern void mCoBG_Ut2SetPluss5PointOffset_file(int ux, int uz, mCoBG_OffsetTable_c ofs_data, char* file, int line);
extern void mCoBG_SetPluss5PointOffset_file(xyz_t pos, mCoBG_OffsetTable_c ofs_data, char* file, int line);
extern int mCoBG_Change2PoorAttr(mCoBG_Collision_u* col);
extern void mCoBG_Ut2SetDefaultOffset(int ux, int uz);
extern int mCoBG_LineCheck_RemoveFg(xyz_t* rev, xyz_t start_pos, xyz_t end_pos, mCoBG_COLUMN_CHECK_ITEM_TYPE_PROC check_proc, int line_check_type);
extern f32 mCoBG_GetBgY_AngleS_FromWpos2(s_xyz* ground_angle, xyz_t pos, f32 ground_dist);
extern f32 mCoBG_GetWaterHeight_File(xyz_t pos, char* file, int line);
extern int mCoBG_CheckWaterAttribute(u32 attr);
extern int mCoBG_CheckWaterAttribute_OutOfSea(u32 attr);
extern void mCoBG_WaveCos2BgCheck(f32 value);
extern f32 mCoBG_WaveCos(void);
extern int mCoBG_GetWaterFlow(xyz_t* flow, u32 attr);
extern int mCoBG_CheckWaveAttr(u32 attr);
extern int mCoBG_CheckSand2Sea(xyz_t* pos);
typedef struct math_3d_linef_s {
xyz_t a;
xyz_t b;
} Math3D_linef_c;
typedef struct math_3d_pipe_s {
s16 radius;
s16 height;
s16 offset;
s_xyz center;
} Math3D_pipe_c;
typedef struct math_3d_sphere_s {
s_xyz center;
s16 radius;
} Math3D_sphere_c;
typedef struct math_3d_plane_s {
xyz_t normal;
f32 originDist;
} Math3D_plane_c;
typedef struct math_3d_triangle_s {
xyz_t vtx[3];
Math3D_plane_c plane;
} Math3D_triangle_c;
typedef struct math_3d_spheref_s {
xyz_t center;
f32 radius;
} Math3D_sphereF_c;
typedef struct math_3d_pipef_s {
f32 radius;
f32 height;
f32 offset;
xyz_t center;
} Math3D_pipeF_c;
extern f32 Math3d_normalizeXyz_t(xyz_t* a);
extern void Math3DInDivPos1(const xyz_t* v, const xyz_t* d, f32 t, xyz_t* c);
extern void Math3DInDivPos2(const xyz_t* v, const xyz_t* d, xyz_t* c, f32 t);
extern f32 Math3DVecLengthSquare2D(f32 a, f32 b);
extern f32 Math3DVecLength2D(f32 a, f32 b);
extern f32 Math3DLengthSquare2D(f32 x0, f32 y0, f32 x1, f32 y1);
extern f32 Math3DLength2D(f32 x0, f32 x1, f32 y0, f32 y1);
extern f32 Math3DVecLengthSquare(xyz_t* v);
extern f32 Math3DVecLength(xyz_t* v);
extern f32 Math3DLengthSquare(xyz_t* a, xyz_t* b);
extern f32 Math3DLength(const xyz_t* a, const xyz_t* b);
extern void Math3DVectorProduct2Vec(const xyz_t* a, const xyz_t* b, xyz_t* ret);
extern void Math3DVectorProductXYZ(xyz_t* va, xyz_t* vb, xyz_t* vc, xyz_t* ret);
extern void Math3DPlane(xyz_t* va, xyz_t* vb, xyz_t* vc, f32* nox, f32* noy, f32* noz, f32* odist);
extern f32 Math3DPlaneFunc(f32 nox, f32 noy, f32 noz, f32 odist, const xyz_t* pl);
extern f32 Math3DLengthPlaneAndPos(f32 nox, f32 noy, f32 noz, f32 odist, const xyz_t* pl);
extern f32 Math3DSignedLengthPlaneAndPos(f32 nox, f32 noy, f32 noz, f32 odist, const xyz_t* pl);
extern int Math3DTriangleCrossYCheck_general(xyz_t* v0, xyz_t* v1, xyz_t* v2, f32 z, f32 x, f32 dt, f32 dist, f32 noy);
extern int Math3DTriangleCrossYLine_scope(xyz_t* v0, xyz_t* v1, xyz_t* v2, f32 nox, f32 noy, f32 noz, f32 dst, f32 z,
f32 x, f32* yint, f32 y0, f32 y1);
extern int Math3DTriangleCrossZCheck_general(xyz_t* v0, xyz_t* v1, xyz_t* v2, f32 x, f32 y, f32 dt, f32 dist, f32 noz);
extern int Math3D_sphereCollisionPoint(Math3D_sphere_c* s, xyz_t* p);
extern int Math3D_pointVsLineSegmentLengthSquare2D(f32 x0, f32 y0, f32 x1, f32 y1, f32 x2, f32 y2, f32* lsq);
extern int Math3D_sphereCrossLineSegment(Math3D_sphere_c* s, Math3D_linef_c* l);
extern void Math3D_sphereCrossTriangleCalc_cp(Math3D_sphere_c* s, Math3D_triangle_c* tri, xyz_t* ip);
extern int Math3D_sphereCrossTriangle3_cp(Math3D_sphere_c* s, Math3D_triangle_c* tri, xyz_t* ip);
extern int Math3D_pipeVsPos(Math3D_pipe_c* c, xyz_t* p);
extern int Math3D_pipeCrossLine(Math3D_pipe_c* c, xyz_t* la, xyz_t* lb, xyz_t* ia, xyz_t* ib);
extern int Math3D_pipeCrossTriangle_cp(Math3D_pipe_c* c, Math3D_triangle_c* tri, xyz_t* in);
extern int Math3D_sphereCrossSphere_cl(Math3D_sphere_c* a, Math3D_sphere_c* b, f32* in);
extern int Math3D_sphereCrossSphere_cl_cc(Math3D_sphere_c* a, Math3D_sphere_c* b, f32* in, f32* cdist);
extern int Math3D_sphereVsPipe_cl(Math3D_sphere_c* s, Math3D_pipe_c* c, f32* in);
extern int Math3D_sphereVsPipe_cl_cc(Math3D_sphere_c* s, Math3D_pipe_c* c, f32* in, f32* cdist);
extern int Math3D_pipeVsPipe_cl(Math3D_pipe_c* a, Math3D_pipe_c* b, f32* d);
extern int Math3D_pipeVsPipe_cl_cc(Math3D_pipe_c* a, Math3D_pipe_c* b, f32* d, f32* di);
extern void sMath_RotateY(xyz_t* v, f32 y);
extern void sMath_RotateX(xyz_t* v, f32 x);
extern void sMath_RotateZ(xyz_t* v, f32 z);
extern xyz_t ZeroVec;
extern s_xyz ZeroSVec;
enum collision_type {
ClObj_TYPE_JNT_SPH,
ClObj_TYPE_PIPE,
ClObj_TYPE_TRIS,
ClObj_TYPE_NUM
};
enum weight { MASS_IMMOVABLE, MASS_HEAVY, MASS_NORMAL };
typedef struct collision_obj_s {
ACTOR* owner_actor;
ACTOR* collided_actor;
u8 collision_flags0;
u8 collision_flags1;
u8 collision_type;
} ClObj_c;
typedef struct collision_elem_s {
u8 flags;
} ClObjElem_c;
typedef struct collision_pipe_attribute_s {
Math3D_pipe_c pipe;
} ClObjPipeAttr_c;
typedef struct collision_pipe_s {
ClObj_c collision_obj;
ClObjElem_c element;
ClObjPipeAttr_c attribute;
} ClObjPipe_c;
typedef struct collision_obj_data_s {
u8 collision_flags0;
u8 collision_flags1;
u8 type;
} ClObjData_c;
typedef struct collision_obj_elem_data_s {
u8 flags;
} ClObjElemData_c;
typedef struct collision_obj_pipe_attr_data_s {
Math3D_pipe_c pipe;
} ClObjPipeAttrData_c;
typedef struct collision_obj_pipe_data_s {
ClObjData_c collision_data;
ClObjElemData_c element_data;
ClObjPipeAttrData_c attribute_data;
} ClObjPipeData_c;
typedef struct collision_check_tris_element_attr_data_s {
xyz_t vtx[3];
} ClObjTrisElemAttrData_c;
typedef struct collision_check_tris_element_data_s {
ClObjElemData_c element;
ClObjTrisElemAttrData_c data;
} ClObjTrisElemData_c;
typedef struct collision_check_tris_element_s {
Math3D_triangle_c tri;
xyz_t t;
} ClObjTrisElemAttr_c;
typedef struct collision_tris_elem_s {
ClObjElem_c element;
ClObjTrisElemAttr_c attribute;
} ClObjTrisElem_c;
typedef struct collision_tris_s {
ClObj_c collision_obj;
int count;
ClObjTrisElem_c* elements;
} ClObjTris_c;
typedef struct ClObjTris_Init {
ClObjData_c data;
int count;
ClObjTrisElemData_c* elem_data;
} ClObjTrisData_c;
typedef struct collision_obj_joint_sphere_elem_attribute_s {
Math3D_sphere_c s1;
Math3D_sphere_c s2;
f32 unk8;
u8 unk14;
} ClObjJntSphElemAttr_c;
typedef struct collision_joint_sphere_elem_s {
ClObjElem_c element;
ClObjJntSphElemAttr_c attribute;
} ClObjJntSphElem_c;
typedef struct collision_joint_sphere_s {
ClObj_c collision_obj;
int count;
ClObjJntSphElem_c* elements;
} ClObjJntSph_c;
typedef struct collision_check_s {
u16 flags;
int collider_num;
ClObj_c* collider_table[50 ];
} CollisionCheck_c;
typedef struct status_s {
xyz_t collision_vec;
s16 radius;
s16 height;
s16 offset;
u8 weight;
u8 hp;
u8 damage;
u8 damage_effect;
u8 at_hit_effect;
u8 ac_hit_effect;
} Status_c;
typedef struct status_data_s {
u8 health;
s16 radius;
s16 height;
s16 offset;
u8 weight;
} StatusData_c;
typedef struct mco_work_s {
int count;
ClObj_c* colliders[10];
} McoWork;
extern McoWork mco_work;
typedef void (*CollisionOCFunction)(GAME*, CollisionCheck_c*, ClObj_c*, ClObj_c*);
typedef int (*CollisionOCClear)(GAME*, ClObj_c*);
typedef int (*CollisionClearFunction)(GAME*, ClObj_c*);
extern void CollisionCheck_workTrisElemCenter(ClObjTrisElem_c*, xyz_t*);
extern int ClObj_ct(GAME*, ClObj_c*);
extern int ClObj_dt(GAME*, ClObj_c*);
extern int ClObj_set4(GAME*, ClObj_c*, ACTOR*, ClObjData_c*);
extern void ClObj_OCClear(GAME*, ClObj_c*);
extern int ClObjElem_ct(ClObjElem_c*);
extern int ClObjElem_set(ClObjElem_c*, ClObjElemData_c*);
extern void ClObjElem_OCClear(GAME*, ClObjElem_c*);
extern int ClObjJntSphElem_OCClear(GAME*, ClObjJntSphElem_c*);
extern int ClObjJntSph_OCClear(GAME*, ClObj_c*);
extern int ClObjPipeAttr_ct(GAME*, ClObjPipeAttr_c*);
extern int ClObjPipeAttr_dt(GAME*, ClObjPipeAttr_c*);
extern int ClObjPipeAttr_set(GAME*, ClObjPipeAttr_c*, ClObjPipeAttr_c*);
extern int ClObjPipe_ct(GAME*, ClObjPipe_c*);
extern int ClObjPipe_dt(GAME*, ClObjPipe_c*);
extern int ClObjPipe_set5(GAME*, ClObjPipe_c*, ACTOR*, ClObjPipeData_c*);
extern int ClObjPipe_OCClear(GAME*, ClObj_c*);
extern int ClObjTrisElemAttr_ct(GAME*, ClObjTrisElemAttr_c*);
extern int ClObjTrisElemAttr_dt(GAME*, ClObjTrisElemAttr_c*);
extern int ClObjTrisElemAttr_set(GAME*, ClObjTrisElemAttr_c*, ClObjTrisElemAttrData_c*);
extern int ClObjTrisElem_ct(GAME*, ClObjTrisElem_c*);
extern int ClObjTrisElem_dt(GAME*, ClObjTrisElem_c*);
extern int ClObjTrisElem_set(GAME*, ClObjTrisElem_c*, ClObjTrisElemData_c*);
extern int ClObjTrisElem_OCClear(GAME*, ClObjTrisElem_c*);
extern int ClObjTris_ct(GAME*, ClObjTris_c*);
extern int ClObjTris_dt_nzf(GAME*, ClObjTris_c*);
extern int ClObjTris_set5_nzm(GAME*, ClObjTris_c*, ACTOR*, ClObjTrisData_c*, ClObjTrisElem_c*);
extern int ClObjTris_OCClear(GAME*, ClObj_c*);
extern void CollisionCheck_ct(GAME*, CollisionCheck_c*);
extern void CollisionCheck_dt(GAME*, CollisionCheck_c*);
extern void CollisionCheck_clear(GAME*, CollisionCheck_c*);
extern int CollisionCheck_setOC(GAME*, CollisionCheck_c*, ClObj_c*);
extern int get_type(u8);
extern void CollisionCheck_setOC_HitInfo(ClObj_c*, ClObjElem_c*, xyz_t*, ClObj_c*, ClObjElem_c*, xyz_t*, f32);
extern void CollisionCheck_OC_JntSph_Vs_JntSph(GAME*, CollisionCheck_c*, ClObj_c*, ClObj_c*);
extern void CollisionCheck_OC_JntSph_Vs_Pipe(GAME*, CollisionCheck_c*, ClObj_c*, ClObj_c*);
extern void CollisionCheck_OC_Pipe_Vs_JntSph(GAME*, CollisionCheck_c*, ClObj_c*, ClObj_c*);
extern void CollisionCheck_OC_Pipe_Vs_Pipe(GAME*, CollisionCheck_c*, ClObj_c*, ClObj_c*);
extern int CollisionCheck_Check1ClObjNoOC(ClObj_c*);
extern int CollisionCheck_Check2ClObjNoOC(ClObj_c*, ClObj_c*);
extern void CollisionCheck_OC(GAME*, CollisionCheck_c*);
extern void CollisionCheck_setOCC_HitInfo(GAME*, ClObj_c*, ClObjTrisElem_c*, xyz_t*, ClObj_c*, ClObjElem_c*, xyz_t*,
xyz_t*);
extern void CollisionCheck_OCC_Tris_Vs_JntSph(GAME*, CollisionCheck_c*, ClObjTris_c*, ClObjJntSph_c*);
extern void CollisionCheck_OCC_Tris_Vs_Pipe(GAME*, CollisionCheck_c*, ClObjTris_c*, ClObjPipe_c*);
extern int CollisionCheck_Check1ClObjNoOCC(ClObj_c*);
extern void CollisionCheck_OCC(GAME*, CollisionCheck_c*);
extern int ClObjTrisElem_OCCClear(GAME*, ClObjTrisElem_c*);
extern int ClObj_OCCClear(GAME*, ClObj_c*);
extern int ClObjTris_OCCClear(GAME*, ClObj_c*);
extern int CollisionCheck_setOCC(GAME*, CollisionCheck_c*, ClObj_c*);
extern void CollisionCheck_Status_ct(Status_c*);
extern void CollisionCheck_Status_Clear(Status_c*);
extern void CollisionCheck_Status_set3(Status_c*, StatusData_c*);
extern int CollisionCheck_Uty_ActorWorldPosSetPipeC(ACTOR*, ClObjPipe_c*);
typedef struct actor_dlftbl_s {
u32 rom_start;
u32 rom_end;
u8* ram_start;
u8* ram_end;
u8* alloc_buf;
ACTOR_PROFILE* profile;
int unk;
u16 flags;
s8 num_actors;
s8 unk2;
} ACTOR_DLFTBL;
extern int actor_dlftbls_num;
extern ACTOR_DLFTBL actor_dlftbls[];
extern void actor_dlftbls_init();
extern void actor_dlftbls_cleanup();
typedef void (*mActor_proc)(ACTOR*, GAME*);
typedef enum bank_id {
ACTOR_OBJ_BANK_NONE,
ACTOR_OBJ_BANK_1,
ACTOR_OBJ_BANK_2,
ACTOR_OBJ_BANK_KEEP,
ACTOR_OBJ_BANK_BGITEM,
ACTOR_OBJ_BANK_ROOM_SUNSHINE,
ACTOR_OBJ_BANK_6,
ACTOR_OBJ_BANK_AIRPLANE,
ACTOR_OBJ_BANK_8,
ACTOR_OBJ_BANK_9,
ACTOR_OBJ_BANK_10,
ACTOR_OBJ_BANK_TRAINDOOR,
ACTOR_OBJ_BANK_12,
ACTOR_OBJ_BANK_13,
ACTOR_OBJ_BANK_14,
ACTOR_OBJ_BANK_15,
ACTOR_OBJ_BANK_TOOLS,
ACTOR_OBJ_BANK_17,
ACTOR_OBJ_BANK_18,
ACTOR_OBJ_BANK_19,
ACTOR_OBJ_BANK_20,
ACTOR_OBJ_BANK_21,
ACTOR_OBJ_BANK_KAMAKURA_INDOOR,
ACTOR_OBJ_BANK_23,
ACTOR_OBJ_BANK_24,
ACTOR_OBJ_BANK_PSNOWMAN,
ACTOR_OBJ_BANK_26,
ACTOR_OBJ_BANK_27,
ACTOR_OBJ_BANK_UMBRELLA,
ACTOR_OBJ_BANK_29,
ACTOR_OBJ_BANK_SHOP_GOODS,
ACTOR_OBJ_BANK_31,
ACTOR_OBJ_BANK_32,
ACTOR_OBJ_BANK_33,
ACTOR_OBJ_BANK_34,
ACTOR_OBJ_BANK_35,
ACTOR_OBJ_BANK_BG_CHERRY_ITEM,
ACTOR_OBJ_BANK_BG_WINTER_ITEM,
ACTOR_OBJ_BANK_BG_XMAS_ITEM,
ACTOR_OBJ_BANK_39,
ACTOR_OBJ_BANK_40,
ACTOR_OBJ_BANK_TRAINWINDOW,
ACTOR_OBJ_BANK_42,
ACTOR_OBJ_BANK_POSTHOUSE,
ACTOR_OBJ_BANK_EF_POLICE,
ACTOR_OBJ_BANK_KEITAI,
ACTOR_OBJ_BANK_46,
ACTOR_OBJ_BANK_47,
ACTOR_OBJ_BANK_UKI,
ACTOR_OBJ_BANK_49,
ACTOR_OBJ_BANK_50,
ACTOR_OBJ_BANK_51,
ACTOR_OBJ_BANK_52,
ACTOR_OBJ_BANK_HANABI,
ACTOR_OBJ_BANK_54,
ACTOR_OBJ_BANK_55,
ACTOR_OBJ_BANK_56,
ACTOR_OBJ_BANK_57,
ACTOR_OBJ_BANK_58,
ACTOR_OBJ_BANK_59,
ACTOR_OBJ_BANK_60,
ACTOR_OBJ_BANK_61,
ACTOR_OBJ_BANK_62,
ACTOR_OBJ_BANK_63,
ACTOR_OBJ_BANK_64,
ACTOR_OBJ_BANK_65,
ACTOR_OBJ_BANK_66,
ACTOR_OBJ_BANK_67,
ACTOR_OBJ_BANK_68,
ACTOR_OBJ_BANK_69,
ACTOR_OBJ_BANK_70,
ACTOR_OBJ_BANK_71,
ACTOR_OBJ_BANK_72,
ACTOR_OBJ_BANK_73,
ACTOR_OBJ_BANK_74,
ACTOR_OBJ_BANK_75,
ACTOR_OBJ_BANK_76,
ACTOR_OBJ_BANK_77,
ACTOR_OBJ_BANK_78,
ACTOR_OBJ_BANK_79,
ACTOR_OBJ_BANK_80,
ACTOR_OBJ_BANK_81,
ACTOR_OBJ_BANK_82,
ACTOR_OBJ_BANK_83,
ACTOR_OBJ_BANK_84,
ACTOR_OBJ_BANK_85,
ACTOR_OBJ_BANK_86,
ACTOR_OBJ_BANK_87,
ACTOR_OBJ_BANK_88,
ACTOR_OBJ_BANK_89,
ACTOR_OBJ_BANK_90,
ACTOR_OBJ_BANK_91,
ACTOR_OBJ_BANK_92,
ACTOR_OBJ_BANK_93,
ACTOR_OBJ_BANK_94,
ACTOR_OBJ_BANK_95,
ACTOR_OBJ_BANK_96,
ACTOR_OBJ_BANK_97,
ACTOR_OBJ_BANK_98,
ACTOR_OBJ_BANK_99,
ACTOR_OBJ_BANK_100,
ACTOR_OBJ_BANK_101,
ACTOR_OBJ_BANK_102,
ACTOR_OBJ_BANK_103,
ACTOR_OBJ_BANK_104,
ACTOR_OBJ_BANK_105,
ACTOR_OBJ_BANK_106,
ACTOR_OBJ_BANK_107,
ACTOR_OBJ_BANK_108,
ACTOR_OBJ_BANK_109,
ACTOR_OBJ_BANK_110,
ACTOR_OBJ_BANK_111,
ACTOR_OBJ_BANK_112,
ACTOR_OBJ_BANK_113,
ACTOR_OBJ_BANK_114,
ACTOR_OBJ_BANK_115,
ACTOR_OBJ_BANK_116,
ACTOR_OBJ_BANK_117,
ACTOR_OBJ_BANK_118,
ACTOR_OBJ_BANK_119,
ACTOR_OBJ_BANK_120,
ACTOR_OBJ_BANK_121,
ACTOR_OBJ_BANK_122,
ACTOR_OBJ_BANK_123,
ACTOR_OBJ_BANK_124,
ACTOR_OBJ_BANK_125,
ACTOR_OBJ_BANK_126,
ACTOR_OBJ_BANK_127,
ACTOR_OBJ_BANK_128,
ACTOR_OBJ_BANK_129,
ACTOR_OBJ_BANK_130,
ACTOR_OBJ_BANK_131,
ACTOR_OBJ_BANK_132,
ACTOR_OBJ_BANK_133,
ACTOR_OBJ_BANK_134,
ACTOR_OBJ_BANK_135,
ACTOR_OBJ_BANK_136,
ACTOR_OBJ_BANK_137,
ACTOR_OBJ_BANK_138,
ACTOR_OBJ_BANK_139,
ACTOR_OBJ_BANK_140,
ACTOR_OBJ_BANK_141,
ACTOR_OBJ_BANK_142,
ACTOR_OBJ_BANK_143,
ACTOR_OBJ_BANK_144,
ACTOR_OBJ_BANK_145,
ACTOR_OBJ_BANK_146,
ACTOR_OBJ_BANK_147,
ACTOR_OBJ_BANK_148,
ACTOR_OBJ_BANK_149,
ACTOR_OBJ_BANK_150,
ACTOR_OBJ_BANK_151,
ACTOR_OBJ_BANK_152,
ACTOR_OBJ_BANK_153,
ACTOR_OBJ_BANK_154,
ACTOR_OBJ_BANK_155,
ACTOR_OBJ_BANK_156,
ACTOR_OBJ_BANK_157,
ACTOR_OBJ_BANK_158,
ACTOR_OBJ_BANK_159,
ACTOR_OBJ_BANK_160,
ACTOR_OBJ_BANK_161,
ACTOR_OBJ_BANK_162,
ACTOR_OBJ_BANK_163,
ACTOR_OBJ_BANK_164,
ACTOR_OBJ_BANK_165,
ACTOR_OBJ_BANK_166,
ACTOR_OBJ_BANK_167,
ACTOR_OBJ_BANK_168,
ACTOR_OBJ_BANK_169,
ACTOR_OBJ_BANK_170,
ACTOR_OBJ_BANK_171,
ACTOR_OBJ_BANK_172,
ACTOR_OBJ_BANK_173,
ACTOR_OBJ_BANK_174,
ACTOR_OBJ_BANK_175,
ACTOR_OBJ_BANK_176,
ACTOR_OBJ_BANK_177,
ACTOR_OBJ_BANK_178,
ACTOR_OBJ_BANK_179,
ACTOR_OBJ_BANK_180,
ACTOR_OBJ_BANK_181,
ACTOR_OBJ_BANK_182,
ACTOR_OBJ_BANK_183,
ACTOR_OBJ_BANK_184,
ACTOR_OBJ_BANK_185,
ACTOR_OBJ_BANK_186,
ACTOR_OBJ_BANK_187,
ACTOR_OBJ_BANK_188,
ACTOR_OBJ_BANK_189,
ACTOR_OBJ_BANK_190,
ACTOR_OBJ_BANK_191,
ACTOR_OBJ_BANK_192,
ACTOR_OBJ_BANK_193,
ACTOR_OBJ_BANK_194,
ACTOR_OBJ_BANK_195,
ACTOR_OBJ_BANK_196,
ACTOR_OBJ_BANK_197,
ACTOR_OBJ_BANK_198,
ACTOR_OBJ_BANK_199,
ACTOR_OBJ_BANK_200,
ACTOR_OBJ_BANK_201,
ACTOR_OBJ_BANK_202,
ACTOR_OBJ_BANK_203,
ACTOR_OBJ_BANK_204,
ACTOR_OBJ_BANK_205,
ACTOR_OBJ_BANK_206,
ACTOR_OBJ_BANK_207,
ACTOR_OBJ_BANK_208,
ACTOR_OBJ_BANK_209,
ACTOR_OBJ_BANK_210,
ACTOR_OBJ_BANK_211,
ACTOR_OBJ_BANK_212,
ACTOR_OBJ_BANK_213,
ACTOR_OBJ_BANK_214,
ACTOR_OBJ_BANK_215,
ACTOR_OBJ_BANK_216,
ACTOR_OBJ_BANK_217,
ACTOR_OBJ_BANK_218,
ACTOR_OBJ_BANK_219,
ACTOR_OBJ_BANK_220,
ACTOR_OBJ_BANK_221,
ACTOR_OBJ_BANK_222,
ACTOR_OBJ_BANK_223,
ACTOR_OBJ_BANK_224,
ACTOR_OBJ_BANK_225,
ACTOR_OBJ_BANK_226,
ACTOR_OBJ_BANK_227,
ACTOR_OBJ_BANK_228,
ACTOR_OBJ_BANK_229,
ACTOR_OBJ_BANK_230,
ACTOR_OBJ_BANK_231,
ACTOR_OBJ_BANK_232,
ACTOR_OBJ_BANK_233,
ACTOR_OBJ_BANK_234,
ACTOR_OBJ_BANK_235,
ACTOR_OBJ_BANK_236,
ACTOR_OBJ_BANK_237,
ACTOR_OBJ_BANK_238,
ACTOR_OBJ_BANK_239,
ACTOR_OBJ_BANK_240,
ACTOR_OBJ_BANK_241,
ACTOR_OBJ_BANK_242,
ACTOR_OBJ_BANK_243,
ACTOR_OBJ_BANK_244,
ACTOR_OBJ_BANK_245,
ACTOR_OBJ_BANK_246,
ACTOR_OBJ_BANK_247,
ACTOR_OBJ_BANK_248,
ACTOR_OBJ_BANK_249,
ACTOR_OBJ_BANK_250,
ACTOR_OBJ_BANK_251,
ACTOR_OBJ_BANK_252,
ACTOR_OBJ_BANK_253,
ACTOR_OBJ_BANK_254,
ACTOR_OBJ_BANK_255,
ACTOR_OBJ_BANK_256,
ACTOR_OBJ_BANK_257,
ACTOR_OBJ_BANK_258,
ACTOR_OBJ_BANK_259,
ACTOR_OBJ_BANK_260,
ACTOR_OBJ_BANK_261,
ACTOR_OBJ_BANK_262,
ACTOR_OBJ_BANK_263,
ACTOR_OBJ_BANK_264,
ACTOR_OBJ_BANK_265,
ACTOR_OBJ_BANK_266,
ACTOR_OBJ_BANK_267,
ACTOR_OBJ_BANK_268,
ACTOR_OBJ_BANK_269,
ACTOR_OBJ_BANK_270,
ACTOR_OBJ_BANK_271,
ACTOR_OBJ_BANK_272,
ACTOR_OBJ_BANK_273,
ACTOR_OBJ_BANK_274,
ACTOR_OBJ_BANK_275,
ACTOR_OBJ_BANK_276,
ACTOR_OBJ_BANK_277,
ACTOR_OBJ_BANK_278,
ACTOR_OBJ_BANK_279,
ACTOR_OBJ_BANK_280,
ACTOR_OBJ_BANK_281,
ACTOR_OBJ_BANK_282,
ACTOR_OBJ_BANK_283,
ACTOR_OBJ_BANK_284,
ACTOR_OBJ_BANK_285,
ACTOR_OBJ_BANK_286,
ACTOR_OBJ_BANK_287,
ACTOR_OBJ_BANK_288,
ACTOR_OBJ_BANK_289,
ACTOR_OBJ_BANK_290,
ACTOR_OBJ_BANK_291,
ACTOR_OBJ_BANK_292,
ACTOR_OBJ_BANK_293,
ACTOR_OBJ_BANK_294,
ACTOR_OBJ_BANK_295,
ACTOR_OBJ_BANK_296,
ACTOR_OBJ_BANK_297,
ACTOR_OBJ_BANK_298,
ACTOR_OBJ_BANK_299,
ACTOR_OBJ_BANK_300,
ACTOR_OBJ_BANK_301,
ACTOR_OBJ_BANK_302,
ACTOR_OBJ_BANK_303,
ACTOR_OBJ_BANK_304,
ACTOR_OBJ_BANK_305,
ACTOR_OBJ_BANK_306,
ACTOR_OBJ_BANK_307,
ACTOR_OBJ_BANK_308,
ACTOR_OBJ_BANK_309,
ACTOR_OBJ_BANK_310,
ACTOR_OBJ_BANK_311,
ACTOR_OBJ_BANK_312,
ACTOR_OBJ_BANK_313,
ACTOR_OBJ_BANK_314,
ACTOR_OBJ_BANK_315,
ACTOR_OBJ_BANK_316,
ACTOR_OBJ_BANK_317,
ACTOR_OBJ_BANK_318,
ACTOR_OBJ_BANK_319,
ACTOR_OBJ_BANK_320,
ACTOR_OBJ_BANK_321,
ACTOR_OBJ_BANK_322,
ACTOR_OBJ_BANK_323,
ACTOR_OBJ_BANK_324,
ACTOR_OBJ_BANK_325,
ACTOR_OBJ_BANK_326,
ACTOR_OBJ_BANK_327,
ACTOR_OBJ_BANK_328,
ACTOR_OBJ_BANK_329,
ACTOR_OBJ_BANK_330,
ACTOR_OBJ_BANK_331,
ACTOR_OBJ_BANK_332,
ACTOR_OBJ_BANK_333,
ACTOR_OBJ_BANK_334,
ACTOR_OBJ_BANK_335,
ACTOR_OBJ_BANK_336,
ACTOR_OBJ_BANK_337,
ACTOR_OBJ_BANK_338,
ACTOR_OBJ_BANK_339,
ACTOR_OBJ_BANK_340,
ACTOR_OBJ_BANK_341,
ACTOR_OBJ_BANK_342,
ACTOR_OBJ_BANK_343,
ACTOR_OBJ_BANK_344,
ACTOR_OBJ_BANK_345,
ACTOR_OBJ_BANK_346,
ACTOR_OBJ_BANK_347,
ACTOR_OBJ_BANK_348,
ACTOR_OBJ_BANK_349,
ACTOR_OBJ_BANK_350,
ACTOR_OBJ_BANK_351,
ACTOR_OBJ_BANK_352,
ACTOR_OBJ_BANK_353,
ACTOR_OBJ_BANK_354,
ACTOR_OBJ_BANK_355,
ACTOR_OBJ_BANK_356,
ACTOR_OBJ_BANK_357,
ACTOR_OBJ_BANK_358,
ACTOR_OBJ_BANK_359,
ACTOR_OBJ_BANK_360,
ACTOR_OBJ_BANK_361,
ACTOR_OBJ_BANK_362,
ACTOR_OBJ_BANK_363,
ACTOR_OBJ_BANK_364,
ACTOR_OBJ_BANK_365,
ACTOR_OBJ_BANK_366,
ACTOR_OBJ_BANK_367,
ACTOR_OBJ_BANK_368,
ACTOR_OBJ_BANK_HOUSE_GOKI,
ACTOR_OBJ_BANK_NPC_SAO,
ACTOR_OBJ_BANK_TUMBLER,
ACTOR_OBJ_BANK_372,
ACTOR_OBJ_BANK_373,
ACTOR_OBJ_BANK_374,
ACTOR_OBJ_BANK_375,
ACTOR_OBJ_BANK_376,
ACTOR_OBJ_BANK_377,
ACTOR_OBJ_BANK_378,
ACTOR_OBJ_BANK_379,
ACTOR_OBJ_BANK_380,
ACTOR_OBJ_BANK_381,
ACTOR_OBJ_BANK_382,
ACTOR_OBJ_BANK_383,
ACTOR_OBJ_BANK_384,
ACTOR_OBJ_BANK_385,
ACTOR_OBJ_BANK_386,
ACTOR_OBJ_BANK_387,
ACTOR_OBJ_BANK_388,
ACTOR_OBJ_BANK_389,
ACTOR_OBJ_BANK_390,
ACTOR_OBJ_BANK_TAMA,
ACTOR_OBJ_BANK_BEE,
ACTOR_OBJ_BANK_393,
ACTOR_OBJ_BANK_ROPE,
ACTOR_OBJ_BANK_CRACKER,
ACTOR_OBJ_BANK_396,
ACTOR_OBJ_BANK_397,
ACTOR_OBJ_BANK_398,
ACTOR_OBJ_BANK_399,
ACTOR_OBJ_BANK_FUUSEN,
ACTOR_OBJ_BANK_401,
ACTOR_OBJ_BANK_402,
ACTOR_OBJ_BANK_403,
ACTOR_OBJ_BANK_404,
ACTOR_OBJ_BANK_MUSEUM_PICTURE,
ACTOR_OBJ_BANK_406,
ACTOR_OBJ_BANK_407,
ACTOR_OBJ_BANK_408,
ACTOR_OBJ_BANK_EF_MUSEUM,
ACTOR_OBJ_BANK_EF_MINSECT,
ACTOR_OBJ_BANK_AC_SIGN,
ACTOR_OBJ_BANK_MURAL,
ACTOR_OBJ_BANK_ANT,
ACTOR_OBJ_BANK_414,
ACTOR_OBJ_BANK_415,
ACTOR_OBJ_BANK_416,
ACTOR_OBJ_BANK_417,
ACTOR_OBJ_BANK_418,
ACTOR_OBJ_BANK_419,
ACTOR_OBJ_BANK_420,
ACTOR_OBJ_BANK_421,
ACTOR_OBJ_BANK_422,
ACTOR_OBJ_BANK_423,
ACTOR_OBJ_BANK_424,
ACTOR_OBJ_BANK_425,
ACTOR_OBJ_BANK_426,
ACTOR_OBJ_BANK_427,
ACTOR_OBJ_BANK_428,
ACTOR_OBJ_BANK_429,
ACTOR_OBJ_BANK_430,
ACTOR_OBJ_BANK_431,
ACTOR_OBJ_BANK_432,
ACTOR_OBJ_BANK_433,
ACTOR_OBJ_BANK_434,
ACTOR_OBJ_BANK_435,
ACTOR_OBJ_BANK_436,
ACTOR_OBJ_BANK_437,
ACTOR_OBJ_BANK_438,
ACTOR_OBJ_BANK_439,
ACTOR_OBJ_BANK_440,
ACTOR_OBJ_BANK_441,
ACTOR_OBJ_BANK_442,
ACTOR_OBJ_BANK_443,
ACTOR_OBJ_BANK_444,
ACTOR_OBJ_BANK_445,
ACTOR_OBJ_BANK_446,
ACTOR_OBJ_BANK_447,
ACTOR_OBJ_BANK_448,
ACTOR_OBJ_BANK_449,
ACTOR_OBJ_BANK_450,
ACTOR_OBJ_BANK_451,
ACTOR_OBJ_BANK_452,
ACTOR_OBJ_BANK_453,
ACTOR_OBJ_BANK_454,
ACTOR_OBJ_BANK_455,
ACTOR_OBJ_BANK_456,
ACTOR_OBJ_BANK_457,
ACTOR_OBJ_BANK_458,
ACTOR_OBJ_BANK_459,
ACTOR_OBJ_BANK_460,
ACTOR_OBJ_BANK_461,
ACTOR_OBJ_BANK_462,
ACTOR_OBJ_BANK_463,
ACTOR_OBJ_BANK_464,
ACTOR_OBJ_BANK_465,
ACTOR_OBJ_BANK_466,
ACTOR_OBJ_BANK_467,
ACTOR_OBJ_BANK_468,
ACTOR_OBJ_BANK_469,
ACTOR_OBJ_BANK_470,
ACTOR_OBJ_BANK_471,
ACTOR_OBJ_BANK_472,
ACTOR_OBJ_BANK_473,
ACTOR_OBJ_BANK_474,
ACTOR_OBJ_BANK_475,
ACTOR_OBJ_BANK_476,
ACTOR_OBJ_BANK_477,
ACTOR_OBJ_BANK_478,
ACTOR_OBJ_BANK_479,
ACTOR_OBJ_BANK_480,
ACTOR_OBJ_BANK_481,
ACTOR_OBJ_BANK_482,
ACTOR_OBJ_BANK_483,
ACTOR_OBJ_BANK_484,
ACTOR_OBJ_BANK_485,
ACTOR_OBJ_BANK_486,
ACTOR_OBJ_BANK_487,
ACTOR_OBJ_BANK_488,
ACTOR_OBJ_BANK_489,
ACTOR_OBJ_BANK_490,
ACTOR_OBJ_BANK_491,
ACTOR_OBJ_BANK_492,
ACTOR_OBJ_BANK_493,
ACTOR_OBJ_BANK_494,
ACTOR_OBJ_BANK_495,
ACTOR_OBJ_BANK_496,
ACTOR_OBJ_BANK_497,
ACTOR_OBJ_BANK_498,
ACTOR_OBJ_BANK_499,
ACTOR_OBJ_BANK_500,
ACTOR_OBJ_BANK_501,
ACTOR_OBJ_BANK_502,
ACTOR_OBJ_BANK_503,
ACTOR_OBJ_BANK_504,
ACTOR_OBJ_BANK_505,
ACTOR_OBJ_BANK_506,
ACTOR_OBJ_BANK_507,
ACTOR_OBJ_BANK_508,
ACTOR_OBJ_BANK_509,
ACTOR_OBJ_BANK_510,
ACTOR_OBJ_BANK_511,
ACTOR_OBJ_BANK_512,
ACTOR_OBJ_BANK_513,
ACTOR_OBJ_BANK_514,
ACTOR_OBJ_BANK_515,
ACTOR_OBJ_BANK_516,
ACTOR_OBJ_BANK_517,
ACTOR_OBJ_BANK_518,
ACTOR_OBJ_BANK_519,
ACTOR_OBJ_BANK_520,
ACTOR_OBJ_BANK_521,
ACTOR_OBJ_BANK_522,
ACTOR_OBJ_BANK_523,
ACTOR_OBJ_BANK_524,
ACTOR_OBJ_BANK_525,
ACTOR_OBJ_BANK_526,
ACTOR_OBJ_BANK_527,
ACTOR_OBJ_BANK_528,
ACTOR_OBJ_BANK_529,
ACTOR_OBJ_BANK_530,
ACTOR_OBJ_BANK_531,
ACTOR_OBJ_BANK_532,
ACTOR_OBJ_BANK_533,
ACTOR_OBJ_BANK_534,
ACTOR_OBJ_BANK_535,
ACTOR_OBJ_BANK_536,
ACTOR_OBJ_BANK_537,
ACTOR_OBJ_BANK_538,
ACTOR_OBJ_BANK_539,
ACTOR_OBJ_BANK_540,
ACTOR_OBJ_BANK_541,
ACTOR_OBJ_BANK_542,
ACTOR_OBJ_BANK_543,
ACTOR_OBJ_BANK_544,
ACTOR_OBJ_BANK_545,
ACTOR_OBJ_BANK_546,
ACTOR_OBJ_BANK_547,
ACTOR_OBJ_BANK_548,
ACTOR_OBJ_BANK_549,
ACTOR_OBJ_BANK_550,
ACTOR_OBJ_BANK_551,
ACTOR_OBJ_BANK_552,
ACTOR_OBJ_BANK_553,
ACTOR_OBJ_BANK_554,
ACTOR_OBJ_BANK_555,
ACTOR_OBJ_BANK_556,
ACTOR_OBJ_BANK_557,
ACTOR_OBJ_BANK_558,
ACTOR_OBJ_BANK_559,
ACTOR_OBJ_BANK_560,
ACTOR_OBJ_BANK_561,
ACTOR_OBJ_BANK_562,
ACTOR_OBJ_BANK_563,
ACTOR_OBJ_BANK_564,
ACTOR_OBJ_BANK_565,
ACTOR_OBJ_BANK_566,
ACTOR_OBJ_BANK_567,
ACTOR_OBJ_BANK_568,
ACTOR_OBJ_BANK_569,
ACTOR_OBJ_BANK_570,
ACTOR_OBJ_BANK_571,
ACTOR_OBJ_BANK_572,
ACTOR_OBJ_BANK_573,
ACTOR_OBJ_BANK_574,
ACTOR_OBJ_BANK_575,
ACTOR_OBJ_BANK_576,
ACTOR_OBJ_BANK_577,
ACTOR_OBJ_BANK_578,
ACTOR_OBJ_BANK_579,
ACTOR_OBJ_BANK_580,
ACTOR_OBJ_BANK_581,
ACTOR_OBJ_BANK_582,
ACTOR_OBJ_BANK_583,
ACTOR_OBJ_BANK_584,
ACTOR_OBJ_BANK_585,
ACTOR_OBJ_BANK_586,
ACTOR_OBJ_BANK_587,
ACTOR_OBJ_BANK_588,
ACTOR_OBJ_BANK_589,
ACTOR_OBJ_BANK_590,
ACTOR_OBJ_BANK_591,
ACTOR_OBJ_BANK_592,
ACTOR_OBJ_BANK_593,
ACTOR_OBJ_BANK_594,
ACTOR_OBJ_BANK_595,
ACTOR_OBJ_BANK_596,
ACTOR_OBJ_BANK_597,
ACTOR_OBJ_BANK_598,
ACTOR_OBJ_BANK_599,
ACTOR_OBJ_BANK_600,
ACTOR_OBJ_BANK_601,
ACTOR_OBJ_BANK_602,
ACTOR_OBJ_BANK_603,
ACTOR_OBJ_BANK_604,
ACTOR_OBJ_BANK_605,
ACTOR_OBJ_BANK_606,
ACTOR_OBJ_BANK_607,
ACTOR_OBJ_BANK_608,
ACTOR_OBJ_BANK_609,
ACTOR_OBJ_BANK_610,
ACTOR_OBJ_BANK_611,
ACTOR_OBJ_BANK_612,
ACTOR_OBJ_BANK_613,
ACTOR_OBJ_BANK_614,
ACTOR_OBJ_BANK_615,
ACTOR_OBJ_BANK_616,
ACTOR_OBJ_BANK_617,
ACTOR_OBJ_BANK_618,
ACTOR_OBJ_BANK_619,
ACTOR_OBJ_BANK_620,
ACTOR_OBJ_BANK_621,
ACTOR_OBJ_BANK_622,
ACTOR_OBJ_BANK_623,
ACTOR_OBJ_BANK_624,
ACTOR_OBJ_BANK_625,
ACTOR_OBJ_BANK_626,
ACTOR_OBJ_BANK_627,
ACTOR_OBJ_BANK_628,
ACTOR_OBJ_BANK_629,
ACTOR_OBJ_BANK_630,
ACTOR_OBJ_BANK_631,
ACTOR_OBJ_BANK_632,
ACTOR_OBJ_BANK_633,
ACTOR_OBJ_BANK_634,
ACTOR_OBJ_BANK_635,
ACTOR_OBJ_BANK_636,
ACTOR_OBJ_BANK_637,
ACTOR_OBJ_BANK_638,
ACTOR_OBJ_BANK_639,
ACTOR_OBJ_BANK_640,
ACTOR_OBJ_BANK_641,
ACTOR_OBJ_BANK_642,
ACTOR_OBJ_BANK_643,
ACTOR_OBJ_BANK_644,
ACTOR_OBJ_BANK_645,
ACTOR_OBJ_BANK_646,
ACTOR_OBJ_BANK_647,
ACTOR_OBJ_BANK_648,
ACTOR_OBJ_BANK_649,
ACTOR_OBJ_BANK_650,
ACTOR_OBJ_BANK_651,
ACTOR_OBJ_BANK_652,
ACTOR_OBJ_BANK_653,
ACTOR_OBJ_BANK_654,
ACTOR_OBJ_BANK_655,
ACTOR_OBJ_BANK_656,
ACTOR_OBJ_BANK_657,
ACTOR_OBJ_BANK_658,
ACTOR_OBJ_BANK_659,
ACTOR_OBJ_BANK_660,
ACTOR_OBJ_BANK_661,
ACTOR_OBJ_BANK_662,
ACTOR_OBJ_BANK_663,
ACTOR_OBJ_BANK_664,
ACTOR_OBJ_BANK_665,
ACTOR_OBJ_BANK_666,
ACTOR_OBJ_BANK_667,
ACTOR_OBJ_BANK_668,
ACTOR_OBJ_BANK_669,
ACTOR_OBJ_BANK_670,
ACTOR_OBJ_BANK_671,
ACTOR_OBJ_BANK_672,
ACTOR_OBJ_BANK_673,
ACTOR_OBJ_BANK_674,
ACTOR_OBJ_BANK_675,
ACTOR_OBJ_BANK_676,
ACTOR_OBJ_BANK_677,
ACTOR_OBJ_BANK_678,
ACTOR_OBJ_BANK_679,
ACTOR_OBJ_BANK_680,
ACTOR_OBJ_BANK_681,
ACTOR_OBJ_BANK_682,
ACTOR_OBJ_BANK_683,
ACTOR_OBJ_BANK_684,
ACTOR_OBJ_BANK_685,
ACTOR_OBJ_BANK_686,
ACTOR_OBJ_BANK_687,
ACTOR_OBJ_BANK_688,
ACTOR_OBJ_BANK_689,
ACTOR_OBJ_BANK_690,
ACTOR_OBJ_BANK_691,
ACTOR_OBJ_BANK_692,
ACTOR_OBJ_BANK_693,
ACTOR_OBJ_BANK_694,
ACTOR_OBJ_BANK_695,
ACTOR_OBJ_BANK_696,
ACTOR_OBJ_BANK_697,
ACTOR_OBJ_BANK_698,
ACTOR_OBJ_BANK_699,
ACTOR_OBJ_BANK_700,
ACTOR_OBJ_BANK_701,
ACTOR_OBJ_BANK_702,
ACTOR_OBJ_BANK_703,
ACTOR_OBJ_BANK_704,
ACTOR_OBJ_BANK_705,
ACTOR_OBJ_BANK_706,
ACTOR_OBJ_BANK_707,
ACTOR_OBJ_BANK_708,
ACTOR_OBJ_BANK_709,
ACTOR_OBJ_BANK_710,
ACTOR_OBJ_BANK_711,
ACTOR_OBJ_BANK_712,
ACTOR_OBJ_BANK_713,
ACTOR_OBJ_BANK_714,
ACTOR_OBJ_BANK_715,
ACTOR_OBJ_BANK_716,
ACTOR_OBJ_BANK_717,
ACTOR_OBJ_BANK_718,
ACTOR_OBJ_BANK_719,
ACTOR_OBJ_BANK_720,
ACTOR_OBJ_BANK_721,
ACTOR_OBJ_BANK_722,
ACTOR_OBJ_BANK_723,
ACTOR_OBJ_BANK_724,
ACTOR_OBJ_BANK_725,
ACTOR_OBJ_BANK_726,
ACTOR_OBJ_BANK_727,
ACTOR_OBJ_BANK_728,
ACTOR_OBJ_BANK_729,
ACTOR_OBJ_BANK_730,
ACTOR_OBJ_BANK_731,
};
enum actor_part {
ACTOR_PART_FG,
ACTOR_PART_ITEM,
ACTOR_PART_UNUSED,
ACTOR_PART_PLAYER,
ACTOR_PART_NPC,
ACTOR_PART_BG,
ACTOR_PART_EFFECT,
ACTOR_PART_CONTROL,
ACTOR_PART_NUM
};
enum actor_profile_table {
mAc_PROFILE_PLAYER,
mAc_PROFILE_BGITEM,
mAc_PROFILE_SAMPLE,
mAc_PROFILE_FIELDM_DRAW,
mAc_PROFILE_FIELD_DRAW,
mAc_PROFILE_AIRPLANE,
mAc_PROFILE_ROOM_SUNSHINE,
mAc_PROFILE_LAMP_LIGHT,
mAc_PROFILE_EV_ANGLER,
mAc_PROFILE_BALL,
mAc_PROFILE_HANIWA,
mAc_PROFILE_MY_ROOM,
mAc_PROFILE_MBG,
mAc_PROFILE_T_TAMA,
mAc_PROFILE_BOXMANAGER,
mAc_PROFILE_BOXMOVE,
mAc_PROFILE_BOXTRICK01,
mAc_PROFILE_ARRANGE_ROOM,
mAc_PROFILE_ARRANGE_FURNITURE,
mAc_PROFILE_TRAINDOOR,
mAc_PROFILE_T_KEITAI,
mAc_PROFILE_HALLOWEEN_NPC,
mAc_PROFILE_EV_PUMPKIN,
mAc_PROFILE_RIDE_OFF_DEMO,
mAc_PROFILE_NPC_MAMEDANUKI,
mAc_PROFILE_HANABI_NPC0,
mAc_PROFILE_HANABI_NPC1,
mAc_PROFILE_SNOWMAN,
mAc_PROFILE_NPC_POST_GIRL,
mAc_PROFILE_NPC_ENGINEER,
mAc_PROFILE_NPC_MAJIN3,
mAc_PROFILE_NPC_SLEEP_OBABA,
mAc_PROFILE_NPC,
mAc_PROFILE_EFFECT_CONTROL,
mAc_PROFILE_NPC2,
mAc_PROFILE_KAMAKURA_NPC0,
mAc_PROFILE_NPC_POST_MAN,
mAc_PROFILE_SHOP_DESIGN,
mAc_PROFILE_QUEST_MANAGER,
mAc_PROFILE_MAILBOX,
mAc_PROFILE_HOUSE,
mAc_PROFILE_SHOP_LEVEL,
mAc_PROFILE_SHOP,
mAc_PROFILE_MYHOUSE,
mAc_PROFILE_EV_ARTIST,
mAc_PROFILE_EV_BROKER,
mAc_PROFILE_EV_DESIGNER,
mAc_PROFILE_T_UMBRELLA,
mAc_PROFILE_NPC_SHOP_MASTER,
mAc_PROFILE_BIRTH_CONTROL,
mAc_PROFILE_SHOP_MANEKIN,
mAc_PROFILE_SHOP_INDOOR,
mAc_PROFILE_EVENT_MANAGER,
mAc_PROFILE_SHOP_GOODS,
mAc_PROFILE_BRSHOP,
mAc_PROFILE_WEATHER,
mAc_PROFILE_POST_OFFICE,
mAc_PROFILE_NPC_GUIDE,
mAc_PROFILE_NPC_GUIDE2,
mAc_PROFILE_INSECT,
mAc_PROFILE_STATION,
mAc_PROFILE_EV_CARPETPEDDLER,
mAc_PROFILE_EV_KABUPEDDLER,
mAc_PROFILE_RESERVE,
mAc_PROFILE_HANDOVERITEM,
mAc_PROFILE_NPC_CONV_MASTER,
mAc_PROFILE_NPC_SUPER_MASTER,
mAc_PROFILE_NPC_DEPART_MASTER,
mAc_PROFILE_TOOLS,
mAc_PROFILE_STRUCTURE,
mAc_PROFILE_EV_GYPSY,
mAc_PROFILE_NPC_POLICE,
mAc_PROFILE_TRAIN0,
mAc_PROFILE_TRAIN1,
mAc_PROFILE_NPC_STATION_MASTER,
mAc_PROFILE_EV_SANTA,
mAc_PROFILE_NPC_POLICE2,
mAc_PROFILE_POLICE_BOX,
mAc_PROFILE_BGPOLICEITEM,
mAc_PROFILE_BGCHERRYITEM,
mAc_PROFILE_BGWINTERITEM,
mAc_PROFILE_BGXMASITEM,
mAc_PROFILE_BGPOSTITEM,
mAc_PROFILE_FALLS,
mAc_PROFILE_FALLSESW,
mAc_PROFILE_EV_BROKER2,
mAc_PROFILE_BROKER_DESIGN,
mAc_PROFILE_T_UTIWA,
mAc_PROFILE_PSNOWMAN,
mAc_PROFILE_MY_INDOOR,
mAc_PROFILE_NPC_RCN_GUIDE,
mAc_PROFILE_INTRO_DEMO,
mAc_PROFILE_SHRINE,
mAc_PROFILE_BUGGY,
mAc_PROFILE_T_HANABI,
mAc_PROFILE_CONVENI,
mAc_PROFILE_SUPER,
mAc_PROFILE_DEPART,
mAc_PROFILE_HANAMI_NPC0,
mAc_PROFILE_S_CAR,
mAc_PROFILE_HANAMI_NPC1,
mAc_PROFILE_NPC_P_SEL,
mAc_PROFILE_NPC_P_SEL2,
mAc_PROFILE_NPC_RCN_GUIDE2,
mAc_PROFILE_TRAIN_WINDOW,
mAc_PROFILE_NPC_MAJIN4,
mAc_PROFILE_KAMAKURA,
mAc_PROFILE_GYOEI,
mAc_PROFILE_NPC_MAJIN,
mAc_PROFILE_T_NPCSAO,
mAc_PROFILE_EV_SONCHO,
mAc_PROFILE_UKI,
mAc_PROFILE_NPC_MAJIN2,
mAc_PROFILE_NORMAL_NPC,
mAc_PROFILE_SET_MANAGER,
mAc_PROFILE_SET_NPC_MANAGER,
mAc_PROFILE_NPC_SHOP_MASTERSP,
mAc_PROFILE_ROOM_SUNSHINE_POSTHOUSE,
mAc_PROFILE_ROOM_SUNSHINE_POLICE,
mAc_PROFILE_EFFECTBG,
mAc_PROFILE_EV_CHERRY_MANAGER,
mAc_PROFILE_EV_YOMISE,
mAc_PROFILE_TOKYOSO_NPC0,
mAc_PROFILE_TOKYOSO_NPC1,
mAc_PROFILE_GOZA,
mAc_PROFILE_RADIO,
mAc_PROFILE_YATAI,
mAc_PROFILE_TOKYOSO_CONTROL,
mAc_PROFILE_SHOP_UMBRELLA,
mAc_PROFILE_GYO_RELEASE,
mAc_PROFILE_TUKIMI,
mAc_PROFILE_KAMAKURA_INDOOR,
mAc_PROFILE_EV_MIKO,
mAc_PROFILE_GYO_KAGE,
mAc_PROFILE_MIKUJI,
mAc_PROFILE_HOUSE_GOKI,
mAc_PROFILE_T_CRACKER,
mAc_PROFILE_NPC_NEEDLEWORK,
mAc_PROFILE_T_PISTOL,
mAc_PROFILE_T_FLAG,
mAc_PROFILE_T_TUMBLER,
mAc_PROFILE_TUKIMI_NPC0,
mAc_PROFILE_TUKIMI_NPC1,
mAc_PROFILE_NEEDLEWORK_SHOP,
mAc_PROFILE_COUNTDOWN_NPC0,
mAc_PROFILE_COUNTDOWN_NPC1,
mAc_PROFILE_TURI_NPC0,
mAc_PROFILE_TAISOU_NPC0,
mAc_PROFILE_COUNT,
mAc_PROFILE_GARAGARA,
mAc_PROFILE_TAMAIRE_NPC0,
mAc_PROFILE_TAMAIRE_NPC1,
mAc_PROFILE_HATUMODE_NPC0,
mAc_PROFILE_NPC_TOTAKEKE,
mAc_PROFILE_COUNT02,
mAc_PROFILE_HATUMODE_CONTROL,
mAc_PROFILE_TAMA,
mAc_PROFILE_KAGO,
mAc_PROFILE_TURI,
mAc_PROFILE_HOUSE_CLOCK,
mAc_PROFILE_TUNAHIKI_CONTROL,
mAc_PROFILE_TUNAHIKI_NPC0,
mAc_PROFILE_TUNAHIKI_NPC1,
mAc_PROFILE_KOINOBORI,
mAc_PROFILE_BEE,
mAc_PROFILE_NAMEPLATE,
mAc_PROFILE_DUMP,
mAc_PROFILE_ROPE,
mAc_PROFILE_EV_DOZAEMON,
mAc_PROFILE_WINDMILL,
mAc_PROFILE_LOTUS,
mAc_PROFILE_ANIMAL_LOGO,
mAc_PROFILE_MIKANBOX,
mAc_PROFILE_DOUZOU,
mAc_PROFILE_NPC_RTC,
mAc_PROFILE_TOUDAI,
mAc_PROFILE_NPC_RESTART,
mAc_PROFILE_NPC_MAJIN5,
mAc_PROFILE_FUUSEN,
mAc_PROFILE_EV_DOKUTU,
mAc_PROFILE_DUMMY,
mAc_PROFILE_NPC_CURATOR,
mAc_PROFILE_MUSEUM,
mAc_PROFILE_EV_GHOST,
mAc_PROFILE_MUSEUM_PICTURE,
mAc_PROFILE_185,
mAc_PROFILE_MUSEUM_FISH,
mAc_PROFILE_MUSEUM_INSECT,
mAc_PROFILE_BRIDGE_A,
mAc_PROFILE_ROOM_SUNSHINE_MUSEUM,
mAc_PROFILE_NEEDLEWORK_INDOOR,
mAc_PROFILE_ROOM_SUNSHINE_MINSECT,
mAc_PROFILE_MUSEUM_FOSSIL,
mAc_PROFILE_MURAL,
mAc_PROFILE_AC_SIGN,
mAc_PROFILE_ANT,
mAc_PROFILE_NPC_SENDO,
mAc_PROFILE_FLAG,
mAc_PROFILE_PRESENT_DEMO,
mAc_PROFILE_PRESENT_NPC,
mAc_PROFILE_BOAT,
mAc_PROFILE_BOAT_DEMO,
mAc_PROFILE_COTTAGE_MY,
mAc_PROFILE_COTTAGE_NPC,
mAc_PROFILE_EV_SONCHO2,
mAc_PROFILE_NPC_MASK_CAT,
mAc_PROFILE_NPC_MASK_CAT2,
mAc_PROFILE_RESET_DEMO,
mAc_PROFILE_GO_HOME_NPC,
mAc_PROFILE_MISIN,
mAc_PROFILE_LIGHTHOUSE_SWITCH,
mAc_PROFILE_MUSEUM_INDOOR,
mAc_PROFILE_T_ANRIUM1,
mAc_PROFILE_T_BISCUS1,
mAc_PROFILE_T_BISCUS2,
mAc_PROFILE_T_HASU1,
mAc_PROFILE_T_HAT1,
mAc_PROFILE_T_ZINNIA1,
mAc_PROFILE_T_BISCUS3,
mAc_PROFILE_T_BISCUS4,
mAc_PROFILE_T_ZINNIA2,
mAc_PROFILE_T_HAT2,
mAc_PROFILE_T_HAT3,
mAc_PROFILE_T_REI1,
mAc_PROFILE_T_REI2,
mAc_PROFILE_NPC_SHASHO,
mAc_PROFILE_T_BAG1,
mAc_PROFILE_T_BAG2,
mAc_PROFILE_EV_CASTAWAY,
mAc_PROFILE_T_COBRA1,
mAc_PROFILE_BALLOON,
mAc_PROFILE_NPC_SONCHO,
mAc_PROFILE_APRILFOOL_CONTROL,
mAc_PROFILE_EV_MAJIN,
mAc_PROFILE_HARVEST_NPC0,
mAc_PROFILE_HARVEST_NPC1,
mAc_PROFILE_GROUNDHOG_CONTROL,
mAc_PROFILE_EV_SPEECH_SONCHO,
mAc_PROFILE_GROUNDHOG_NPC0,
mAc_PROFILE_EV_TURKEY,
mAc_PROFILE_GHOG,
mAc_PROFILE_HTABLE,
mAc_PROFILE_NPC_HEM,
mAc_PROFILE_TENT,
mAc_PROFILE_PTERMINAL,
mAc_PROFILE_MSCORE_CONTROL,
mAc_PROFILE_NUM
};
enum {
mAc_HILITE_OPAQUE,
mAc_HILITE_TRANSLUCENT,
mAc_HILITE_NUM
};
struct actor_profile_s {
s16 id;
u8 part;
u32 initial_flags_state;
mActor_name_t npc_id;
s16 obj_bank_id;
size_t class_size;
mActor_proc ct_proc;
mActor_proc dt_proc;
mActor_proc mv_proc;
mActor_proc dw_proc;
mActor_proc sv_proc;
};
typedef void (*mActor_shadow_proc)(ACTOR*, LightsN*, GAME_PLAY*);
typedef struct actor_shape_info_s {
s_xyz rotation;
s16 unk_6;
f32 ofs_y;
mActor_shadow_proc shadow_proc;
f32 shadow_size_x;
f32 shadow_size_z;
f32 shadow_size_change_rate;
f32 shadow_alpha_change_rate;
int unk_20;
xyz_t* shadow_position;
int move_bg_idx;
u8 draw_shadow;
u8 unk_2D;
u8
force_shadow_position;
u8 unused_2F[0x48 - 0x2F];
} Shape_Info;
typedef struct actor_shadow_s {
xyz_t position;
f32 groundY;
f32 unk10;
f32 unk14;
f32 unk18;
f32 unk1C;
s16 unk20;
s16 unk22;
s16 unk24;
s16 unk26;
char pad28[0xC];
int unk34;
int kind;
} Shadow_Info;
struct actor_s {
s16 id;
u8 part;
u8 restore_fg;
s16 scene_id;
mActor_name_t npc_id;
s8 block_x;
s8 block_z;
s16 move_actor_list_idx;
PositionAngle home;
u32 state_bitfield;
s16 actor_specific;
s16 data_bank_id;
PositionAngle world;
xyz_t last_world_position;
PositionAngle eye;
xyz_t scale;
xyz_t position_speed;
f32 speed;
f32 gravity;
f32 max_velocity_y;
f32 ground_y;
mCoBG_Check_c bg_collision_check;
u8 unknown_b4;
u8 drawn;
s16 player_angle_y;
f32 player_distance;
f32 player_distance_xz;
f32 player_distance_y;
Status_c status_data;
Shape_Info shape_info;
xyz_t camera_position;
f32 camera_w;
f32 cull_width;
f32 cull_height;
f32 cull_distance;
f32 cull_radius;
f32 talk_distance;
u8 cull_while_talking;
u8 skip_drawing;
ACTOR* parent_actor;
ACTOR* child_actor;
ACTOR* prev_actor;
ACTOR* next_actor;
mActor_proc ct_proc;
mActor_proc dt_proc;
mActor_proc mv_proc;
mActor_proc dw_proc;
mActor_proc sv_proc;
ACTOR_DLFTBL* dlftbl;
};
typedef struct actor_list_s {
int num_actors;
ACTOR* actor;
} Actor_list;
typedef struct actor_info_s {
int total_num;
Actor_list list[ACTOR_PART_NUM];
} Actor_info;
typedef struct actor_data_s {
s16 profile;
s_xyz position;
s_xyz rotation;
s16 arg;
} Actor_data;
extern void Actor_world_to_eye(ACTOR* actor, f32 eye_height);
extern void Actor_position_move(ACTOR* actor);
extern void Actor_position_speed_set(ACTOR* actor);
extern void Actor_position_moveF(ACTOR* actor);
extern int Actor_player_look_direction_check(ACTOR* actor, s16 angle, GAME_PLAY* play);
extern void Shape_Info_init(ACTOR* actor, f32 ofs_y, mActor_shadow_proc shadow_proc, f32 shadow_size_x,
f32 shadow_size_z);
extern void Actor_delete(ACTOR* actor);
extern int Actor_draw_actor_no_culling_check(ACTOR* actor);
extern int Actor_draw_actor_no_culling_check2(ACTOR* actor, xyz_t* camera_pos, f32 camera_w);
extern void Actor_info_ct(GAME* game, Actor_info* actor_info, Actor_data* player_data);
extern void Actor_info_dt(Actor_info* actor_info, GAME_PLAY* play);
extern void Actor_info_call_actor(GAME_PLAY* play, Actor_info* actor_info);
extern void Actor_info_draw_actor(GAME_PLAY* play, Actor_info* actor_info);
extern void Actor_free_overlay_area(ACTOR_DLFTBL* dlftbl);
extern void Actor_get_overlay_area(ACTOR_DLFTBL* dlftbl, int unused, size_t alloc_size);
extern void Actor_init_actor_class(ACTOR* actor, ACTOR_PROFILE* profile, ACTOR_DLFTBL* dlftbl, GAME_PLAY* play,
int bank_idx, f32 x, f32 y, f32 z, s16 rot_x, s16 rot_y, s16 rot_z, s8 block_x,
s8 block_z, s16 move_actor_list_idx, mActor_name_t name_id, s16 arg);
extern ACTOR* Actor_info_make_actor(Actor_info* actor_info, GAME* game, s16 profile_no, f32 x, f32 y, f32 z, s16 rot_x,
s16 rot_y, s16 rot_z, s8 block_x, s8 block_z, s16 move_actor_list_idx,
mActor_name_t name_id, s16 arg, s8 npc_info_idx, int data_bank_idx);
extern ACTOR* Actor_info_make_child_actor(Actor_info* actor_info, ACTOR* parent_actor, GAME* game, s16 profile, f32 x,
f32 y, f32 z, s16 rot_x, s16 rot_y, s16 rot_z, s16 move_actor_list_idx,
mActor_name_t name_id, s16 arg, int data_bank_idx);
extern void restore_fgdata_all(GAME_PLAY* play);
extern void Actor_info_save_actor(GAME_PLAY* play);
extern ACTOR* Actor_info_delete(Actor_info* actor_info, ACTOR* actor, GAME* game);
extern ACTOR* Actor_info_name_search_sub(ACTOR* actor, s16 name);
extern ACTOR* Actor_info_name_search(Actor_info* actor_info, s16 name, int part);
extern ACTOR* Actor_info_fgName_search_sub(ACTOR* actor, mActor_name_t fgName);
extern ACTOR* Actor_info_fgName_search(Actor_info* actor_info, mActor_name_t fgName, int part);
extern Gfx* HiliteReflect_new(xyz_t* pos, xyz_t* eye, xyz_t* light_direction, GRAPH* graph, Gfx* gfx, Hilite** hilite);
extern Hilite* HiliteReflect_init(xyz_t* pos, xyz_t* eye, xyz_t* light_direction, GRAPH* graph);
extern Hilite* HiliteReflect_xlu_init(xyz_t* pos, xyz_t* eye, xyz_t* light_direction, GRAPH* graph);
extern void Setpos_HiliteReflect_init(xyz_t* pos, GAME_PLAY* play);
extern void Setpos_HiliteReflect_xlu_init(xyz_t* pos, GAME_PLAY* play);
typedef float MtxF_t[4][4];
typedef union {
MtxF_t mf;
struct {
float xx, yx, zx, wx,
xy, yy, zy, wy,
xz, yz, zz, wz,
xw, yw, zw, ww;
};
} MtxF;
typedef struct {
f32 x, y, z;
} Vec3f;
s16 sins(u16);
s16 coss(u16);
f32 fatan2(f32, f32);
f32 fsqrt(f32);
f32 facos(f32);
typedef struct rect_s {
int top, bottom;
int l, r;
} rect;
typedef struct generic_unit_s {
int z;
int x;
} BlockOrUnit_c;
extern void radianxy_by_2pos(xyz_t* dest, xyz_t* sub, xyz_t* min);
extern s_xyz sanglexy_by_2pos(xyz_t* sub, xyz_t* min);
typedef struct view_s {
GRAPH* graph;
rect screen;
f32 fovY;
f32 near, far;
f32 scale;
xyz_t eye;
xyz_t center;
xyz_t up;
Vp viewport;
Mtx mtx_projection;
Mtx mtx_viewing;
Mtx* p_projection;
Mtx* p_viewing;
struct stretch_s {
xyz_t target_rotate;
xyz_t target_scale;
f32 step;
xyz_t rotate;
xyz_t scale;
} stretch;
u16 normal;
int flag;
int _unused_pad0;
} View;
extern void initView(View* view, GRAPH* graph);
extern void setLookAtView(View* view, xyz_t* eye, xyz_t* center, xyz_t* up);
extern void setScaleView(View* view, f32 scale);
extern void setPerspectiveView(View* view, f32 fovY, f32 near, f32 far);
extern void setScissorView(View* view, rect* screen);
extern int stretchViewInit(View* view);
extern int showView(View* view, int flags);
extern int showPerspectiveView(View* view);
extern int showOrthoView(View* view);
extern int showView1(View* view, int flag_mask, Gfx** gfx_p);
enum {
CAMERA2_PROCESS_STOP,
CAMERA2_PROCESS_NORMAL,
CAMERA2_PROCESS_WADE,
CAMERA2_PROCESS_TALK,
CAMERA2_PROCESS_DEMO,
CAMERA2_PROCESS_ITEM,
CAMERA2_PROCESS_LOCK,
CAMERA2_PROCESS_DOOR,
CAMERA2_PROCESS_SIMPLE,
CAMERA2_PROCESS_CUST_TALK,
CAMERA2_PROCESS_INTER,
CAMERA2_PROCESS_STAFF_ROLL,
CAMERA2_PROCESS_INTER2,
CAMERA2_PROCESS_NUM
};
typedef struct camera_main_cust_talk_s {
ACTOR* speaker_actor;
ACTOR* listener_actor;
f32 center_ratio;
f32 cull_timer;
s16 angle_x;
s16 angle_y;
f32 distance;
} CameraCustTalk;
typedef struct camera_main_demo_s {
xyz_t starting_center_pos;
f32 starting_distance;
s_xyz starting_direction;
xyz_t goal_center_pos;
f32 goal_distance;
s_xyz goal_direction;
f32 goal_delta;
f32 acceleration_delta;
f32 braking_delta;
f32 now_delta;
} CameraDemo;
typedef struct camera_main_door_s {
u32 flags;
int morph_counter;
xyz_t center_position;
} CameraDoor;
typedef struct camera_main_inter_s {
xyz_t starting_center_pos;
xyz_t starting_eye_pos;
xyz_t goal_center_pos;
xyz_t goal_eye_pos;
f32 slope0;
f32 slope1;
u32 flags;
int now_delta;
int max_delta;
int pad[2];
} CameraInter;
typedef struct camera_main_item_s {
int type;
f32 cull_timer;
} CameraItem;
typedef struct camera_main_lock_s {
xyz_t center_pos;
xyz_t eye_pos;
f32 fov_y;
int morph_counter;
f32 near;
f32 far;
} CameraLock;
typedef struct camera_main_normal_s {
u32 flags;
int last_indoor_distance_addition_idx;
int last_indoor_direction_addition_idx;
int morph_counter;
} CameraNormal;
typedef struct camera_main_simple_s {
xyz_t center_pos;
s_xyz angle;
f32 distance;
int morph_counter;
int mode;
f32 cull_timer;
} CameraSimple;
typedef struct camera_main_staff_roll_s {
xyz_t last_center_pos;
xyz_t last_eye_pos;
f32 last_distance;
ACTOR* speaker_actor;
ACTOR* listener_actor;
s16 rotation_y_delta;
s16 r_delta;
s16 rotation_x_delta;
u16 flags;
u16 morph_counter;
u16 pad;
u16 dist_counter;
s_xyz last_direction;
} CameraStaffRoll;
typedef struct camera_main_talk_s {
ACTOR* speaker_actor;
ACTOR* listener_actor;
xyz_t listener_pos;
f32 cull_timer;
u32 flags;
xyz_t goal_center_pos;
} CameraTalk;
typedef struct camera_main_wade_s {
f32 timer;
xyz_t start_pos;
xyz_t goal_pos;
f32 goal_time;
} CameraWade;
typedef union camera_main_data_u {
CameraCustTalk cust_talk;
CameraDemo demo;
CameraDoor door;
CameraInter inter;
CameraItem item;
CameraLock lock;
CameraNormal normal;
CameraSimple simple;
CameraStaffRoll staff_roll;
CameraTalk talk;
CameraWade wade;
u64 align;
} CameraMainData;
typedef struct camera_request_cust_talk_s {
ACTOR* speaker_actor;
ACTOR* listener_actor;
f32 center_ratio;
s16 angle_x;
s16 angle_y;
f32 distance;
} CameraRequestCustTalk;
typedef struct camera_request_demo_s {
xyz_t starting_center_pos;
f32 starting_distance;
s_xyz starting_direction;
xyz_t goal_center_pos;
f32 goal_distance;
s_xyz goal_direction;
f32 goal_delta;
f32 acceleration_delta;
f32 braking_delta;
} CameraRequestDemo;
typedef struct camera_request_door_s {
ACTOR* door_actor;
u32 flags;
} CameraRequestDoor;
typedef struct camera_request_inter_s {
xyz_t starting_center_pos;
xyz_t starting_eye_pos;
xyz_t goal_center_pos;
xyz_t goal_eye_pos;
f32 slope0;
f32 slope1;
u32 flags;
int morph_counter;
int pad[2];
} CameraRequestInter;
typedef struct camera_request_item_s {
int type;
} CameraRequestItem;
typedef struct camera_request_lock_s {
xyz_t center_pos;
xyz_t eye_pos;
f32 fov_y;
int morph_counter;
f32 near;
f32 far;
} CameraRequestLock;
typedef struct camera_request_normal_s {
xyz_t position;
int flags;
} CameraRequestNormal;
typedef struct camera_request_simple_s {
xyz_t center_pos;
s_xyz angle;
f32 distance;
int morph_counter;
int mode;
} CameraRequestSimple;
typedef struct camera_request_staff_roll_s {
ACTOR* speaker_actor;
ACTOR* listener_actor;
} CameraRequestStaffRoll;
typedef struct camera_request_talk_s {
ACTOR* speaker_actor;
ACTOR* listener_actor;
xyz_t listener_pos;
u32 flags;
} CameraRequestTalk;
typedef struct camera_request_wade_s {
xyz_t goal_pos;
f32 goal_time;
} CameraRequestWade;
typedef union camera_request_data_u {
CameraRequestCustTalk cust_talk;
CameraRequestDemo demo;
CameraRequestDoor door;
CameraRequestInter inter;
CameraRequestItem item;
CameraRequestLock lock;
CameraRequestNormal normal;
CameraRequestSimple simple;
CameraRequestStaffRoll staff_roll;
CameraRequestTalk talk;
CameraRequestWade wade;
u64 align;
} CameraRequestData;
typedef struct camera_lookat_s {
xyz_t eye;
xyz_t center;
xyz_t up;
} CameraLookat;
typedef struct camera_perspective_s {
f32 fov_y;
f32 aspect_ratio;
f32 near;
f32 far;
f32 scale;
} CameraPerspective;
typedef struct camera_s {
CameraLookat lookat;
CameraPerspective perspective;
s_xyz direction;
s_xyz direction_velocity;
xyz_t movement_velocity;
f32 focus_distance;
f32 focus_distance_velocity;
int indoor_distance_addition_idx;
int indoor_direction_addition_idx;
int now_main_index;
int last_main_index;
int requested_main_index;
int requested_main_index_priority;
int requested_main_index_flag;
CameraMainData main_data;
CameraRequestData request_data;
xyz_t mic_pos;
u32 flags;
xyz_t offset_eye;
xyz_t offset_center;
} Camera2;
extern s16 getCamera2AngleY(GAME_PLAY* play);
extern int Camera2_change_priority(GAME_PLAY* play, int priority);
extern xyz_t* Camera2_getEyePos_p();
extern xyz_t* Camera2_getCenterPos_p();
extern int Camera2_CheckCullingMode();
extern int Camera2_CheckEnterCullingArea(f32 pos_x, f32 pos_z, f32 width);
extern void Camera2_ClearActorTalking_Cull(GAME_PLAY* play);
extern int Camera2_Check_main_index(GAME_PLAY* play, int main_index);
extern xyz_t* Camera2_getMicPos_p(GAME_PLAY* play);
extern int Camera2NormalState_get(GAME_PLAY* play);
extern int Camera2_request_main_wade(GAME_PLAY* play, xyz_t* pos, int priority, f32 goal_time);
extern int Camera2_request_main_talk(GAME_PLAY* play, ACTOR* speaker, ACTOR* listener, int priority);
extern int Camera2_request_main_talk_pos(GAME_PLAY* play, ACTOR* speaker, const xyz_t* const listener_pos, int priority);
extern int Camera2_request_main_normal(GAME_PLAY* play, int flags, int priority);
extern int Camera2_request_main_demo(GAME_PLAY* play, const xyz_t* start_center, const f32 start_dist,
const s_xyz* start_dir, const xyz_t* goal_center, const f32 goal_dist,
const s_xyz* goal_dir, const f32 goal_delta, const f32 accel_delta,
const f32 braking_delta, const int priority);
extern int Camera2_request_main_demo_fromNowPos(GAME_PLAY* play, const xyz_t* goal_center, const s_xyz* goal_dir,
const f32 goal_dist, const f32 goal_delta, const f32 accel_delta,
const f32 braking_delta, const int priority);
extern int Camera2_request_main_demo_fromNowPos2(GAME_PLAY* play, const xyz_t* goal_center, const f32 goal_delta,
const f32 accel_delta, const f32 braking_delta, const int priority);
extern int Camera2_request_main_item(GAME_PLAY* play, int type, int priority);
extern int Camera2_request_main_lock(GAME_PLAY* play, const xyz_t* center_pos, const xyz_t* eye_pos, f32 fov_y, int morph_counter,
f32 near, f32 far, int priority);
extern int Camera2_request_main_door(GAME_PLAY* play, ACTOR* door_actor, u32 flags, int priority);
extern int Camera2_request_main_simple2(GAME_PLAY* play, const xyz_t* center, const s_xyz* dir, f32 dist, int morph_counter,
int mode, int priority);
extern int Camera2_request_main_simple_kirin(GAME_PLAY* play, const xyz_t* center, int priority);
extern int Camera2_request_main_simple_fishing(GAME_PLAY* play, const xyz_t* player_pos, const xyz_t* bobber_pos,
int priority);
extern int Camera2_request_main_simple_fishing_return(GAME_PLAY* play, const xyz_t* player_pos, int priority);
extern int Camera2_request_main_simple(GAME_PLAY* play, const xyz_t* pos, const s_xyz* dir, f32 dist, int morph_counter,
int priority);
extern void Camera2_main_Simple_AngleDistStd(GAME_PLAY* play, s_xyz* angle, f32* dist);
extern int Camera2_request_main_listen_front_low_talk(GAME_PLAY* play, ACTOR* speaker, ACTOR* listener, int priority);
extern int Camera2_request_main_needlework_talk(GAME_PLAY* play, ACTOR* speaker, ACTOR* listener, int priority);
extern int Camera2_request_main_cust_talk(GAME_PLAY* play, ACTOR* speaker, ACTOR* listener, f32 center_ratio,
int priority, s16 angle_x, s16 angle_y, f32 distance);
extern int Camera2_request_BuySikimono_WallPaper(GAME_PLAY* play, xyz_t* center, xyz_t* eye);
extern int Camera2_Inter_set_reverse_mode(GAME_PLAY* play);
extern int Camera2_request_main_inter(GAME_PLAY* play, const xyz_t* start_center, const xyz_t* start_eye, const xyz_t* goal_center,
const xyz_t* goal_eye, f32 s0, f32 s1, u32 flags, int morph_counter, int priority);
extern int Camera2_request_main_staff_roll(GAME_PLAY* play, ACTOR* speaker, ACTOR* listener, int priority);
extern void Init_Camera2(GAME_PLAY* play);
extern void Camera2_process(GAME_PLAY* play);
extern void Camera2_draw(GAME_PLAY* play);
typedef struct submenu_overlay_s Submenu_Overlay_c;
typedef struct land_info_s {
u8 name[8 ];
s8 exists;
u16 id;
} mLd_land_info_c;
typedef struct personal_id_s {
u8 player_name[8 ];
u8 land_name[8 ];
u16 player_id;
u16 land_id;
} PersonalID_c;
enum {
mNpc_LOOKS_GIRL,
mNpc_LOOKS_KO_GIRL,
mNpc_LOOKS_BOY,
mNpc_LOOKS_SPORT_MAN,
mNpc_LOOKS_GRIM_MAN,
mNpc_LOOKS_NANIWA_LADY,
mNpc_LOOKS_UNSET,
mNpc_LOOKS_NUM = mNpc_LOOKS_UNSET
};
typedef struct animal_personal_id_s {
mActor_name_t npc_id;
u16 land_id;
u8 land_name[8 ];
u8 name_id;
u8 looks;
} AnmPersonalID_c;
enum {
mMl_NAME_TYPE_PLAYER,
mMl_NAME_TYPE_NPC,
mMl_NAME_TYPE_MUSEUM,
mMl_NAME_TYPE_NUM,
mMl_NAME_TYPE_CLEAR = 0xFF
};
enum {
mMl_FONT_RECV,
mMl_FONT_SEND,
mMl_FONT_RECV_READ,
mMl_FONT_RECV_PLAYER_PRESENT,
mMl_FONT_RECV_PLAYER_PRESENT_READ,
mMl_FONT_NUM
};
enum {
mMl_DATA,
mMl_DATA2,
mMl_DATA_NUM
};
enum {
mMl_TYPE_MAIL,
mMl_TYPE_XMAS,
mMl_TYPE_SHOP_SALE_LEAFLET,
mMl_TYPE_BROKER_SALE_LEAFLET,
mMl_TYPE_MOTHER,
mMl_TYPE_OMIKUJI,
mMl_TYPE_HRA,
mMl_TYPE_SHOP,
mMl_TYPE_SNOWMAN,
mMl_TYPE_FISHING_CONTENST,
mMl_TYPE_POSTOFFICE,
mMl_TYPE_SPNPC_PASSWORD,
mMl_TYPE_NUM
};
typedef struct mail_nm_s {
PersonalID_c personalID;
u8 type;
} Mail_nm_c;
typedef struct mail_header_save_s {
s8 header_back_start;
u8 unknown;
u8 header[(32 - 8) ];
u8 footer[32 ];
} Mail_hs_c;
typedef struct mail_header_s {
Mail_nm_c recipient;
Mail_nm_c sender;
} Mail_hdr_c;
typedef struct mail_content_s {
u8 font;
u8 header_back_start;
u8 mail_type;
u8 paper_type;
u8 header[(32 - 8) ];
u8 body[192 ];
u8 footer[32 ];
} Mail_ct_c;
typedef struct mail_s {
Mail_hdr_c header;
mActor_name_t present;
Mail_ct_c content;
} Mail_c;
extern int mMl_strlen(u8* str, int size, u8 end_char);
extern int mMl_strlen2(int* found, u8* str, int size, u8 end_char);
extern void mMl_clear_mail_header(Mail_hdr_c* header);
extern void mMl_clear_mail(Mail_c* mail);
extern void mMl_clear_mail_box(Mail_c* mail, int num);
extern int mMl_check_not_used_mail(Mail_c* mail);
extern void mMl_copy_header_name(Mail_nm_c* dst, Mail_nm_c* src);
extern void mMl_set_to_plname(Mail_c* mail, PersonalID_c* pid);
extern void mMl_set_playername(Mail_c* mail, PersonalID_c* pid);
extern void mMl_init_mail(Mail_c* mail, PersonalID_c* pid);
extern int mMl_chk_mail_free_space(Mail_c* mail, int num);
extern int mMl_count_use_mail_space(Mail_c* mail, int num);
extern void mMl_copy_mail(Mail_c* dst, Mail_c* src);
extern void mMl_clear_mail_header_common(Mail_hs_c* header);
extern void mMl_set_mail_name_npcinfo(Mail_nm_c* name, AnmPersonalID_c* anm_pid);
extern int mMl_get_npcinfo_from_mail_name(AnmPersonalID_c* anm_pid, Mail_nm_c* name);
extern int mMl_hunt_for_send_address(Mail_c* mail);
extern int mMl_check_send_mail(Mail_c* mail);
extern int mMl_check_set_present_myself(Mail_c* mail);
extern int mMl_send_mail_box(PersonalID_c* recipient_pid, int player_no, Mail_c* mail, mActor_name_t present,
mActor_name_t paper, int mail_no, u8* sender_name, u32 proc_type);
extern int mMl_send_mail_postoffice(PersonalID_c* recipient_pid, int player_no, mActor_name_t present,
mActor_name_t paper, int mail_no, u8* sender_name, u32 proc_type, u8 mail_type);
extern int mMl_send_mail(PersonalID_c* recipient_pid, int player_no, mActor_name_t present, mActor_name_t paper,
int mail_no, u8* sender_name, u32 proc_type);
extern void mMl_start_send_mail();
typedef struct private_s Private_c;
typedef struct private_cloth_s {
u16 idx;
mActor_name_t item;
} mPr_cloth_c;
typedef void* (*PrintCallback)(void*, const char*, int);
typedef struct gfxprint_obj {
PrintCallback prout_func;
Gfx* glistp;
u16 position_x;
u16 position_y;
u16 offset_x;
u8 offset_y;
u8 flags;
rgba8888 color;
u8 dummy[28];
} gfxprint_t;
extern u8 __gfxprint_default_flags;
extern u16 gfxprint_moji_tlut[];
extern u8 gfxprint_font[];
static void gfxprint_setup(gfxprint_t* this);
static void gfxprint_putc1(gfxprint_t* this, char c);
static void* gfxprint_prout(void* this, const char* buffer, int n);
extern void gfxprint_color(gfxprint_t* this, u32 r, u32 g, u32 b, u32 a);
extern void gfxprint_locate(gfxprint_t* this, int x, int y);
extern void gfxprint_locate8x8(gfxprint_t* this, int x, int y);
extern void gfxprint_setoffset(gfxprint_t* this, int x, int y);
extern void gfxprint_putc(gfxprint_t* this, char c);
extern void gfxprint_write(gfxprint_t* this, const void* buffer, size_t size, size_t n);
extern void gfxprint_puts(gfxprint_t* this, char* string);
extern void gfxprint_init(gfxprint_t* this);
extern void gfxprint_cleanup(gfxprint_t* this);
extern void gfxprint_open(gfxprint_t* this, Gfx* glistp);
extern Gfx* gfxprint_close(gfxprint_t* this);
extern int gfxprint_vprintf(gfxprint_t* this, const char* fmt, va_list ap);
extern int gfxprint_printf(gfxprint_t* this, const char* fmt, ...);
typedef struct OSRTCTime {
u8 sec;
u8 min;
u8 hour;
u8 day;
u8 weekday;
u8 month;
u16 year;
} OSRTCTime;
typedef u8 lbRTC_sec_t;
typedef u8 lbRTC_min_t;
typedef u8 lbRTC_hour_t;
typedef u8 lbRTC_day_t;
typedef u8 lbRTC_weekday_t;
typedef u8 lbRTC_month_t;
typedef u16 lbRTC_year_t;
typedef OSRTCTime lbRTC_time_c;
typedef struct lbRTC_ymd_s {
lbRTC_year_t year;
lbRTC_month_t month;
lbRTC_day_t day;
} lbRTC_ymd_c;
enum WEEKDAYS {
lbRTC_WEEKDAYS_BEGIN = 0,
lbRTC_SUNDAY = lbRTC_WEEKDAYS_BEGIN,
lbRTC_MONDAY,
lbRTC_TUESDAY,
lbRTC_WEDNESDAY,
lbRTC_THURSDAY,
lbRTC_FRIDAY,
lbRTC_SATURDAY,
lbRTC_WEEK,
lbRTC_WEEKDAYS_MAX = lbRTC_WEEK
};
enum MONTHS {
lbRTC_MONTHS_BEGIN = 0,
lbRTC_JANUARY = 1,
lbRTC_FEBRUARY,
lbRTC_MARCH,
lbRTC_APRIL,
lbRTC_MAY,
lbRTC_JUNE,
lbRTC_JULY,
lbRTC_AUGUST,
lbRTC_SEPTEMBER,
lbRTC_OCTOBER,
lbRTC_NOVEMBER,
lbRTC_DECEMBER,
lbRTC_MONTHS_MAX = lbRTC_DECEMBER
};
enum RTC_EQUALITY {
lbRTC_LESS = -1,
lbRTC_EQUAL = 0,
lbRTC_OVER = 1
};
enum RTC_EQUALITY_FLAGS {
lbRTC_CHECK_NONE = 0,
lbRTC_CHECK_SECONDS = 1 << 0,
lbRTC_CHECK_MINUTES = 1 << 1,
lbRTC_CHECK_HOURS = 1 << 2,
lbRTC_CHECK_WEEKDAYS = 1 << 3,
lbRTC_CHECK_DAYS = 1 << 4,
lbRTC_CHECK_MONTHS = 1 << 5,
lbRTC_CHECK_YEARS = 1 << 6,
lbRTC_CHECK_ALL = lbRTC_CHECK_SECONDS |
lbRTC_CHECK_MINUTES |
lbRTC_CHECK_HOURS |
lbRTC_CHECK_WEEKDAYS |
lbRTC_CHECK_DAYS |
lbRTC_CHECK_MONTHS |
lbRTC_CHECK_YEARS
};
extern OSTime lbRTC_HardTime();
extern int lbRTC_IsAbnormal();
extern void lbRTC_Sampling();
extern void lbRTC_SetTime(lbRTC_time_c* time);
extern void lbRTC_GetTime(lbRTC_time_c* time);
extern lbRTC_day_t lbRTC_GetDaysByMonth(lbRTC_year_t year, lbRTC_month_t month);
extern int lbRTC_IsEqualDate(
lbRTC_year_t y0, lbRTC_month_t m0, lbRTC_day_t d0,
lbRTC_year_t y1, lbRTC_month_t m1, lbRTC_day_t d1
);
extern int lbRTC_IsEqualTime(const lbRTC_time_c* t0, const lbRTC_time_c* t1, int flags);
extern int lbRTC_IsOverTime(const lbRTC_time_c* t0, const lbRTC_time_c* t1);
extern int lbRTC_IsOverRTC(const lbRTC_time_c* time);
extern int lbRTC_IntervalTime(const lbRTC_time_c* time0, const lbRTC_time_c* time1);
extern int lbRTC_GetIntervalDays(const lbRTC_time_c* t0, const lbRTC_time_c* t1);
extern int lbRTC_GetIntervalDays2(lbRTC_ymd_c* ymd0, lbRTC_ymd_c* ymd1);
extern void lbRTC_Add_YY(lbRTC_time_c* time, int year);
extern void lbRTC_Add_MM(lbRTC_time_c* time, int month);
extern void lbRTC_Add_DD(lbRTC_time_c* time, int day);
extern void lbRTC_Add_hh(lbRTC_time_c* time, int hour);
extern void lbRTC_Add_mm(lbRTC_time_c* time, int min);
extern void lbRTC_Add_ss(lbRTC_time_c* time, int sec);
extern void lbRTC_Add_Date(lbRTC_time_c* time, const lbRTC_time_c* add_time);
extern void lbRTC_Sub_YY(lbRTC_time_c* time, int year);
extern void lbRTC_Sub_MM(lbRTC_time_c* time, int month);
extern void lbRTC_Sub_DD(lbRTC_time_c* time, int days);
extern void lbRTC_Sub_hh(lbRTC_time_c* time, int hour);
extern void lbRTC_Sub_mm(lbRTC_time_c* time, int min);
extern void lbRTC_Sub_ss(lbRTC_time_c* time, int sec);
extern lbRTC_weekday_t lbRTC_Week(lbRTC_year_t year, lbRTC_month_t month, lbRTC_day_t day);
extern void lbRTC_TimeCopy(lbRTC_time_c* dst, const lbRTC_time_c* src);
extern int lbRTC_IsValidTime(const lbRTC_time_c* time);
extern int lbRTC_time_c_save_data_check(const lbRTC_time_c* time);
extern int lbRTC_Weekly_day(lbRTC_year_t year, lbRTC_month_t month, int weeks, int weekday);
enum {
mQst_QUEST_TYPE_DELIVERY,
mQst_QUEST_TYPE_ERRAND,
mQst_QUEST_TYPE_CONTEST,
mQst_QUEST_TYPE_NONE,
mQst_QUEST_TYPE_NUM = mQst_QUEST_TYPE_NONE
};
typedef struct quest_base_s {
u32 quest_type : 2;
u32 quest_kind : 6;
u32 time_limit_enabled : 1;
u32 progress : 4;
u32 give_reward : 1;
u32 unused : 2;
lbRTC_time_c time_limit;
} mQst_base_c;
enum {
mQst_CONTEST_KIND_FRUIT,
mQst_CONTEST_KIND_SOCCER,
mQst_CONTEST_KIND_SNOWMAN,
mQst_CONTEST_KIND_FLOWER,
mQst_CONTEST_KIND_FISH,
mQst_CONTEST_KIND_INSECT,
mQst_CONTEST_KIND_LETTER,
mQst_CONTEST_KIND_NUM
};
enum {
mQst_CONTEST_DATA_NONE,
mQst_CONTEST_DATA_FLOWER,
mQst_CONTEST_DATA_LETTER,
mQst_CONTEST_DATA_NUM
};
typedef union quest_contest_info_s {
struct {
u8 flowers_requested;
} flower_data;
struct {
u8 score;
mActor_name_t present;
} letter_data;
} mQst_contest_info_u;
typedef struct quest_contest_s {
mQst_base_c base;
mActor_name_t requested_item;
PersonalID_c player_id;
s8 type;
mQst_contest_info_u info;
} mQst_contest_c;
enum {
mQst_DELIVERY_KIND_NORMAL,
mQst_DELIVERY_KIND_FOREIGN,
mQst_DELIVERY_KIND_REMOVE,
mQst_DELIVERY_KIND_LOST,
mQst_DELIVERY_KIND_NUM
};
typedef struct quest_delivery_s {
mQst_base_c base;
AnmPersonalID_c recipient;
AnmPersonalID_c sender;
} mQst_delivery_c;
enum {
mQst_ERRAND_REQUEST,
mQst_ERRAND_REQUEST_CONTINUE,
mQst_ERRAND_REQUEST_FINAL,
mQst_ERRAND_FIRSTJOB_CHANGE_CLOTH,
mQst_ERRAND_FIRSTJOB_PLANT_FLOWER,
mQst_ERRAND_FIRSTJOB_DELIVER_FTR,
mQst_ERRAND_FIRSTJOB_SEND_LETTER,
mQst_ERRAND_FIRSTJOB_DELIVER_CARPET,
mQst_ERRAND_FIRSTJOB_DELIVER_AXE,
mQst_ERRAND_FIRSTJOB_POST_NOTICE,
mQst_ERRAND_FIRSTJOB_SEND_LETTER2,
mQst_ERRAND_FIRSTJOB_DELIVER_AXE2,
mQst_ERRAND_FIRSTJOB_INTRODUCTIONS,
mQst_ERRAND_FIRSTJOB_OPEN,
mQst_ERRAND_FIRSTJOB_START,
mQst_ERRAND_NUM
};
enum {
mQst_ERRAND_TYPE_NONE,
mQst_ERRAND_TYPE_CHAIN,
mQst_ERRAND_TYPE_FIRST_JOB,
mQst_ERRAND_TYPE_NUM
};
typedef struct quest_first_job_s {
AnmPersonalID_c used_ids[2 ];
u8 used_num : 7;
u8 wrong_cloth : 1;
} mQst_firstjob_c;
typedef struct quest_errand_chain_s {
AnmPersonalID_c used_ids[3 ];
u8 used_num;
} mQst_errand_chain_c;
typedef union {
mQst_errand_chain_c chain;
mQst_firstjob_c first_job;
} mQst_errand_info_u;
typedef struct quest_errand_s {
mQst_base_c base;
AnmPersonalID_c recipient;
AnmPersonalID_c sender;
mActor_name_t item;
s8 pockets_idx : 5;
s8 errand_type : 3;
mQst_errand_info_u info;
} mQst_errand_c;
typedef struct not_saved_quest_s {
int work;
u8 h;
} mQst_not_saved_c;
extern void mQst_ClearQuestInfo(mQst_base_c* quest);
extern void mQst_ClearDelivery(mQst_delivery_c* delivery, int num);
extern void mQst_ClearErrand(mQst_errand_c* errand, int num);
extern void mQst_ClearContest(mQst_contest_c* contest);
extern void mQst_ClearNotSaveQuest(mQst_not_saved_c* not_saved);
extern void mQst_CopyQuestInfo(mQst_base_c* dst, mQst_base_c* src);
extern void mQst_CopyDelivery(mQst_delivery_c* dst, mQst_delivery_c* src);
extern void mQst_CopyErrand(mQst_errand_c* dst, mQst_errand_c* src);
extern int mQst_CheckFreeQuest(mQst_base_c* quest);
extern int mQst_CheckLimitOver(mQst_base_c* quest);
extern int mQst_GetOccuredDeliveryIdx(int delivery_kind);
extern int mQst_ClearQuestbyPossessionIdx(int idx);
extern int mQst_CheckLimitbyPossessionIdx(int idx);
extern void mQst_ClearGrabItemInfo();
extern void mQst_CheckGrabItem(mActor_name_t item, int pocket_idx);
extern void mQst_CheckPutItem(mActor_name_t item, int pocket_idx);
extern int mQst_CheckNpcExistbyItemIdx(int idx, int sender_or_receipient);
extern int mQst_GetToFromName(u8* to_name, u8* from_name, int idx);
extern int mQst_GetOccuredContestIdx(int kind);
extern int mQst_GetFlowerSeedNum(int block_x, int block_z);
extern int mQst_GetFlowerNum(int block_x, int block_z);
extern int mQst_GetNullNoNum(int block_x, int block_z);
extern void mQst_SetItemNameStr(mActor_name_t item, int string_no);
extern void mQst_SetItemNameFreeStr(mActor_name_t item, int string_no);
extern int mQst_SendRemail(mQst_contest_c* contest, AnmPersonalID_c* sender_id);
extern void mQst_SetReceiveLetter(mQst_contest_c* contest, PersonalID_c* sender_id, u8* body, mActor_name_t present);
extern mQst_errand_c* mQst_GetFirstJobData();
extern int mQst_CheckFirstJobQuestbyItemIdx(int idx);
extern int mQst_CheckFirstJobFin(mQst_errand_c* errand);
extern int mQst_CheckRemoveTarget(mQst_errand_c* errand);
extern void mQst_SetFirstJobStart(mQst_errand_c* errand);
extern void mQst_SetFirstJobChangeCloth(mQst_errand_c* errand, mActor_name_t item);
extern void mQst_SetFirstJobSeed(mQst_errand_c* errand);
extern void mQst_SetFirstJobHello(mQst_errand_c* errand);
extern void mQst_SetFirstJobFurniture(mQst_errand_c* errand, AnmPersonalID_c* pid, mActor_name_t item, int slot);
extern void mQst_SetFirstJobLetter(mQst_errand_c* errand, AnmPersonalID_c* pid);
extern void mQst_SetFirstJobLetter2(mQst_errand_c* errand, AnmPersonalID_c* pid);
extern void mQst_SetFirstJobOpenQuest(mQst_errand_c* errand);
extern void mQst_SetFirstJobCarpet(mQst_errand_c* errand, AnmPersonalID_c* pid, mActor_name_t item, int slot);
extern void mQst_SetFirstJobAxe(mQst_errand_c* errand, AnmPersonalID_c* pid, mActor_name_t item, int slot);
extern void mQst_SetFirstJobAxe2(mQst_errand_c* errand, AnmPersonalID_c* pid, mActor_name_t item, int slot);
extern void mQst_SetFirstJobNotice(mQst_errand_c* errand);
extern int mQst_GetRandom(int max);
extern void mQst_GetGoods_common(mActor_name_t* item, AnmPersonalID_c* pid, int category, mActor_name_t* exist_table,
int exist_num, int list);
extern int mQst_CheckSoccerTarget(ACTOR* actor);
extern void mQst_NextSoccer(ACTOR* actor);
extern void mQst_NextSnowman(xyz_t snowman_pos);
extern void mQst_BackSnowman(xyz_t snowman_pos);
extern void mQst_PrintQuestInfo(gfxprint_t* gfxprint);
enum {
EVW_ANIME_TYPE_SCROLL1,
EVW_ANIME_TYPE_SCROLL2,
EVW_ANIME_TYPE_COLREG_MANUAL,
EVW_ANIME_TYPE_COLREG_LINEAR,
EVW_ANIME_TYPE_COLREG_NONLINEAR,
EVW_ANIME_TYPE_TEXANIME,
EVW_ANIME_TYPE_NUM
};
typedef struct evw_anime_col_prim_s {
u8 r;
u8 g;
u8 b;
u8 a;
u8 l;
} EVW_ANIME_COL_PRIM;
typedef struct evw_anime_col_env_s {
u8 r;
u8 g;
u8 b;
u8 a;
} EVW_ANIME_COL_ENV;
typedef struct evw_anime_col_reg_s {
u16 frame_count;
u16 key_count;
EVW_ANIME_COL_PRIM* prim_colors;
EVW_ANIME_COL_ENV* env_colors;
u16* keyframes;
} EVW_ANIME_COLREG;
typedef struct evw_anime_scroll_s {
s8 x;
s8 y;
u8 width;
u8 height;
} EVW_ANIME_SCROLL;
typedef struct evw_anime_texanime_s {
u16 frame_count;
u16 key_count;
void** texture_tbl;
u8* animation_pattern;
u16* keyframes;
} EVW_ANIME_TEXANIME;
typedef struct evw_anime_s {
s8 segment;
s16 type;
void* data_p;
} EVW_ANIME_DATA;
extern void Evw_Anime_Set(GAME_PLAY* play, EVW_ANIME_DATA* evw_anime_data);
enum __block_combi__ {
BLOCK_COMBI_GRD_0,
BLOCK_COMBI_GRD_1,
BLOCK_COMBI_GRD_2,
BLOCK_COMBI_GRD_3,
BLOCK_COMBI_GRD_4,
BLOCK_COMBI_GRD_5,
BLOCK_COMBI_GRD_6,
BLOCK_COMBI_GRD_7,
BLOCK_COMBI_ROOM01,
BLOCK_COMBI_GRD_9,
BLOCK_COMBI_GRD_10,
BLOCK_COMBI_GRD_11,
BLOCK_COMBI_GRD_12,
BLOCK_COMBI_GRD_13,
BLOCK_COMBI_GRD_14,
BLOCK_COMBI_GRD_15,
BLOCK_COMBI_GRD_16,
BLOCK_COMBI_GRD_17,
BLOCK_COMBI_ROM_MY_ROOM_L,
BLOCK_COMBI_GRD_19,
BLOCK_COMBI_GRD_20,
BLOCK_COMBI_ROM_NPC_ROOM01,
BLOCK_COMBI_GRD_22,
BLOCK_COMBI_GRD_23,
BLOCK_COMBI_GRD_S_R5_B_1,
BLOCK_COMBI_ROM_SHOP1,
BLOCK_COMBI_GRD_26,
BLOCK_COMBI_GRD_S_C5_R1_1,
BLOCK_COMBI_GRD_S_T_R1_1,
BLOCK_COMBI_TMP,
BLOCK_COMBI_TMP2,
BLOCK_COMBI_TMPR,
BLOCK_COMBI_TMPR2,
BLOCK_COMBI_GRD_S_C1_R1_1,
BLOCK_COMBI_GRD_S_C1_S_1,
BLOCK_COMBI_GRD_S_C2_R1_1,
BLOCK_COMBI_GRD_S_C2_R2_1,
BLOCK_COMBI_GRD_S_F_1,
BLOCK_COMBI_GRD_S_F_2,
BLOCK_COMBI_GRD_S_C1_1,
BLOCK_COMBI_GRD_S_C1_R2_1,
BLOCK_COMBI_GRD_S_C1_R3_1,
BLOCK_COMBI_GRD_S_C2_1,
BLOCK_COMBI_GRD_S_C3_1,
BLOCK_COMBI_GRD_S_C3_R1_1,
BLOCK_COMBI_GRD_S_C4_1,
BLOCK_COMBI_GRD_S_C4_R1_1,
BLOCK_COMBI_GRD_S_C4_R2_1,
BLOCK_COMBI_GRD_S_C5_1,
BLOCK_COMBI_GRD_S_C5_R2_1,
BLOCK_COMBI_GRD_S_C5_R3_1,
BLOCK_COMBI_GRD_S_C6_1,
BLOCK_COMBI_GRD_S_C6_R1_1,
BLOCK_COMBI_GRD_S_C7_1,
BLOCK_COMBI_GRD_S_R1_1,
BLOCK_COMBI_GRD_S_R2_1,
BLOCK_COMBI_GRD_S_R3_1,
BLOCK_COMBI_GRD_S_R4_1,
BLOCK_COMBI_GRD_S_R5_1,
BLOCK_COMBI_GRD_S_R6_1,
BLOCK_COMBI_GRD_S_R7_1,
BLOCK_COMBI_GRD_S_C3_R2_1,
BLOCK_COMBI_GRD_S_C7_R3_1,
BLOCK_COMBI_GRD_S_C6_R3_1,
BLOCK_COMBI_GRD_S_R1_B_1,
BLOCK_COMBI_GRD_S_R2_B_1,
BLOCK_COMBI_GRD_S_R3_B_1,
BLOCK_COMBI_GRD_S_R4_B_1,
BLOCK_COMBI_GRD_S_R6_B_1,
BLOCK_COMBI_GRD_S_R7_B_1,
BLOCK_COMBI_GRD_S_T_1,
BLOCK_COMBI_GRD_S_C1_S_2,
BLOCK_COMBI_GRD_S_C2_S_1,
BLOCK_COMBI_GRD_S_C3_S_1,
BLOCK_COMBI_GRD_S_C4_S_1,
BLOCK_COMBI_GRD_S_C5_S_1,
BLOCK_COMBI_GRD_S_C6_S_1,
BLOCK_COMBI_GRD_S_C7_S_1,
BLOCK_COMBI_GRD_S_C7_R1_1,
BLOCK_COMBI_GRD_S_C4_R3_1,
BLOCK_COMBI_GRD_YAMISHOP,
BLOCK_COMBI_GRD_POST_OFFICE,
BLOCK_COMBI_ROM_TRAIN_IN,
BLOCK_COMBI_ROM_TRAIN_IN2,
BLOCK_COMBI_GRD_S_F_1_84,
BLOCK_COMBI_GRD_S_T_ST1_1,
BLOCK_COMBI_GRD_S_F_1_86,
BLOCK_COMBI_GRD_S_C1_2,
BLOCK_COMBI_GRD_S_C1_3,
BLOCK_COMBI_GRD_S_C1_4,
BLOCK_COMBI_GRD_S_C1_5,
BLOCK_COMBI_GRD_S_C2_2,
BLOCK_COMBI_GRD_S_R1_2,
BLOCK_COMBI_GRD_S_R1_3,
BLOCK_COMBI_GRD_S_R4_2,
BLOCK_COMBI_GRD_S_R5_2,
BLOCK_COMBI_GRD_S_R7_2,
BLOCK_COMBI_GRD_S_R7_3,
BLOCK_COMBI_GRD_S_C2_S_2,
BLOCK_COMBI_GRD_S_C1_S_3,
BLOCK_COMBI_GRD_S_C4_S_2,
BLOCK_COMBI_GRD_S_C5_S_2,
BLOCK_COMBI_GRD_S_C6_R1_2,
BLOCK_COMBI_GRD_S_C3_R1_2,
BLOCK_COMBI_GRD_S_C3_2,
BLOCK_COMBI_GRD_S_C7_3,
BLOCK_COMBI_GRD_S_C1_R2_2,
BLOCK_COMBI_GRD_S_C1_R3_2,
BLOCK_COMBI_GRD_S_C4_2,
BLOCK_COMBI_GRD_S_C5_2,
BLOCK_COMBI_GRD_S_C6_2,
BLOCK_COMBI_GRD_S_R2_2,
BLOCK_COMBI_GRD_S_R3_2,
BLOCK_COMBI_GRD_S_C4_R1_2,
BLOCK_COMBI_GRD_S_C4_R2_2,
BLOCK_COMBI_GRD_S_C7_R1_2,
BLOCK_COMBI_GRD_S_R6_2,
BLOCK_COMBI_GRD_S_C5_R2_2,
BLOCK_COMBI_GRD_S_C4_R3_2,
BLOCK_COMBI_GRD_S_R2_3,
BLOCK_COMBI_GRD_S_R3_3,
BLOCK_COMBI_GRD_S_C5_R3_2,
BLOCK_COMBI_GRD_S_C5_3,
BLOCK_COMBI_GRD_S_C4_3,
BLOCK_COMBI_GRD_S_C3_3,
BLOCK_COMBI_GRD_S_C2_3,
BLOCK_COMBI_POLICE_INDOOR,
BLOCK_COMBI_GRD_S_R1_P_1,
BLOCK_COMBI_GRD_S_C1_R1_2,
BLOCK_COMBI_GRD_S_C1_R1_3,
BLOCK_COMBI_GRD_S_C1_R2_3,
BLOCK_COMBI_GRD_S_C1_R3_3,
BLOCK_COMBI_GRD_S_C2_R1_2,
BLOCK_COMBI_GRD_S_C5_R1_2,
BLOCK_COMBI_GRD_S_C6_3,
BLOCK_COMBI_GRD_S_C7_2,
BLOCK_COMBI_GRD_S_R1_4,
BLOCK_COMBI_GRD_S_R2_4,
BLOCK_COMBI_GRD_S_R3_4,
BLOCK_COMBI_GRD_S_R4_3,
BLOCK_COMBI_GRD_S_R5_3,
BLOCK_COMBI_GRD_S_R6_3,
BLOCK_COMBI_GRD_S_T_10_146,
BLOCK_COMBI_GRD_S_T_10_147,
BLOCK_COMBI_GRD_S_F_1_148,
BLOCK_COMBI_GRD_S_C2_R2_2,
BLOCK_COMBI_GRD_S_C3_R2_2,
BLOCK_COMBI_GRD_S_R1_B_2,
BLOCK_COMBI_GRD_S_R2_B_2,
BLOCK_COMBI_GRD_S_R4_B_2,
BLOCK_COMBI_GRD_S_R3_B_2,
BLOCK_COMBI_GRD_S_R5_B_2,
BLOCK_COMBI_GRD_S_R6_B_2,
BLOCK_COMBI_GRD_S_R7_B_2,
BLOCK_COMBI_GRD_S_R1_B_3,
BLOCK_COMBI_GRD_S_R2_B_3,
BLOCK_COMBI_GRD_S_R3_B_3,
BLOCK_COMBI_GRD_S_F_3,
BLOCK_COMBI_GRD_S_F_4,
BLOCK_COMBI_GRD_S_F_5,
BLOCK_COMBI_GRD_S_F_6,
BLOCK_COMBI_GRD_S_F_7,
BLOCK_COMBI_GRD_S_F_8,
BLOCK_COMBI_GRD_S_F_9,
BLOCK_COMBI_GRD_S_F_10,
BLOCK_COMBI_GRD_S_T_2,
BLOCK_COMBI_GRD_S_T_3,
BLOCK_COMBI_GRD_S_T_4,
BLOCK_COMBI_GRD_S_T_5,
BLOCK_COMBI_GRD_S_T_6,
BLOCK_COMBI_GRD_S_T_7,
BLOCK_COMBI_GRD_S_T_8,
BLOCK_COMBI_GRD_S_T_9,
BLOCK_COMBI_GRD_S_T_10,
BLOCK_COMBI_GRD_S_T_R1_2,
BLOCK_COMBI_GRD_S_T_R1_3,
BLOCK_COMBI_GRD_S_T_R1_4,
BLOCK_COMBI_GRD_S_T_R1_5,
BLOCK_COMBI_GRD_S_R2_P_1,
BLOCK_COMBI_GRD_S_R3_P_1,
BLOCK_COMBI_GRD_S_F_1_180,
BLOCK_COMBI_GRD_S_F_1_181,
BLOCK_COMBI_GRD_S_F_1_182,
BLOCK_COMBI_GRD_S_F_1_183,
BLOCK_COMBI_GRD_S_F_1_184,
BLOCK_COMBI_GRD_S_R1_1_185,
BLOCK_COMBI_GRD_S_R6_P_1,
BLOCK_COMBI_GRD_S_R7_P_1,
BLOCK_COMBI_GRD_S_T_ST1_2,
BLOCK_COMBI_GRD_S_T_ST1_3,
BLOCK_COMBI_GRD_S_R4_P_1,
BLOCK_COMBI_GRD_S_R5_P_1,
BLOCK_COMBI_ROM_URANAI,
BLOCK_COMBI_GRD_PLAYER_SELECT,
BLOCK_COMBI_ROM_MY_ROOM_S,
BLOCK_COMBI_ROM_MY_ROOM_M,
BLOCK_COMBI_GRD_S_F_9_1,
BLOCK_COMBI_GRD_S_R1_3_1,
BLOCK_COMBI_GRD_S_C1_3_1,
BLOCK_COMBI_GRD_S_F_9_2,
BLOCK_COMBI_GRD_S_C1_S_4,
BLOCK_COMBI_GRD_S_E1_1,
BLOCK_COMBI_GRD_S_E1_R1_1,
BLOCK_COMBI_GRD_S_E2_1,
BLOCK_COMBI_GRD_S_E2_C1_1,
BLOCK_COMBI_GRD_S_E2_T_1,
BLOCK_COMBI_GRD_S_E3_1,
BLOCK_COMBI_GRD_S_E3_C1_1,
BLOCK_COMBI_GRD_S_E3_T_1,
BLOCK_COMBI_GRD_S_E4_1,
BLOCK_COMBI_GRD_S_E5_1,
BLOCK_COMBI_GRD_S_F_KO_1,
BLOCK_COMBI_GRD_S_F_KO_2,
BLOCK_COMBI_GRD_S_F_KO_3,
BLOCK_COMBI_GRD_S_F_MH_1,
BLOCK_COMBI_GRD_S_F_MH_2,
BLOCK_COMBI_GRD_S_F_MH_3,
BLOCK_COMBI_GRD_S_F_PK_1,
BLOCK_COMBI_GRD_S_F_PK_2,
BLOCK_COMBI_GRD_S_F_PK_3,
BLOCK_COMBI_GRD_S_T_PO_1,
BLOCK_COMBI_GRD_S_T_SH_1,
BLOCK_COMBI_GRD_S_T_SH_2,
BLOCK_COMBI_GRD_S_T_SH_3,
BLOCK_COMBI_GRD_S_T_PO_2,
BLOCK_COMBI_GRD_S_T_PO_3,
BLOCK_COMBI_GRD_226,
BLOCK_COMBI_ROM_SHOP2,
BLOCK_COMBI_ROM_SHOP4_1,
BLOCK_COMBI_ROM_SHOP4_2,
BLOCK_COMBI_ROM_SHOP3,
BLOCK_COMBI_GRD_S_HOLE_TEST,
BLOCK_COMBI_GRD_S_M_1_232,
BLOCK_COMBI_GRD_S_M_2_233,
BLOCK_COMBI_GRD_S_M_1_234,
BLOCK_COMBI_GRD_S_M_2_235,
BLOCK_COMBI_GRD_S_M_R1_1,
BLOCK_COMBI_GRD_S_E2_M_1,
BLOCK_COMBI_GRD_S_E3_M_1,
BLOCK_COMBI_ROM_KAMAKURA,
BLOCK_COMBI_GRD_S_M_R1_2,
BLOCK_COMBI_GRD_S_M_R1_3,
BLOCK_COMBI_GRD_S_M_R1_4,
BLOCK_COMBI_GRD_S_M_R1_5,
BLOCK_COMBI_GRD_S_M_R1_B_1,
BLOCK_COMBI_GRD_S_M_R1_B_2,
BLOCK_COMBI_GRD_S_M_R1_B_3,
BLOCK_COMBI_GRD_247,
BLOCK_COMBI_GRD_248,
BLOCK_COMBI_GRD_249,
BLOCK_COMBI_GRD_250,
BLOCK_COMBI_GRD_251,
BLOCK_COMBI_GRD_S_M_3,
BLOCK_COMBI_GRD_S_M_4,
BLOCK_COMBI_GRD_S_M_5,
BLOCK_COMBI_GRD_S_M_6,
BLOCK_COMBI_GRD_S_M_7,
BLOCK_COMBI_GRD_S_M_8,
BLOCK_COMBI_GRD_S_M_9,
BLOCK_COMBI_GRD_S_M_10,
BLOCK_COMBI_GRD_S_C2_S_3,
BLOCK_COMBI_GRD_S_C7_R3_2,
BLOCK_COMBI_GRD_S_C7_S_2,
BLOCK_COMBI_GRD_S_C7_S_3,
BLOCK_COMBI_GRD_S_R1_P_1_264,
BLOCK_COMBI_GRD_S_C7_S_3_265,
BLOCK_COMBI_GRD_S_F_1_266,
BLOCK_COMBI_GRD_S_C2_1_267,
BLOCK_COMBI_GRD_S_C5_1_268,
BLOCK_COMBI_GRD_S_M_R1_B_2_269,
BLOCK_COMBI_GRD_S_R6_1_270,
BLOCK_COMBI_GRD_S_R3_1_271,
BLOCK_COMBI_GRD_S_C1_S_1_272,
BLOCK_COMBI_GRD_S_M_3_273,
BLOCK_COMBI_GRD_S_R1_B_1_274,
BLOCK_COMBI_GRD_S_C5_1_275,
BLOCK_COMBI_GRD_S_C7_1_276,
BLOCK_COMBI_GRD_S_F_1_277,
BLOCK_COMBI_ROM_MUSEUM1,
BLOCK_COMBI_ROM_MUSEUM3,
BLOCK_COMBI_ROM_MUSEUM2,
BLOCK_COMBI_ROM_MUSEUM4,
BLOCK_COMBI_ROM_MUSEUM5,
BLOCK_COMBI_GRD_S_F_1_283,
BLOCK_COMBI_GRD_S_F_1_284,
BLOCK_COMBI_GRD_S_C1_R1_1_285,
BLOCK_COMBI_GRD_S_R1_2_286,
BLOCK_COMBI_ROM_TAILOR,
BLOCK_COMBI_GRD_S_F_MU_1,
BLOCK_COMBI_GRD_S_F_MU_2,
BLOCK_COMBI_GRD_S_F_MU_3,
BLOCK_COMBI_GRD_S_M_TA_1,
BLOCK_COMBI_GRD_S_M_TA_2,
BLOCK_COMBI_GRD_S_M_TA_3,
BLOCK_COMBI_GRD_S_M_WF_1,
BLOCK_COMBI_GRD_S_O_1_295,
BLOCK_COMBI_GRD_S_IR_1,
BLOCK_COMBI_GRD_S_IL_1,
BLOCK_COMBI_GRD_305,
BLOCK_COMBI_GRD_306,
BLOCK_COMBI_GRD_307,
BLOCK_COMBI_GRD_308,
BLOCK_COMBI_GRD_309,
BLOCK_COMBI_GRD_310,
BLOCK_COMBI_GRD_311,
BLOCK_COMBI_GRD_312,
BLOCK_COMBI_GRD_313,
BLOCK_COMBI_GRD_314,
BLOCK_COMBI_GRD_315,
BLOCK_COMBI_GRD_316,
BLOCK_COMBI_GRD_317,
BLOCK_COMBI_GRD_318,
BLOCK_COMBI_GRD_S_O_1_312,
BLOCK_COMBI_GRD_S_O_1_313,
BLOCK_COMBI_GRD_S_O_2_314,
BLOCK_COMBI_GRD_S_O_2_315,
BLOCK_COMBI_GRD_S_O_2_316,
BLOCK_COMBI_GRD_S_O_2_317,
BLOCK_COMBI_GRD_S_O_3_318,
BLOCK_COMBI_GRD_S_O_3_319,
BLOCK_COMBI_GRD_S_O_3_320,
BLOCK_COMBI_GRD_S_O_4_322,
BLOCK_COMBI_GRD_S_O_4_323,
BLOCK_COMBI_GRD_S_O_4_324,
BLOCK_COMBI_GRD_S_O_4_325,
BLOCK_COMBI_GRD_S_O_4_326,
BLOCK_COMBI_GRD_S_E2_O_1,
BLOCK_COMBI_GRD_S_E3_O_1,
BLOCK_COMBI_GRD_S_O_1_328,
BLOCK_COMBI_GRD_S_O_2_329,
BLOCK_COMBI_GRD_S_O_3_330,
BLOCK_COMBI_GRD_S_O_4_331,
BLOCK_COMBI_GRD_S_O_5,
BLOCK_COMBI_GRD_S_O_6,
BLOCK_COMBI_GRD_S_O_7,
BLOCK_COMBI_GRD_S_O_8,
BLOCK_COMBI_GRD_S_O_9,
BLOCK_COMBI_GRD_S_O_10,
BLOCK_COMBI_GRD_S_O_R1_1,
BLOCK_COMBI_GRD_S_O_R1_2,
BLOCK_COMBI_GRD_S_O_R1_3,
BLOCK_COMBI_GRD_S_O_R1_4,
BLOCK_COMBI_GRD_S_O_R1_5,
BLOCK_COMBI_GRD_S_O_R1_B_1,
BLOCK_COMBI_GRD_S_O_R1_B_2,
BLOCK_COMBI_GRD_S_O_R1_B_3,
BLOCK_COMBI_GRD_S_O_TA_1,
BLOCK_COMBI_GRD_S_O_TA_2,
BLOCK_COMBI_GRD_S_O_TA_3,
BLOCK_COMBI_GRD_S_O_WF_1,
BLOCK_COMBI_GRD_S_O_I_1_350,
BLOCK_COMBI_GRD_S_O_I_1_351,
BLOCK_COMBI_GRD_S_O_I_2_352,
BLOCK_COMBI_GRD_S_O_I_2_353,
BLOCK_COMBI_GRD_S_O_I_2_354,
BLOCK_COMBI_GRD_S_O_I_2_355,
BLOCK_COMBI_ROM_TOUDAI,
BLOCK_COMBI_GRD_S_IR_2,
BLOCK_COMBI_GRD_S_IL_2,
BLOCK_COMBI_GRD_S_IR_3,
BLOCK_COMBI_GRD_S_IL_3,
BLOCK_COMBI_GRD_S_IR_4,
BLOCK_COMBI_GRD_S_IL_4,
BLOCK_COMBI_GRD_S_M_WF_2,
BLOCK_COMBI_GRD_S_M_WF_3,
BLOCK_COMBI_GRD_S_O_WF_2,
BLOCK_COMBI_GRD_S_O_WF_3,
BLOCK_COMBI_ROM_TENT,
BLOCK_COMBI_NUM
};
enum {
mFM_BLOCK_TYPE_BORDER_CLIFF_TOP,
mFM_BLOCK_TYPE_BORDER_CLIFF_RIVER,
mFM_BLOCK_TYPE_BORDER_CLIFF_LEFT,
mFM_BLOCK_TYPE_3,
mFM_BLOCK_TYPE_BORDER_CLIFF_RIGHT,
mFM_BLOCK_TYPE_BORDER_CLIFF_CORNER_TOP_LEFT,
mFM_BLOCK_TYPE_6,
mFM_BLOCK_TYPE_TRACKS,
mFM_BLOCK_TYPE_BORDER_CLIFF_CORNER_TOP_RIGHT,
mFM_BLOCK_TYPE_BORDER_CLIFF_LEFT_TUNNEL,
mFM_BLOCK_TYPE_BORDER_CLIFF_RIGHT_TUNNEL,
mFM_BLOCK_TYPE_TRACKS_STATION,
mFM_BLOCK_TYPE_TRACKS_DUMP,
mFM_BLOCK_TYPE_TRACKS_RIVER,
mFM_BLOCK_TYPE_PLAYER_HOUSE,
mFM_BLOCK_TYPE_CLIFF_HORIZONTAL,
mFM_BLOCK_TYPE_CLIFF_BOTTOM_RIGHT_CORNER,
mFM_BLOCK_TYPE_CLIFF_VERTICAL_RIGHT,
mFM_BLOCK_TYPE_CLIFF_TOP_RIGHT_CORNER,
mFM_BLOCK_TYPE_CLIFF_TOP_LEFT_CORNER,
mFM_BLOCK_TYPE_CLIFF_VERTICAL_LEFT,
mFM_BLOCK_TYPE_CLIFF_BOTTOM_LEFT_CORNER,
mFM_BLOCK_TYPE_WATERFALL_STRAIGHT_CLIFF_HORIZONTAL,
mFM_BLOCK_TYPE_WATERFALL_STRAIGHT_CLIFF_BOTTOM_RIGHT_CORNER,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_VERTICAL_RIGHT,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_TOP_RIGHT_CORNER,
mFM_BLOCK_TYPE_WATERFALL_STRAIGHT_CLIFF_TOP_LEFT_CORNER,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_VERTICAL_LEFT,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_BOTTOM_LEFT_CORNER,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_HORIZONTAL,
mFM_BLOCK_TYPE_WATERFALL_EAST_CLIFF_BOTTOM_RIGHT_CORNER,
mFM_BLOCK_TYPE_WATERFALL_EAST_CLIFF_VERTICAL_RIGHT,
mFM_BLOCK_TYPE_RIVER_EAST_CLIFF_TOP_RIGHT_CORNER,
mFM_BLOCK_TYPE_RIVER_EAST_CLIFF_TOP_LEFT_CORNER,
mFM_BLOCK_TYPE_RIVER_WEST_CLIFF_HORIZONTAL,
mFM_BLOCK_TYPE_RIVER_WEST_CLIFF_TOP_RIGHT_CORNER,
mFM_BLOCK_TYPE_RIVER_WEST_CLIFF_TOP_LEFT_CORNER,
mFM_BLOCK_TYPE_WATERFALL_WEST_CLIFF_VERTICAL_LEFT,
mFM_BLOCK_TYPE_WATERFALL_WEST_CLIFF_BOTTOM_LEFT_CORNER,
mFM_BLOCK_TYPE_FLAT,
mFM_BLOCK_TYPE_RIVER_SOUTH,
mFM_BLOCK_TYPE_RIVER_EAST,
mFM_BLOCK_TYPE_RIVER_WEST,
mFM_BLOCK_TYPE_RIVER_SOUTH_EAST,
mFM_BLOCK_TYPE_RIVER_EAST_SOUTH,
mFM_BLOCK_TYPE_RIVER_SOUTH_WEST,
mFM_BLOCK_TYPE_RIVER_WEST_SOUTH,
mFM_BLOCK_TYPE_RIVER_SOUTH_BRIDGE,
mFM_BLOCK_TYPE_RIVER_EAST_BRIDGE,
mFM_BLOCK_TYPE_RIVER_WEST_BRIDGE,
mFM_BLOCK_TYPE_RIVER_SOUTH_EAST_BRIDGE,
mFM_BLOCK_TYPE_RIVER_EAST_SOUTH_BRIDGE,
mFM_BLOCK_TYPE_RIVER_SOUTH_WEST_BRIDGE,
mFM_BLOCK_TYPE_RIVER_WEST_SOUTH_BRIDGE,
mFM_BLOCK_TYPE_SLOPE_HORIZONTAL,
mFM_BLOCK_TYPE_SLOPE_BOTTOM_RIGHT_CORNER,
mFM_BLOCK_TYPE_SLOPE_VERTICAL_RIGHT,
mFM_BLOCK_TYPE_SLOPE_TOP_RIGHT_CORNER,
mFM_BLOCK_TYPE_SLOPE_TOP_LEFT_CORNER,
mFM_BLOCK_TYPE_SLOPE_VERTICAL_LEFT,
mFM_BLOCK_TYPE_SLOPE_BOTTOM_LEFT_CORNER,
mFM_BLOCK_TYPE_BORDER_CLIFF_LEFT_TRANSITION,
mFM_BLOCK_TYPE_BORDER_CLIFF_RIGHT_TRANSITION,
mFM_BLOCK_TYPE_BEACH,
mFM_BLOCK_TYPE_BEACH_RIVER,
mFM_BLOCK_TYPE_TRACKS_SHOP,
mFM_BLOCK_TYPE_SHRINE,
mFM_BLOCK_TYPE_TRACKS_POST_OFFICE,
mFM_BLOCK_TYPE_POLICE_BOX,
mFM_BLOCK_TYPE_POOL_SOUTH,
mFM_BLOCK_TYPE_POOL_EAST,
mFM_BLOCK_TYPE_POOL_WEST,
mFM_BLOCK_TYPE_POOL_SOUTH_EAST,
mFM_BLOCK_TYPE_POOL_EAST_SOUTH,
mFM_BLOCK_TYPE_POOL_SOUTH_WEST,
mFM_BLOCK_TYPE_POOL_WEST_SOUTH,
mFM_BLOCK_TYPE_TRACKS6,
mFM_BLOCK_TYPE_TRACKS7,
mFM_BLOCK_TYPE_TRACKS8,
mFM_BLOCK_TYPE_TRACKS9,
mFM_BLOCK_TYPE_BORDER_CLIFF_OCEAN_LEFT,
mFM_BLOCK_TYPE_BORDER_CLIFF_OCEAN_RIGHT,
mFM_BLOCK_TYPE_BEACH_RIVER_BRIDGE,
mFM_BLOCK_TYPE_OCEAN,
mFM_BLOCK_TYPE_MUSEUM,
mFM_BLOCK_TYPE_NEEDLEWORK,
mFM_BLOCK_TYPE_TRACKS_RIVER_BRIDGE,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_HORIZONTAL_BRIDGE,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_VERTICAL_RIGHT_BRIDGE,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_TOP_RIGHT_CORNER_BRIDGE,
mFM_BLOCK_TYPE_RIVER_EAST_CLIFF_TOP_RIGHT_CORNER_BRIDGE,
mFM_BLOCK_TYPE_RIVER_EAST_CLIFF_TOP_LEFT_CORNER_BRIDGE,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_VERTICAL_LEFT_BRIDGE,
mFM_BLOCK_TYPE_RIVER_STRAIGHT_CLIFF_BOTTOM_LEFT_CORNER_BRIDGE,
mFM_BLOCK_TYPE_OCEAN_2,
mFM_BLOCK_TYPE_OCEAN_3,
mFM_BLOCK_TYPE_OCEAN_4,
mFM_BLOCK_TYPE_OCEAN_5,
mFM_BLOCK_TYPE_ISLAND_LEFT,
mFM_BLOCK_TYPE_ISLAND_RIGHT,
mFM_BLOCK_TYPE_PORT,
mFM_BLOCK_TYPE_SEA_EXCEPTIONAL,
mFM_BLOCK_TYPE_OCEAN_6,
mFM_BLOCK_TYPE_OCEAN_7,
mFM_BLOCK_TYPE_OCEAN_8,
mFM_BLOCK_TYPE_RIVER_WEST_CLIFF_HORIZONTAL_BRIDGE,
mFM_BLOCK_TYPE_RIVER_WEST_CLIFF_TOP_RIGHT_CORNER_BRIDGE,
mFM_BLOCK_TYPE_RIVER_WEST_CLIFF_TOP_LEFT_CORNER_BRIDGE,
mFM_BLOCK_TYPE_NUM,
mFM_BLOCK_TYPE_NONE = 255
};
typedef struct block_combination_s {
u16 combination_type : 14;
u16 height : 2;
} mFM_combination_c;
typedef struct fg_items_s {
mActor_name_t items[16 ][16 ];
} mFM_fg_c;
typedef struct block_combo_s {
mActor_name_t bg_id;
mActor_name_t fg_id;
u8 type;
} mFM_combo_info_c;
typedef struct field_display_list_info_s {
int block_x;
int block_z;
u32 dma_loaded;
} mFM_field_draw_info_c;
typedef struct field_pal_s {
u16* earth_pal;
u16* cliff_pal;
u16* bush_pal;
u16* flower0_pal;
u16* flower1_pal;
u16* flower2_pal;
u16* grass_pal;
u16* tree_pal;
u16* cedar_tree_pal;
u16* palm_tree_pal;
u16* golden_tree_pal;
} mFM_field_pal_c;
typedef struct field_bg_sound_source_s {
s16 kind;
xyz_t pos;
} mFM_bg_sound_source_c;
typedef struct field_bg_info_s {
mFM_combination_c bg_id;
Gfx* opaque_gfx;
Gfx* translucent_gfx;
EVW_ANIME_DATA* animation;
s8 animation_count;
u8 block_type;
u32 block_kind;
int rom_start_addr;
int rom_size;
mCoBG_Collision_u collision[16 ][16 ];
u8 keep_h[16 ][16 ];
mFM_bg_sound_source_c sound_source[6 ];
} mFM_bg_info_c;
typedef struct field_fg_move_actor_s {
mActor_name_t name_id;
u8 ut_x;
u8 ut_z;
s8 npc_info_idx;
s16 arg;
} mFM_move_actor_c;
typedef struct field_fg_move_actor_data_s {
mActor_name_t name_id;
int block_x;
int block_z;
u8 ut_x;
u8 ut_z;
s8 npc_info_idx;
s16 arg;
u32 desired_block_kind;
} mFM_move_actor_data_c;
typedef struct field_fg_info_s {
mActor_name_t fg_id;
mActor_name_t* items_p;
u16* deposit_p;
mFM_move_actor_c move_actors[16 ];
u16 move_actor_bit_data;
u8 haniwa_step[4 ];
} mFM_fg_info_c;
typedef struct field_block_info_s {
mFM_bg_info_c bg_info;
mFM_fg_info_c fg_info;
} mFM_block_info_c;
typedef struct field_bg_sound_source_data_s {
s16 kind;
u8 ut_x;
u8 ut_z;
} mFM_bg_sound_source_data_c;
typedef struct field_bg_data_s {
mActor_name_t bg_id;
Gfx* opaque_gfx;
Gfx* translucent_gfx;
EVW_ANIME_DATA* animation;
s8 animation_count;
u32 rom_start_addr;
u32 rom_end_addr;
mCoBG_Collision_u collision[16 ][16 ];
mFM_bg_sound_source_data_c sound_source[6 ];
} mFM_bg_data_c;
typedef struct field_fg_data_s {
mActor_name_t fg_id;
mActor_name_t items[16 ][16 ];
u8 haniwa_step[4 ];
} mFM_fg_data_c;
typedef struct field_data_s {
mActor_name_t field_name;
u8 block_x_max;
u8 block_z_max;
mFM_combination_c combi[(7 * 10) ];
mFM_move_actor_data_c* move_actor_data;
u32 _94;
u32 _98;
u32 _9C;
u32 _A0;
} mFM_field_data_c;
typedef struct field_info_s {
mActor_name_t field_id;
u32 _04;
mFM_field_draw_info_c bg_draw_info[4 ];
u8* bg_display_list_p[4 ];
mFM_field_pal_c field_palette;
mFM_block_info_c* block_info;
mActor_name_t** fg2_p;
int last_bg_idx[4 ];
u16 bg_max;
u8 bg_num;
u8 update_fg;
u8 born_item;
u8 born_actor;
u8 block_x_max;
u8 block_z_max;
} mFM_fdinfo_c;
enum {
mFM_BG_TEX_TRIANGLE,
mFM_BG_TEX_SQUARE,
mFM_BG_TEX_CIRCLE,
mFM_BG_TEX_NUM
};
extern u8* g_block_type_p;
extern int* g_block_kind_p;
extern mFM_fdinfo_c* g_fdinfo;
extern int l_bg_disp_num;
extern int l_bg_disp_size;
extern mFM_bg_data_c data_bgd[];
extern int data_bgd_number;
extern void mFM_GetPolicePos(int* bx, int* bz, int* ut_x, int* ut_z);
extern void mFM_DecideBgTexIdx(u8* bg_tex_idx);
extern void mFM_SetFieldInitData(int bg_disp_num, int bg_disp_size);
extern void mFM_FieldInit(GAME_PLAY* play);
extern void mFM_Field_dt();
extern void mFM_SetBlockKindLoadCombi();
extern void mFM_InitFgCombiSaveData(GAME* game);
extern void mFM_RenewalReserve();
extern mActor_name_t mFM_GetReseveName(int bx, int bz);
extern void mFM_toSummer();
extern void mFM_returnSeason();
extern void mFM_RestoreIslandBG(int* island_x_blocks, int bx_num);
extern void mFM_SetIslandNpcRoomData(GAME* game, int malloc_flag);
enum ftr_name {
FTR_SUM_HAL_CHEST02,
FTR_SUM_CLCHEST03,
FTR_SUM_BLUE_BUREAU01,
FTR_KOB_LOCKER1,
FTR_SUM_X_CHEST01,
FTR_SUM_WHI_CHEST02,
FTR_SUM_RATAN_CHEST02,
FTR_SUM_LOG_CHEST02,
FTR_SUM_LICCACHEST,
FTR_SUM_GRE_CHEST02,
FTR_SUM_FRUITCHEST03,
FTR_SUM_CONT_CHEST02,
FTR_SUM_BLUE_CAB01,
FTR_SUM_BLA_CHEST03,
FTR_SUM_ASI_CHEST03,
FTR_SUM_X_CHEST02,
FTR_SUM_WHI_CHEST01,
FTR_SUM_RATAN_CHEST01,
FTR_SUM_LOG_CHEST01,
FTR_SUM_LICCALOWCHEST,
FTR_SUM_HAL_CHEST03,
FTR_SUM_GRE_CHEST03,
FTR_SUM_FRUITCHEST01,
FTR_SUM_CONT_CHEST03,
FTR_SUM_CLASSICCHEST01,
FTR_SUM_BLUE_LOWCHEST01,
FTR_SUM_BLA_CHEST01,
FTR_SUM_ASI_CHEST02,
FTR_NOG_TRI_CHEST01,
FTR_NOG_TRI_CHEST02,
FTR_NOG_TRI_CHEST03,
FTR_NKH_BOX01,
FTR_IKE_JPN_STEP01,
FTR_IKE_JPN_SAI01,
FTR_NOG_FAN01,
FTR_NKH_LIGHT01,
FTR_NKH_TABLE01,
FTR_NKH_TABLE02,
FTR_NKH_WALL01,
FTR_NKH_ZAB01,
FTR_NKH_BOARD01,
FTR_ARI_ISU01,
FTR_ARI_TABLE01,
FTR_ARI_REIZOU01,
FTR_SUM_CHEST01,
FTR_SUM_CHEST02,
FTR_SUM_SOFE01,
FTR_SUM_SOFE02,
FTR_IKE_JPN_HIBATI01,
FTR_ARI_KITCHEN01,
FTR_SUM_SOFE03,
FTR_IKE_JPN_TANSU01,
FTR_IKE_JPN_KOTATU01,
FTR_IKE_JPN_KOTATU02,
FTR_SUM_GUITAR01,
FTR_SUM_GUITAR02,
FTR_SUM_GUITAR03,
FTR_SUM_DOLL01,
FTR_SUM_DOLL02,
FTR_SUM_DOLL03,
FTR_SUM_DOLL04,
FTR_SUM_CLASSICCABINET01,
FTR_SUM_CLASSICCHAIR01,
FTR_SUM_CLASSICCHEST02,
FTR_SUM_CLASSICTABLE01,
FTR_SUM_CLASSICWARDROPE01,
FTR_SUM_CLCHAIR02,
FTR_SUM_CUPBOARD01,
FTR_SUM_DESK01,
FTR_SUM_DOLL05,
FTR_SUM_DOLL06,
FTR_SUM_DOLL07,
FTR_SUM_DOLL08,
FTR_SUM_DOLL09,
FTR_SUM_DOLL10,
FTR_SUM_GLOBE01,
FTR_SUM_KITCHAIR01,
FTR_SUM_KITTABLE01,
FTR_SUM_TV01,
FTR_SUM_TOTEMP01,
FTR_SUM_TOTEMP02,
FTR_SUM_TOTEMP03,
FTR_SUM_TOTEMP04,
FTR_SUM_TAIKO01,
FTR_SUM_STOVE01,
FTR_SUM_STEREO01,
FTR_SUM_RATAN_ISU01,
FTR_SUM_OLDSOFA01,
FTR_SUM_LICCATABLE,
FTR_SUM_LICCASOFA,
FTR_SUM_LICCAPIANO,
FTR_SUM_LICCALANP,
FTR_SUM_LICCAKITCHEN,
FTR_SUM_LICCACHAIR,
FTR_SUM_LICCABED,
FTR_SUM_OLDCLK01,
FTR_SUM_RATAN_BED01,
FTR_SUM_GOLFBAG01,
FTR_SUM_GOLFBAG02,
FTR_SUM_GOLFBAG03,
FTR_SUM_BOOKCHT01,
FTR_SUM_CHAIR01,
FTR_SUM_CONT_SOFA01,
FTR_SUM_CONT_SOFA02,
FTR_SUM_CONT_TABLE01,
FTR_SUM_CONT_CAB01,
FTR_SUM_CONT_CHEST01,
FTR_SUM_CONT_CHAIR01,
FTR_SUM_CONT_BED01,
FTR_SUM_CONT_TABLE02,
FTR_SUM_COMP01,
FTR_KOB_JIMUDESK,
FTR_KOB_MASTERSWORD,
FTR_KOB_NCUBE,
FTR_SUM_TEKIN01,
FTR_SUM_BIWA01,
FTR_SUM_CONGA01,
FTR_SUM_SHOUKAKI,
FTR_SUM_COL_CHAIR01,
FTR_SUM_COL_CHAIR02,
FTR_SUM_COL_CHAIR03,
FTR_SUM_CONPO01,
FTR_KOB_PIPEISU,
FTR_SUM_LICCAMIRROR,
FTR_SUM_PET01,
FTR_SUM_TIMPANI01,
FTR_SUM_SPIKA01,
FTR_SUM_BDCAKE01,
FTR_KOB_S_DESK1,
FTR_KOB_S_DESK2,
FTR_KOB_S_DESK3,
FTR_SUM_SABO01,
FTR_SUM_SABO02,
FTR_SUM_CLBED02,
FTR_SUM_TV02,
FTR_SUM_LICCALOWTABLE,
FTR_SUM_KADOMATU,
FTR_SUM_KAGAMOCHI,
FTR_SUM_TOURO01,
FTR_SUM_TOURO02,
FTR_SUM_TOURO03,
FTR_KOB_JIMUISU,
FTR_KOB_GETABAKO1,
FTR_KOB_GETABAKO2,
FTR_KOB_S_ISU1,
FTR_KOB_S_ISU2,
FTR_KOB_S_ISU3,
FTR_KOB_RIKA_DESK,
FTR_KOB_TYOUREIDAI,
FTR_SUM_TOURO04,
FTR_SUM_TARU01,
FTR_SUM_TARU02,
FTR_KOB_TOBIBAKO,
FTR_KON_TUKUE,
FTR_SUM_MEZACLOCK,
FTR_SUM_POPTABLE01,
FTR_SUM_POPTABLE02,
FTR_SUM_POPTABLE03,
FTR_KON_TUBO,
FTR_SUM_POPCHAIR01,
FTR_SUM_POPCHAIR02,
FTR_SUM_POPCHAIR03,
FTR_SUM_SUBERI01,
FTR_SUM_WC01,
FTR_SUM_WC02,
FTR_TAK_TABLE02,
FTR_TAK_ISU03,
FTR_KON_TUBO2,
FTR_KON_TUBO3,
FTR_SUM_MISIN01,
FTR_SUM_BILLIADS,
FTR_SUM_ART01,
FTR_IKE_ART_ANG,
FTR_IKE_ART_SYA,
FTR_SUM_ART04,
FTR_SUM_ART05,
FTR_SUM_ART06,
FTR_IKE_ART_FEL,
FTR_SUM_ART08,
FTR_SUM_ART09,
FTR_SUM_ART10,
FTR_SUM_ART11,
FTR_SUM_ART12,
FTR_SUM_ART13,
FTR_SUM_ART14,
FTR_SUM_ART15,
FTR_SUM_FRUITBED01,
FTR_SUM_FRUITCHAIR01,
FTR_SUM_FRUITCHEST02,
FTR_SUM_FRUITTABLE01,
FTR_SUM_FRUITTV01,
FTR_SUM_TAKKYU,
FTR_SUM_HARP,
FTR_SUM_LOG_HATOCLK,
FTR_SUM_KISHA,
FTR_SUM_MIZUNOMI,
FTR_SUM_OKIAGARI01,
FTR_SUM_SARU,
FTR_SUM_SLOT,
FTR_SUM_ASI_CHAIR01,
FTR_SUM_ASI_CHAIR02,
FTR_SUM_ASI_CHEST01,
FTR_SUM_ASI_LANP01,
FTR_SUM_PL_CALADIUM01,
FTR_SUM_PL_SHUROCI,
FTR_SUM_ASI_SCREEN01,
FTR_SUM_ASI_TABLE01,
FTR_SUM_ASI_TAIKO,
FTR_SUM_BLA_BED01,
FTR_BLA_CHAIR01,
FTR_SUM_BLA_CHEST02,
FTR_SUM_BLA_DESK01,
FTR_SUM_BLA_SOFA02,
FTR_SUM_BLA_TABLE01,
FTR_SUM_BLUE_BED01,
FTR_SUM_BLUE_BENCH01,
FTR_SUM_BLUE_CHAIR01,
FTR_SUM_BLUE_CHEST01,
FTR_SUM_BLUE_CHEST02,
FTR_SUM_BLUE_TABLE01,
FTR_SUM_GRE_BED01,
FTR_SUM_GRE_CHAIR01,
FTR_SUM_GRE_CHAIR02,
FTR_SUM_GRE_CHEST01,
FTR_SUM_GRE_COUNTER01,
FTR_SUM_GRE_LANP01,
FTR_SUM_GRE_TABLE01,
FTR_SUM_LOG_BED01,
FTR_SUM_LOG_CHAIR01,
FTR_SUM_LOG_CHAIR02,
FTR_SUM_LOG_CHEST03,
FTR_SUM_LOG_TABLE01,
FTR_SUM_PL_ALOE01,
FTR_SUM_PL_ANANAS,
FTR_SUM_PL_COCOS,
FTR_SUM_PL_COMPACTA,
FTR_SUM_PL_DRACAENA,
FTR_SUM_PL_GOMUNOKI,
FTR_SUM_PL_POTHOS,
FTR_SUM_PL_YAMAYASI,
FTR_SUM_FRUITTABLE02,
FTR_SUM_FRUITCHAIR02,
FTR_SUM_PL_BENJYAMI,
FTR_SUM_PL_DRACA02,
FTR_SUM_PL_KUROTON,
FTR_SUM_PL_PAKILA,
FTR_SUM_PL_HIRASABO,
FTR_TAK_METRO,
FTR_KON_SISIODOSI,
FTR_SUM_BON_MATU01,
FTR_SUM_BON_MATU02,
FTR_TAK_BARBER,
FTR_SUM_BON_MATU03,
FTR_SUM_BON_UME,
FTR_NOG_DARUMAL,
FTR_NOG_DARUMAM,
FTR_NOG_DARUMAS,
FTR_SUM_BON_BOKE,
FTR_SUM_BON_SATUKI,
FTR_SUM_BON_SANSHU,
FTR_KON_CRACKER,
FTR_TAK_CONE01,
FTR_TAK_CONE02,
FTR_TAK_CONE03,
FTR_KON_JIHANKI01,
FTR_SUM_BON_MOMIJI,
FTR_SUM_BON_PIRA,
FTR_SUM_BON_TURU,
FTR_TAK_FENCE01,
FTR_TAK_FENCE02,
FTR_TAK_FENCE03,
FTR_TAK_FENCE04,
FTR_KON_JIHANKI02,
FTR_TAK_HOLE01,
FTR_KON_JIHANKI03,
FTR_TAK_DRUM01,
FTR_TAK_DRUM02,
FTR_TAK_DRUM03,
FTR_KON_JIHANKI04,
FTR_TAK_TEKKIN,
FTR_KON_GOMI01,
FTR_KON_GOMI02,
FTR_SUM_FRUITCHAIR03,
FTR_SUM_FRUITCHAIR04,
FTR_SUM_FRUITTABLE03,
FTR_TAK_UDEFURI,
FTR_KON_GOMI03,
FTR_KON_GOMI04,
FTR_SUM_VIOLA01,
FTR_SUM_BASS01,
FTR_SUM_CELLO01,
FTR_SUM_PIANO01,
FTR_KON_CHOUZU01,
FTR_TAK_NEKO,
FTR_KON_CHOUZU02,
FTR_SUM_HAL_PKIN,
FTR_TAK_DENKO,
FTR_TAK_YAJI,
FTR_KON_ISI01,
FTR_KON_ISI02,
FTR_TAK_KANBAN01,
FTR_TAK_KANBAN02,
FTR_TAK_KANBAN03,
FTR_KON_CHOUZU03,
FTR_SUM_HAL_BED01,
FTR_SUM_HAL_BOX01,
FTR_SUM_HAL_CHAIR01,
FTR_SUM_GST_CHAIR01,
FTR_SUM_HAL_CHEST01,
FTR_SUM_HAL_SOFA01,
FTR_SUM_HAL_TABLE01,
FTR_TAK_APOLLO1,
FTR_TAK_EISEI,
FTR_KON_ISI03,
FTR_KON_ISI04,
FTR_KON_ISI05,
FTR_TAK_UFO,
FTR_KON_ISI06,
FTR_KON_POUND,
FTR_TAK_ROCKET1,
FTR_TAK_ASTRO,
FTR_SUM_HAL_CLK01,
FTR_SUM_HAL_LANP01,
FTR_SUM_ASI_BED01,
FTR_SUM_ASI_TABLE02,
FTR_TAK_ASTEROID1,
FTR_SUM_RATAN_LANP,
FTR_SUM_RATAN_TABLE01,
FTR_KON_OKE,
FTR_KON_TAIJU,
FTR_KON_ARAIBA,
FTR_KON_HUROISU,
FTR_SUM_RATAN_SCREEN,
FTR_SUM_RATAN_MIRROR,
FTR_SUM_RATAN_ISU02,
FTR_SUM_RATAN_CHEST03,
FTR_TAK_ARWING,
FTR_TAK_MOONCAR,
FTR_KON_MASAJI,
FTR_KON_MAT,
FTR_KON_YUBUNE,
FTR_SUM_BLUE_CLK,
FTR_TAK_MOTI,
FTR_SUM_HAL_MIRROR01,
FTR_SUM_GRE_DESK01,
FTR_KON_BANDAI,
FTR_SUM_BLA_CHAIR02,
FTR_SUM_BLA_TABLE02,
FTR_TAK_STATION,
FTR_KON_TUITATE,
FTR_SUM_LOG_CHAIR03,
FTR_SUM_WHI_BED01,
FTR_TAK_SHUTTLE,
FTR_SUM_WHI_MIRROR,
FTR_SUM_WHI_SOFA01,
FTR_SUM_WHI_LANP,
FTR_SUM_LOG_TABLE02,
FTR_KON_LOCKER,
FTR_KON_MILK,
FTR_SUM_UWA_CUP01,
FTR_SUM_UWA_POTO01,
FTR_SUM_UWA_VASE01,
FTR_SUM_UWA_VASE02,
FTR_SUM_UWA_VASE03,
FTR_HNW_COMMON000,
FTR_HNW_COMMON001,
FTR_HNW_COMMON002,
FTR_HNW_COMMON003,
FTR_HNW_COMMON004,
FTR_HNW_COMMON005,
FTR_HNW_COMMON006,
FTR_HNW_COMMON007,
FTR_HNW_COMMON008,
FTR_HNW_COMMON009,
FTR_HNW_COMMON010,
FTR_HNW_COMMON011,
FTR_HNW_COMMON012,
FTR_HNW_COMMON013,
FTR_HNW_COMMON014,
FTR_HNW_COMMON015,
FTR_HNW_COMMON016,
FTR_HNW_COMMON017,
FTR_HNW_COMMON018,
FTR_HNW_COMMON019,
FTR_HNW_COMMON020,
FTR_HNW_COMMON021,
FTR_HNW_COMMON022,
FTR_HNW_COMMON023,
FTR_HNW_COMMON024,
FTR_HNW_COMMON025,
FTR_HNW_COMMON026,
FTR_HNW_COMMON027,
FTR_HNW_COMMON028,
FTR_HNW_COMMON029,
FTR_HNW_COMMON030,
FTR_HNW_COMMON031,
FTR_HNW_COMMON032,
FTR_HNW_COMMON033,
FTR_HNW_COMMON034,
FTR_HNW_COMMON035,
FTR_HNW_COMMON036,
FTR_HNW_COMMON037,
FTR_HNW_COMMON038,
FTR_HNW_COMMON039,
FTR_HNW_COMMON040,
FTR_HNW_COMMON041,
FTR_HNW_COMMON042,
FTR_HNW_COMMON043,
FTR_HNW_COMMON044,
FTR_HNW_COMMON045,
FTR_HNW_COMMON046,
FTR_HNW_COMMON047,
FTR_HNW_COMMON048,
FTR_HNW_COMMON049,
FTR_HNW_COMMON050,
FTR_HNW_COMMON051,
FTR_HNW_COMMON052,
FTR_HNW_COMMON053,
FTR_HNW_COMMON054,
FTR_HNW_COMMON055,
FTR_HNW_COMMON056,
FTR_HNW_COMMON057,
FTR_HNW_COMMON058,
FTR_HNW_COMMON059,
FTR_HNW_COMMON060,
FTR_HNW_COMMON061,
FTR_HNW_COMMON062,
FTR_HNW_COMMON063,
FTR_HNW_COMMON064,
FTR_HNW_COMMON065,
FTR_HNW_COMMON066,
FTR_HNW_COMMON067,
FTR_HNW_COMMON068,
FTR_HNW_COMMON069,
FTR_HNW_COMMON070,
FTR_HNW_COMMON071,
FTR_HNW_COMMON072,
FTR_HNW_COMMON073,
FTR_HNW_COMMON074,
FTR_HNW_COMMON075,
FTR_HNW_COMMON076,
FTR_HNW_COMMON077,
FTR_HNW_COMMON078,
FTR_HNW_COMMON079,
FTR_HNW_COMMON080,
FTR_HNW_COMMON081,
FTR_HNW_COMMON082,
FTR_HNW_COMMON083,
FTR_HNW_COMMON084,
FTR_HNW_COMMON085,
FTR_HNW_COMMON086,
FTR_HNW_COMMON087,
FTR_HNW_COMMON088,
FTR_HNW_COMMON089,
FTR_HNW_COMMON090,
FTR_HNW_COMMON091,
FTR_HNW_COMMON092,
FTR_HNW_COMMON093,
FTR_HNW_COMMON094,
FTR_HNW_COMMON095,
FTR_HNW_COMMON096,
FTR_HNW_COMMON097,
FTR_HNW_COMMON098,
FTR_HNW_COMMON099,
FTR_HNW_COMMON100,
FTR_HNW_COMMON101,
FTR_HNW_COMMON102,
FTR_HNW_COMMON103,
FTR_HNW_COMMON104,
FTR_HNW_COMMON105,
FTR_HNW_COMMON106,
FTR_HNW_COMMON107,
FTR_HNW_COMMON108,
FTR_HNW_COMMON109,
FTR_HNW_COMMON110,
FTR_HNW_COMMON111,
FTR_HNW_COMMON112,
FTR_HNW_COMMON113,
FTR_HNW_COMMON114,
FTR_HNW_COMMON115,
FTR_HNW_COMMON116,
FTR_HNW_COMMON117,
FTR_HNW_COMMON118,
FTR_HNW_COMMON119,
FTR_HNW_COMMON120,
FTR_HNW_COMMON121,
FTR_HNW_COMMON122,
FTR_HNW_COMMON123,
FTR_HNW_COMMON124,
FTR_HNW_COMMON125,
FTR_HNW_COMMON126,
FTR_FMANEKIN000,
FTR_FMANEKIN001,
FTR_FMANEKIN002,
FTR_FMANEKIN003,
FTR_FMANEKIN004,
FTR_FMANEKIN005,
FTR_FMANEKIN006,
FTR_FMANEKIN007,
FTR_FMANEKIN008,
FTR_FMANEKIN009,
FTR_FMANEKIN010,
FTR_FMANEKIN011,
FTR_FMANEKIN012,
FTR_FMANEKIN013,
FTR_FMANEKIN014,
FTR_FMANEKIN015,
FTR_FMANEKIN016,
FTR_FMANEKIN017,
FTR_FMANEKIN018,
FTR_FMANEKIN019,
FTR_FMANEKIN020,
FTR_FMANEKIN021,
FTR_FMANEKIN022,
FTR_FMANEKIN023,
FTR_FMANEKIN024,
FTR_FMANEKIN025,
FTR_FMANEKIN026,
FTR_FMANEKIN027,
FTR_FMANEKIN028,
FTR_FMANEKIN029,
FTR_FMANEKIN030,
FTR_FMANEKIN031,
FTR_FMANEKIN032,
FTR_FMANEKIN033,
FTR_FMANEKIN034,
FTR_FMANEKIN035,
FTR_FMANEKIN036,
FTR_FMANEKIN037,
FTR_FMANEKIN038,
FTR_FMANEKIN039,
FTR_FMANEKIN040,
FTR_FMANEKIN041,
FTR_FMANEKIN042,
FTR_FMANEKIN043,
FTR_FMANEKIN044,
FTR_FMANEKIN045,
FTR_FMANEKIN046,
FTR_FMANEKIN047,
FTR_FMANEKIN048,
FTR_FMANEKIN049,
FTR_FMANEKIN050,
FTR_FMANEKIN051,
FTR_FMANEKIN052,
FTR_FMANEKIN053,
FTR_FMANEKIN054,
FTR_FMANEKIN055,
FTR_FMANEKIN056,
FTR_FMANEKIN057,
FTR_FMANEKIN058,
FTR_FMANEKIN059,
FTR_FMANEKIN060,
FTR_FMANEKIN061,
FTR_FMANEKIN062,
FTR_FMANEKIN063,
FTR_FMANEKIN064,
FTR_FMANEKIN065,
FTR_FMANEKIN066,
FTR_FMANEKIN067,
FTR_FMANEKIN068,
FTR_FMANEKIN069,
FTR_FMANEKIN070,
FTR_FMANEKIN071,
FTR_FMANEKIN072,
FTR_FMANEKIN073,
FTR_FMANEKIN074,
FTR_FMANEKIN075,
FTR_FMANEKIN076,
FTR_FMANEKIN077,
FTR_FMANEKIN078,
FTR_FMANEKIN079,
FTR_FMANEKIN080,
FTR_FMANEKIN081,
FTR_FMANEKIN082,
FTR_FMANEKIN083,
FTR_FMANEKIN084,
FTR_FMANEKIN085,
FTR_FMANEKIN086,
FTR_FMANEKIN087,
FTR_FMANEKIN088,
FTR_FMANEKIN089,
FTR_FMANEKIN090,
FTR_FMANEKIN091,
FTR_FMANEKIN092,
FTR_FMANEKIN093,
FTR_FMANEKIN094,
FTR_FMANEKIN095,
FTR_FMANEKIN096,
FTR_FMANEKIN097,
FTR_FMANEKIN098,
FTR_FMANEKIN099,
FTR_FMANEKIN100,
FTR_FMANEKIN101,
FTR_FMANEKIN102,
FTR_FMANEKIN103,
FTR_FMANEKIN104,
FTR_FMANEKIN105,
FTR_FMANEKIN106,
FTR_FMANEKIN107,
FTR_FMANEKIN108,
FTR_FMANEKIN109,
FTR_FMANEKIN110,
FTR_FMANEKIN111,
FTR_FMANEKIN112,
FTR_FMANEKIN113,
FTR_FMANEKIN114,
FTR_FMANEKIN115,
FTR_FMANEKIN116,
FTR_FMANEKIN117,
FTR_FMANEKIN118,
FTR_FMANEKIN119,
FTR_FMANEKIN120,
FTR_FMANEKIN121,
FTR_FMANEKIN122,
FTR_FMANEKIN123,
FTR_FMANEKIN124,
FTR_FMANEKIN125,
FTR_FMANEKIN126,
FTR_FMANEKIN127,
FTR_FMANEKIN128,
FTR_FMANEKIN129,
FTR_FMANEKIN130,
FTR_FMANEKIN131,
FTR_FMANEKIN132,
FTR_FMANEKIN133,
FTR_FMANEKIN134,
FTR_FMANEKIN135,
FTR_FMANEKIN136,
FTR_FMANEKIN137,
FTR_FMANEKIN138,
FTR_FMANEKIN139,
FTR_FMANEKIN140,
FTR_FMANEKIN141,
FTR_FMANEKIN142,
FTR_FMANEKIN143,
FTR_FMANEKIN144,
FTR_FMANEKIN145,
FTR_FMANEKIN146,
FTR_FMANEKIN147,
FTR_FMANEKIN148,
FTR_FMANEKIN149,
FTR_FMANEKIN150,
FTR_FMANEKIN151,
FTR_FMANEKIN152,
FTR_FMANEKIN153,
FTR_FMANEKIN154,
FTR_FMANEKIN155,
FTR_FMANEKIN156,
FTR_FMANEKIN157,
FTR_FMANEKIN158,
FTR_FMANEKIN159,
FTR_FMANEKIN160,
FTR_FMANEKIN161,
FTR_FMANEKIN162,
FTR_FMANEKIN163,
FTR_FMANEKIN164,
FTR_FMANEKIN165,
FTR_FMANEKIN166,
FTR_FMANEKIN167,
FTR_FMANEKIN168,
FTR_FMANEKIN169,
FTR_FMANEKIN170,
FTR_FMANEKIN171,
FTR_FMANEKIN172,
FTR_FMANEKIN173,
FTR_FMANEKIN174,
FTR_FMANEKIN175,
FTR_FMANEKIN176,
FTR_FMANEKIN177,
FTR_FMANEKIN178,
FTR_FMANEKIN179,
FTR_FMANEKIN180,
FTR_FMANEKIN181,
FTR_FMANEKIN182,
FTR_FMANEKIN183,
FTR_FMANEKIN184,
FTR_FMANEKIN185,
FTR_FMANEKIN186,
FTR_FMANEKIN187,
FTR_FMANEKIN188,
FTR_FMANEKIN189,
FTR_FMANEKIN190,
FTR_FMANEKIN191,
FTR_FMANEKIN192,
FTR_FMANEKIN193,
FTR_FMANEKIN194,
FTR_FMANEKIN195,
FTR_FMANEKIN196,
FTR_FMANEKIN197,
FTR_FMANEKIN198,
FTR_FMANEKIN199,
FTR_FMANEKIN200,
FTR_FMANEKIN201,
FTR_FMANEKIN202,
FTR_FMANEKIN203,
FTR_FMANEKIN204,
FTR_FMANEKIN205,
FTR_FMANEKIN206,
FTR_FMANEKIN207,
FTR_FMANEKIN208,
FTR_FMANEKIN209,
FTR_FMANEKIN210,
FTR_FMANEKIN211,
FTR_FMANEKIN212,
FTR_FMANEKIN213,
FTR_FMANEKIN214,
FTR_FMANEKIN215,
FTR_FMANEKIN216,
FTR_FMANEKIN217,
FTR_FMANEKIN218,
FTR_FMANEKIN219,
FTR_FMANEKIN220,
FTR_FMANEKIN221,
FTR_FMANEKIN222,
FTR_FMANEKIN223,
FTR_FMANEKIN224,
FTR_FMANEKIN225,
FTR_FMANEKIN226,
FTR_FMANEKIN227,
FTR_FMANEKIN228,
FTR_FMANEKIN229,
FTR_FMANEKIN230,
FTR_FMANEKIN231,
FTR_FMANEKIN232,
FTR_FMANEKIN233,
FTR_FMANEKIN234,
FTR_FMANEKIN235,
FTR_FMANEKIN236,
FTR_FMANEKIN237,
FTR_FMANEKIN238,
FTR_FMANEKIN239,
FTR_FMANEKIN240,
FTR_FMANEKIN241,
FTR_FMANEKIN242,
FTR_FMANEKIN243,
FTR_FMANEKIN244,
FTR_FMANEKIN245,
FTR_FMANEKIN246,
FTR_FMANEKIN247,
FTR_FMANEKIN248,
FTR_FMANEKIN249,
FTR_FMANEKIN250,
FTR_FMANEKIN251,
FTR_FMANEKIN252,
FTR_FMANEKIN253,
FTR_FMANEKIN254,
FTR_MYFMANEKIN0,
FTR_MYFMANEKIN1,
FTR_MYFMANEKIN2,
FTR_MYFMANEKIN3,
FTR_MYFMANEKIN4,
FTR_MYFMANEKIN5,
FTR_MYFMANEKIN6,
FTR_MYFMANEKIN7,
FTR_SUM_MONSHIRO,
FTR_SUM_MONKI,
FTR_SUM_KIAGEHA,
FTR_SUM_OHMURASAKI,
FTR_SUM_MINMIN,
FTR_SUM_TUKUTUKU,
FTR_SUM_HIGURASHI,
FTR_SUM_ABURA,
FTR_SUM_HACHI,
FTR_SUM_SHIOKARA,
FTR_SUM_AKIAKANE,
FTR_SUM_GINYANMA,
FTR_SUM_ONIYANMA,
FTR_SUM_SYOURYOU,
FTR_SUM_TONOSAMA,
FTR_SUM_KOOROGI,
FTR_SUM_KIRIGIRISU,
FTR_SUM_SUZUMUSHI,
FTR_SUM_MATUMUSHI,
FTR_SUM_KANABUN,
FTR_SUM_KABUTO,
FTR_SUM_HIRATA,
FTR_SUM_TAMAMUSHI,
FTR_SUM_GOMADARA,
FTR_SUM_TENTOU,
FTR_SUM_NANAHOSHI,
FTR_SUM_KAMAKIRI,
FTR_SUM_GENJI,
FTR_SUM_DANNA,
FTR_SUM_NOKOGIRI,
FTR_SUM_MIYAMA,
FTR_SUM_OKUWA,
FTR_NOG_MAIMAI,
FTR_NOG_KERA,
FTR_NOG_AMENBO,
FTR_NOG_MINO,
FTR_NOG_DANGO,
FTR_NOG_KUMO,
FTR_NOG_ARI,
FTR_NOG_KA,
FTR_SUM_FUNA,
FTR_SUM_HERA,
FTR_SUM_KOI,
FTR_SUM_NISIKI,
FTR_SUM_NAMAZU,
FTR_SUM_BASS,
FTR_SUM_BASSM,
FTR_SUM_BASSL,
FTR_SUM_GILL,
FTR_SUM_OONAMAZU,
FTR_SUM_RAIGYO,
FTR_SUM_NIGOI,
FTR_SUM_UGUI,
FTR_SUM_OIKAWA,
FTR_SUM_TANAGO,
FTR_SUM_DOJYO,
FTR_SUM_WAKASAGI,
FTR_SUM_AYU,
FTR_SUM_YAMAME,
FTR_SUM_IWANA,
FTR_SUM_NIJI,
FTR_SUM_ITO,
FTR_SUM_SAKE,
FTR_SUM_KINGYO,
FTR_SUM_PIRANIA,
FTR_SUM_AROANA,
FTR_SUM_UNAGI,
FTR_SUM_DONKO,
FTR_SUM_ANGEL,
FTR_SUM_GUPI,
FTR_SUM_DEMEKIN,
FTR_SUM_KASEKI,
FTR_NOG_ZARIGANI,
FTR_NOG_KAERU,
FTR_NOG_MEDAKA,
FTR_NOG_KURAGE,
FTR_NOG_SUZUKI,
FTR_NOG_TAI,
FTR_NOG_ISIDAI,
FTR_NOG_PIRALUKU,
FTR_FUMBRELLA00,
FTR_FUMBRELLA01,
FTR_FUMBRELLA02,
FTR_FUMBRELLA03,
FTR_FUMBRELLA04,
FTR_FUMBRELLA05,
FTR_FUMBRELLA06,
FTR_FUMBRELLA07,
FTR_FUMBRELLA08,
FTR_FUMBRELLA09,
FTR_FUMBRELLA10,
FTR_FUMBRELLA11,
FTR_FUMBRELLA12,
FTR_FUMBRELLA13,
FTR_FUMBRELLA14,
FTR_FUMBRELLA15,
FTR_FUMBRELLA16,
FTR_FUMBRELLA17,
FTR_FUMBRELLA18,
FTR_FUMBRELLA19,
FTR_FUMBRELLA20,
FTR_FUMBRELLA21,
FTR_FUMBRELLA22,
FTR_FUMBRELLA23,
FTR_FUMBRELLA24,
FTR_FUMBRELLA25,
FTR_FUMBRELLA26,
FTR_FUMBRELLA27,
FTR_FUMBRELLA28,
FTR_FUMBRELLA29,
FTR_FUMBRELLA30,
FTR_FUMBRELLA31,
FTR_MYFUMBRELLA0,
FTR_MYFUMBRELLA1,
FTR_MYFUMBRELLA2,
FTR_MYFUMBRELLA3,
FTR_MYFUMBRELLA4,
FTR_MYFUMBRELLA5,
FTR_MYFUMBRELLA6,
FTR_MYFUMBRELLA7,
FTR_FAMICOM_COMMON00,
FTR_FAMICOM_COMMON01,
FTR_FAMICOM_COMMON02,
FTR_FAMICOM_COMMON03,
FTR_FAMICOM_COMMON04,
FTR_FAMICOM_COMMON05,
FTR_FAMICOM_COMMON06,
FTR_FAMICOM_COMMON07,
FTR_FAMICOM_COMMON08,
FTR_FAMICOM_COMMON09,
FTR_FAMICOM_COMMON10,
FTR_FAMICOM_COMMON11,
FTR_FAMICOM_COMMON12,
FTR_FAMICOM_COMMON13,
FTR_FAMICOM_COMMON14,
FTR_FAMICOM_COMMON15,
FTR_FAMICOM_COMMON16,
FTR_FAMICOM_COMMON17,
FTR_FAMICOM_COMMON18,
FTR_KOB_DISKSYSTEM8,
FTR_SUM_CHIKUON01,
FTR_SUM_CHIKUON02,
FTR_SUM_JUKEBOX,
FTR_SUM_RADIO01,
FTR_SUM_RADIO02,
FTR_SUM_CONPO02,
FTR_SUM_STEREO02,
FTR_SUM_LV_STEREO,
FTR_SUM_X_LANP,
FTR_SUM_X_CHAIR01,
FTR_SUM_X_CHEST03,
FTR_SUM_X_SOFA01,
FTR_SUM_X_BED01,
FTR_SUM_X_CLK,
FTR_SUM_X_TABLE01,
FTR_SUM_X_PIANO,
FTR_SUM_DOLL11,
FTR_SUM_ROBOCONPO,
FTR_SUM_SAICONPO,
FTR_SUM_FRUITCLK,
FTR_SUM_ROBOCLK,
FTR_KON_AMECLOCK,
FTR_KON_ATQCLOCK,
FTR_SUM_RECO01,
FTR_SUM_CASSE01,
FTR_SUM_MD01,
FTR_KON_GRCLOCK,
FTR_KON_WACLOCK,
FTR_KON_REDCLOCK,
FTR_KON_BLUECLOCK,
FTR_KON_MIMICLOCK,
FTR_KON_MANEKI01,
FTR_KON_MANEKI02,
FTR_KON_MUSYA,
FTR_KON_TANUKI,
FTR_KON_KAERU,
FTR_KON_XTREE02,
FTR_NOG_ROOKW,
FTR_NOG_ROOKB,
FTR_NOG_QUEENW,
FTR_NOG_QUEENB,
FTR_NOG_BISHOPW,
FTR_NOG_BISHOPB,
FTR_NOG_KINGW,
FTR_NOG_KINGB,
FTR_NOG_KNIGHTW,
FTR_NOG_KNIGHTB,
FTR_NOG_PAWNW,
FTR_NOG_PAWNB,
FTR_NOG_XTREE,
FTR_NOG_TRI_CLOCK01,
FTR_NOG_TRI_BED01,
FTR_NOG_TRI_TABLE01,
FTR_NOG_TRI_SOFA01,
FTR_NOG_TRI_AUDIO01,
FTR_NOG_TRI_CHAIR01,
FTR_NOG_TRI_RACK01,
FTR_IKE_JPN_TOKONOMA01,
FTR_IKE_JPN_IRORI01,
FTR_SUM_KOKUBAN,
FTR_SUM_BAKETU,
FTR_DIN_TRIKERA_HEAD,
FTR_DIN_TRIKERA_TAIL,
FTR_DIN_TRIKERA_BODY,
FTR_DIN_TREX_HEAD,
FTR_DIN_TREX_TAIL,
FTR_DIN_TREX_BODY,
FTR_DIN_BRONT_HEAD,
FTR_DIN_BRONT_TAIL,
FTR_DIN_BRONT_BODY,
FTR_DIN_STEGO_HEAD,
FTR_DIN_STEGO_TAIL,
FTR_DIN_STEGO_BODY,
FTR_DIN_PTERA_HEAD,
FTR_DIN_PTERA_RWING,
FTR_DIN_PTERA_LWING,
FTR_DIN_HUTABA_HEAD,
FTR_DIN_HUTABA_NECK,
FTR_DIN_HUTABA_BODY,
FTR_DIN_MAMMOTH_HEAD,
FTR_DIN_MAMMOTH_BODY,
FTR_DIN_AMBER,
FTR_DIN_STUMP,
FTR_DIN_AMMONITE,
FTR_DIN_EGG,
FTR_DIN_TRILOBITE,
FTR_SUM_BLA_LANP,
FTR_KON_SNOWFREEZER,
FTR_KON_SNOWTABLE,
FTR_KON_SNOWBED,
FTR_TAK_SNOWISU,
FTR_TAK_SNOWLAMP,
FTR_KON_SNOWSOFA,
FTR_KON_SNOWTV,
FTR_KON_SNOWTANSU,
FTR_KON_SNOWBOX,
FTR_KON_SNOWCLOCK,
FTR_DIN_TRIKERA_DUMMY,
FTR_DIN_TREX_DUMMY,
FTR_DIN_BRONT_DUMMY,
FTR_DIN_PTERA_DUMMY,
FTR_DIN_HUTABA_DUMMY,
FTR_DIN_MAMMOTH_DUMMY,
FTR_DIN_STEGO_DUMMYA,
FTR_DIN_STEGO_DUMMYB,
FTR_DIN_DUMMY,
FTR_TAK_SYOGI,
FTR_IKE_JNY_MAKADA01,
FTR_IKE_PST_POST01,
FTR_IKE_PST_PIG01,
FTR_IKE_PST_TESYU01,
FTR_IKE_JNY_AFMEN01,
FTR_IKE_JNY_ROSIA01,
FTR_HAYAKAWA_FAMICOM,
FTR_IKE_JNY_BOTLE01,
FTR_IKE_JNY_HARIKO01,
FTR_IKE_JNY_MOAI01,
FTR_RADIO_TEST,
FTR_IKE_JNY_GOJYU01,
FTR_IKE_JNY_KIBORI01,
FTR_IKE_JNY_TRUTH01,
FTR_IKE_JNY_SIRSER01,
FTR_IKE_JNY_PISA01,
FTR_TAK_LION,
FTR_IKE_JNY_SYON01,
FTR_IKE_JNY_TOWER01,
FTR_NOG_BALLOON_COMMON0,
FTR_NOG_BALLOON_COMMON1,
FTR_NOG_BALLOON_COMMON2,
FTR_NOG_BALLOON_COMMON3,
FTR_NOG_BALLOON_COMMON4,
FTR_NOG_BALLOON_COMMON5,
FTR_NOG_BALLOON_COMMON6,
FTR_NOG_BALLOON_COMMON7,
FTR_TAK_MEGAMI,
FTR_IKE_JNY_GATE01,
FTR_TAK_MONEY,
FTR_IKE_JNY_NINGYO01,
FTR_NOG_YUBIN,
FTR_NOG_MYHOME2,
FTR_NOG_MYHOME4,
FTR_NOG_KOBAN,
FTR_NOG_MUSEUM,
FTR_TAK_YOROI,
FTR_IKE_K_TUKIMI01,
FTR_IKE_K_MAME01,
FTR_IKE_K_SINNEN01,
FTR_IKE_K_OTOME01,
FTR_NOG_YAMISHOP,
FTR_NOG_URANAI,
FTR_IKE_JNY_SIRSER201,
FTR_IKE_K_TANABATA01,
FTR_TAK_FLAG01,
FTR_TAK_FLAG02,
FTR_NOG_SHOP1,
FTR_IKE_JNY_HOUI01,
FTR_IKE_K_COUNT01,
FTR_IKE_K_TURIS01,
FTR_TAK_TOUDAI,
FTR_IKE_K_SUM01,
FTR_NOG_S_TREE,
FTR_NOG_F_TREE,
FTR_NOG_ZASSOU,
FTR_TAK_TAILOR,
FTR_NOG_DUMP,
FTR_IID_HANABI,
FTR_NOG_SNOWMAN,
FTR_IKE_K_IVEBOY01,
FTR_TAK_FLAG03,
FTR_TAK_MOON,
FTR_IKE_K_KID01,
FTR_IID_NINGYOU,
FTR_NOG_STATION00,
FTR_NOG_STATION01,
FTR_NOG_STATION02,
FTR_NOG_STATION03,
FTR_NOG_STATION04,
FTR_NOG_STATION05,
FTR_NOG_STATION06,
FTR_NOG_STATION07,
FTR_NOG_STATION08,
FTR_NOG_STATION09,
FTR_NOG_STATION10,
FTR_NOG_STATION11,
FTR_NOG_STATION12,
FTR_NOG_STATION13,
FTR_NOG_STATION14,
FTR_NOG_SHRINE,
FTR_NOG_FLAT,
FTR_NOG_RAIL,
FTR_NOG_EARTH,
FTR_IKE_K_KID02,
FTR_NOG_MIKANBOX,
FTR_NOG_COLLEGENOTE,
FTR_NOG_SCHOOLNOTE,
FTR_NOG_SYSTEMNOTE,
FTR_NOG_HARDDIARY,
FTR_NOG_TUDURINOTE,
FTR_IID_DIARY,
FTR_IID_FUNEDIARY,
FTR_IID_MDIARY,
FTR_IID_NEWDIARY,
FTR_TAK_NIKKI01,
FTR_IKE_NIKKI_FAN1,
FTR_IKE_NIKKI_FAN2,
FTR_IKE_NIKKI_FAN3,
FTR_IKE_NIKKI_FAN4,
FTR_IKE_NIKKI_FAN5,
FTR_IKE_NIKKI_WAFU1,
FTR_GOLD_ITEM0,
FTR_GOLD_ITEM1,
FTR_GOLD_ITEM2,
FTR_GOLD_ITEM3,
FTR_UTIWA0,
FTR_UTIWA1,
FTR_UTIWA2,
FTR_UTIWA3,
FTR_UTIWA4,
FTR_UTIWA5,
FTR_UTIWA6,
FTR_UTIWA7,
FTR_KAZAGURUMA0,
FTR_KAZAGURUMA1,
FTR_KAZAGURUMA2,
FTR_KAZAGURUMA3,
FTR_KAZAGURUMA4,
FTR_KAZAGURUMA5,
FTR_KAZAGURUMA6,
FTR_KAZAGURUMA7,
FTR_TOOL0,
FTR_TOOL1,
FTR_TOOL2,
FTR_TOOL3,
FTR_NOG_NABE,
FTR_IKE_KAMA_DANRO01,
FTR_NOG_KAMAKURA,
FTR_NOG_W_TREE,
FTR_TAK_ICE,
FTR_IKE_ISLAND_HAKO01,
FTR_NOG_BEACHBED,
FTR_NOG_BEACHTABLE,
FTR_TAK_HIBATI,
FTR_IID_SURF,
FTR_IID_SNOW,
FTR_TAK_TETRA,
FTR_IKE_ISLAND_UKU01,
FTR_IKE_ISLAND_SENSUI01,
FTR_IID_YUKI,
FTR_SUM_ART02,
FTR_SUM_ART03,
FTR_TAK_SORI01,
FTR_IID_BENTI,
FTR_TAK_CUBE,
FTR_IKU_DENKO,
FTR_YAZ_ROCKET,
FTR_IKU_SLIP,
FTR_IKU_UKAI,
FTR_IKU_WORK,
FTR_HOS_DESKL,
FTR_HOS_DESKR,
FTR_HOS_FLIP,
FTR_IKU_FLAGMAN,
FTR_YAZ_FISH_TROPHY,
FTR_IKU_JERSEY,
FTR_IKU_REDUCESPEED,
FTR_YAZ_GOLF_TROPHY,
FTR_HOS_TDESK,
FTR_IKU_HAZARDOUS_TOP,
FTR_YAZ_TENNIS_TROPHY,
FTR_IKU_SAWHOUSEV,
FTR_YAZ_KART_TROPHY,
FTR_IKU_BUGZAPPER,
FTR_YAZ_TELESCOPE,
FTR_IKU_COCOA,
FTR_YAZ_B_BATH,
FTR_SUGI_BARBECUE,
FTR_SUGI_RADIATORL,
FTR_SUGI_ALCHAIR,
FTR_SUGI_CHESSTABLE,
FTR_IKU_CANDY,
FTR_SUGI_KPOOL,
FTR_IKU_CEMENT,
FTR_IKU_JACK,
FTR_SUGI_TORCH,
FTR_YAZ_B_HOUSE,
FTR_YOS_PBSTOVE,
FTR_IKU_BUSSTOP,
FTR_TAK_HAM1,
FTR_IKU_FLIP_TOP,
FTR_YOS_KFLAG,
FTR_TAK_NES01,
FTR_YOS_B_FEEDER,
FTR_IKU_CHAIR,
FTR_IKU_ROLLER,
FTR_YOS_FLAMINGO,
FTR_YOS_MAILBOX,
FTR_YAZ_CANDLE,
FTR_IKU_HAM,
FTR_YOS_GNOME,
FTR_YOS_FLAMINGO2,
FTR_IKU_GOLD_GREEN,
FTR_IKU_GOLD_RED,
FTR_IKU_TUMBLE,
FTR_IKU_COW,
FTR_IKU_ORANGE,
FTR_IKU_SAKU_A,
FTR_IKU_SAKU_B,
FTR_YAZ_TUB,
FTR_YOS_LUIGI,
FTR_YOS_MARIO,
FTR_IKU_TURKEY_LAMP,
FTR_YAZ_WAGON,
FTR_YOS_TERRACE,
FTR_HOS_PIKNIC,
FTR_IKU_TURKEY_TABLE,
FTR_IKU_TURKEY_TV,
FTR_IKU_TURKEY_BED,
FTR_YAZ_TURKEY_CHAIR,
FTR_YOS_TURKEY_WATCH,
FTR_HOS_TURKEY_SOFA,
FTR_IKU_MARIO_DOKAN,
FTR_IKU_MARIO_RENGA,
FTR_YAZ_TURKEY_CLOSET,
FTR_HOS_MARIO_HATA,
FTR_YAZ_TURKEY_CHEST,
FTR_HOS_MARIO_KINOKO,
FTR_YOS_TURKEY_MIRROR,
FTR_IKU_MARIO_COIN,
FTR_IKU_MARIO_HATENA,
FTR_IKU_MARIO_STAR,
FTR_IKU_MARIO_KOURA,
FTR_IKU_MARIO_TAIHOU,
FTR_YOS_CACTUS,
FTR_YAZ_MARIO_FLOWER,
FTR_YOS_WHEEL,
FTR_IKU_IDO,
FTR_IKE_PRORES_FENSE01,
FTR_IKE_PRORES_LING01,
FTR_IKE_PRORES_LING02,
FTR_IKE_PRORES_LING03,
FTR_IKE_PRORES_MAT01,
FTR_IKE_PRORES_TABLE01,
FTR_IKE_PRORES_PUNCH01,
FTR_IKE_PRORES_SANDBAG01,
FTR_IKE_PRORES_BENCH01,
FTR_IKE_TENT_FIRE01,
FTR_IKE_TENT_FIRE02,
FTR_IKE_TENT_KAYAK01,
FTR_NOG_SPRINKLER,
FTR_TAK_TENT,
FTR_IKE_TENT_KNAP01,
FTR_IKE_FISH_TRO2,
FTR_NOG_FLOWER0,
FTR_NOG_FLOWER1,
FTR_NOG_FLOWER2,
FTR_NOG_FLOWER3,
FTR_NOG_FLOWER4,
FTR_NOG_FLOWER5,
FTR_NOG_FLOWER6,
FTR_NOG_FLOWER7,
FTR_NOG_FLOWER8,
FTR_TAK_TENT_LAMP,
FTR_NOG_LAWNMOWER,
FTR_TAK_TENT_BOX,
FTR_IKE_TENT_BIKE01,
FTR_IKE_TENT_SLEEPBAG01,
FTR_NOG_BURNER,
FTR_NOG_CORNUCOPIA,
FTR_NOG_GONG,
FTR_TAK_NOISE,
FTR_TAK_STEW,
FTR_DUMMY,
FTR_NUM
};
enum {
NAME_TYPE_ITEM0,
NAME_TYPE_FTR0,
NAME_TYPE_ITEM1,
NAME_TYPE_FTR1,
NAME_TYPE_WARP,
NAME_TYPE_STRUCT,
NAME_TYPE_PAD6,
NAME_TYPE_PAD7,
NAME_TYPE_ITEM2,
NAME_TYPE_ACTOR,
NAME_TYPE_PROPS,
NAME_TYPE_PADB,
NAME_TYPE_PADC,
NAME_TYPE_SPNPC,
NAME_TYPE_NPC,
NAME_TYPE_PAD15,
NAME_TYPE_NUM
};
enum {
ITEM1_CAT_PAPER,
ITEM1_CAT_MONEY,
ITEM1_CAT_TOOL,
ITEM1_CAT_FISH,
ITEM1_CAT_CLOTH,
ITEM1_CAT_ETC,
ITEM1_CAT_CARPET,
ITEM1_CAT_WALL,
ITEM1_CAT_FRUIT,
ITEM1_CAT_PLANT,
ITEM1_CAT_MINIDISK,
ITEM1_CAT_DUMMY,
ITEM1_CAT_TICKET,
ITEM1_CAT_INSECT,
ITEM1_CAT_HUKUBUKURO,
ITEM1_CAT_KABU,
ITEM1_CAT_NUM
};
enum {
mNT_TREE_TYPE_NORMAL,
mNT_TREE_TYPE_PALM,
mNT_TREE_TYPE_CEDAR,
mNT_TREE_TYPE_GOLD,
mNT_TREE_TYPE_NUM
};
enum {
mNT_ITEM_TYPE_NONE,
mNT_ITEM_TYPE_APPLE,
mNT_ITEM_TYPE_ORANGE,
mNT_ITEM_TYPE_PEACH,
mNT_ITEM_TYPE_PEAR,
mNT_ITEM_TYPE_NUTS,
mNT_ITEM_TYPE_MATSUTAKE,
mNT_ITEM_TYPE_KABU,
mNT_ITEM_TYPE_FISH,
mNT_ITEM_TYPE_BAG,
mNT_ITEM_TYPE_LEAF,
mNT_ITEM_TYPE_ROLL,
mNT_ITEM_TYPE_BOX,
mNT_ITEM_TYPE_PACK,
mNT_ITEM_TYPE_PRESENT,
mNT_ITEM_TYPE_SEED,
mNT_ITEM_TYPE_HANIWA,
mNT_ITEM_TYPE_ETC,
mNT_ITEM_TYPE_CAGE,
mNT_ITEM_TYPE_TOOL,
mNT_ITEM_TYPE_FOSSIL,
mNT_ITEM_TYPE_TRASH,
mNT_ITEM_TYPE_LETTER,
mNT_ITEM_TYPE_OTOSI,
mNT_ITEM_TYPE_SHELLA,
mNT_ITEM_TYPE_SHELLB,
mNT_ITEM_TYPE_SHELLC,
mNT_ITEM_TYPE_CANDY,
mNT_ITEM_TYPE_COCONUT,
mNT_ITEM_TYPE_OMIKUJI,
mNT_ITEM_TYPE_CLOTH,
mNT_ITEM_TYPE_CARPET,
mNT_ITEM_TYPE_WALL,
mNT_ITEM_TYPE_AXE,
mNT_ITEM_TYPE_NET,
mNT_ITEM_TYPE_ROD,
mNT_ITEM_TYPE_SHOVEL,
mNT_ITEM_TYPE_AXE2,
mNT_ITEM_TYPE_NET2,
mNT_ITEM_TYPE_ROD2,
mNT_ITEM_TYPE_SHOVEL2,
mNT_ITEM_TYPE_UMBRELLA,
mNT_ITEM_TYPE_KAZA,
mNT_ITEM_TYPE_UTIWA,
mNT_ITEM_TYPE_PAPER,
mNT_ITEM_TYPE_FLOWER_SEED,
mNT_ITEM_TYPE_HUKUBUKURO,
mNT_ITEM_TYPE_TAISOU,
mNT_ITEM_TYPE_MD,
mNT_ITEM_TYPE_TICKET,
mNT_ITEM_TYPE_BONE,
mNT_ITEM_TYPE_DIARY,
mNT_ITEM_TYPE_FORK_ON,
mNT_ITEM_TYPE_NUM
};
enum {
mNT_TREE_SIZE_FULL,
mNT_TREE_SIZE_S2,
mNT_TREE_SIZE_S1,
mNT_TREE_SIZE_S0,
mNT_TREE_SIZE_NUM
};
typedef struct offset_table_s {
int type;
mCoBG_OffsetTable_c table;
} mNT_offset_table_c;
extern s16 move_obj_profile_table[];
extern s16 actor_profile_table[];
extern s16 props_profile_table[];
extern u8 npc_looks_table[];
extern int mNT_get_itemTableNo(mActor_name_t item);
extern mActor_name_t mNT_FishIdx2FishItemNo(int idx);
extern mActor_name_t bg_item_fg_sub(mActor_name_t item, s16 flag);
extern mActor_name_t bg_item_fg_sub_tree_grow(mActor_name_t item, int past_days, int check_plant);
extern mActor_name_t bg_item_fg_sub_dig2take_conv(mActor_name_t item);
extern mNT_offset_table_c* obj_hight_table_item0_nogrow(mActor_name_t item);
extern int FGTreeType_check(mActor_name_t tree);
extern int mNT_ItIsStump(mActor_name_t actor);
extern int mNT_ItIsStoneCoin10(mActor_name_t actor);
extern int mNT_ItIsReserveDummy(mActor_name_t actor);
extern int mNT_check_unknown(mActor_name_t item_no);
enum {
___FTR0_START = 0x1000 -1,
FTR_SUM_HAL_CHEST02_SOUTH, FTR_SUM_HAL_CHEST02_EAST, FTR_SUM_HAL_CHEST02_NORTH, FTR_SUM_HAL_CHEST02_WEST ,
FTR_SUM_CLCHEST03_SOUTH, FTR_SUM_CLCHEST03_EAST, FTR_SUM_CLCHEST03_NORTH, FTR_SUM_CLCHEST03_WEST ,
FTR_SUM_BLUE_BUREAU01_SOUTH, FTR_SUM_BLUE_BUREAU01_EAST, FTR_SUM_BLUE_BUREAU01_NORTH, FTR_SUM_BLUE_BUREAU01_WEST ,
FTR_KOB_LOCKER1_SOUTH, FTR_KOB_LOCKER1_EAST, FTR_KOB_LOCKER1_NORTH, FTR_KOB_LOCKER1_WEST ,
FTR_SUM_X_CHEST01_SOUTH, FTR_SUM_X_CHEST01_EAST, FTR_SUM_X_CHEST01_NORTH, FTR_SUM_X_CHEST01_WEST ,
FTR_SUM_WHI_CHEST02_SOUTH, FTR_SUM_WHI_CHEST02_EAST, FTR_SUM_WHI_CHEST02_NORTH, FTR_SUM_WHI_CHEST02_WEST ,
FTR_SUM_RATAN_CHEST02_SOUTH, FTR_SUM_RATAN_CHEST02_EAST, FTR_SUM_RATAN_CHEST02_NORTH, FTR_SUM_RATAN_CHEST02_WEST ,
FTR_SUM_LOG_CHEST02_SOUTH, FTR_SUM_LOG_CHEST02_EAST, FTR_SUM_LOG_CHEST02_NORTH, FTR_SUM_LOG_CHEST02_WEST ,
FTR_SUM_LICCACHEST_SOUTH, FTR_SUM_LICCACHEST_EAST, FTR_SUM_LICCACHEST_NORTH, FTR_SUM_LICCACHEST_WEST ,
FTR_SUM_GRE_CHEST02_SOUTH, FTR_SUM_GRE_CHEST02_EAST, FTR_SUM_GRE_CHEST02_NORTH, FTR_SUM_GRE_CHEST02_WEST ,
FTR_SUM_FRUITCHEST03_SOUTH, FTR_SUM_FRUITCHEST03_EAST, FTR_SUM_FRUITCHEST03_NORTH, FTR_SUM_FRUITCHEST03_WEST ,
FTR_SUM_CONT_CHEST02_SOUTH, FTR_SUM_CONT_CHEST02_EAST, FTR_SUM_CONT_CHEST02_NORTH, FTR_SUM_CONT_CHEST02_WEST ,
FTR_SUM_BLUE_CAB01_SOUTH, FTR_SUM_BLUE_CAB01_EAST, FTR_SUM_BLUE_CAB01_NORTH, FTR_SUM_BLUE_CAB01_WEST ,
FTR_SUM_BLA_CHEST03_SOUTH, FTR_SUM_BLA_CHEST03_EAST, FTR_SUM_BLA_CHEST03_NORTH, FTR_SUM_BLA_CHEST03_WEST ,
FTR_SUM_ASI_CHEST03_SOUTH, FTR_SUM_ASI_CHEST03_EAST, FTR_SUM_ASI_CHEST03_NORTH, FTR_SUM_ASI_CHEST03_WEST ,
FTR_SUM_X_CHEST02_SOUTH, FTR_SUM_X_CHEST02_EAST, FTR_SUM_X_CHEST02_NORTH, FTR_SUM_X_CHEST02_WEST ,
FTR_SUM_WHI_CHEST01_SOUTH, FTR_SUM_WHI_CHEST01_EAST, FTR_SUM_WHI_CHEST01_NORTH, FTR_SUM_WHI_CHEST01_WEST ,
FTR_SUM_RATAN_CHEST01_SOUTH, FTR_SUM_RATAN_CHEST01_EAST, FTR_SUM_RATAN_CHEST01_NORTH, FTR_SUM_RATAN_CHEST01_WEST ,
FTR_SUM_LOG_CHEST01_SOUTH, FTR_SUM_LOG_CHEST01_EAST, FTR_SUM_LOG_CHEST01_NORTH, FTR_SUM_LOG_CHEST01_WEST ,
FTR_SUM_LICCALOWCHEST_SOUTH, FTR_SUM_LICCALOWCHEST_EAST, FTR_SUM_LICCALOWCHEST_NORTH, FTR_SUM_LICCALOWCHEST_WEST ,
FTR_SUM_HAL_CHEST03_SOUTH, FTR_SUM_HAL_CHEST03_EAST, FTR_SUM_HAL_CHEST03_NORTH, FTR_SUM_HAL_CHEST03_WEST ,
FTR_SUM_GRE_CHEST03_SOUTH, FTR_SUM_GRE_CHEST03_EAST, FTR_SUM_GRE_CHEST03_NORTH, FTR_SUM_GRE_CHEST03_WEST ,
FTR_SUM_FRUITCHEST01_SOUTH, FTR_SUM_FRUITCHEST01_EAST, FTR_SUM_FRUITCHEST01_NORTH, FTR_SUM_FRUITCHEST01_WEST ,
FTR_SUM_CONT_CHEST03_SOUTH, FTR_SUM_CONT_CHEST03_EAST, FTR_SUM_CONT_CHEST03_NORTH, FTR_SUM_CONT_CHEST03_WEST ,
FTR_SUM_CLASSICCHEST01_SOUTH, FTR_SUM_CLASSICCHEST01_EAST, FTR_SUM_CLASSICCHEST01_NORTH, FTR_SUM_CLASSICCHEST01_WEST ,
FTR_SUM_BLUE_LOWCHEST01_SOUTH, FTR_SUM_BLUE_LOWCHEST01_EAST, FTR_SUM_BLUE_LOWCHEST01_NORTH, FTR_SUM_BLUE_LOWCHEST01_WEST ,
FTR_SUM_BLA_CHEST01_SOUTH, FTR_SUM_BLA_CHEST01_EAST, FTR_SUM_BLA_CHEST01_NORTH, FTR_SUM_BLA_CHEST01_WEST ,
FTR_SUM_ASI_CHEST02_SOUTH, FTR_SUM_ASI_CHEST02_EAST, FTR_SUM_ASI_CHEST02_NORTH, FTR_SUM_ASI_CHEST02_WEST ,
FTR_NOG_TRI_CHEST01_SOUTH, FTR_NOG_TRI_CHEST01_EAST, FTR_NOG_TRI_CHEST01_NORTH, FTR_NOG_TRI_CHEST01_WEST ,
FTR_NOG_TRI_CHEST02_SOUTH, FTR_NOG_TRI_CHEST02_EAST, FTR_NOG_TRI_CHEST02_NORTH, FTR_NOG_TRI_CHEST02_WEST ,
FTR_NOG_TRI_CHEST03_SOUTH, FTR_NOG_TRI_CHEST03_EAST, FTR_NOG_TRI_CHEST03_NORTH, FTR_NOG_TRI_CHEST03_WEST ,
FTR_NKH_BOX01_SOUTH, FTR_NKH_BOX01_EAST, FTR_NKH_BOX01_NORTH, FTR_NKH_BOX01_WEST ,
FTR_IKE_JPN_STEP01_SOUTH, FTR_IKE_JPN_STEP01_EAST, FTR_IKE_JPN_STEP01_NORTH, FTR_IKE_JPN_STEP01_WEST ,
FTR_IKE_JPN_SAI01_SOUTH, FTR_IKE_JPN_SAI01_EAST, FTR_IKE_JPN_SAI01_NORTH, FTR_IKE_JPN_SAI01_WEST ,
FTR_NOG_FAN01_SOUTH, FTR_NOG_FAN01_EAST, FTR_NOG_FAN01_NORTH, FTR_NOG_FAN01_WEST ,
FTR_NKH_LIGHT01_SOUTH, FTR_NKH_LIGHT01_EAST, FTR_NKH_LIGHT01_NORTH, FTR_NKH_LIGHT01_WEST ,
FTR_NKH_TABLE01_SOUTH, FTR_NKH_TABLE01_EAST, FTR_NKH_TABLE01_NORTH, FTR_NKH_TABLE01_WEST ,
FTR_NKH_TABLE02_SOUTH, FTR_NKH_TABLE02_EAST, FTR_NKH_TABLE02_NORTH, FTR_NKH_TABLE02_WEST ,
FTR_NKH_WALL01_SOUTH, FTR_NKH_WALL01_EAST, FTR_NKH_WALL01_NORTH, FTR_NKH_WALL01_WEST ,
FTR_NKH_ZAB01_SOUTH, FTR_NKH_ZAB01_EAST, FTR_NKH_ZAB01_NORTH, FTR_NKH_ZAB01_WEST ,
FTR_NKH_BOARD01_SOUTH, FTR_NKH_BOARD01_EAST, FTR_NKH_BOARD01_NORTH, FTR_NKH_BOARD01_WEST ,
FTR_ARI_ISU01_SOUTH, FTR_ARI_ISU01_EAST, FTR_ARI_ISU01_NORTH, FTR_ARI_ISU01_WEST ,
FTR_ARI_TABLE01_SOUTH, FTR_ARI_TABLE01_EAST, FTR_ARI_TABLE01_NORTH, FTR_ARI_TABLE01_WEST ,
FTR_ARI_REIZOU01_SOUTH, FTR_ARI_REIZOU01_EAST, FTR_ARI_REIZOU01_NORTH, FTR_ARI_REIZOU01_WEST ,
FTR_SUM_CHEST01_SOUTH, FTR_SUM_CHEST01_EAST, FTR_SUM_CHEST01_NORTH, FTR_SUM_CHEST01_WEST ,
FTR_SUM_CHEST02_SOUTH, FTR_SUM_CHEST02_EAST, FTR_SUM_CHEST02_NORTH, FTR_SUM_CHEST02_WEST ,
FTR_SUM_SOFE01_SOUTH, FTR_SUM_SOFE01_EAST, FTR_SUM_SOFE01_NORTH, FTR_SUM_SOFE01_WEST ,
FTR_SUM_SOFE02_SOUTH, FTR_SUM_SOFE02_EAST, FTR_SUM_SOFE02_NORTH, FTR_SUM_SOFE02_WEST ,
FTR_IKE_JPN_HIBATI01_SOUTH, FTR_IKE_JPN_HIBATI01_EAST, FTR_IKE_JPN_HIBATI01_NORTH, FTR_IKE_JPN_HIBATI01_WEST ,
FTR_ARI_KITCHEN01_SOUTH, FTR_ARI_KITCHEN01_EAST, FTR_ARI_KITCHEN01_NORTH, FTR_ARI_KITCHEN01_WEST ,
FTR_SUM_SOFE03_SOUTH, FTR_SUM_SOFE03_EAST, FTR_SUM_SOFE03_NORTH, FTR_SUM_SOFE03_WEST ,
FTR_IKE_JPN_TANSU01_SOUTH, FTR_IKE_JPN_TANSU01_EAST, FTR_IKE_JPN_TANSU01_NORTH, FTR_IKE_JPN_TANSU01_WEST ,
FTR_IKE_JPN_KOTATU01_SOUTH, FTR_IKE_JPN_KOTATU01_EAST, FTR_IKE_JPN_KOTATU01_NORTH, FTR_IKE_JPN_KOTATU01_WEST ,
FTR_IKE_JPN_KOTATU02_SOUTH, FTR_IKE_JPN_KOTATU02_EAST, FTR_IKE_JPN_KOTATU02_NORTH, FTR_IKE_JPN_KOTATU02_WEST ,
FTR_SUM_GUITAR01_SOUTH, FTR_SUM_GUITAR01_EAST, FTR_SUM_GUITAR01_NORTH, FTR_SUM_GUITAR01_WEST ,
FTR_SUM_GUITAR02_SOUTH, FTR_SUM_GUITAR02_EAST, FTR_SUM_GUITAR02_NORTH, FTR_SUM_GUITAR02_WEST ,
FTR_SUM_GUITAR03_SOUTH, FTR_SUM_GUITAR03_EAST, FTR_SUM_GUITAR03_NORTH, FTR_SUM_GUITAR03_WEST ,
FTR_SUM_DOLL01_SOUTH, FTR_SUM_DOLL01_EAST, FTR_SUM_DOLL01_NORTH, FTR_SUM_DOLL01_WEST ,
FTR_SUM_DOLL02_SOUTH, FTR_SUM_DOLL02_EAST, FTR_SUM_DOLL02_NORTH, FTR_SUM_DOLL02_WEST ,
FTR_SUM_DOLL03_SOUTH, FTR_SUM_DOLL03_EAST, FTR_SUM_DOLL03_NORTH, FTR_SUM_DOLL03_WEST ,
FTR_SUM_DOLL04_SOUTH, FTR_SUM_DOLL04_EAST, FTR_SUM_DOLL04_NORTH, FTR_SUM_DOLL04_WEST ,
FTR_SUM_CLASSICCABINET01_SOUTH, FTR_SUM_CLASSICCABINET01_EAST, FTR_SUM_CLASSICCABINET01_NORTH, FTR_SUM_CLASSICCABINET01_WEST ,
FTR_SUM_CLASSICCHAIR01_SOUTH, FTR_SUM_CLASSICCHAIR01_EAST, FTR_SUM_CLASSICCHAIR01_NORTH, FTR_SUM_CLASSICCHAIR01_WEST ,
FTR_SUM_CLASSICCHEST02_SOUTH, FTR_SUM_CLASSICCHEST02_EAST, FTR_SUM_CLASSICCHEST02_NORTH, FTR_SUM_CLASSICCHEST02_WEST ,
FTR_SUM_CLASSICTABLE01_SOUTH, FTR_SUM_CLASSICTABLE01_EAST, FTR_SUM_CLASSICTABLE01_NORTH, FTR_SUM_CLASSICTABLE01_WEST ,
FTR_SUM_CLASSICWARDROPE01_SOUTH, FTR_SUM_CLASSICWARDROPE01_EAST, FTR_SUM_CLASSICWARDROPE01_NORTH, FTR_SUM_CLASSICWARDROPE01_WEST ,
FTR_SUM_CLCHAIR02_SOUTH, FTR_SUM_CLCHAIR02_EAST, FTR_SUM_CLCHAIR02_NORTH, FTR_SUM_CLCHAIR02_WEST ,
FTR_SUM_CUPBOARD01_SOUTH, FTR_SUM_CUPBOARD01_EAST, FTR_SUM_CUPBOARD01_NORTH, FTR_SUM_CUPBOARD01_WEST ,
FTR_SUM_DESK01_SOUTH, FTR_SUM_DESK01_EAST, FTR_SUM_DESK01_NORTH, FTR_SUM_DESK01_WEST ,
FTR_SUM_DOLL05_SOUTH, FTR_SUM_DOLL05_EAST, FTR_SUM_DOLL05_NORTH, FTR_SUM_DOLL05_WEST ,
FTR_SUM_DOLL06_SOUTH, FTR_SUM_DOLL06_EAST, FTR_SUM_DOLL06_NORTH, FTR_SUM_DOLL06_WEST ,
FTR_SUM_DOLL07_SOUTH, FTR_SUM_DOLL07_EAST, FTR_SUM_DOLL07_NORTH, FTR_SUM_DOLL07_WEST ,
FTR_SUM_DOLL08_SOUTH, FTR_SUM_DOLL08_EAST, FTR_SUM_DOLL08_NORTH, FTR_SUM_DOLL08_WEST ,
FTR_SUM_DOLL09_SOUTH, FTR_SUM_DOLL09_EAST, FTR_SUM_DOLL09_NORTH, FTR_SUM_DOLL09_WEST ,
FTR_SUM_DOLL10_SOUTH, FTR_SUM_DOLL10_EAST, FTR_SUM_DOLL10_NORTH, FTR_SUM_DOLL10_WEST ,
FTR_SUM_GLOBE01_SOUTH, FTR_SUM_GLOBE01_EAST, FTR_SUM_GLOBE01_NORTH, FTR_SUM_GLOBE01_WEST ,
FTR_SUM_KITCHAIR01_SOUTH, FTR_SUM_KITCHAIR01_EAST, FTR_SUM_KITCHAIR01_NORTH, FTR_SUM_KITCHAIR01_WEST ,
FTR_SUM_KITTABLE01_SOUTH, FTR_SUM_KITTABLE01_EAST, FTR_SUM_KITTABLE01_NORTH, FTR_SUM_KITTABLE01_WEST ,
FTR_SUM_TV01_SOUTH, FTR_SUM_TV01_EAST, FTR_SUM_TV01_NORTH, FTR_SUM_TV01_WEST ,
FTR_SUM_TOTEMP01_SOUTH, FTR_SUM_TOTEMP01_EAST, FTR_SUM_TOTEMP01_NORTH, FTR_SUM_TOTEMP01_WEST ,
FTR_SUM_TOTEMP02_SOUTH, FTR_SUM_TOTEMP02_EAST, FTR_SUM_TOTEMP02_NORTH, FTR_SUM_TOTEMP02_WEST ,
FTR_SUM_TOTEMP03_SOUTH, FTR_SUM_TOTEMP03_EAST, FTR_SUM_TOTEMP03_NORTH, FTR_SUM_TOTEMP03_WEST ,
FTR_SUM_TOTEMP04_SOUTH, FTR_SUM_TOTEMP04_EAST, FTR_SUM_TOTEMP04_NORTH, FTR_SUM_TOTEMP04_WEST ,
FTR_SUM_TAIKO01_SOUTH, FTR_SUM_TAIKO01_EAST, FTR_SUM_TAIKO01_NORTH, FTR_SUM_TAIKO01_WEST ,
FTR_SUM_STOVE01_SOUTH, FTR_SUM_STOVE01_EAST, FTR_SUM_STOVE01_NORTH, FTR_SUM_STOVE01_WEST ,
FTR_SUM_STEREO01_SOUTH, FTR_SUM_STEREO01_EAST, FTR_SUM_STEREO01_NORTH, FTR_SUM_STEREO01_WEST ,
FTR_SUM_RATAN_ISU01_SOUTH, FTR_SUM_RATAN_ISU01_EAST, FTR_SUM_RATAN_ISU01_NORTH, FTR_SUM_RATAN_ISU01_WEST ,
FTR_SUM_OLDSOFA01_SOUTH, FTR_SUM_OLDSOFA01_EAST, FTR_SUM_OLDSOFA01_NORTH, FTR_SUM_OLDSOFA01_WEST ,
FTR_SUM_LICCATABLE_SOUTH, FTR_SUM_LICCATABLE_EAST, FTR_SUM_LICCATABLE_NORTH, FTR_SUM_LICCATABLE_WEST ,
FTR_SUM_LICCASOFA_SOUTH, FTR_SUM_LICCASOFA_EAST, FTR_SUM_LICCASOFA_NORTH, FTR_SUM_LICCASOFA_WEST ,
FTR_SUM_LICCAPIANO_SOUTH, FTR_SUM_LICCAPIANO_EAST, FTR_SUM_LICCAPIANO_NORTH, FTR_SUM_LICCAPIANO_WEST ,
FTR_SUM_LICCALANP_SOUTH, FTR_SUM_LICCALANP_EAST, FTR_SUM_LICCALANP_NORTH, FTR_SUM_LICCALANP_WEST ,
FTR_SUM_LICCAKITCHEN_SOUTH, FTR_SUM_LICCAKITCHEN_EAST, FTR_SUM_LICCAKITCHEN_NORTH, FTR_SUM_LICCAKITCHEN_WEST ,
FTR_SUM_LICCACHAIR_SOUTH, FTR_SUM_LICCACHAIR_EAST, FTR_SUM_LICCACHAIR_NORTH, FTR_SUM_LICCACHAIR_WEST ,
FTR_SUM_LICCABED_SOUTH, FTR_SUM_LICCABED_EAST, FTR_SUM_LICCABED_NORTH, FTR_SUM_LICCABED_WEST ,
FTR_SUM_OLDCLK01_SOUTH, FTR_SUM_OLDCLK01_EAST, FTR_SUM_OLDCLK01_NORTH, FTR_SUM_OLDCLK01_WEST ,
FTR_SUM_RATAN_BED01_SOUTH, FTR_SUM_RATAN_BED01_EAST, FTR_SUM_RATAN_BED01_NORTH, FTR_SUM_RATAN_BED01_WEST ,
FTR_SUM_GOLFBAG01_SOUTH, FTR_SUM_GOLFBAG01_EAST, FTR_SUM_GOLFBAG01_NORTH, FTR_SUM_GOLFBAG01_WEST ,
FTR_SUM_GOLFBAG02_SOUTH, FTR_SUM_GOLFBAG02_EAST, FTR_SUM_GOLFBAG02_NORTH, FTR_SUM_GOLFBAG02_WEST ,
FTR_SUM_GOLFBAG03_SOUTH, FTR_SUM_GOLFBAG03_EAST, FTR_SUM_GOLFBAG03_NORTH, FTR_SUM_GOLFBAG03_WEST ,
FTR_SUM_BOOKCHT01_SOUTH, FTR_SUM_BOOKCHT01_EAST, FTR_SUM_BOOKCHT01_NORTH, FTR_SUM_BOOKCHT01_WEST ,
FTR_SUM_CHAIR01_SOUTH, FTR_SUM_CHAIR01_EAST, FTR_SUM_CHAIR01_NORTH, FTR_SUM_CHAIR01_WEST ,
FTR_SUM_CONT_SOFA01_SOUTH, FTR_SUM_CONT_SOFA01_EAST, FTR_SUM_CONT_SOFA01_NORTH, FTR_SUM_CONT_SOFA01_WEST ,
FTR_SUM_CONT_SOFA02_SOUTH, FTR_SUM_CONT_SOFA02_EAST, FTR_SUM_CONT_SOFA02_NORTH, FTR_SUM_CONT_SOFA02_WEST ,
FTR_SUM_CONT_TABLE01_SOUTH, FTR_SUM_CONT_TABLE01_EAST, FTR_SUM_CONT_TABLE01_NORTH, FTR_SUM_CONT_TABLE01_WEST ,
FTR_SUM_CONT_CAB01_SOUTH, FTR_SUM_CONT_CAB01_EAST, FTR_SUM_CONT_CAB01_NORTH, FTR_SUM_CONT_CAB01_WEST ,
FTR_SUM_CONT_CHEST01_SOUTH, FTR_SUM_CONT_CHEST01_EAST, FTR_SUM_CONT_CHEST01_NORTH, FTR_SUM_CONT_CHEST01_WEST ,
FTR_SUM_CONT_CHAIR01_SOUTH, FTR_SUM_CONT_CHAIR01_EAST, FTR_SUM_CONT_CHAIR01_NORTH, FTR_SUM_CONT_CHAIR01_WEST ,
FTR_SUM_CONT_BED01_SOUTH, FTR_SUM_CONT_BED01_EAST, FTR_SUM_CONT_BED01_NORTH, FTR_SUM_CONT_BED01_WEST ,
FTR_SUM_CONT_TABLE02_SOUTH, FTR_SUM_CONT_TABLE02_EAST, FTR_SUM_CONT_TABLE02_NORTH, FTR_SUM_CONT_TABLE02_WEST ,
FTR_SUM_COMP01_SOUTH, FTR_SUM_COMP01_EAST, FTR_SUM_COMP01_NORTH, FTR_SUM_COMP01_WEST ,
FTR_KOB_JIMUDESK_SOUTH, FTR_KOB_JIMUDESK_EAST, FTR_KOB_JIMUDESK_NORTH, FTR_KOB_JIMUDESK_WEST ,
FTR_KOB_MASTERSWORD_SOUTH, FTR_KOB_MASTERSWORD_EAST, FTR_KOB_MASTERSWORD_NORTH, FTR_KOB_MASTERSWORD_WEST ,
FTR_KOB_NCUBE_SOUTH, FTR_KOB_NCUBE_EAST, FTR_KOB_NCUBE_NORTH, FTR_KOB_NCUBE_WEST ,
FTR_SUM_TEKIN01_SOUTH, FTR_SUM_TEKIN01_EAST, FTR_SUM_TEKIN01_NORTH, FTR_SUM_TEKIN01_WEST ,
FTR_SUM_BIWA01_SOUTH, FTR_SUM_BIWA01_EAST, FTR_SUM_BIWA01_NORTH, FTR_SUM_BIWA01_WEST ,
FTR_SUM_CONGA01_SOUTH, FTR_SUM_CONGA01_EAST, FTR_SUM_CONGA01_NORTH, FTR_SUM_CONGA01_WEST ,
FTR_SUM_SHOUKAKI_SOUTH, FTR_SUM_SHOUKAKI_EAST, FTR_SUM_SHOUKAKI_NORTH, FTR_SUM_SHOUKAKI_WEST ,
FTR_SUM_COL_CHAIR01_SOUTH, FTR_SUM_COL_CHAIR01_EAST, FTR_SUM_COL_CHAIR01_NORTH, FTR_SUM_COL_CHAIR01_WEST ,
FTR_SUM_COL_CHAIR02_SOUTH, FTR_SUM_COL_CHAIR02_EAST, FTR_SUM_COL_CHAIR02_NORTH, FTR_SUM_COL_CHAIR02_WEST ,
FTR_SUM_COL_CHAIR03_SOUTH, FTR_SUM_COL_CHAIR03_EAST, FTR_SUM_COL_CHAIR03_NORTH, FTR_SUM_COL_CHAIR03_WEST ,
FTR_SUM_CONPO01_SOUTH, FTR_SUM_CONPO01_EAST, FTR_SUM_CONPO01_NORTH, FTR_SUM_CONPO01_WEST ,
FTR_KOB_PIPEISU_SOUTH, FTR_KOB_PIPEISU_EAST, FTR_KOB_PIPEISU_NORTH, FTR_KOB_PIPEISU_WEST ,
FTR_SUM_LICCAMIRROR_SOUTH, FTR_SUM_LICCAMIRROR_EAST, FTR_SUM_LICCAMIRROR_NORTH, FTR_SUM_LICCAMIRROR_WEST ,
FTR_SUM_PET01_SOUTH, FTR_SUM_PET01_EAST, FTR_SUM_PET01_NORTH, FTR_SUM_PET01_WEST ,
FTR_SUM_TIMPANI01_SOUTH, FTR_SUM_TIMPANI01_EAST, FTR_SUM_TIMPANI01_NORTH, FTR_SUM_TIMPANI01_WEST ,
FTR_SUM_SPIKA01_SOUTH, FTR_SUM_SPIKA01_EAST, FTR_SUM_SPIKA01_NORTH, FTR_SUM_SPIKA01_WEST ,
FTR_SUM_BDCAKE01_SOUTH, FTR_SUM_BDCAKE01_EAST, FTR_SUM_BDCAKE01_NORTH, FTR_SUM_BDCAKE01_WEST ,
FTR_KOB_S_DESK1_SOUTH, FTR_KOB_S_DESK1_EAST, FTR_KOB_S_DESK1_NORTH, FTR_KOB_S_DESK1_WEST ,
FTR_KOB_S_DESK2_SOUTH, FTR_KOB_S_DESK2_EAST, FTR_KOB_S_DESK2_NORTH, FTR_KOB_S_DESK2_WEST ,
FTR_KOB_S_DESK3_SOUTH, FTR_KOB_S_DESK3_EAST, FTR_KOB_S_DESK3_NORTH, FTR_KOB_S_DESK3_WEST ,
FTR_SUM_SABO01_SOUTH, FTR_SUM_SABO01_EAST, FTR_SUM_SABO01_NORTH, FTR_SUM_SABO01_WEST ,
FTR_SUM_SABO02_SOUTH, FTR_SUM_SABO02_EAST, FTR_SUM_SABO02_NORTH, FTR_SUM_SABO02_WEST ,
FTR_SUM_CLBED02_SOUTH, FTR_SUM_CLBED02_EAST, FTR_SUM_CLBED02_NORTH, FTR_SUM_CLBED02_WEST ,
FTR_SUM_TV02_SOUTH, FTR_SUM_TV02_EAST, FTR_SUM_TV02_NORTH, FTR_SUM_TV02_WEST ,
FTR_SUM_LICCALOWTABLE_SOUTH, FTR_SUM_LICCALOWTABLE_EAST, FTR_SUM_LICCALOWTABLE_NORTH, FTR_SUM_LICCALOWTABLE_WEST ,
FTR_SUM_KADOMATU_SOUTH, FTR_SUM_KADOMATU_EAST, FTR_SUM_KADOMATU_NORTH, FTR_SUM_KADOMATU_WEST ,
FTR_SUM_KAGAMOCHI_SOUTH, FTR_SUM_KAGAMOCHI_EAST, FTR_SUM_KAGAMOCHI_NORTH, FTR_SUM_KAGAMOCHI_WEST ,
FTR_SUM_TOURO01_SOUTH, FTR_SUM_TOURO01_EAST, FTR_SUM_TOURO01_NORTH, FTR_SUM_TOURO01_WEST ,
FTR_SUM_TOURO02_SOUTH, FTR_SUM_TOURO02_EAST, FTR_SUM_TOURO02_NORTH, FTR_SUM_TOURO02_WEST ,
FTR_SUM_TOURO03_SOUTH, FTR_SUM_TOURO03_EAST, FTR_SUM_TOURO03_NORTH, FTR_SUM_TOURO03_WEST ,
FTR_KOB_JIMUISU_SOUTH, FTR_KOB_JIMUISU_EAST, FTR_KOB_JIMUISU_NORTH, FTR_KOB_JIMUISU_WEST ,
FTR_KOB_GETABAKO1_SOUTH, FTR_KOB_GETABAKO1_EAST, FTR_KOB_GETABAKO1_NORTH, FTR_KOB_GETABAKO1_WEST ,
FTR_KOB_GETABAKO2_SOUTH, FTR_KOB_GETABAKO2_EAST, FTR_KOB_GETABAKO2_NORTH, FTR_KOB_GETABAKO2_WEST ,
FTR_KOB_S_ISU1_SOUTH, FTR_KOB_S_ISU1_EAST, FTR_KOB_S_ISU1_NORTH, FTR_KOB_S_ISU1_WEST ,
FTR_KOB_S_ISU2_SOUTH, FTR_KOB_S_ISU2_EAST, FTR_KOB_S_ISU2_NORTH, FTR_KOB_S_ISU2_WEST ,
FTR_KOB_S_ISU3_SOUTH, FTR_KOB_S_ISU3_EAST, FTR_KOB_S_ISU3_NORTH, FTR_KOB_S_ISU3_WEST ,
FTR_KOB_RIKA_DESK_SOUTH, FTR_KOB_RIKA_DESK_EAST, FTR_KOB_RIKA_DESK_NORTH, FTR_KOB_RIKA_DESK_WEST ,
FTR_KOB_TYOUREIDAI_SOUTH, FTR_KOB_TYOUREIDAI_EAST, FTR_KOB_TYOUREIDAI_NORTH, FTR_KOB_TYOUREIDAI_WEST ,
FTR_SUM_TOURO04_SOUTH, FTR_SUM_TOURO04_EAST, FTR_SUM_TOURO04_NORTH, FTR_SUM_TOURO04_WEST ,
FTR_SUM_TARU01_SOUTH, FTR_SUM_TARU01_EAST, FTR_SUM_TARU01_NORTH, FTR_SUM_TARU01_WEST ,
FTR_SUM_TARU02_SOUTH, FTR_SUM_TARU02_EAST, FTR_SUM_TARU02_NORTH, FTR_SUM_TARU02_WEST ,
FTR_KOB_TOBIBAKO_SOUTH, FTR_KOB_TOBIBAKO_EAST, FTR_KOB_TOBIBAKO_NORTH, FTR_KOB_TOBIBAKO_WEST ,
FTR_KON_TUKUE_SOUTH, FTR_KON_TUKUE_EAST, FTR_KON_TUKUE_NORTH, FTR_KON_TUKUE_WEST ,
FTR_SUM_MEZACLOCK_SOUTH, FTR_SUM_MEZACLOCK_EAST, FTR_SUM_MEZACLOCK_NORTH, FTR_SUM_MEZACLOCK_WEST ,
FTR_SUM_POPTABLE01_SOUTH, FTR_SUM_POPTABLE01_EAST, FTR_SUM_POPTABLE01_NORTH, FTR_SUM_POPTABLE01_WEST ,
FTR_SUM_POPTABLE02_SOUTH, FTR_SUM_POPTABLE02_EAST, FTR_SUM_POPTABLE02_NORTH, FTR_SUM_POPTABLE02_WEST ,
FTR_SUM_POPTABLE03_SOUTH, FTR_SUM_POPTABLE03_EAST, FTR_SUM_POPTABLE03_NORTH, FTR_SUM_POPTABLE03_WEST ,
FTR_KON_TUBO_SOUTH, FTR_KON_TUBO_EAST, FTR_KON_TUBO_NORTH, FTR_KON_TUBO_WEST ,
FTR_SUM_POPCHAIR01_SOUTH, FTR_SUM_POPCHAIR01_EAST, FTR_SUM_POPCHAIR01_NORTH, FTR_SUM_POPCHAIR01_WEST ,
FTR_SUM_POPCHAIR02_SOUTH, FTR_SUM_POPCHAIR02_EAST, FTR_SUM_POPCHAIR02_NORTH, FTR_SUM_POPCHAIR02_WEST ,
FTR_SUM_POPCHAIR03_SOUTH, FTR_SUM_POPCHAIR03_EAST, FTR_SUM_POPCHAIR03_NORTH, FTR_SUM_POPCHAIR03_WEST ,
FTR_SUM_SUBERI01_SOUTH, FTR_SUM_SUBERI01_EAST, FTR_SUM_SUBERI01_NORTH, FTR_SUM_SUBERI01_WEST ,
FTR_SUM_WC01_SOUTH, FTR_SUM_WC01_EAST, FTR_SUM_WC01_NORTH, FTR_SUM_WC01_WEST ,
FTR_SUM_WC02_SOUTH, FTR_SUM_WC02_EAST, FTR_SUM_WC02_NORTH, FTR_SUM_WC02_WEST ,
FTR_TAK_TABLE02_SOUTH, FTR_TAK_TABLE02_EAST, FTR_TAK_TABLE02_NORTH, FTR_TAK_TABLE02_WEST ,
FTR_TAK_ISU03_SOUTH, FTR_TAK_ISU03_EAST, FTR_TAK_ISU03_NORTH, FTR_TAK_ISU03_WEST ,
FTR_KON_TUBO2_SOUTH, FTR_KON_TUBO2_EAST, FTR_KON_TUBO2_NORTH, FTR_KON_TUBO2_WEST ,
FTR_KON_TUBO3_SOUTH, FTR_KON_TUBO3_EAST, FTR_KON_TUBO3_NORTH, FTR_KON_TUBO3_WEST ,
FTR_SUM_MISIN01_SOUTH, FTR_SUM_MISIN01_EAST, FTR_SUM_MISIN01_NORTH, FTR_SUM_MISIN01_WEST ,
FTR_SUM_BILLIADS_SOUTH, FTR_SUM_BILLIADS_EAST, FTR_SUM_BILLIADS_NORTH, FTR_SUM_BILLIADS_WEST ,
FTR_SUM_ART01_SOUTH, FTR_SUM_ART01_EAST, FTR_SUM_ART01_NORTH, FTR_SUM_ART01_WEST ,
FTR_IKE_ART_ANG_SOUTH, FTR_IKE_ART_ANG_EAST, FTR_IKE_ART_ANG_NORTH, FTR_IKE_ART_ANG_WEST ,
FTR_IKE_ART_SYA_SOUTH, FTR_IKE_ART_SYA_EAST, FTR_IKE_ART_SYA_NORTH, FTR_IKE_ART_SYA_WEST ,
FTR_SUM_ART04_SOUTH, FTR_SUM_ART04_EAST, FTR_SUM_ART04_NORTH, FTR_SUM_ART04_WEST ,
FTR_SUM_ART05_SOUTH, FTR_SUM_ART05_EAST, FTR_SUM_ART05_NORTH, FTR_SUM_ART05_WEST ,
FTR_SUM_ART06_SOUTH, FTR_SUM_ART06_EAST, FTR_SUM_ART06_NORTH, FTR_SUM_ART06_WEST ,
FTR_IKE_ART_FEL_SOUTH, FTR_IKE_ART_FEL_EAST, FTR_IKE_ART_FEL_NORTH, FTR_IKE_ART_FEL_WEST ,
FTR_SUM_ART08_SOUTH, FTR_SUM_ART08_EAST, FTR_SUM_ART08_NORTH, FTR_SUM_ART08_WEST ,
FTR_SUM_ART09_SOUTH, FTR_SUM_ART09_EAST, FTR_SUM_ART09_NORTH, FTR_SUM_ART09_WEST ,
FTR_SUM_ART10_SOUTH, FTR_SUM_ART10_EAST, FTR_SUM_ART10_NORTH, FTR_SUM_ART10_WEST ,
FTR_SUM_ART11_SOUTH, FTR_SUM_ART11_EAST, FTR_SUM_ART11_NORTH, FTR_SUM_ART11_WEST ,
FTR_SUM_ART12_SOUTH, FTR_SUM_ART12_EAST, FTR_SUM_ART12_NORTH, FTR_SUM_ART12_WEST ,
FTR_SUM_ART13_SOUTH, FTR_SUM_ART13_EAST, FTR_SUM_ART13_NORTH, FTR_SUM_ART13_WEST ,
FTR_SUM_ART14_SOUTH, FTR_SUM_ART14_EAST, FTR_SUM_ART14_NORTH, FTR_SUM_ART14_WEST ,
FTR_SUM_ART15_SOUTH, FTR_SUM_ART15_EAST, FTR_SUM_ART15_NORTH, FTR_SUM_ART15_WEST ,
FTR_SUM_FRUITBED01_SOUTH, FTR_SUM_FRUITBED01_EAST, FTR_SUM_FRUITBED01_NORTH, FTR_SUM_FRUITBED01_WEST ,
FTR_SUM_FRUITCHAIR01_SOUTH, FTR_SUM_FRUITCHAIR01_EAST, FTR_SUM_FRUITCHAIR01_NORTH, FTR_SUM_FRUITCHAIR01_WEST ,
FTR_SUM_FRUITCHEST02_SOUTH, FTR_SUM_FRUITCHEST02_EAST, FTR_SUM_FRUITCHEST02_NORTH, FTR_SUM_FRUITCHEST02_WEST ,
FTR_SUM_FRUITTABLE01_SOUTH, FTR_SUM_FRUITTABLE01_EAST, FTR_SUM_FRUITTABLE01_NORTH, FTR_SUM_FRUITTABLE01_WEST ,
FTR_SUM_FRUITTV01_SOUTH, FTR_SUM_FRUITTV01_EAST, FTR_SUM_FRUITTV01_NORTH, FTR_SUM_FRUITTV01_WEST ,
FTR_SUM_TAKKYU_SOUTH, FTR_SUM_TAKKYU_EAST, FTR_SUM_TAKKYU_NORTH, FTR_SUM_TAKKYU_WEST ,
FTR_SUM_HARP_SOUTH, FTR_SUM_HARP_EAST, FTR_SUM_HARP_NORTH, FTR_SUM_HARP_WEST ,
FTR_SUM_LOG_HATOCLK_SOUTH, FTR_SUM_LOG_HATOCLK_EAST, FTR_SUM_LOG_HATOCLK_NORTH, FTR_SUM_LOG_HATOCLK_WEST ,
FTR_SUM_KISHA_SOUTH, FTR_SUM_KISHA_EAST, FTR_SUM_KISHA_NORTH, FTR_SUM_KISHA_WEST ,
FTR_SUM_MIZUNOMI_SOUTH, FTR_SUM_MIZUNOMI_EAST, FTR_SUM_MIZUNOMI_NORTH, FTR_SUM_MIZUNOMI_WEST ,
FTR_SUM_OKIAGARI01_SOUTH, FTR_SUM_OKIAGARI01_EAST, FTR_SUM_OKIAGARI01_NORTH, FTR_SUM_OKIAGARI01_WEST ,
FTR_SUM_SARU_SOUTH, FTR_SUM_SARU_EAST, FTR_SUM_SARU_NORTH, FTR_SUM_SARU_WEST ,
FTR_SUM_SLOT_SOUTH, FTR_SUM_SLOT_EAST, FTR_SUM_SLOT_NORTH, FTR_SUM_SLOT_WEST ,
FTR_SUM_ASI_CHAIR01_SOUTH, FTR_SUM_ASI_CHAIR01_EAST, FTR_SUM_ASI_CHAIR01_NORTH, FTR_SUM_ASI_CHAIR01_WEST ,
FTR_SUM_ASI_CHAIR02_SOUTH, FTR_SUM_ASI_CHAIR02_EAST, FTR_SUM_ASI_CHAIR02_NORTH, FTR_SUM_ASI_CHAIR02_WEST ,
FTR_SUM_ASI_CHEST01_SOUTH, FTR_SUM_ASI_CHEST01_EAST, FTR_SUM_ASI_CHEST01_NORTH, FTR_SUM_ASI_CHEST01_WEST ,
FTR_SUM_ASI_LANP01_SOUTH, FTR_SUM_ASI_LANP01_EAST, FTR_SUM_ASI_LANP01_NORTH, FTR_SUM_ASI_LANP01_WEST ,
FTR_SUM_PL_CALADIUM01_SOUTH, FTR_SUM_PL_CALADIUM01_EAST, FTR_SUM_PL_CALADIUM01_NORTH, FTR_SUM_PL_CALADIUM01_WEST ,
FTR_SUM_PL_SHUROCI_SOUTH, FTR_SUM_PL_SHUROCI_EAST, FTR_SUM_PL_SHUROCI_NORTH, FTR_SUM_PL_SHUROCI_WEST ,
FTR_SUM_ASI_SCREEN01_SOUTH, FTR_SUM_ASI_SCREEN01_EAST, FTR_SUM_ASI_SCREEN01_NORTH, FTR_SUM_ASI_SCREEN01_WEST ,
FTR_SUM_ASI_TABLE01_SOUTH, FTR_SUM_ASI_TABLE01_EAST, FTR_SUM_ASI_TABLE01_NORTH, FTR_SUM_ASI_TABLE01_WEST ,
FTR_SUM_ASI_TAIKO_SOUTH, FTR_SUM_ASI_TAIKO_EAST, FTR_SUM_ASI_TAIKO_NORTH, FTR_SUM_ASI_TAIKO_WEST ,
FTR_SUM_BLA_BED01_SOUTH, FTR_SUM_BLA_BED01_EAST, FTR_SUM_BLA_BED01_NORTH, FTR_SUM_BLA_BED01_WEST ,
FTR_BLA_CHAIR01_SOUTH, FTR_BLA_CHAIR01_EAST, FTR_BLA_CHAIR01_NORTH, FTR_BLA_CHAIR01_WEST ,
FTR_SUM_BLA_CHEST02_SOUTH, FTR_SUM_BLA_CHEST02_EAST, FTR_SUM_BLA_CHEST02_NORTH, FTR_SUM_BLA_CHEST02_WEST ,
FTR_SUM_BLA_DESK01_SOUTH, FTR_SUM_BLA_DESK01_EAST, FTR_SUM_BLA_DESK01_NORTH, FTR_SUM_BLA_DESK01_WEST ,
FTR_SUM_BLA_SOFA02_SOUTH, FTR_SUM_BLA_SOFA02_EAST, FTR_SUM_BLA_SOFA02_NORTH, FTR_SUM_BLA_SOFA02_WEST ,
FTR_SUM_BLA_TABLE01_SOUTH, FTR_SUM_BLA_TABLE01_EAST, FTR_SUM_BLA_TABLE01_NORTH, FTR_SUM_BLA_TABLE01_WEST ,
FTR_SUM_BLUE_BED01_SOUTH, FTR_SUM_BLUE_BED01_EAST, FTR_SUM_BLUE_BED01_NORTH, FTR_SUM_BLUE_BED01_WEST ,
FTR_SUM_BLUE_BENCH01_SOUTH, FTR_SUM_BLUE_BENCH01_EAST, FTR_SUM_BLUE_BENCH01_NORTH, FTR_SUM_BLUE_BENCH01_WEST ,
FTR_SUM_BLUE_CHAIR01_SOUTH, FTR_SUM_BLUE_CHAIR01_EAST, FTR_SUM_BLUE_CHAIR01_NORTH, FTR_SUM_BLUE_CHAIR01_WEST ,
FTR_SUM_BLUE_CHEST01_SOUTH, FTR_SUM_BLUE_CHEST01_EAST, FTR_SUM_BLUE_CHEST01_NORTH, FTR_SUM_BLUE_CHEST01_WEST ,
FTR_SUM_BLUE_CHEST02_SOUTH, FTR_SUM_BLUE_CHEST02_EAST, FTR_SUM_BLUE_CHEST02_NORTH, FTR_SUM_BLUE_CHEST02_WEST ,
FTR_SUM_BLUE_TABLE01_SOUTH, FTR_SUM_BLUE_TABLE01_EAST, FTR_SUM_BLUE_TABLE01_NORTH, FTR_SUM_BLUE_TABLE01_WEST ,
FTR_SUM_GRE_BED01_SOUTH, FTR_SUM_GRE_BED01_EAST, FTR_SUM_GRE_BED01_NORTH, FTR_SUM_GRE_BED01_WEST ,
FTR_SUM_GRE_CHAIR01_SOUTH, FTR_SUM_GRE_CHAIR01_EAST, FTR_SUM_GRE_CHAIR01_NORTH, FTR_SUM_GRE_CHAIR01_WEST ,
FTR_SUM_GRE_CHAIR02_SOUTH, FTR_SUM_GRE_CHAIR02_EAST, FTR_SUM_GRE_CHAIR02_NORTH, FTR_SUM_GRE_CHAIR02_WEST ,
FTR_SUM_GRE_CHEST01_SOUTH, FTR_SUM_GRE_CHEST01_EAST, FTR_SUM_GRE_CHEST01_NORTH, FTR_SUM_GRE_CHEST01_WEST ,
FTR_SUM_GRE_COUNTER01_SOUTH, FTR_SUM_GRE_COUNTER01_EAST, FTR_SUM_GRE_COUNTER01_NORTH, FTR_SUM_GRE_COUNTER01_WEST ,
FTR_SUM_GRE_LANP01_SOUTH, FTR_SUM_GRE_LANP01_EAST, FTR_SUM_GRE_LANP01_NORTH, FTR_SUM_GRE_LANP01_WEST ,
FTR_SUM_GRE_TABLE01_SOUTH, FTR_SUM_GRE_TABLE01_EAST, FTR_SUM_GRE_TABLE01_NORTH, FTR_SUM_GRE_TABLE01_WEST ,
FTR_SUM_LOG_BED01_SOUTH, FTR_SUM_LOG_BED01_EAST, FTR_SUM_LOG_BED01_NORTH, FTR_SUM_LOG_BED01_WEST ,
FTR_SUM_LOG_CHAIR01_SOUTH, FTR_SUM_LOG_CHAIR01_EAST, FTR_SUM_LOG_CHAIR01_NORTH, FTR_SUM_LOG_CHAIR01_WEST ,
FTR_SUM_LOG_CHAIR02_SOUTH, FTR_SUM_LOG_CHAIR02_EAST, FTR_SUM_LOG_CHAIR02_NORTH, FTR_SUM_LOG_CHAIR02_WEST ,
FTR_SUM_LOG_CHEST03_SOUTH, FTR_SUM_LOG_CHEST03_EAST, FTR_SUM_LOG_CHEST03_NORTH, FTR_SUM_LOG_CHEST03_WEST ,
FTR_SUM_LOG_TABLE01_SOUTH, FTR_SUM_LOG_TABLE01_EAST, FTR_SUM_LOG_TABLE01_NORTH, FTR_SUM_LOG_TABLE01_WEST ,
FTR_SUM_PL_ALOE01_SOUTH, FTR_SUM_PL_ALOE01_EAST, FTR_SUM_PL_ALOE01_NORTH, FTR_SUM_PL_ALOE01_WEST ,
FTR_SUM_PL_ANANAS_SOUTH, FTR_SUM_PL_ANANAS_EAST, FTR_SUM_PL_ANANAS_NORTH, FTR_SUM_PL_ANANAS_WEST ,
FTR_SUM_PL_COCOS_SOUTH, FTR_SUM_PL_COCOS_EAST, FTR_SUM_PL_COCOS_NORTH, FTR_SUM_PL_COCOS_WEST ,
FTR_SUM_PL_COMPACTA_SOUTH, FTR_SUM_PL_COMPACTA_EAST, FTR_SUM_PL_COMPACTA_NORTH, FTR_SUM_PL_COMPACTA_WEST ,
FTR_SUM_PL_DRACAENA_SOUTH, FTR_SUM_PL_DRACAENA_EAST, FTR_SUM_PL_DRACAENA_NORTH, FTR_SUM_PL_DRACAENA_WEST ,
FTR_SUM_PL_GOMUNOKI_SOUTH, FTR_SUM_PL_GOMUNOKI_EAST, FTR_SUM_PL_GOMUNOKI_NORTH, FTR_SUM_PL_GOMUNOKI_WEST ,
FTR_SUM_PL_POTHOS_SOUTH, FTR_SUM_PL_POTHOS_EAST, FTR_SUM_PL_POTHOS_NORTH, FTR_SUM_PL_POTHOS_WEST ,
FTR_SUM_PL_YAMAYASI_SOUTH, FTR_SUM_PL_YAMAYASI_EAST, FTR_SUM_PL_YAMAYASI_NORTH, FTR_SUM_PL_YAMAYASI_WEST ,
FTR_SUM_FRUITTABLE02_SOUTH, FTR_SUM_FRUITTABLE02_EAST, FTR_SUM_FRUITTABLE02_NORTH, FTR_SUM_FRUITTABLE02_WEST ,
FTR_SUM_FRUITCHAIR02_SOUTH, FTR_SUM_FRUITCHAIR02_EAST, FTR_SUM_FRUITCHAIR02_NORTH, FTR_SUM_FRUITCHAIR02_WEST ,
FTR_SUM_PL_BENJYAMI_SOUTH, FTR_SUM_PL_BENJYAMI_EAST, FTR_SUM_PL_BENJYAMI_NORTH, FTR_SUM_PL_BENJYAMI_WEST ,
FTR_SUM_PL_DRACA02_SOUTH, FTR_SUM_PL_DRACA02_EAST, FTR_SUM_PL_DRACA02_NORTH, FTR_SUM_PL_DRACA02_WEST ,
FTR_SUM_PL_KUROTON_SOUTH, FTR_SUM_PL_KUROTON_EAST, FTR_SUM_PL_KUROTON_NORTH, FTR_SUM_PL_KUROTON_WEST ,
FTR_SUM_PL_PAKILA_SOUTH, FTR_SUM_PL_PAKILA_EAST, FTR_SUM_PL_PAKILA_NORTH, FTR_SUM_PL_PAKILA_WEST ,
FTR_SUM_PL_HIRASABO_SOUTH, FTR_SUM_PL_HIRASABO_EAST, FTR_SUM_PL_HIRASABO_NORTH, FTR_SUM_PL_HIRASABO_WEST ,
FTR_TAK_METRO_SOUTH, FTR_TAK_METRO_EAST, FTR_TAK_METRO_NORTH, FTR_TAK_METRO_WEST ,
FTR_KON_SISIODOSI_SOUTH, FTR_KON_SISIODOSI_EAST, FTR_KON_SISIODOSI_NORTH, FTR_KON_SISIODOSI_WEST ,
FTR_SUM_BON_MATU01_SOUTH, FTR_SUM_BON_MATU01_EAST, FTR_SUM_BON_MATU01_NORTH, FTR_SUM_BON_MATU01_WEST ,
FTR_SUM_BON_MATU02_SOUTH, FTR_SUM_BON_MATU02_EAST, FTR_SUM_BON_MATU02_NORTH, FTR_SUM_BON_MATU02_WEST ,
FTR_TAK_BARBER_SOUTH, FTR_TAK_BARBER_EAST, FTR_TAK_BARBER_NORTH, FTR_TAK_BARBER_WEST ,
FTR_SUM_BON_MATU03_SOUTH, FTR_SUM_BON_MATU03_EAST, FTR_SUM_BON_MATU03_NORTH, FTR_SUM_BON_MATU03_WEST ,
FTR_SUM_BON_UME_SOUTH, FTR_SUM_BON_UME_EAST, FTR_SUM_BON_UME_NORTH, FTR_SUM_BON_UME_WEST ,
FTR_NOG_DARUMAL_SOUTH, FTR_NOG_DARUMAL_EAST, FTR_NOG_DARUMAL_NORTH, FTR_NOG_DARUMAL_WEST ,
FTR_NOG_DARUMAM_SOUTH, FTR_NOG_DARUMAM_EAST, FTR_NOG_DARUMAM_NORTH, FTR_NOG_DARUMAM_WEST ,
FTR_NOG_DARUMAS_SOUTH, FTR_NOG_DARUMAS_EAST, FTR_NOG_DARUMAS_NORTH, FTR_NOG_DARUMAS_WEST ,
FTR_SUM_BON_BOKE_SOUTH, FTR_SUM_BON_BOKE_EAST, FTR_SUM_BON_BOKE_NORTH, FTR_SUM_BON_BOKE_WEST ,
FTR_SUM_BON_SATUKI_SOUTH, FTR_SUM_BON_SATUKI_EAST, FTR_SUM_BON_SATUKI_NORTH, FTR_SUM_BON_SATUKI_WEST ,
FTR_SUM_BON_SANSHU_SOUTH, FTR_SUM_BON_SANSHU_EAST, FTR_SUM_BON_SANSHU_NORTH, FTR_SUM_BON_SANSHU_WEST ,
FTR_KON_CRACKER_SOUTH, FTR_KON_CRACKER_EAST, FTR_KON_CRACKER_NORTH, FTR_KON_CRACKER_WEST ,
FTR_TAK_CONE01_SOUTH, FTR_TAK_CONE01_EAST, FTR_TAK_CONE01_NORTH, FTR_TAK_CONE01_WEST ,
FTR_TAK_CONE02_SOUTH, FTR_TAK_CONE02_EAST, FTR_TAK_CONE02_NORTH, FTR_TAK_CONE02_WEST ,
FTR_TAK_CONE03_SOUTH, FTR_TAK_CONE03_EAST, FTR_TAK_CONE03_NORTH, FTR_TAK_CONE03_WEST ,
FTR_KON_JIHANKI01_SOUTH, FTR_KON_JIHANKI01_EAST, FTR_KON_JIHANKI01_NORTH, FTR_KON_JIHANKI01_WEST ,
FTR_SUM_BON_MOMIJI_SOUTH, FTR_SUM_BON_MOMIJI_EAST, FTR_SUM_BON_MOMIJI_NORTH, FTR_SUM_BON_MOMIJI_WEST ,
FTR_SUM_BON_PIRA_SOUTH, FTR_SUM_BON_PIRA_EAST, FTR_SUM_BON_PIRA_NORTH, FTR_SUM_BON_PIRA_WEST ,
FTR_SUM_BON_TURU_SOUTH, FTR_SUM_BON_TURU_EAST, FTR_SUM_BON_TURU_NORTH, FTR_SUM_BON_TURU_WEST ,
FTR_TAK_FENCE01_SOUTH, FTR_TAK_FENCE01_EAST, FTR_TAK_FENCE01_NORTH, FTR_TAK_FENCE01_WEST ,
FTR_TAK_FENCE02_SOUTH, FTR_TAK_FENCE02_EAST, FTR_TAK_FENCE02_NORTH, FTR_TAK_FENCE02_WEST ,
FTR_TAK_FENCE03_SOUTH, FTR_TAK_FENCE03_EAST, FTR_TAK_FENCE03_NORTH, FTR_TAK_FENCE03_WEST ,
FTR_TAK_FENCE04_SOUTH, FTR_TAK_FENCE04_EAST, FTR_TAK_FENCE04_NORTH, FTR_TAK_FENCE04_WEST ,
FTR_KON_JIHANKI02_SOUTH, FTR_KON_JIHANKI02_EAST, FTR_KON_JIHANKI02_NORTH, FTR_KON_JIHANKI02_WEST ,
FTR_TAK_HOLE01_SOUTH, FTR_TAK_HOLE01_EAST, FTR_TAK_HOLE01_NORTH, FTR_TAK_HOLE01_WEST ,
FTR_KON_JIHANKI03_SOUTH, FTR_KON_JIHANKI03_EAST, FTR_KON_JIHANKI03_NORTH, FTR_KON_JIHANKI03_WEST ,
FTR_TAK_DRUM01_SOUTH, FTR_TAK_DRUM01_EAST, FTR_TAK_DRUM01_NORTH, FTR_TAK_DRUM01_WEST ,
FTR_TAK_DRUM02_SOUTH, FTR_TAK_DRUM02_EAST, FTR_TAK_DRUM02_NORTH, FTR_TAK_DRUM02_WEST ,
FTR_TAK_DRUM03_SOUTH, FTR_TAK_DRUM03_EAST, FTR_TAK_DRUM03_NORTH, FTR_TAK_DRUM03_WEST ,
FTR_KON_JIHANKI04_SOUTH, FTR_KON_JIHANKI04_EAST, FTR_KON_JIHANKI04_NORTH, FTR_KON_JIHANKI04_WEST ,
FTR_TAK_TEKKIN_SOUTH, FTR_TAK_TEKKIN_EAST, FTR_TAK_TEKKIN_NORTH, FTR_TAK_TEKKIN_WEST ,
FTR_KON_GOMI01_SOUTH, FTR_KON_GOMI01_EAST, FTR_KON_GOMI01_NORTH, FTR_KON_GOMI01_WEST ,
FTR_KON_GOMI02_SOUTH, FTR_KON_GOMI02_EAST, FTR_KON_GOMI02_NORTH, FTR_KON_GOMI02_WEST ,
FTR_SUM_FRUITCHAIR03_SOUTH, FTR_SUM_FRUITCHAIR03_EAST, FTR_SUM_FRUITCHAIR03_NORTH, FTR_SUM_FRUITCHAIR03_WEST ,
FTR_SUM_FRUITCHAIR04_SOUTH, FTR_SUM_FRUITCHAIR04_EAST, FTR_SUM_FRUITCHAIR04_NORTH, FTR_SUM_FRUITCHAIR04_WEST ,
FTR_SUM_FRUITTABLE03_SOUTH, FTR_SUM_FRUITTABLE03_EAST, FTR_SUM_FRUITTABLE03_NORTH, FTR_SUM_FRUITTABLE03_WEST ,
FTR_TAK_UDEFURI_SOUTH, FTR_TAK_UDEFURI_EAST, FTR_TAK_UDEFURI_NORTH, FTR_TAK_UDEFURI_WEST ,
FTR_KON_GOMI03_SOUTH, FTR_KON_GOMI03_EAST, FTR_KON_GOMI03_NORTH, FTR_KON_GOMI03_WEST ,
FTR_KON_GOMI04_SOUTH, FTR_KON_GOMI04_EAST, FTR_KON_GOMI04_NORTH, FTR_KON_GOMI04_WEST ,
FTR_SUM_VIOLA01_SOUTH, FTR_SUM_VIOLA01_EAST, FTR_SUM_VIOLA01_NORTH, FTR_SUM_VIOLA01_WEST ,
FTR_SUM_BASS01_SOUTH, FTR_SUM_BASS01_EAST, FTR_SUM_BASS01_NORTH, FTR_SUM_BASS01_WEST ,
FTR_SUM_CELLO01_SOUTH, FTR_SUM_CELLO01_EAST, FTR_SUM_CELLO01_NORTH, FTR_SUM_CELLO01_WEST ,
FTR_SUM_PIANO01_SOUTH, FTR_SUM_PIANO01_EAST, FTR_SUM_PIANO01_NORTH, FTR_SUM_PIANO01_WEST ,
FTR_KON_CHOUZU01_SOUTH, FTR_KON_CHOUZU01_EAST, FTR_KON_CHOUZU01_NORTH, FTR_KON_CHOUZU01_WEST ,
FTR_TAK_NEKO_SOUTH, FTR_TAK_NEKO_EAST, FTR_TAK_NEKO_NORTH, FTR_TAK_NEKO_WEST ,
FTR_KON_CHOUZU02_SOUTH, FTR_KON_CHOUZU02_EAST, FTR_KON_CHOUZU02_NORTH, FTR_KON_CHOUZU02_WEST ,
FTR_SUM_HAL_PKIN_SOUTH, FTR_SUM_HAL_PKIN_EAST, FTR_SUM_HAL_PKIN_NORTH, FTR_SUM_HAL_PKIN_WEST ,
FTR_TAK_DENKO_SOUTH, FTR_TAK_DENKO_EAST, FTR_TAK_DENKO_NORTH, FTR_TAK_DENKO_WEST ,
FTR_TAK_YAJI_SOUTH, FTR_TAK_YAJI_EAST, FTR_TAK_YAJI_NORTH, FTR_TAK_YAJI_WEST ,
FTR_KON_ISI01_SOUTH, FTR_KON_ISI01_EAST, FTR_KON_ISI01_NORTH, FTR_KON_ISI01_WEST ,
FTR_KON_ISI02_SOUTH, FTR_KON_ISI02_EAST, FTR_KON_ISI02_NORTH, FTR_KON_ISI02_WEST ,
FTR_TAK_KANBAN01_SOUTH, FTR_TAK_KANBAN01_EAST, FTR_TAK_KANBAN01_NORTH, FTR_TAK_KANBAN01_WEST ,
FTR_TAK_KANBAN02_SOUTH, FTR_TAK_KANBAN02_EAST, FTR_TAK_KANBAN02_NORTH, FTR_TAK_KANBAN02_WEST ,
FTR_TAK_KANBAN03_SOUTH, FTR_TAK_KANBAN03_EAST, FTR_TAK_KANBAN03_NORTH, FTR_TAK_KANBAN03_WEST ,
FTR_KON_CHOUZU03_SOUTH, FTR_KON_CHOUZU03_EAST, FTR_KON_CHOUZU03_NORTH, FTR_KON_CHOUZU03_WEST ,
FTR_SUM_HAL_BED01_SOUTH, FTR_SUM_HAL_BED01_EAST, FTR_SUM_HAL_BED01_NORTH, FTR_SUM_HAL_BED01_WEST ,
FTR_SUM_HAL_BOX01_SOUTH, FTR_SUM_HAL_BOX01_EAST, FTR_SUM_HAL_BOX01_NORTH, FTR_SUM_HAL_BOX01_WEST ,
FTR_SUM_HAL_CHAIR01_SOUTH, FTR_SUM_HAL_CHAIR01_EAST, FTR_SUM_HAL_CHAIR01_NORTH, FTR_SUM_HAL_CHAIR01_WEST ,
FTR_SUM_GST_CHAIR01_SOUTH, FTR_SUM_GST_CHAIR01_EAST, FTR_SUM_GST_CHAIR01_NORTH, FTR_SUM_GST_CHAIR01_WEST ,
FTR_SUM_HAL_CHEST01_SOUTH, FTR_SUM_HAL_CHEST01_EAST, FTR_SUM_HAL_CHEST01_NORTH, FTR_SUM_HAL_CHEST01_WEST ,
FTR_SUM_HAL_SOFA01_SOUTH, FTR_SUM_HAL_SOFA01_EAST, FTR_SUM_HAL_SOFA01_NORTH, FTR_SUM_HAL_SOFA01_WEST ,
FTR_SUM_HAL_TABLE01_SOUTH, FTR_SUM_HAL_TABLE01_EAST, FTR_SUM_HAL_TABLE01_NORTH, FTR_SUM_HAL_TABLE01_WEST ,
FTR_TAK_APOLLO1_SOUTH, FTR_TAK_APOLLO1_EAST, FTR_TAK_APOLLO1_NORTH, FTR_TAK_APOLLO1_WEST ,
FTR_TAK_EISEI_SOUTH, FTR_TAK_EISEI_EAST, FTR_TAK_EISEI_NORTH, FTR_TAK_EISEI_WEST ,
FTR_KON_ISI03_SOUTH, FTR_KON_ISI03_EAST, FTR_KON_ISI03_NORTH, FTR_KON_ISI03_WEST ,
FTR_KON_ISI04_SOUTH, FTR_KON_ISI04_EAST, FTR_KON_ISI04_NORTH, FTR_KON_ISI04_WEST ,
FTR_KON_ISI05_SOUTH, FTR_KON_ISI05_EAST, FTR_KON_ISI05_NORTH, FTR_KON_ISI05_WEST ,
FTR_TAK_UFO_SOUTH, FTR_TAK_UFO_EAST, FTR_TAK_UFO_NORTH, FTR_TAK_UFO_WEST ,
FTR_KON_ISI06_SOUTH, FTR_KON_ISI06_EAST, FTR_KON_ISI06_NORTH, FTR_KON_ISI06_WEST ,
FTR_KON_POUND_SOUTH, FTR_KON_POUND_EAST, FTR_KON_POUND_NORTH, FTR_KON_POUND_WEST ,
FTR_TAK_ROCKET1_SOUTH, FTR_TAK_ROCKET1_EAST, FTR_TAK_ROCKET1_NORTH, FTR_TAK_ROCKET1_WEST ,
FTR_TAK_ASTRO_SOUTH, FTR_TAK_ASTRO_EAST, FTR_TAK_ASTRO_NORTH, FTR_TAK_ASTRO_WEST ,
FTR_SUM_HAL_CLK01_SOUTH, FTR_SUM_HAL_CLK01_EAST, FTR_SUM_HAL_CLK01_NORTH, FTR_SUM_HAL_CLK01_WEST ,
FTR_SUM_HAL_LANP01_SOUTH, FTR_SUM_HAL_LANP01_EAST, FTR_SUM_HAL_LANP01_NORTH, FTR_SUM_HAL_LANP01_WEST ,
FTR_SUM_ASI_BED01_SOUTH, FTR_SUM_ASI_BED01_EAST, FTR_SUM_ASI_BED01_NORTH, FTR_SUM_ASI_BED01_WEST ,
FTR_SUM_ASI_TABLE02_SOUTH, FTR_SUM_ASI_TABLE02_EAST, FTR_SUM_ASI_TABLE02_NORTH, FTR_SUM_ASI_TABLE02_WEST ,
FTR_TAK_ASTEROID1_SOUTH, FTR_TAK_ASTEROID1_EAST, FTR_TAK_ASTEROID1_NORTH, FTR_TAK_ASTEROID1_WEST ,
FTR_SUM_RATAN_LANP_SOUTH, FTR_SUM_RATAN_LANP_EAST, FTR_SUM_RATAN_LANP_NORTH, FTR_SUM_RATAN_LANP_WEST ,
FTR_SUM_RATAN_TABLE01_SOUTH, FTR_SUM_RATAN_TABLE01_EAST, FTR_SUM_RATAN_TABLE01_NORTH, FTR_SUM_RATAN_TABLE01_WEST ,
FTR_KON_OKE_SOUTH, FTR_KON_OKE_EAST, FTR_KON_OKE_NORTH, FTR_KON_OKE_WEST ,
FTR_KON_TAIJU_SOUTH, FTR_KON_TAIJU_EAST, FTR_KON_TAIJU_NORTH, FTR_KON_TAIJU_WEST ,
FTR_KON_ARAIBA_SOUTH, FTR_KON_ARAIBA_EAST, FTR_KON_ARAIBA_NORTH, FTR_KON_ARAIBA_WEST ,
FTR_KON_HUROISU_SOUTH, FTR_KON_HUROISU_EAST, FTR_KON_HUROISU_NORTH, FTR_KON_HUROISU_WEST ,
FTR_SUM_RATAN_SCREEN_SOUTH, FTR_SUM_RATAN_SCREEN_EAST, FTR_SUM_RATAN_SCREEN_NORTH, FTR_SUM_RATAN_SCREEN_WEST ,
FTR_SUM_RATAN_MIRROR_SOUTH, FTR_SUM_RATAN_MIRROR_EAST, FTR_SUM_RATAN_MIRROR_NORTH, FTR_SUM_RATAN_MIRROR_WEST ,
FTR_SUM_RATAN_ISU02_SOUTH, FTR_SUM_RATAN_ISU02_EAST, FTR_SUM_RATAN_ISU02_NORTH, FTR_SUM_RATAN_ISU02_WEST ,
FTR_SUM_RATAN_CHEST03_SOUTH, FTR_SUM_RATAN_CHEST03_EAST, FTR_SUM_RATAN_CHEST03_NORTH, FTR_SUM_RATAN_CHEST03_WEST ,
FTR_TAK_ARWING_SOUTH, FTR_TAK_ARWING_EAST, FTR_TAK_ARWING_NORTH, FTR_TAK_ARWING_WEST ,
FTR_TAK_MOONCAR_SOUTH, FTR_TAK_MOONCAR_EAST, FTR_TAK_MOONCAR_NORTH, FTR_TAK_MOONCAR_WEST ,
FTR_KON_MASAJI_SOUTH, FTR_KON_MASAJI_EAST, FTR_KON_MASAJI_NORTH, FTR_KON_MASAJI_WEST ,
FTR_KON_MAT_SOUTH, FTR_KON_MAT_EAST, FTR_KON_MAT_NORTH, FTR_KON_MAT_WEST ,
FTR_KON_YUBUNE_SOUTH, FTR_KON_YUBUNE_EAST, FTR_KON_YUBUNE_NORTH, FTR_KON_YUBUNE_WEST ,
FTR_SUM_BLUE_CLK_SOUTH, FTR_SUM_BLUE_CLK_EAST, FTR_SUM_BLUE_CLK_NORTH, FTR_SUM_BLUE_CLK_WEST ,
FTR_TAK_MOTI_SOUTH, FTR_TAK_MOTI_EAST, FTR_TAK_MOTI_NORTH, FTR_TAK_MOTI_WEST ,
FTR_SUM_HAL_MIRROR01_SOUTH, FTR_SUM_HAL_MIRROR01_EAST, FTR_SUM_HAL_MIRROR01_NORTH, FTR_SUM_HAL_MIRROR01_WEST ,
FTR_SUM_GRE_DESK01_SOUTH, FTR_SUM_GRE_DESK01_EAST, FTR_SUM_GRE_DESK01_NORTH, FTR_SUM_GRE_DESK01_WEST ,
FTR_KON_BANDAI_SOUTH, FTR_KON_BANDAI_EAST, FTR_KON_BANDAI_NORTH, FTR_KON_BANDAI_WEST ,
FTR_SUM_BLA_CHAIR02_SOUTH, FTR_SUM_BLA_CHAIR02_EAST, FTR_SUM_BLA_CHAIR02_NORTH, FTR_SUM_BLA_CHAIR02_WEST ,
FTR_SUM_BLA_TABLE02_SOUTH, FTR_SUM_BLA_TABLE02_EAST, FTR_SUM_BLA_TABLE02_NORTH, FTR_SUM_BLA_TABLE02_WEST ,
FTR_TAK_STATION_SOUTH, FTR_TAK_STATION_EAST, FTR_TAK_STATION_NORTH, FTR_TAK_STATION_WEST ,
FTR_KON_TUITATE_SOUTH, FTR_KON_TUITATE_EAST, FTR_KON_TUITATE_NORTH, FTR_KON_TUITATE_WEST ,
FTR_SUM_LOG_CHAIR03_SOUTH, FTR_SUM_LOG_CHAIR03_EAST, FTR_SUM_LOG_CHAIR03_NORTH, FTR_SUM_LOG_CHAIR03_WEST ,
FTR_SUM_WHI_BED01_SOUTH, FTR_SUM_WHI_BED01_EAST, FTR_SUM_WHI_BED01_NORTH, FTR_SUM_WHI_BED01_WEST ,
FTR_TAK_SHUTTLE_SOUTH, FTR_TAK_SHUTTLE_EAST, FTR_TAK_SHUTTLE_NORTH, FTR_TAK_SHUTTLE_WEST ,
FTR_SUM_WHI_MIRROR_SOUTH, FTR_SUM_WHI_MIRROR_EAST, FTR_SUM_WHI_MIRROR_NORTH, FTR_SUM_WHI_MIRROR_WEST ,
FTR_SUM_WHI_SOFA01_SOUTH, FTR_SUM_WHI_SOFA01_EAST, FTR_SUM_WHI_SOFA01_NORTH, FTR_SUM_WHI_SOFA01_WEST ,
FTR_SUM_WHI_LANP_SOUTH, FTR_SUM_WHI_LANP_EAST, FTR_SUM_WHI_LANP_NORTH, FTR_SUM_WHI_LANP_WEST ,
FTR_SUM_LOG_TABLE02_SOUTH, FTR_SUM_LOG_TABLE02_EAST, FTR_SUM_LOG_TABLE02_NORTH, FTR_SUM_LOG_TABLE02_WEST ,
FTR_KON_LOCKER_SOUTH, FTR_KON_LOCKER_EAST, FTR_KON_LOCKER_NORTH, FTR_KON_LOCKER_WEST ,
FTR_KON_MILK_SOUTH, FTR_KON_MILK_EAST, FTR_KON_MILK_NORTH, FTR_KON_MILK_WEST ,
FTR_SUM_UWA_CUP01_SOUTH, FTR_SUM_UWA_CUP01_EAST, FTR_SUM_UWA_CUP01_NORTH, FTR_SUM_UWA_CUP01_WEST ,
FTR_SUM_UWA_POTO01_SOUTH, FTR_SUM_UWA_POTO01_EAST, FTR_SUM_UWA_POTO01_NORTH, FTR_SUM_UWA_POTO01_WEST ,
FTR_SUM_UWA_VASE01_SOUTH, FTR_SUM_UWA_VASE01_EAST, FTR_SUM_UWA_VASE01_NORTH, FTR_SUM_UWA_VASE01_WEST ,
FTR_SUM_UWA_VASE02_SOUTH, FTR_SUM_UWA_VASE02_EAST, FTR_SUM_UWA_VASE02_NORTH, FTR_SUM_UWA_VASE02_WEST ,
FTR_SUM_UWA_VASE03_SOUTH, FTR_SUM_UWA_VASE03_EAST, FTR_SUM_UWA_VASE03_NORTH, FTR_SUM_UWA_VASE03_WEST ,
FTR_HNW_COMMON000_SOUTH, FTR_HNW_COMMON000_EAST, FTR_HNW_COMMON000_NORTH, FTR_HNW_COMMON000_WEST ,
FTR_HNW_COMMON001_SOUTH, FTR_HNW_COMMON001_EAST, FTR_HNW_COMMON001_NORTH, FTR_HNW_COMMON001_WEST ,
FTR_HNW_COMMON002_SOUTH, FTR_HNW_COMMON002_EAST, FTR_HNW_COMMON002_NORTH, FTR_HNW_COMMON002_WEST ,
FTR_HNW_COMMON003_SOUTH, FTR_HNW_COMMON003_EAST, FTR_HNW_COMMON003_NORTH, FTR_HNW_COMMON003_WEST ,
FTR_HNW_COMMON004_SOUTH, FTR_HNW_COMMON004_EAST, FTR_HNW_COMMON004_NORTH, FTR_HNW_COMMON004_WEST ,
FTR_HNW_COMMON005_SOUTH, FTR_HNW_COMMON005_EAST, FTR_HNW_COMMON005_NORTH, FTR_HNW_COMMON005_WEST ,
FTR_HNW_COMMON006_SOUTH, FTR_HNW_COMMON006_EAST, FTR_HNW_COMMON006_NORTH, FTR_HNW_COMMON006_WEST ,
FTR_HNW_COMMON007_SOUTH, FTR_HNW_COMMON007_EAST, FTR_HNW_COMMON007_NORTH, FTR_HNW_COMMON007_WEST ,
FTR_HNW_COMMON008_SOUTH, FTR_HNW_COMMON008_EAST, FTR_HNW_COMMON008_NORTH, FTR_HNW_COMMON008_WEST ,
FTR_HNW_COMMON009_SOUTH, FTR_HNW_COMMON009_EAST, FTR_HNW_COMMON009_NORTH, FTR_HNW_COMMON009_WEST ,
FTR_HNW_COMMON010_SOUTH, FTR_HNW_COMMON010_EAST, FTR_HNW_COMMON010_NORTH, FTR_HNW_COMMON010_WEST ,
FTR_HNW_COMMON011_SOUTH, FTR_HNW_COMMON011_EAST, FTR_HNW_COMMON011_NORTH, FTR_HNW_COMMON011_WEST ,
FTR_HNW_COMMON012_SOUTH, FTR_HNW_COMMON012_EAST, FTR_HNW_COMMON012_NORTH, FTR_HNW_COMMON012_WEST ,
FTR_HNW_COMMON013_SOUTH, FTR_HNW_COMMON013_EAST, FTR_HNW_COMMON013_NORTH, FTR_HNW_COMMON013_WEST ,
FTR_HNW_COMMON014_SOUTH, FTR_HNW_COMMON014_EAST, FTR_HNW_COMMON014_NORTH, FTR_HNW_COMMON014_WEST ,
FTR_HNW_COMMON015_SOUTH, FTR_HNW_COMMON015_EAST, FTR_HNW_COMMON015_NORTH, FTR_HNW_COMMON015_WEST ,
FTR_HNW_COMMON016_SOUTH, FTR_HNW_COMMON016_EAST, FTR_HNW_COMMON016_NORTH, FTR_HNW_COMMON016_WEST ,
FTR_HNW_COMMON017_SOUTH, FTR_HNW_COMMON017_EAST, FTR_HNW_COMMON017_NORTH, FTR_HNW_COMMON017_WEST ,
FTR_HNW_COMMON018_SOUTH, FTR_HNW_COMMON018_EAST, FTR_HNW_COMMON018_NORTH, FTR_HNW_COMMON018_WEST ,
FTR_HNW_COMMON019_SOUTH, FTR_HNW_COMMON019_EAST, FTR_HNW_COMMON019_NORTH, FTR_HNW_COMMON019_WEST ,
FTR_HNW_COMMON020_SOUTH, FTR_HNW_COMMON020_EAST, FTR_HNW_COMMON020_NORTH, FTR_HNW_COMMON020_WEST ,
FTR_HNW_COMMON021_SOUTH, FTR_HNW_COMMON021_EAST, FTR_HNW_COMMON021_NORTH, FTR_HNW_COMMON021_WEST ,
FTR_HNW_COMMON022_SOUTH, FTR_HNW_COMMON022_EAST, FTR_HNW_COMMON022_NORTH, FTR_HNW_COMMON022_WEST ,
FTR_HNW_COMMON023_SOUTH, FTR_HNW_COMMON023_EAST, FTR_HNW_COMMON023_NORTH, FTR_HNW_COMMON023_WEST ,
FTR_HNW_COMMON024_SOUTH, FTR_HNW_COMMON024_EAST, FTR_HNW_COMMON024_NORTH, FTR_HNW_COMMON024_WEST ,
FTR_HNW_COMMON025_SOUTH, FTR_HNW_COMMON025_EAST, FTR_HNW_COMMON025_NORTH, FTR_HNW_COMMON025_WEST ,
FTR_HNW_COMMON026_SOUTH, FTR_HNW_COMMON026_EAST, FTR_HNW_COMMON026_NORTH, FTR_HNW_COMMON026_WEST ,
FTR_HNW_COMMON027_SOUTH, FTR_HNW_COMMON027_EAST, FTR_HNW_COMMON027_NORTH, FTR_HNW_COMMON027_WEST ,
FTR_HNW_COMMON028_SOUTH, FTR_HNW_COMMON028_EAST, FTR_HNW_COMMON028_NORTH, FTR_HNW_COMMON028_WEST ,
FTR_HNW_COMMON029_SOUTH, FTR_HNW_COMMON029_EAST, FTR_HNW_COMMON029_NORTH, FTR_HNW_COMMON029_WEST ,
FTR_HNW_COMMON030_SOUTH, FTR_HNW_COMMON030_EAST, FTR_HNW_COMMON030_NORTH, FTR_HNW_COMMON030_WEST ,
FTR_HNW_COMMON031_SOUTH, FTR_HNW_COMMON031_EAST, FTR_HNW_COMMON031_NORTH, FTR_HNW_COMMON031_WEST ,
FTR_HNW_COMMON032_SOUTH, FTR_HNW_COMMON032_EAST, FTR_HNW_COMMON032_NORTH, FTR_HNW_COMMON032_WEST ,
FTR_HNW_COMMON033_SOUTH, FTR_HNW_COMMON033_EAST, FTR_HNW_COMMON033_NORTH, FTR_HNW_COMMON033_WEST ,
FTR_HNW_COMMON034_SOUTH, FTR_HNW_COMMON034_EAST, FTR_HNW_COMMON034_NORTH, FTR_HNW_COMMON034_WEST ,
FTR_HNW_COMMON035_SOUTH, FTR_HNW_COMMON035_EAST, FTR_HNW_COMMON035_NORTH, FTR_HNW_COMMON035_WEST ,
FTR_HNW_COMMON036_SOUTH, FTR_HNW_COMMON036_EAST, FTR_HNW_COMMON036_NORTH, FTR_HNW_COMMON036_WEST ,
FTR_HNW_COMMON037_SOUTH, FTR_HNW_COMMON037_EAST, FTR_HNW_COMMON037_NORTH, FTR_HNW_COMMON037_WEST ,
FTR_HNW_COMMON038_SOUTH, FTR_HNW_COMMON038_EAST, FTR_HNW_COMMON038_NORTH, FTR_HNW_COMMON038_WEST ,
FTR_HNW_COMMON039_SOUTH, FTR_HNW_COMMON039_EAST, FTR_HNW_COMMON039_NORTH, FTR_HNW_COMMON039_WEST ,
FTR_HNW_COMMON040_SOUTH, FTR_HNW_COMMON040_EAST, FTR_HNW_COMMON040_NORTH, FTR_HNW_COMMON040_WEST ,
FTR_HNW_COMMON041_SOUTH, FTR_HNW_COMMON041_EAST, FTR_HNW_COMMON041_NORTH, FTR_HNW_COMMON041_WEST ,
FTR_HNW_COMMON042_SOUTH, FTR_HNW_COMMON042_EAST, FTR_HNW_COMMON042_NORTH, FTR_HNW_COMMON042_WEST ,
FTR_HNW_COMMON043_SOUTH, FTR_HNW_COMMON043_EAST, FTR_HNW_COMMON043_NORTH, FTR_HNW_COMMON043_WEST ,
FTR_HNW_COMMON044_SOUTH, FTR_HNW_COMMON044_EAST, FTR_HNW_COMMON044_NORTH, FTR_HNW_COMMON044_WEST ,
FTR_HNW_COMMON045_SOUTH, FTR_HNW_COMMON045_EAST, FTR_HNW_COMMON045_NORTH, FTR_HNW_COMMON045_WEST ,
FTR_HNW_COMMON046_SOUTH, FTR_HNW_COMMON046_EAST, FTR_HNW_COMMON046_NORTH, FTR_HNW_COMMON046_WEST ,
FTR_HNW_COMMON047_SOUTH, FTR_HNW_COMMON047_EAST, FTR_HNW_COMMON047_NORTH, FTR_HNW_COMMON047_WEST ,
FTR_HNW_COMMON048_SOUTH, FTR_HNW_COMMON048_EAST, FTR_HNW_COMMON048_NORTH, FTR_HNW_COMMON048_WEST ,
FTR_HNW_COMMON049_SOUTH, FTR_HNW_COMMON049_EAST, FTR_HNW_COMMON049_NORTH, FTR_HNW_COMMON049_WEST ,
FTR_HNW_COMMON050_SOUTH, FTR_HNW_COMMON050_EAST, FTR_HNW_COMMON050_NORTH, FTR_HNW_COMMON050_WEST ,
FTR_HNW_COMMON051_SOUTH, FTR_HNW_COMMON051_EAST, FTR_HNW_COMMON051_NORTH, FTR_HNW_COMMON051_WEST ,
FTR_HNW_COMMON052_SOUTH, FTR_HNW_COMMON052_EAST, FTR_HNW_COMMON052_NORTH, FTR_HNW_COMMON052_WEST ,
FTR_HNW_COMMON053_SOUTH, FTR_HNW_COMMON053_EAST, FTR_HNW_COMMON053_NORTH, FTR_HNW_COMMON053_WEST ,
FTR_HNW_COMMON054_SOUTH, FTR_HNW_COMMON054_EAST, FTR_HNW_COMMON054_NORTH, FTR_HNW_COMMON054_WEST ,
FTR_HNW_COMMON055_SOUTH, FTR_HNW_COMMON055_EAST, FTR_HNW_COMMON055_NORTH, FTR_HNW_COMMON055_WEST ,
FTR_HNW_COMMON056_SOUTH, FTR_HNW_COMMON056_EAST, FTR_HNW_COMMON056_NORTH, FTR_HNW_COMMON056_WEST ,
FTR_HNW_COMMON057_SOUTH, FTR_HNW_COMMON057_EAST, FTR_HNW_COMMON057_NORTH, FTR_HNW_COMMON057_WEST ,
FTR_HNW_COMMON058_SOUTH, FTR_HNW_COMMON058_EAST, FTR_HNW_COMMON058_NORTH, FTR_HNW_COMMON058_WEST ,
FTR_HNW_COMMON059_SOUTH, FTR_HNW_COMMON059_EAST, FTR_HNW_COMMON059_NORTH, FTR_HNW_COMMON059_WEST ,
FTR_HNW_COMMON060_SOUTH, FTR_HNW_COMMON060_EAST, FTR_HNW_COMMON060_NORTH, FTR_HNW_COMMON060_WEST ,
FTR_HNW_COMMON061_SOUTH, FTR_HNW_COMMON061_EAST, FTR_HNW_COMMON061_NORTH, FTR_HNW_COMMON061_WEST ,
FTR_HNW_COMMON062_SOUTH, FTR_HNW_COMMON062_EAST, FTR_HNW_COMMON062_NORTH, FTR_HNW_COMMON062_WEST ,
FTR_HNW_COMMON063_SOUTH, FTR_HNW_COMMON063_EAST, FTR_HNW_COMMON063_NORTH, FTR_HNW_COMMON063_WEST ,
FTR_HNW_COMMON064_SOUTH, FTR_HNW_COMMON064_EAST, FTR_HNW_COMMON064_NORTH, FTR_HNW_COMMON064_WEST ,
FTR_HNW_COMMON065_SOUTH, FTR_HNW_COMMON065_EAST, FTR_HNW_COMMON065_NORTH, FTR_HNW_COMMON065_WEST ,
FTR_HNW_COMMON066_SOUTH, FTR_HNW_COMMON066_EAST, FTR_HNW_COMMON066_NORTH, FTR_HNW_COMMON066_WEST ,
FTR_HNW_COMMON067_SOUTH, FTR_HNW_COMMON067_EAST, FTR_HNW_COMMON067_NORTH, FTR_HNW_COMMON067_WEST ,
FTR_HNW_COMMON068_SOUTH, FTR_HNW_COMMON068_EAST, FTR_HNW_COMMON068_NORTH, FTR_HNW_COMMON068_WEST ,
FTR_HNW_COMMON069_SOUTH, FTR_HNW_COMMON069_EAST, FTR_HNW_COMMON069_NORTH, FTR_HNW_COMMON069_WEST ,
FTR_HNW_COMMON070_SOUTH, FTR_HNW_COMMON070_EAST, FTR_HNW_COMMON070_NORTH, FTR_HNW_COMMON070_WEST ,
FTR_HNW_COMMON071_SOUTH, FTR_HNW_COMMON071_EAST, FTR_HNW_COMMON071_NORTH, FTR_HNW_COMMON071_WEST ,
FTR_HNW_COMMON072_SOUTH, FTR_HNW_COMMON072_EAST, FTR_HNW_COMMON072_NORTH, FTR_HNW_COMMON072_WEST ,
FTR_HNW_COMMON073_SOUTH, FTR_HNW_COMMON073_EAST, FTR_HNW_COMMON073_NORTH, FTR_HNW_COMMON073_WEST ,
FTR_HNW_COMMON074_SOUTH, FTR_HNW_COMMON074_EAST, FTR_HNW_COMMON074_NORTH, FTR_HNW_COMMON074_WEST ,
FTR_HNW_COMMON075_SOUTH, FTR_HNW_COMMON075_EAST, FTR_HNW_COMMON075_NORTH, FTR_HNW_COMMON075_WEST ,
FTR_HNW_COMMON076_SOUTH, FTR_HNW_COMMON076_EAST, FTR_HNW_COMMON076_NORTH, FTR_HNW_COMMON076_WEST ,
FTR_HNW_COMMON077_SOUTH, FTR_HNW_COMMON077_EAST, FTR_HNW_COMMON077_NORTH, FTR_HNW_COMMON077_WEST ,
FTR_HNW_COMMON078_SOUTH, FTR_HNW_COMMON078_EAST, FTR_HNW_COMMON078_NORTH, FTR_HNW_COMMON078_WEST ,
FTR_HNW_COMMON079_SOUTH, FTR_HNW_COMMON079_EAST, FTR_HNW_COMMON079_NORTH, FTR_HNW_COMMON079_WEST ,
FTR_HNW_COMMON080_SOUTH, FTR_HNW_COMMON080_EAST, FTR_HNW_COMMON080_NORTH, FTR_HNW_COMMON080_WEST ,
FTR_HNW_COMMON081_SOUTH, FTR_HNW_COMMON081_EAST, FTR_HNW_COMMON081_NORTH, FTR_HNW_COMMON081_WEST ,
FTR_HNW_COMMON082_SOUTH, FTR_HNW_COMMON082_EAST, FTR_HNW_COMMON082_NORTH, FTR_HNW_COMMON082_WEST ,
FTR_HNW_COMMON083_SOUTH, FTR_HNW_COMMON083_EAST, FTR_HNW_COMMON083_NORTH, FTR_HNW_COMMON083_WEST ,
FTR_HNW_COMMON084_SOUTH, FTR_HNW_COMMON084_EAST, FTR_HNW_COMMON084_NORTH, FTR_HNW_COMMON084_WEST ,
FTR_HNW_COMMON085_SOUTH, FTR_HNW_COMMON085_EAST, FTR_HNW_COMMON085_NORTH, FTR_HNW_COMMON085_WEST ,
FTR_HNW_COMMON086_SOUTH, FTR_HNW_COMMON086_EAST, FTR_HNW_COMMON086_NORTH, FTR_HNW_COMMON086_WEST ,
FTR_HNW_COMMON087_SOUTH, FTR_HNW_COMMON087_EAST, FTR_HNW_COMMON087_NORTH, FTR_HNW_COMMON087_WEST ,
FTR_HNW_COMMON088_SOUTH, FTR_HNW_COMMON088_EAST, FTR_HNW_COMMON088_NORTH, FTR_HNW_COMMON088_WEST ,
FTR_HNW_COMMON089_SOUTH, FTR_HNW_COMMON089_EAST, FTR_HNW_COMMON089_NORTH, FTR_HNW_COMMON089_WEST ,
FTR_HNW_COMMON090_SOUTH, FTR_HNW_COMMON090_EAST, FTR_HNW_COMMON090_NORTH, FTR_HNW_COMMON090_WEST ,
FTR_HNW_COMMON091_SOUTH, FTR_HNW_COMMON091_EAST, FTR_HNW_COMMON091_NORTH, FTR_HNW_COMMON091_WEST ,
FTR_HNW_COMMON092_SOUTH, FTR_HNW_COMMON092_EAST, FTR_HNW_COMMON092_NORTH, FTR_HNW_COMMON092_WEST ,
FTR_HNW_COMMON093_SOUTH, FTR_HNW_COMMON093_EAST, FTR_HNW_COMMON093_NORTH, FTR_HNW_COMMON093_WEST ,
FTR_HNW_COMMON094_SOUTH, FTR_HNW_COMMON094_EAST, FTR_HNW_COMMON094_NORTH, FTR_HNW_COMMON094_WEST ,
FTR_HNW_COMMON095_SOUTH, FTR_HNW_COMMON095_EAST, FTR_HNW_COMMON095_NORTH, FTR_HNW_COMMON095_WEST ,
FTR_HNW_COMMON096_SOUTH, FTR_HNW_COMMON096_EAST, FTR_HNW_COMMON096_NORTH, FTR_HNW_COMMON096_WEST ,
FTR_HNW_COMMON097_SOUTH, FTR_HNW_COMMON097_EAST, FTR_HNW_COMMON097_NORTH, FTR_HNW_COMMON097_WEST ,
FTR_HNW_COMMON098_SOUTH, FTR_HNW_COMMON098_EAST, FTR_HNW_COMMON098_NORTH, FTR_HNW_COMMON098_WEST ,
FTR_HNW_COMMON099_SOUTH, FTR_HNW_COMMON099_EAST, FTR_HNW_COMMON099_NORTH, FTR_HNW_COMMON099_WEST ,
FTR_HNW_COMMON100_SOUTH, FTR_HNW_COMMON100_EAST, FTR_HNW_COMMON100_NORTH, FTR_HNW_COMMON100_WEST ,
FTR_HNW_COMMON101_SOUTH, FTR_HNW_COMMON101_EAST, FTR_HNW_COMMON101_NORTH, FTR_HNW_COMMON101_WEST ,
FTR_HNW_COMMON102_SOUTH, FTR_HNW_COMMON102_EAST, FTR_HNW_COMMON102_NORTH, FTR_HNW_COMMON102_WEST ,
FTR_HNW_COMMON103_SOUTH, FTR_HNW_COMMON103_EAST, FTR_HNW_COMMON103_NORTH, FTR_HNW_COMMON103_WEST ,
FTR_HNW_COMMON104_SOUTH, FTR_HNW_COMMON104_EAST, FTR_HNW_COMMON104_NORTH, FTR_HNW_COMMON104_WEST ,
FTR_HNW_COMMON105_SOUTH, FTR_HNW_COMMON105_EAST, FTR_HNW_COMMON105_NORTH, FTR_HNW_COMMON105_WEST ,
FTR_HNW_COMMON106_SOUTH, FTR_HNW_COMMON106_EAST, FTR_HNW_COMMON106_NORTH, FTR_HNW_COMMON106_WEST ,
FTR_HNW_COMMON107_SOUTH, FTR_HNW_COMMON107_EAST, FTR_HNW_COMMON107_NORTH, FTR_HNW_COMMON107_WEST ,
FTR_HNW_COMMON108_SOUTH, FTR_HNW_COMMON108_EAST, FTR_HNW_COMMON108_NORTH, FTR_HNW_COMMON108_WEST ,
FTR_HNW_COMMON109_SOUTH, FTR_HNW_COMMON109_EAST, FTR_HNW_COMMON109_NORTH, FTR_HNW_COMMON109_WEST ,
FTR_HNW_COMMON110_SOUTH, FTR_HNW_COMMON110_EAST, FTR_HNW_COMMON110_NORTH, FTR_HNW_COMMON110_WEST ,
FTR_HNW_COMMON111_SOUTH, FTR_HNW_COMMON111_EAST, FTR_HNW_COMMON111_NORTH, FTR_HNW_COMMON111_WEST ,
FTR_HNW_COMMON112_SOUTH, FTR_HNW_COMMON112_EAST, FTR_HNW_COMMON112_NORTH, FTR_HNW_COMMON112_WEST ,
FTR_HNW_COMMON113_SOUTH, FTR_HNW_COMMON113_EAST, FTR_HNW_COMMON113_NORTH, FTR_HNW_COMMON113_WEST ,
FTR_HNW_COMMON114_SOUTH, FTR_HNW_COMMON114_EAST, FTR_HNW_COMMON114_NORTH, FTR_HNW_COMMON114_WEST ,
FTR_HNW_COMMON115_SOUTH, FTR_HNW_COMMON115_EAST, FTR_HNW_COMMON115_NORTH, FTR_HNW_COMMON115_WEST ,
FTR_HNW_COMMON116_SOUTH, FTR_HNW_COMMON116_EAST, FTR_HNW_COMMON116_NORTH, FTR_HNW_COMMON116_WEST ,
FTR_HNW_COMMON117_SOUTH, FTR_HNW_COMMON117_EAST, FTR_HNW_COMMON117_NORTH, FTR_HNW_COMMON117_WEST ,
FTR_HNW_COMMON118_SOUTH, FTR_HNW_COMMON118_EAST, FTR_HNW_COMMON118_NORTH, FTR_HNW_COMMON118_WEST ,
FTR_HNW_COMMON119_SOUTH, FTR_HNW_COMMON119_EAST, FTR_HNW_COMMON119_NORTH, FTR_HNW_COMMON119_WEST ,
FTR_HNW_COMMON120_SOUTH, FTR_HNW_COMMON120_EAST, FTR_HNW_COMMON120_NORTH, FTR_HNW_COMMON120_WEST ,
FTR_HNW_COMMON121_SOUTH, FTR_HNW_COMMON121_EAST, FTR_HNW_COMMON121_NORTH, FTR_HNW_COMMON121_WEST ,
FTR_HNW_COMMON122_SOUTH, FTR_HNW_COMMON122_EAST, FTR_HNW_COMMON122_NORTH, FTR_HNW_COMMON122_WEST ,
FTR_HNW_COMMON123_SOUTH, FTR_HNW_COMMON123_EAST, FTR_HNW_COMMON123_NORTH, FTR_HNW_COMMON123_WEST ,
FTR_HNW_COMMON124_SOUTH, FTR_HNW_COMMON124_EAST, FTR_HNW_COMMON124_NORTH, FTR_HNW_COMMON124_WEST ,
FTR_HNW_COMMON125_SOUTH, FTR_HNW_COMMON125_EAST, FTR_HNW_COMMON125_NORTH, FTR_HNW_COMMON125_WEST ,
FTR_HNW_COMMON126_SOUTH, FTR_HNW_COMMON126_EAST, FTR_HNW_COMMON126_NORTH, FTR_HNW_COMMON126_WEST ,
FTR_FMANEKIN000_SOUTH, FTR_FMANEKIN000_EAST, FTR_FMANEKIN000_NORTH, FTR_FMANEKIN000_WEST ,
FTR_FMANEKIN001_SOUTH, FTR_FMANEKIN001_EAST, FTR_FMANEKIN001_NORTH, FTR_FMANEKIN001_WEST ,
FTR_FMANEKIN002_SOUTH, FTR_FMANEKIN002_EAST, FTR_FMANEKIN002_NORTH, FTR_FMANEKIN002_WEST ,
FTR_FMANEKIN003_SOUTH, FTR_FMANEKIN003_EAST, FTR_FMANEKIN003_NORTH, FTR_FMANEKIN003_WEST ,
FTR_FMANEKIN004_SOUTH, FTR_FMANEKIN004_EAST, FTR_FMANEKIN004_NORTH, FTR_FMANEKIN004_WEST ,
FTR_FMANEKIN005_SOUTH, FTR_FMANEKIN005_EAST, FTR_FMANEKIN005_NORTH, FTR_FMANEKIN005_WEST ,
FTR_FMANEKIN006_SOUTH, FTR_FMANEKIN006_EAST, FTR_FMANEKIN006_NORTH, FTR_FMANEKIN006_WEST ,
FTR_FMANEKIN007_SOUTH, FTR_FMANEKIN007_EAST, FTR_FMANEKIN007_NORTH, FTR_FMANEKIN007_WEST ,
FTR_FMANEKIN008_SOUTH, FTR_FMANEKIN008_EAST, FTR_FMANEKIN008_NORTH, FTR_FMANEKIN008_WEST ,
FTR_FMANEKIN009_SOUTH, FTR_FMANEKIN009_EAST, FTR_FMANEKIN009_NORTH, FTR_FMANEKIN009_WEST ,
FTR_FMANEKIN010_SOUTH, FTR_FMANEKIN010_EAST, FTR_FMANEKIN010_NORTH, FTR_FMANEKIN010_WEST ,
FTR_FMANEKIN011_SOUTH, FTR_FMANEKIN011_EAST, FTR_FMANEKIN011_NORTH, FTR_FMANEKIN011_WEST ,
FTR_FMANEKIN012_SOUTH, FTR_FMANEKIN012_EAST, FTR_FMANEKIN012_NORTH, FTR_FMANEKIN012_WEST ,
FTR_FMANEKIN013_SOUTH, FTR_FMANEKIN013_EAST, FTR_FMANEKIN013_NORTH, FTR_FMANEKIN013_WEST ,
FTR_FMANEKIN014_SOUTH, FTR_FMANEKIN014_EAST, FTR_FMANEKIN014_NORTH, FTR_FMANEKIN014_WEST ,
FTR_FMANEKIN015_SOUTH, FTR_FMANEKIN015_EAST, FTR_FMANEKIN015_NORTH, FTR_FMANEKIN015_WEST ,
FTR_FMANEKIN016_SOUTH, FTR_FMANEKIN016_EAST, FTR_FMANEKIN016_NORTH, FTR_FMANEKIN016_WEST ,
FTR_FMANEKIN017_SOUTH, FTR_FMANEKIN017_EAST, FTR_FMANEKIN017_NORTH, FTR_FMANEKIN017_WEST ,
FTR_FMANEKIN018_SOUTH, FTR_FMANEKIN018_EAST, FTR_FMANEKIN018_NORTH, FTR_FMANEKIN018_WEST ,
FTR_FMANEKIN019_SOUTH, FTR_FMANEKIN019_EAST, FTR_FMANEKIN019_NORTH, FTR_FMANEKIN019_WEST ,
FTR_FMANEKIN020_SOUTH, FTR_FMANEKIN020_EAST, FTR_FMANEKIN020_NORTH, FTR_FMANEKIN020_WEST ,
FTR_FMANEKIN021_SOUTH, FTR_FMANEKIN021_EAST, FTR_FMANEKIN021_NORTH, FTR_FMANEKIN021_WEST ,
FTR_FMANEKIN022_SOUTH, FTR_FMANEKIN022_EAST, FTR_FMANEKIN022_NORTH, FTR_FMANEKIN022_WEST ,
FTR_FMANEKIN023_SOUTH, FTR_FMANEKIN023_EAST, FTR_FMANEKIN023_NORTH, FTR_FMANEKIN023_WEST ,
FTR_FMANEKIN024_SOUTH, FTR_FMANEKIN024_EAST, FTR_FMANEKIN024_NORTH, FTR_FMANEKIN024_WEST ,
FTR_FMANEKIN025_SOUTH, FTR_FMANEKIN025_EAST, FTR_FMANEKIN025_NORTH, FTR_FMANEKIN025_WEST ,
FTR_FMANEKIN026_SOUTH, FTR_FMANEKIN026_EAST, FTR_FMANEKIN026_NORTH, FTR_FMANEKIN026_WEST ,
FTR_FMANEKIN027_SOUTH, FTR_FMANEKIN027_EAST, FTR_FMANEKIN027_NORTH, FTR_FMANEKIN027_WEST ,
FTR_FMANEKIN028_SOUTH, FTR_FMANEKIN028_EAST, FTR_FMANEKIN028_NORTH, FTR_FMANEKIN028_WEST ,
FTR_FMANEKIN029_SOUTH, FTR_FMANEKIN029_EAST, FTR_FMANEKIN029_NORTH, FTR_FMANEKIN029_WEST ,
FTR_FMANEKIN030_SOUTH, FTR_FMANEKIN030_EAST, FTR_FMANEKIN030_NORTH, FTR_FMANEKIN030_WEST ,
FTR_FMANEKIN031_SOUTH, FTR_FMANEKIN031_EAST, FTR_FMANEKIN031_NORTH, FTR_FMANEKIN031_WEST ,
FTR_FMANEKIN032_SOUTH, FTR_FMANEKIN032_EAST, FTR_FMANEKIN032_NORTH, FTR_FMANEKIN032_WEST ,
FTR_FMANEKIN033_SOUTH, FTR_FMANEKIN033_EAST, FTR_FMANEKIN033_NORTH, FTR_FMANEKIN033_WEST ,
FTR_FMANEKIN034_SOUTH, FTR_FMANEKIN034_EAST, FTR_FMANEKIN034_NORTH, FTR_FMANEKIN034_WEST ,
FTR_FMANEKIN035_SOUTH, FTR_FMANEKIN035_EAST, FTR_FMANEKIN035_NORTH, FTR_FMANEKIN035_WEST ,
FTR_FMANEKIN036_SOUTH, FTR_FMANEKIN036_EAST, FTR_FMANEKIN036_NORTH, FTR_FMANEKIN036_WEST ,
FTR_FMANEKIN037_SOUTH, FTR_FMANEKIN037_EAST, FTR_FMANEKIN037_NORTH, FTR_FMANEKIN037_WEST ,
FTR_FMANEKIN038_SOUTH, FTR_FMANEKIN038_EAST, FTR_FMANEKIN038_NORTH, FTR_FMANEKIN038_WEST ,
FTR_FMANEKIN039_SOUTH, FTR_FMANEKIN039_EAST, FTR_FMANEKIN039_NORTH, FTR_FMANEKIN039_WEST ,
FTR_FMANEKIN040_SOUTH, FTR_FMANEKIN040_EAST, FTR_FMANEKIN040_NORTH, FTR_FMANEKIN040_WEST ,
FTR_FMANEKIN041_SOUTH, FTR_FMANEKIN041_EAST, FTR_FMANEKIN041_NORTH, FTR_FMANEKIN041_WEST ,
FTR_FMANEKIN042_SOUTH, FTR_FMANEKIN042_EAST, FTR_FMANEKIN042_NORTH, FTR_FMANEKIN042_WEST ,
FTR_FMANEKIN043_SOUTH, FTR_FMANEKIN043_EAST, FTR_FMANEKIN043_NORTH, FTR_FMANEKIN043_WEST ,
FTR_FMANEKIN044_SOUTH, FTR_FMANEKIN044_EAST, FTR_FMANEKIN044_NORTH, FTR_FMANEKIN044_WEST ,
FTR_FMANEKIN045_SOUTH, FTR_FMANEKIN045_EAST, FTR_FMANEKIN045_NORTH, FTR_FMANEKIN045_WEST ,
FTR_FMANEKIN046_SOUTH, FTR_FMANEKIN046_EAST, FTR_FMANEKIN046_NORTH, FTR_FMANEKIN046_WEST ,
FTR_FMANEKIN047_SOUTH, FTR_FMANEKIN047_EAST, FTR_FMANEKIN047_NORTH, FTR_FMANEKIN047_WEST ,
FTR_FMANEKIN048_SOUTH, FTR_FMANEKIN048_EAST, FTR_FMANEKIN048_NORTH, FTR_FMANEKIN048_WEST ,
FTR_FMANEKIN049_SOUTH, FTR_FMANEKIN049_EAST, FTR_FMANEKIN049_NORTH, FTR_FMANEKIN049_WEST ,
FTR_FMANEKIN050_SOUTH, FTR_FMANEKIN050_EAST, FTR_FMANEKIN050_NORTH, FTR_FMANEKIN050_WEST ,
FTR_FMANEKIN051_SOUTH, FTR_FMANEKIN051_EAST, FTR_FMANEKIN051_NORTH, FTR_FMANEKIN051_WEST ,
FTR_FMANEKIN052_SOUTH, FTR_FMANEKIN052_EAST, FTR_FMANEKIN052_NORTH, FTR_FMANEKIN052_WEST ,
FTR_FMANEKIN053_SOUTH, FTR_FMANEKIN053_EAST, FTR_FMANEKIN053_NORTH, FTR_FMANEKIN053_WEST ,
FTR_FMANEKIN054_SOUTH, FTR_FMANEKIN054_EAST, FTR_FMANEKIN054_NORTH, FTR_FMANEKIN054_WEST ,
FTR_FMANEKIN055_SOUTH, FTR_FMANEKIN055_EAST, FTR_FMANEKIN055_NORTH, FTR_FMANEKIN055_WEST ,
FTR_FMANEKIN056_SOUTH, FTR_FMANEKIN056_EAST, FTR_FMANEKIN056_NORTH, FTR_FMANEKIN056_WEST ,
FTR_FMANEKIN057_SOUTH, FTR_FMANEKIN057_EAST, FTR_FMANEKIN057_NORTH, FTR_FMANEKIN057_WEST ,
FTR_FMANEKIN058_SOUTH, FTR_FMANEKIN058_EAST, FTR_FMANEKIN058_NORTH, FTR_FMANEKIN058_WEST ,
FTR_FMANEKIN059_SOUTH, FTR_FMANEKIN059_EAST, FTR_FMANEKIN059_NORTH, FTR_FMANEKIN059_WEST ,
FTR_FMANEKIN060_SOUTH, FTR_FMANEKIN060_EAST, FTR_FMANEKIN060_NORTH, FTR_FMANEKIN060_WEST ,
FTR_FMANEKIN061_SOUTH, FTR_FMANEKIN061_EAST, FTR_FMANEKIN061_NORTH, FTR_FMANEKIN061_WEST ,
FTR_FMANEKIN062_SOUTH, FTR_FMANEKIN062_EAST, FTR_FMANEKIN062_NORTH, FTR_FMANEKIN062_WEST ,
FTR_FMANEKIN063_SOUTH, FTR_FMANEKIN063_EAST, FTR_FMANEKIN063_NORTH, FTR_FMANEKIN063_WEST ,
FTR_FMANEKIN064_SOUTH, FTR_FMANEKIN064_EAST, FTR_FMANEKIN064_NORTH, FTR_FMANEKIN064_WEST ,
FTR_FMANEKIN065_SOUTH, FTR_FMANEKIN065_EAST, FTR_FMANEKIN065_NORTH, FTR_FMANEKIN065_WEST ,
FTR_FMANEKIN066_SOUTH, FTR_FMANEKIN066_EAST, FTR_FMANEKIN066_NORTH, FTR_FMANEKIN066_WEST ,
FTR_FMANEKIN067_SOUTH, FTR_FMANEKIN067_EAST, FTR_FMANEKIN067_NORTH, FTR_FMANEKIN067_WEST ,
FTR_FMANEKIN068_SOUTH, FTR_FMANEKIN068_EAST, FTR_FMANEKIN068_NORTH, FTR_FMANEKIN068_WEST ,
FTR_FMANEKIN069_SOUTH, FTR_FMANEKIN069_EAST, FTR_FMANEKIN069_NORTH, FTR_FMANEKIN069_WEST ,
FTR_FMANEKIN070_SOUTH, FTR_FMANEKIN070_EAST, FTR_FMANEKIN070_NORTH, FTR_FMANEKIN070_WEST ,
FTR_FMANEKIN071_SOUTH, FTR_FMANEKIN071_EAST, FTR_FMANEKIN071_NORTH, FTR_FMANEKIN071_WEST ,
FTR_FMANEKIN072_SOUTH, FTR_FMANEKIN072_EAST, FTR_FMANEKIN072_NORTH, FTR_FMANEKIN072_WEST ,
FTR_FMANEKIN073_SOUTH, FTR_FMANEKIN073_EAST, FTR_FMANEKIN073_NORTH, FTR_FMANEKIN073_WEST ,
FTR_FMANEKIN074_SOUTH, FTR_FMANEKIN074_EAST, FTR_FMANEKIN074_NORTH, FTR_FMANEKIN074_WEST ,
FTR_FMANEKIN075_SOUTH, FTR_FMANEKIN075_EAST, FTR_FMANEKIN075_NORTH, FTR_FMANEKIN075_WEST ,
FTR_FMANEKIN076_SOUTH, FTR_FMANEKIN076_EAST, FTR_FMANEKIN076_NORTH, FTR_FMANEKIN076_WEST ,
FTR_FMANEKIN077_SOUTH, FTR_FMANEKIN077_EAST, FTR_FMANEKIN077_NORTH, FTR_FMANEKIN077_WEST ,
FTR_FMANEKIN078_SOUTH, FTR_FMANEKIN078_EAST, FTR_FMANEKIN078_NORTH, FTR_FMANEKIN078_WEST ,
FTR_FMANEKIN079_SOUTH, FTR_FMANEKIN079_EAST, FTR_FMANEKIN079_NORTH, FTR_FMANEKIN079_WEST ,
FTR_FMANEKIN080_SOUTH, FTR_FMANEKIN080_EAST, FTR_FMANEKIN080_NORTH, FTR_FMANEKIN080_WEST ,
FTR_FMANEKIN081_SOUTH, FTR_FMANEKIN081_EAST, FTR_FMANEKIN081_NORTH, FTR_FMANEKIN081_WEST ,
FTR_FMANEKIN082_SOUTH, FTR_FMANEKIN082_EAST, FTR_FMANEKIN082_NORTH, FTR_FMANEKIN082_WEST ,
FTR_FMANEKIN083_SOUTH, FTR_FMANEKIN083_EAST, FTR_FMANEKIN083_NORTH, FTR_FMANEKIN083_WEST ,
FTR_FMANEKIN084_SOUTH, FTR_FMANEKIN084_EAST, FTR_FMANEKIN084_NORTH, FTR_FMANEKIN084_WEST ,
FTR_FMANEKIN085_SOUTH, FTR_FMANEKIN085_EAST, FTR_FMANEKIN085_NORTH, FTR_FMANEKIN085_WEST ,
FTR_FMANEKIN086_SOUTH, FTR_FMANEKIN086_EAST, FTR_FMANEKIN086_NORTH, FTR_FMANEKIN086_WEST ,
FTR_FMANEKIN087_SOUTH, FTR_FMANEKIN087_EAST, FTR_FMANEKIN087_NORTH, FTR_FMANEKIN087_WEST ,
FTR_FMANEKIN088_SOUTH, FTR_FMANEKIN088_EAST, FTR_FMANEKIN088_NORTH, FTR_FMANEKIN088_WEST ,
FTR_FMANEKIN089_SOUTH, FTR_FMANEKIN089_EAST, FTR_FMANEKIN089_NORTH, FTR_FMANEKIN089_WEST ,
FTR_FMANEKIN090_SOUTH, FTR_FMANEKIN090_EAST, FTR_FMANEKIN090_NORTH, FTR_FMANEKIN090_WEST ,
FTR_FMANEKIN091_SOUTH, FTR_FMANEKIN091_EAST, FTR_FMANEKIN091_NORTH, FTR_FMANEKIN091_WEST ,
FTR_FMANEKIN092_SOUTH, FTR_FMANEKIN092_EAST, FTR_FMANEKIN092_NORTH, FTR_FMANEKIN092_WEST ,
FTR_FMANEKIN093_SOUTH, FTR_FMANEKIN093_EAST, FTR_FMANEKIN093_NORTH, FTR_FMANEKIN093_WEST ,
FTR_FMANEKIN094_SOUTH, FTR_FMANEKIN094_EAST, FTR_FMANEKIN094_NORTH, FTR_FMANEKIN094_WEST ,
FTR_FMANEKIN095_SOUTH, FTR_FMANEKIN095_EAST, FTR_FMANEKIN095_NORTH, FTR_FMANEKIN095_WEST ,
FTR_FMANEKIN096_SOUTH, FTR_FMANEKIN096_EAST, FTR_FMANEKIN096_NORTH, FTR_FMANEKIN096_WEST ,
FTR_FMANEKIN097_SOUTH, FTR_FMANEKIN097_EAST, FTR_FMANEKIN097_NORTH, FTR_FMANEKIN097_WEST ,
FTR_FMANEKIN098_SOUTH, FTR_FMANEKIN098_EAST, FTR_FMANEKIN098_NORTH, FTR_FMANEKIN098_WEST ,
FTR_FMANEKIN099_SOUTH, FTR_FMANEKIN099_EAST, FTR_FMANEKIN099_NORTH, FTR_FMANEKIN099_WEST ,
FTR_FMANEKIN100_SOUTH, FTR_FMANEKIN100_EAST, FTR_FMANEKIN100_NORTH, FTR_FMANEKIN100_WEST ,
FTR_FMANEKIN101_SOUTH, FTR_FMANEKIN101_EAST, FTR_FMANEKIN101_NORTH, FTR_FMANEKIN101_WEST ,
FTR_FMANEKIN102_SOUTH, FTR_FMANEKIN102_EAST, FTR_FMANEKIN102_NORTH, FTR_FMANEKIN102_WEST ,
FTR_FMANEKIN103_SOUTH, FTR_FMANEKIN103_EAST, FTR_FMANEKIN103_NORTH, FTR_FMANEKIN103_WEST ,
FTR_FMANEKIN104_SOUTH, FTR_FMANEKIN104_EAST, FTR_FMANEKIN104_NORTH, FTR_FMANEKIN104_WEST ,
FTR_FMANEKIN105_SOUTH, FTR_FMANEKIN105_EAST, FTR_FMANEKIN105_NORTH, FTR_FMANEKIN105_WEST ,
FTR_FMANEKIN106_SOUTH, FTR_FMANEKIN106_EAST, FTR_FMANEKIN106_NORTH, FTR_FMANEKIN106_WEST ,
FTR_FMANEKIN107_SOUTH, FTR_FMANEKIN107_EAST, FTR_FMANEKIN107_NORTH, FTR_FMANEKIN107_WEST ,
FTR_FMANEKIN108_SOUTH, FTR_FMANEKIN108_EAST, FTR_FMANEKIN108_NORTH, FTR_FMANEKIN108_WEST ,
FTR_FMANEKIN109_SOUTH, FTR_FMANEKIN109_EAST, FTR_FMANEKIN109_NORTH, FTR_FMANEKIN109_WEST ,
FTR_FMANEKIN110_SOUTH, FTR_FMANEKIN110_EAST, FTR_FMANEKIN110_NORTH, FTR_FMANEKIN110_WEST ,
FTR_FMANEKIN111_SOUTH, FTR_FMANEKIN111_EAST, FTR_FMANEKIN111_NORTH, FTR_FMANEKIN111_WEST ,
FTR_FMANEKIN112_SOUTH, FTR_FMANEKIN112_EAST, FTR_FMANEKIN112_NORTH, FTR_FMANEKIN112_WEST ,
FTR_FMANEKIN113_SOUTH, FTR_FMANEKIN113_EAST, FTR_FMANEKIN113_NORTH, FTR_FMANEKIN113_WEST ,
FTR_FMANEKIN114_SOUTH, FTR_FMANEKIN114_EAST, FTR_FMANEKIN114_NORTH, FTR_FMANEKIN114_WEST ,
FTR_FMANEKIN115_SOUTH, FTR_FMANEKIN115_EAST, FTR_FMANEKIN115_NORTH, FTR_FMANEKIN115_WEST ,
FTR_FMANEKIN116_SOUTH, FTR_FMANEKIN116_EAST, FTR_FMANEKIN116_NORTH, FTR_FMANEKIN116_WEST ,
FTR_FMANEKIN117_SOUTH, FTR_FMANEKIN117_EAST, FTR_FMANEKIN117_NORTH, FTR_FMANEKIN117_WEST ,
FTR_FMANEKIN118_SOUTH, FTR_FMANEKIN118_EAST, FTR_FMANEKIN118_NORTH, FTR_FMANEKIN118_WEST ,
FTR_FMANEKIN119_SOUTH, FTR_FMANEKIN119_EAST, FTR_FMANEKIN119_NORTH, FTR_FMANEKIN119_WEST ,
FTR_FMANEKIN120_SOUTH, FTR_FMANEKIN120_EAST, FTR_FMANEKIN120_NORTH, FTR_FMANEKIN120_WEST ,
FTR_FMANEKIN121_SOUTH, FTR_FMANEKIN121_EAST, FTR_FMANEKIN121_NORTH, FTR_FMANEKIN121_WEST ,
FTR_FMANEKIN122_SOUTH, FTR_FMANEKIN122_EAST, FTR_FMANEKIN122_NORTH, FTR_FMANEKIN122_WEST ,
FTR_FMANEKIN123_SOUTH, FTR_FMANEKIN123_EAST, FTR_FMANEKIN123_NORTH, FTR_FMANEKIN123_WEST ,
FTR_FMANEKIN124_SOUTH, FTR_FMANEKIN124_EAST, FTR_FMANEKIN124_NORTH, FTR_FMANEKIN124_WEST ,
FTR_FMANEKIN125_SOUTH, FTR_FMANEKIN125_EAST, FTR_FMANEKIN125_NORTH, FTR_FMANEKIN125_WEST ,
FTR_FMANEKIN126_SOUTH, FTR_FMANEKIN126_EAST, FTR_FMANEKIN126_NORTH, FTR_FMANEKIN126_WEST ,
FTR_FMANEKIN127_SOUTH, FTR_FMANEKIN127_EAST, FTR_FMANEKIN127_NORTH, FTR_FMANEKIN127_WEST ,
FTR_FMANEKIN128_SOUTH, FTR_FMANEKIN128_EAST, FTR_FMANEKIN128_NORTH, FTR_FMANEKIN128_WEST ,
FTR_FMANEKIN129_SOUTH, FTR_FMANEKIN129_EAST, FTR_FMANEKIN129_NORTH, FTR_FMANEKIN129_WEST ,
FTR_FMANEKIN130_SOUTH, FTR_FMANEKIN130_EAST, FTR_FMANEKIN130_NORTH, FTR_FMANEKIN130_WEST ,
FTR_FMANEKIN131_SOUTH, FTR_FMANEKIN131_EAST, FTR_FMANEKIN131_NORTH, FTR_FMANEKIN131_WEST ,
FTR_FMANEKIN132_SOUTH, FTR_FMANEKIN132_EAST, FTR_FMANEKIN132_NORTH, FTR_FMANEKIN132_WEST ,
FTR_FMANEKIN133_SOUTH, FTR_FMANEKIN133_EAST, FTR_FMANEKIN133_NORTH, FTR_FMANEKIN133_WEST ,
FTR_FMANEKIN134_SOUTH, FTR_FMANEKIN134_EAST, FTR_FMANEKIN134_NORTH, FTR_FMANEKIN134_WEST ,
FTR_FMANEKIN135_SOUTH, FTR_FMANEKIN135_EAST, FTR_FMANEKIN135_NORTH, FTR_FMANEKIN135_WEST ,
FTR_FMANEKIN136_SOUTH, FTR_FMANEKIN136_EAST, FTR_FMANEKIN136_NORTH, FTR_FMANEKIN136_WEST ,
FTR_FMANEKIN137_SOUTH, FTR_FMANEKIN137_EAST, FTR_FMANEKIN137_NORTH, FTR_FMANEKIN137_WEST ,
FTR_FMANEKIN138_SOUTH, FTR_FMANEKIN138_EAST, FTR_FMANEKIN138_NORTH, FTR_FMANEKIN138_WEST ,
FTR_FMANEKIN139_SOUTH, FTR_FMANEKIN139_EAST, FTR_FMANEKIN139_NORTH, FTR_FMANEKIN139_WEST ,
FTR_FMANEKIN140_SOUTH, FTR_FMANEKIN140_EAST, FTR_FMANEKIN140_NORTH, FTR_FMANEKIN140_WEST ,
FTR_FMANEKIN141_SOUTH, FTR_FMANEKIN141_EAST, FTR_FMANEKIN141_NORTH, FTR_FMANEKIN141_WEST ,
FTR_FMANEKIN142_SOUTH, FTR_FMANEKIN142_EAST, FTR_FMANEKIN142_NORTH, FTR_FMANEKIN142_WEST ,
FTR_FMANEKIN143_SOUTH, FTR_FMANEKIN143_EAST, FTR_FMANEKIN143_NORTH, FTR_FMANEKIN143_WEST ,
FTR_FMANEKIN144_SOUTH, FTR_FMANEKIN144_EAST, FTR_FMANEKIN144_NORTH, FTR_FMANEKIN144_WEST ,
FTR_FMANEKIN145_SOUTH, FTR_FMANEKIN145_EAST, FTR_FMANEKIN145_NORTH, FTR_FMANEKIN145_WEST ,
FTR_FMANEKIN146_SOUTH, FTR_FMANEKIN146_EAST, FTR_FMANEKIN146_NORTH, FTR_FMANEKIN146_WEST ,
FTR_FMANEKIN147_SOUTH, FTR_FMANEKIN147_EAST, FTR_FMANEKIN147_NORTH, FTR_FMANEKIN147_WEST ,
FTR_FMANEKIN148_SOUTH, FTR_FMANEKIN148_EAST, FTR_FMANEKIN148_NORTH, FTR_FMANEKIN148_WEST ,
FTR_FMANEKIN149_SOUTH, FTR_FMANEKIN149_EAST, FTR_FMANEKIN149_NORTH, FTR_FMANEKIN149_WEST ,
FTR_FMANEKIN150_SOUTH, FTR_FMANEKIN150_EAST, FTR_FMANEKIN150_NORTH, FTR_FMANEKIN150_WEST ,
FTR_FMANEKIN151_SOUTH, FTR_FMANEKIN151_EAST, FTR_FMANEKIN151_NORTH, FTR_FMANEKIN151_WEST ,
FTR_FMANEKIN152_SOUTH, FTR_FMANEKIN152_EAST, FTR_FMANEKIN152_NORTH, FTR_FMANEKIN152_WEST ,
FTR_FMANEKIN153_SOUTH, FTR_FMANEKIN153_EAST, FTR_FMANEKIN153_NORTH, FTR_FMANEKIN153_WEST ,
FTR_FMANEKIN154_SOUTH, FTR_FMANEKIN154_EAST, FTR_FMANEKIN154_NORTH, FTR_FMANEKIN154_WEST ,
FTR_FMANEKIN155_SOUTH, FTR_FMANEKIN155_EAST, FTR_FMANEKIN155_NORTH, FTR_FMANEKIN155_WEST ,
FTR_FMANEKIN156_SOUTH, FTR_FMANEKIN156_EAST, FTR_FMANEKIN156_NORTH, FTR_FMANEKIN156_WEST ,
FTR_FMANEKIN157_SOUTH, FTR_FMANEKIN157_EAST, FTR_FMANEKIN157_NORTH, FTR_FMANEKIN157_WEST ,
FTR_FMANEKIN158_SOUTH, FTR_FMANEKIN158_EAST, FTR_FMANEKIN158_NORTH, FTR_FMANEKIN158_WEST ,
FTR_FMANEKIN159_SOUTH, FTR_FMANEKIN159_EAST, FTR_FMANEKIN159_NORTH, FTR_FMANEKIN159_WEST ,
FTR_FMANEKIN160_SOUTH, FTR_FMANEKIN160_EAST, FTR_FMANEKIN160_NORTH, FTR_FMANEKIN160_WEST ,
FTR_FMANEKIN161_SOUTH, FTR_FMANEKIN161_EAST, FTR_FMANEKIN161_NORTH, FTR_FMANEKIN161_WEST ,
FTR_FMANEKIN162_SOUTH, FTR_FMANEKIN162_EAST, FTR_FMANEKIN162_NORTH, FTR_FMANEKIN162_WEST ,
FTR_FMANEKIN163_SOUTH, FTR_FMANEKIN163_EAST, FTR_FMANEKIN163_NORTH, FTR_FMANEKIN163_WEST ,
FTR_FMANEKIN164_SOUTH, FTR_FMANEKIN164_EAST, FTR_FMANEKIN164_NORTH, FTR_FMANEKIN164_WEST ,
FTR_FMANEKIN165_SOUTH, FTR_FMANEKIN165_EAST, FTR_FMANEKIN165_NORTH, FTR_FMANEKIN165_WEST ,
FTR_FMANEKIN166_SOUTH, FTR_FMANEKIN166_EAST, FTR_FMANEKIN166_NORTH, FTR_FMANEKIN166_WEST ,
FTR_FMANEKIN167_SOUTH, FTR_FMANEKIN167_EAST, FTR_FMANEKIN167_NORTH, FTR_FMANEKIN167_WEST ,
FTR_FMANEKIN168_SOUTH, FTR_FMANEKIN168_EAST, FTR_FMANEKIN168_NORTH, FTR_FMANEKIN168_WEST ,
FTR_FMANEKIN169_SOUTH, FTR_FMANEKIN169_EAST, FTR_FMANEKIN169_NORTH, FTR_FMANEKIN169_WEST ,
FTR_FMANEKIN170_SOUTH, FTR_FMANEKIN170_EAST, FTR_FMANEKIN170_NORTH, FTR_FMANEKIN170_WEST ,
FTR_FMANEKIN171_SOUTH, FTR_FMANEKIN171_EAST, FTR_FMANEKIN171_NORTH, FTR_FMANEKIN171_WEST ,
FTR_FMANEKIN172_SOUTH, FTR_FMANEKIN172_EAST, FTR_FMANEKIN172_NORTH, FTR_FMANEKIN172_WEST ,
FTR_FMANEKIN173_SOUTH, FTR_FMANEKIN173_EAST, FTR_FMANEKIN173_NORTH, FTR_FMANEKIN173_WEST ,
FTR_FMANEKIN174_SOUTH, FTR_FMANEKIN174_EAST, FTR_FMANEKIN174_NORTH, FTR_FMANEKIN174_WEST ,
FTR_FMANEKIN175_SOUTH, FTR_FMANEKIN175_EAST, FTR_FMANEKIN175_NORTH, FTR_FMANEKIN175_WEST ,
FTR_FMANEKIN176_SOUTH, FTR_FMANEKIN176_EAST, FTR_FMANEKIN176_NORTH, FTR_FMANEKIN176_WEST ,
FTR_FMANEKIN177_SOUTH, FTR_FMANEKIN177_EAST, FTR_FMANEKIN177_NORTH, FTR_FMANEKIN177_WEST ,
FTR_FMANEKIN178_SOUTH, FTR_FMANEKIN178_EAST, FTR_FMANEKIN178_NORTH, FTR_FMANEKIN178_WEST ,
FTR_FMANEKIN179_SOUTH, FTR_FMANEKIN179_EAST, FTR_FMANEKIN179_NORTH, FTR_FMANEKIN179_WEST ,
FTR_FMANEKIN180_SOUTH, FTR_FMANEKIN180_EAST, FTR_FMANEKIN180_NORTH, FTR_FMANEKIN180_WEST ,
FTR_FMANEKIN181_SOUTH, FTR_FMANEKIN181_EAST, FTR_FMANEKIN181_NORTH, FTR_FMANEKIN181_WEST ,
FTR_FMANEKIN182_SOUTH, FTR_FMANEKIN182_EAST, FTR_FMANEKIN182_NORTH, FTR_FMANEKIN182_WEST ,
FTR_FMANEKIN183_SOUTH, FTR_FMANEKIN183_EAST, FTR_FMANEKIN183_NORTH, FTR_FMANEKIN183_WEST ,
FTR_FMANEKIN184_SOUTH, FTR_FMANEKIN184_EAST, FTR_FMANEKIN184_NORTH, FTR_FMANEKIN184_WEST ,
FTR_FMANEKIN185_SOUTH, FTR_FMANEKIN185_EAST, FTR_FMANEKIN185_NORTH, FTR_FMANEKIN185_WEST ,
FTR_FMANEKIN186_SOUTH, FTR_FMANEKIN186_EAST, FTR_FMANEKIN186_NORTH, FTR_FMANEKIN186_WEST ,
FTR_FMANEKIN187_SOUTH, FTR_FMANEKIN187_EAST, FTR_FMANEKIN187_NORTH, FTR_FMANEKIN187_WEST ,
FTR_FMANEKIN188_SOUTH, FTR_FMANEKIN188_EAST, FTR_FMANEKIN188_NORTH, FTR_FMANEKIN188_WEST ,
FTR_FMANEKIN189_SOUTH, FTR_FMANEKIN189_EAST, FTR_FMANEKIN189_NORTH, FTR_FMANEKIN189_WEST ,
FTR_FMANEKIN190_SOUTH, FTR_FMANEKIN190_EAST, FTR_FMANEKIN190_NORTH, FTR_FMANEKIN190_WEST ,
FTR_FMANEKIN191_SOUTH, FTR_FMANEKIN191_EAST, FTR_FMANEKIN191_NORTH, FTR_FMANEKIN191_WEST ,
FTR_FMANEKIN192_SOUTH, FTR_FMANEKIN192_EAST, FTR_FMANEKIN192_NORTH, FTR_FMANEKIN192_WEST ,
FTR_FMANEKIN193_SOUTH, FTR_FMANEKIN193_EAST, FTR_FMANEKIN193_NORTH, FTR_FMANEKIN193_WEST ,
FTR_FMANEKIN194_SOUTH, FTR_FMANEKIN194_EAST, FTR_FMANEKIN194_NORTH, FTR_FMANEKIN194_WEST ,
FTR_FMANEKIN195_SOUTH, FTR_FMANEKIN195_EAST, FTR_FMANEKIN195_NORTH, FTR_FMANEKIN195_WEST ,
FTR_FMANEKIN196_SOUTH, FTR_FMANEKIN196_EAST, FTR_FMANEKIN196_NORTH, FTR_FMANEKIN196_WEST ,
FTR_FMANEKIN197_SOUTH, FTR_FMANEKIN197_EAST, FTR_FMANEKIN197_NORTH, FTR_FMANEKIN197_WEST ,
FTR_FMANEKIN198_SOUTH, FTR_FMANEKIN198_EAST, FTR_FMANEKIN198_NORTH, FTR_FMANEKIN198_WEST ,
FTR_FMANEKIN199_SOUTH, FTR_FMANEKIN199_EAST, FTR_FMANEKIN199_NORTH, FTR_FMANEKIN199_WEST ,
FTR_FMANEKIN200_SOUTH, FTR_FMANEKIN200_EAST, FTR_FMANEKIN200_NORTH, FTR_FMANEKIN200_WEST ,
FTR_FMANEKIN201_SOUTH, FTR_FMANEKIN201_EAST, FTR_FMANEKIN201_NORTH, FTR_FMANEKIN201_WEST ,
FTR_FMANEKIN202_SOUTH, FTR_FMANEKIN202_EAST, FTR_FMANEKIN202_NORTH, FTR_FMANEKIN202_WEST ,
FTR_FMANEKIN203_SOUTH, FTR_FMANEKIN203_EAST, FTR_FMANEKIN203_NORTH, FTR_FMANEKIN203_WEST ,
FTR_FMANEKIN204_SOUTH, FTR_FMANEKIN204_EAST, FTR_FMANEKIN204_NORTH, FTR_FMANEKIN204_WEST ,
FTR_FMANEKIN205_SOUTH, FTR_FMANEKIN205_EAST, FTR_FMANEKIN205_NORTH, FTR_FMANEKIN205_WEST ,
FTR_FMANEKIN206_SOUTH, FTR_FMANEKIN206_EAST, FTR_FMANEKIN206_NORTH, FTR_FMANEKIN206_WEST ,
FTR_FMANEKIN207_SOUTH, FTR_FMANEKIN207_EAST, FTR_FMANEKIN207_NORTH, FTR_FMANEKIN207_WEST ,
FTR_FMANEKIN208_SOUTH, FTR_FMANEKIN208_EAST, FTR_FMANEKIN208_NORTH, FTR_FMANEKIN208_WEST ,
FTR_FMANEKIN209_SOUTH, FTR_FMANEKIN209_EAST, FTR_FMANEKIN209_NORTH, FTR_FMANEKIN209_WEST ,
FTR_FMANEKIN210_SOUTH, FTR_FMANEKIN210_EAST, FTR_FMANEKIN210_NORTH, FTR_FMANEKIN210_WEST ,
FTR_FMANEKIN211_SOUTH, FTR_FMANEKIN211_EAST, FTR_FMANEKIN211_NORTH, FTR_FMANEKIN211_WEST ,
FTR_FMANEKIN212_SOUTH, FTR_FMANEKIN212_EAST, FTR_FMANEKIN212_NORTH, FTR_FMANEKIN212_WEST ,
FTR_FMANEKIN213_SOUTH, FTR_FMANEKIN213_EAST, FTR_FMANEKIN213_NORTH, FTR_FMANEKIN213_WEST ,
FTR_FMANEKIN214_SOUTH, FTR_FMANEKIN214_EAST, FTR_FMANEKIN214_NORTH, FTR_FMANEKIN214_WEST ,
FTR_FMANEKIN215_SOUTH, FTR_FMANEKIN215_EAST, FTR_FMANEKIN215_NORTH, FTR_FMANEKIN215_WEST ,
FTR_FMANEKIN216_SOUTH, FTR_FMANEKIN216_EAST, FTR_FMANEKIN216_NORTH, FTR_FMANEKIN216_WEST ,
FTR_FMANEKIN217_SOUTH, FTR_FMANEKIN217_EAST, FTR_FMANEKIN217_NORTH, FTR_FMANEKIN217_WEST ,
FTR_FMANEKIN218_SOUTH, FTR_FMANEKIN218_EAST, FTR_FMANEKIN218_NORTH, FTR_FMANEKIN218_WEST ,
FTR_FMANEKIN219_SOUTH, FTR_FMANEKIN219_EAST, FTR_FMANEKIN219_NORTH, FTR_FMANEKIN219_WEST ,
FTR_FMANEKIN220_SOUTH, FTR_FMANEKIN220_EAST, FTR_FMANEKIN220_NORTH, FTR_FMANEKIN220_WEST ,
FTR_FMANEKIN221_SOUTH, FTR_FMANEKIN221_EAST, FTR_FMANEKIN221_NORTH, FTR_FMANEKIN221_WEST ,
FTR_FMANEKIN222_SOUTH, FTR_FMANEKIN222_EAST, FTR_FMANEKIN222_NORTH, FTR_FMANEKIN222_WEST ,
FTR_FMANEKIN223_SOUTH, FTR_FMANEKIN223_EAST, FTR_FMANEKIN223_NORTH, FTR_FMANEKIN223_WEST ,
FTR_FMANEKIN224_SOUTH, FTR_FMANEKIN224_EAST, FTR_FMANEKIN224_NORTH, FTR_FMANEKIN224_WEST ,
FTR_FMANEKIN225_SOUTH, FTR_FMANEKIN225_EAST, FTR_FMANEKIN225_NORTH, FTR_FMANEKIN225_WEST ,
FTR_FMANEKIN226_SOUTH, FTR_FMANEKIN226_EAST, FTR_FMANEKIN226_NORTH, FTR_FMANEKIN226_WEST ,
FTR_FMANEKIN227_SOUTH, FTR_FMANEKIN227_EAST, FTR_FMANEKIN227_NORTH, FTR_FMANEKIN227_WEST ,
FTR_FMANEKIN228_SOUTH, FTR_FMANEKIN228_EAST, FTR_FMANEKIN228_NORTH, FTR_FMANEKIN228_WEST ,
FTR_FMANEKIN229_SOUTH, FTR_FMANEKIN229_EAST, FTR_FMANEKIN229_NORTH, FTR_FMANEKIN229_WEST ,
FTR_FMANEKIN230_SOUTH, FTR_FMANEKIN230_EAST, FTR_FMANEKIN230_NORTH, FTR_FMANEKIN230_WEST ,
FTR_FMANEKIN231_SOUTH, FTR_FMANEKIN231_EAST, FTR_FMANEKIN231_NORTH, FTR_FMANEKIN231_WEST ,
FTR_FMANEKIN232_SOUTH, FTR_FMANEKIN232_EAST, FTR_FMANEKIN232_NORTH, FTR_FMANEKIN232_WEST ,
FTR_FMANEKIN233_SOUTH, FTR_FMANEKIN233_EAST, FTR_FMANEKIN233_NORTH, FTR_FMANEKIN233_WEST ,
FTR_FMANEKIN234_SOUTH, FTR_FMANEKIN234_EAST, FTR_FMANEKIN234_NORTH, FTR_FMANEKIN234_WEST ,
FTR_FMANEKIN235_SOUTH, FTR_FMANEKIN235_EAST, FTR_FMANEKIN235_NORTH, FTR_FMANEKIN235_WEST ,
FTR_FMANEKIN236_SOUTH, FTR_FMANEKIN236_EAST, FTR_FMANEKIN236_NORTH, FTR_FMANEKIN236_WEST ,
FTR_FMANEKIN237_SOUTH, FTR_FMANEKIN237_EAST, FTR_FMANEKIN237_NORTH, FTR_FMANEKIN237_WEST ,
FTR_FMANEKIN238_SOUTH, FTR_FMANEKIN238_EAST, FTR_FMANEKIN238_NORTH, FTR_FMANEKIN238_WEST ,
FTR_FMANEKIN239_SOUTH, FTR_FMANEKIN239_EAST, FTR_FMANEKIN239_NORTH, FTR_FMANEKIN239_WEST ,
FTR_FMANEKIN240_SOUTH, FTR_FMANEKIN240_EAST, FTR_FMANEKIN240_NORTH, FTR_FMANEKIN240_WEST ,
FTR_FMANEKIN241_SOUTH, FTR_FMANEKIN241_EAST, FTR_FMANEKIN241_NORTH, FTR_FMANEKIN241_WEST ,
FTR_FMANEKIN242_SOUTH, FTR_FMANEKIN242_EAST, FTR_FMANEKIN242_NORTH, FTR_FMANEKIN242_WEST ,
FTR_FMANEKIN243_SOUTH, FTR_FMANEKIN243_EAST, FTR_FMANEKIN243_NORTH, FTR_FMANEKIN243_WEST ,
FTR_FMANEKIN244_SOUTH, FTR_FMANEKIN244_EAST, FTR_FMANEKIN244_NORTH, FTR_FMANEKIN244_WEST ,
FTR_FMANEKIN245_SOUTH, FTR_FMANEKIN245_EAST, FTR_FMANEKIN245_NORTH, FTR_FMANEKIN245_WEST ,
FTR_FMANEKIN246_SOUTH, FTR_FMANEKIN246_EAST, FTR_FMANEKIN246_NORTH, FTR_FMANEKIN246_WEST ,
FTR_FMANEKIN247_SOUTH, FTR_FMANEKIN247_EAST, FTR_FMANEKIN247_NORTH, FTR_FMANEKIN247_WEST ,
FTR_FMANEKIN248_SOUTH, FTR_FMANEKIN248_EAST, FTR_FMANEKIN248_NORTH, FTR_FMANEKIN248_WEST ,
FTR_FMANEKIN249_SOUTH, FTR_FMANEKIN249_EAST, FTR_FMANEKIN249_NORTH, FTR_FMANEKIN249_WEST ,
FTR_FMANEKIN250_SOUTH, FTR_FMANEKIN250_EAST, FTR_FMANEKIN250_NORTH, FTR_FMANEKIN250_WEST ,
FTR_FMANEKIN251_SOUTH, FTR_FMANEKIN251_EAST, FTR_FMANEKIN251_NORTH, FTR_FMANEKIN251_WEST ,
FTR_FMANEKIN252_SOUTH, FTR_FMANEKIN252_EAST, FTR_FMANEKIN252_NORTH, FTR_FMANEKIN252_WEST ,
FTR_FMANEKIN253_SOUTH, FTR_FMANEKIN253_EAST, FTR_FMANEKIN253_NORTH, FTR_FMANEKIN253_WEST ,
FTR_FMANEKIN254_SOUTH, FTR_FMANEKIN254_EAST, FTR_FMANEKIN254_NORTH, FTR_FMANEKIN254_WEST ,
FTR_MYFMANEKIN0_SOUTH, FTR_MYFMANEKIN0_EAST, FTR_MYFMANEKIN0_NORTH, FTR_MYFMANEKIN0_WEST ,
FTR_MYFMANEKIN1_SOUTH, FTR_MYFMANEKIN1_EAST, FTR_MYFMANEKIN1_NORTH, FTR_MYFMANEKIN1_WEST ,
FTR_MYFMANEKIN2_SOUTH, FTR_MYFMANEKIN2_EAST, FTR_MYFMANEKIN2_NORTH, FTR_MYFMANEKIN2_WEST ,
FTR_MYFMANEKIN3_SOUTH, FTR_MYFMANEKIN3_EAST, FTR_MYFMANEKIN3_NORTH, FTR_MYFMANEKIN3_WEST ,
FTR_MYFMANEKIN4_SOUTH, FTR_MYFMANEKIN4_EAST, FTR_MYFMANEKIN4_NORTH, FTR_MYFMANEKIN4_WEST ,
FTR_MYFMANEKIN5_SOUTH, FTR_MYFMANEKIN5_EAST, FTR_MYFMANEKIN5_NORTH, FTR_MYFMANEKIN5_WEST ,
FTR_MYFMANEKIN6_SOUTH, FTR_MYFMANEKIN6_EAST, FTR_MYFMANEKIN6_NORTH, FTR_MYFMANEKIN6_WEST ,
FTR_MYFMANEKIN7_SOUTH, FTR_MYFMANEKIN7_EAST, FTR_MYFMANEKIN7_NORTH, FTR_MYFMANEKIN7_WEST ,
FTR_SUM_MONSHIRO_SOUTH, FTR_SUM_MONSHIRO_EAST, FTR_SUM_MONSHIRO_NORTH, FTR_SUM_MONSHIRO_WEST ,
FTR_SUM_MONKI_SOUTH, FTR_SUM_MONKI_EAST, FTR_SUM_MONKI_NORTH, FTR_SUM_MONKI_WEST ,
FTR_SUM_KIAGEHA_SOUTH, FTR_SUM_KIAGEHA_EAST, FTR_SUM_KIAGEHA_NORTH, FTR_SUM_KIAGEHA_WEST ,
FTR_SUM_OHMURASAKI_SOUTH, FTR_SUM_OHMURASAKI_EAST, FTR_SUM_OHMURASAKI_NORTH, FTR_SUM_OHMURASAKI_WEST ,
FTR_SUM_MINMIN_SOUTH, FTR_SUM_MINMIN_EAST, FTR_SUM_MINMIN_NORTH, FTR_SUM_MINMIN_WEST ,
FTR_SUM_TUKUTUKU_SOUTH, FTR_SUM_TUKUTUKU_EAST, FTR_SUM_TUKUTUKU_NORTH, FTR_SUM_TUKUTUKU_WEST ,
FTR_SUM_HIGURASHI_SOUTH, FTR_SUM_HIGURASHI_EAST, FTR_SUM_HIGURASHI_NORTH, FTR_SUM_HIGURASHI_WEST ,
FTR_SUM_ABURA_SOUTH, FTR_SUM_ABURA_EAST, FTR_SUM_ABURA_NORTH, FTR_SUM_ABURA_WEST ,
FTR_SUM_HACHI_SOUTH, FTR_SUM_HACHI_EAST, FTR_SUM_HACHI_NORTH, FTR_SUM_HACHI_WEST ,
FTR_SUM_SHIOKARA_SOUTH, FTR_SUM_SHIOKARA_EAST, FTR_SUM_SHIOKARA_NORTH, FTR_SUM_SHIOKARA_WEST ,
FTR_SUM_AKIAKANE_SOUTH, FTR_SUM_AKIAKANE_EAST, FTR_SUM_AKIAKANE_NORTH, FTR_SUM_AKIAKANE_WEST ,
FTR_SUM_GINYANMA_SOUTH, FTR_SUM_GINYANMA_EAST, FTR_SUM_GINYANMA_NORTH, FTR_SUM_GINYANMA_WEST ,
FTR_SUM_ONIYANMA_SOUTH, FTR_SUM_ONIYANMA_EAST, FTR_SUM_ONIYANMA_NORTH, FTR_SUM_ONIYANMA_WEST ,
FTR_SUM_SYOURYOU_SOUTH, FTR_SUM_SYOURYOU_EAST, FTR_SUM_SYOURYOU_NORTH, FTR_SUM_SYOURYOU_WEST ,
FTR_SUM_TONOSAMA_SOUTH, FTR_SUM_TONOSAMA_EAST, FTR_SUM_TONOSAMA_NORTH, FTR_SUM_TONOSAMA_WEST ,
FTR_SUM_KOOROGI_SOUTH, FTR_SUM_KOOROGI_EAST, FTR_SUM_KOOROGI_NORTH, FTR_SUM_KOOROGI_WEST ,
FTR_SUM_KIRIGIRISU_SOUTH, FTR_SUM_KIRIGIRISU_EAST, FTR_SUM_KIRIGIRISU_NORTH, FTR_SUM_KIRIGIRISU_WEST ,
FTR_SUM_SUZUMUSHI_SOUTH, FTR_SUM_SUZUMUSHI_EAST, FTR_SUM_SUZUMUSHI_NORTH, FTR_SUM_SUZUMUSHI_WEST ,
FTR_SUM_MATUMUSHI_SOUTH, FTR_SUM_MATUMUSHI_EAST, FTR_SUM_MATUMUSHI_NORTH, FTR_SUM_MATUMUSHI_WEST ,
FTR_SUM_KANABUN_SOUTH, FTR_SUM_KANABUN_EAST, FTR_SUM_KANABUN_NORTH, FTR_SUM_KANABUN_WEST ,
FTR_SUM_KABUTO_SOUTH, FTR_SUM_KABUTO_EAST, FTR_SUM_KABUTO_NORTH, FTR_SUM_KABUTO_WEST ,
FTR_SUM_HIRATA_SOUTH, FTR_SUM_HIRATA_EAST, FTR_SUM_HIRATA_NORTH, FTR_SUM_HIRATA_WEST ,
FTR_SUM_TAMAMUSHI_SOUTH, FTR_SUM_TAMAMUSHI_EAST, FTR_SUM_TAMAMUSHI_NORTH, FTR_SUM_TAMAMUSHI_WEST ,
FTR_SUM_GOMADARA_SOUTH, FTR_SUM_GOMADARA_EAST, FTR_SUM_GOMADARA_NORTH, FTR_SUM_GOMADARA_WEST ,
FTR_SUM_TENTOU_SOUTH, FTR_SUM_TENTOU_EAST, FTR_SUM_TENTOU_NORTH, FTR_SUM_TENTOU_WEST ,
FTR_SUM_NANAHOSHI_SOUTH, FTR_SUM_NANAHOSHI_EAST, FTR_SUM_NANAHOSHI_NORTH, FTR_SUM_NANAHOSHI_WEST ,
FTR_SUM_KAMAKIRI_SOUTH, FTR_SUM_KAMAKIRI_EAST, FTR_SUM_KAMAKIRI_NORTH, FTR_SUM_KAMAKIRI_WEST ,
FTR_SUM_GENJI_SOUTH, FTR_SUM_GENJI_EAST, FTR_SUM_GENJI_NORTH, FTR_SUM_GENJI_WEST ,
FTR_SUM_DANNA_SOUTH, FTR_SUM_DANNA_EAST, FTR_SUM_DANNA_NORTH, FTR_SUM_DANNA_WEST ,
FTR_SUM_NOKOGIRI_SOUTH, FTR_SUM_NOKOGIRI_EAST, FTR_SUM_NOKOGIRI_NORTH, FTR_SUM_NOKOGIRI_WEST ,
FTR_SUM_MIYAMA_SOUTH, FTR_SUM_MIYAMA_EAST, FTR_SUM_MIYAMA_NORTH, FTR_SUM_MIYAMA_WEST ,
FTR_SUM_OKUWA_SOUTH, FTR_SUM_OKUWA_EAST, FTR_SUM_OKUWA_NORTH, FTR_SUM_OKUWA_WEST ,
FTR_NOG_MAIMAI_SOUTH, FTR_NOG_MAIMAI_EAST, FTR_NOG_MAIMAI_NORTH, FTR_NOG_MAIMAI_WEST ,
FTR_NOG_KERA_SOUTH, FTR_NOG_KERA_EAST, FTR_NOG_KERA_NORTH, FTR_NOG_KERA_WEST ,
FTR_NOG_AMENBO_SOUTH, FTR_NOG_AMENBO_EAST, FTR_NOG_AMENBO_NORTH, FTR_NOG_AMENBO_WEST ,
FTR_NOG_MINO_SOUTH, FTR_NOG_MINO_EAST, FTR_NOG_MINO_NORTH, FTR_NOG_MINO_WEST ,
FTR_NOG_DANGO_SOUTH, FTR_NOG_DANGO_EAST, FTR_NOG_DANGO_NORTH, FTR_NOG_DANGO_WEST ,
FTR_NOG_KUMO_SOUTH, FTR_NOG_KUMO_EAST, FTR_NOG_KUMO_NORTH, FTR_NOG_KUMO_WEST ,
FTR_NOG_ARI_SOUTH, FTR_NOG_ARI_EAST, FTR_NOG_ARI_NORTH, FTR_NOG_ARI_WEST ,
FTR_NOG_KA_SOUTH, FTR_NOG_KA_EAST, FTR_NOG_KA_NORTH, FTR_NOG_KA_WEST ,
FTR_SUM_FUNA_SOUTH, FTR_SUM_FUNA_EAST, FTR_SUM_FUNA_NORTH, FTR_SUM_FUNA_WEST ,
FTR_SUM_HERA_SOUTH, FTR_SUM_HERA_EAST, FTR_SUM_HERA_NORTH, FTR_SUM_HERA_WEST ,
FTR_SUM_KOI_SOUTH, FTR_SUM_KOI_EAST, FTR_SUM_KOI_NORTH, FTR_SUM_KOI_WEST ,
FTR_SUM_NISIKI_SOUTH, FTR_SUM_NISIKI_EAST, FTR_SUM_NISIKI_NORTH, FTR_SUM_NISIKI_WEST ,
FTR_SUM_NAMAZU_SOUTH, FTR_SUM_NAMAZU_EAST, FTR_SUM_NAMAZU_NORTH, FTR_SUM_NAMAZU_WEST ,
FTR_SUM_BASS_SOUTH, FTR_SUM_BASS_EAST, FTR_SUM_BASS_NORTH, FTR_SUM_BASS_WEST ,
FTR_SUM_BASSM_SOUTH, FTR_SUM_BASSM_EAST, FTR_SUM_BASSM_NORTH, FTR_SUM_BASSM_WEST ,
FTR_SUM_BASSL_SOUTH, FTR_SUM_BASSL_EAST, FTR_SUM_BASSL_NORTH, FTR_SUM_BASSL_WEST ,
FTR_SUM_GILL_SOUTH, FTR_SUM_GILL_EAST, FTR_SUM_GILL_NORTH, FTR_SUM_GILL_WEST ,
FTR_SUM_OONAMAZU_SOUTH, FTR_SUM_OONAMAZU_EAST, FTR_SUM_OONAMAZU_NORTH, FTR_SUM_OONAMAZU_WEST ,
FTR_SUM_RAIGYO_SOUTH, FTR_SUM_RAIGYO_EAST, FTR_SUM_RAIGYO_NORTH, FTR_SUM_RAIGYO_WEST ,
FTR_SUM_NIGOI_SOUTH, FTR_SUM_NIGOI_EAST, FTR_SUM_NIGOI_NORTH, FTR_SUM_NIGOI_WEST ,
FTR_SUM_UGUI_SOUTH, FTR_SUM_UGUI_EAST, FTR_SUM_UGUI_NORTH, FTR_SUM_UGUI_WEST ,
FTR_SUM_OIKAWA_SOUTH, FTR_SUM_OIKAWA_EAST, FTR_SUM_OIKAWA_NORTH, FTR_SUM_OIKAWA_WEST ,
FTR_SUM_TANAGO_SOUTH, FTR_SUM_TANAGO_EAST, FTR_SUM_TANAGO_NORTH, FTR_SUM_TANAGO_WEST ,
FTR_SUM_DOJYO_SOUTH, FTR_SUM_DOJYO_EAST, FTR_SUM_DOJYO_NORTH, FTR_SUM_DOJYO_WEST ,
FTR_SUM_WAKASAGI_SOUTH, FTR_SUM_WAKASAGI_EAST, FTR_SUM_WAKASAGI_NORTH, FTR_SUM_WAKASAGI_WEST ,
FTR_SUM_AYU_SOUTH, FTR_SUM_AYU_EAST, FTR_SUM_AYU_NORTH, FTR_SUM_AYU_WEST ,
FTR_SUM_YAMAME_SOUTH, FTR_SUM_YAMAME_EAST, FTR_SUM_YAMAME_NORTH, FTR_SUM_YAMAME_WEST ,
FTR_SUM_IWANA_SOUTH, FTR_SUM_IWANA_EAST, FTR_SUM_IWANA_NORTH, FTR_SUM_IWANA_WEST ,
FTR_SUM_NIJI_SOUTH, FTR_SUM_NIJI_EAST, FTR_SUM_NIJI_NORTH, FTR_SUM_NIJI_WEST ,
FTR_SUM_ITO_SOUTH, FTR_SUM_ITO_EAST, FTR_SUM_ITO_NORTH, FTR_SUM_ITO_WEST ,
FTR_SUM_SAKE_SOUTH, FTR_SUM_SAKE_EAST, FTR_SUM_SAKE_NORTH, FTR_SUM_SAKE_WEST ,
FTR_SUM_KINGYO_SOUTH, FTR_SUM_KINGYO_EAST, FTR_SUM_KINGYO_NORTH, FTR_SUM_KINGYO_WEST ,
FTR_SUM_PIRANIA_SOUTH, FTR_SUM_PIRANIA_EAST, FTR_SUM_PIRANIA_NORTH, FTR_SUM_PIRANIA_WEST ,
FTR_SUM_AROANA_SOUTH, FTR_SUM_AROANA_EAST, FTR_SUM_AROANA_NORTH, FTR_SUM_AROANA_WEST ,
FTR_SUM_UNAGI_SOUTH, FTR_SUM_UNAGI_EAST, FTR_SUM_UNAGI_NORTH, FTR_SUM_UNAGI_WEST ,
FTR_SUM_DONKO_SOUTH, FTR_SUM_DONKO_EAST, FTR_SUM_DONKO_NORTH, FTR_SUM_DONKO_WEST ,
FTR_SUM_ANGEL_SOUTH, FTR_SUM_ANGEL_EAST, FTR_SUM_ANGEL_NORTH, FTR_SUM_ANGEL_WEST ,
FTR_SUM_GUPI_SOUTH, FTR_SUM_GUPI_EAST, FTR_SUM_GUPI_NORTH, FTR_SUM_GUPI_WEST ,
FTR_SUM_DEMEKIN_SOUTH, FTR_SUM_DEMEKIN_EAST, FTR_SUM_DEMEKIN_NORTH, FTR_SUM_DEMEKIN_WEST ,
FTR_SUM_KASEKI_SOUTH, FTR_SUM_KASEKI_EAST, FTR_SUM_KASEKI_NORTH, FTR_SUM_KASEKI_WEST ,
FTR_NOG_ZARIGANI_SOUTH, FTR_NOG_ZARIGANI_EAST, FTR_NOG_ZARIGANI_NORTH, FTR_NOG_ZARIGANI_WEST ,
FTR_NOG_KAERU_SOUTH, FTR_NOG_KAERU_EAST, FTR_NOG_KAERU_NORTH, FTR_NOG_KAERU_WEST ,
FTR_NOG_MEDAKA_SOUTH, FTR_NOG_MEDAKA_EAST, FTR_NOG_MEDAKA_NORTH, FTR_NOG_MEDAKA_WEST ,
FTR_NOG_KURAGE_SOUTH, FTR_NOG_KURAGE_EAST, FTR_NOG_KURAGE_NORTH, FTR_NOG_KURAGE_WEST ,
FTR_NOG_SUZUKI_SOUTH, FTR_NOG_SUZUKI_EAST, FTR_NOG_SUZUKI_NORTH, FTR_NOG_SUZUKI_WEST ,
FTR_NOG_TAI_SOUTH, FTR_NOG_TAI_EAST, FTR_NOG_TAI_NORTH, FTR_NOG_TAI_WEST ,
FTR_NOG_ISIDAI_SOUTH, FTR_NOG_ISIDAI_EAST, FTR_NOG_ISIDAI_NORTH, FTR_NOG_ISIDAI_WEST ,
FTR_NOG_PIRALUKU_SOUTH, FTR_NOG_PIRALUKU_EAST, FTR_NOG_PIRALUKU_NORTH, FTR_NOG_PIRALUKU_WEST ,
FTR_FUMBRELLA00_SOUTH, FTR_FUMBRELLA00_EAST, FTR_FUMBRELLA00_NORTH, FTR_FUMBRELLA00_WEST ,
FTR_FUMBRELLA01_SOUTH, FTR_FUMBRELLA01_EAST, FTR_FUMBRELLA01_NORTH, FTR_FUMBRELLA01_WEST ,
FTR_FUMBRELLA02_SOUTH, FTR_FUMBRELLA02_EAST, FTR_FUMBRELLA02_NORTH, FTR_FUMBRELLA02_WEST ,
FTR_FUMBRELLA03_SOUTH, FTR_FUMBRELLA03_EAST, FTR_FUMBRELLA03_NORTH, FTR_FUMBRELLA03_WEST ,
FTR_FUMBRELLA04_SOUTH, FTR_FUMBRELLA04_EAST, FTR_FUMBRELLA04_NORTH, FTR_FUMBRELLA04_WEST ,
FTR_FUMBRELLA05_SOUTH, FTR_FUMBRELLA05_EAST, FTR_FUMBRELLA05_NORTH, FTR_FUMBRELLA05_WEST ,
FTR_FUMBRELLA06_SOUTH, FTR_FUMBRELLA06_EAST, FTR_FUMBRELLA06_NORTH, FTR_FUMBRELLA06_WEST ,
FTR_FUMBRELLA07_SOUTH, FTR_FUMBRELLA07_EAST, FTR_FUMBRELLA07_NORTH, FTR_FUMBRELLA07_WEST ,
FTR_FUMBRELLA08_SOUTH, FTR_FUMBRELLA08_EAST, FTR_FUMBRELLA08_NORTH, FTR_FUMBRELLA08_WEST ,
FTR_FUMBRELLA09_SOUTH, FTR_FUMBRELLA09_EAST, FTR_FUMBRELLA09_NORTH, FTR_FUMBRELLA09_WEST ,
FTR_FUMBRELLA10_SOUTH, FTR_FUMBRELLA10_EAST, FTR_FUMBRELLA10_NORTH, FTR_FUMBRELLA10_WEST ,
FTR_FUMBRELLA11_SOUTH, FTR_FUMBRELLA11_EAST, FTR_FUMBRELLA11_NORTH, FTR_FUMBRELLA11_WEST ,
FTR_FUMBRELLA12_SOUTH, FTR_FUMBRELLA12_EAST, FTR_FUMBRELLA12_NORTH, FTR_FUMBRELLA12_WEST ,
FTR_FUMBRELLA13_SOUTH, FTR_FUMBRELLA13_EAST, FTR_FUMBRELLA13_NORTH, FTR_FUMBRELLA13_WEST ,
FTR_FUMBRELLA14_SOUTH, FTR_FUMBRELLA14_EAST, FTR_FUMBRELLA14_NORTH, FTR_FUMBRELLA14_WEST ,
FTR_FUMBRELLA15_SOUTH, FTR_FUMBRELLA15_EAST, FTR_FUMBRELLA15_NORTH, FTR_FUMBRELLA15_WEST ,
FTR_FUMBRELLA16_SOUTH, FTR_FUMBRELLA16_EAST, FTR_FUMBRELLA16_NORTH, FTR_FUMBRELLA16_WEST ,
FTR_FUMBRELLA17_SOUTH, FTR_FUMBRELLA17_EAST, FTR_FUMBRELLA17_NORTH, FTR_FUMBRELLA17_WEST ,
FTR_FUMBRELLA18_SOUTH, FTR_FUMBRELLA18_EAST, FTR_FUMBRELLA18_NORTH, FTR_FUMBRELLA18_WEST ,
FTR_FUMBRELLA19_SOUTH, FTR_FUMBRELLA19_EAST, FTR_FUMBRELLA19_NORTH, FTR_FUMBRELLA19_WEST ,
FTR_FUMBRELLA20_SOUTH, FTR_FUMBRELLA20_EAST, FTR_FUMBRELLA20_NORTH, FTR_FUMBRELLA20_WEST ,
FTR_FUMBRELLA21_SOUTH, FTR_FUMBRELLA21_EAST, FTR_FUMBRELLA21_NORTH, FTR_FUMBRELLA21_WEST ,
FTR_FUMBRELLA22_SOUTH, FTR_FUMBRELLA22_EAST, FTR_FUMBRELLA22_NORTH, FTR_FUMBRELLA22_WEST ,
FTR_FUMBRELLA23_SOUTH, FTR_FUMBRELLA23_EAST, FTR_FUMBRELLA23_NORTH, FTR_FUMBRELLA23_WEST ,
FTR_FUMBRELLA24_SOUTH, FTR_FUMBRELLA24_EAST, FTR_FUMBRELLA24_NORTH, FTR_FUMBRELLA24_WEST ,
FTR_FUMBRELLA25_SOUTH, FTR_FUMBRELLA25_EAST, FTR_FUMBRELLA25_NORTH, FTR_FUMBRELLA25_WEST ,
FTR_FUMBRELLA26_SOUTH, FTR_FUMBRELLA26_EAST, FTR_FUMBRELLA26_NORTH, FTR_FUMBRELLA26_WEST ,
FTR_FUMBRELLA27_SOUTH, FTR_FUMBRELLA27_EAST, FTR_FUMBRELLA27_NORTH, FTR_FUMBRELLA27_WEST ,
FTR_FUMBRELLA28_SOUTH, FTR_FUMBRELLA28_EAST, FTR_FUMBRELLA28_NORTH, FTR_FUMBRELLA28_WEST ,
FTR_FUMBRELLA29_SOUTH, FTR_FUMBRELLA29_EAST, FTR_FUMBRELLA29_NORTH, FTR_FUMBRELLA29_WEST ,
FTR_FUMBRELLA30_SOUTH, FTR_FUMBRELLA30_EAST, FTR_FUMBRELLA30_NORTH, FTR_FUMBRELLA30_WEST ,
FTR_FUMBRELLA31_SOUTH, FTR_FUMBRELLA31_EAST, FTR_FUMBRELLA31_NORTH, FTR_FUMBRELLA31_WEST ,
FTR_MYFUMBRELLA0_SOUTH, FTR_MYFUMBRELLA0_EAST, FTR_MYFUMBRELLA0_NORTH, FTR_MYFUMBRELLA0_WEST ,
FTR_MYFUMBRELLA1_SOUTH, FTR_MYFUMBRELLA1_EAST, FTR_MYFUMBRELLA1_NORTH, FTR_MYFUMBRELLA1_WEST ,
FTR_MYFUMBRELLA2_SOUTH, FTR_MYFUMBRELLA2_EAST, FTR_MYFUMBRELLA2_NORTH, FTR_MYFUMBRELLA2_WEST ,
FTR_MYFUMBRELLA3_SOUTH, FTR_MYFUMBRELLA3_EAST, FTR_MYFUMBRELLA3_NORTH, FTR_MYFUMBRELLA3_WEST ,
FTR_MYFUMBRELLA4_SOUTH, FTR_MYFUMBRELLA4_EAST, FTR_MYFUMBRELLA4_NORTH, FTR_MYFUMBRELLA4_WEST ,
FTR_MYFUMBRELLA5_SOUTH, FTR_MYFUMBRELLA5_EAST, FTR_MYFUMBRELLA5_NORTH, FTR_MYFUMBRELLA5_WEST ,
FTR_MYFUMBRELLA6_SOUTH, FTR_MYFUMBRELLA6_EAST, FTR_MYFUMBRELLA6_NORTH, FTR_MYFUMBRELLA6_WEST ,
FTR_MYFUMBRELLA7_SOUTH, FTR_MYFUMBRELLA7_EAST, FTR_MYFUMBRELLA7_NORTH, FTR_MYFUMBRELLA7_WEST ,
FTR_FAMICOM_COMMON00_SOUTH, FTR_FAMICOM_COMMON00_EAST, FTR_FAMICOM_COMMON00_NORTH, FTR_FAMICOM_COMMON00_WEST ,
FTR_FAMICOM_COMMON01_SOUTH, FTR_FAMICOM_COMMON01_EAST, FTR_FAMICOM_COMMON01_NORTH, FTR_FAMICOM_COMMON01_WEST ,
FTR_FAMICOM_COMMON02_SOUTH, FTR_FAMICOM_COMMON02_EAST, FTR_FAMICOM_COMMON02_NORTH, FTR_FAMICOM_COMMON02_WEST ,
FTR_FAMICOM_COMMON03_SOUTH, FTR_FAMICOM_COMMON03_EAST, FTR_FAMICOM_COMMON03_NORTH, FTR_FAMICOM_COMMON03_WEST ,
FTR_FAMICOM_COMMON04_SOUTH, FTR_FAMICOM_COMMON04_EAST, FTR_FAMICOM_COMMON04_NORTH, FTR_FAMICOM_COMMON04_WEST ,
FTR_FAMICOM_COMMON05_SOUTH, FTR_FAMICOM_COMMON05_EAST, FTR_FAMICOM_COMMON05_NORTH, FTR_FAMICOM_COMMON05_WEST ,
FTR_FAMICOM_COMMON06_SOUTH, FTR_FAMICOM_COMMON06_EAST, FTR_FAMICOM_COMMON06_NORTH, FTR_FAMICOM_COMMON06_WEST ,
FTR_FAMICOM_COMMON07_SOUTH, FTR_FAMICOM_COMMON07_EAST, FTR_FAMICOM_COMMON07_NORTH, FTR_FAMICOM_COMMON07_WEST ,
FTR_FAMICOM_COMMON08_SOUTH, FTR_FAMICOM_COMMON08_EAST, FTR_FAMICOM_COMMON08_NORTH, FTR_FAMICOM_COMMON08_WEST ,
FTR_FAMICOM_COMMON09_SOUTH, FTR_FAMICOM_COMMON09_EAST, FTR_FAMICOM_COMMON09_NORTH, FTR_FAMICOM_COMMON09_WEST ,
FTR_FAMICOM_COMMON10_SOUTH, FTR_FAMICOM_COMMON10_EAST, FTR_FAMICOM_COMMON10_NORTH, FTR_FAMICOM_COMMON10_WEST ,
FTR_FAMICOM_COMMON11_SOUTH, FTR_FAMICOM_COMMON11_EAST, FTR_FAMICOM_COMMON11_NORTH, FTR_FAMICOM_COMMON11_WEST ,
FTR_FAMICOM_COMMON12_SOUTH, FTR_FAMICOM_COMMON12_EAST, FTR_FAMICOM_COMMON12_NORTH, FTR_FAMICOM_COMMON12_WEST ,
FTR_FAMICOM_COMMON13_SOUTH, FTR_FAMICOM_COMMON13_EAST, FTR_FAMICOM_COMMON13_NORTH, FTR_FAMICOM_COMMON13_WEST ,
FTR_FAMICOM_COMMON14_SOUTH, FTR_FAMICOM_COMMON14_EAST, FTR_FAMICOM_COMMON14_NORTH, FTR_FAMICOM_COMMON14_WEST ,
FTR_FAMICOM_COMMON15_SOUTH, FTR_FAMICOM_COMMON15_EAST, FTR_FAMICOM_COMMON15_NORTH, FTR_FAMICOM_COMMON15_WEST ,
FTR_FAMICOM_COMMON16_SOUTH, FTR_FAMICOM_COMMON16_EAST, FTR_FAMICOM_COMMON16_NORTH, FTR_FAMICOM_COMMON16_WEST ,
FTR_FAMICOM_COMMON17_SOUTH, FTR_FAMICOM_COMMON17_EAST, FTR_FAMICOM_COMMON17_NORTH, FTR_FAMICOM_COMMON17_WEST ,
FTR_FAMICOM_COMMON18_SOUTH, FTR_FAMICOM_COMMON18_EAST, FTR_FAMICOM_COMMON18_NORTH, FTR_FAMICOM_COMMON18_WEST ,
FTR_KOB_DISKSYSTEM8_SOUTH, FTR_KOB_DISKSYSTEM8_EAST, FTR_KOB_DISKSYSTEM8_NORTH, FTR_KOB_DISKSYSTEM8_WEST ,
FTR_SUM_CHIKUON01_SOUTH, FTR_SUM_CHIKUON01_EAST, FTR_SUM_CHIKUON01_NORTH, FTR_SUM_CHIKUON01_WEST ,
FTR_SUM_CHIKUON02_SOUTH, FTR_SUM_CHIKUON02_EAST, FTR_SUM_CHIKUON02_NORTH, FTR_SUM_CHIKUON02_WEST ,
FTR_SUM_JUKEBOX_SOUTH, FTR_SUM_JUKEBOX_EAST, FTR_SUM_JUKEBOX_NORTH, FTR_SUM_JUKEBOX_WEST ,
FTR_SUM_RADIO01_SOUTH, FTR_SUM_RADIO01_EAST, FTR_SUM_RADIO01_NORTH, FTR_SUM_RADIO01_WEST ,
FTR_SUM_RADIO02_SOUTH, FTR_SUM_RADIO02_EAST, FTR_SUM_RADIO02_NORTH, FTR_SUM_RADIO02_WEST ,
FTR_SUM_CONPO02_SOUTH, FTR_SUM_CONPO02_EAST, FTR_SUM_CONPO02_NORTH, FTR_SUM_CONPO02_WEST ,
FTR_SUM_STEREO02_SOUTH, FTR_SUM_STEREO02_EAST, FTR_SUM_STEREO02_NORTH, FTR_SUM_STEREO02_WEST ,
FTR_SUM_LV_STEREO_SOUTH, FTR_SUM_LV_STEREO_EAST, FTR_SUM_LV_STEREO_NORTH, FTR_SUM_LV_STEREO_WEST ,
FTR_SUM_X_LANP_SOUTH, FTR_SUM_X_LANP_EAST, FTR_SUM_X_LANP_NORTH, FTR_SUM_X_LANP_WEST ,
FTR_SUM_X_CHAIR01_SOUTH, FTR_SUM_X_CHAIR01_EAST, FTR_SUM_X_CHAIR01_NORTH, FTR_SUM_X_CHAIR01_WEST ,
FTR_SUM_X_CHEST03_SOUTH, FTR_SUM_X_CHEST03_EAST, FTR_SUM_X_CHEST03_NORTH, FTR_SUM_X_CHEST03_WEST ,
FTR_SUM_X_SOFA01_SOUTH, FTR_SUM_X_SOFA01_EAST, FTR_SUM_X_SOFA01_NORTH, FTR_SUM_X_SOFA01_WEST ,
FTR_SUM_X_BED01_SOUTH, FTR_SUM_X_BED01_EAST, FTR_SUM_X_BED01_NORTH, FTR_SUM_X_BED01_WEST ,
FTR_SUM_X_CLK_SOUTH, FTR_SUM_X_CLK_EAST, FTR_SUM_X_CLK_NORTH, FTR_SUM_X_CLK_WEST ,
FTR_SUM_X_TABLE01_SOUTH, FTR_SUM_X_TABLE01_EAST, FTR_SUM_X_TABLE01_NORTH, FTR_SUM_X_TABLE01_WEST ,
FTR_SUM_X_PIANO_SOUTH, FTR_SUM_X_PIANO_EAST, FTR_SUM_X_PIANO_NORTH, FTR_SUM_X_PIANO_WEST ,
FTR_SUM_DOLL11_SOUTH, FTR_SUM_DOLL11_EAST, FTR_SUM_DOLL11_NORTH, FTR_SUM_DOLL11_WEST ,
FTR_SUM_ROBOCONPO_SOUTH, FTR_SUM_ROBOCONPO_EAST, FTR_SUM_ROBOCONPO_NORTH, FTR_SUM_ROBOCONPO_WEST ,
FTR_SUM_SAICONPO_SOUTH, FTR_SUM_SAICONPO_EAST, FTR_SUM_SAICONPO_NORTH, FTR_SUM_SAICONPO_WEST ,
FTR_SUM_FRUITCLK_SOUTH, FTR_SUM_FRUITCLK_EAST, FTR_SUM_FRUITCLK_NORTH, FTR_SUM_FRUITCLK_WEST ,
FTR_SUM_ROBOCLK_SOUTH, FTR_SUM_ROBOCLK_EAST, FTR_SUM_ROBOCLK_NORTH, FTR_SUM_ROBOCLK_WEST ,
FTR_KON_AMECLOCK_SOUTH, FTR_KON_AMECLOCK_EAST, FTR_KON_AMECLOCK_NORTH, FTR_KON_AMECLOCK_WEST ,
FTR_KON_ATQCLOCK_SOUTH, FTR_KON_ATQCLOCK_EAST, FTR_KON_ATQCLOCK_NORTH, FTR_KON_ATQCLOCK_WEST ,
FTR_SUM_RECO01_SOUTH, FTR_SUM_RECO01_EAST, FTR_SUM_RECO01_NORTH, FTR_SUM_RECO01_WEST ,
FTR_SUM_CASSE01_SOUTH, FTR_SUM_CASSE01_EAST, FTR_SUM_CASSE01_NORTH, FTR_SUM_CASSE01_WEST ,
FTR_SUM_MD01_SOUTH, FTR_SUM_MD01_EAST, FTR_SUM_MD01_NORTH, FTR_SUM_MD01_WEST ,
FTR_KON_GRCLOCK_SOUTH, FTR_KON_GRCLOCK_EAST, FTR_KON_GRCLOCK_NORTH, FTR_KON_GRCLOCK_WEST ,
FTR_KON_WACLOCK_SOUTH, FTR_KON_WACLOCK_EAST, FTR_KON_WACLOCK_NORTH, FTR_KON_WACLOCK_WEST ,
FTR_KON_REDCLOCK_SOUTH, FTR_KON_REDCLOCK_EAST, FTR_KON_REDCLOCK_NORTH, FTR_KON_REDCLOCK_WEST ,
FTR_KON_BLUECLOCK_SOUTH, FTR_KON_BLUECLOCK_EAST, FTR_KON_BLUECLOCK_NORTH, FTR_KON_BLUECLOCK_WEST ,
FTR_KON_MIMICLOCK_SOUTH, FTR_KON_MIMICLOCK_EAST, FTR_KON_MIMICLOCK_NORTH, FTR_KON_MIMICLOCK_WEST ,
FTR_KON_MANEKI01_SOUTH, FTR_KON_MANEKI01_EAST, FTR_KON_MANEKI01_NORTH, FTR_KON_MANEKI01_WEST ,
FTR_KON_MANEKI02_SOUTH, FTR_KON_MANEKI02_EAST, FTR_KON_MANEKI02_NORTH, FTR_KON_MANEKI02_WEST ,
FTR_KON_MUSYA_SOUTH, FTR_KON_MUSYA_EAST, FTR_KON_MUSYA_NORTH, FTR_KON_MUSYA_WEST ,
FTR_KON_TANUKI_SOUTH, FTR_KON_TANUKI_EAST, FTR_KON_TANUKI_NORTH, FTR_KON_TANUKI_WEST ,
FTR_KON_KAERU_SOUTH, FTR_KON_KAERU_EAST, FTR_KON_KAERU_NORTH, FTR_KON_KAERU_WEST ,
FTR_KON_XTREE02_SOUTH, FTR_KON_XTREE02_EAST, FTR_KON_XTREE02_NORTH, FTR_KON_XTREE02_WEST ,
FTR_NOG_ROOKW_SOUTH, FTR_NOG_ROOKW_EAST, FTR_NOG_ROOKW_NORTH, FTR_NOG_ROOKW_WEST ,
FTR_NOG_ROOKB_SOUTH, FTR_NOG_ROOKB_EAST, FTR_NOG_ROOKB_NORTH, FTR_NOG_ROOKB_WEST ,
FTR_NOG_QUEENW_SOUTH, FTR_NOG_QUEENW_EAST, FTR_NOG_QUEENW_NORTH, FTR_NOG_QUEENW_WEST ,
FTR_NOG_QUEENB_SOUTH, FTR_NOG_QUEENB_EAST, FTR_NOG_QUEENB_NORTH, FTR_NOG_QUEENB_WEST ,
FTR_NOG_BISHOPW_SOUTH, FTR_NOG_BISHOPW_EAST, FTR_NOG_BISHOPW_NORTH, FTR_NOG_BISHOPW_WEST ,
FTR_NOG_BISHOPB_SOUTH, FTR_NOG_BISHOPB_EAST, FTR_NOG_BISHOPB_NORTH, FTR_NOG_BISHOPB_WEST ,
FTR_NOG_KINGW_SOUTH, FTR_NOG_KINGW_EAST, FTR_NOG_KINGW_NORTH, FTR_NOG_KINGW_WEST ,
FTR_NOG_KINGB_SOUTH, FTR_NOG_KINGB_EAST, FTR_NOG_KINGB_NORTH, FTR_NOG_KINGB_WEST ,
FTR_NOG_KNIGHTW_SOUTH, FTR_NOG_KNIGHTW_EAST, FTR_NOG_KNIGHTW_NORTH, FTR_NOG_KNIGHTW_WEST ,
FTR_NOG_KNIGHTB_SOUTH, FTR_NOG_KNIGHTB_EAST, FTR_NOG_KNIGHTB_NORTH, FTR_NOG_KNIGHTB_WEST ,
FTR_NOG_PAWNW_SOUTH, FTR_NOG_PAWNW_EAST, FTR_NOG_PAWNW_NORTH, FTR_NOG_PAWNW_WEST ,
FTR_NOG_PAWNB_SOUTH, FTR_NOG_PAWNB_EAST, FTR_NOG_PAWNB_NORTH, FTR_NOG_PAWNB_WEST ,
FTR_NOG_XTREE_SOUTH, FTR_NOG_XTREE_EAST, FTR_NOG_XTREE_NORTH, FTR_NOG_XTREE_WEST ,
FTR_NOG_TRI_CLOCK01_SOUTH, FTR_NOG_TRI_CLOCK01_EAST, FTR_NOG_TRI_CLOCK01_NORTH, FTR_NOG_TRI_CLOCK01_WEST ,
FTR_NOG_TRI_BED01_SOUTH, FTR_NOG_TRI_BED01_EAST, FTR_NOG_TRI_BED01_NORTH, FTR_NOG_TRI_BED01_WEST ,
FTR_NOG_TRI_TABLE01_SOUTH, FTR_NOG_TRI_TABLE01_EAST, FTR_NOG_TRI_TABLE01_NORTH, FTR_NOG_TRI_TABLE01_WEST ,
FTR_NOG_TRI_SOFA01_SOUTH, FTR_NOG_TRI_SOFA01_EAST, FTR_NOG_TRI_SOFA01_NORTH, FTR_NOG_TRI_SOFA01_WEST ,
FTR_NOG_TRI_AUDIO01_SOUTH, FTR_NOG_TRI_AUDIO01_EAST, FTR_NOG_TRI_AUDIO01_NORTH, FTR_NOG_TRI_AUDIO01_WEST ,
FTR_NOG_TRI_CHAIR01_SOUTH, FTR_NOG_TRI_CHAIR01_EAST, FTR_NOG_TRI_CHAIR01_NORTH, FTR_NOG_TRI_CHAIR01_WEST ,
FTR_NOG_TRI_RACK01_SOUTH, FTR_NOG_TRI_RACK01_EAST, FTR_NOG_TRI_RACK01_NORTH, FTR_NOG_TRI_RACK01_WEST ,
FTR_IKE_JPN_TOKONOMA01_SOUTH, FTR_IKE_JPN_TOKONOMA01_EAST, FTR_IKE_JPN_TOKONOMA01_NORTH, FTR_IKE_JPN_TOKONOMA01_WEST ,
FTR_IKE_JPN_IRORI01_SOUTH, FTR_IKE_JPN_IRORI01_EAST, FTR_IKE_JPN_IRORI01_NORTH, FTR_IKE_JPN_IRORI01_WEST ,
FTR_SUM_KOKUBAN_SOUTH, FTR_SUM_KOKUBAN_EAST, FTR_SUM_KOKUBAN_NORTH, FTR_SUM_KOKUBAN_WEST ,
FTR_SUM_BAKETU_SOUTH, FTR_SUM_BAKETU_EAST, FTR_SUM_BAKETU_NORTH, FTR_SUM_BAKETU_WEST ,
FTR_DIN_TRIKERA_HEAD_SOUTH, FTR_DIN_TRIKERA_HEAD_EAST, FTR_DIN_TRIKERA_HEAD_NORTH, FTR_DIN_TRIKERA_HEAD_WEST ,
FTR_DIN_TRIKERA_TAIL_SOUTH, FTR_DIN_TRIKERA_TAIL_EAST, FTR_DIN_TRIKERA_TAIL_NORTH, FTR_DIN_TRIKERA_TAIL_WEST ,
FTR_DIN_TRIKERA_BODY_SOUTH, FTR_DIN_TRIKERA_BODY_EAST, FTR_DIN_TRIKERA_BODY_NORTH, FTR_DIN_TRIKERA_BODY_WEST ,
FTR_DIN_TREX_HEAD_SOUTH, FTR_DIN_TREX_HEAD_EAST, FTR_DIN_TREX_HEAD_NORTH, FTR_DIN_TREX_HEAD_WEST ,
FTR_DIN_TREX_TAIL_SOUTH, FTR_DIN_TREX_TAIL_EAST, FTR_DIN_TREX_TAIL_NORTH, FTR_DIN_TREX_TAIL_WEST ,
FTR_DIN_TREX_BODY_SOUTH, FTR_DIN_TREX_BODY_EAST, FTR_DIN_TREX_BODY_NORTH, FTR_DIN_TREX_BODY_WEST ,
FTR_DIN_BRONT_HEAD_SOUTH, FTR_DIN_BRONT_HEAD_EAST, FTR_DIN_BRONT_HEAD_NORTH, FTR_DIN_BRONT_HEAD_WEST ,
FTR_DIN_BRONT_TAIL_SOUTH, FTR_DIN_BRONT_TAIL_EAST, FTR_DIN_BRONT_TAIL_NORTH, FTR_DIN_BRONT_TAIL_WEST ,
FTR_DIN_BRONT_BODY_SOUTH, FTR_DIN_BRONT_BODY_EAST, FTR_DIN_BRONT_BODY_NORTH, FTR_DIN_BRONT_BODY_WEST ,
FTR_DIN_STEGO_HEAD_SOUTH, FTR_DIN_STEGO_HEAD_EAST, FTR_DIN_STEGO_HEAD_NORTH, FTR_DIN_STEGO_HEAD_WEST ,
FTR_DIN_STEGO_TAIL_SOUTH, FTR_DIN_STEGO_TAIL_EAST, FTR_DIN_STEGO_TAIL_NORTH, FTR_DIN_STEGO_TAIL_WEST ,
FTR_DIN_STEGO_BODY_SOUTH, FTR_DIN_STEGO_BODY_EAST, FTR_DIN_STEGO_BODY_NORTH, FTR_DIN_STEGO_BODY_WEST ,
FTR_DIN_PTERA_HEAD_SOUTH, FTR_DIN_PTERA_HEAD_EAST, FTR_DIN_PTERA_HEAD_NORTH, FTR_DIN_PTERA_HEAD_WEST ,
FTR_DIN_PTERA_RWING_SOUTH, FTR_DIN_PTERA_RWING_EAST, FTR_DIN_PTERA_RWING_NORTH, FTR_DIN_PTERA_RWING_WEST ,
FTR_DIN_PTERA_LWING_SOUTH, FTR_DIN_PTERA_LWING_EAST, FTR_DIN_PTERA_LWING_NORTH, FTR_DIN_PTERA_LWING_WEST ,
FTR_DIN_HUTABA_HEAD_SOUTH, FTR_DIN_HUTABA_HEAD_EAST, FTR_DIN_HUTABA_HEAD_NORTH, FTR_DIN_HUTABA_HEAD_WEST ,
FTR_DIN_HUTABA_NECK_SOUTH, FTR_DIN_HUTABA_NECK_EAST, FTR_DIN_HUTABA_NECK_NORTH, FTR_DIN_HUTABA_NECK_WEST ,
FTR_DIN_HUTABA_BODY_SOUTH, FTR_DIN_HUTABA_BODY_EAST, FTR_DIN_HUTABA_BODY_NORTH, FTR_DIN_HUTABA_BODY_WEST ,
FTR_DIN_MAMMOTH_HEAD_SOUTH, FTR_DIN_MAMMOTH_HEAD_EAST, FTR_DIN_MAMMOTH_HEAD_NORTH, FTR_DIN_MAMMOTH_HEAD_WEST ,
FTR_DIN_MAMMOTH_BODY_SOUTH, FTR_DIN_MAMMOTH_BODY_EAST, FTR_DIN_MAMMOTH_BODY_NORTH, FTR_DIN_MAMMOTH_BODY_WEST ,
FTR_DIN_AMBER_SOUTH, FTR_DIN_AMBER_EAST, FTR_DIN_AMBER_NORTH, FTR_DIN_AMBER_WEST ,
FTR_DIN_STUMP_SOUTH, FTR_DIN_STUMP_EAST, FTR_DIN_STUMP_NORTH, FTR_DIN_STUMP_WEST ,
FTR_DIN_AMMONITE_SOUTH, FTR_DIN_AMMONITE_EAST, FTR_DIN_AMMONITE_NORTH, FTR_DIN_AMMONITE_WEST ,
FTR_DIN_EGG_SOUTH, FTR_DIN_EGG_EAST, FTR_DIN_EGG_NORTH, FTR_DIN_EGG_WEST ,
FTR_DIN_TRILOBITE_SOUTH, FTR_DIN_TRILOBITE_EAST, FTR_DIN_TRILOBITE_NORTH, FTR_DIN_TRILOBITE_WEST ,
FTR_SUM_BLA_LANP_SOUTH, FTR_SUM_BLA_LANP_EAST, FTR_SUM_BLA_LANP_NORTH, FTR_SUM_BLA_LANP_WEST ,
FTR_KON_SNOWFREEZER_SOUTH, FTR_KON_SNOWFREEZER_EAST, FTR_KON_SNOWFREEZER_NORTH, FTR_KON_SNOWFREEZER_WEST ,
FTR_KON_SNOWTABLE_SOUTH, FTR_KON_SNOWTABLE_EAST, FTR_KON_SNOWTABLE_NORTH, FTR_KON_SNOWTABLE_WEST ,
FTR_KON_SNOWBED_SOUTH, FTR_KON_SNOWBED_EAST, FTR_KON_SNOWBED_NORTH, FTR_KON_SNOWBED_WEST ,
FTR_TAK_SNOWISU_SOUTH, FTR_TAK_SNOWISU_EAST, FTR_TAK_SNOWISU_NORTH, FTR_TAK_SNOWISU_WEST ,
FTR_TAK_SNOWLAMP_SOUTH, FTR_TAK_SNOWLAMP_EAST, FTR_TAK_SNOWLAMP_NORTH, FTR_TAK_SNOWLAMP_WEST ,
FTR_KON_SNOWSOFA_SOUTH, FTR_KON_SNOWSOFA_EAST, FTR_KON_SNOWSOFA_NORTH, FTR_KON_SNOWSOFA_WEST ,
FTR_KON_SNOWTV_SOUTH, FTR_KON_SNOWTV_EAST, FTR_KON_SNOWTV_NORTH, FTR_KON_SNOWTV_WEST ,
FTR_KON_SNOWTANSU_SOUTH, FTR_KON_SNOWTANSU_EAST, FTR_KON_SNOWTANSU_NORTH, FTR_KON_SNOWTANSU_WEST ,
FTR_KON_SNOWBOX_SOUTH, FTR_KON_SNOWBOX_EAST, FTR_KON_SNOWBOX_NORTH, FTR_KON_SNOWBOX_WEST ,
FTR_KON_SNOWCLOCK_SOUTH, FTR_KON_SNOWCLOCK_EAST, FTR_KON_SNOWCLOCK_NORTH, FTR_KON_SNOWCLOCK_WEST ,
FTR_DIN_TRIKERA_DUMMY_SOUTH, FTR_DIN_TRIKERA_DUMMY_EAST, FTR_DIN_TRIKERA_DUMMY_NORTH, FTR_DIN_TRIKERA_DUMMY_WEST ,
FTR_DIN_TREX_DUMMY_SOUTH, FTR_DIN_TREX_DUMMY_EAST, FTR_DIN_TREX_DUMMY_NORTH, FTR_DIN_TREX_DUMMY_WEST ,
FTR_DIN_BRONT_DUMMY_SOUTH, FTR_DIN_BRONT_DUMMY_EAST, FTR_DIN_BRONT_DUMMY_NORTH, FTR_DIN_BRONT_DUMMY_WEST ,
FTR_DIN_PTERA_DUMMY_SOUTH, FTR_DIN_PTERA_DUMMY_EAST, FTR_DIN_PTERA_DUMMY_NORTH, FTR_DIN_PTERA_DUMMY_WEST ,
FTR_DIN_HUTABA_DUMMY_SOUTH, FTR_DIN_HUTABA_DUMMY_EAST, FTR_DIN_HUTABA_DUMMY_NORTH, FTR_DIN_HUTABA_DUMMY_WEST ,
FTR_DIN_MAMMOTH_DUMMY_SOUTH, FTR_DIN_MAMMOTH_DUMMY_EAST, FTR_DIN_MAMMOTH_DUMMY_NORTH, FTR_DIN_MAMMOTH_DUMMY_WEST ,
FTR_DIN_STEGO_DUMMYA_SOUTH, FTR_DIN_STEGO_DUMMYA_EAST, FTR_DIN_STEGO_DUMMYA_NORTH, FTR_DIN_STEGO_DUMMYA_WEST ,
FTR_DIN_STEGO_DUMMYB_SOUTH, FTR_DIN_STEGO_DUMMYB_EAST, FTR_DIN_STEGO_DUMMYB_NORTH, FTR_DIN_STEGO_DUMMYB_WEST ,
FTR_DIN_DUMMY_SOUTH, FTR_DIN_DUMMY_EAST, FTR_DIN_DUMMY_NORTH, FTR_DIN_DUMMY_WEST ,
FTR_TAK_SYOGI_SOUTH, FTR_TAK_SYOGI_EAST, FTR_TAK_SYOGI_NORTH, FTR_TAK_SYOGI_WEST ,
FTR_IKE_JNY_MAKADA01_SOUTH, FTR_IKE_JNY_MAKADA01_EAST, FTR_IKE_JNY_MAKADA01_NORTH, FTR_IKE_JNY_MAKADA01_WEST ,
FTR_IKE_PST_POST01_SOUTH, FTR_IKE_PST_POST01_EAST, FTR_IKE_PST_POST01_NORTH, FTR_IKE_PST_POST01_WEST ,
FTR_IKE_PST_PIG01_SOUTH, FTR_IKE_PST_PIG01_EAST, FTR_IKE_PST_PIG01_NORTH, FTR_IKE_PST_PIG01_WEST ,
FTR_IKE_PST_TESYU01_SOUTH, FTR_IKE_PST_TESYU01_EAST, FTR_IKE_PST_TESYU01_NORTH, FTR_IKE_PST_TESYU01_WEST ,
FTR_IKE_JNY_AFMEN01_SOUTH, FTR_IKE_JNY_AFMEN01_EAST, FTR_IKE_JNY_AFMEN01_NORTH, FTR_IKE_JNY_AFMEN01_WEST ,
FTR_IKE_JNY_ROSIA01_SOUTH, FTR_IKE_JNY_ROSIA01_EAST, FTR_IKE_JNY_ROSIA01_NORTH, FTR_IKE_JNY_ROSIA01_WEST ,
FTR_HAYAKAWA_FAMICOM_SOUTH, FTR_HAYAKAWA_FAMICOM_EAST, FTR_HAYAKAWA_FAMICOM_NORTH, FTR_HAYAKAWA_FAMICOM_WEST ,
FTR_IKE_JNY_BOTLE01_SOUTH, FTR_IKE_JNY_BOTLE01_EAST, FTR_IKE_JNY_BOTLE01_NORTH, FTR_IKE_JNY_BOTLE01_WEST ,
FTR_IKE_JNY_HARIKO01_SOUTH, FTR_IKE_JNY_HARIKO01_EAST, FTR_IKE_JNY_HARIKO01_NORTH, FTR_IKE_JNY_HARIKO01_WEST ,
FTR_IKE_JNY_MOAI01_SOUTH, FTR_IKE_JNY_MOAI01_EAST, FTR_IKE_JNY_MOAI01_NORTH, FTR_IKE_JNY_MOAI01_WEST ,
FTR_RADIO_TEST_SOUTH, FTR_RADIO_TEST_EAST, FTR_RADIO_TEST_NORTH, FTR_RADIO_TEST_WEST ,
FTR_IKE_JNY_GOJYU01_SOUTH, FTR_IKE_JNY_GOJYU01_EAST, FTR_IKE_JNY_GOJYU01_NORTH, FTR_IKE_JNY_GOJYU01_WEST ,
FTR_IKE_JNY_KIBORI01_SOUTH, FTR_IKE_JNY_KIBORI01_EAST, FTR_IKE_JNY_KIBORI01_NORTH, FTR_IKE_JNY_KIBORI01_WEST ,
FTR_IKE_JNY_TRUTH01_SOUTH, FTR_IKE_JNY_TRUTH01_EAST, FTR_IKE_JNY_TRUTH01_NORTH, FTR_IKE_JNY_TRUTH01_WEST ,
FTR_IKE_JNY_SIRSER01_SOUTH, FTR_IKE_JNY_SIRSER01_EAST, FTR_IKE_JNY_SIRSER01_NORTH, FTR_IKE_JNY_SIRSER01_WEST ,
FTR_IKE_JNY_PISA01_SOUTH, FTR_IKE_JNY_PISA01_EAST, FTR_IKE_JNY_PISA01_NORTH, FTR_IKE_JNY_PISA01_WEST ,
FTR_TAK_LION_SOUTH, FTR_TAK_LION_EAST, FTR_TAK_LION_NORTH, FTR_TAK_LION_WEST ,
FTR_IKE_JNY_SYON01_SOUTH, FTR_IKE_JNY_SYON01_EAST, FTR_IKE_JNY_SYON01_NORTH, FTR_IKE_JNY_SYON01_WEST ,
FTR_IKE_JNY_TOWER01_SOUTH, FTR_IKE_JNY_TOWER01_EAST, FTR_IKE_JNY_TOWER01_NORTH, FTR_IKE_JNY_TOWER01_WEST ,
FTR_NOG_BALLOON_COMMON0_SOUTH, FTR_NOG_BALLOON_COMMON0_EAST, FTR_NOG_BALLOON_COMMON0_NORTH, FTR_NOG_BALLOON_COMMON0_WEST ,
FTR_NOG_BALLOON_COMMON1_SOUTH, FTR_NOG_BALLOON_COMMON1_EAST, FTR_NOG_BALLOON_COMMON1_NORTH, FTR_NOG_BALLOON_COMMON1_WEST ,
FTR_NOG_BALLOON_COMMON2_SOUTH, FTR_NOG_BALLOON_COMMON2_EAST, FTR_NOG_BALLOON_COMMON2_NORTH, FTR_NOG_BALLOON_COMMON2_WEST ,
FTR_NOG_BALLOON_COMMON3_SOUTH, FTR_NOG_BALLOON_COMMON3_EAST, FTR_NOG_BALLOON_COMMON3_NORTH, FTR_NOG_BALLOON_COMMON3_WEST ,
FTR0_END
};
enum ftr1_e {
__FTR1_START = 0x3000 -1,
FTR_NOG_BALLOON_COMMON4_SOUTH, FTR_NOG_BALLOON_COMMON4_EAST, FTR_NOG_BALLOON_COMMON4_NORTH, FTR_NOG_BALLOON_COMMON4_WEST ,
FTR_NOG_BALLOON_COMMON5_SOUTH, FTR_NOG_BALLOON_COMMON5_EAST, FTR_NOG_BALLOON_COMMON5_NORTH, FTR_NOG_BALLOON_COMMON5_WEST ,
FTR_NOG_BALLOON_COMMON6_SOUTH, FTR_NOG_BALLOON_COMMON6_EAST, FTR_NOG_BALLOON_COMMON6_NORTH, FTR_NOG_BALLOON_COMMON6_WEST ,
FTR_NOG_BALLOON_COMMON7_SOUTH, FTR_NOG_BALLOON_COMMON7_EAST, FTR_NOG_BALLOON_COMMON7_NORTH, FTR_NOG_BALLOON_COMMON7_WEST ,
FTR_TAK_MEGAMI_SOUTH, FTR_TAK_MEGAMI_EAST, FTR_TAK_MEGAMI_NORTH, FTR_TAK_MEGAMI_WEST ,
FTR_IKE_JNY_GATE01_SOUTH, FTR_IKE_JNY_GATE01_EAST, FTR_IKE_JNY_GATE01_NORTH, FTR_IKE_JNY_GATE01_WEST ,
FTR_TAK_MONEY_SOUTH, FTR_TAK_MONEY_EAST, FTR_TAK_MONEY_NORTH, FTR_TAK_MONEY_WEST ,
FTR_IKE_JNY_NINGYO01_SOUTH, FTR_IKE_JNY_NINGYO01_EAST, FTR_IKE_JNY_NINGYO01_NORTH, FTR_IKE_JNY_NINGYO01_WEST ,
FTR_NOG_YUBIN_SOUTH, FTR_NOG_YUBIN_EAST, FTR_NOG_YUBIN_NORTH, FTR_NOG_YUBIN_WEST ,
FTR_NOG_MYHOME2_SOUTH, FTR_NOG_MYHOME2_EAST, FTR_NOG_MYHOME2_NORTH, FTR_NOG_MYHOME2_WEST ,
FTR_NOG_MYHOME4_SOUTH, FTR_NOG_MYHOME4_EAST, FTR_NOG_MYHOME4_NORTH, FTR_NOG_MYHOME4_WEST ,
FTR_NOG_KOBAN_SOUTH, FTR_NOG_KOBAN_EAST, FTR_NOG_KOBAN_NORTH, FTR_NOG_KOBAN_WEST ,
FTR_NOG_MUSEUM_SOUTH, FTR_NOG_MUSEUM_EAST, FTR_NOG_MUSEUM_NORTH, FTR_NOG_MUSEUM_WEST ,
FTR_TAK_YOROI_SOUTH, FTR_TAK_YOROI_EAST, FTR_TAK_YOROI_NORTH, FTR_TAK_YOROI_WEST ,
FTR_IKE_K_TUKIMI01_SOUTH, FTR_IKE_K_TUKIMI01_EAST, FTR_IKE_K_TUKIMI01_NORTH, FTR_IKE_K_TUKIMI01_WEST ,
FTR_IKE_K_MAME01_SOUTH, FTR_IKE_K_MAME01_EAST, FTR_IKE_K_MAME01_NORTH, FTR_IKE_K_MAME01_WEST ,
FTR_IKE_K_SINNEN01_SOUTH, FTR_IKE_K_SINNEN01_EAST, FTR_IKE_K_SINNEN01_NORTH, FTR_IKE_K_SINNEN01_WEST ,
FTR_IKE_K_OTOME01_SOUTH, FTR_IKE_K_OTOME01_EAST, FTR_IKE_K_OTOME01_NORTH, FTR_IKE_K_OTOME01_WEST ,
FTR_NOG_YAMISHOP_SOUTH, FTR_NOG_YAMISHOP_EAST, FTR_NOG_YAMISHOP_NORTH, FTR_NOG_YAMISHOP_WEST ,
FTR_NOG_URANAI_SOUTH, FTR_NOG_URANAI_EAST, FTR_NOG_URANAI_NORTH, FTR_NOG_URANAI_WEST ,
FTR_IKE_JNY_SIRSER201_SOUTH, FTR_IKE_JNY_SIRSER201_EAST, FTR_IKE_JNY_SIRSER201_NORTH, FTR_IKE_JNY_SIRSER201_WEST ,
FTR_IKE_K_TANABATA01_SOUTH, FTR_IKE_K_TANABATA01_EAST, FTR_IKE_K_TANABATA01_NORTH, FTR_IKE_K_TANABATA01_WEST ,
FTR_TAK_FLAG01_SOUTH, FTR_TAK_FLAG01_EAST, FTR_TAK_FLAG01_NORTH, FTR_TAK_FLAG01_WEST ,
FTR_TAK_FLAG02_SOUTH, FTR_TAK_FLAG02_EAST, FTR_TAK_FLAG02_NORTH, FTR_TAK_FLAG02_WEST ,
FTR_NOG_SHOP1_SOUTH, FTR_NOG_SHOP1_EAST, FTR_NOG_SHOP1_NORTH, FTR_NOG_SHOP1_WEST ,
FTR_IKE_JNY_HOUI01_SOUTH, FTR_IKE_JNY_HOUI01_EAST, FTR_IKE_JNY_HOUI01_NORTH, FTR_IKE_JNY_HOUI01_WEST ,
FTR_IKE_K_COUNT01_SOUTH, FTR_IKE_K_COUNT01_EAST, FTR_IKE_K_COUNT01_NORTH, FTR_IKE_K_COUNT01_WEST ,
FTR_IKE_K_TURIS01_SOUTH, FTR_IKE_K_TURIS01_EAST, FTR_IKE_K_TURIS01_NORTH, FTR_IKE_K_TURIS01_WEST ,
FTR_TAK_TOUDAI_SOUTH, FTR_TAK_TOUDAI_EAST, FTR_TAK_TOUDAI_NORTH, FTR_TAK_TOUDAI_WEST ,
FTR_IKE_K_SUM01_SOUTH, FTR_IKE_K_SUM01_EAST, FTR_IKE_K_SUM01_NORTH, FTR_IKE_K_SUM01_WEST ,
FTR_NOG_S_TREE_SOUTH, FTR_NOG_S_TREE_EAST, FTR_NOG_S_TREE_NORTH, FTR_NOG_S_TREE_WEST ,
FTR_NOG_F_TREE_SOUTH, FTR_NOG_F_TREE_EAST, FTR_NOG_F_TREE_NORTH, FTR_NOG_F_TREE_WEST ,
FTR_NOG_ZASSOU_SOUTH, FTR_NOG_ZASSOU_EAST, FTR_NOG_ZASSOU_NORTH, FTR_NOG_ZASSOU_WEST ,
FTR_TAK_TAILOR_SOUTH, FTR_TAK_TAILOR_EAST, FTR_TAK_TAILOR_NORTH, FTR_TAK_TAILOR_WEST ,
FTR_NOG_DUMP_SOUTH, FTR_NOG_DUMP_EAST, FTR_NOG_DUMP_NORTH, FTR_NOG_DUMP_WEST ,
FTR_IID_HANABI_SOUTH, FTR_IID_HANABI_EAST, FTR_IID_HANABI_NORTH, FTR_IID_HANABI_WEST ,
FTR_NOG_SNOWMAN_SOUTH, FTR_NOG_SNOWMAN_EAST, FTR_NOG_SNOWMAN_NORTH, FTR_NOG_SNOWMAN_WEST ,
FTR_IKE_K_IVEBOY01_SOUTH, FTR_IKE_K_IVEBOY01_EAST, FTR_IKE_K_IVEBOY01_NORTH, FTR_IKE_K_IVEBOY01_WEST ,
FTR_TAK_FLAG03_SOUTH, FTR_TAK_FLAG03_EAST, FTR_TAK_FLAG03_NORTH, FTR_TAK_FLAG03_WEST ,
FTR_TAK_MOON_SOUTH, FTR_TAK_MOON_EAST, FTR_TAK_MOON_NORTH, FTR_TAK_MOON_WEST ,
FTR_IKE_K_KID01_SOUTH, FTR_IKE_K_KID01_EAST, FTR_IKE_K_KID01_NORTH, FTR_IKE_K_KID01_WEST ,
FTR_IID_NINGYOU_SOUTH, FTR_IID_NINGYOU_EAST, FTR_IID_NINGYOU_NORTH, FTR_IID_NINGYOU_WEST ,
FTR_NOG_STATION00_SOUTH, FTR_NOG_STATION00_EAST, FTR_NOG_STATION00_NORTH, FTR_NOG_STATION00_WEST ,
FTR_NOG_STATION01_SOUTH, FTR_NOG_STATION01_EAST, FTR_NOG_STATION01_NORTH, FTR_NOG_STATION01_WEST ,
FTR_NOG_STATION02_SOUTH, FTR_NOG_STATION02_EAST, FTR_NOG_STATION02_NORTH, FTR_NOG_STATION02_WEST ,
FTR_NOG_STATION03_SOUTH, FTR_NOG_STATION03_EAST, FTR_NOG_STATION03_NORTH, FTR_NOG_STATION03_WEST ,
FTR_NOG_STATION04_SOUTH, FTR_NOG_STATION04_EAST, FTR_NOG_STATION04_NORTH, FTR_NOG_STATION04_WEST ,
FTR_NOG_STATION05_SOUTH, FTR_NOG_STATION05_EAST, FTR_NOG_STATION05_NORTH, FTR_NOG_STATION05_WEST ,
FTR_NOG_STATION06_SOUTH, FTR_NOG_STATION06_EAST, FTR_NOG_STATION06_NORTH, FTR_NOG_STATION06_WEST ,
FTR_NOG_STATION07_SOUTH, FTR_NOG_STATION07_EAST, FTR_NOG_STATION07_NORTH, FTR_NOG_STATION07_WEST ,
FTR_NOG_STATION08_SOUTH, FTR_NOG_STATION08_EAST, FTR_NOG_STATION08_NORTH, FTR_NOG_STATION08_WEST ,
FTR_NOG_STATION09_SOUTH, FTR_NOG_STATION09_EAST, FTR_NOG_STATION09_NORTH, FTR_NOG_STATION09_WEST ,
FTR_NOG_STATION10_SOUTH, FTR_NOG_STATION10_EAST, FTR_NOG_STATION10_NORTH, FTR_NOG_STATION10_WEST ,
FTR_NOG_STATION11_SOUTH, FTR_NOG_STATION11_EAST, FTR_NOG_STATION11_NORTH, FTR_NOG_STATION11_WEST ,
FTR_NOG_STATION12_SOUTH, FTR_NOG_STATION12_EAST, FTR_NOG_STATION12_NORTH, FTR_NOG_STATION12_WEST ,
FTR_NOG_STATION13_SOUTH, FTR_NOG_STATION13_EAST, FTR_NOG_STATION13_NORTH, FTR_NOG_STATION13_WEST ,
FTR_NOG_STATION14_SOUTH, FTR_NOG_STATION14_EAST, FTR_NOG_STATION14_NORTH, FTR_NOG_STATION14_WEST ,
FTR_NOG_SHRINE_SOUTH, FTR_NOG_SHRINE_EAST, FTR_NOG_SHRINE_NORTH, FTR_NOG_SHRINE_WEST ,
FTR_NOG_FLAT_SOUTH, FTR_NOG_FLAT_EAST, FTR_NOG_FLAT_NORTH, FTR_NOG_FLAT_WEST ,
FTR_NOG_RAIL_SOUTH, FTR_NOG_RAIL_EAST, FTR_NOG_RAIL_NORTH, FTR_NOG_RAIL_WEST ,
FTR_NOG_EARTH_SOUTH, FTR_NOG_EARTH_EAST, FTR_NOG_EARTH_NORTH, FTR_NOG_EARTH_WEST ,
FTR_IKE_K_KID02_SOUTH, FTR_IKE_K_KID02_EAST, FTR_IKE_K_KID02_NORTH, FTR_IKE_K_KID02_WEST ,
FTR_NOG_MIKANBOX_SOUTH, FTR_NOG_MIKANBOX_EAST, FTR_NOG_MIKANBOX_NORTH, FTR_NOG_MIKANBOX_WEST ,
FTR_NOG_COLLEGENOTE_SOUTH, FTR_NOG_COLLEGENOTE_EAST, FTR_NOG_COLLEGENOTE_NORTH, FTR_NOG_COLLEGENOTE_WEST ,
FTR_NOG_SCHOOLNOTE_SOUTH, FTR_NOG_SCHOOLNOTE_EAST, FTR_NOG_SCHOOLNOTE_NORTH, FTR_NOG_SCHOOLNOTE_WEST ,
FTR_NOG_SYSTEMNOTE_SOUTH, FTR_NOG_SYSTEMNOTE_EAST, FTR_NOG_SYSTEMNOTE_NORTH, FTR_NOG_SYSTEMNOTE_WEST ,
FTR_NOG_HARDDIARY_SOUTH, FTR_NOG_HARDDIARY_EAST, FTR_NOG_HARDDIARY_NORTH, FTR_NOG_HARDDIARY_WEST ,
FTR_NOG_TUDURINOTE_SOUTH, FTR_NOG_TUDURINOTE_EAST, FTR_NOG_TUDURINOTE_NORTH, FTR_NOG_TUDURINOTE_WEST ,
FTR_IID_DIARY_SOUTH, FTR_IID_DIARY_EAST, FTR_IID_DIARY_NORTH, FTR_IID_DIARY_WEST ,
FTR_IID_FUNEDIARY_SOUTH, FTR_IID_FUNEDIARY_EAST, FTR_IID_FUNEDIARY_NORTH, FTR_IID_FUNEDIARY_WEST ,
FTR_IID_MDIARY_SOUTH, FTR_IID_MDIARY_EAST, FTR_IID_MDIARY_NORTH, FTR_IID_MDIARY_WEST ,
FTR_IID_NEWDIARY_SOUTH, FTR_IID_NEWDIARY_EAST, FTR_IID_NEWDIARY_NORTH, FTR_IID_NEWDIARY_WEST ,
FTR_TAK_NIKKI01_SOUTH, FTR_TAK_NIKKI01_EAST, FTR_TAK_NIKKI01_NORTH, FTR_TAK_NIKKI01_WEST ,
FTR_IKE_NIKKI_FAN1_SOUTH, FTR_IKE_NIKKI_FAN1_EAST, FTR_IKE_NIKKI_FAN1_NORTH, FTR_IKE_NIKKI_FAN1_WEST ,
FTR_IKE_NIKKI_FAN2_SOUTH, FTR_IKE_NIKKI_FAN2_EAST, FTR_IKE_NIKKI_FAN2_NORTH, FTR_IKE_NIKKI_FAN2_WEST ,
FTR_IKE_NIKKI_FAN3_SOUTH, FTR_IKE_NIKKI_FAN3_EAST, FTR_IKE_NIKKI_FAN3_NORTH, FTR_IKE_NIKKI_FAN3_WEST ,
FTR_IKE_NIKKI_FAN4_SOUTH, FTR_IKE_NIKKI_FAN4_EAST, FTR_IKE_NIKKI_FAN4_NORTH, FTR_IKE_NIKKI_FAN4_WEST ,
FTR_IKE_NIKKI_FAN5_SOUTH, FTR_IKE_NIKKI_FAN5_EAST, FTR_IKE_NIKKI_FAN5_NORTH, FTR_IKE_NIKKI_FAN5_WEST ,
FTR_IKE_NIKKI_WAFU1_SOUTH, FTR_IKE_NIKKI_WAFU1_EAST, FTR_IKE_NIKKI_WAFU1_NORTH, FTR_IKE_NIKKI_WAFU1_WEST ,
FTR_GOLD_ITEM0_SOUTH, FTR_GOLD_ITEM0_EAST, FTR_GOLD_ITEM0_NORTH, FTR_GOLD_ITEM0_WEST ,
FTR_GOLD_ITEM1_SOUTH, FTR_GOLD_ITEM1_EAST, FTR_GOLD_ITEM1_NORTH, FTR_GOLD_ITEM1_WEST ,
FTR_GOLD_ITEM2_SOUTH, FTR_GOLD_ITEM2_EAST, FTR_GOLD_ITEM2_NORTH, FTR_GOLD_ITEM2_WEST ,
FTR_GOLD_ITEM3_SOUTH, FTR_GOLD_ITEM3_EAST, FTR_GOLD_ITEM3_NORTH, FTR_GOLD_ITEM3_WEST ,
FTR_UTIWA0_SOUTH, FTR_UTIWA0_EAST, FTR_UTIWA0_NORTH, FTR_UTIWA0_WEST ,
FTR_UTIWA1_SOUTH, FTR_UTIWA1_EAST, FTR_UTIWA1_NORTH, FTR_UTIWA1_WEST ,
FTR_UTIWA2_SOUTH, FTR_UTIWA2_EAST, FTR_UTIWA2_NORTH, FTR_UTIWA2_WEST ,
FTR_UTIWA3_SOUTH, FTR_UTIWA3_EAST, FTR_UTIWA3_NORTH, FTR_UTIWA3_WEST ,
FTR_UTIWA4_SOUTH, FTR_UTIWA4_EAST, FTR_UTIWA4_NORTH, FTR_UTIWA4_WEST ,
FTR_UTIWA5_SOUTH, FTR_UTIWA5_EAST, FTR_UTIWA5_NORTH, FTR_UTIWA5_WEST ,
FTR_UTIWA6_SOUTH, FTR_UTIWA6_EAST, FTR_UTIWA6_NORTH, FTR_UTIWA6_WEST ,
FTR_UTIWA7_SOUTH, FTR_UTIWA7_EAST, FTR_UTIWA7_NORTH, FTR_UTIWA7_WEST ,
FTR_KAZAGURUMA0_SOUTH, FTR_KAZAGURUMA0_EAST, FTR_KAZAGURUMA0_NORTH, FTR_KAZAGURUMA0_WEST ,
FTR_KAZAGURUMA1_SOUTH, FTR_KAZAGURUMA1_EAST, FTR_KAZAGURUMA1_NORTH, FTR_KAZAGURUMA1_WEST ,
FTR_KAZAGURUMA2_SOUTH, FTR_KAZAGURUMA2_EAST, FTR_KAZAGURUMA2_NORTH, FTR_KAZAGURUMA2_WEST ,
FTR_KAZAGURUMA3_SOUTH, FTR_KAZAGURUMA3_EAST, FTR_KAZAGURUMA3_NORTH, FTR_KAZAGURUMA3_WEST ,
FTR_KAZAGURUMA4_SOUTH, FTR_KAZAGURUMA4_EAST, FTR_KAZAGURUMA4_NORTH, FTR_KAZAGURUMA4_WEST ,
FTR_KAZAGURUMA5_SOUTH, FTR_KAZAGURUMA5_EAST, FTR_KAZAGURUMA5_NORTH, FTR_KAZAGURUMA5_WEST ,
FTR_KAZAGURUMA6_SOUTH, FTR_KAZAGURUMA6_EAST, FTR_KAZAGURUMA6_NORTH, FTR_KAZAGURUMA6_WEST ,
FTR_KAZAGURUMA7_SOUTH, FTR_KAZAGURUMA7_EAST, FTR_KAZAGURUMA7_NORTH, FTR_KAZAGURUMA7_WEST ,
FTR_TOOL0_SOUTH, FTR_TOOL0_EAST, FTR_TOOL0_NORTH, FTR_TOOL0_WEST ,
FTR_TOOL1_SOUTH, FTR_TOOL1_EAST, FTR_TOOL1_NORTH, FTR_TOOL1_WEST ,
FTR_TOOL2_SOUTH, FTR_TOOL2_EAST, FTR_TOOL2_NORTH, FTR_TOOL2_WEST ,
FTR_TOOL3_SOUTH, FTR_TOOL3_EAST, FTR_TOOL3_NORTH, FTR_TOOL3_WEST ,
FTR_NOG_NABE_SOUTH, FTR_NOG_NABE_EAST, FTR_NOG_NABE_NORTH, FTR_NOG_NABE_WEST ,
FTR_IKE_KAMA_DANRO01_SOUTH, FTR_IKE_KAMA_DANRO01_EAST, FTR_IKE_KAMA_DANRO01_NORTH, FTR_IKE_KAMA_DANRO01_WEST ,
FTR_NOG_KAMAKURA_SOUTH, FTR_NOG_KAMAKURA_EAST, FTR_NOG_KAMAKURA_NORTH, FTR_NOG_KAMAKURA_WEST ,
FTR_NOG_W_TREE_SOUTH, FTR_NOG_W_TREE_EAST, FTR_NOG_W_TREE_NORTH, FTR_NOG_W_TREE_WEST ,
FTR_TAK_ICE_SOUTH, FTR_TAK_ICE_EAST, FTR_TAK_ICE_NORTH, FTR_TAK_ICE_WEST ,
FTR_IKE_ISLAND_HAKO01_SOUTH, FTR_IKE_ISLAND_HAKO01_EAST, FTR_IKE_ISLAND_HAKO01_NORTH, FTR_IKE_ISLAND_HAKO01_WEST ,
FTR_NOG_BEACHBED_SOUTH, FTR_NOG_BEACHBED_EAST, FTR_NOG_BEACHBED_NORTH, FTR_NOG_BEACHBED_WEST ,
FTR_NOG_BEACHTABLE_SOUTH, FTR_NOG_BEACHTABLE_EAST, FTR_NOG_BEACHTABLE_NORTH, FTR_NOG_BEACHTABLE_WEST ,
FTR_TAK_HIBATI_SOUTH, FTR_TAK_HIBATI_EAST, FTR_TAK_HIBATI_NORTH, FTR_TAK_HIBATI_WEST ,
FTR_IID_SURF_SOUTH, FTR_IID_SURF_EAST, FTR_IID_SURF_NORTH, FTR_IID_SURF_WEST ,
FTR_IID_SNOW_SOUTH, FTR_IID_SNOW_EAST, FTR_IID_SNOW_NORTH, FTR_IID_SNOW_WEST ,
FTR_TAK_TETRA_SOUTH, FTR_TAK_TETRA_EAST, FTR_TAK_TETRA_NORTH, FTR_TAK_TETRA_WEST ,
FTR_IKE_ISLAND_UKU01_SOUTH, FTR_IKE_ISLAND_UKU01_EAST, FTR_IKE_ISLAND_UKU01_NORTH, FTR_IKE_ISLAND_UKU01_WEST ,
FTR_IKE_ISLAND_SENSUI01_SOUTH, FTR_IKE_ISLAND_SENSUI01_EAST, FTR_IKE_ISLAND_SENSUI01_NORTH, FTR_IKE_ISLAND_SENSUI01_WEST ,
FTR_IID_YUKI_SOUTH, FTR_IID_YUKI_EAST, FTR_IID_YUKI_NORTH, FTR_IID_YUKI_WEST ,
FTR_SUM_ART02_SOUTH, FTR_SUM_ART02_EAST, FTR_SUM_ART02_NORTH, FTR_SUM_ART02_WEST ,
FTR_SUM_ART03_SOUTH, FTR_SUM_ART03_EAST, FTR_SUM_ART03_NORTH, FTR_SUM_ART03_WEST ,
FTR_TAK_SORI01_SOUTH, FTR_TAK_SORI01_EAST, FTR_TAK_SORI01_NORTH, FTR_TAK_SORI01_WEST ,
FTR_IID_BENTI_SOUTH, FTR_IID_BENTI_EAST, FTR_IID_BENTI_NORTH, FTR_IID_BENTI_WEST ,
FTR_TAK_CUBE_SOUTH, FTR_TAK_CUBE_EAST, FTR_TAK_CUBE_NORTH, FTR_TAK_CUBE_WEST ,
FTR_IKU_DENKO_SOUTH, FTR_IKU_DENKO_EAST, FTR_IKU_DENKO_NORTH, FTR_IKU_DENKO_WEST ,
FTR_YAZ_ROCKET_SOUTH, FTR_YAZ_ROCKET_EAST, FTR_YAZ_ROCKET_NORTH, FTR_YAZ_ROCKET_WEST ,
FTR_IKU_SLIP_SOUTH, FTR_IKU_SLIP_EAST, FTR_IKU_SLIP_NORTH, FTR_IKU_SLIP_WEST ,
FTR_IKU_UKAI_SOUTH, FTR_IKU_UKAI_EAST, FTR_IKU_UKAI_NORTH, FTR_IKU_UKAI_WEST ,
FTR_IKU_WORK_SOUTH, FTR_IKU_WORK_EAST, FTR_IKU_WORK_NORTH, FTR_IKU_WORK_WEST ,
FTR_HOS_DESKL_SOUTH, FTR_HOS_DESKL_EAST, FTR_HOS_DESKL_NORTH, FTR_HOS_DESKL_WEST ,
FTR_HOS_DESKR_SOUTH, FTR_HOS_DESKR_EAST, FTR_HOS_DESKR_NORTH, FTR_HOS_DESKR_WEST ,
FTR_HOS_FLIP_SOUTH, FTR_HOS_FLIP_EAST, FTR_HOS_FLIP_NORTH, FTR_HOS_FLIP_WEST ,
FTR_IKU_FLAGMAN_SOUTH, FTR_IKU_FLAGMAN_EAST, FTR_IKU_FLAGMAN_NORTH, FTR_IKU_FLAGMAN_WEST ,
FTR_YAZ_FISH_TROPHY_SOUTH, FTR_YAZ_FISH_TROPHY_EAST, FTR_YAZ_FISH_TROPHY_NORTH, FTR_YAZ_FISH_TROPHY_WEST ,
FTR_IKU_JERSEY_SOUTH, FTR_IKU_JERSEY_EAST, FTR_IKU_JERSEY_NORTH, FTR_IKU_JERSEY_WEST ,
FTR_IKU_REDUCESPEED_SOUTH, FTR_IKU_REDUCESPEED_EAST, FTR_IKU_REDUCESPEED_NORTH, FTR_IKU_REDUCESPEED_WEST ,
FTR_YAZ_GOLF_TROPHY_SOUTH, FTR_YAZ_GOLF_TROPHY_EAST, FTR_YAZ_GOLF_TROPHY_NORTH, FTR_YAZ_GOLF_TROPHY_WEST ,
FTR_HOS_TDESK_SOUTH, FTR_HOS_TDESK_EAST, FTR_HOS_TDESK_NORTH, FTR_HOS_TDESK_WEST ,
FTR_IKU_HAZARDOUS_TOP_SOUTH, FTR_IKU_HAZARDOUS_TOP_EAST, FTR_IKU_HAZARDOUS_TOP_NORTH, FTR_IKU_HAZARDOUS_TOP_WEST ,
FTR_YAZ_TENNIS_TROPHY_SOUTH, FTR_YAZ_TENNIS_TROPHY_EAST, FTR_YAZ_TENNIS_TROPHY_NORTH, FTR_YAZ_TENNIS_TROPHY_WEST ,
FTR_IKU_SAWHOUSEV_SOUTH, FTR_IKU_SAWHOUSEV_EAST, FTR_IKU_SAWHOUSEV_NORTH, FTR_IKU_SAWHOUSEV_WEST ,
FTR_YAZ_KART_TROPHY_SOUTH, FTR_YAZ_KART_TROPHY_EAST, FTR_YAZ_KART_TROPHY_NORTH, FTR_YAZ_KART_TROPHY_WEST ,
FTR_IKU_BUGZAPPER_SOUTH, FTR_IKU_BUGZAPPER_EAST, FTR_IKU_BUGZAPPER_NORTH, FTR_IKU_BUGZAPPER_WEST ,
FTR_YAZ_TELESCOPE_SOUTH, FTR_YAZ_TELESCOPE_EAST, FTR_YAZ_TELESCOPE_NORTH, FTR_YAZ_TELESCOPE_WEST ,
FTR_IKU_COCOA_SOUTH, FTR_IKU_COCOA_EAST, FTR_IKU_COCOA_NORTH, FTR_IKU_COCOA_WEST ,
FTR_YAZ_B_BATH_SOUTH, FTR_YAZ_B_BATH_EAST, FTR_YAZ_B_BATH_NORTH, FTR_YAZ_B_BATH_WEST ,
FTR_SUGI_BARBECUE_SOUTH, FTR_SUGI_BARBECUE_EAST, FTR_SUGI_BARBECUE_NORTH, FTR_SUGI_BARBECUE_WEST ,
FTR_SUGI_RADIATORL_SOUTH, FTR_SUGI_RADIATORL_EAST, FTR_SUGI_RADIATORL_NORTH, FTR_SUGI_RADIATORL_WEST ,
FTR_SUGI_ALCHAIR_SOUTH, FTR_SUGI_ALCHAIR_EAST, FTR_SUGI_ALCHAIR_NORTH, FTR_SUGI_ALCHAIR_WEST ,
FTR_SUGI_CHESSTABLE_SOUTH, FTR_SUGI_CHESSTABLE_EAST, FTR_SUGI_CHESSTABLE_NORTH, FTR_SUGI_CHESSTABLE_WEST ,
FTR_IKU_CANDY_SOUTH, FTR_IKU_CANDY_EAST, FTR_IKU_CANDY_NORTH, FTR_IKU_CANDY_WEST ,
FTR_SUGI_KPOOL_SOUTH, FTR_SUGI_KPOOL_EAST, FTR_SUGI_KPOOL_NORTH, FTR_SUGI_KPOOL_WEST ,
FTR_IKU_CEMENT_SOUTH, FTR_IKU_CEMENT_EAST, FTR_IKU_CEMENT_NORTH, FTR_IKU_CEMENT_WEST ,
FTR_IKU_JACK_SOUTH, FTR_IKU_JACK_EAST, FTR_IKU_JACK_NORTH, FTR_IKU_JACK_WEST ,
FTR_SUGI_TORCH_SOUTH, FTR_SUGI_TORCH_EAST, FTR_SUGI_TORCH_NORTH, FTR_SUGI_TORCH_WEST ,
FTR_YAZ_B_HOUSE_SOUTH, FTR_YAZ_B_HOUSE_EAST, FTR_YAZ_B_HOUSE_NORTH, FTR_YAZ_B_HOUSE_WEST ,
FTR_YOS_PBSTOVE_SOUTH, FTR_YOS_PBSTOVE_EAST, FTR_YOS_PBSTOVE_NORTH, FTR_YOS_PBSTOVE_WEST ,
FTR_IKU_BUSSTOP_SOUTH, FTR_IKU_BUSSTOP_EAST, FTR_IKU_BUSSTOP_NORTH, FTR_IKU_BUSSTOP_WEST ,
FTR_TAK_HAM1_SOUTH, FTR_TAK_HAM1_EAST, FTR_TAK_HAM1_NORTH, FTR_TAK_HAM1_WEST ,
FTR_IKU_FLIP_TOP_SOUTH, FTR_IKU_FLIP_TOP_EAST, FTR_IKU_FLIP_TOP_NORTH, FTR_IKU_FLIP_TOP_WEST ,
FTR_YOS_KFLAG_SOUTH, FTR_YOS_KFLAG_EAST, FTR_YOS_KFLAG_NORTH, FTR_YOS_KFLAG_WEST ,
FTR_TAK_NES01_SOUTH, FTR_TAK_NES01_EAST, FTR_TAK_NES01_NORTH, FTR_TAK_NES01_WEST ,
FTR_YOS_B_FEEDER_SOUTH, FTR_YOS_B_FEEDER_EAST, FTR_YOS_B_FEEDER_NORTH, FTR_YOS_B_FEEDER_WEST ,
FTR_IKU_CHAIR_SOUTH, FTR_IKU_CHAIR_EAST, FTR_IKU_CHAIR_NORTH, FTR_IKU_CHAIR_WEST ,
FTR_IKU_ROLLER_SOUTH, FTR_IKU_ROLLER_EAST, FTR_IKU_ROLLER_NORTH, FTR_IKU_ROLLER_WEST ,
FTR_YOS_FLAMINGO_SOUTH, FTR_YOS_FLAMINGO_EAST, FTR_YOS_FLAMINGO_NORTH, FTR_YOS_FLAMINGO_WEST ,
FTR_YOS_MAILBOX_SOUTH, FTR_YOS_MAILBOX_EAST, FTR_YOS_MAILBOX_NORTH, FTR_YOS_MAILBOX_WEST ,
FTR_YAZ_CANDLE_SOUTH, FTR_YAZ_CANDLE_EAST, FTR_YAZ_CANDLE_NORTH, FTR_YAZ_CANDLE_WEST ,
FTR_IKU_HAM_SOUTH, FTR_IKU_HAM_EAST, FTR_IKU_HAM_NORTH, FTR_IKU_HAM_WEST ,
FTR_YOS_GNOME_SOUTH, FTR_YOS_GNOME_EAST, FTR_YOS_GNOME_NORTH, FTR_YOS_GNOME_WEST ,
FTR_YOS_FLAMINGO2_SOUTH, FTR_YOS_FLAMINGO2_EAST, FTR_YOS_FLAMINGO2_NORTH, FTR_YOS_FLAMINGO2_WEST ,
FTR_IKU_GOLD_GREEN_SOUTH, FTR_IKU_GOLD_GREEN_EAST, FTR_IKU_GOLD_GREEN_NORTH, FTR_IKU_GOLD_GREEN_WEST ,
FTR_IKU_GOLD_RED_SOUTH, FTR_IKU_GOLD_RED_EAST, FTR_IKU_GOLD_RED_NORTH, FTR_IKU_GOLD_RED_WEST ,
FTR_IKU_TUMBLE_SOUTH, FTR_IKU_TUMBLE_EAST, FTR_IKU_TUMBLE_NORTH, FTR_IKU_TUMBLE_WEST ,
FTR_IKU_COW_SOUTH, FTR_IKU_COW_EAST, FTR_IKU_COW_NORTH, FTR_IKU_COW_WEST ,
FTR_IKU_ORANGE_SOUTH, FTR_IKU_ORANGE_EAST, FTR_IKU_ORANGE_NORTH, FTR_IKU_ORANGE_WEST ,
FTR_IKU_SAKU_A_SOUTH, FTR_IKU_SAKU_A_EAST, FTR_IKU_SAKU_A_NORTH, FTR_IKU_SAKU_A_WEST ,
FTR_IKU_SAKU_B_SOUTH, FTR_IKU_SAKU_B_EAST, FTR_IKU_SAKU_B_NORTH, FTR_IKU_SAKU_B_WEST ,
FTR_YAZ_TUB_SOUTH, FTR_YAZ_TUB_EAST, FTR_YAZ_TUB_NORTH, FTR_YAZ_TUB_WEST ,
FTR_YOS_LUIGI_SOUTH, FTR_YOS_LUIGI_EAST, FTR_YOS_LUIGI_NORTH, FTR_YOS_LUIGI_WEST ,
FTR_YOS_MARIO_SOUTH, FTR_YOS_MARIO_EAST, FTR_YOS_MARIO_NORTH, FTR_YOS_MARIO_WEST ,
FTR_IKU_TURKEY_LAMP_SOUTH, FTR_IKU_TURKEY_LAMP_EAST, FTR_IKU_TURKEY_LAMP_NORTH, FTR_IKU_TURKEY_LAMP_WEST ,
FTR_YAZ_WAGON_SOUTH, FTR_YAZ_WAGON_EAST, FTR_YAZ_WAGON_NORTH, FTR_YAZ_WAGON_WEST ,
FTR_YOS_TERRACE_SOUTH, FTR_YOS_TERRACE_EAST, FTR_YOS_TERRACE_NORTH, FTR_YOS_TERRACE_WEST ,
FTR_HOS_PIKNIC_SOUTH, FTR_HOS_PIKNIC_EAST, FTR_HOS_PIKNIC_NORTH, FTR_HOS_PIKNIC_WEST ,
FTR_IKU_TURKEY_TABLE_SOUTH, FTR_IKU_TURKEY_TABLE_EAST, FTR_IKU_TURKEY_TABLE_NORTH, FTR_IKU_TURKEY_TABLE_WEST ,
FTR_IKU_TURKEY_TV_SOUTH, FTR_IKU_TURKEY_TV_EAST, FTR_IKU_TURKEY_TV_NORTH, FTR_IKU_TURKEY_TV_WEST ,
FTR_IKU_TURKEY_BED_SOUTH, FTR_IKU_TURKEY_BED_EAST, FTR_IKU_TURKEY_BED_NORTH, FTR_IKU_TURKEY_BED_WEST ,
FTR_YAZ_TURKEY_CHAIR_SOUTH, FTR_YAZ_TURKEY_CHAIR_EAST, FTR_YAZ_TURKEY_CHAIR_NORTH, FTR_YAZ_TURKEY_CHAIR_WEST ,
FTR_YOS_TURKEY_WATCH_SOUTH, FTR_YOS_TURKEY_WATCH_EAST, FTR_YOS_TURKEY_WATCH_NORTH, FTR_YOS_TURKEY_WATCH_WEST ,
FTR_HOS_TURKEY_SOFA_SOUTH, FTR_HOS_TURKEY_SOFA_EAST, FTR_HOS_TURKEY_SOFA_NORTH, FTR_HOS_TURKEY_SOFA_WEST ,
FTR_IKU_MARIO_DOKAN_SOUTH, FTR_IKU_MARIO_DOKAN_EAST, FTR_IKU_MARIO_DOKAN_NORTH, FTR_IKU_MARIO_DOKAN_WEST ,
FTR_IKU_MARIO_RENGA_SOUTH, FTR_IKU_MARIO_RENGA_EAST, FTR_IKU_MARIO_RENGA_NORTH, FTR_IKU_MARIO_RENGA_WEST ,
FTR_YAZ_TURKEY_CLOSET_SOUTH, FTR_YAZ_TURKEY_CLOSET_EAST, FTR_YAZ_TURKEY_CLOSET_NORTH, FTR_YAZ_TURKEY_CLOSET_WEST ,
FTR_HOS_MARIO_HATA_SOUTH, FTR_HOS_MARIO_HATA_EAST, FTR_HOS_MARIO_HATA_NORTH, FTR_HOS_MARIO_HATA_WEST ,
FTR_YAZ_TURKEY_CHEST_SOUTH, FTR_YAZ_TURKEY_CHEST_EAST, FTR_YAZ_TURKEY_CHEST_NORTH, FTR_YAZ_TURKEY_CHEST_WEST ,
FTR_HOS_MARIO_KINOKO_SOUTH, FTR_HOS_MARIO_KINOKO_EAST, FTR_HOS_MARIO_KINOKO_NORTH, FTR_HOS_MARIO_KINOKO_WEST ,
FTR_YOS_TURKEY_MIRROR_SOUTH, FTR_YOS_TURKEY_MIRROR_EAST, FTR_YOS_TURKEY_MIRROR_NORTH, FTR_YOS_TURKEY_MIRROR_WEST ,
FTR_IKU_MARIO_COIN_SOUTH, FTR_IKU_MARIO_COIN_EAST, FTR_IKU_MARIO_COIN_NORTH, FTR_IKU_MARIO_COIN_WEST ,
FTR_IKU_MARIO_HATENA_SOUTH, FTR_IKU_MARIO_HATENA_EAST, FTR_IKU_MARIO_HATENA_NORTH, FTR_IKU_MARIO_HATENA_WEST ,
FTR_IKU_MARIO_STAR_SOUTH, FTR_IKU_MARIO_STAR_EAST, FTR_IKU_MARIO_STAR_NORTH, FTR_IKU_MARIO_STAR_WEST ,
FTR_IKU_MARIO_KOURA_SOUTH, FTR_IKU_MARIO_KOURA_EAST, FTR_IKU_MARIO_KOURA_NORTH, FTR_IKU_MARIO_KOURA_WEST ,
FTR_IKU_MARIO_TAIHOU_SOUTH, FTR_IKU_MARIO_TAIHOU_EAST, FTR_IKU_MARIO_TAIHOU_NORTH, FTR_IKU_MARIO_TAIHOU_WEST ,
FTR_YOS_CACTUS_SOUTH, FTR_YOS_CACTUS_EAST, FTR_YOS_CACTUS_NORTH, FTR_YOS_CACTUS_WEST ,
FTR_YAZ_MARIO_FLOWER_SOUTH, FTR_YAZ_MARIO_FLOWER_EAST, FTR_YAZ_MARIO_FLOWER_NORTH, FTR_YAZ_MARIO_FLOWER_WEST ,
FTR_YOS_WHEEL_SOUTH, FTR_YOS_WHEEL_EAST, FTR_YOS_WHEEL_NORTH, FTR_YOS_WHEEL_WEST ,
FTR_IKU_IDO_SOUTH, FTR_IKU_IDO_EAST, FTR_IKU_IDO_NORTH, FTR_IKU_IDO_WEST ,
FTR_IKE_PRORES_FENSE01_SOUTH, FTR_IKE_PRORES_FENSE01_EAST, FTR_IKE_PRORES_FENSE01_NORTH, FTR_IKE_PRORES_FENSE01_WEST ,
FTR_IKE_PRORES_LING01_SOUTH, FTR_IKE_PRORES_LING01_EAST, FTR_IKE_PRORES_LING01_NORTH, FTR_IKE_PRORES_LING01_WEST ,
FTR_IKE_PRORES_LING02_SOUTH, FTR_IKE_PRORES_LING02_EAST, FTR_IKE_PRORES_LING02_NORTH, FTR_IKE_PRORES_LING02_WEST ,
FTR_IKE_PRORES_LING03_SOUTH, FTR_IKE_PRORES_LING03_EAST, FTR_IKE_PRORES_LING03_NORTH, FTR_IKE_PRORES_LING03_WEST ,
FTR_IKE_PRORES_MAT01_SOUTH, FTR_IKE_PRORES_MAT01_EAST, FTR_IKE_PRORES_MAT01_NORTH, FTR_IKE_PRORES_MAT01_WEST ,
FTR_IKE_PRORES_TABLE01_SOUTH, FTR_IKE_PRORES_TABLE01_EAST, FTR_IKE_PRORES_TABLE01_NORTH, FTR_IKE_PRORES_TABLE01_WEST ,
FTR_IKE_PRORES_PUNCH01_SOUTH, FTR_IKE_PRORES_PUNCH01_EAST, FTR_IKE_PRORES_PUNCH01_NORTH, FTR_IKE_PRORES_PUNCH01_WEST ,
FTR_IKE_PRORES_SANDBAG01_SOUTH, FTR_IKE_PRORES_SANDBAG01_EAST, FTR_IKE_PRORES_SANDBAG01_NORTH, FTR_IKE_PRORES_SANDBAG01_WEST ,
FTR_IKE_PRORES_BENCH01_SOUTH, FTR_IKE_PRORES_BENCH01_EAST, FTR_IKE_PRORES_BENCH01_NORTH, FTR_IKE_PRORES_BENCH01_WEST ,
FTR_IKE_TENT_FIRE01_SOUTH, FTR_IKE_TENT_FIRE01_EAST, FTR_IKE_TENT_FIRE01_NORTH, FTR_IKE_TENT_FIRE01_WEST ,
FTR_IKE_TENT_FIRE02_SOUTH, FTR_IKE_TENT_FIRE02_EAST, FTR_IKE_TENT_FIRE02_NORTH, FTR_IKE_TENT_FIRE02_WEST ,
FTR_IKE_TENT_KAYAK01_SOUTH, FTR_IKE_TENT_KAYAK01_EAST, FTR_IKE_TENT_KAYAK01_NORTH, FTR_IKE_TENT_KAYAK01_WEST ,
FTR_NOG_SPRINKLER_SOUTH, FTR_NOG_SPRINKLER_EAST, FTR_NOG_SPRINKLER_NORTH, FTR_NOG_SPRINKLER_WEST ,
FTR_TAK_TENT_SOUTH, FTR_TAK_TENT_EAST, FTR_TAK_TENT_NORTH, FTR_TAK_TENT_WEST ,
FTR_IKE_TENT_KNAP01_SOUTH, FTR_IKE_TENT_KNAP01_EAST, FTR_IKE_TENT_KNAP01_NORTH, FTR_IKE_TENT_KNAP01_WEST ,
FTR_IKE_FISH_TRO2_SOUTH, FTR_IKE_FISH_TRO2_EAST, FTR_IKE_FISH_TRO2_NORTH, FTR_IKE_FISH_TRO2_WEST ,
FTR_NOG_FLOWER0_SOUTH, FTR_NOG_FLOWER0_EAST, FTR_NOG_FLOWER0_NORTH, FTR_NOG_FLOWER0_WEST ,
FTR_NOG_FLOWER1_SOUTH, FTR_NOG_FLOWER1_EAST, FTR_NOG_FLOWER1_NORTH, FTR_NOG_FLOWER1_WEST ,
FTR_NOG_FLOWER2_SOUTH, FTR_NOG_FLOWER2_EAST, FTR_NOG_FLOWER2_NORTH, FTR_NOG_FLOWER2_WEST ,
FTR_NOG_FLOWER3_SOUTH, FTR_NOG_FLOWER3_EAST, FTR_NOG_FLOWER3_NORTH, FTR_NOG_FLOWER3_WEST ,
FTR_NOG_FLOWER4_SOUTH, FTR_NOG_FLOWER4_EAST, FTR_NOG_FLOWER4_NORTH, FTR_NOG_FLOWER4_WEST ,
FTR_NOG_FLOWER5_SOUTH, FTR_NOG_FLOWER5_EAST, FTR_NOG_FLOWER5_NORTH, FTR_NOG_FLOWER5_WEST ,
FTR_NOG_FLOWER6_SOUTH, FTR_NOG_FLOWER6_EAST, FTR_NOG_FLOWER6_NORTH, FTR_NOG_FLOWER6_WEST ,
FTR_NOG_FLOWER7_SOUTH, FTR_NOG_FLOWER7_EAST, FTR_NOG_FLOWER7_NORTH, FTR_NOG_FLOWER7_WEST ,
FTR_NOG_FLOWER8_SOUTH, FTR_NOG_FLOWER8_EAST, FTR_NOG_FLOWER8_NORTH, FTR_NOG_FLOWER8_WEST ,
FTR_TAK_TENT_LAMP_SOUTH, FTR_TAK_TENT_LAMP_EAST, FTR_TAK_TENT_LAMP_NORTH, FTR_TAK_TENT_LAMP_WEST ,
FTR_NOG_LAWNMOWER_SOUTH, FTR_NOG_LAWNMOWER_EAST, FTR_NOG_LAWNMOWER_NORTH, FTR_NOG_LAWNMOWER_WEST ,
FTR_TAK_TENT_BOX_SOUTH, FTR_TAK_TENT_BOX_EAST, FTR_TAK_TENT_BOX_NORTH, FTR_TAK_TENT_BOX_WEST ,
FTR_IKE_TENT_BIKE01_SOUTH, FTR_IKE_TENT_BIKE01_EAST, FTR_IKE_TENT_BIKE01_NORTH, FTR_IKE_TENT_BIKE01_WEST ,
FTR_IKE_TENT_SLEEPBAG01_SOUTH, FTR_IKE_TENT_SLEEPBAG01_EAST, FTR_IKE_TENT_SLEEPBAG01_NORTH, FTR_IKE_TENT_SLEEPBAG01_WEST ,
FTR_NOG_BURNER_SOUTH, FTR_NOG_BURNER_EAST, FTR_NOG_BURNER_NORTH, FTR_NOG_BURNER_WEST ,
FTR_NOG_CORNUCOPIA_SOUTH, FTR_NOG_CORNUCOPIA_EAST, FTR_NOG_CORNUCOPIA_NORTH, FTR_NOG_CORNUCOPIA_WEST ,
FTR_NOG_GONG_SOUTH, FTR_NOG_GONG_EAST, FTR_NOG_GONG_NORTH, FTR_NOG_GONG_WEST ,
FTR_TAK_NOISE_SOUTH, FTR_TAK_NOISE_EAST, FTR_TAK_NOISE_NORTH, FTR_TAK_NOISE_WEST ,
FTR_TAK_STEW_SOUTH, FTR_TAK_STEW_EAST, FTR_TAK_STEW_NORTH, FTR_TAK_STEW_WEST ,
FTR_DUMMY_SOUTH, FTR_DUMMY_EAST, FTR_DUMMY_NORTH, FTR_DUMMY_WEST ,
FTR1_END
};
typedef struct npc_actor_s NPC_ACTOR;
enum {
mNpc_MOOD_0,
mNpc_MOOD_1,
mNpc_MOOD_2,
mNpc_MOOD_3,
mNpc_MOOD_4,
mNpc_MOOD_5,
mNpc_MOOD_6,
mNpc_MOOD_7,
mNpc_MOOD_8,
mNpc_MOOD_NUM
};
enum {
mNpc_LETTER_RANK_BAD,
mNpc_LETTER_RANK_OK,
mNpc_LETTER_RANK_NUM
};
enum {
mNpc_EVENT_MAIL_VT_DAY,
mNpc_EVENT_MAIL_WT_DAY,
mNpc_EVENT_MAIL_NUM
};
enum {
mNpc_EVENT_MAIL_BEST_FRIEND,
mNpc_EVENT_MAIL_OK_FRIEND,
mNpc_EVENT_MAIL_NOT_FRIEND,
mNpc_EVENT_MAIL_FRIEND_NUM
};
enum {
mNpc_GROW_STARTER,
mNpc_GROW_MOVE_IN,
mNpc_GROW_ISLANDER,
mNpc_GROW_NUM
};
enum {
mNpc_NAME_TYPE_SPNPC,
mNpc_NAME_TYPE_NPC,
mNpc_NAME_TYPE_NUM
};
enum {
mNpc_FEEL_NORMAL,
mNpc_FEEL_HAPPY,
mNpc_FEEL_ANGRY,
mNpc_FEEL_SAD,
mNpc_FEEL_SLEEPY,
mNpc_FEEL_PITFALL,
mNpc_FEEL_NUM,
mNpc_FEEL_6 = mNpc_FEEL_NUM,
mNpc_FEEL_UZAI_0,
mNpc_FEEL_UZAI_1,
mNpc_FEEL_ALL_NUM
};
enum {
mNpc_PATIENCE_MILDLY_ANNOYED,
mNpc_PATIENCE_ANNOYED,
mNpc_PATIENCE_NORMAL,
mNpc_PATIENCE_NUM
};
typedef struct animal_remail_s {
lbRTC_ymd_c date;
u8 name[8 ];
u8 land_name[8 ];
struct {
u8 cond : 1;
u8 looks : 7;
} flags;
} Anmremail_c;
typedef struct animal_player_maiL_s {
u8 font;
u8 paper_type;
mActor_name_t present;
u8 header_back_start;
u8 header[(32 - 8) ];
u8 body[192 ];
u8 footer[32 ];
u8 pad0;
lbRTC_ymd_c date;
} Anmplmail_c;
typedef struct animal_home_s {
u8 type_unused;
u8 block_x;
u8 block_z;
u8 ut_x;
u8 ut_z;
} Anmhome_c;
typedef struct animal_letter_info_s {
u8 exists : 1;
u8 cond : 1;
u8 send_reply : 1;
u8 has_present_cloth : 1;
u8 wearing_present_cloth : 1;
u8 bit5_7 : 3;
} Anmlet_c;
typedef struct animal_land_mem_s {
u8 name[8 ];
u16 id;
} Anmlnd_c;
typedef struct island_animal_best_ftr_s {
u32 check;
u16 have_bitfield;
} Anm_bestFtr_c;
typedef union {
Anmlnd_c land;
Anm_bestFtr_c island;
} memuni_u;
typedef struct animal_memory_s {
PersonalID_c memory_player_id;
lbRTC_time_c last_speak_time;
memuni_u memuni;
u64 saved_town_tune;
s8 friendship;
Anmlet_c letter_info;
Anmplmail_c letter;
} Anmmem_c;
typedef union {
u8 previous_land_name[8 ];
mActor_name_t island_ftr[4 ];
} anmuni_u;
typedef struct animal_password_mail_s {
lbRTC_time_c receive_time;
u8 password[20];
} AnmHPMail_c;
typedef struct animal_s {
AnmPersonalID_c id;
Anmmem_c memories[7 ];
Anmhome_c home_info;
u8 catchphrase[10 ];
mQst_contest_c contest_quest;
u8
parent_name[8 ];
anmuni_u anmuni;
u16 previous_land_id;
u8 mood;
u8 mood_time;
mActor_name_t cloth;
u16 remove_info;
u8 is_home;
u8
moved_in;
u8 removing;
u8
cloth_original_id;
u8 umbrella_id;
u8 unk_8ED;
mActor_name_t
present_cloth;
u8 animal_relations[15 ];
AnmHPMail_c hp_mail[4 ];
u8 unused[24];
} Animal_c;
typedef struct animal_return_s {
mActor_name_t npc_id;
u8 talk_bit;
u8 exist;
lbRTC_time_c renew_time;
} Anmret_c;
typedef struct demo_npc_s {
mActor_name_t npc_name;
u32 block_x, block_z;
u32 ut_x, ut_z;
} mNpc_demo_npc_c;
typedef struct {
u8 type;
u8 palette;
u8 wall_id;
u8 floor_id;
mActor_name_t main_layer_id;
mActor_name_t secondary_layer_id;
} mNpc_NpcHouseData_c;
typedef struct npc_conversation_s {
u8 beesting : 1;
u8 fish_complete : 1;
u8 insect_complete : 1;
u8 unk : 5;
} mNpc_NpcConversation_c;
typedef struct npc_list_s {
mActor_name_t name;
mActor_name_t field_name;
xyz_t house_position;
xyz_t position;
u8 appear_flag;
mNpc_NpcConversation_c conversation_flags;
mQst_base_c quest_info;
mNpc_NpcHouseData_c house_data;
mActor_name_t reward_furniture;
} mNpc_NpcList_c;
typedef struct event_npc_s {
mActor_name_t event_id;
mActor_name_t texture_id;
mActor_name_t npc_id;
mActor_name_t cloth_id;
u8 exists;
u8 in_use;
u16 _A;
} mNpc_EventNpc_c;
typedef struct mask_npc_s {
mActor_name_t mask_id;
mActor_name_t npc_id;
mActor_name_t cloth_id;
u8 exists;
u8 in_use;
Animal_c animal_data;
} mNpc_MaskNpc_c;
typedef struct npc_default_data_s {
mActor_name_t cloth;
u16 catchphrase_str_idx;
s8 umbrella;
} mNpc_Default_Data_c;
extern void mNpc_AddNowNpcMax(u8* npc_max);
extern void mNpc_SubNowNpcMax(u8* npc_max);
extern void mNpc_ClearAnimalPersonalID(AnmPersonalID_c* pid);
extern int mNpc_CheckFreeAnimalPersonalID(AnmPersonalID_c* pid);
extern void mNpc_CopyAnimalPersonalID(AnmPersonalID_c* dst, AnmPersonalID_c* src);
extern int mNpc_CheckCmpAnimalPersonalID(AnmPersonalID_c* pid0, AnmPersonalID_c* pid1);
extern int mNpc_GetAnimalNum();
extern int mNpc_CheckRemoveExp(Animal_c* animal);
extern int mNpc_GetRemoveTime(Animal_c* animal);
extern void mNpc_AddRemoveTime(Animal_c* animal);
extern void mNpc_SetRemoveExp(Animal_c* animal, u16 remove_exp);
extern void mNpc_SetRemoveExp(Animal_c* animal, u16 remove_exp);
extern void mNpc_SetParentName(Animal_c* animal, PersonalID_c* parent_id);
extern void mNpc_SetParentNameAllAnimal();
extern void mNpc_ClearAnimalMail(Anmplmail_c* mail);
extern void mNpc_CopyAnimalMail(Anmplmail_c* dst, Anmplmail_c* src);
extern void mNpc_ClearAnimalMemory(Anmmem_c* memory, int num);
extern void mNpc_ClearIslandAnimalMemory(Anmmem_c* memory, int num);
extern void mNpc_CopyAnimalMemory(Anmmem_c* dst, Anmmem_c* src);
extern void mNpc_AddFriendship(Anmmem_c* memory, int amount);
extern int mNpc_CheckFreeAnimalMemory(Anmmem_c* memory);
extern void mNpc_RenewalAnimalMemory();
extern int mNpc_GetOldAnimalMemoryIdx(Anmmem_c* memory, int num);
extern int mNpc_GetFreeAnimalMemoryIdx(Anmmem_c* memory, int num);
extern int mNpc_GetOldPlayerAnimalMemoryIdx(Anmmem_c* memory, int num);
extern int mNpc_ForceGetFreeAnimalMemoryIdx(Animal_c* animal, Anmmem_c* memory, int num);
extern void mNpc_SetAnimalMemory(PersonalID_c* pid, AnmPersonalID_c* anm_id, Anmmem_c* memory);
extern int mNpc_GetAnimalMemoryIdx(PersonalID_c* pid, Anmmem_c* memory, int num);
extern void mNpc_SetAnimalLastTalk(Animal_c* animal);
extern void mNpc_SetAnimalPersonalID2Memory(AnmPersonalID_c* anm_id);
extern int mNpc_GetHighestFriendshipIdx(Anmmem_c* memory, int num);
extern int mNpc_GetAnimalMemoryBestFriend(Anmmem_c* memory, int num);
extern int mNpc_GetAnimalMemoryNum(Anmmem_c* memory, int count);
extern int mNpc_GetAnimalMemoryLetterNum(Anmmem_c* memory, int count);
extern int mNpc_GetAnimalMemoryLandKindNum(Anmmem_c* memory, int count);
extern void mNpc_ClearAnimalInfo(Animal_c* animal);
extern void mNpc_ClearIslandAnimalInfo(Animal_c* animal);
extern void mNpc_ClearAnyAnimalInfo(Animal_c* animal, int count);
extern int mNpc_CheckFreeAnimalInfo(Animal_c* animal);
extern int mNpc_GetFreeAnimalInfo(Animal_c* animal, int count);
extern int mNpc_UseFreeAnimalInfo(Animal_c* animal, int count);
extern void mNpc_CopyAnimalInfo(Animal_c* dst, Animal_c* src);
extern int mNpc_SearchAnimalinfo(Animal_c* animal, mActor_name_t npc_id, int count);
extern Animal_c* mNpc_GetAnimalInfoP(mActor_name_t npc_id);
extern int mNpc_SearchAnimalPersonalID(AnmPersonalID_c* anm_pid);
extern AnmPersonalID_c* mNpc_GetOtherAnimalPersonalIDOtherBlock(AnmPersonalID_c* exclude_pids, int count, int bx,
int bz, int check_flag);
extern AnmPersonalID_c* mNpc_GetOtherAnimalPersonalID(AnmPersonalID_c* pids, int count);
extern void mNpc_SetAnimalThisLand(Animal_c* animal, int count);
extern int mNpc_GetSameLooksNum(u8 looks);
extern int mNpc_CheckNpcExistBlock(int idx, int check_bx, int check_bz);
extern void mNpc_Mail2AnimalMail(Anmplmail_c* animal_mail, Mail_c* mail);
extern void mNpc_AnimalMail2Mail(Mail_c* mail, Anmplmail_c* animal_mail, PersonalID_c* pid, AnmPersonalID_c* anm_id);
extern int mNpc_CheckNormalMail_sub(int* char_num, u8* body);
extern u8 mNpc_CheckNormalMail_length(int* len, u8* body);
extern u8 mNpc_CheckNormalMail_nes(u8* body);
extern int mNpc_SendMailtoNpc(Mail_c* mail);
extern void mNpc_ClearRemail(Anmremail_c* remail);
extern void mNpc_Remail();
extern u8 mNpc_GetPaperType();
extern int mNpc_SendVtdayMail();
extern int mNpc_CheckFriendship(PersonalID_c* pid, Animal_c* animal);
extern int mNpc_SendEventBirthdayCard(PersonalID_c* pid);
extern int mNpc_SendEventBirthdayCard2(PersonalID_c* pid, int player_no);
extern int mNpc_SendEventXmasCard(PersonalID_c* pid, int player_no);
extern int mNpc_GetPresentClothMemoryIdx(Anmmem_c* memory);
extern int mNpc_GetPresentClothMemoryIdx_rnd(Anmmem_c* memory);
extern int mNpc_CheckTalkPresentCloth(Animal_c* animal);
extern void mNpc_ChangePresentCloth();
extern u8* mNpc_GetWordEnding(ACTOR* actor);
extern void mNpc_ResetWordEnding(NPC_ACTOR* nactorx);
extern int mNpc_GetFreeEventNpcIdx();
extern int mNpc_RegistEventNpc(mActor_name_t event_id, mActor_name_t texture_id, mActor_name_t npc_id,
mActor_name_t cloth_id);
extern void mNpc_UnRegistEventNpc(mNpc_EventNpc_c* npc);
extern void mNpc_ClearEventNpc();
extern mNpc_EventNpc_c* mNpc_GetSameEventNpc(mActor_name_t event_id);
extern int mNpc_GetFreeMaskNpcIdx();
extern int mNpc_RegistMaskNpc(mActor_name_t mask_id, mActor_name_t npc_id, mActor_name_t cloth_id);
extern void mNpc_UnRegistMaskNpc(mNpc_MaskNpc_c* npc);
extern void mNpc_ClearMaskNpc();
extern mNpc_MaskNpc_c* mNpc_GetSameMaskNpc(mActor_name_t mask_id);
extern u8 mNpc_GetLooks(mActor_name_t npc_id);
extern void mNpc_SetDefAnimalCloth(Animal_c* animal);
extern void mNpc_SetDefAnimalUmbrella(Animal_c* animal);
extern void mNpc_SetDefAnimal(Animal_c* animal, mActor_name_t npc_id, mNpc_Default_Data_c* def_data);
extern void mNpc_SetAnimalTitleDemo(mNpc_demo_npc_c* demo_npc, Animal_c* animal, GAME* game);
extern int mNpc_GetReservedUtNum(int* ut_x, int* ut_z, mActor_name_t* item);
extern int mNpc_BlockNum2ReservedUtNum(int* ut_x, int* ut_z, int bx, int bz);
extern void mNpc_MakeReservedListBeforeFieldct(Anmhome_c* reserved, int reserved_num, u8* reserved_count);
extern void mNpc_MakeReservedListAfterFieldct(Anmhome_c* reserved, int reserved_num, u8* reserved_count, u8 bx_max,
u8 bz_max);
extern void mNpc_InitNpcData();
extern void mNpc_InitNpcList(mNpc_NpcList_c* npclist, int count);
extern void mNpc_SetNpcList(mNpc_NpcList_c* npclist, Animal_c* animal, int count, int malloc_flag);
extern void mNpc_SetNpcinfo(ACTOR* actor, s8 npc_info_idx);
extern void mNpc_AddNpc_inBlock(mFM_move_actor_c* move_actor_list, u8 bx, u8 bz);
extern void mNpc_RenewalNpcRoom(s16* wall_floor);
extern void mNpc_RenewalSetNpc(ACTOR* actor);
extern int mNpc_GetFriendAnimalNum(PersonalID_c* pid);
extern int mNpc_CheckFriendAllAnimal(PersonalID_c* pid);
extern void mNpc_SetNpcFurnitureRandom(mFM_fg_data_c** fg_data_table, int fg_base_id);
extern mActor_name_t mNpc_GetNpcFurniture(AnmPersonalID_c* anm_id);
extern void mNpc_ClearInAnimal();
extern Animal_c* mNpc_GetInAnimalP();
extern void mNpc_SetRemoveAnimalNo(u8* remove_animal_no, Animal_c* animal, int ignored_idx);
extern int mNpc_GetGoodbyAnimalIdx(int ignored_idx);
extern void mNpc_FirstClearGoodbyMail();
extern void mNpc_SendRegisteredGoodbyMail();
extern void mNpc_GetRemoveAnimal(Animal_c* transferring_animal, int moving_out);
extern void mNpc_SetReturnAnimal(Animal_c* return_animal);
extern void mNpc_AddActor_inBlock(mFM_move_actor_c* move_actor_list, u8 bx, u8 bz);
extern void mNpc_LoadNpcNameString(u8* dst, u8 name_id);
extern void mNpc_GetNpcWorldNameTableNo(u8* dst, mActor_name_t npc_id);
extern void mNpc_ClearCacheName();
extern void mNpc_GetNpcWorldNameAnm(u8* dst, AnmPersonalID_c* anm_id);
extern void mNpc_GetActorWorldName(u8* dst, mActor_name_t npc_id);
extern u8* mNpc_GetNpcWorldNameP(mActor_name_t npc_id);
extern void mNpc_GetNpcWorldName(u8* dst, ACTOR* actor);
extern void mNpc_GetRandomAnimalName(u8* dst);
extern void mNpc_GetAnimalPlateName(u8* dst, xyz_t wpos);
extern int mNpc_GetNpcLooks(ACTOR* actor);
extern int mNpc_GetLooks2Sex(int looks);
extern int mNpc_GetAnimalSex(Animal_c* animal);
extern int mNpc_GetNpcSex(ACTOR* actor);
extern int mNpc_GetNpcSoundSpec(ACTOR* actor);
extern void mNpc_InitNpcAllInfo(int malloc_flag);
extern void mNpc_Grow();
extern void mNpc_ForceRemove();
extern int mNpc_DecideMaskNpc_summercamp(mActor_name_t* npc_id);
extern int mNpc_RegistMaskNpc_summercamp(mActor_name_t mask_id, mActor_name_t npc_id, mActor_name_t cloth_id);
extern int mNpc_CheckNpcSet_fgcol(mActor_name_t fg_item, u32 attribute);
extern int mNpc_CheckNpcSet(int bx, int bz, int ut_x, int ut_z);
extern int mNpc_GetMakeUtNuminBlock_hard_area(int* ut_x, int* ut_z, int bx, int bz, int restrict_area);
extern int mNpc_GetMakeUtNuminBlock_area(int* ut_x, int* ut_z, int bx, int bz, int restrict_area);
extern int mNpc_GetMakeUtNuminBlock(int* ut_x, int* ut_z, int bx, int bz);
extern int mNpc_GetMakeUtNuminBlock33(int* make_ut_x, int* make_ut_z, int ut_x, int ut_z, int bx, int bz);
extern int mNpc_GetMakeUtNuminBlock_hide_hard_area(int* ut_x, int* ut_z, int bx, int bz, int restrict_area);
extern void mNpc_ClearTalkInfo();
extern int mNpc_CheckOverImpatient(int animal_idx, int looks);
extern int mNpc_GetOverImpatient(int animal_idx, int looks);
extern int mNpc_CheckQuestRequest(int animal_idx);
extern void mNpc_SetQuestRequestOFF(int animal_idx, int looks);
extern void mNpc_TalkInfoMove();
extern void mNpc_TalkEndMove(int animal_idx, int feel);
extern int mNpc_GetNpcFloorNo();
extern int mNpc_GetNpcWallNo();
extern void mNpc_SetTalkBee();
extern u8 mNpc_GetFishCompleteTalk(mNpc_NpcList_c* npclist);
extern u8 mNpc_GetInsectCompleteTalk(mNpc_NpcList_c* npclist);
extern void mNpc_SetFishCompleteTalk(mNpc_NpcList_c* npclist);
extern void mNpc_SetInsectCompleteTalk(mNpc_NpcList_c* npclist);
extern void mNpc_SetNpcHomeYpos();
extern void mNpc_DecideIslandNpc(Animal_c* animal);
extern void mNpc_SetIslandRoomFtr(Animal_c* animal);
extern void mNpc_SetIslandGetFtr(mActor_name_t ftr);
extern void mNpc_SetIslandGetFtrtoRoom();
extern void mNpc_SetIslandGetLetter(int get);
extern int mNpc_GetIslandGetLetter();
extern void mNpc_SetIslandCheckFtrMsg(int set);
extern int mNpc_GetIslandCheckFtrMsg();
extern void mNpc_ClearIslandNpcRoomData();
extern void mNpc_IslandNpcRoomDataSet(mFM_fg_data_c** data_table, int base_idx);
extern mActor_name_t* mNpc_GetIslandRoomP(mActor_name_t npc_id);
extern void mNpc_GetIslandWallFloorIdx(int* wall, int* floor, mActor_name_t npc_id);
extern int mNpc_CheckIslandNpcRoomFtrItemNo_keep(mActor_name_t ftr);
extern void mNpc_ChangeIslandRoom(mActor_name_t* items);
extern int mNpc_CheckFtrIsIslandBestFtr(mActor_name_t ftr);
extern int mNpc_CheckFtrIsIslandNormalFtr(mActor_name_t ftr);
extern int mNpc_SetIslandFtr(PersonalID_c* pid, mActor_name_t ftr);
extern int mNpc_EraseIslandFtr(mActor_name_t ftr);
extern int mNpc_EraseIslandFtr_keep(mActor_name_t ftr);
extern void mNpc_ClearIslandPresentFtrInfo();
extern void mNpc_SetIslandPresentFtr();
extern void mNpc_RestoreIslandPresentFtr();
extern int mNpc_GetIslandRoomFtrNum();
extern int mNpc_CheckIslandPresentFtrIs();
extern mActor_name_t mNpc_GetIslandPresentFtr();
extern PersonalID_c* mNpc_GetIslandPresentFtrPersonalID();
extern mActor_name_t mNpc_GetRandomBestFtr();
extern Anmmem_c* mNpc_GetOtherBestFtr(PersonalID_c* pid, mActor_name_t* other_best_ftr, mActor_name_t exist_ftr);
extern mActor_name_t mNpc_GetPlayerBestFtr(PersonalID_c* pid, mActor_name_t exist_ftr);
extern mActor_name_t mNpc_GetPlayerFtr(PersonalID_c* pid);
extern int mNpc_CheckIslandAnimal(Animal_c* animal);
extern u32 mNpc_GetMDIdx(mActor_name_t npc_id);
extern u32 mNpc_GetIslandMDIdx();
extern void mNpc_ClearHPMail(AnmHPMail_c* hp_mail, int count);
extern void mNpc_AllClearHPMailPlayerIdx(int player_no);
extern int mNpc_ReceiveHPMail(Mail_c* mail);
extern void mNpc_SendHPMail();
extern void mNpc_PrintRemoveInfo(gfxprint_t* gfxprint);
extern void mNpc_set_addd_bit(int bit);
extern void mNpc_set_addd_edit_bit(int bit);
extern void mNpc_set_addd_edit_info(int mtype, int disp_add);
extern void mNpc_SetTalkAnimalIdx_fdebug(AnmPersonalID_c* anm_id);
extern void mNpc_PrintFriendship_fdebug(gfxprint_t* gfxprint);
enum {
mMmd_DISPLAY_CANNOT_DONATE,
mMmd_DISPLAY_CAN_DONATE,
mMmd_DISPLAY_ALREADY_DONATED,
mMmd_DISPLAY_NUM
};
enum {
mMmd_DONATOR_NONE,
mMmd_DONATOR_PLAYER1,
mMmd_DONATOR_PLAYER2,
mMmd_DONATOR_PLAYER3,
mMmd_DONATOR_PLAYER4,
mMmd_DONATOR_DELETED_PLAYER,
mMmd_DONATOR_NUM
};
enum {
mMmd_CATEGORY_FOSSIL,
mMmd_CATEGORY_ART,
mMmd_CATEGORY_INSECT,
mMmd_CATEGORY_FISH,
mMmd_CATEGORY_NUM
};
typedef struct museum_display_info_s {
u8 fossil_bit[13 ];
u8 art_bit[8 ];
u8 fish_bit[21 ];
u8 insect_bit[21 ];
} mMmd_info_c;
extern int mMmd_FossilInfo(int fossil_no);
extern int mMmd_ArtInfo(int art_no);
extern int mMmd_InsectInfo(int insect_no);
extern int mMmd_FishInfo(int fish_no);
extern void mMmd_SetFossil(int fossil_no);
extern void mMmd_SetArt(int art_no);
extern void mMmd_SetInsect(int insect_no);
extern void mMmd_SetFish(int fish_no);
extern int mMmd_GetDisplayInfo(mActor_name_t item);
extern int mMmd_RequestMuseumDisplay(mActor_name_t item);
extern void mMmd_MakeMuseumDisplayData();
extern void mMmd_DeletePresentedByPlayer(u8 player_no);
extern int mMmd_CountDisplayedFossil();
extern int mMmd_CountDisplayedArt();
extern int mMmd_CountDisplayedInsect();
extern int mMmd_CountDisplayedFish();
enum {
mMsm_FOSSIL_TYPE_SINGLE,
mMsm_FOSSIL_TYPE_MULTI,
mMsm_FOSSIL_TYPE_NUM
};
enum {
mMsm_REMAIL_KIND_CLEAR,
mMsm_REMAIL_KIND_CANNOT_DONATE,
mMsm_REMAIL_KIND_DONATED,
mMsm_REMAIL_KIND_ALREADY_DONATED,
mMsm_REMAIL_KIND_FOREIGNER,
mMsm_REMAIL_KIND_NUM,
};
typedef struct museum_remail_info_s {
u8 types[30 / 2];
mActor_name_t items[30 ];
} mMsm_remail_info_c;
typedef struct museum_record_s {
u8 contacted:1;
u8 remail_pending:1;
u8 send_info_mail:1;
u8 stored_fossil_num:5;
mMsm_remail_info_c remail_info;
} mMsm_record_c;
extern void mMsm_ClearRecord(mMsm_record_c* record);
extern void mMsm_GetMuseumMailName(Mail_nm_c* name);
extern void mMsm_SendInformationMail();
extern void mMsm_SendMuseumMail(Mail_c* mail);
extern int mMsm_GetDepositAbleNum(mActor_name_t* fg_items, mCoBG_Collision_u* col_data);
extern void mMsm_DepositItemBlock_cancel(mActor_name_t* fg_items, mActor_name_t deposit_item, mCoBG_Collision_u* col_data, u16* deposit, u16* cancel_ut, u8 valid_ut_count);
extern void mMsm_DepositItemBlock(mActor_name_t* fg_items, mActor_name_t item, int block_x, int block_z, u16* deposit, u8 valid_ut_count);
extern int mMsm_RecordDepositFossil(u8* record, mActor_name_t item, int block_x);
extern u8 mMsm_GetDepositBlockNum(u8 record);
extern void mMsm_DepositFossil(u8 deposit_record, int fossil_count, u16* cancel_ut, int send_order_info);
extern void mMsm_SetCompMail();
extern void mMsm_SendCompMail();
enum {
mNW_PALETTE0,
mNW_PALETTE1,
mNW_PALETTE2,
mNW_PALETTE3,
mNW_PALETTE4,
mNW_PALETTE5,
mNW_PALETTE6,
mNW_PALETTE7,
mNW_PALETTE8,
mNW_PALETTE9,
mNW_PALETTE10,
mNW_PALETTE11,
mNW_PALETTE12,
mNW_PALETTE13,
mNW_PALETTE14,
mNW_PALETTE15,
mNW_PALETTE_NUM
};
enum {
mNW_TYPE_MANEKIN,
mNW_TYPE_UMBRELLA,
mNW_TYPE_NUM
};
typedef struct original_texture_s {
u8 data[(32 * (32 / 2)) ];
} __attribute__((aligned(32))) mNW_original_tex_c;
typedef struct original_data_s {
u8 name[16 ];
u8 palette;
u8 flag_design_set;
mNW_original_tex_c design;
} mNW_original_design_c;
typedef struct needlework_s {
mNW_original_design_c original_design[(4 + 4) ];
} mNW_needlework_c;
extern void mNW_InitMyOriginal();
extern void mNW_InitOneMyOriginal(int player_no);
extern void mNW_InitNeedleworkData();
extern void mNW_AGB_to_GC_texture(u8* agb, u8* gc);
extern void mNW_GC_to_Agb_texture(u8* gc, u8* agb);
extern u16* mNW_PaletteIdx2Palette(int palette_idx);
extern void mNW_CopyOriginalTextureClass(mNW_original_design_c* dst, mNW_original_design_c* src) ;
extern void mNW_CopyOriginalTexture(void* dst, mNW_original_design_c* src);
extern void mNW_CopyOriginalPalette(void* dst, mNW_original_design_c* src);
extern void mNW_OverWriteOriginalTexture(mNW_original_design_c* dst, u8* src);
extern void mNW_OverWriteOriginalName(mNW_original_design_c* dst, u8* src);
extern void mNW_SwapOriginalData(mNW_original_design_c* org0, mNW_original_design_c* org1);
extern void mNW_InitOriginalData(mNW_original_design_c* design);
extern void mNW_InitPrivateOriginalData(int player_no);
typedef struct calendar_player_info_s {
u32 played_days[lbRTC_MONTHS_MAX];
u32 event_days[lbRTC_MONTHS_MAX];
u16 event_flags;
u8 edit;
u8 pad_63;
lbRTC_year_t year;
lbRTC_month_t month;
} mCD_player_calendar_c;
extern void mCD_calendar_clear(int player_no);
extern void mCD_calendar_check_delete(int player_no, lbRTC_year_t year, lbRTC_month_t month, lbRTC_day_t day);
extern void mCD_calendar_wellcome_on();
extern void mCD_calendar_event_on(lbRTC_year_t year, lbRTC_month_t month, lbRTC_day_t day, u8 event);
extern int mCD_calendar_event_check(lbRTC_year_t year, lbRTC_month_t month, lbRTC_day_t day, int player_no, u8 event);
enum {
mPr_PLAYER_0,
mPr_PLAYER_1,
mPr_PLAYER_2,
mPr_PLAYER_3,
mPr_FOREIGNER,
mPr_PLAYER_NUM
};
enum {
mPr_ITEM_COND_NORMAL,
mPr_ITEM_COND_PRESENT,
mPr_ITEM_COND_QUEST,
mPr_ITEM_COND_NUM
};
enum {
mPr_SEX_MALE,
mPr_SEX_FEMALE,
mPr_SEX_OTHER,
mPr_SEX_NUM = mPr_SEX_OTHER
};
enum {
mPr_FACE_TYPE0,
mPr_FACE_TYPE1,
mPr_FACE_TYPE2,
mPr_FACE_TYPE3,
mPr_FACE_TYPE4,
mPr_FACE_TYPE5,
mPr_FACE_TYPE6,
mPr_FACE_TYPE7,
mPr_FACE_TYPE_NUM
};
enum {
mPr_SUNBURN_RANK_MIN,
mPr_SUNBURN_RANK0 = mPr_SUNBURN_RANK_MIN,
mPr_SUNBURN_RANK1,
mPr_SUNBURN_RANK2,
mPr_SUNBURN_RANK3,
mPr_SUNBURN_RANK4,
mPr_SUNBURN_RANK5,
mPr_SUNBURN_RANK6,
mPr_SUNBURN_RANK7,
mPr_SUNBURN_RANK8,
mPr_SUNBURN_RANK_MAX = mPr_SUNBURN_RANK8,
mPr_SUNBURN_RANK_NUM
};
enum {
mPr_DESTINY_NORMAL,
mPr_DESTINY_POPULAR,
mPr_DESTINY_UNPOPULAR,
mPr_DESTINY_BAD_LUCK,
mPr_DESTINY_MONEY_LUCK,
mPr_DESTINY_GOODS_LUCK,
mPr_DESTINY_NUM
};
typedef struct player_destiny_s {
lbRTC_time_c received_time;
u8 type;
} mPr_destiny_c;
typedef struct player_birthday_s {
u16 year;
u8 month;
u8 day;
} mPr_birthday_c;
typedef struct player_catalog_order_s {
mActor_name_t item;
u8 shop_level;
} mPr_catalog_order_c;
typedef struct player_animal_memory_s {
mActor_name_t npc_id;
u8 land_name[8 ];
} mPr_animal_memory_c;
typedef struct player_map_s {
u8 land_name[8 ];
u16 land_id;
} mPr_map_info_c;
typedef struct player_day_day_s {
lbRTC_ymd_c last_date;
u8 days;
} mPr_day_day_c;
typedef struct player_sunburn_s {
lbRTC_ymd_c last_changed_date;
s8 rank;
s8 rankdown_days;
} mPr_sunburn_c;
typedef struct player_ecard_data_s {
lbRTC_ymd_c letter_send_date;
u8 card_letters_sent[((367 + 7) / 8) ];
} mPr_carde_data_c;
typedef struct private_mother_mail_data_s {
u8 normal[7 ];
u8 monthly[2 ];
u8 august;
} mPr_mother_mail_data_c;
typedef struct private_mother_mail_info_s {
lbRTC_ymd_c date;
mPr_mother_mail_data_c data;
} mPr_mother_mail_info_c;
struct private_s {
PersonalID_c player_ID;
s8 gender;
s8 face;
u8 reset_count;
mMsm_record_c museum_record;
struct {
mActor_name_t pockets[15 ];
u8 lotto_ticket_expiry_month;
u8 lotto_ticket_mail_storage;
u32 item_conditions;
u32 wallet;
u32 loan;
} inventory;
mQst_delivery_c deliveries[15 ];
mQst_errand_c errands[5 ];
mActor_name_t equipment;
Mail_hs_c saved_mail_header;
Mail_c mail[10 ];
mActor_name_t backgound_texture;
u8 exists;
u8 hint_count;
mPr_cloth_c cloth;
AnmPersonalID_c stored_anm_id;
mPr_destiny_c destiny;
mPr_birthday_c birthday;
mPr_catalog_order_c
catalog_orders[5 ];
u8 unk_10A8[24];
u32 aircheck_collect_bitfield[2];
Anmremail_c remail;
u32 reset_code;
mPr_animal_memory_c animal_memory;
u8
complete_fish_insect_flags;
lbRTC_year_t celebrated_birthday_year;
u32 furniture_collected_bitfield[43];
u32 wall_collected_bitfield[3];
u32 carpet_collected_bitfield[3];
u32 paper_collected_bitfield[2];
u32 music_collected_bitfield[2];
mPr_map_info_c maps[8 ];
u32 bank_account;
mNW_original_design_c my_org[8 ];
u8 my_org_no_table[8 ];
u32 state_flags;
mCD_player_calendar_c calendar;
u32 soncho_trophy_field0;
mPr_day_day_c nw_visitor;
mPr_day_day_c radiocard;
mPr_sunburn_c sunburn;
u8 unused_23CA[14];
mActor_name_t birthday_present_npc;
u8 golden_items_collected;
u32 soncho_trophy_field1;
mPr_carde_data_c ecard_letter_data;
u8 unused_2412[46];
};
extern void mPr_ClearPlayerName(u8* buf);
extern void mPr_CopyPlayerName(u8* dst, u8* src);
extern int mPr_NullCheckPlayerName(u8* name_p);
extern int mPr_CheckCmpPlayerName(u8* name0, u8* name1);
extern int mPr_GetPlayerName(u8* buf, int player_no);
extern int mPr_NullCheckPersonalID(PersonalID_c* pid);
extern void mPr_ClearPersonalID(PersonalID_c* pid);
extern void mPr_ClearAnyPersonalID(PersonalID_c* pid, int count);
extern void mPr_CopyPersonalID(PersonalID_c* dst, PersonalID_c* src);
extern int mPr_CheckCmpPersonalID(PersonalID_c* pid0, PersonalID_c* pid1);
extern void mPr_ClearPrivateBirthday(mPr_birthday_c* birthday);
extern void mPr_ClearAnimalMemory(mPr_animal_memory_c* memory);
extern void mPr_ClearPrivateInfo(Private_c* private_info);
extern void mPr_SetNowPrivateCloth();
extern void mPr_InitPrivateInfo(Private_c* priv);
extern void mPr_CopyPrivateInfo(Private_c* dst, Private_c* src);
extern int mPr_CheckPrivate(Private_c* priv);
extern int mPr_CheckCmpPrivate(Private_c* priv0, Private_c* priv1);
extern int mPr_GetPrivateIdx(PersonalID_c* pid);
extern int mPr_GetPossessionItemIdx(Private_c* priv, mActor_name_t item);
extern int mPr_GetPossessionItemIdxWithCond(Private_c* priv, mActor_name_t item, u32 cond);
extern int mPr_GetPossessionItemIdxFGTypeWithCond_cancel(Private_c* priv, mActor_name_t fg_type, u32 cond,
mActor_name_t cancel_item);
extern int mPr_GetPossessionItemIdxItem1Category(Private_c* priv, u8 item1_type);
extern int mPr_GetPossessionItemIdxItem1CategoryWithCond_cancel(Private_c* priv, u8 item1_type, u32 cond,
mActor_name_t cancel_item);
extern int mPr_GetPossessionItemIdxKindWithCond(Private_c* priv, mActor_name_t kind_start, mActor_name_t kind_end,
u32 cond);
extern u32 mPr_GetPossessionItemSum(Private_c* priv, mActor_name_t item);
extern u32 mPr_GetPossessionItemSumWithCond(Private_c* priv, mActor_name_t item, u32 cond);
extern u32 mPr_GetPossessionItemSumFGTypeWithCond_cancel(Private_c* priv, mActor_name_t fg_type, u32 cond,
mActor_name_t cancel_item);
extern u32 mPr_GetPossessionItemSumItemCategoryWithCond_cancel(Private_c* priv, u8 item1_type, u32 cond,
mActor_name_t cancel_item);
extern u32 mPr_GetPossessionItemSumItemCategoryWithCond(Private_c* priv, u8 item1_type, u32 cond);
extern u32 mPr_GetPossessionItemSumKindWithCond(Private_c* priv, mActor_name_t kind_start, mActor_name_t kind_end,
u32 cond);
extern void mPr_SetItemCollectBit(mActor_name_t item);
extern mActor_name_t mPr_DummyPresentToTruePresent();
extern void mPr_SetPossessionItem(Private_c* priv, int idx, mActor_name_t item, u32 cond);
extern int mPr_SetFreePossessionItem(Private_c* priv, mActor_name_t item, u32 cond);
extern void mPr_AddFirstJobHint(Private_c* priv);
extern int mPr_GetFirstJobHintTime(Private_c* priv);
extern int mPr_CheckFirstJobHint(Private_c* priv);
extern s16 mPr_GetMoneyPower();
extern s16 mPr_GetGoodsPower();
extern int mPr_CheckMuseumAddress(Private_c* priv);
extern int mPr_CheckMuseumInfoMail(Private_c* priv);
extern Private_c* mPr_GetForeignerP();
extern int mPr_LoadPak_and_SetPrivateInfo2(Private_c* unused_private, u8 player_no);
extern void mPr_ClearMotherMailInfo(mPr_mother_mail_info_c* mother_mail);
extern void mPr_SendMailFromMother();
extern void mPr_SendForeingerAnimalMail(Private_c* priv);
extern void mPr_StartSetCompleteTalkInfo();
extern void mPr_SetFishCompleteTalk();
extern int mPr_CheckFishCompleteTalk(u8 player_no);
extern void mPr_SetInsectCompleteTalk();
extern int mPr_CheckInsectCompleteTalk(u8 player_no);
extern int mPr_GetFishCompTalkPermission();
extern int mPr_GetInsectCompTalkPermission();
extern void mPr_ClearMapInfo(mPr_map_info_c* map_info, int max);
extern int mPr_GetThisLandMapIdx(mPr_map_info_c* map_info, int max);
extern void mPr_SetNewMap(mPr_map_info_c* map_info, int max);
extern void mPr_RenewalMapInfo(mPr_map_info_c* map_info, int max, mLd_land_info_c* land_info);
extern void mPr_RandomSetPlayerData_title_demo();
extern void mPr_PrintMapInfo_debug(gfxprint_t* gfxprint);
extern Private_c g_foreigner_private;
typedef struct submenu_s Submenu;
enum {
mSM_MODE_IDLE,
mSM_MODE_PRERENDER_INIT,
mSM_MODE_PRERENDER_WAIT,
mSM_MODE_PRERENDER_DONE,
mSM_MODE_OTHER,
mSM_MODE_NUM
};
enum {
mSM_PROCESS_WAIT,
mSM_PROCESS_PREWAIT,
mSM_PROCESS_LINKWAIT,
mSM_PROCESS_PLAY,
mSM_PROCESS_END,
mSM_PROCESS_NUM
};
enum {
mSM_DLF_SUBMENU_OVL,
mSM_DLF_PLAYER_ACTOR,
mSM_DLF_NUM
};
enum {
mSM_MOVE_OUT_RIGHT,
mSM_MOVE_IN_RIGHT,
mSM_MOVE_OUT_LEFT,
mSM_MOVE_IN_LEFT,
mSM_MOVE_OUT_TOP,
mSM_MOVE_IN_TOP,
mSM_MOVE_OUT_BOTTOM,
mSM_MOVE_IN_BOTTOM,
mSM_MOVE_NUM
};
enum submenu_overlay {
mSM_OVL_NONE,
mSM_OVL_INVENTORY,
mSM_OVL_HBOARD,
mSM_OVL_TIMEIN,
mSM_OVL_LEDIT,
mSM_OVL_MAP,
mSM_OVL_NOTICE,
mSM_OVL_REPAY,
mSM_OVL_MSCORE,
mSM_OVL_BIRTHDAY,
mSM_OVL_EDITOR,
mSM_OVL_MAILBOX,
mSM_OVL_BOARD,
mSM_OVL_ADDRESS,
mSM_OVL_HANIWA,
mSM_OVL_EDITENDCHK,
mSM_OVL_WARNING,
mSM_OVL_CPMAIL,
mSM_OVL_CPWARNING,
mSM_OVL_CPEDIT,
mSM_OVL_CATALOG,
mSM_OVL_MUSIC,
mSM_OVL_BANK,
mSM_OVL_NEEDLEWORK,
mSM_OVL_CPORIGINAL,
mSM_OVL_DESIGN,
mSM_OVL_GBA,
mSM_OVL_DIARY,
mSM_OVL_CALENDAR,
mSM_OVL_PASSWORDMAKE,
mSM_OVL_PASSWORDCHK,
mSM_OVL_NUM
};
enum {
mSM_IV_OPEN_NORMAL,
mSM_IV_OPEN_MAILBOX,
mSM_IV_OPEN_HANIWA_ENTRUST,
mSM_IV_OPEN_HANIWA_TAKE,
mSM_IV_OPEN_QUEST,
mSM_IV_OPEN_SELL,
mSM_IV_OPEN_GIVE,
mSM_IV_OPEN_SEND_MAIL,
mSM_IV_OPEN_TAKE,
mSM_IV_OPEN_PUTIN_FTR,
mSM_IV_OPEN_MINIDISK,
mSM_IV_OPEN_SHRINE,
mSM_IV_OPEN_12,
mSM_IV_OPEN_EXCHANGE,
mSM_IV_OPEN_CPMAIL,
mSM_IV_OPEN_CURATOR,
mSM_IV_OPEN_PASSWORD,
mSM_IV_OPEN_NUM
};
enum {
mSM_IV_ITEM_NORMAL,
mSM_IV_ITEM_PUT_AWAY,
mSM_IV_ITEM_WAIT,
mSM_IV_ITEM_NUM
};
enum {
mSM_HANIWA_OPEN_ENTRUST,
mSM_HANIWA_OPEN_TAKE,
mSM_HANIWA_OPEN_NUM
};
enum {
mSM_BD_OPEN_WRITE,
mSM_BD_OPEN_READ,
mSM_BD_OPEN_REWRITE,
mSM_BD_OPEN_WRITE_ISLAND,
mSM_BD_OPEN_READ_ISLAND,
mSM_BD_OPEN_NUM
};
typedef struct submenu_item_s {
mActor_name_t item;
u8 slot_no;
} Submenu_Item_c;
typedef struct submenu_dlftbl {
void* _00;
int _04;
int _08;
int _0C;
int _10;
int _14;
const char* name;
} mSM_dlftbl_c;
typedef void (*SUBMENU_PROC)(Submenu*);
typedef void (*SUBMENU_GAME_PROC)(Submenu*, GAME*);
struct submenu_s {
int mode;
int menu_type;
int current_menu_type;
int process_status;
int param0;
int param1;
void* param2;
int param3;
int wait_timer;
char* overlay_address;
char* next_overlay_address;
Submenu_Overlay_c* overlay;
SUBMENU_PROC move_proc;
SUBMENU_GAME_PROC draw_proc;
Mail_c mail;
u8 open_flag;
u8 after_mode;
u8 unk_164;
u8 start_refuse;
u8 start_refuse_timer;
xyz_t water_pos;
Submenu_Item_c*
item_p;
s16 item_num;
s16 selected_item_num;
Submenu_Item_c
items[15 ];
};
extern int mSM_COLLECT_INSECT_GET(int idx);
extern void mSM_COLLECT_INSECT_SET(int idx);
extern int mSM_CHECK_ALL_INSECT_GET();
extern int mSM_CHECK_LAST_INSECT_GET(int idx);
extern int mSM_COLLECT_FISH_GET(int idx);
extern void mSM_COLLECT_FISH_SET(int idx);
extern int mSM_CHECK_ALL_FISH_GET();
extern int mSM_CHECK_LAST_FISH_GET(int idx);
extern int SubmenuArea_IsPlayer();
extern void* mSM_ovlptr_dllcnv(void* proc, Submenu* submenu, int dlf_idx);
extern void mSM_submenu_ovlptr_init(GAME_PLAY* play);
extern void mSM_submenu_ovlptr_cleanup(Submenu* submenu);
extern void load_player(Submenu* submenu);
extern void mSM_submenu_ct(Submenu* submenu);
extern void mSM_submenu_dt(Submenu* submenu);
extern void mSM_open_submenu(Submenu* submenu, int type, int arg0, int arg1);
extern void mSM_open_submenu_new(Submenu* submenu, int type, int arg0, int arg1, void* arg2);
extern void mSM_open_submenu_new2(Submenu* submenu, int type, int arg0, int arg1, void* arg2, int arg3);
extern void mSM_submenu_ctrl(GAME_PLAY* play);
extern void mSM_submenu_move(Submenu* submenu);
extern void mSM_submenu_draw(Submenu* submenu, GAME* game);
extern int mSM_check_open_inventory_itemlist(int type, int param_2);
extern void mSM_Object_Exchange_keep_new_Menu(GAME_PLAY* play);
extern u8* mSM_Get_ground_tex_p(GAME_PLAY* play);
extern u16* mSM_Get_ground_pallet_p(GAME_PLAY* play);
enum weather {
mEnv_WEATHER_CLEAR,
mEnv_WEATHER_RAIN,
mEnv_WEATHER_SNOW,
mEnv_WEATHER_SAKURA,
mEnv_WEATHER_LEAVES,
mEnv_WEATHER_NUM
};
enum weather_intensity {
mEnv_WEATHER_INTENSITY_NONE,
mEnv_WEATHER_INTENSITY_LIGHT,
mEnv_WEATHER_INTENSITY_NORMAL,
mEnv_WEATHER_INTENSITY_HEAVY,
mEnv_WEATHER_INTENSITY_NUM,
};
enum {
mEnv_LIGHT_TYPE_PLAYER,
mEnv_LIGHT_TYPE_TENT,
mEnv_LIGHT_TYPE_LIGHTHOUSE,
mEnv_LIGHT_TYPE_NUM
};
enum {
mEnv_SWITCH_STATUS_ON,
mEnv_SWITCH_STATUS_OFF,
mEnv_SWITCH_STATUS_TURNING_OFF,
mEnv_SWITCH_STATUS_TURNING_ON,
mEnv_SWITCH_STATUS_NUM
};
enum {
mEnv_WIND_STATE_STEADY,
mEnv_WIND_STATE_FAST,
mEnv_WIND_STATE_SLOW,
mEnv_WIND_STATE_REDUCING,
mEnv_WIND_STATE_NUM
};
typedef struct base_light_s {
u8 ambient_color[3];
s8 sun_dir[3];
u8 sun_color[3];
s8 moon_dir[3];
u8 moon_color[3];
u8 fog_color[3];
s16 fog_near;
s16 fog_far;
u8 shadow_color[3];
u8 room_color[3];
u8 sun_color_window[3];
u8 moon_color_window[3];
u8 background_color[3];
} BaseLight;
typedef struct add_light_info_s {
s16 ambient_color[3];
s16 diffuse_color[3];
s16 fog_color[3];
s16 fog_near;
s16 fog_far;
} AddLightInfo;
typedef void (*NATURE_PROC)(ACTOR*);
typedef struct nature_s {
NATURE_PROC proc;
void* arg;
} Nature;
typedef struct kankyo_s {
Lights sun_light;
Lights moon_light;
Lights* lamp_light;
Lights point_light;
int _30;
u8 _34[0x78 - 0x34];
AddLightInfo add_light_info;
int _90;
BaseLight base_light;
u8 _BA[0xC0 - 0xBA];
f32 shadow_pos;
u8 shadow_alpha;
u8 countdown_timer;
Nature nature;
} Kankyo;
extern void mEnv_regist_nature(Kankyo* kankyo, NATURE_PROC nature_proc, void* arg);
extern int mEnv_unregist_nature(Kankyo* kankyo, NATURE_PROC nature_proc);
extern void Global_kankyo_ct(GAME* game, Kankyo* kankyo);
extern void mEnv_GetRoomPrimColor(u8* r, u8* g, u8* b, GAME_PLAY* play);
extern void Global_kankyo_set_room_prim(GAME* game);
extern int mEnv_RequestChangeLightON(GAME_PLAY* play, int light_on_type, int play_sfx);
extern int mEnv_RequestChangeLightOFF(GAME_PLAY* play, int light_off_type, f32 step);
extern void mEnv_ManagePointLight(GAME_PLAY* play, Kankyo* kankyo, Global_light* global_light);
extern void Global_kankyo_set(GAME_PLAY* play, Kankyo* kankyo, Global_light* global_light);
extern void staffroll_light_init(GAME_PLAY* play);
extern void staffroll_light_proc_start(GAME_PLAY* play);
extern int staffroll_light_proc_end(GAME_PLAY* play);
extern void staffroll_light_dt(GAME_PLAY* play);
extern void mEnv_GetShadowPrimColor_Light(u8* r, u8* g, u8* b, GAME* game);
extern int mEnv_PointLightMin();
extern int mEnv_HereIsPlayerSelect();
extern f32 mKK_windowlight_alpha_get();
extern int mEnv_ReqeustChangeWeatherEnviroment(s16 now_weather, s16 next_weather);
extern int mEnv_ReservePointLight(GAME_PLAY* play, xyz_t* pos, u8 r, u8 g, u8 b, s16 power);
extern void mEnv_OperateReservedPointLight_Position(int point_light_idx, xyz_t* pos);
extern void mEnv_OperateReservedPointLight_Color(int point_light_idx, u8 r, u8 g, u8 b);
extern void mEnv_OperateReservedPointLight_Power(int point_light_idx, s16 power);
extern void mEnv_OperateReservedPointLight(int point_light_idx, xyz_t* pos, u8 r, u8 g, u8 b, s16 power);
extern int mEnv_CancelReservedPointLight(int point_light_idx, GAME_PLAY* play);
extern void mEnv_DecideWindDirect(s_xyz* dir, s16 x, s16 z);
extern void mEnv_RandomWeather(s16* next_weather, s16* next_intensity);
extern s16 mEnv_GetWindAngleS();
extern f32 mEnv_GetWindPowerF();
extern f32 mEnv_GetWindPowerF_Windmill();
extern void mEnv_DecideTodayWindPowerRange();
extern void mEnv_ChangeWind();
extern void mEnv_WindMove();
extern void mEnv_DecideWeather_GameStart();
extern void mEnv_DecideWeather_FirstGameStart();
extern void mEnv_PreRainNowFine_Init();
extern void mEnv_DecideWeather_NormalGameStart();
extern int mEnv_NowWeather();
typedef struct pause_t{
int enabled;
int timer;
} pause_t;
void Pause_ct(pause_t* pause);
int Pause_proc(pause_t* pause, pad_t* pad);
enum __bg_type__ {
BG_TYPE_GRD_S_HOLE_TEST,
BG_TYPE_GRD_S_C1_1,
BG_TYPE_GRD_S_C1_2,
BG_TYPE_GRD_S_C1_3,
BG_TYPE_GRD_S_C1_4,
BG_TYPE_GRD_S_C1_5,
BG_TYPE_GRD_S_C1_R1_1,
BG_TYPE_GRD_S_C1_R1_2,
BG_TYPE_GRD_S_C1_R1_3,
BG_TYPE_GRD_S_C1_R2_1,
BG_TYPE_GRD_S_C1_R2_2,
BG_TYPE_GRD_S_C1_R2_3,
BG_TYPE_GRD_S_C1_R3_1,
BG_TYPE_GRD_S_C1_R3_2,
BG_TYPE_GRD_S_C1_R3_3,
BG_TYPE_GRD_S_C1_S_1,
BG_TYPE_GRD_S_C1_S_2,
BG_TYPE_GRD_S_C1_S_3,
BG_TYPE_GRD_S_C1_S_4,
BG_TYPE_GRD_S_C2_1,
BG_TYPE_GRD_S_C2_2,
BG_TYPE_GRD_S_C2_3,
BG_TYPE_GRD_S_C2_R1_1,
BG_TYPE_GRD_S_C2_R1_2,
BG_TYPE_GRD_S_C2_R2_1,
BG_TYPE_GRD_S_C2_R2_2,
BG_TYPE_GRD_S_C2_S_1,
BG_TYPE_GRD_S_C2_S_2,
BG_TYPE_GRD_S_C2_S_3,
BG_TYPE_GRD_S_C3_1,
BG_TYPE_GRD_S_C3_2,
BG_TYPE_GRD_S_C3_3,
BG_TYPE_GRD_S_C3_R1_1,
BG_TYPE_GRD_S_C3_R1_2,
BG_TYPE_GRD_S_C3_R2_1,
BG_TYPE_GRD_S_C3_R2_2,
BG_TYPE_GRD_S_C3_S_1,
BG_TYPE_GRD_S_C4_1,
BG_TYPE_GRD_S_C4_2,
BG_TYPE_GRD_S_C4_3,
BG_TYPE_GRD_S_C4_R1_1,
BG_TYPE_GRD_S_C4_R1_2,
BG_TYPE_GRD_S_C4_R2_1,
BG_TYPE_GRD_S_C4_R2_2,
BG_TYPE_GRD_S_C4_R3_1,
BG_TYPE_GRD_S_C4_R3_2,
BG_TYPE_GRD_S_C4_S_1,
BG_TYPE_GRD_S_C4_S_2,
BG_TYPE_GRD_S_C5_1,
BG_TYPE_GRD_S_C5_2,
BG_TYPE_GRD_S_C5_3,
BG_TYPE_GRD_S_C5_R1_1,
BG_TYPE_GRD_S_C5_R1_2,
BG_TYPE_GRD_S_C5_R2_1,
BG_TYPE_GRD_S_C5_R2_2,
BG_TYPE_GRD_S_C5_R3_1,
BG_TYPE_GRD_S_C5_R3_2,
BG_TYPE_GRD_S_C5_S_1,
BG_TYPE_GRD_S_C5_S_2,
BG_TYPE_GRD_S_C6_1,
BG_TYPE_GRD_S_C6_2,
BG_TYPE_GRD_S_C6_3,
BG_TYPE_GRD_S_C6_R1_1,
BG_TYPE_GRD_S_C6_R1_2,
BG_TYPE_GRD_S_C6_R3_1,
BG_TYPE_GRD_S_C6_S_1,
BG_TYPE_GRD_S_C7_1,
BG_TYPE_GRD_S_C7_2,
BG_TYPE_GRD_S_C7_3,
BG_TYPE_GRD_S_C7_R1_1,
BG_TYPE_GRD_S_C7_R1_2,
BG_TYPE_GRD_S_C7_R3_1,
BG_TYPE_GRD_S_C7_R3_2,
BG_TYPE_GRD_S_C7_S_1,
BG_TYPE_GRD_S_C7_S_2,
BG_TYPE_GRD_S_C7_S_3,
BG_TYPE_GRD_S_E1_1,
BG_TYPE_GRD_S_E1_R1_1,
BG_TYPE_GRD_S_E2_1,
BG_TYPE_GRD_S_E2_C1_1,
BG_TYPE_GRD_S_E2_M_1,
BG_TYPE_GRD_S_E2_O_1,
BG_TYPE_GRD_S_E2_T_1,
BG_TYPE_GRD_S_E3_1,
BG_TYPE_GRD_S_E3_C1_1,
BG_TYPE_GRD_S_E3_M_1,
BG_TYPE_GRD_S_E3_O_1,
BG_TYPE_GRD_S_E3_T_1,
BG_TYPE_GRD_S_E4_1,
BG_TYPE_GRD_S_E5_1,
BG_TYPE_GRD_S_F_1,
BG_TYPE_GRD_S_F_2,
BG_TYPE_GRD_S_F_3,
BG_TYPE_GRD_S_F_4,
BG_TYPE_GRD_S_F_5,
BG_TYPE_GRD_S_F_6,
BG_TYPE_GRD_S_F_7,
BG_TYPE_GRD_S_F_8,
BG_TYPE_GRD_S_F_9,
BG_TYPE_GRD_S_F_10,
BG_TYPE_GRD_S_F_KO_1,
BG_TYPE_GRD_S_F_KO_2,
BG_TYPE_GRD_S_F_KO_3,
BG_TYPE_GRD_S_F_MH_1,
BG_TYPE_GRD_S_F_MH_2,
BG_TYPE_GRD_S_F_MH_3,
BG_TYPE_GRD_S_F_MU_1,
BG_TYPE_GRD_S_F_MU_2,
BG_TYPE_GRD_S_F_MU_3,
BG_TYPE_GRD_S_F_PK_1,
BG_TYPE_GRD_S_F_PK_2,
BG_TYPE_GRD_S_F_PK_3,
BG_TYPE_GRD_S_IR_1,
BG_TYPE_GRD_S_IR_2,
BG_TYPE_GRD_S_IR_3,
BG_TYPE_GRD_S_IR_4,
BG_TYPE_GRD_S_IL_1,
BG_TYPE_GRD_S_IL_2,
BG_TYPE_GRD_S_IL_3,
BG_TYPE_GRD_S_IL_4,
BG_TYPE_GRD_S_M_1,
BG_TYPE_GRD_S_M_2,
BG_TYPE_GRD_S_M_3,
BG_TYPE_GRD_S_M_4,
BG_TYPE_GRD_S_M_5,
BG_TYPE_GRD_S_M_6,
BG_TYPE_GRD_S_M_7,
BG_TYPE_GRD_S_M_8,
BG_TYPE_GRD_S_M_9,
BG_TYPE_GRD_S_M_10,
BG_TYPE_GRD_S_M_R1_1,
BG_TYPE_GRD_S_M_R1_2,
BG_TYPE_GRD_S_M_R1_3,
BG_TYPE_GRD_S_M_R1_4,
BG_TYPE_GRD_S_M_R1_5,
BG_TYPE_GRD_S_M_R1_B_1,
BG_TYPE_GRD_S_M_R1_B_2,
BG_TYPE_GRD_S_M_R1_B_3,
BG_TYPE_GRD_S_M_TA_1,
BG_TYPE_GRD_S_M_TA_2,
BG_TYPE_GRD_S_M_TA_3,
BG_TYPE_GRD_S_M_WF_1,
BG_TYPE_GRD_S_M_WF_2,
BG_TYPE_GRD_S_M_WF_3,
BG_TYPE_GRD_S_O_1,
BG_TYPE_GRD_S_O_2,
BG_TYPE_GRD_S_O_3,
BG_TYPE_GRD_S_O_4,
BG_TYPE_GRD_S_O_5,
BG_TYPE_GRD_S_O_6,
BG_TYPE_GRD_S_O_7,
BG_TYPE_GRD_S_O_8,
BG_TYPE_GRD_S_O_9,
BG_TYPE_GRD_S_O_10,
BG_TYPE_GRD_S_O_I_1,
BG_TYPE_GRD_S_O_I_2,
BG_TYPE_GRD_S_O_R1_1,
BG_TYPE_GRD_S_O_R1_2,
BG_TYPE_GRD_S_O_R1_3,
BG_TYPE_GRD_S_O_R1_4,
BG_TYPE_GRD_S_O_R1_5,
BG_TYPE_GRD_S_O_R1_B_1,
BG_TYPE_GRD_S_O_R1_B_2,
BG_TYPE_GRD_S_O_R1_B_3,
BG_TYPE_GRD_S_O_TA_1,
BG_TYPE_GRD_S_O_TA_2,
BG_TYPE_GRD_S_O_TA_3,
BG_TYPE_GRD_S_O_WF_1,
BG_TYPE_GRD_S_O_WF_2,
BG_TYPE_GRD_S_O_WF_3,
BG_TYPE_GRD_S_R1_1,
BG_TYPE_GRD_S_R1_2,
BG_TYPE_GRD_S_R1_3,
BG_TYPE_GRD_S_R1_4,
BG_TYPE_GRD_S_R1_B_1,
BG_TYPE_GRD_S_R1_B_2,
BG_TYPE_GRD_S_R1_B_3,
BG_TYPE_GRD_S_R1_P_1,
BG_TYPE_GRD_S_R2_1,
BG_TYPE_GRD_S_R2_2,
BG_TYPE_GRD_S_R2_3,
BG_TYPE_GRD_S_R2_4,
BG_TYPE_GRD_S_R2_B_1,
BG_TYPE_GRD_S_R2_B_2,
BG_TYPE_GRD_S_R2_B_3,
BG_TYPE_GRD_S_R2_P_1,
BG_TYPE_GRD_S_R3_1,
BG_TYPE_GRD_S_R3_2,
BG_TYPE_GRD_S_R3_3,
BG_TYPE_GRD_S_R3_4,
BG_TYPE_GRD_S_R3_B_1,
BG_TYPE_GRD_S_R3_B_2,
BG_TYPE_GRD_S_R3_B_3,
BG_TYPE_GRD_S_R3_P_1,
BG_TYPE_GRD_S_R4_1,
BG_TYPE_GRD_S_R4_2,
BG_TYPE_GRD_S_R4_3,
BG_TYPE_GRD_S_R4_B_1,
BG_TYPE_GRD_S_R4_B_2,
BG_TYPE_GRD_S_R4_P_1,
BG_TYPE_GRD_S_R5_1,
BG_TYPE_GRD_S_R5_2,
BG_TYPE_GRD_S_R5_3,
BG_TYPE_GRD_S_R5_B_1,
BG_TYPE_GRD_S_R5_B_2,
BG_TYPE_GRD_S_R5_P_1,
BG_TYPE_GRD_S_R6_1,
BG_TYPE_GRD_S_R6_2,
BG_TYPE_GRD_S_R6_3,
BG_TYPE_GRD_S_R6_B_1,
BG_TYPE_GRD_S_R6_B_2,
BG_TYPE_GRD_S_R6_P_1,
BG_TYPE_GRD_S_R7_1,
BG_TYPE_GRD_S_R7_2,
BG_TYPE_GRD_S_R7_3,
BG_TYPE_GRD_S_R7_B_1,
BG_TYPE_GRD_S_R7_B_2,
BG_TYPE_GRD_S_R7_P_1,
BG_TYPE_GRD_S_T_R1_1,
BG_TYPE_GRD_S_T_1,
BG_TYPE_GRD_S_T_2,
BG_TYPE_GRD_S_T_3,
BG_TYPE_GRD_S_T_4,
BG_TYPE_GRD_S_T_5,
BG_TYPE_GRD_S_T_6,
BG_TYPE_GRD_S_T_7,
BG_TYPE_GRD_S_T_8,
BG_TYPE_GRD_S_T_9,
BG_TYPE_GRD_S_T_10,
BG_TYPE_GRD_S_T_PO_1,
BG_TYPE_GRD_S_T_PO_2,
BG_TYPE_GRD_S_T_PO_3,
BG_TYPE_GRD_S_T_R1_2,
BG_TYPE_GRD_S_T_R1_3,
BG_TYPE_GRD_S_T_R1_4,
BG_TYPE_GRD_S_T_R1_5,
BG_TYPE_GRD_S_T_SH_1,
BG_TYPE_GRD_S_T_SH_2,
BG_TYPE_GRD_S_T_SH_3,
BG_TYPE_GRD_S_T_ST1_1,
BG_TYPE_GRD_S_T_ST1_2,
BG_TYPE_GRD_S_T_ST1_3,
BG_TYPE_ROM_MY_ROOM_L,
BG_TYPE_ROM_TENT,
BG_TYPE_ROOM01,
BG_TYPE_MYR_ETC,
BG_TYPE_NPC_ROOM01,
BG_TYPE_247,
BG_TYPE_ROM_SHOP1,
BG_TYPE_249,
BG_TYPE_ROM_SHOP1_FUKU,
BG_TYPE_ROM_SHOP2_FUKU,
BG_TYPE_ROM_SHOP3_FUKU,
BG_TYPE_ROM_SHOP4_FUKU,
BG_TYPE_ROM_SHOP2,
BG_TYPE_ROM_URANAI,
BG_TYPE_ROM_SHOP4_1,
BG_TYPE_ROM_SHOP4_2,
BG_TYPE_ROM_SHOP3,
BG_TYPE_ROM_MY_ROOM_S,
BG_TYPE_ROM_MY_ROOM_M,
BG_TYPE_ROM_TRAIN_IN,
BG_TYPE_GRD_S_F_9_1,
BG_TYPE_GRD_S_R1_3_1,
BG_TYPE_GRD_S_C1_3_1,
BG_TYPE_GRD_S_F_9_2,
BG_TYPE_GRD_PLAYER_SELECT,
BG_TYPE_GRD_POST_OFFICE,
BG_TYPE_POLICE_INDOOR,
BG_TYPE_TMP,
BG_TYPE_TMP2,
BG_TYPE_TMPR,
BG_TYPE_TMPR2,
BG_TYPE_TMP3,
BG_TYPE_TMPR3,
BG_TYPE_TMP4,
BG_TYPE_TMPR4,
BG_TYPE_GRD_YAMISHOP,
BG_TYPE_ROM_MUSEUM1,
BG_TYPE_ROM_MUSEUM2,
BG_TYPE_ROM_MUSEUM3,
BG_TYPE_ROM_MUSEUM5,
BG_TYPE_ROM_MUSEUM4,
BG_TYPE_ROM_MY_ROOM_LL1,
BG_TYPE_ROM_MY_ROOM_LL2,
BG_TYPE_285,
BG_TYPE_ROM_MY_ROOM_M_BASEMENT,
BG_TYPE_ROM_MY_ROOM_L_BASEMENT,
BG_TYPE_ROM_MY_ROOM_LL1_BASEMENT,
BG_TYPE_ROM_MY_ROOM_BASEMENT,
BG_TYPE_ROM_TAILOR,
BG_TYPE_ROM_TOUDAI,
BG_TYPE_292,
BG_TYPE_NUM
};
enum field_type {
mFI_FIELDTYPE_FG,
mFI_FIELDTYPE_1,
mFI_FIELDTYPE_2,
mFI_FIELDTYPE_ROOM,
mFI_FIELDTYPE_NPC_ROOM,
mFI_FIELDTYPE_DEMO,
mFI_FIELDTYPE_PLAYER_ROOM,
mFI_FIELDTYPE_NUM
};
enum field_type2 {
mFI_FIELDTYPE2_FG,
mFI_FIELDTYPE2_PLAYER_ROOM,
mFI_FIELDTYPE2_NPC_ROOM,
mFI_FIELDTYPE2_ROOM,
mFI_FIELDTYPE2_NUM
};
enum field_room {
mFI_FIELD_FG = (((mFI_FIELDTYPE_FG) << 12) | (0)) ,
mFI_FIELD_ROOM0 = (((mFI_FIELDTYPE_ROOM) << 12) | (0)) ,
mFI_FIELD_ROOM_SHOP0,
mFI_FIELD_ROOM_BROKER_SHOP,
mFI_FIELD_ROOM_POST_OFFICE,
mFI_FIELD_ROOM_POLICE_BOX,
mFI_FIELD_ROOM_BUGGY,
mFI_FIELD_ROOM_SHOP1,
mFI_FIELD_ROOM_SHOP2,
mFI_FIELD_ROOM_SHOP3_1,
mFI_FIELD_ROOM_SHOP3_2,
mFI_FIELD_ROOM_KAMAKURA,
mFI_FIELD_ROOM_MUSEUM_ENTRANCE,
mFI_FIELD_ROOM_MUSEUM_PAINTING,
mFI_FIELD_ROOM_MUSEUM_FOSSIL,
mFI_FIELD_ROOM_MUSEUM_INSECT,
mFI_FIELD_ROOM_MUSEUM_FISH,
mFI_FIELD_ROOM_NEEDLEWORK,
mFI_FIELD_ROOM_LIGHTHOUSE,
mFI_FIELD_ROOM_TENT,
mFI_FIELD_NPCROOM0 = (((mFI_FIELDTYPE_NPC_ROOM) << 12) | (0)) ,
mFI_FIELD_NPCROOM_FIELD_TOOL_INSIDE,
mFI_FIELD_DEMO_STARTDEMO = (((mFI_FIELDTYPE_DEMO) << 12) | (0)) ,
mFI_FIELD_DEMO_STARTDEMO2,
mFI_FIELD_DEMO_PLAYERSELECT,
mFI_FIELD_DEMO_STARTDEMO3,
mFI_FIELD_PLAYER0_ROOM = (((mFI_FIELDTYPE_PLAYER_ROOM) << 12) | (0)) ,
mFI_FIELD_PLAYER1_ROOM,
mFI_FIELD_PLAYER2_ROOM,
mFI_FIELD_PLAYER3_ROOM,
};
enum player_wade_state {
mFI_WADE_NONE,
mFI_WADE_START,
mFI_WADE_INPROGRESS,
mFI_WADE_END,
mFI_WADE_ERROR,
mFI_WADE_NUM
};
enum {
mFI_DEPOSIT_ON,
mFI_DEPOSIT_OFF,
mFI_DEPOSIT_GET,
mFI_DEPOSIT_NUM
};
enum {
mFI_MOVEDIR_NONE,
mFI_MOVEDIR_RIGHT,
mFI_MOVEDIR_LEFT,
mFI_MOVEDIR_UP,
mFI_MOVEDIR_DOWN,
mFI_MOVEDIR_NUM
};
enum {
mFI_CLIMATE_0,
mFI_CLIMATE_ISLAND,
mFI_CLIMATE_2,
mFI_CLIMATE_3,
mFI_CLIMATE_4,
mFI_CLIMATE_5,
mFI_CLIMATE_NUM,
};
enum {
mFI_DIGSTATUS_MISS,
mFI_DIGSTATUS_CANCEL,
mFI_DIGSTATUS_FILLIN,
mFI_DIGSTATUS_DIG,
mFI_DIGSTATUS_PUT_ITEM,
mFI_DIGSTATUS_GET_ITEM,
mFI_DIGSTATUS_NUM
};
enum {
mFI_SET_STRUCTURE_SET,
mFI_SET_STRUCTURE_REMOVE,
mFI_SET_STRUCTURE_NUM
};
typedef struct location_info_s {
int block_x;
int block_z;
int unit_x;
int unit_z;
mActor_name_t* block_data;
} mFI_unit_c;
typedef struct block_table_s {
s8 block_x;
s8 block_z;
f32 pos_x;
f32 pos_z;
mActor_name_t* items;
} mFI_block_tbl_c;
typedef struct visible_block_item_info_s {
int count;
mFI_block_tbl_c block_info_tbl[4 ];
} mFI_item_table_c;
enum {
mFI_SOUND_SOURCE_NONE,
mFI_SOUND_SOURCE_RIVER,
mFI_SOUND_SOURCE_OCEAN,
mFI_SOUND_SOURCE_POND,
mFI_SOUND_SOURCE_NUM
};
extern void mFI_ClearFieldData();
extern int mFI_CheckFieldData();
extern mFM_block_info_c* mFI_GetBlockTopP();
extern mActor_name_t mFI_GetFieldId();
extern int mFI_CheckShopFieldName(mActor_name_t field_name);
extern int mFI_CheckShop();
extern u8 mFI_GetBlockXMax();
extern u8 mFI_GetBlockZMax();
extern f32 mFI_GetBlockWidth();
extern f32 mFI_GetBlockHeight();
extern int mFI_GetBlockNum(int block_x, int block_z);
extern int mFI_BlockCheck(int block_x, int block_z);
extern int mFI_UtNumCheck(int ut_x, int ut_z, int bx_max, int bz_max);
extern int mFI_WposX2UtNumX(f32 wpos_x);
extern int mFI_WposZ2UtNumZ(f32 wpos_z);
extern int mFI_Wpos2UtNum(int* ut_x, int* ut_z, xyz_t wpos);
extern int mFI_UtNum2CenterWpos(xyz_t* wpos, int ut_x, int ut_z);
extern int mFI_Wpos2UtCenterWpos(xyz_t* wpos, xyz_t src_pos);
extern int mFI_Wpos2UtNum_inBlock(int* ut_x, int* ut_z, xyz_t wpos);
extern int mFI_Wpos2BlockNum(int* bx, int* bz, xyz_t wpos);
extern int mFI_Wpos2BkandUtNuminBlock(int* bx, int* bz, int* ut_x, int* ut_z, xyz_t wpos);
extern int mFI_WpostoLposInBK(xyz_t* lpos, xyz_t wpos);
extern int mFI_LposInBKtoWpos(xyz_t* wpos, xyz_t lpos, int bx, int bz);
extern int mFI_ScrollCheck(xyz_t wpos, u8 dir);
extern int mFI_BkNum2WposXZ(f32* wpos_x, f32* wpos_z, int bx, int bz);
extern void mFI_UtNum2PosXZInBk(f32* pos_x, f32* pos_z, int ut_x, int ut_z);
extern void mFI_BkandUtNum2Wpos(xyz_t* wpos, int bx, int bz, int ut_x, int ut_z);
extern void mFI_BkandUtNum2CenterWpos(xyz_t* wpos, int bx, int bz, int ut_x, int ut_z);
extern mFM_field_draw_info_c* mFI_BGDisplayListTop();
extern mFM_field_pal_c* mFI_GetFieldPal();
extern int mFI_GetPlayerHouseFloorNo(int scene);
extern int mFI_GetNowPlayerHouseFloorNo();
extern void mFI_InitRegisterBgInfo();
extern int mFI_CheckBgDma(int bx, int bz);
extern f32 mFI_UtNum2BaseHeight(int ut_x, int ut_z);
extern f32 mFI_BkNum2BaseHeight(int bx, int bz);
extern u8 mFI_BkNum2BlockType(int bx, int bz);
extern int mFI_GetPuleIdx();
extern u32 mFI_BkNum2BlockKind(int bx, int bz);
extern int mFI_CheckBlockKind(int bx, int bz, u32 block_kind);
extern int mFI_CheckBlockKind_OR(int bx, int bz, u32 block_kind_OR);
extern int mFI_BlockKind2BkNum(int* bx, int* bz, u32 kind);
extern void mFI_GetSpecialBlockNum(int* block_pos, u32* kinds, int count);
extern void mFI_GetIslandBlockNumX(int* island_x_blocks);
extern mCoBG_Collision_u* mFI_GetBkNum2ColTop(int bx, int bz);
extern mCoBG_Collision_u* mFI_UtNum2UtCol(int ut_x, int ut_z);
extern void mFI_ClearColKeep();
extern mCoBG_Collision_u* mFI_GetUnitCol(xyz_t wpos);
extern u8 mFI_UtNum2UtKeepH(int ut_x, int ut_z);
extern mFM_bg_sound_source_c* mFI_GetSoundSourcePBlockNum(int bx, int bz);
extern Gfx* mFI_GetBGDisplayListRom(int bx, int bz);
extern Gfx* mFI_GetBGDisplayListRom_XLU(int bx, int bz);
extern EVW_ANIME_DATA* mFI_GetBGTexAnimInfo(s8* anim_num, int bx, int bz);
extern void mFI_InitAreaInfo();
extern void mFI_BGDisplayListRefresh(xyz_t wpos);
extern int mFI_CheckInIsland();
extern int mFI_CheckInJustIslandOutdoor();
extern u32 mFI_CheckPlayerBlockInfo();
extern mActor_name_t* mFI_BkNumtoUtFGTop(int bx, int bz);
extern mActor_name_t* mFI_BkNum2UtFGTop_layer(int bx, int bz, int layer);
extern mActor_name_t* mFI_UtNum2UtFG(int ut_x, int ut_z);
extern mActor_name_t* mFI_GetUnitFG(xyz_t wpos);
extern mActor_name_t* mFI_GetUnitFG2(xyz_t wpos);
extern int mFI_GetBlockUtNum2FG(mActor_name_t* item, int bx, int bz, int ut_x, int ut_z);
extern int mFI_BlockUtNumtoFGSet(mActor_name_t item, int bx, int bz, int ut_x, int ut_z);
extern int mFI_UtNumtoFGSet_common(mActor_name_t item, int ut_x, int ut_z, int update);
extern int mFI_SetFG_common(mActor_name_t item, xyz_t wpos, int update);
extern int mFI_SetFG2(mActor_name_t item, xyz_t wpos);
extern void mFI_InitItemTable(mFI_item_table_c* vis_block_info);
extern int mFI_GetOldItemTableIdx(int n);
extern int mFI_GetItemTable_NoReset(mFI_item_table_c* item_table, xyz_t wpos);
extern int mFI_GetItemTable(mFI_item_table_c* item_table, xyz_t wpos, char* file, int line);
extern int mFI_FGisUpDate();
extern void mFI_SetFGUpData();
extern void mFI_BornItemON();
extern int mFI_ItemisBorn();
extern int mFI_ActorisBorn();
extern void mFI_SetBearActor(GAME_PLAY* play, xyz_t wpos, int set_flag);
extern int mFI_search_unit_around(xyz_t* wpos, mActor_name_t item);
extern __declspec(section "forcestrip") int mFI_search_unit_around2(xyz_t* wpos, mActor_name_t item);
extern int mFI_GetItemNumOnBlock(int bx, int bz, mActor_name_t min_item, mActor_name_t max_item);
extern int mFI_GetItemNumOnBlockInField(int bx, int bz, mActor_name_t min_item, mActor_name_t max_item);
extern int mFI_GetItemNumField_BCT(mActor_name_t min_item, mActor_name_t max_item);
extern int mFI_GetItemNumField(mActor_name_t min_item, mActor_name_t max_item);
extern int mFI_GetItemNumInBlock(mActor_name_t item, mActor_name_t* fg_items);
extern int mFI_SearchFGInBlock(int* ut_x, int* ut_z, mActor_name_t item, int bx, int bz);
extern int mFI_CheckFGExist(mActor_name_t* check_items, int check_item_num);
extern u8* mFI_GetHaniwaStepBlock(int bx, int bz);
extern u16 mFI_GetMoveActorBitData(int bx, int bz);
extern void mFI_SetMoveActorBitData(int bx, int bz, u16 move_actor_bit_data);
extern void mFI_SetMoveActorBitData_ON(s16 move_actor_idx, int bx, int bz);
extern void mFI_SetMoveActorBitData_OFF(s16 move_actor_idx, int bx, int bz);
extern void mFI_MyMoveActorBitData_ON(ACTOR* actor);
extern int mFI_GetMoveActorListIdx(mFM_move_actor_c* move_actor_list, int list_size, mActor_name_t actor_name);
extern int mFI_RegistMoveActorList(mActor_name_t actor_name, int bx, int bz, int ut_x, int ut_z, int npc_info_idx,
s16 arg);
extern int mFI_UnregistMoveActorList(mActor_name_t actor_name, int bx, int bz);
extern int mFI_AddMoveActorList(mActor_name_t actor_name, int bx, int bz, int ut_x, int ut_z, s16 arg);
extern mFM_move_actor_c* mFI_MoveActorListDma(int bx, int bz);
extern void mFI_InitMoveActorBitData();
extern void mFI_SetPlayerWade(GAME* game);
extern int mFI_CheckPlayerWade(int wade);
extern int mFI_GetPlayerWade();
extern int mFI_GetNextBlockNum(int* bx, int* bz);
extern u16* mFI_GetDepositP(int bx, int bz);
extern void mFI_ClearDeposit(int bx, int bz);
extern int mFI_GetLineDeposit(u16* deposit, int ut_x);
extern void mFI_BlockDepositOFF(u16* deposit_p, int ut_x, int ut_z);
extern int mFI_GetBlockDeposit(u16* deposit_p, int ut_x, int ut_z);
extern void mFI_BkUtNum2DepositOFF(int bx, int bz, int ut_x, int ut_z);
extern void mFI_UtNum2DepositON(int ut_x, int ut_z);
extern void mFI_UtNum2DepositOFF(int ut_x, int ut_z);
extern int mFI_UtNum2DepositGet(int ut_x, int ut_z);
extern void mFI_Wpos2DepositON(xyz_t wpos);
extern void mFI_Wpos2DepositOFF(xyz_t wpos);
extern int mFI_Wpos2DepositGet(xyz_t wpos);
extern int mFI_CheckItemNoHole(mActor_name_t item);
extern int mFI_GetDigStatus(mActor_name_t* item, xyz_t wpos, int golden_shovel);
extern void mFI_ClearHoleBlock(int bx, int bz);
extern void mFI_ClearBeecomb(int bx, int bz);
extern int mFI_SetFGStructure_common(mActor_name_t structure_name, int bx, int bz, int ut_x, int ut_z, int set_type);
extern int mFI_CheckStructureArea(int ut_x, int ut_z, mActor_name_t structure_name, int structure_ut_x,
int structure_ut_z);
extern mActor_name_t mFI_GetOtherFruit();
extern int mFI_CheckFGNpcOn(mActor_name_t item);
extern int mFI_CheckLapPolice(int bx, int bz, int ut_x, int ut_z);
extern int mFI_GetWaveUtinBlock(int* ut_x, int* ut_z, int bx, int bz);
extern int mFI_ClearBlockItemRandom_common(mActor_name_t item, int clear_num, mActor_name_t* fg_p, u16* deposit_p,
int delete_buried);
extern void mFI_SetFirstSetShell();
extern void mFI_FieldMove(xyz_t player_pos);
extern void mFI_PrintNowBGNum(gfxprint_t* gfxprint);
extern void mFI_PrintFgAttr(gfxprint_t* gfxprint);
extern int mFI_SetOyasiroPos(s16* oyasiro_p);
extern int mFI_SetTreasure(int* selected_bx, int* selected_bz, mActor_name_t item);
extern int mFI_GetClimate();
extern void mFI_SetClimate(int climate);
extern int mFI_CheckBeforeScenePerpetual();
extern void mFI_ChangeClimate_ForEventNotice();
extern void mFI_PullTanukiPathTrees();
enum {
mTM_SEASON_BEGIN = 0,
mTM_SEASON_SPRING = mTM_SEASON_BEGIN,
mTM_SEASON_SUMMER,
mTM_SEASON_AUTUMN,
mTM_SEASON_WINTER,
mTM_SEASON_NUM
};
enum {
mTM_TERM_BEGIN = 0,
mTM_TERM_0 = mTM_TERM_BEGIN,
mTM_TERM_1,
mTM_TERM_2,
mTM_TERM_3,
mTM_TERM_4,
mTM_TERM_5,
mTM_TERM_6,
mTM_TERM_7,
mTM_TERM_8,
mTM_TERM_9,
mTM_TERM_10,
mTM_TERM_11,
mTM_TERM_12,
mTM_TERM_13,
mTM_TERM_14,
mTM_TERM_15,
mTM_TERM_16,
mTM_TERM_17,
mTM_TERM_NUM
};
enum {
mTM_RENEW_TIME_BEGIN = 0,
mTM_RENEW_TIME_WEATHER = mTM_RENEW_TIME_BEGIN,
mTM_RENEW_TIME_DAILY
};
typedef struct time_calendar_term_s {
lbRTC_month_t month;
lbRTC_day_t day;
u16 season;
s16 bgitem_profile;
s16 bgitem_bank;
} mTM_calendar_term_t;
extern void mTM_set_season_com(int term_idx);
extern void mTM_set_season();
extern int mTM_check_renew_time(u8 renew_flag);
extern void mTM_off_renew_time(u8 renew_flag);
extern void mTM_set_renew_is();
extern void mTM_set_renew_time(lbRTC_ymd_c* renew_time, lbRTC_time_c* time);
extern void mTM_ymd_2_time(lbRTC_time_c* time, lbRTC_ymd_c* ymd);
extern void mTM_renewal_renew_time();
extern void mTM_clear_renew_is();
extern void mTM_rtcTime_limit_check();
extern void mTM_time();
extern void mTM_time_init();
extern const lbRTC_time_c mTM_rtcTime_clear_code;
extern const lbRTC_ymd_c mTM_rtcTime_ymd_clear_code;
extern const lbRTC_time_c mTM_rtcTime_default_code;
enum {
mEv_TITLEDEMO_STAFFROLL = -9,
mEv_TITLEDEMO_LOGO = -1,
mEv_TITLEDEMO_NONE = 0,
mEv_TITLEDEMO_START1,
mEv_TITLEDEMO_START2,
mEv_TITLEDEMO_START3,
mEv_TITLEDEMO_START4,
mEv_TITLEDEMO_START5,
mEv_TITLEDEMO_NUM
};
typedef union event_monthday_s {
struct {
u8 month;
u8 day;
};
u16 raw;
} mEv_MonthDay_u;
typedef struct event_today_s {
int type;
u32 active_hours;
mEv_MonthDay_u begin_date;
mEv_MonthDay_u end_date;
s16 status;
u16 pad;
} mEv_event_today_c;
typedef struct event_date_s {
u8 month;
u8 day;
u8 _2;
u8 hour;
} mEv_schedule_date_c;
typedef union {
mEv_schedule_date_c d;
u16 md, _h;
u32 raw;
} mEv_schedule_date_u;
typedef struct event_schedule_s {
mEv_schedule_date_u date[2];
s16 _8;
s16 type;
} mEv_schedule_c;
enum event_type {
mEv_SPNPC_EVENT,
mEv_SAVED_EVENT,
mEv_TYPE2_EVENT,
mEv_TYPE_RUMOR,
mEv_TYPE4_EVENT,
mEv_DAILY_EVENT,
mEv_SPECL_EVENT,
mEv_EVENT_TYPE_NUM
};
enum events {
mEv_SPNPC_SHOP = (int)((((mEv_SPNPC_EVENT) << 29) & (0b111 << 29)) | (((0) << 29) & (0b111 << 29))) ,
mEv_SPNPC_DESIGNER,
mEv_SPNPC_BROKER,
mEv_SPNPC_ARTIST,
mEv_SPNPC_ARABIAN,
mEv_SPNPC_GYPSY,
mEv_SPNPC_END,
mEv_SAVED_RENEWSHOP = (int)((((mEv_SAVED_EVENT) << 29) & (0b111 << 29)) | (((0) << 29) & (0b111 << 29))) ,
mEv_SAVED_UNK1,
mEv_SAVED_FIRSTJOB_PLR0,
mEv_SAVED_FIRSTJOB_PLR1,
mEv_SAVED_FIRSTJOB_PLR2,
mEv_SAVED_FIRSTJOB_PLR3,
mEv_SAVED_FIRSTINTRO_PLR0,
mEv_SAVED_FIRSTINTRO_PLR1,
mEv_SAVED_FIRSTINTRO_PLR2,
mEv_SAVED_FIRSTINTRO_PLR3,
mEv_SAVED_HRAWAIT_PLR0,
mEv_SAVED_HRAWAIT_PLR1,
mEv_SAVED_HRAWAIT_PLR2,
mEv_SAVED_HRAWAIT_PLR3,
mEv_SAVED_HRATALK_PLR0,
mEv_SAVED_HRATALK_PLR1,
mEv_SAVED_HRATALK_PLR2,
mEv_SAVED_HRATALK_PLR3,
mEv_SAVED_FJOPENQUEST_PLR0,
mEv_SAVED_FJOPENQUEST_PLR1,
mEv_SAVED_FJOPENQUEST_PLR2,
mEv_SAVED_FJOPENQUEST_PLR3,
mEv_SAVED_GATEWAY_PLR0,
mEv_SAVED_GATEWAY_PLR1,
mEv_SAVED_GATEWAY_PLR2,
mEv_SAVED_GATEWAY_PLR3,
mEv_SAVED_GATEWAY_FRGN,
mEv_RUMOR_NEW_YEARS_DAY = (int)((((mEv_TYPE_RUMOR) << 29) & (0b111 << 29)) | (((0) << 29) & (0b111 << 29))) ,
mEv_RUMOR_KAMAKURA,
mEv_RUMOR_VALENTINES_DAY,
mEv_RUMOR_GROUNDHOG_DAY,
mEv_RUMOR_CHERRY_BLOSSOM_FESTIVAL,
mEv_RUMOR_CHERRY_BLOSSOM_FESTIVAL2,
mEv_RUMOR_SPRING_SPORTS_FAIR,
mEv_RUMOR_HARVEST_FESTIVAL,
mEv_RUMOR_KOINOBORI,
mEv_RUMOR_SUMMER_FISHING_TOURNEY,
mEv_RUMOR_SUMMER_FISHING_TOURNEY2,
mEv_RUMOR_MORNING_AEROBICS,
mEv_RUMOR_MORNING_AEROBICS2,
mEv_RUMOR_FIREWORKS_SHOW,
mEv_RUMOR_FIREWORKS_SHOW2,
mEv_RUMOR_METEOR_SHOWER,
mEv_RUMOR_HARVEST_MOON_DAY,
mEv_RUMOR_FALL_SPORTS_FAIR,
mEv_RUMOR_MUSHROOM_SEASON,
mEv_RUMOR_TALK_MUSHROOM_SEASON,
mEv_RUMOR_HALLOWEEN,
mEv_RUMOR_FALL_FISHING_TOURNEY,
mEv_RUMOR_FALL_FISHING_TOURNEY2,
mEv_RUMOR_TOY_DAY,
mEv_RUMOR_NEW_YEARS_EVE_COUNTDOWN,
mEv_DAILY_0 = (int)((((mEv_DAILY_EVENT) << 29) & (0b111 << 29)) | (((0) << 29) & (0b111 << 29))) ,
mEv_DAILY_1,
mEv_DAILY_2,
mEv_DAILY_OPEN_SHOP,
mEv_SPECL_DESIGNER_COMPLETE = (int)((((mEv_SPECL_EVENT) << 29) & (0b111 << 29)) | (((0) << 29) & (0b111 << 29)))
};
enum week_type {
mEv_WEEKTYPE_NONE,
mEv_WEEKTYPE_1ST,
mEv_WEEKTYPE_2ND,
mEv_WEEKTYPE_3RD,
mEv_WEEKTYPE_4TH,
mEv_WEEKTYPE_5TH,
mEv_WEEKTYPE_LAST,
mEv_WEEKTYPE_SPECIAL
};
enum event_table {
mEv_EVENT_RUMOR_NEW_YEARS_DAY,
mEv_EVENT_NEW_YEARS_DAY,
mEv_EVENT_RUMOR_KAMAKURA,
mEv_EVENT_KAMAKURA,
mEv_EVENT_SONCHO_VACATION_JANUARY,
mEv_EVENT_SONCHO_VACATION_FEBRUARY,
mEv_EVENT_RUMOR_GROUNDHOG_DAY,
mEv_EVENT_GROUNDHOG_DAY,
mEv_EVENT_RUMOR_VALENTINES_DAY,
mEv_EVENT_VALENTINES_DAY,
mEv_EVENT_RUMOR_SPRING_SPORTS_FAIR,
mEv_EVENT_SPRING_EQUINOX,
mEv_EVENT_SPORTS_FAIR_BALL_TOSS,
mEv_EVENT_SPORTS_FAIR_AEROBICS,
mEv_EVENT_SPORTS_FAIR_TUG_OF_WAR,
mEv_EVENT_SPORTS_FAIR_FOOT_RACE,
mEv_EVENT_SPORTS_FAIR,
mEv_EVENT_APRILFOOLS_DAY,
mEv_EVENT_RUMOR_APRILFOOLS_DAY,
mEv_EVENT_RUMOR_CHERRY_BLOSSOM_FESTIVAL,
mEv_EVENT_CHERRY_BLOSSOM_FESTIVAL,
mEv_EVENT_NATURE_DAY,
mEv_EVENT_SPRING_CLEANING,
mEv_EVENT_MOTHERS_DAY,
mEv_EVENT_SUMMER_CAMPER,
mEv_EVENT_GRADUATION_DAY,
mEv_EVENT_FATHERS_DAY,
mEv_EVENT_RUMOR_FISHING_TOURNEY_1,
mEv_EVENT_TALK_FISHING_TOURNEY_1,
mEv_EVENT_FISHING_TOURNEY_1,
mEv_EVENT_TOWN_DAY,
mEv_EVENT_RUMOR_FIREWORKS_SHOW,
mEv_EVENT_FIREWORKS_SHOW,
mEv_EVENT_RUMOR_MORNING_AEROBICS,
mEv_EVENT_TALK_MORNING_AEROBICS,
mEv_EVENT_MORNING_AEROBICS,
mEv_EVENT_RUMOR_METEOR_SHOWER,
mEv_EVENT_METEOR_SHOWER,
mEv_EVENT_FOUNDERS_DAY,
mEv_EVENT_LABOR_DAY,
mEv_EVENT_RUMOR_FALL_SPORTS_FAIR,
mEv_EVENT_AUTUMN_EQUINOX,
mEv_EVENT_RUMOR_HARVEST_MOON_DAY,
mEv_EVENT_HARVEST_MOON_FESTIVAL,
mEv_EVENT_EXPLORERS_DAY,
mEv_EVENT_RUMOR_MUSHROOM_SEASON,
mEv_EVENT_TALK_MUSHROOM_SEASON,
mEv_EVENT_MUSHROOM_SEASON,
mEv_EVENT_RUMOR_HALLOWEEN,
mEv_EVENT_HALLOWEEN,
mEv_EVENT_MAYORS_DAY,
mEv_EVENT_OFFICERS_DAY,
mEv_EVENT_RUMOR_FISHING_TOURNEY_2,
mEv_EVENT_TALK_FISHING_TOURNEY_2,
mEv_EVENT_FISHING_TOURNEY_2,
mEv_EVENT_RUMOR_HARVEST_FESTIVAL,
mEv_EVENT_HARVEST_FESTIVAL,
mEv_EVENT_SALE_DAY,
mEv_EVENT_SNOW_DAY,
mEv_EVENT_TOY_DAY_SONCHO,
mEv_EVENT_RUMOR_TOY_DAY,
mEv_EVENT_TOY_DAY_JINGLE,
mEv_EVENT_SNOWMAN_SEASON,
mEv_EVENT_RUMOR_NEW_YEARS_EVE_COUNTDOWN,
mEv_EVENT_NEW_YEARS_EVE_COUNTDOWN,
mEv_EVENT_CHERRY_BLOSSOM_PETALS,
mEv_EVENT_TALK_TOY_DAY,
mEv_EVENT_PLAYER_BIRTHDAY,
mEv_EVENT_DOZAEMON,
mEv_EVENT_KABU_PEDDLER,
mEv_EVENT_LOTTERY,
mEv_EVENT_KK_SLIDER,
mEv_EVENT_HANDBILL_BROKER,
mEv_EVENT_HANDBILL_SHOP_SALE,
mEv_EVENT_ARTIST,
mEv_EVENT_BROKER_SALE,
mEv_EVENT_DESIGNER,
mEv_EVENT_GYPSY,
mEv_EVENT_SHOP_SALE,
mEv_EVENT_CARPET_PEDDLER,
mEv_EVENT_SONCHO_NEW_YEARS_DAY,
mEv_EVENT_SONCHO_GROUNDHOG_DAY,
mEv_EVENT_SONCHO_SPRING_SPORTS_FAIR,
mEv_EVENT_SONCHO_APRILFOOLS_DAY,
mEv_EVENT_SONCHO_CHERRY_BLOSSOM_FESTIVAL,
mEv_EVENT_SONCHO_NATURE_DAY,
mEv_EVENT_SONCHO_SPRING_CLEANING,
mEv_EVENT_SONCHO_MOTHERS_DAY,
mEv_EVENT_SONCHO_GRADUATION_DAY,
mEv_EVENT_SONCHO_FATHERS_DAY,
mEv_EVENT_SONCHO_FISHING_TOURNEY_1,
mEv_EVENT_SONCHO_TOWN_DAY,
mEv_EVENT_SONCHO_FIREWORKS_SHOW,
mEv_EVENT_SONCHO_METEOR_SHOWER,
mEv_EVENT_SONCHO_FOUNDERS_DAY,
mEv_EVENT_SONCHO_LABOR_DAY,
mEv_EVENT_SONCHO_FALL_SPORTS_FAIR,
mEv_EVENT_SONCHO_HARVEST_MOON_FESTIVAL,
mEv_EVENT_SONCHO_EXPLORERS_DAY,
mEv_EVENT_SONCHO_HALLOWEEN,
mEv_EVENT_SONCHO_MAYORS_DAY,
mEv_EVENT_SONCHO_OFFICERS_DAY,
mEv_EVENT_SONCHO_FISHING_TOURNEY_2,
mEv_EVENT_SONCHO_HARVEST_FESTIVAL,
mEv_EVENT_SONCHO_SALE_DAY,
mEv_EVENT_SONCHO_SNOW_DAY,
mEv_EVENT_SONCHO_TOY_DAY,
mEv_EVENT_TALK_NEW_YEARS_COUNTDOWN,
mEv_EVENT_HARVEST_FESTIVAL_FRANKLIN,
mEv_EVENT_WEATHER_CLEAR,
mEv_EVENT_WEATHER_SNOW,
mEv_EVENT_WEATHER_SPORTS_FAIR,
mEv_EVENT_BRIDGE_MAKE,
mEv_EVENT_SONCHO_BRIDGE_MAKE,
mEv_EVENT_GHOST,
mEv_EVENT_MASK_NPC,
mEv_EVENT_74,
mEv_EVENT_KOINOBORI,
mEv_EVENT_76,
mEv_EVENT_NUM
};
enum {
mEv_SAVE_DATE_TODAY,
mEv_SAVE_DATE_LAST_PLAY_DATE,
mEv_SAVE_DATE_BIRTHDAY,
mEv_SAVE_DATE_SPECIAL0,
mEv_SAVE_DATE_SPECIAL1,
mEv_SAVE_DATE_SPECIAL2,
mEv_SAVE_DATE_WEEKLY,
mEv_SAVE_DATE_SPECIAL3,
mEv_SAVE_DATE_NUM
};
enum {
mEv_SPECIAL_STATE_UNSCHEDULED,
mEv_SPECIAL_STATE_SCHEDULED_LATER,
mEv_SPECIAL_STATE_SCHEDULED_TODAY,
mEv_SPECIAL_STATE_ACTIVE,
mEv_SPECIAL_STATE_NUM
};
enum {
mEv_EVENT_MAIL_VT_DAY,
mEv_EVENT_MAIL_WT_DAY,
mEv_EVENT_MAIL_NUM
};
typedef struct ghost_spirit_block_data_s {
u8 block_x[5 ];
u8 block_z[5 ];
} mEv_gst_hitodama_block_c;
typedef struct ghost_common_s {
mEv_gst_hitodama_block_c hitodama_block_data;
u16 flags;
u8 _0C[0x2C - 0x0C];
} mEv_gst_common_c;
typedef struct ghost_event_s {
u16 okoruhito_str_no;
u16 flags;
lbRTC_ymd_c renew_time;
} mEv_gst_c;
typedef struct designer_common_s {
int button_presses;
int _04;
} mEv_dsg_common_c;
typedef struct kabu_peddler_event_s {
PersonalID_c spoken_pids[(4 + 1) ];
} mEv_kabu_peddler_c;
typedef struct dozaemon_event_s {
u16 flags;
} mEv_dozaemon_c;
typedef union {
mEv_kabu_peddler_c kabu_peddler;
mEv_dozaemon_c dozaemon;
} mEv_weekly_u;
typedef struct bargin_event_s {
lbRTC_time_c start_time;
lbRTC_time_c end_time;
mActor_name_t items[5 ];
int kind;
} mEv_bargin_c;
typedef struct designer_event_s {
PersonalID_c pids[3 ];
int used;
mActor_name_t gifted_cloths[3 ];
} mEv_designer_c;
typedef struct broker_event_s {
PersonalID_c pid[3 - 1];
lbRTC_time_c end_time;
int used;
mActor_name_t sold_items[3 - 1];
mActor_name_t items[3 ];
} mEv_broker_c;
typedef struct artist_event_s {
PersonalID_c pids[2 ];
int used;
mActor_name_t walls[2 ];
} mEv_artist_c;
typedef struct arabian_event_s {
int used;
mActor_name_t carpet;
} mEv_arabian_c;
typedef struct gypsy_event_s {
int _00;
int block_z;
int block_x;
int ut_z;
int ut_x;
} mEv_gypsy_c;
typedef union {
mEv_bargin_c bargin;
mEv_designer_c designer;
mEv_broker_c broker;
mEv_artist_c artist;
mEv_arabian_c arabian;
mEv_gypsy_c gypsy;
} mEv_special_u;
typedef struct special_event_s {
lbRTC_time_c scheduled;
u32 kind;
mEv_special_u event;
} mEv_special_c;
typedef struct save_event_data_s {
mEv_special_c special;
mEv_weekly_u weekly;
u32 flags;
} mEv_event_save_c;
typedef struct broker_event_common_s {
PersonalID_c entered_pid;
int hide_npc;
} mEv_broker_common_c;
typedef struct santa_event_common_s {
u8 present;
u8 talk_counter;
s8 bx;
s8 bz;
mActor_name_t last_talk_cloth;
} mEv_santa_event_common_c;
typedef struct santa_event_s {
PersonalID_c pid;
u8 present_count;
mActor_name_t cloth[10 ];
} mEv_santa_event_c;
typedef union {
mEv_broker_common_c broker;
mEv_santa_event_common_c santa;
} mEv_event_common_u;
typedef struct event_s {
u8 day;
u8 hour;
u8 _02;
u8 state;
u8 month;
u8 year;
s16 changed_num;
int block_z;
int block_x;
int unused[5];
} Event_c;
typedef struct event_info_s {
u8 type;
u8 id;
u16 year;
mEv_MonthDay_u start_date;
mEv_MonthDay_u end_date;
} mEv_info_c;
typedef struct event_place_data_s {
BlockOrUnit_c block;
BlockOrUnit_c unit;
mActor_name_t actor_name;
s16 flag;
} mEv_place_data_c;
typedef struct event_place_s {
mEv_info_c info;
mEv_place_data_c data;
} mEv_place_c;
typedef struct event_area_s {
mEv_info_c info;
int data[11];
} mEv_area_c;
typedef struct event_common_s {
s16 _00;
s16 area_use_bitfield;
mEv_area_c area[5 ];
s16 too_short;
s16 place_use_bitfield;
mEv_place_c place[10 ];
s16 fieldday_event_id;
s16 fieldday_event_over_status;
u32 unused[2];
} mEv_common_data_c;
typedef struct event_save_event_info_s {
u8 type;
u8 flags;
} mEv_event_save_info_c;
typedef struct event_common_save_data {
mEv_event_save_info_c special_event;
mEv_event_save_info_c weekly_event;
u16 dates[mEv_SAVE_DATE_NUM];
int area_use_bitfield;
mEv_area_c area[5 ];
int last_date;
int delete_event_id;
u32 valentines_day_date;
u32 white_day_date;
u16 ghost_day;
u16 bridge_day;
union {
struct {
u8 used_all_locations : 1;
u8 locations_used : 7;
};
u8 raw;
} bridge_flags;
u8 ghost_event_type;
u8 soncho_event_type;
u8 dozaemon_completed;
} mEv_save_common_data_c;
extern void mEv_ClearSpecialEvent(mEv_special_c* special_event);
extern void mEv_ClearEventKabuPeddler(mEv_kabu_peddler_c* kabu_peddler);
extern void mEv_ClearEventSaveInfo(mEv_event_save_c* save_event);
extern void mEv_ClearEventInfo();
extern void mEv_EventON(u32 event_kind);
extern void mEv_EventOFF(u32 event_kind);
extern int mEv_CheckEvent(u32 event_kind);
extern void mEv_ClearPersonalEventFlag(int player_no);
extern void mEv_SetFirstJob();
extern int mEv_CheckRealArbeit();
extern int mEv_CheckArbeit();
extern int mEv_CheckFirstJob();
extern void mEv_UnSetFirstJob();
extern void mEv_SetFirstIntro();
extern int mEv_CheckFirstIntro();
extern void mEv_UnSetFirstIntro();
extern void mEv_SetGateway();
extern int mEv_CheckGateway();
extern void mEv_UnSetGateway();
extern int mEv_CheckTitleDemo();
extern void mEv_SetTitleDemo(int demo_number);
extern void mEv_RenewalDataEveryDay();
extern void mEv_GetEventWeather(s16* weather, s16* intensity);
extern lbRTC_day_t mEv_get_next_weekday(lbRTC_weekday_t weekday);
extern int mEv_weekday2day(lbRTC_month_t month, int week, int weekday);
extern int mEv_get_end_time(int event_type);
extern u16 mEv_get_bargain_day();
extern u16 mEv_get_special_event_day();
extern u16 mEv_get_special_event_type();
extern int mEv_get_event_place(int event, int* bx, int* bz);
extern int mEv_bridge_time_check();
extern void mEv_init(Event_c* event);
extern void mEv_init_force(Event_c* event);
extern void mEv_2nd_init(Event_c* event);
extern int mEv_PlayerOK();
extern void mEv_run(Event_c* event);
extern void mEv_finish(Event_c* event);
extern int mEv_check_schedule(int event);
extern int mEv_check_run_today(int event);
extern void mEv_set_status(int event, s16 status);
extern void mEv_clear_status(int event, s16 status);
extern int mEv_check_status(int event, s16 status);
extern int mEv_check_status_edge(s16 status);
extern void mEv_set_keep(int event);
extern void mEv_clear_keep(int event);
extern int mEv_check_keep(int event);
extern u8* mEv_reserve_save_area(int type, u8 id);
extern u8* mEv_get_save_area(int type, u8 id);
extern int mEv_clear_save_area(int type, u8 id);
extern u8* mEv_reserve_common_area(int type, u8 id);
extern u8* mEv_get_common_area(int type, u8 id);
extern int mEv_clear_common_area(int type, u8 id);
extern mEv_place_data_c* mEv_reserve_common_place(int type, u8 id);
extern mEv_place_data_c* mEv_get_common_place(int type, u8 id);
extern int mEv_clear_common_place(int type, u8 id);
extern int mEv_use_block_by_other_event(int type, BlockOrUnit_c block);
extern void mEv_erase_FG_all_in_common_place();
extern void mEv_clear_rumor();
extern int mEv_spread_rumor(int type);
extern int mEv_get_rumor();
extern void mEv_actor_dying_message(int type, ACTOR* actor);
extern int mEv_LiveSonchoPresent();
extern int mEv_LivePlayer(u32 player_no);
extern int mEv_ArbeitPlayer_kari(u32 player_no);
extern int mEv_ArbeitPlayer(u32 player_no);
extern void mEv_make_new_special_event();
extern int mEv_GetMonth(Event_c* event);
extern int mEv_GetDay(Event_c* event);
extern int mEv_GetHour(Event_c* event);
extern void mEv_debug_print4f(gfxprint_t* gfxprint);
extern void mEv_sp_debug_print4f(gfxprint_t* gfxprint);
extern int mEv_change(Event_c* event);
extern int mEv_get_special_event_state();
extern int mEv_snowman_born_check();
extern int mEv_someone_died();
extern void mEv_special_event_soldout(int type);
extern void mEv_toland_clear_common();
extern void mGH_animal_return_init();
extern int mGH_check_birth2();
extern int mGH_check_birth();
extern void mGH_check_delete();
extern void mMC_mask_cat_init();
extern int mMC_check_birth();
extern int mMC_check_birth_day();
extern void mMC_check_delete();
extern void mMC_set_time();
typedef struct {
int cols;
int rows;
int frame;
xy_t* vtxData;
Vtx* vtxFrame1;
Vtx* vtxFrame2;
Mtx projection;
Mtx modelView1;
Mtx modelView2;
Gfx* gfx;
u16* zBuffer;
} fbdemo_c;
extern void fbdemo_init_gfx(fbdemo_c*);
extern void fbdemo_init_data(fbdemo_c*);
extern void fbdemo_cleanup(fbdemo_c*);
extern fbdemo_c* fbdemo_init(fbdemo_c*, int, int);
extern void fbdemo_update(fbdemo_c*);
extern void fbdemo_draw(fbdemo_c*, Gfx**);
extern void fbdemo_move(fbdemo_c*);
typedef struct {
Color_RGBA8_u32 color;
Color_RGBA8_u32 unkColor;
u8 direction;
u8 frame;
u8 finished;
u16 texX;
u16 texY;
u16 normal;
Mtx projection;
Mtx lookAt;
Mtx modelView[2][3];
} fbdemo_wipe1;
extern fbdemo_wipe1* fbdemo_wipe1_init(fbdemo_wipe1*);
extern void fbdemo_wipe1_move(fbdemo_wipe1*, int);
extern void fbdemo_wipe1_draw(fbdemo_wipe1*, Gfx**);
extern void fbdemo_wipe1_startup(fbdemo_wipe1*);
extern void fbdemo_wipe1_settype(fbdemo_wipe1*, int);
extern void fbdemo_wipe1_setcolor_rgba8888(fbdemo_wipe1*, u32);
extern u8 fbdemo_wipe1_is_finish(fbdemo_wipe1*);
typedef struct {
u8 type;
u8 isDone;
u8 direction;
Color_RGBA8_u32 color;
s16 frame;
u16 unkA;
u16 timer;
} fbdemo_fade;
extern fbdemo_fade* fbdemo_fade_init(fbdemo_fade*);
extern void fbdemo_fade_move(fbdemo_fade*, int);
extern void fbdemo_fade_draw(fbdemo_fade* this, Gfx** gfxP);
extern void fbdemo_fade_startup(fbdemo_fade*);
extern void fbdemo_fade_settype(fbdemo_fade*, int);
extern void fbdemo_fade_setcolor_rgba8888(fbdemo_fade* this, u32 color);
extern u8 fbdemo_fade_is_finish(fbdemo_fade*);
typedef struct {
int txt;
int frame;
u8 direction;
u8 textureno;
s8 finished;
u8 tmp;
u16 normal;
u8 temp2[2];
Mtx perspmtx;
Mtx lookatmtx;
} fbdemo_triforce;
extern void fbdemo_triforce_startup(fbdemo_triforce*);
extern fbdemo_triforce* fbdemo_triforce_init(fbdemo_triforce*);
extern void fbdemo_triforce_move(fbdemo_triforce*, int);
extern void fbdemo_triforce_draw(fbdemo_triforce*, Gfx**);
extern s8 fbdemo_triforce_is_finish(fbdemo_triforce*);
extern void fbdemo_triforce_settype(fbdemo_triforce*, int);
extern void fbdemo_triforce_setcolor_rgba8888(void);
typedef union fbdemo_wipe_union {
fbdemo_wipe1 fbdemo_wipe1;
fbdemo_triforce fbdemo_triforce;
fbdemo_fade fbdemo_fade;
} fbdemo_wipe_u;
typedef fbdemo_wipe_u* (*FBDEMO_INIT_PROC)(fbdemo_wipe_u*);
typedef void (*FBDEMO_CLEANUP_PROC)(fbdemo_wipe_u*);
typedef void (*FBDEMO_MOVE_PROC)(fbdemo_wipe_u*, int);
typedef void (*FBDEMO_DRAW_PROC)(fbdemo_wipe_u*, Gfx**);
typedef void (*FBDEMO_STARTUP_PROC)(fbdemo_wipe_u*);
typedef void (*FBDEMO_SETTYPE_PROC)(fbdemo_wipe_u*, int);
typedef void (*FBDEMO_SETCOLOR_PROC)(fbdemo_wipe_u*, u32);
typedef int (*FBDEMO_ISFINISHED_PROC)(fbdemo_wipe_u*);
typedef struct {
FBDEMO_INIT_PROC init_proc;
FBDEMO_CLEANUP_PROC cleanup_proc;
FBDEMO_MOVE_PROC move_proc;
FBDEMO_DRAW_PROC draw_proc;
FBDEMO_STARTUP_PROC startup_proc;
FBDEMO_SETTYPE_PROC settype_proc;
FBDEMO_SETCOLOR_PROC setcolor_proc;
void* unused_proc;
FBDEMO_ISFINISHED_PROC isfinished_proc;
} fbdemo_wipe_proc_c;
typedef struct {
fbdemo_wipe_u wipe_data;
int wipe_type;
fbdemo_wipe_proc_c wipe_procs;
} fbdemo_wipe;
typedef void* (*MALLOC_ALIGN_FUNC)(size_t size, u32 align);
typedef void (*MALLOC_FREE_FUNC)(void* ptr);
typedef int (*MALLOC_GETMEMBLOCKSIZE_FUNC)(void* ptr);
typedef int (*MALLOC_GETTOTALFREESIZE_FUNC)();
typedef struct malloc_s {
MALLOC_ALIGN_FUNC malloc_align;
MALLOC_FREE_FUNC free;
MALLOC_GETMEMBLOCKSIZE_FUNC getmemblocksize;
MALLOC_GETTOTALFREESIZE_FUNC gettotalfreesize;
} Famicom_MallocInfo;
enum filer_demo_mode {
FILER_DEMO_MODE_NORMAL,
FILER_DEMO_MODE_AUTO,
FILER_DEMO_MODE_NUM
};
typedef struct FamicomSaveDataHeader {
u8 name[8 ];
u8 _08;
u8 _09;
u8 headerSize;
u8 checksum;
u16 size;
u8 no_save;
u8 _temp[0x40 - 0x000F];
} FamicomSaveDataHeader;
enum {
MEMCARD_COMMENT_TYPE_NONE,
MEMCARD_COMMENT_TYPE_DEFAULT,
MEMCARD_COMMENT_TYPE_COPY_ROM,
MEMCARD_COMMENT_TYPE_COPY_EMBEDDED
};
enum {
MEMCARD_BANNER_TYPE_NONE,
MEMCARD_BANNER_TYPE_DEFAULT,
MEMCARD_BANNER_TYPE_COPY_ROM,
MEMCARD_BANNER_TYPE_COPY_EMBEDDED
};
enum {
MEMCARD_ICON_TYPE_NONE,
MEMCARD_ICON_TYPE_DEFAULT,
MEMCARD_ICON_TYPE_COPY_ROM,
MEMCARD_ICON_TYPE_COPY_EMBEDDED
};
enum {
FAMICOM_RESULT_OK,
FAMICOM_RESULT_NOSPACE,
FAMICOM_RESULT_NOENTRY,
FAMICOM_RESULT_BROKEN,
FAMICOM_RESULT_WRONGDEVICE,
FAMICOM_RESULT_WRONGENCODING,
FAMICOM_RESULT_NOCARD,
FAMICOM_RESULT_NOFILE
};
typedef struct MemcardGameHeader_t {
u8 _00;
u8 _01;
u8 mori_name[16 ];
u16 nesrom_size;
u16 nestags_size;
u16 icon_format;
u16 icon_flags;
u16 comment_img_size;
struct {
u8 has_comment_img : 1;
u8 comment_type : 2;
u8 banner_type : 2;
u8 icon_type : 2;
u8 no_copy_flag : 1;
} flags0;
struct {
u8 no_move_flag : 1;
u8 banner_fmt : 2;
u8 reserved : 5;
} flags1;
u16 pad;
} MemcardGameHeader_t;
typedef int (*FAMICOM_GETSAVECHAN_PROC)(int* player_no, s32* slot_card_result);
extern int famicom_getErrorChan();
extern void famicom_setCallback_getSaveChan(FAMICOM_GETSAVECHAN_PROC proc);
extern int famicom_mount_archive_end_check();
extern void famicom_mount_archive();
extern int famicom_init(int rom_idx, Famicom_MallocInfo* malloc_info, int player_no);
extern int famicom_cleanup();
extern void famicom_1frame();
extern int famicom_rom_load_check();
extern int famicom_internal_data_load();
extern int famicom_internal_data_save();
extern int famicom_external_data_save();
extern int famicom_external_data_save_check();
extern int famicom_get_disksystem_titles(int* n_games, char* title_name_bufp, int namebuf_size);
extern void nesinfo_tags_set(int rom_no);
extern void nesinfo_tag_process1(u8* save_data, int mode, u32* max_ofs_p);
extern void nesinfo_tag_process2();
extern void nesinfo_tag_process3(u8* save_data);
extern void nesinfo_update_highscore(u8* save_data, int mode);
extern int nesinfo_get_highscore_num();
extern u8* nesinfo_get_moriName();
extern void nesinfo_init();
extern void highscore_setup_flags(u8* flags);
typedef struct game_famicom_emu_s {
GAME game;
} GAME_FAMICOM_EMU;
extern Famicom_MallocInfo my_malloc_func;
extern void famicom_emu_main(GAME* game);
extern void famicom_emu_init(GAME* game);
extern void famicom_emu_cleanup(GAME* game);
extern void* famicom_gba_getImage(u32 rom_id, size_t* size);
extern void famicom_gba_removeImage(void*);
enum field_draw_type {
FIELD_DRAW_TYPE_OUTDOORS,
FIELD_DRAW_TYPE_INDOORS,
FIELD_DRAW_TYPE_TRAIN,
FIELD_DRAW_TYPE_PLAYER_SELECT,
FIELD_DRAW_TYPE_NUM
};
typedef struct scene_status_s {
u8 unk0[0x13];
u8 unk13;
} Scene_data_status_c;
enum scene_table {
SCENE_TEST1,
SCENE_TEST2,
SCENE_TEST3,
SCENE_WATER_TEST,
SCENE_FOOTPRINT_TEST,
SCENE_NPC_TEST,
SCENE_NPC_HOUSE,
SCENE_FG,
SCENE_RANDOM_NPC_TEST,
SCENE_SHOP0,
SCENE_BG_TEST_NO_RIVER,
SCENE_BG_TEST_RIVER,
SCENE_BROKER_SHOP,
SCENE_FIELD_TOOL_INSIDE,
SCENE_POST_OFFICE,
SCENE_START_DEMO,
SCENE_START_DEMO2,
SCENE_POLICE_BOX,
SCENE_BUGGY,
SCENE_PLAYERSELECT,
SCENE_MY_ROOM_S,
SCENE_MY_ROOM_M,
SCENE_MY_ROOM_L,
SCENE_CONVENI,
SCENE_SUPER,
SCENE_DEPART,
SCENE_TEST5,
SCENE_PLAYERSELECT_2,
SCENE_PLAYERSELECT_3,
SCENE_DEPART_2,
SCENE_EVENT_ANNOUNCEMENT,
SCENE_KAMAKURA,
SCENE_FIELD_TOOL,
SCENE_TITLE_DEMO,
SCENE_PLAYERSELECT_SAVE,
SCENE_MUSEUM_ENTRANCE,
SCENE_MUSEUM_ROOM_PAINTING,
SCENE_MUSEUM_ROOM_FOSSIL,
SCENE_MUSEUM_ROOM_INSECT,
SCENE_MUSEUM_ROOM_FISH,
SCENE_MY_ROOM_LL1,
SCENE_MY_ROOM_LL2,
SCENE_MY_ROOM_BASEMENT_S,
SCENE_MY_ROOM_BASEMENT_M,
SCENE_MY_ROOM_BASEMENT_L,
SCENE_MY_ROOM_BASEMENT_LL1,
SCENE_NEEDLEWORK,
SCENE_COTTAGE_MY,
SCENE_COTTAGE_NPC,
SCENE_START_DEMO3,
SCENE_LIGHTHOUSE,
SCENE_TENT,
SCENE_NUM
};
extern Scene_data_status_c scene_data_status[SCENE_NUM];
enum {
mSc_DIRECT_SOUTH,
mSc_DIRECT_SOUTH_EAST,
mSc_DIRECT_EAST,
mSc_DIRECT_NORTH_EAST,
mSc_DIRECT_NORTH,
mSc_DIRECT_NORTH_WEST,
mSc_DIRECT_WEST,
mSc_DIRECT_SOUTH_WEST,
mSc_DIRECT_NUM
};
enum {
mSc_ITEM_TYPE_BGITEM,
mSc_ITEM_TYPE_DUMMY,
mSc_ITEM_TYPE_BGPOLICEITEM,
mSc_ITEM_TYPE_BGPOSTITEM,
mSc_ITEM_TYPE_NUM
};
enum {
mSc_ROOM_TYPE_OUTDOORS,
mSc_ROOM_TYPE_MY_ROOM,
mSc_ROOM_TYPE_NPC_ROOM,
mSc_ROOM_TYPE_MISC_ROOM,
mSc_ROOM_TYPE_NUM
};
typedef struct door_data_s {
int next_scene_id;
u8 exit_orientation;
u8 exit_type;
u16 extra_data;
s_xyz exit_position;
mActor_name_t door_actor_name;
u8 wipe_type;
u8 pad[3];
} Door_data_c;
typedef struct object_bank_s {
s16 bank_id;
char* ram_start;
char* dma_start;
u32 rom_addr;
size_t size;
u32 _14;
int _18;
int _1C;
int _20;
int _24;
int _28;
OSMessageQueue* msg_queue_p;
OSMessage _30_msg;
OSMessageQueue dma_controller_msg_queue;
OSMessage dma_controller_msg;
s16 num_exist;
u8 part_id;
u8 state;
} Object_Bank_c;
typedef struct object_exchange_s {
Object_Bank_c banks[70 ];
int bank_idx;
int keep_id;
int exchange_id;
char* next_bank_ram_address;
char* max_ram_address;
char* start_address_save[2];
char* end_address_save[2];
char* _194C;
int selected_partition;
int _1954;
} Object_Exchange_c;
enum {
mSc_SCENE_DATA_TYPE_PLAYER_PTR,
mSc_SCENE_DATA_TYPE_CTRL_ACTOR_PTR,
mSc_SCENE_DATA_TYPE_ACTOR_PTR,
mSc_SCENE_DATA_TYPE_OBJECT_EXCHANGE_BANK_PTR,
mSc_SCENE_DATA_TYPE_DOOR_DATA_PTR,
mSc_SCENE_DATA_TYPE_FIELD_CT,
mSc_SCENE_DATA_TYPE_MY_ROOM_CT,
mSc_SCENE_DATA_TYPE_ARRANGE_ROOM_CT,
mSc_SCENE_DATA_TYPE_ARRANGE_FURNITURE_CT,
mSc_SCENE_DATA_TYPE_SOUND,
mSc_SCENE_DATA_TYPE_END,
mSc_SCENE_DATA_TYPE_NUM
};
typedef struct {
u8 type;
u8 num_actors;
Actor_data* data_p;
} Scene_Word_Data_Actor_c;
typedef struct {
u8 type;
u8 num_ctrl_actors;
s16* ctrl_actor_profile_p;
} Scene_Word_Data_Ctrl_Actor_c;
typedef struct {
u8 type;
u8 num_banks;
s16* banks_p;
} Scene_Word_Data_Object_Bank_c;
typedef struct {
u8 type;
u8 num_doors;
Door_data_c* door_data_p;
} Scene_Word_Data_Door_Data_c;
typedef struct {
u8 type;
u8 item_type;
u8 bg_num;
u16 bg_disp_size;
u8 room_type;
u8 draw_type;
} Scene_Word_Data_FieldCt_c;
typedef struct {
u8 type;
u8 arrange_ftr_num;
} Scene_Word_Data_ArrangeFurniture_ct_c;
typedef struct {
u8 type;
u8 param0;
u8 param1;
u8 param2;
u32 param3;
} Scene_Word_Data_Misc_c;
typedef union scene_word_u {
Scene_Word_Data_Misc_c misc;
Scene_Word_Data_Actor_c actor;
Scene_Word_Data_Ctrl_Actor_c control_actor;
Scene_Word_Data_Object_Bank_c object_bank;
Scene_Word_Data_Door_Data_c door_data;
Scene_Word_Data_FieldCt_c field_ct;
Scene_Word_Data_ArrangeFurniture_ct_c arrange_ftr_ct;
} Scene_Word_u;
typedef struct door_info_s {
u8 num_doors;
Door_data_c* door_data_p;
} Door_info_c;
extern Scene_Word_u test01_info[];
extern Scene_Word_u test02_info[];
extern Scene_Word_u test03_info[];
extern Scene_Word_u water_test_info[];
extern Scene_Word_u test_step01_info[];
extern Scene_Word_u test04_info[];
extern Scene_Word_u npc_room01_info[];
extern Scene_Word_u test_fd_npc_land_info[];
extern Scene_Word_u field_tool_field_info[];
extern Scene_Word_u shop01_info[];
extern Scene_Word_u BG_TEST01_info[];
extern Scene_Word_u BG_TEST01_XLU_info[];
extern Scene_Word_u broker_shop_info[];
extern Scene_Word_u fg_tool_in_info[];
extern Scene_Word_u post_office_info[];
extern Scene_Word_u start_demo1_info[];
extern Scene_Word_u start_demo2_info[];
extern Scene_Word_u police_box_info[];
extern Scene_Word_u buggy_info[];
extern Scene_Word_u player_select_info[];
extern Scene_Word_u player_room_s_info[];
extern Scene_Word_u player_room_m_info[];
extern Scene_Word_u player_room_l_info[];
extern Scene_Word_u shop02_info[];
extern Scene_Word_u shop03_info[];
extern Scene_Word_u shop04_1f_info[];
extern Scene_Word_u test05_info[];
extern Scene_Word_u PLAYER_SELECT2_info[];
extern Scene_Word_u PLAYER_SELECT3_info[];
extern Scene_Word_u shop04_2f_info[];
extern Scene_Word_u event_notification_info[];
extern Scene_Word_u kamakura_info[];
extern Scene_Word_u field_tool_field_info[];
extern Scene_Word_u title_demo_info[];
extern Scene_Word_u PLAYER_SELECT4_info[];
extern Scene_Word_u museum_entrance_info[];
extern Scene_Word_u museum_picture_info[];
extern Scene_Word_u museum_fossil_info[];
extern Scene_Word_u museum_insect_info[];
extern Scene_Word_u museum_fish_info[];
extern Scene_Word_u player_room_ll1_info[];
extern Scene_Word_u player_room_ll2_info[];
extern Scene_Word_u p_room_bm_s_info[];
extern Scene_Word_u p_room_bm_m_info[];
extern Scene_Word_u p_room_bm_l_info[];
extern Scene_Word_u p_room_bm_ll1_info[];
extern Scene_Word_u NEEDLEWORK_info[];
extern Scene_Word_u player_room_island_info[];
extern Scene_Word_u npc_room_island_info[];
extern Scene_Word_u start_demo3_info[];
extern Scene_Word_u lighthouse_info[];
extern Scene_Word_u tent_info[];
extern char* mSc_secure_exchange_keep_bank(Object_Exchange_c* exchange, s16 bank_id, size_t size);
extern void mSc_background_dmacopy_controller(Object_Bank_c* bank);
extern void mSc_dmacopy_data_bank(Object_Exchange_c* exchange);
extern int mSc_bank_regist_check(Object_Exchange_c* exchange, s16 bank_id);
extern void mSc_regist_initial_exchange_bank(GAME_PLAY* play);
extern void mSc_dmacopy_all_exchange_bank(Object_Exchange_c* exchange);
extern void mSc_data_bank_ct(GAME_PLAY* play, Object_Exchange_c* exchange);
extern void mSc_decide_exchange_bank(Object_Exchange_c* exchange);
extern void Scene_ct(GAME_PLAY* play, Scene_Word_u* scene_data);
extern void Door_info_ct(Door_info_c* door_info);
extern int goto_other_scene(GAME_PLAY* play, Door_data_c* door_data, int update_player_mode);
extern int goto_next_scene(GAME_PLAY* play, int next_idx, int update_player_mode);
extern int goto_emu_game(GAME* game, s16 famicom_rom_id);
extern void return_emu_game(GAME* game);
typedef struct {
u16 imageX;
u16 imageW;
s16 frameX;
u16 frameW;
u16 imageY;
u16 imageH;
s16 frameY;
u16 frameH;
u64 *imagePtr;
u16 imageLoad;
u8 imageFmt;
u8 imageSiz;
u16 imagePal;
u16 imageFlip;
u16 tmemW;
u16 tmemH;
u16 tmemLoadSH;
u16 tmemLoadTH;
u16 tmemSizeW;
u16 tmemSize;
} uObjBg_t;
typedef struct {
u16 imageX;
u16 imageW;
s16 frameX;
u16 frameW;
u16 imageY;
u16 imageH;
s16 frameY;
u16 frameH;
u64 *imagePtr;
u16 imageLoad;
u8 imageFmt;
u8 imageSiz;
u16 imagePal;
u16 imageFlip;
u16 scaleW;
u16 scaleH;
s32 imageYorig;
u8 padding[4];
} uObjScaleBg_t;
typedef union {
uObjBg_t b;
uObjScaleBg_t s;
long long int force_structure_alignment;
} uObjBg;
typedef struct {
s16 objX;
u16 scaleW;
u16 imageW;
u16 paddingX;
s16 objY;
u16 scaleH;
u16 imageH;
u16 paddingY;
u16 imageStride;
u16 imageAdrs;
u8 imageFmt;
u8 imageSiz;
u8 imagePal;
u8 imageFlags;
} uObjSprite_t;
typedef union {
uObjSprite_t s;
long long int force_structure_alignment;
} uObjSprite;
typedef struct {
s32 A, B, C, D;
s16 X, Y;
u16 BaseScaleX;
u16 BaseScaleY;
} uObjMtx_t;
typedef union {
uObjMtx_t m;
long long int force_structure_alignment;
} uObjMtx;
typedef struct {
s16 X, Y;
u16 BaseScaleX;
u16 BaseScaleY;
} uObjSubMtx_t;
typedef union {
uObjSubMtx_t m;
long long int force_structure_alignment;
} uObjSubMtx;
typedef struct {
u32 type;
u64 *image;
u16 tmem;
u16 tsize;
u16 tline;
u16 sid;
u32 flag;
u32 mask;
} uObjTxtrBlock_t;
typedef struct {
u32 type;
u64 *image;
u16 tmem;
u16 twidth;
u16 theight;
u16 sid;
u32 flag;
u32 mask;
} uObjTxtrTile_t;
typedef struct {
u32 type;
u64 *image;
u16 phead;
u16 pnum;
u16 zero;
u16 sid;
u32 flag;
u32 mask;
} uObjTxtrTLUT_t;
typedef union {
uObjTxtrBlock_t block;
uObjTxtrTile_t tile;
uObjTxtrTLUT_t tlut;
long long int force_structure_alignment;
} uObjTxtr;
typedef struct {
uObjTxtr txtr;
uObjSprite sprite;
} uObjTxSprite;
extern u64 gspS2DEX_fifoTextStart[], gspS2DEX_fifoTextEnd[];
extern u64 gspS2DEX_fifoDataStart[], gspS2DEX_fifoDataEnd[];
extern u64 gspS2DEX_fifo_dTextStart[], gspS2DEX_fifo_dTextEnd[];
extern u64 gspS2DEX_fifo_dDataStart[], gspS2DEX_fifo_dDataEnd[];
extern u64 gspS2DEX2_fifoTextStart[], gspS2DEX2_fifoTextEnd[];
extern u64 gspS2DEX2_fifoDataStart[], gspS2DEX2_fifoDataEnd[];
extern u64 gspS2DEX2_xbusTextStart[], gspS2DEX2_xbusTextEnd[];
extern u64 gspS2DEX2_xbusDataStart[], gspS2DEX2_xbusDataEnd[];
extern void guS2DInitBg(uObjBg *);
extern void guS2D2EmuSetScissor(u32, u32, u32, u32, u8);
extern void guS2D2EmuBgRect1Cyc(Gfx **, uObjBg *);
typedef struct prerender_s {
u16 width;
u16 height;
u16 width_bak;
u16 height_bak;
u16 unk8;
u16 unkA;
u8 unkC;
u8 unkD;
u16 unkE;
u16* framebuffer;
u16* framebuffer_bak;
u8* cvg_bak;
u16* zbuffer;
u16* zbuffer_bak;
u16 ulx_bak;
u16 uly_bak;
u16 lrx_bak;
u16 lry_bak;
u16 ulx;
u16 uly;
u16 lrx;
u16 lry;
u8 _34[0x14];
} PreRender;
typedef struct {
void* timg;
void* tlut;
u16 width;
u16 height;
u8 fmt;
u8 siz;
u16 tt;
u16 tlutCount;
f32 x;
f32 y;
f32 xScale;
f32 yScale;
u32 flags;
} PreRenderBackground2DParams;
extern void wallpaper_draw1(PreRenderBackground2DParams* bg2D, Gfx** gfxp);
extern void wallpaper_draw(Gfx** const gfxp, u16* const timg, u16* const tlut, const u16 width, const u16 height,
const u8 fmt, const u8 siz, const u16 tt, const u16 tlutCount, f32 x, const f32 y,
const f32 xScale, const f32 yScale, const u32 flags);
extern void PreRender_setup_savebuf(PreRender* render, u32 width, u32 height, void* fbuf, void* zbuf, void* cvg);
extern void PreRender_init(PreRender* render);
extern void PreRender_setup_renderbuf(PreRender* render, u32 width, u32 height, void* fbuf, void* zbuf);
extern void PreRender_cleanup(PreRender* render);
extern void PreRender_CopyRGBC(PreRender* render, Gfx** gfxp, int width, int height);
enum {
FADE_TYPE_NONE,
FADE_TYPE_IN,
FADE_TYPE_OUT,
FADE_TYPE_OUT_START_EMU,
FADE_TYPE_OUT_RETURN_TITLE,
FADE_TYPE_OUT_GAME_END_TRAIN,
FADE_TYPE_OUT_GAME_END,
FADE_TYPE_LOCK,
FADE_TYPE_SELECT,
FADE_TYPE_DEMO,
FADE_TYPE_SELECT_END,
FADE_TYPE_EVENT,
FADE_TYPE_OTHER_ROOM,
FADE_TYPE_OUT_NO_RESTART,
FADE_TYPE_NUM
};
enum {
WIPE_TYPE_NORMAL,
WIPE_TYPE_TRIFORCE,
WIPE_TYPE_FADE_WHITE,
WIPE_TYPE_FADE_BLACK,
WIPE_TYPE_CIRCLE_LEFT,
WIPE_TYPE_CIRCLE_RIGHT,
WIPE_TYPE_EVENT,
WIPE_TYPE_NUM
};
enum {
WIPE_MODE_NONE,
WIPE_MODE_CREATE,
WIPE_MODE_INIT,
WIPE_MODE_MOVE,
WIPE_MODE_NUM
};
enum {
FBDEMO_MODE_NONE,
FBDEMO_MODE_CREATE,
FBDEMO_MODE_INIT,
FBDEMO_MODE_MOVE,
FBDEMO_MODE_NUM
};
typedef int (*DRAW_CHK_PROC)(ACTOR*, GAME_PLAY*);
typedef void (*PLAY_WIPE_PROC)(GAME_PLAY*);
struct game_play_s {
GAME game;
s16 scene_id;
mFI_block_tbl_c block_table;
mFI_block_tbl_c last_block_table;
u8 _0104[0x010C - 0x0104];
Scene_Word_u* current_scene_data;
Object_Exchange_c object_exchange;
View view;
Camera2 camera;
Kankyo kankyo;
Global_light global_light;
pause_t pause;
Actor_info actor_info;
Submenu submenu;
s8 submenu_ground_idx;
char* submenu_ground_tex[2];
char* submenu_ground_pallet[2];
PreRender prerender;
Door_info_c door_info;
int next_scene_no;
MtxF projection_matrix;
MtxF billboard_matrix;
Mtx* billboard_mtx_p;
u32 game_frame;
u8 _2094;
u8 actor_data_num;
u8 ctrl_actor_data_num;
u8 obj_bank_data_num;
Actor_data* player_data;
Actor_data* actor_data;
s16* ctrl_actor_data;
s16* obj_bank_data;
int _20A8;
Event_c event;
u8 fb_fade_type;
u8 fb_wipe_type;
u8 fb_mode;
u8 fb_wipe_mode;
fbdemo_wipe fbdemo_wipe;
fbdemo_fade color_fade;
CollisionCheck_c collision_check;
DRAW_CHK_PROC draw_chk_proc;
rgba8888 fade_color_value;
Scene_data_status_c* scene_data_status;
u8 _2400[0x2600 - 0x2404];
};
extern void play_cleanup(GAME*);
extern void play_init(GAME*);
extern void play_main(GAME*);
extern int ScreenWidth;
extern int ScreenHeight;
extern OSThread graphThread;
extern u8 SegmentBaseAddress[0x40];
void main();
extern void mainproc(void* val);
void DCEnable(void);
void DCInvalidateRange(void*, u32);
void DCFlushRange(void*, u32);
void DCStoreRange(void*, u32);
void DCFlushRangeNoSync(void*, u32);
void DCStoreRangeNoSync(void*, u32);
void DCZeroRange(void*, u32);
void DCTouchRange(void*, u32 len);
void ICInvalidateRange(void*, u32);
void ICFlashInvalidate(void);
void ICEnable(void);
void LCDisable(void);
void guMtxIdentF(float mf[4][4]);
inline void guTranslateF(float m[4][4], float x, float y, float z){
guMtxIdentF(m);
m[3][0] = x;
m[3][1] = y;
m[3][2] = z;
}
inline void guScaleF(float mf[4][4], float x, float y, float z) {
guMtxIdentF(mf);
mf[0][0] = x;
mf[1][1] = y;
mf[2][2] = z;
mf[3][3] = 1.0;
}
void guMtxF2L(float mf[4][4], Mtx *m);
void guTranslate(Mtx *m, float x, float y, float z);
void guScale(Mtx *m, float x, float y, float z);
void guMtxIdent(Mtx *m);
void guNormalize(float* x, float* y, float* z);
void guOrtho(Mtx *m, float l, float r, float b, float t, float n, float f, float scale);
void guRotate(Mtx* m, float a, float x, float y, float z);
void guLookAt(Mtx *m,
float xEye, float yEye, float zEye,
float xAt, float yAt, float zAt,
float xUp, float yUp, float zUp);
void guPerspective(Mtx *m, u16 *perspNorm, float fovy,
float aspect, float near, float far, float scale);
void guLookAtHilite (Mtx *m, LookAt *l, Hilite *h,
float xEye, float yEye, float zEye,
float xAt, float yAt, float zAt,
float xUp, float yUp, float zUp,
float xl1, float yl1, float zl1,
float xl2, float yl2, float zl2,
int twidth, int theight);
extern signed short sins (unsigned short angle);
extern signed short coss (unsigned short angle);
typedef void* OSMesg;
typedef struct OSMesgQueue_s {
OSThread* mtqueue;
OSThread* fullqueue;
volatile int validCount;
int first;
int msgCount;
OSMesg* msg;
} OSMesgQueue;
extern void osCreateMesgQueue(OSMessageQueue* mq, OSMessage msg, int flags);
extern int osSendMesg(OSMessageQueue* mq, OSMessage msg, int flags);
extern int osRecvMesg(OSMessageQueue* mq, OSMessage* msg, int flags);
void osShutdownStart(int shutdown_type);
typedef struct OSAlarm OSAlarm;
typedef void (*OSAlarmHandler)(OSAlarm* alarm, OSContext* context);
struct OSAlarm
{
OSAlarmHandler handler;
OSTime fire;
OSAlarm *prev;
OSAlarm *next;
OSTime period;
OSTime start;
};
void OSInitAlarm(void);
void OSSetAlarm(OSAlarm *alarm, OSTime tick, OSAlarmHandler handler);
void OSSetAbsAlarm(OSAlarm *alarm, OSTime time, OSAlarmHandler handler);
void OSSetPeriodicAlarm(OSAlarm *alarm, OSTime start, OSTime period,
OSAlarmHandler handler);
void OSCreateAlarm(OSAlarm *alarm);
void OSCancelAlarm(OSAlarm *alarm);
BOOL OSCheckAlarmQueue(void);
typedef struct OSTimer_s {
OSAlarm alarm;
struct OSTimer_s* next;
struct OSTimer_s* prev;
OSTime interval;
OSTime value;
OSMessageQueue* mq;
OSMessage msg;
} OSTimer;
extern int osSetTimer(OSTimer* t, OSTime countdown, OSTime interval, OSMessageQueue* mq, OSMessage msg);
extern void osStopTimerAll(void);
extern OSTimer* __osTimerList;
typedef s32 OSPri;
typedef s32 OSId;
OSId osGetThreadId(OSThread*);
extern void osCreateThread2(OSThread* t, OSId id, void(*entry)(void*), void* arg, void* stack_pointer, size_t stack_size, OSPriority priority);
extern void osStartThread(OSThread* t);
extern void osDestroyThread(OSThread* t);
typedef struct {
u32 errStatus;
void* dramAddr;
void* C2Addr;
u32 sectorSize;
u32 C1ErrNum;
u32 C1ErrSector[4];
} __OSBlockInfo;
typedef struct {
u32 cmdType;
u16 transferMode;
u16 blockNum;
s32 sectorNum;
uintptr_t devAddr;
u32 bmCtlShadow;
u32 seqCtlShadow;
__OSBlockInfo block[2];
} __OSTranxInfo;
typedef struct OSPiHandle {
struct OSPiHandle* next;
u8 type;
u8 latency;
u8 pageSize;
u8 relDuration;
u8 pulse;
u8 domain;
uintptr_t baseAddress;
u32 speed;
__OSTranxInfo transferInfo;
} OSPiHandle;
typedef struct {
u8 type;
uintptr_t address;
} OSPiInfo;
typedef struct {
u16 type;
u8 pri;
u8 status;
OSMesgQueue* retQueue;
} OSIoMesgHdr;
typedef struct {
OSIoMesgHdr hdr;
void* dramAddr;
uintptr_t devAddr;
size_t size;
OSPiHandle* piHandle;
} OSIoMesg;
extern void __osInitialize_common();
extern BOOL osIsEnableShutdown(void);
extern BOOL osIsDisableShutdown(void);
extern OSTime osGetDisableShutdownTime(void);
extern OSTime __osShutdownTime;
extern OSTime __osDisableShutdownTime;
extern int __osShutdownDisable;
typedef u64 Z_OSTime;
int bcmp(void* v1, void* v2, u32 size);
void bcopy(void* src, void* dst, size_t n);
void bzero(void* ptr, size_t size);
void osSyncPrintf(const char* fmt, ...);
void osWritebackDCache(void* vaddr, u32 nbytes);
u32 osGetCount(void);
OSTime osGetTime(void);
extern s32 osAppNMIBuffer[16];
extern int osShutdown;
extern u8 __osResetSwitchPressed;
extern MtxF MtxF_clear;
extern Mtx Mtx_clear;
extern void new_Matrix(GAME* game);
extern void Matrix_push();
extern void Matrix_pull();
extern void Matrix_get(MtxF* m);
extern void Matrix_put(MtxF* m);
extern MtxF* get_Matrix_now();
extern void Matrix_mult(MtxF* m, u8 flag);
extern void Matrix_translate(f32 x, f32 y, f32 z, u8 flag);
extern void Matrix_scale(f32 x, f32 y, f32 z, u8 flag);
extern void Matrix_RotateX(s16 x, int flag);
extern void Matrix_RotateY(s16 x, int flag);
extern void Matrix_RotateZ(s16 x, int flag);
extern void Matrix_rotateXYZ(s16 x, s16 y, s16 z, int flag);
extern void Matrix_softcv3_mult(xyz_t* pos, s_xyz* rot);
extern void Matrix_softcv3_load(s_xyz* src, f32 x, f32 y, f32 z);
extern Mtx* _MtxF_to_Mtx(MtxF* src, Mtx* dest);
extern Mtx* _Matrix_to_Mtx(Mtx* dest);
extern Mtx* _Matrix_to_Mtx_new(GRAPH* graph);
extern void Matrix_Position(xyz_t* input_position, xyz_t* output_position);
extern void Matrix_Position_Zero(xyz_t* screen_pos);
extern void Matrix_Position_VecX(f32 x, xyz_t* screen_pos);
extern void Matrix_Position_VecZ(f32 z, xyz_t* screen_pos);
extern void Matrix_copy_MtxF(MtxF* dest, MtxF* src);
extern void Matrix_MtxtoMtxF(Mtx* src, MtxF* dest);
extern void Matrix_reverse(MtxF* m);
extern void Matrix_to_rotate_new(MtxF* m, s_xyz* vec, int flag);
extern void Matrix_to_rotate2_new(MtxF* m, s_xyz* vec, int flag);
extern void Matrix_RotateVector(s16 angle, xyz_t* axis, u8 flag);
extern void suMtxMakeTS(Mtx* m, f32 scaleX, f32 scaleY, f32 scaleZ, f32 translateX, f32 translateY, f32 translateZ);
extern void suMtxMakeSRT(Mtx* m, f32 scaleX, f32 scaleY, f32 scaleZ, s16 rotX, s16 rotY, s16 rotZ, f32 translateX, f32 translateY, f32 translateZ);
extern void suMtxMakeSRT_ZXY(Mtx* m, f32 scaleX, f32 scaleY, f32 scaleZ, s16 rotX, s16 rotY, s16 rotZ, f32 translateX, f32 translateY, f32 translateZ);
extern s16 add_calc_short_angle3(s16* pValue, s16 target, f32 fraction, s16 maxStep, s16 minStep) {
f32 stepSize;
s32 uTarget;
s32 newValue;
s32 uValue;
if (target != *pValue) {
uValue = (u16)*pValue;
uTarget = (u16)target;
if (uValue > uTarget) {
uTarget += 65536;
}
stepSize = (uTarget - uValue) * fraction;
if (stepSize > maxStep) {
stepSize = maxStep;
} else if (stepSize < minStep) {
stepSize = minStep;
}
newValue = uValue + (s32)stepSize;
if (newValue > uTarget) {
newValue = uTarget;
}
*pValue = newValue;
}
return target - *pValue;
}
