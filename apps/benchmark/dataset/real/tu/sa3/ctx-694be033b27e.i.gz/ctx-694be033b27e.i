typedef long int ptrdiff_t;
typedef unsigned long int size_t;
typedef int wchar_t;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef int int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef uint16_t winreg_t;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
typedef u16 MetatileIndexType;
typedef u8 int_vcount;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef u8 bool8;
typedef u16 bool16;
typedef u32 bool32;
struct BgCnt
{
    u16 priority:2;
    u16 charBaseBlock:2;
    u16 dummy:2;
    u16 mosaic:1;
    u16 palettes:1;
    u16 screenBaseBlock:5;
    u16 areaOverflowMode:1;
    u16 screenSize:2;
};
typedef volatile struct BgCnt vBgCnt;
struct PlttData
{
    u16 r:5;
    u16 g:5;
    u16 b:5;
    u16 unused_15:1;
};
typedef struct __attribute__((packed)) OamDataShort { u32 y : 8; u32 affineMode : 2; u32 objMode : 2; u32 mosaic : 1; u32 bpp : 1; u32 shape : 2; u32 x : 9; u32 matrixNum : 5; u32 size : 2; u16 tileNum : 10; u16 priority : 2; u16 paletteNum : 4; } OamDataShort;;
typedef union {
    struct {
             u32 y:8;
             u32 affineMode:2;
             u32 objMode:2;
             u32 mosaic:1;
             u32 bpp:1;
             u32 shape:2;
             u32 x:9;
             u32 matrixNum:5;
             u32 size:2;
             u16 tileNum:10;
             u16 priority:2;
             u16 paletteNum:4;
             u16 fractional:8;
             u16 integer:7;
             u16 sign:1;
    } split;
    struct {
        u16 attr0;
        u16 attr1;
        u16 attr2;
        u16 affineParam;
    } all;
    u16 raw[4];
} OamData;
struct BgAffineSrcData
{
    s32 texX;
    s32 texY;
    s16 scrX;
    s16 scrY;
    s16 sx;
    s16 sy;
    u16 alpha;
};
struct BgAffineDstData
{
    s16 pa;
    s16 pb;
    s16 pc;
    s16 pd;
    s32 dx;
    s32 dy;
};
struct ObjAffineSrcData
{
    s16 xScale;
    s16 yScale;
    u16 rotation;
};
struct SioNormalCnt
{
    u16 sck_I_O:1;
    u16 sck:1;
    u16 ackRecv:1;
    u16 ackSend:1;
    u16 unused_6_4:3;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct SioMultiCnt
{
    u16 baudRate:2;
    u16 si:1;
    u16 sd:1;
    u16 id:2;
    u16 error:1;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u16 data;
};
struct SioUartCnt
{
    u16 baudRate:2;
    u16 ctsEnable:1;
    u16 paritySelect:1;
    u16 transDataFull:1;
    u16 recvDataEmpty:1;
    u16 error:1;
    u16 length:1;
    u16 fifoEnable:1;
    u16 parityEnable:1;
    u16 transEnable:1;
    u16 recvEnable:1;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct JoyCnt
{
    u8 ifReset:1;
    u8 ifRecv:1;
    u8 ifSend:1;
    u8 unused_5_3:3;
    u8 ifEnable:1;
    u8 unused_7:1;
};
struct JoyStat
{
    u8 unused_0:1;
    u8 recv:1;
    u8 unused_2:1;
    u8 send:1;
    u8 flags:2;
    u8 unused_7_6:2;
};
struct RCnt
{
    u8 sc:1;
    u8 sd:1;
    u8 si:1;
    u8 so:1;
    u8 sc_i_o:1;
    u8 sd_i_o:1;
    u8 si_i_o:1;
    u8 so_i_o:1;
    u8 ifEnable:1;
    u8 unused_13_9:5;
    u8 sioModeMaster:2;
};
struct MultiBootParam
{
    u32 system_work[5];
    u8 handshake_data;
    u8 padding;
    u16 handshake_timeout;
    u8 probe_count;
    u8 client_data[3];
    u8 palette_data;
    u8 response_bit;
    u8 client_bit;
    u8 reserved1;
    u8 *boot_srcp;
    u8 *boot_endp;
    u8 *masterp;
    u8 *reserved2[3];
    u32 system_work2[4];
    u8 sendflag;
    u8 probe_target_bit;
    u8 check_wait;
    u8 server_type;
};
typedef struct {
    u32 srcLength : 16;
    u32 srcWidth : 8;
    u32 dstWidth : 8;
} BitUnPackData;
void SoftReset(u32 resetFlags);
void SoftResetExram(u32 resetFlags);
void RegisterRamReset(u32 resetFlags);
void VBlankIntrWait(void);
u16 Sqrt(u32 num);
u16 ArcTan2(s16 x, s16 y);
void CpuSet(const void *src, void *dest, u32 control);
void CpuFastSet(const void *src, void *dest, u32 control);
void BgAffineSet(struct BgAffineSrcData *src, struct BgAffineDstData *dest, s32 count);
void ObjAffineSet(struct ObjAffineSrcData *src, void *dest, s32 count, s32 offset);
void LZ77UnCompWram(const void *src, void *dest);
void LZ77UnCompVram(const void *src, void *dest);
void RLUnCompWram(const void *src, void *dest);
void RLUnCompVram(const void *src, void *dest);
int MultiBoot(struct MultiBootParam *mp);
s32 Div(s32 num, s32 denom);
s32 DivArm(s32 denom, s32 num);
s32 Mod(s32 num, s32 denom);
s32 ModArm(s32 denom, s32 num);
void SoundBiasReset(void);
void SoundBiasSet(void);
void AGBPrintInit(void);
void AGBPutc(const char cChr);
void AGBPrint(const char *pBuf);
void AGBPrintf(const char *pBuf, ...);
void AGBPrintFlush1Block(void);
void AGBPrintFlush(void);
void AGBAssert(const char *pFile, int nLine, const char *pExpression, int nStopProgram);
typedef void (*VoidFn)(void);
typedef struct {
    s16 x;
    s16 y;
} Vec2_16;
typedef struct {
    u16 x;
    u16 y;
} Vec2_u16;
typedef struct {
    s32 x;
    s32 y;
} Vec2_32;
typedef struct {
    u32 reserved : 4;
    u32 compressedType : 4;
    u32 size : 24;
    void *data;
} RLCompressed;
struct BlendRegs {
    u16 bldCnt;
    u16 bldAlpha;
    u16 bldY;
};
typedef struct {
               u16 pa, pb, pc, pd;
               u32 x, y;
} BgAffineReg;
typedef void (*HBlankIntrFunc)(int_vcount vcount);
typedef void (*IntrFunc)(void);
typedef bool32 (*VBlankFunc)(void);
extern void *iwram_end;
extern void *ewram_end;
extern void *rom_footer;
struct EwramNode {
              struct EwramNode *next;
              s32 state;
              u8 __attribute__((aligned(sizeof(void *)))) space[0];
};
void EwramInitHeap(void);
void *EwramMalloc(u32);
void EwramFree(void *);
extern u8 gEwramHeap[0x20080];
typedef int __int32_t;
typedef unsigned int __uint32_t;
void * memchr (const void *, int, size_t);
int memcmp (const void *, const void *, size_t);
void * memcpy (void *, const void *, size_t);
void * memmove (void *, const void *, size_t);
void * memset (void *, int, size_t);
char *strcat (char *, const char *);
char *strchr (const char *, int);
int strcmp (const char *, const char *);
int strcoll (const char *, const char *);
char *strcpy (char *, const char *);
size_t strcspn (const char *, const char *);
char *strerror (int);
size_t strlen (const char *);
char *strncat (char *, const char *, size_t);
int strncmp (const char *, const char *, size_t);
char *strncpy (char *, const char *, size_t);
char *strpbrk (const char *, const char *);
char *strrchr (const char *, int);
size_t strspn (const char *, const char *);
char *strstr (const char *, const char *);
char *strtok (char *, const char *);
size_t strxfrm (char *, const char *, size_t);
char *strtok_r (char *, const char *, char **);
int bcmp (const char *, const char *, size_t);
void bcopy (const char *, char *, size_t);
void bzero (char *, size_t);
int ffs (int);
char *index (const char *, int);
void * memccpy (void *, const void *, int, size_t);
char *rindex (const char *, int);
int strcasecmp (const char *, const char *);
char *strdup (const char *);
int strncasecmp (const char *, const char *, size_t);
char *strsep (char **, const char *);
char *strlwr (char *);
char *strupr (char *);
typedef uint16_t ColorRaw;
typedef int16_t ColorRawSigned;
typedef union Color {
    struct {
        uint16_t r : 5;
        uint16_t g : 5;
        uint16_t b : 5;
        uint16_t a : 1;
    } split;
    ColorRaw raw;
} Color;
typedef struct Rect8 {
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} Rect8;
typedef u16 AnimId;
struct GraphicsData {
               const void *src;
               void *dest;
               u16 size;
               AnimId anim;
};
typedef struct {
               struct GraphicsData graphics;
               u16 *layoutVram;
               const u16 *layout;
               u16 xTiles;
               u16 yTiles;
               u16 unk18;
               u16 unk1A;
               u16 tilemapId;
               u16 unk1E;
               u16 unk20;
               u16 unk22;
               u16 unk24;
               u16 targetTilesX;
               u16 targetTilesY;
               u8 paletteOffset;
               u8 animFrameCounter;
               u8 animDelayCounter;
               u16 flags;
               u16 scrollX;
               u16 scrollY;
               u16 prevScrollX;
               u16 prevScrollY;
               const MetatileIndexType *metatileMap;
               u16 mapWidth;
               u16 mapHeight;
} Background;
typedef struct {
               u16 oamIndex;
               u16 numSubframes;
               u16 width;
               u16 height;
               s16 offsetX;
               s16 offsetY;
} SpriteOffset;
typedef struct SpriteOffset2 {
    SpriteOffset base;
    u32 unkC;
} SpriteOffset2;
typedef struct {
               s32 index;
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} HitboxOld;
typedef struct {
               s32 index;
               Rect8 b;
} Hitbox;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[1];
} Sprite;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[2];
} Sprite2;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[3];
} Sprite3;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[5];
} Sprite5;
typedef struct {
               u16 rotation;
               s16 qScaleX;
               s16 qScaleY;
               s16 x;
               s16 y;
} SpriteTransform;
typedef struct {
               u32 numTiles;
               AnimId anim;
               u8 variant;
} TileInfo;
typedef struct {
               AnimId anim;
               u8 variant;
               u32 numTiles;
} TileInfo2;
typedef struct {
               AnimId anim;
               u8 variant;
               u16 numTiles;
} TileInfo3;
typedef struct {
               u16 numTiles;
               AnimId anim;
               u16 variant;
} TileInfo_16;
typedef struct {
    AnimId anim;
    u16 variant;
    u16 numTiles;
} TileInfo_16_2;
extern const u8 gOamShapesSizes[12][2];
typedef enum {
    ACMD_RESULT__ANIM_CHANGED = -1,
    ACMD_RESULT__ENDED = 0,
    ACMD_RESULT__RUNNING = +1,
    ACMD_RESULT__S32_MATCH = 0x7FFFFFFF
} AnimCmdResult;
AnimCmdResult UpdateSpriteAnimation(Sprite *s);
AnimCmdResult UpdateSpriteAnimation_BG(Sprite *s);
void sub_80C07E0(Sprite *s);
void DisplaySprite(Sprite *s);
void DisplaySprites(Sprite *s, Vec2_16 *positions, u8 count);
void DrawBackground(Background *);
bool32 sa2__sub_8002B20(void);
u32 sa2__sub_80039E4(void);
u32 sa2__sub_8004010(void);
s16 sa2__sub_8004418(s16 x, s16 y);
void ProcessOamBuffers(void);
OamData *OamMalloc(u8 order);
void TransformSprite(Sprite *sprite, SpriteTransform *transform);
void UnusedTransform(Sprite *, SpriteTransform *);
void sa2__sub_8003EE4(u16 p0, s16 p1, s16 p2, s16 p3, s16 p4, s16 p5, s16 p6, BgAffineReg *affine);
s16 sa2__sub_8004418(s16 x, s16 y);
extern u8 gNextFreeAffineIndex;
struct Task;
typedef void (*TaskMain)(void);
typedef void (*TaskDestructor)(struct Task *);
typedef u16 TaskPtr;
typedef u32 TaskPtr32;
typedef u16 IwramData;
typedef struct Task {
               TaskPtr parent;
               TaskPtr prev;
               TaskPtr next;
               IwramData data;
               TaskMain main;
               TaskDestructor dtor;
               u16 priority;
               u16 flags;
} Task;
typedef u16 IwramNodePtr;
typedef u32 IwramNodePtr32;
struct IwramNode {
    IwramNodePtr next;
    s16 state;
    u8 __attribute__((aligned(sizeof(void *)))) space[0];
};
extern struct Task gTasks[128];
extern struct Task gEmptyTask;
extern struct Task *gTaskPtrs[128];
extern s32 gNumTasks;
extern struct Task *gNextTaskToCheckForDestruction;
extern struct Task *gNextTask;
extern struct Task *gCurTask;
extern u8 gIwramHeap[((0x881) * sizeof(uintptr_t))];
u32 TasksInit(void);
void TasksExec(void);
struct Task *TaskCreate(TaskMain taskMain, u16 structSize, u16 priority, u16 flags, TaskDestructor taskDestructor);
void TaskDestroy(struct Task *);
void *IwramMalloc(u16);
void IwramFree(void *p);
void TasksDestroyInPriorityRange(u16, u16);
typedef struct {
    u16 index : 10;
    u16 xFlip : 1;
    u16 yFlip : 1;
    u16 pal : 4;
} Tile;
typedef struct {
               u16 xTiles;
               u16 yTiles;
               u16 animTileSize;
               u8 animFrameCount;
               u8 animDelay;
               const u8 *tiles;
               u32 tilesSize;
               const u16 *palette;
               u16 palOffset;
               u16 palLength;
               const u16 *map;
} Tilemap;
struct MapHeader {
               Tilemap tileset;
               const u16 *metatileMap;
               u16 mapWidth;
               u16 mapHeight;
};
struct MultiSioPacket {
    u8 frameCounter;
    u8 recvErrorFlags : 4;
    u8 loadRequest : 1;
    u8 downloadSuccessFlag : 1;
    u8 loadSuccessFlag : 1;
    u8 reserved_0 : 1;
    u16 checkSum;
    u16 data[24 / 2];
    u16 overrunCatch[2];
};
struct MultiSioArea {
    u8 type;
    u8 state;
    u8 connectedFlags;
    u8 recvSuccessFlags;
    u8 syncRecvFlag[4];
    u8 downloadSuccessFlags : 4;
    u8 loadEnable : 1;
    u8 loadRequest : 1;
    u8 loadSuccessFlag : 1;
    u8 startFlag : 1;
    u8 hardError;
    u8 recvFlagsAvailableCounter;
    u8 sendFrameCounter;
    u8 recvFrameCounter[4][2];
    s32 sendBufCounter;
    s32 recvBufCounter[4];
    u16 *nextSendBufp;
    u16 *currentSendBufp;
    u16 *currentRecvBufp[4];
    u16 *lastRecvBufp[4];
    u16 *recvCheckBufp[4];
    struct MultiSioPacket sendBuf[2];
    struct MultiSioPacket recvBuf[4][3];
};
extern u32 gMultiSioRecvFuncBuf[0x40 / 4];
extern u8 gUnknown_03002BE0[0x10];
extern u8 *gUnknown_03002BF0;
extern u32 gMultiSioIntrFuncBuf[0x120 / 4];
extern struct MultiSioArea gMultiSioArea;
extern void MultiSioInit(u32 connectedFlags);
void MultiSioStart(void);
void MultiSioStop(void);
extern u32 MultiSioMain(void *sendp, void *recvp, u32 loadRequest);
struct MultiSioReturn {
    u32 recvSuccessFlags : 4;
    u32 loadEnable : 1;
    u32 loadRequest : 1;
    u32 loadSuccessFlag : 1;
    u32 type : 1;
    u32 connectedFlags : 4;
    u32 hardError : 1;
    u32 idOverError : 1;
    u32 reserved : 1;
    u32 recvFlagsAvailable : 1;
};
extern void MultiSioIntr(void);
extern void MultiSioSendDataSet(void *sendp, u32 loadReq);
extern u32 MultiSioRecvDataCheck(void *recvp);
struct InputRecorder {
               s32 playbackHead;
               s32 recordHead;
               u8 mode;
};
void InputRecorderResetRecordHead(void);
void InputRecorderResetPlaybackHead(void);
void InputRecorderLoadTape(void);
u16 InputRecorderRead(void);
void InputRecorderWrite(u16);
typedef AnimCmdResult (*AnimationCommandFunc)(void *cursor, Sprite *sprite);
typedef struct {
               s32 cmdId;
               s32 tileIndex;
               u32 numTilesToCopy;
} ACmd_GetTiles;
typedef struct {
               s32 cmdId;
               s32 palId;
               u16 numColors;
               u16 insertOffset;
} ACmd_GetPalette;
typedef struct {
               s32 cmdId;
               s32 offset;
} ACmd_JumpBack;
typedef struct {
               s32 cmdId;
} ACmd_4;
typedef struct {
               s32 cmdId;
               u16 songId;
} ACmd_PlaySoundEffect;
typedef struct {
               s32 cmdId;
               Hitbox hitbox;
} ACmd_Hitbox;
typedef struct {
               s32 cmdId;
               u16 x;
               u16 y;
} ACmd_TranslateSprite;
typedef struct {
               s32 cmdId;
               s32 unk4;
               s32 unk8;
} ACmd_8;
typedef struct {
               s32 cmdId;
               AnimId animId;
               u16 variant;
} ACmd_SetIdAndVariant;
typedef struct {
               s32 cmdId;
               s32 unk4;
               s32 unk8;
               s32 unkC;
} ACmd_10;
typedef struct {
               s32 cmdId;
               s32 priority;
} ACmd_SetSpritePriority;
typedef struct {
               s32 cmdId;
               s32 orderIndex;
} ACmd_SetOamOrder;
typedef struct {
    s32 delay;
    s32 index;
} ACmd_ShowFrame;
typedef union {
    s32 id;
    ACmd_GetTiles tiles;
    ACmd_GetPalette pal;
    ACmd_JumpBack jump;
    ACmd_4 end;
    ACmd_PlaySoundEffect sfx;
    ACmd_Hitbox _6;
    ACmd_TranslateSprite translate;
    ACmd_8 _8;
    ACmd_SetIdAndVariant setAnimId;
    ACmd_10 _10;
    ACmd_SetSpritePriority _11;
    ACmd_SetOamOrder setOamOrder;
    ACmd_ShowFrame show;
} ACmd;
u32 Base10DigitsToHexNibbles(u16 num);
extern const ACmd **const gAnimations[1524];
extern const SpriteOffset *const gSpriteDimensions[1524];
extern const OamDataShort *const gSpriteOamData[1524];
extern const u16 gSpritePalettes[][16];
struct MultiSioData_0_0 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u32 unk4;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_1 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_2 {
    u8 unk0;
    u8 filler1;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_3 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u32 unk8;
    u16 unkC;
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_4 {
    u16 unk0;
    s16 x;
    s16 y;
    u16 unk6;
    u16 unk8;
    u8 unkA;
    u8 unkB;
    u8 unkC;
    u8 unkD;
    u8 unkE;
    u8 numRings;
    u8 unk10;
    u8 unk11;
    u8 unk12;
    u8 unk13;
};
struct MultiSioData_0_5 {
    u16 unk0;
    s16 x;
    s16 y;
    u8 filler3[0x9];
    u8 sioId;
    u8 unk10;
    u8 unk11;
    u8 unk12;
    u8 unk13;
};
struct MultiSioData_3_0 {
    u8 filler0[0x4];
    u8 unk4;
    u8 filler5[0xA];
    u8 unkF[4];
    u8 unk13;
};
struct MultiSioData_Unknown {
    u16 unk0;
    s16 x;
    s16 y;
    u8 filler3[0x9];
    u8 sioId;
    u8 unk10;
    u8 unk11;
    u8 unk12;
    u8 unk13;
    s16 levelTimer;
};
union MultiSioData {
    struct MultiSioData_0_0 pat0;
    struct MultiSioData_0_1 pat1;
    struct MultiSioData_0_2 pat2;
    struct MultiSioData_0_3 pat3;
    struct MultiSioData_0_4 pat4;
    struct MultiSioData_0_5 pat5;
    struct MultiSioData_3_0 pat3_0;
    struct MultiSioData_Unknown patU;
    u8 raw[24];
};
typedef u32 collPxDim_t;
typedef struct {
               const s8 *height_map;
               const u8 *tile_rotation;
               const u16 *metatiles;
               const MetatileIndexType *map[2];
               const u16 *flags;
               u16 levelX, levelY;
               collPxDim_t pxWidth, pxHeight;
} Collision;
struct Unk_03003674_1_Sub {
    u16 unk0, unk2, unk4, unk6;
    s16 unk8, unkA;
};
struct Unk_03003674_1_Full {
    struct Unk_03003674_1_Sub sub;
    u32 unkC;
};
union Unk_03003674_1 {
    const struct Unk_03003674_1_Sub *sub;
    const struct Unk_03003674_1_Full *full;
};
struct Unk_03003674 {
    const union Unk_03003674_0 *const *unk0;
    const union Unk_03003674_1 *unk4;
    const u16 *const *unk8;
    const void *unkC;
    const void *unk10;
    const void *unk14;
    const s32 *unk18;
};
typedef struct {
               const ACmd **const *animations;
               const SpriteOffset *const *dimensions;
               const u16 **const oamData;
               const u16 *const palettes;
               const u8 *const tiles_4bpp;
               const u8 *const tiles_8bpp;
               const u32 *const unk18;
} SpriteTables;
extern u32 gFlags;
extern u32 gFlagsPreVBlank;
extern u32 gFrameCount;
extern IntrFunc gIntrTable[16];
extern IntrFunc const gIntrTableTemplate[14];
extern u32 gIntrMainBuf[0x80];
extern struct Task *gCurTask;
extern struct Task gTasks[128];
extern struct Task *gTaskPtrs[128];
extern struct Task *gNextTask;
extern struct Task gEmptyTask;
extern s32 gNumTasks;
extern u16 gInput;
extern u16 gPrevInput;
extern u16 gPhysicalInput;
extern u16 gReleasedKeys;
extern u16 gRepeatedKeys;
extern u16 gPressedKeys;
extern u8 gKeysFirstRepeatIntervals[10];
extern u8 gRepeatedKeysTestCounter[10];
extern u8 gKeysContinuedRepeatIntervals[10];
extern const u8 *gInputPlaybackData;
extern struct InputRecorder gInputRecorder;
extern u16 *gInputRecorderTapeBuffer;
extern union MultiSioData gMultiSioSend;
extern union MultiSioData gMultiSioRecv[4];
extern u32 gMultiSioStatusFlags;
extern bool8 gMultiSioEnabled;
extern HBlankIntrFunc gHBlankIntrs[4];
extern HBlankIntrFunc gHBlankCallbacks[4];
extern u8 gNumHBlankCallbacks;
extern u8 gNumHBlankIntrs;
extern void *gVramHeapStartAddr;
extern u16 gVramHeapMaxTileSlots;
extern u16 gVramHeapState[256];
extern bool8 gExecSoundMain;
extern u16 gDispCnt;
extern winreg_t gWinRegs[6];
extern struct BlendRegs gBldRegs;
extern BgAffineReg gBgAffineRegs[2];
extern u16 gObjPalette[0x200 / sizeof(u16)];
extern u16 gBgPalette[0x200 / sizeof(u16)];
extern u16 gBgCntRegs[4];
extern s16 gBgScrollRegs[4][2];
extern OamData gOamMallocBuffer[128];
extern OamData gOamBuffer[128];
extern int_vcount gBgOffsetsBuffer[2][160][4];
extern Background *gBackgroundsCopyQueue[16];
extern void *gBgOffsetsHBlankPrimary;
extern u16 gSpriteTransformScaleX;
extern Vec2_16 gSpriteOffset;
extern u8 gOamMallocOrders_StartIndex[32];
extern IntrFunc gVBlankCallbacks[4];
extern u8 gOamFreeIndex;
extern u16 gSpriteTransformRotation;
extern u8 gNumVBlankIntrs;
extern s16 gSpriteTransformX;
extern Tilemap **gTilemapsRef;
extern u8 gBgSprites_Unknown2[4][4];
extern u8 gBgSprites_Unknown1[16];
extern struct GraphicsData gVramGraphicsCopyQueue[32];
extern u8 gVramGraphicsCopyQueueIndex;
extern void *gBgOffsetsHBlankSecondary;
extern void *sa2__gUnknown_030022C0;
typedef void (*Func3003C08)(ColorRaw *palette, u8 destObjPaletteOffset, u16 numColors);
extern Func3003C08 gUnknown_03003C08;
extern s16 gSpriteTransformY;
extern u8 sa2__gUnknown_03002874;
extern void *gHBlankCopyTarget;
extern ColorRaw gRgbMap[3][2 * 16u];
extern u8 gBackgroundsCopyQueueIndex;
extern u8 gHBlankCopySize;
extern u16 sa2__gUnknown_03002A8C;
extern u8 gOamFirstPausedIndex;
extern u8 gBackgroundsCopyQueueCursor;
extern Sprite *gBgSprites[16];
extern u8 gNumVBlankCallbacks;
extern void *gBgOffsetsPrimary;
extern u16 sa2__gUnknown_03004D58;
extern u8 gVramGraphicsCopyCursor;
extern u8 gOamMallocOrders_EndIndex[0x20];
extern u8 gBgSpritesCount;
extern u16 gSpriteTransformScaleY;
extern s16 gSpriteTransformScaleUnknown;
extern IntrFunc gVBlankIntrs[4];
extern s32 gPseudoRandom;
extern u8 gOamMallocCopiedOrder[128];
extern struct MultiBootParam gMultiBootParam;
extern const SpriteTables *gRefSpriteTables;
void EngineInit(void);
void EngineMainLoop(void);
extern u32 gFlags;
extern const s16 gSineTable[1280];
typedef s32 CamCoord;
typedef void (*BgUpdate)(s32, s32);
struct Camera {
               s32 x;
               s32 y;
               s16 shiftX;
               s16 shiftY;
               s16 shakeOffsetX;
               s16 shakeOffsetY;
               s32 minY;
               s32 maxY;
               s32 minX;
               s32 maxX;
               s32 sa2__qUnk8;
               s32 sa2__unkC;
               CamCoord sa2__unk10;
               CamCoord sa2__unk14;
               s32 dx;
               s32 dy;
               s32 sa2__unk44;
               s32 sa2__unk48;
               s32 unk40;
               s32 unk44;
               struct Task *task48;
               struct Task *task4C;
               struct Task *task50;
               struct Task *task54;
               s16 sa2__unk56;
               s16 sa2__unk40;
               u16 sa2__unk50;
               u8 padding5E[2];
               s16 unk60;
               s16 unk62;
               s16 unk64;
               s16 sa2__unk64;
               u8 unk68;
               u8 unk69;
               s16 unk6A;
};
struct Camera gCamera;
bool32 IsWorldPtActive(s32 worldX, s32 worldY);
bool32 IsScreenPtActive128px(s32 screenX, s32 screenY);
extern const Collision *gRefCollision;
extern const Collision *const gCollisionTable[73];
typedef enum {
    CHARACTER_SONIC,
    CHARACTER_CREAM,
    CHARACTER_TAILS,
    CHARACTER_KNUCKLES,
    CHARACTER_AMY,
    NUM_CHARACTERS
} ECharacters;
extern const s16 gPlayerCharacterIdleAnims[NUM_CHARACTERS];
void GameStart(void);
bool16 GetZoneAndActTypeFromStageID(s16 stageId, u8 *zone, u8 *actType);
extern void sub_80003B8(void);
typedef struct __attribute__((packed)) MapEntity { u8 x; u8 y; u8 index; union __attribute__((packed)) { s8 sData[5]; u8 uData[5]; } d; } MapEntity;;
typedef struct __attribute__((packed)) MapEntity_Itembox { u8 x; u8 y; u8 index; } MapEntity_Itembox;;
typedef struct __attribute__((packed)) MapEntity_Ring { u8 x; u8 y; } MapEntity_Ring;;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 unk8;
               u8 unk9;
               u8 meX;
               u8 id;
} SpriteBase;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u16 unk8;
               u8 meX;
               u8 id;
} SpriteBase2;
typedef struct {
               MapEntity *me;
               s32 qWorldX;
               s32 qWorldY;
               u16 regionX;
               u16 regionY;
               u16 unk10;
               s16 unk12;
               u8 meX;
               u8 id;
               u8 unk16;
               u8 unk17;
               u8 unk18;
               u8 unk19;
} SpriteBase3;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 filler8[0x2];
               u16 qSpeedAirX;
               u16 qSpeedAirY;
               u8 meX;
               u8 id;
} SpriteBase4;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 meX;
               u8 id;
               u8 unkA;
               u8 unkB;
} SpriteBase5;
typedef struct {
    SpriteBase base;
    Sprite s;
} EnemyBase;
typedef enum {
    SONIC,
    CREAM,
    TAILS,
    KNUCKLES,
    AMY,
    PLAYERCHAR_COUNT,
    PLAYERCHAR_NONE = 0xFF,
} eCharacter;
struct Player;
typedef struct Player Player;
typedef void (*PlayerCallback)(Player *p);
typedef union __attribute__((packed)) StateNum { u16 raw; struct { u8 subCount : 4; u8 other : 3; u8 subHighBit : 1; s8 highValue : 8; } split; } StateNum;;
typedef struct {
               SpriteTransform tf;
               Sprite2 s;
} PlayerSpriteInfo;
typedef struct PlayerUnkC4 {
    u32 unk0;
    s16 playerId;
} PlayerUnkC4;
typedef struct PlayerUnk148_A {
    s16 unk0;
    s16 unk2;
    u8 unk4;
    u8 unk5;
    u8 unk6;
    u8 unk7;
    s16 unk8;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_A;
typedef struct PlayerUnk148_B {
    s16 unk0;
    u8 unk2;
    u8 unk3;
    u8 unk4;
    u8 unk5;
    u8 unk6;
    u8 unk7;
    u8 unk8;
    u8 unk9;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_B;
typedef struct PlayerUnk148_C {
    s16 unk0;
    u8 unk2;
    u8 unk3;
    u8 *tiles;
    u8 unk8;
    u8 unk9;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_C;
typedef struct PlayerUnk148_D {
    u8 unk0[0x8];
    u16 unk8;
    s16 someAnim0;
    Sprite s;
} PlayerUnk148_D;
typedef union PlayerUnk148 {
    PlayerUnk148_A a;
    PlayerUnk148_B b;
    PlayerUnk148_C c;
    PlayerUnk148_D d;
} PlayerUnk148;
struct Player {
    PlayerCallback callback;
               u32 moveState;
               u32 moveState2;
    u32 unkC;
               s32 qWorldX;
               s32 qWorldY;
    s16 qSpeedAirX;
    s16 qSpeedAirY;
    s16 qSpeedGround;
    u16 keyInput;
    u16 keyInput2;
    u16 unk22;
               s8 spriteOffsetX;
               s8 spriteOffsetY;
               u8 unk26;
               u8 layer;
    struct {
        u8 unk28;
        u8 unk29;
        u8 character : 4;
        u8 padding1 : 4;
        u8 partnerIndex : 2;
        u8 someIndex : 3;
        u8 someFlag0 : 1;
        u8 someFlag1 : 1;
        u8 boostIsActive : 1;
        u8 unk2C_01 : 1;
        u8 unk2C_02 : 1;
        u8 unk2C_04 : 1;
        u8 unk2C_08 : 1;
        u8 unk2C_10 : 1;
        u8 unk2C_20 : 1;
        u8 unk2C_40 : 1;
        u8 unk2C_80 : 1;
                   u8 unk2D_0 : 4;
                   u8 ringSpeedFactor : 4;
        u8 state0_subCount : 4;
        u8 state0_other : 3;
        u8 state0_subHighBit : 1;
        u8 sa2__unk61 : 8;
        s16 anim0;
        s16 anim1;
        u16 anim2;
        u16 state1;
    } charFlags;
    s32 qUnk38;
    s32 qUnk3C;
    s16 timeSinceTagActionDelay;
    s16 timeSinceTagActionCharge;
    s16 unk44;
    s16 Spindash_Velocity;
    s16 unk48;
    s16 framesInvulnerable;
    s16 framesInvincible;
    s16 unk4E;
    s16 boostEffectCounter;
    s16 idleAndCamCounter;
               s16 unk54;
    s8 unk56;
    s8 unk57;
    u8 unk58;
    u8 unk59;
    u8 unk5A;
    u8 unk5B;
    u8 unk5C;
    u8 unk5D;
    s16 timerSpeedup;
    s16 timerSlowItem;
    s16 unk62;
    u16 unk64;
    s16 unk66;
    u8 unk68;
    u8 unk69;
    u8 filler6A[0x2];
               Sprite *sprColliding;
    s32 qUnk70;
    s32 qUnk74;
    s8 unk78[0x10];
    s32 unk88;
    s32 unk8C;
    s32 unk90;
    s32 unk94;
    u8 unk98;
    u8 unk99;
    u8 unk9A;
    u8 unk9B;
               s16 qCamOffsetX;
               s16 qCamOffsetY;
               s16 unkA0;
               s16 unkA2;
    u8 unkA4;
    u8 PaddingA5[0x3];
    u32 unkA8;
    u32 unkAC;
    u32 unkB0;
    u32 unkB4;
    u32 unkB8;
    u32 unkBC;
    u16 unkC0;
    u16 unkC2;
    struct Task *unkC4[0x03];
    struct Task *taskTagAction;
    struct Task *unkD4;
    struct Task *unkD8;
    struct Task *unkDC;
    PlayerSpriteInfo *spriteInfoBody;
    PlayerSpriteInfo *spriteInfoLimbs;
    Vec2_16 unkE8;
    u8 unkEC;
    s32 qUnkF0;
    u16 palette[16];
    Sprite sprShield;
    u8 unk13C;
    u8 unk13D;
    u16 *demoplayInput_Start;
    u16 *demoplayInput_Current;
    union {
        PlayerUnk148 *ptr;
        u8 arr_u8[4];
        s16 arr_s16[2];
    } unk148;
    union {
        u8 arr_u8[4];
        s16 arr_s16[2];
    } unk14C;
};
extern Player gPlayers[4];
struct Struc_3001150_1C;
typedef u16 (*Struc_3001150_InputRes)(struct Struc_3001150_1C *strc, Player *partner, Player *p);
typedef bool32 (*Struc_3001150_BoolRes)(struct Struc_3001150_1C *strc, Player *partner, Player *p);
typedef struct Struc_3001150_1C {
                u8 unk0;
                u8 unk1;
                s16 unk2;
                s32 unk4;
                s32 unk8;
                s32 unkC;
                s32 unk10;
                s32 unk14;
                s32 unk18;
                s32 unk1C;
                s32 unk20;
                s32 unk24;
                s32 unk28;
                s32 unk2C;
                s32 unk30;
                s32 unk34;
                u8 padd38[0x6];
                s16 unk3E;
                u16 unk40;
                u16 inputBuffer[128];
                u8 inputBufferIndex;
                u8 filler143[0x1];
                Struc_3001150_InputRes func;
} Struc_3001150_1C;
typedef struct Struc_3001150_164_0 {
    s32 qWorldX;
    s32 qWorldY;
    s32 unk8;
    s32 unkC;
    s16 unk10;
    u8 unk12;
    u8 unk13;
    u8 unk14;
} Struc_3001150_164_0;
typedef struct Struc_3001150_164 {
                Struc_3001150_164_0 unk0[32];
                s16 unk0Index;
} Struc_3001150_164;
typedef struct Struc_3001150 {
                s32 unk0;
                u8 filler4[0x4];
                s16 unk8;
                s16 unkA;
                s32 unkC;
                s32 unk10;
                s16 unk14;
                s16 unk16;
                s16 unk18;
                Struc_3001150_1C unk1C;
                Struc_3001150_164 unk164;
} Struc_3001150;
Struc_3001150 gUnknown_03001150;
typedef struct Strc_80E3254 {
    Struc_3001150_InputRes funcA;
    Struc_3001150_BoolRes funcB;
    u8 someCount;
} Strc_80E3254;
void InitializePlayer(s16 playerId);
bool16 IsInWater(s16 worldX, s16 worldY, s16 *outYPos);
extern s16 sub_801480C(Player *p);
void Call__Player_8014550(Player *p);
void DemoPlayAlloc(Player *p, s16 zoneIndex);
bool32 sub_802C080(Player *p);
bool32 sub_802C0D4(Player *p);
void sub_8004CC8(s16 playerId);
void sub_8004D30(void);
void sub_80044CC(Player *p);
void sub_8004D68(s32 qWorldX, s32 qWorldY);
void sub_8004DD8(s32 qWorldX, s32 qWorldY);
s32 sub_8011BFC(u8, Player *p);
extern bool32 sub_8020700(Sprite *s, s32 worldX, s32 worldY, s16 p3, Player *p, s16 p5);
extern u32 sub_8020874(Sprite *s, s32 worldX, s32 worldY, s16 p3, Player *p, s16 p5, u8 p6);
u32 sub_8020950(Sprite *s, s32 worldX, s32 worldY, Player *p, u8 param4);
bool32 sub_8020A58(Sprite *s, s16 hbIndex, s32 worldX, s32 worldY, Rect8 *param4, Player *p, u8 param6);
bool32 sub_8020CE0(Sprite *s, s32 worldX, s32 worldY, s16 hbIndex, Player *p);
bool32 sub_8020E3C(Sprite *s, s32 param1, s32 param2, s16 param3, Player *p);
void ResolvePlayerSpriteCollision(Sprite *s, Player *p);
void sub_80274F4(u8, u16 x, s16 y);
void sub_80275B8(u32 level, u8, u8);
void sub_80276A8(u8 charId);
void sub_80276F4(u16 somePlayerFlags, u16 playerIndex);
void sub_80296F8(u16 somePlayerFlags);
void sub_8027674(u8 param0, u16 param1);
typedef struct {
               u8 filler0[7];
               u8 unk7;
               u8 unk8;
               u8 unk9;
               u8 fillerA[0x2];
               u32 unkC[4];
               u16 unk1C[4][6];
               u8 unk4C[4];
               u16 unk50;
               u16 unk52;
               u8 unk54;
               u8 unk55;
               u8 unk56;
} Struct_03001060;
extern Struct_03001060 gUnknown_03001060;
typedef struct {
    s8 r;
    s8 g;
    s8 b;
} MaskingColors;
typedef struct {
    float r;
    float g;
    float b;
} MaskingColorsFloat;
typedef struct {
    u16 anim;
    u8 variant;
    u8 unk3;
    u32 unk4;
    u8 filler8[0xC];
    s32 unk14;
    s32 unk18;
} UnknownColorStruct;
typedef struct UnknownIwramData {
    u8 unk0;
    u8 unk1;
    u8 unk2;
    u8 unk3;
    u32 unk4;
    u16 unk8;
    u16 unkA;
    u8 fillerC[8];
    Sprite *spr14;
    const UnknownColorStruct *unk18;
    s32 *unk1C;
    s32 *unk20;
    s32 *unk24;
    s32 unk28;
    u16 unk2C;
    struct UnknownIwramData *unk30[0];
} UnknownIwramData;
typedef struct {
    Sprite s;
} UnknownIwramDataB;
void CopyObjPaletteMasked(const ColorRaw *srcPalette, u8 destObjPaletteColorOffset, u16 numColors);
void CopyBgPaletteMasked(const ColorRaw *srcPalette, u8 destBgPaletteOffset, u16 numColors);
void *sub_80C4C60(const UnknownColorStruct **param0, u8 hitboxCount);
void sub_80C4E24(UnknownIwramData **param0, u8 param1, s32 **param2);
void sub_80C4EB0(UnknownIwramData **param0, u8 param1, u32 mask);
void sub_80C5294(UnknownIwramData *);
void sub_80C59E8(UnknownIwramData **param0, u8 param1, s32 *screenPos, u8 *arr4, s16 param4);
void FreeUnknownIwramDataArray(UnknownIwramData **param0, u8 param1);
void sub_80C610C(UnknownIwramData **param0, u8 param1);
void CreateMainMenu(s16 param0, u8 param1);
void *VramMalloc(u32);
void VramResetHeapState(void);
void VramFree(void *);
struct MP2KTrack;
struct MP2KPlayerState;
typedef void (*MP2KEventNoteFunc)(u8, struct MP2KPlayerState *, struct MP2KTrack *);
typedef void (*MP2KEventFunc)(struct MP2KPlayerState *, struct MP2KTrack *);
typedef void (*CgbSoundFunc)(void);
typedef void (*CgbOscOffFunc)(u8);
typedef u32 (*MidiKeyToCgbFreqFunc)(u8, u8, u8);
typedef void (*ExtVolPitFunc)(void);
typedef void (*MPlayMainFunc)(struct MP2KPlayerState *);
struct MixerSource {
    u8 status;
    u8 type;
    u8 rightVol;
    u8 leftVol;
    union {
        struct {
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
            u8 key;
            u8 envelopeVol;
            u8 envelopeGoal;
            u8 envelopeCtr;
            u8 echoVol;
            u8 echoLen;
            u8 padding1;
            u8 padding2;
            u8 gateTime;
            u8 untransposedKey;
            u8 velocity;
            u8 priority;
            u8 rhythmPan;
            u8 padding3;
            u8 padding4;
            u8 padding5;
            u8 padding6;
            u8 sustainGoal;
            u8 nrx4;
            u8 pan;
            u8 panMask;
            u8 cgbStatus;
            u8 length;
            u8 sweep;
            u32 freq;
        } cgb;
        struct {
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
            u8 key;
            u8 envelopeVol;
            u8 envelopeVolR;
            u8 envelopeVolL;
            u8 echoVol;
            u8 echoLen;
            u8 padding1;
            u8 padding2;
            u8 gateTime;
            u8 untransposedKey;
            u8 velocity;
            u8 priority;
            u8 rhythmPan;
            u8 padding3;
            u8 padding4;
            u8 padding5;
            u32 ct;
            float fw;
            u32 freq;
        } sound;
    } data;
    void *wav;
    void *current;
    struct MP2KTrack *track;
    struct MixerSource *prev;
    struct MixerSource *next;
    u32 padding7;
    u32 blockCount;
};
struct SoundMixerState {
    u32 lockStatus;
    vu8 dmaCounter;
    u8 reverb;
    u8 numChans;
    u8 masterVol;
    u8 freqOption;
    u8 extensionFlags;
    u8 cgbCounter15;
    u8 framesPerDmaCycle;
    u8 maxScanlines;
    u8 gap[3];
    s32 samplesPerFrame;
    s32 sampleRate;
    s32 sampleRateReciprocal;
    struct MixerSource *cgbChans;
    MPlayMainFunc MPlayMainHead;
    struct MP2KPlayerState *musicPlayerHead;
    CgbSoundFunc CgbSound;
    CgbOscOffFunc CgbOscOff;
    MidiKeyToCgbFreqFunc MidiKeyToCgbFreq;
    void **MPlayJumpTable;
    MP2KEventNoteFunc plynote;
    ExtVolPitFunc ExtVolPit;
    void *reserved2;
    void *reserved3;
    void *reversed4;
    void *reserved5;
    struct MixerSource chans[12];
    s8 pcmBuffer[1584 * 2];
};
struct MP2KVoiceGroup {
    u8 type;
    u8 drumKey;
    u8 cgbLength;
    u8 pan_sweep;
    union {
        struct {
            struct WaveData *wav;
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
        } sound;
        struct {
            struct MP2KVoiceGroup *group;
            u8 *keySplitTable;
        } keySplit;
    } data;
};
struct WaveData {
    u16 type;
    u16 status;
    u32 freq;
    u32 loopStart;
    u32 size;
    s8 data[1];
};
struct MP2KSongHeader {
    u8 trackCount;
    u8 blockCount;
    u8 priority;
    u8 reverb;
    struct MP2KVoiceGroup *voicegroup;
    u8 *part[1];
};
struct MP2KTrack {
    u8 status;
    u8 wait;
    u8 patternLevel;
    u8 repeatCount;
    u8 gateTime;
    u8 key;
    u8 velocity;
    u8 runningStatus;
    s8 keyShiftCalculated;
    u8 pitchCalculated;
    s8 keyShift;
    s8 keyShiftPublic;
    s8 tune;
    u8 pitchPublic;
    s8 bend;
    u8 bendRange;
    u8 volRightCalculated;
    u8 volLeftCalculated;
    u8 vol;
    u8 volPublic;
    s8 pan;
    s8 panPublic;
    s8 modCalculated;
    u8 modDepth;
    u8 modType;
    u8 lfoSpeed;
    u8 lfoSpeedCounter;
    u8 lfoDelay;
    u8 lfoDelayCounter;
    u8 priority;
    u8 echoVolume;
    u8 echoLength;
    struct MixerSource *chan;
    struct MP2KVoiceGroup voicegroup;
    u8 gap[10];
    u16 unk_3A;
    u32 unk_3C;
    u8 *cmdPtr;
    u8 *patternStack[3];
};
struct MP2KPlayerState {
    struct MP2KSongHeader *songHeader;
    u32 status;
    u8 trackCount;
    u8 priority;
    u8 cmd;
    bool8 checkSongPriority;
    u32 clock;
    u8 padding[8];
    u8 *memAccArea;
    u16 tempoRawBPM;
    u16 tempoScale;
    u16 tempoInterval;
    u16 tempoCounter;
    u16 fadeInterval;
    u16 fadeCounter;
    u16 fadeOV;
    struct MP2KTrack *tracks;
    struct MP2KVoiceGroup *voicegroup;
    u32 lockStatus;
    MPlayMainFunc nextPlayerFunc;
    struct MP2KPlayerState *nextPlayer;
};
struct MusicPlayer {
    struct MP2KPlayerState *info;
    struct MP2KTrack *track;
    u8 numTracks;
    u16 unk_A;
};
struct Song {
    struct MP2KSongHeader *header;
    u16 ms;
    u16 me;
};
typedef void (*XcmdFunc)(struct MP2KPlayerState *, struct MP2KTrack *);
extern char SoundMainRAM[];
extern u8 gMPlayMemAccArea[];
extern void *gMPlayJumpTable[];
extern struct MixerSource gCgbChans[];
extern const struct MusicPlayer gMPlayTable[];
extern const struct Song gSongTable[];
extern const XcmdFunc gXcmdTable[];
extern const u8 gClockTable[];
extern const u8 gScaleTable[];
extern const u32 gFreqTable[];
extern const u16 gPcmSamplesPerVBlankTable[];
extern void *const gMPlayJumpTableTemplate[];
extern const u8 gCgbScaleTable[];
extern const s16 gCgbFreqTable[];
extern const u8 gNoiseTable[];
extern const u8 gCgb3Vol[];
extern char gNumMusicPlayers[];
extern char gMaxLines[];
u32 MidiKeyToFreq(struct WaveData *wav, u8 key, u8 fineAdjust);
u32 umul3232H32(u32 multiplier, u32 multiplicand);
void SoundMain(void);
void SoundMainBTM(void *ptr);
void TrackStop(struct MP2KPlayerState *player, struct MP2KTrack *track);
void MP2KPlayerMain(struct MP2KPlayerState *);
void ClearChain(struct MixerSource *chan);
void MP2KClearChain(struct MixerSource *chan);
void MPlayContinue(struct MP2KPlayerState *mplayInfo);
void MPlayStart(struct MP2KPlayerState *mplayInfo, struct MP2KSongHeader *songHeader);
void MPlayStop(struct MP2KPlayerState *mplayInfo);
void FadeOutBody(struct MP2KPlayerState *mplayInfo);
void TrkVolPitSet(struct MP2KPlayerState *mplayInfo, struct MP2KTrack *track);
void MPlayFadeOut(struct MP2KPlayerState *mplayInfo, u16 speed);
void Clear64byte(void *addr);
void SoundInit(struct SoundMixerState *soundInfo);
void MPlayExtender(struct MixerSource *cgbChans);
void m4aSoundMode(u32 mode);
void MPlayOpen(struct MP2KPlayerState *mplayInfo, struct MP2KTrack *tracks, u8 trackCount);
void CgbSound(void);
void CgbOscOff(u8);
void CgbModVol(struct MixerSource *chan);
u32 MidiKeyToCgbFreq(u8, u8, u8);
void MPlayJumpTableCopy(void **mplayJumpTable);
void SampleFreqSet(u32 freq);
void m4aSoundVSyncOn(void);
void m4aSoundVSyncOff(void);
void m4aMPlayTempoControl(struct MP2KPlayerState *mplayInfo, u16 tempo);
void m4aMPlayVolumeControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, u16 volume);
void m4aMPlayPitchControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s16 pitch);
void m4aMPlayPanpotControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s8 pan);
void ClearModM(struct MP2KTrack *track);
void m4aMPlayModDepthSet(struct MP2KPlayerState *mplayInfo, u16 trackBits, u8 modDepth);
void m4aMPlayLFOSpeedSet(struct MP2KPlayerState *mplayInfo, u16 trackBits, u8 lfoSpeed);
void MP2K_event_fine(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_goto(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_patt(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_pend(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_rept(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_memacc(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_prio(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_tempo(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_keysh(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_voice(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_vol(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_pan(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_bend(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_bendr(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_lfos(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_lfodl(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_mod(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_modt(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_tune(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_port(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_endtie(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_nxx(u8 clock, struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xxx(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xwave(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xtype(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xatta(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xdeca(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xsust(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xrele(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xiecv(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xiecl(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xleng(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xswee(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd_0C(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd_0D(struct MP2KPlayerState *, struct MP2KTrack *);
extern struct SoundMixerState gSoundInfo;
extern struct MP2KPlayerState gMPlayInfo_BGM;
extern struct MP2KPlayerState gMPlayInfo_SE1;
extern struct MP2KPlayerState gMPlayInfo_SE2;
extern struct MP2KPlayerState gMPlayInfo_SE3;
void m4aSoundVSync(void);
void m4aSoundInit(void);
void m4aSoundMain(void);
void m4aSongNumStart(u16);
void m4aSongNumStartOrChange(u16);
void m4aSongNumStartOrContinue(u16);
void m4aSongNumStop(u16 n);
void m4aMPlayAllStop(void);
void m4aMPlayAllContinue(void);
void m4aMPlayContinue(struct MP2KPlayerState *mplayInfo);
void m4aMPlayFadeOut(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayFadeOutTemporarily(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayFadeIn(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayImmInit(struct MP2KPlayerState *mplayInfo);
void m4aMPlayTempoControl(struct MP2KPlayerState *mplayInfo, u16 tempo);
void m4aMPlayVolumeControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, u16 volume);
void m4aMPlayPitchControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s16 pitch);
void m4aMPlayPanpotControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s8 pan);
typedef struct {
               s16 window;
               s16 flags;
               s16 brightness;
               s16 speed;
               s16 bldCnt;
               s16 bldAlpha;
} ScreenFade;
extern u8 UpdateScreenFade(ScreenFade *);
void ScreenFadeUpdateValues(ScreenFade *fade);
typedef struct {
               ScreenFade fade;
               u16 character;
               u8 unkE;
} Strc_10_8055DA8;
typedef struct {
               s16 bg2pa;
               s16 bg2pb;
               s16 bg2pc;
               s16 bg2pd;
               s16 bg2x_l;
               s16 bg2x_h;
               s16 bg2y_l;
               s16 bg2y_h;
} DmaIoData;
typedef enum {
    CSI_NONE,
    CSI_PLAYER_IS_CREAM,
    CSI_PARTNER_IS_CREAM,
} ECheeseSpriteIndex;
typedef struct {
                Sprite sprite0;
                Sprite2 sprite28;
                u8 filler58[0x78];
                SpriteTransform tf[2];
                Sprite sprCheese;
                Background bg110;
                ScreenFade fade;
                DmaIoData *data15C;
                s32 *data160;
                s16 unk164;
                s16 unk166;
                u16 unk168;
                s16 unk16A;
                s16 unk16C;
                s16 unk16E;
                s16 unk170;
                s16 unk172;
                s16 unk174;
                s16 unk176;
                s16 unk178;
                u8 playerAnimIndex;
                u8 partnerAnimIndex;
                Sprite sprites17C[4];
                ECheeseSpriteIndex cheeseSpriteIndex;
} Strc_220_sub_8053128;
typedef struct {
                ScreenFade *fade;
                u16 unk4;
                int_vcount unk6;
                int_vcount unk7;
                int_vcount unk8;
                int_vcount unk9;
                s16 someXA;
                s16 someX0;
                s16 someX;
                s16 someX2;
                s16 someX3;
                s16 someX4;
                u8 unk16;
                u8 unk17;
                u8 unk18;
                u8 paramA;
                u8 paramB;
                Sprite sprite1C;
                Sprite sprite44;
                Sprite sprite6C;
                Sprite sprite94;
                Sprite spriteBC;
                Sprite spriteE4;
                Sprite sprites10C[7];
                Sprite sprite224;
                Sprite sprite24C;
} Strc_274_8053284;
typedef struct {
                ScreenFade fade;
                Sprite spritesC[3];
                Sprite sprites84[2];
                Sprite spriteD4;
                Sprite spritesFC[7];
                Sprite sprite214;
                Sprite sprite23C;
                Sprite sprite264;
                int_vcount unk28C;
                int_vcount unk28D;
                int_vcount unk28E;
                int_vcount unk28F;
                u16 unk290;
                s16 unk292;
                u16 unk294;
                s16 someX;
                s16 someX2;
                s16 someX3;
                s16 someX4;
                u8 unk29E;
                u8 unk29F;
                u8 unk2A0;
} Strc_2A4_8053284;
void sub_8053128(s16 character1, s16 character2);
void sub_80533F4(u16 character);
void sub_80534DC(Strc_220_sub_8053128 *strc220, s16, s16);
void sub_805365C(Strc_220_sub_8053128 *strc220);
void sub_80536F0(Strc_220_sub_8053128 *strc220);
void Task_220_8053904(void);
void Task_800303C(void);
void sub_8003D04(u8 zone);
void sub_8003D2C(void);
void sub_8003D84(void);
void sub_8003D88(void);
void sub_8003D8C(void);
void sub_8003DC4(u16 param0);
void sub_8003DF0(u16 song);
void sub_8003E0C(u16 song);
void sub_8003E28(u16 song);
void CreateCharacterSelect(u8 createIndex);
void CreateIceShiver(s16 param0, s16 param1, s16 param2, u16 param3, u8 param4);
u8 sub_8031BAC(Player *p);
void CreateStageMusicManager(u16 song);
void sub_80299D4(u16 songId);
void sub_80299FC();
void sub_8029A18(u16 songId);
extern const u16 gLevelSongs[];
bool32 Player_PlaySong(Player *p, u16 song);
void Player_StopSong(Player *, u16 song);
s32 sub_80110E8(u16, Player *, u8 *, u32 *);
s32 sub_801226C(Player *);
s32 sub_8012368(Player *);
s32 sub_801246C(Player *);
s32 sub_8012550(Player *);
void Player_8012FE0(Player *);
void Player_80149E4(Player *p);
void sub_8016D04(Player *p);
void sub_8016F28(Player *p);
void Player_BoostModeEngage(Player *p);
void Player_BoostModeDisengage(Player *p);
extern void Player_8004FC4(Player *p);
extern void Player_Flyer_SoundStop(Player *p);
extern void Player_800522C(Player *p);
extern void Player_80052C8(Player *p);
extern void Player_8005380(Player *p);
extern void Player_8005434(Player *p);
extern void Player_8005528(Player *p);
extern void Player_80055B8(Player *p);
extern void sub_8005800(Player *p);
extern void Player_8005BD4(Player *p);
extern void Player_8005CB8(Player *p);
extern void Player_8005DAC(Player *p);
extern void Player_8005E80(Player *p);
extern void Player_800613C(Player *p);
extern void Player_80061D8(Player *p);
extern void Player_8006250(Player *p);
extern void Player_8006310(Player *p);
extern void Player_8007930(Player *p);
extern void Player_8006424(Player *p);
extern void Player_80064D4(Player *p);
extern void Player_800657C(Player *p);
extern void Player_8006654(Player *p);
extern void Player_800673C(Player *p);
extern void Player_80068EC(Player *p);
extern void Player_8006824(Player *p);
extern void Player_HitWithoutRingsUpdate(Player *p);
extern void Player_80069E4(Player *p);
extern void Player_8006AE4(Player *p);
extern void Player_8006C70(Player *p);
extern void Player_8006CF0(Player *p);
extern void Player_8006DB8(Player *p);
extern void Player_8006E70(Player *p);
extern void Player_8006F08(Player *p);
extern void Player_8006F98(Player *p);
extern void Player_8007044(Player *p);
extern void Player_8007110(Player *p);
extern void Player_80071A8(Player *p);
extern void Player_8007240(Player *p);
extern void Player_80072D8(Player *p);
extern void Player_8007368(Player *p);
extern void Player_8007430(Player *p);
extern void Player_80074B8(Player *p);
extern void Player_8007560(Player *p);
extern void Player_8007620(Player *p);
extern void Player_8007714(Player *p);
extern void Player_80077CC(Player *p);
extern void Player_8007898(Player *p);
extern void Player_8007B00(Player *p);
extern void Player_8007C28(Player *p);
extern void Player_8007DF4(Player *p);
extern void Player_8007EAC(Player *p);
extern void Player_8007F4C(Player *p);
extern void Player_8007FE8(Player *p);
extern void Player_8008080(Player *p);
extern void Player_80082BC(Player *p);
extern void Player_8008354(Player *p);
extern void Player_800856C(Player *p);
extern void Player_8008654(Player *p);
extern void Player_800872C(Player *p);
extern void Player_80087CC(Player *p);
extern void Player_800891C(Player *p);
extern void Player_80089CC(Player *p);
extern void Player_8008A8C(Player *p);
extern void Player_8008C1C(Player *p);
extern void Player_8008CD0(Player *p);
extern void Player_800913C(Player *p);
extern void Player_8009518(Player *p);
extern void Player_80095E8(Player *p);
void Player_8009780(Player *p);
extern void sub_80099FC(Player *p);
extern void Player_80098D8(Player *p);
extern void Player_8009B4C(Player *p);
extern void Player_8009850(Player *p);
extern void Player_8009BF0(Player *p);
extern void Player_8009C94(Player *p);
extern void Player_8009D04(Player *p);
extern void sub_8009D74(Player *p);
extern void Player_8009E8C(Player *p);
extern void Player_8009F7C(Player *p, s16 someX, s16 someY);
extern void Player_800A094(Player *p);
extern void Player_800A168(Player *p);
extern void Player_800A218(Player *p);
extern void sub_800A2B8(Player *p);
extern void Player_800A3C0(Player *p);
extern void Player_800A438(Player *p);
extern void Player_800A4C8(Player *p);
extern void sub_800A540(Player *p);
extern void Player_800A5B0(Player *p);
extern void sub_800A62C(Player *p);
extern void Player_800A690(Player *p);
extern void Player_800A724(Player *p);
extern void Player_800A7CC(Player *p);
extern void Player_800A860(Player *p);
extern void Player_800A90C(Player *p);
extern void Player_800A98C(Player *p);
extern void Player_800AAC0(Player *p);
extern void Player_800AB48(Player *p);
extern void sub_800ACAC(Player *p);
extern void Player_UseSpecialSpringWithKey(Player *p);
extern void Player_800AD24(Player *p);
extern void Player_800AE14(Player *p);
extern void Player_800AEF4(Player *p);
extern void Player_800B004(Player *p);
extern void sub_800B0B0(Player *);
extern void Player_800B128(Player *p);
extern void Player_800B1B8(Player *p);
extern void Player_800B240(Player *p);
extern void Player_800B374(Player *p);
extern void Player_800B3FC(Player *p);
extern void Player_800B5A4(Player *p);
extern void Player_IceLauncherLaunch(Player *p);
extern void Player_800B628(Player *p);
extern void Player_800B6C4(Player *p);
extern void Player_800B748(Player *p);
extern void Player_800B920(Player *p);
extern void Player_800BA78(Player *p);
extern void Player_800B81C(Player *p);
extern void Player_800BB34(Player *);
extern void Player_CollideGroundAfterIceLauncher(Player *p);
extern void Player_800BC38(Player *p);
extern void Player_800BCE0(Player *p);
extern void Player_800BD88(Player *p);
extern void Player_800BE60(Player *p);
extern void Player_800BEE8(Player *p);
extern void sub_800BF78(Player *p);
extern void sub_800C064(Player *);
extern void sub_800C104(Player *);
extern void sub_800C1FC(Player *);
extern void sub_800C338(Player *);
extern void sub_800C7B8(Player *);
extern void sub_800C87C(Player *p);
extern void sub_800C910(Player *p);
extern void sub_800CBE8(Player *);
extern void sub_800CE30(Player *);
extern void sub_800CF08(Player *);
extern void sub_800D32C(Player *);
void sub_800C5D0(Player *);
void sub_800C684(Player *);
void sub_800C714(Player *);
void sub_800CF60(Player *);
void sub_800E218(Player *);
extern void sub_800EF50(Player *);
extern void sub_800EFB0(Player *);
extern void sub_800D500(Player *);
extern void sub_800D7C8(Player *p);
extern void Player_800D8DC(Player *p);
extern void Player_800D880(Player *p);
extern void Player_800D944(Player *p);
extern void Player_800D978(Player *p);
extern void Player_800D9B4(Player *p);
extern void Player_800D9F4(Player *p);
extern void SetPlayerCallback(Player *p, PlayerCallback callback);
extern void sub_800DA60(Player *p);
extern void Player_800DAF4(Player *p);
extern void sub_800EBD8(Player *p);
extern void Player_800DB30(Player *p);
extern void Player_800DB7C(Player *p);
extern void Player_800DBE8(Player *p);
extern void Player_800DCB4(Player *p);
extern void Player_800DD0C(Player *p);
extern void Player_800DD28(Player *p);
void sub_800DF10(Player *p);
extern void sub_800DF5C(Player *p);
extern void sub_800DFA0(Player *p);
void sub_800DFEC(Player *p);
extern void Player_800E084(Player *p);
extern void sub_800E150(Player *p);
extern void sub_800E198(Player *p);
extern void sub_800E508(Player *p);
extern void sub_800E968(Player *p);
extern void sub_800ECE0(Player *p);
extern void Player_800ED14(Player *p);
extern void Player_800ED4C(Player *p);
extern void sub_800ED80(Player *p);
extern void sub_800F228(Player *p);
extern void sub_800D5F4(Player *p);
extern void sub_800D81C(Player *p);
extern void Player_800DC50(Player *p);
extern void Player_800DD44(Player *p);
extern void Player_800DDB4(Player *p);
extern void Player_800DDD0(Player *p);
extern void Player_800DE48(Player *p);
extern void Player_800DE64(Player *p);
extern void Player_800DEC4(Player *p);
extern void Player_800DF9C(Player *p);
extern void sub_800E01C(Player *p);
extern void sub_800E0CC(Player *p);
extern void Player_800E1E4(Player *p);
extern void sub_800E27C(Player *p);
extern void sub_800E2C8(Player *p);
extern void Player_800E348(Player *p);
extern void Player_800E370(Player *p);
extern void Player_800E398(Player *p);
extern void Player_800E3C4(Player *p);
extern void Player_800E3EC(Player *p);
extern void Player_800E468(Player *p);
extern void Player_800E490(Player *p);
extern void Player_800E4B8(Player *p);
extern void Player_800E4E0(Player *p);
extern void Player_800E564(Player *p);
extern void Player_800E5CC(Player *p);
extern void Player_800E5D0(Player *p);
extern void Player_800E5EC(Player *p);
extern void Player_800E604(Player *p);
extern void Player_800E6CC(Player *p);
extern void Player_800E67C(Player *p);
extern void sub_800E724(Player *p);
extern void sub_800E764(Player *p);
void Player_800E7BC(Player *);
extern void Player_800E808(Player *p);
extern void sub_800E880(Player *p);
extern void sub_800E924(Player *p);
extern void Player_800E9A4(Player *p);
extern void Player_800EA0C(Player *p);
extern void Player_nullsub_800EAA8(Player *p);
extern void Player_800EAAC(Player *p);
extern void sub_800EAEC(Player *p);
extern void Player_800EA74(Player *p);
extern void sub_800EB14(Player *p);
extern void Player_800EB4C(Player *p);
extern void Player_800EB58(Player *p);
extern void Player_800EB5C(Player *p);
extern void sub_800EC20(Player *p);
extern void sub_800EC68(Player *p);
extern void Player_800ED14(Player *p);
extern void Player_800ED34(Player *p);
extern void Player_800ED80(Player *p);
extern void sub_800EDC8(Player *p);
extern void sub_800EE38(Player *p);
extern void sub_800EE64(Player *p);
extern void sub_800EEC4(Player *p);
extern void sub_800EF18(Player *p);
extern void sub_800F004(Player *);
extern void sub_800F068(Player *);
extern void sub_800F074(Player *);
extern void sub_800F080(Player *);
extern void sub_800F08C(Player *);
extern void sub_800F098(Player *);
extern void sub_800F0A4(Player *);
extern void sub_800F0B0(Player *);
extern void sub_800F0BC(Player *);
extern void sub_800F0E8(Player *);
extern void sub_800F12C(Player *p);
extern void sub_800F170(Player *p);
extern void sub_800F734(Player *p);
extern void sub_800F1C4(Player *p);
extern void sub_800F3E8(Player *p);
extern void sub_800F634(Player *p);
extern void sub_800F9C0(Player *p);
extern void Player_800FA1C(Player *p);
extern void sub_800FABC(Player *p);
extern void sub_800FD60(Player *p);
extern void sub_8010430(Player *p);
extern void sub_80105F0(Player *p);
extern void sub_80106E0(Player *p);
extern void sub_80107B4(Player *p);
extern void Player_801080C(Player *p);
extern void Player_801086C(Player *p);
extern void Player_80108B8(Player *p);
extern void Player_80108FC(Player *p);
extern void sub_8010960(Player *p);
extern void sub_801098C(Player *p);
extern void Player_80109C0(Player *p);
extern void sub_80109FC(Player *p);
extern void sub_8010A3C(Player *p);
extern void Player_8010AA0(Player *p);
extern void sub_8010AE4(Player *p);
extern void sub_8010B7C(Player *p);
extern void sub_8010BBC(Player *p);
extern void sub_8010C04(Player *p);
extern void sub_8010C98(Player *p);
extern void sub_8010CD0(Player *p);
extern void sub_8010D28(Player *p);
extern void sub_8010D70(Player *p);
extern void sub_8010DC4(Player *p);
extern void sub_8010E04(Player *p);
extern void sub_8010E4C(Player *p);
extern void sub_8010E94(Player *p);
extern void sub_8010ED0(Player *p);
extern void sub_8010F38(Player *p);
extern void Player_8010F88(Player *p);
extern void sub_8010FE0(Player *p);
extern s16 sub_801139C(Player *p);
extern s16 sub_8011434(Player *p);
extern s32 sub_8011024(s16 arg0, Player *arg1, u8 *arg2, u32 *arg3);
extern bool16 sub_80114CC(Player *p);
extern s16 sub_80116A4(s16 arg0, Player *p);
extern s16 sub_8011978(s16 arg0, Player *p);
extern void sub_8011D08(Player *p);
extern void sub_8011E70(Player *p);
extern void sub_8011FB8(Player *p);
extern void sub_8012118(Player *p);
extern void sub_8012634(Player *p);
extern void sub_80126B8(Player *);
extern void sub_8012804(Player *);
extern void sub_8012930(Player *);
extern void sub_8012A6C(Player *);
extern s32 sub_8012E18(s32, Player *, u8 *, u32 *);
extern s32 sub_8012E54(u8, Player *);
extern s16 sub_8012EA8(Player *);
extern void sub_8012EB8(Player *p);
extern void sub_8012F10(Player *p);
extern void sub_8012FA0(Player *p);
extern void sub_8012FC0(Player *p);
extern void Player_8012FE0(Player *p);
extern void Player_8012FF0(Player *p);
extern void sub_801350C(Player *p);
extern void sub_801409C(Player *p);
extern void sub_8014710(Player *p);
extern void sub_8014230(Player *p, Sprite2 *s);
extern void sub_8014258(Player *);
extern void sub_80142CC(Player *);
extern void sub_80143E0(Player *);
extern void sub_80144B4(Player *);
extern void Player_8014550(Player *p);
extern void sub_8014670(Player *p);
extern void Player_801479C(Player *p);
extern void sub_8014940(Player *p);
extern void Player_80149E4(Player *p);
extern bool32 sub_8014AF8(Player *p);
extern s16 sub_8014BC4(Player *p);
extern void sub_8014E70(Player *p);
extern void sub_8014FA4(Player *p);
extern s16 sub_8015064(Player *p);
extern void sub_8015144(Player *p);
extern void sub_80151C4(Player *p);
extern void sub_8015228(Player *p);
extern void sub_80153BC(Player *);
extern void sub_8015A44(Player *);
extern void sub_8016D30(Player *p);
extern void sub_8016E00(Player *p);
extern void sub_8016E50(Player *p);
extern void sub_8016E70(Player *);
extern void sub_8016EB0(Player *p);
extern bool32 sub_8016FA8(Player *p);
extern void sub_8017004(Player *p);
void sub_80170A0(Player *p);
extern void sub_80173F0(Player *p);
extern void Player_InitializeShieldSprite(Player *p);
extern void sub_8017618(Player *p);
void sub_8017DB4(Player *);
extern void sub_8017134(Player *p);
extern void sub_80171C0(Player *p);
extern void sub_8017258(Player *p);
extern void sub_80172F0(Player *, s16 newY);
extern void Player_8017364(Player *p);
extern void sub_801782C(Player *, s16);
extern void sub_8017914(Player *p);
extern void Player_8017D18(Player *p);
extern void Player_InitializeTagAction(Player *);
extern void sub_801816C(Player *);
extern void sub_80193A4(Player *);
extern void sub_80193CC(Player *);
extern void sub_8019718(Player *p);
extern void Player_8019858(Player *);
extern void sub_8019C24(Player *);
extern void sub_8019FF8(Player *p);
extern void sub_801A05C(Player *p);
extern void sub_801A0C0(Player *p);
extern void Player_Sonic_TrickUp(Player *p);
extern void Player_Sonic_BoundAttack(Player *);
extern void sub_801A3DC(Player *);
extern void sub_801A46C(Player *);
extern void sub_801A504(Player *p);
extern void sub_801A9EC(Player *p);
extern void sub_801AA54(Player *p);
extern void sub_801AA78(Player *);
extern void sub_801AAEC(Player *p);
extern void sub_801AB10(Player *p);
extern void sub_801AB34(Player *p);
extern void sub_801AB58(Player *p);
extern void sub_801AB7C(Player *p);
extern void sub_801ABA0(Player *p);
extern void sub_801ADF4(Player *p);
extern void sub_801AE70(Player *p);
extern void sub_801BCCC(Player *p);
extern void sub_801BD1C(Player *p);
extern void sub_801BD84(Player *p);
extern void sub_801BDD8(Player *p);
extern void sub_801BE40(Player *);
extern void sub_801BEA0(Player *p);
extern void sub_801BF08(Player *p);
extern void sub_801BF6C(Player *p);
extern void sub_801C234(Player *p);
extern void sub_801C2D8(Player *p);
extern void sub_801C348(Player *p);
extern void Player_801D73C(Player *p);
extern void sub_801D7B0(Player *p);
extern void sub_801D804(Player *p);
extern void sub_801D84C(Player *p);
extern void sub_801D8A8(Player *p);
extern void sub_801D950(Player *p);
extern void sub_801D978(Player *p);
extern void Player_801DF18(Player *p);
extern void sub_801DFC4(Player *p);
extern void sub_801E038(Player *p);
extern void sub_801E65C(Player *p);
extern void sub_801E69C(Player *p);
extern void sub_801E6F4(Player *p);
extern void sub_801E758(Player *p);
extern void sub_801E7BC(Player *);
extern void sub_801E2E4(Player *p);
extern void sub_801E828(Player *p);
extern void sub_801E358(Player *p);
extern void sub_801E888(Player *p);
extern void sub_801E8E0(Player *p);
extern void sub_801E980(Player *p);
extern void sub_801E9E0(Player *p);
extern void sub_801EB44(Player *p);
extern void sub_801EBC0(s16, Player *);
extern void sub_801ECAC(Player *p);
extern void Task_801EE74(void);
extern void sub_801EEE8(void);
extern void sub_801EFE8(void);
extern void Task_801F064(void);
extern void Task_801F184(void);
extern void Task_801F2FC(void);
extern void Task_801F418(void);
extern void Task_801F534(void);
extern void Task_801F630(void);
extern void Task_801F6D8(void);
extern void Task_801F740(void);
extern void Task_801F848(void);
extern void Task_801F8D8(void);
extern void Task_801F970(void);
extern void Task_801F9D4(void);
extern void Task_801FA64(void);
extern void Task_801FAFC(void);
extern void Task_801FBA8(void);
extern void Task_801FC2C(void);
extern void Task_801FCD8(void);
extern void Task_801FDAC(void);
extern void Task_801FED0(void);
extern void Task_8020038(void);
extern void sub_8020130(s16);
extern void sub_8020284(void);
extern void TaskDestructor_Cheese(struct Task *t);
extern void Task_802056C(void);
extern void Task_80205F4(void);
extern void Task_8020660(void);
extern void Task_80206B0(void);
extern void CreateCheeseIfPlayerIsCream(Player *p);
extern void sub_8020444(Player *p);
extern void sub_8020488(Player *p);
extern void sub_802051C(Player *p);
extern void sub_8020530(Player *p);
extern void sub_8020544(Player *p);
extern void sub_8020558(Player *p);
extern void sub_80274AC(u16, u16);
extern void sub_802AE64(Player *, s16);
void sub_8019E94(Player *p);
void sub_801A05C(Player *p);
void sub_801A0C0(Player *p);
void sub_801A1D4(Player *p);
void sub_801A280(Player *p);
void sub_801A2DC(Player *p);
void sub_801A330(Player *p);
void sub_801A38C(Player *p);
void sub_801A5A0(Player *p);
void sub_801A644(Player *p);
void sub_801A7FC(Player *p);
void sub_801ADC0(Player *p);
void sub_801A87C(Player *p);
void sub_801AC04(Player *p);
void sub_801AC58(Player *p, u16);
void sub_801ACBC(Player *p, u16);
void sub_801AD10(Player *p);
void sub_801AD64(Player *p);
void sub_801B11C(Player *p);
void sub_801B1B0(Player *p);
void sub_801B458(Player *p);
void sub_801B58C(Player *p);
void sub_801B608(Player *p);
void sub_801B6A8(Player *p);
void sub_801B9A8(Player *p);
void sub_801BA2C(Player *p);
void sub_801B824(Player *p);
void sub_801BAFC(Player *p);
void sub_801BC48(Player *p);
void sub_801BFD4(Player *p);
void sub_801C00C(Player *p);
void sub_801C068(Player *p);
void sub_801C098(Player *p);
void sub_801C14C(Player *p);
void sub_801C1D4(Player *p);
void sub_801CB68(Player *p);
s32 sub_801C884(Player *);
void sub_801CE94(Player *p);
void sub_801CFFC(Player *p);
void sub_801CF4C(Player *p);
void sub_801D16C(Player *p);
void Player_801D1D0(Player *p);
bool16 sub_801D2FC(Player *p);
void sub_801D3F0(Player *p);
void sub_801D8E8(Player *p);
void sub_801D9D0(Player *p);
void sub_801DCDC(Player *p);
void sub_801DD2C(Player *p);
void sub_801DE1C(Player *);
void sub_801DE94(Player *p);
void sub_801DEE4(Player *p);
void sub_801DF80(Player *p);
void sub_801C4A0(Player *p);
void sub_801C934(Player *p);
void sub_801CA00(Player *p);
void sub_801CC14(Player *p);
void sub_801CFA4(Player *p);
void sub_801D0E8(Player *p);
void sub_801D550(Player *p);
void sub_801DD00(Player *p);
void sub_801E4C0(Player *p);
void sub_801E92C(Player *p);
void sub_801EAF4(Player *p);
void sub_801CD50(Player *p);
void Player_801D1D0(Player *p);
void sub_8012BA4(Player *);
void sub_8012F94(Player *p, s8 spriteOffsetX, s8 spriteOffsetY);
void sub_801C414(Player *p);
void sub_801CCB4(Player *);
void sub_801CD50(Player *p);
void sub_801DC60(Player *);
void sub_801DD68(Player *);
void sub_801DDF4(Player *p);
void sub_801D684(Player *p);
void sub_801DA04(Player *p);
void sub_801DA74(Player *p);
void sub_801DB20(Player *p);
void sub_801DB70(Player *p);
void sub_801DBD0(Player *p);
void sub_801DC34(Player *p);
void sub_801EA44(Player *p);
void sub_801EA9C(Player *p);
void sub_801EB94(Player *p);
void sub_801E120(Player *p);
void sub_801E4C0(Player *p);
void sub_801E2E4(Player *p);
extern void sub_8019B4C(Player *p);
extern void sub_8015C90(Player *p, u32 param2);
s32 sub_80210BC(Player *playerA, s16 hbIndexA, Player *playerB, s16 hbIndexB);
extern void sub_80293E8(Player *p);
extern u16 gMedalTimes[][2];
extern u16 gCameraMaxCoords[][2];
typedef s32 (*Func801F100)(s32, s32, s32);
s32 sa2__sub_801EB44(s32, s32, s32);
s32 sa2__sub_801EC3C(s32, s32, s32);
typedef s32 (*Func801F07C)(s32, s32, s32, u8 *);
s32 sa2__sub_801ED24(s32, s32, s32, u8 *);
s32 sa2__sub_801EE64(s32, s32, s32, u8 *);
s32 sa2__sub_801F07C(s32, s32, s32, s32, u8 *, Func801F07C);
s32 sa2__sub_801E4E4(s32, s32, s32, s32, u8 *, Func801F07C);
s32 sa2__sub_801E6D4(s32, s32, s32, s32, u8 *, Func801F07C);
void sa2__sub_801F044(void);
s32 sa2__sub_801F100(s32, s32, s32, s32, Func801F100);
extern const Collision *gRefCollision;
extern const Collision *const gCollisionTable[];
typedef struct {
    u16 jump;
    u16 attack;
    u16 trick;
} ButtonConfig;
typedef struct {
    u8 jump;
    u8 attack;
    u8 trick;
} ButtonConfigPacked;
extern ButtonConfig gPlayerControls;
void SetPlayerControls(u16 jump, u16 attack, u16 trick);
enum eLanguage { JAPANESE = 0, ENGLISH = 1, GERMAN = 2, FRENCH = 3, SPANISH = 4, ITALIAN = 5, NUM_LANGUAGES };
typedef struct {
    u8 Act1 : 1;
    u8 Act2 : 1;
    u8 Act3 : 1;
    u8 Boss : 1;
    u8 BonusCapsule : 1;
    u8 BonusEnemies : 1;
    u8 Bit7 : 1;
} ZoneCompletion;
typedef struct {
    u8 Bronze : 1;
    u8 Silver : 1;
    u8 Gold : 1;
} MedalCollection;
typedef struct {
               u32 playerId;
               u16 playerName[6];
               bool8 slotFilled;
               u8 wins;
               u8 losses;
               u8 draws;
} VsRecords;
typedef struct {
               u8 slotFilled;
               u8 wins;
               u8 draws;
               u8 losses;
               u32 playerId;
               u16 playerName[6];
} VsRecords2;
typedef struct TimeRecord {
    u8 character1;
    u8 character2;
    u16 time;
} TimeRecord;
typedef struct TimeRecords {
    TimeRecord table[7][4][5];
} TimeRecords;
typedef struct {
               u32 playerId;
               u16 playerName[6];
               u8 unlockedCharacters;
               u8 unlockedZones;
               u8 continueZone;
               u8 unk13;
               u16 chaoCount[7];
               u8 specialKeys[7];
               u8 unlockedStages[9];
               u8 collectedEmeralds;
               u8 unlockFlags;
               u16 unk34;
               u8 unk36;
               u8 collectedMedals[9][4];
               u8 unk5B;
               u8 unk5C;
               u8 unk5D;
               u16 unk5E;
               u8 vsWins;
               u8 vsLosses;
               u8 vsDraws;
               u8 unk63;
               VsRecords vsRecords[10];
                TimeRecords timeRecords;
                ButtonConfig buttonConfig;
                u8 difficulty;
                bool8 disableTimeLimit;
                u8 language;
                u8 unk367;
} SaveGame;
extern SaveGame gLoadedSaveGame;
extern SaveGame gUnknown_03000980;
typedef struct SaveSectorHeader {
                u32 magicNumber;
                u32 sectorId;
} SaveSectorHeader;
typedef struct {
    SaveSectorHeader header;
                u32 playerId;
                u16 playerName[6];
                u8 unk18;
                u8 unlockedCharacters;
                u8 unlockedZones;
                u8 continueZone;
                u8 unk1C;
                u16 chaoCount[7];
                u8 specialKeys[7];
                u8 unlockedStages[9];
                u8 collectedEmeralds;
                u8 unlockFlags;
                u8 collectedMedals[9][4];
                u16 unk62;
                u8 vsWins;
                u8 vsDraws;
                u8 vsLosses;
    u8 unk67;
    VsRecords2 vsRecords[10];
                TimeRecords timeRecords;
                ButtonConfigPacked buttonConfig;
                u8 difficulty;
                bool8 disableTimeLimit;
                u8 language;
                u8 unk367;
                u32 checksum;
} SaveSectorData;
extern SaveSectorData gSaveSectorData;
void InsertMultiplayerProfile(u32 playerId, u16 *name);
void RecordOwnMultiplayerResult(s16 result);
void RecordMultiplayerResult(u32 id, u16 *name, s16 result);
void SaveInit(void);
bool16 SaveGameExists(void);
s16 NewSaveGame(void);
s16 LoadSaveGame(void);
void LoadCompletedSaveGame(void);
bool32 WriteSaveGame(void);
typedef struct {
               s32 qWorldX;
               s32 qWorldY;
               s32 qWorldX2;
               s32 qWorldY2;
               s16 unk10;
               s16 unk12;
               s16 unk14;
               u16 moveState;
               u8 unk18;
               u8 unk19;
               u8 unk1A;
               u8 unk1B;
               u8 unk1C;
               u8 unk1D;
               u8 filler1E[0x2];
               Sprite2 s;
               Player *player;
               Player *unk54;
} Cheese;
typedef struct WaterRange {
    u16 minX, minY;
    u16 maxX, maxY;
} WaterRange;
typedef enum {
    CS_GBA = 0,
    CS_GBA_SP = 1,
    CS_GB_PLAYER = 2,
} EColorSetting;
typedef struct {
               u8 language;
               u8 difficulty;
               u8 unk2;
               u8 gameMode;
               u8 unk4;
               u8 unk5;
               u8 playerIndex;
               u8 unk7;
               u8 colorSetting;
               u8 zone;
               u8 act;
               u8 warpId;
               u8 unkC;
               u8 unkD;
               u16 currentLevel;
               u16 unk10;
               u16 nextMapIndex;
               ButtonConfig buttonConfig;
               u32 timer;
               u8 unk20;
               u8 unk21;
               u8 filler22[2];
               u32 unk24;
               u16 respawnX;
               u16 respawnY;
               u8 platformTimerEnableBits;
               u8 springTimerEnableBits;
               u16 platformTimers[8];
               u16 springTimers[8];
               s16 unk4E[8];
               s16 unk5E[8];
               s16 unk6E[8];
               WaterRange *waterRanges;
               u8 waterRangesCount;
               u8 unk85;
               u8 unk86;
               u8 flagSpKey;
               struct Task *taskBoss;
               u16 unk8C;
               u8 mpOpponentPlayerIndex;
               u8 unk8F;
               struct Task *task90;
               struct Task *taskEntitiesManager;
               struct Task *taskCheese;
               struct Task *taskAfterImages;
               struct Task *taskA0;
               struct Task *taskA4;
               struct Task *taskA8;
               u16 rings;
               u16 levelTimer;
               u16 stageFlags;
               u16 unkB2;
               u8 lives;
               u8 unkB5;
               u8 unkB6;
               u8 unkB7;
               u8 unkB8;
               u8 unkB9;
               u8 unkBA;
               u8 unkBB;
               u8 unkBC;
               u8 unkBD;
               u8 unkBE[7];
} StageData;
extern StageData gStageData;
typedef struct AfterImages {
               SpriteTransform tf;
               Sprite2 s;
               u8 unk3C;
} AfterImages;
typedef struct TaskA8 {
               u16 unk0;
               u8 unk2;
               u8 unk3;
} TaskA8;
typedef enum {
    ACT_TYPE_ACT_1 = 0x01,
    ACT_TYPE_ACT_2 = 0x02,
    ACT_TYPE_ACT_3 = 0x04,
    ACT_TYPE_BOSS = 0x08,
    ACT_TYPE_MINIGAME_CAPSULE = 0x10,
    ACT_TYPE_MINIGAME_ENEMIES = 0x20,
    ACT_TYPE_40 = 0x40,
    ACT_TYPE_80 = 0x80,
} eActType;
typedef enum ERingSpeedFactor {
    RSF_0,
    RSF_1,
    RSF_2,
    RSF_3,
    RSF_4,
    RSF_COUNT
} ERingSpeedFactor;
void sub_8019150(void);
s16 sub_8015064(Player *p);
typedef struct {
    AnimId anim;
    u16 variant;
} TileInfoShield;
typedef struct Strc_800FF68 {
               s32 qWorldX;
               s32 qWorldY;
               s16 unk8;
               u16 unkA;
               u8 fillerC[0x4];
               Player *p;
               Sprite s;
} Strc_800FF68;
typedef struct Strc_PlayerStrc2C {
               Sprite s;
               s16 unk28;
               s16 unk2A;
} Strc_PlayerStrc2C;
typedef struct Strc_PlayerStrc2C_2 {
               Sprite s;
               Player *p;
} Strc_PlayerStrc2C_2;
typedef struct Strc_PlayerStrc30 {
               Sprite s;
               Player *p;
               s16 someY;
} Strc_PlayerStrc30;
typedef struct Strc_PlayerStrc30_2 {
               Sprite s;
               s16 someY;
               Player *p;
} Strc_PlayerStrc30_2;
typedef struct Strc_PlayerStrc50 {
               Sprite s;
               Player *p;
               s8 unk2C;
               s8 unk2D;
               s16 unk2E[8][2];
} Strc_PlayerStrc50;
typedef struct PlayerStrcCC_Sprite {
    Sprite s;
    u8 unk28;
    u8 filler29[0x1];
    s16 worldX;
    s16 worldY;
    u8 filler2E[0x2];
} PlayerStrcCC_Sprite;
typedef struct Strc_PlayerStrcCC {
               u8 *vram;
               s16 unk4;
               s16 unk6;
               Player *p;
               PlayerStrcCC_Sprite sprites[4];
} Strc_PlayerStrcCC;
typedef struct Strc_PlayerUnkE0 {
               void *vram;
               Sprite s;
               Sprite s2;
               Vec2_16 unk54[10];
               s16 unk7C;
               s16 unk7E;
               s16 unk80[12][2];
               s16 unkB0[12][2];
} Strc_PlayerUnkE0;
typedef struct SomeSubStruct_3001BF0 {
               s32 qWorldX;
               s32 qWorldY;
               u32 frameFlags;
               u32 moveState;
               s16 anim2;
               s16 rotation;
               s8 state1;
               s8 animSpeed;
} SomeSubStruct_3001BF0;
typedef struct Strc_03001BF0 {
    SomeSubStruct_3001BF0 unk0[8];
    Player *unkC0;
    u8 index;
} Strc_03001BF0;
extern Strc_03001BF0 gUnknown_03001BF0;
typedef struct MusicManagerState {
    u8 unk0;
    u8 unk1;
    u8 unk2;
    u8 unk3;
    u8 unk4;
    u8 unk5;
    u16 fadeoutSpeed;
} MusicManagerState;
extern MusicManagerState gMusicManagerState;
extern u16 gMedalTimes[][2];
extern u8 gUnknown_080CF468[];
extern s16 gUnknown_080CF470[][2];
const s16 gUnknown_080CE5B8[9] = {
    ((s32)((6.00)*256)), ((s32)((6.375)*256)), ((s32)((6.75)*256)), ((s32)((7.125)*256)), ((s32)((7.50)*256)), ((s32)((7.875)*256)), ((s32)((8.25)*256)), ((s32)((8.625)*256)), ((s32)((9.00)*256)),
};
extern const s16 gUnknown_080CECB2[RSF_COUNT][2];
extern const s16 gUnknown_080CECC6[RSF_COUNT];
extern s16 gUnknown_080CECD0[NUM_CHARACTERS][2];
extern s16 gUnknown_080CECE4[NUM_CHARACTERS][2];
extern u16 gCameraMaxCoords[][2];
extern Vec2_16 *gRespawnPositions[];
extern PlayerSpriteInfo gUnknown_030010D0;
extern PlayerSpriteInfo gUnknown_0300110C;
extern PlayerSpriteInfo gUnknown_03001B00[4];
extern TileInfoShield sTileInfoShields[];
extern u16 gUnknown_08E2EAD0[][3];
extern u16 gUnknown_08E2EB04[NUM_CHARACTERS][2];
extern u16 gCheeseTileInfo[][2];
static inline void SongStopCheck_inline(Player *p, u16 song)
{
    if ((gStageData.gameMode) != 7) {
        if (p->moveState & 0x00001000) {
            Player_StopSong(p, song);
        }
    }
}
static inline void BoostEngage_inline(Player *p)
{
    if (p->unk148.ptr->a.unkC != 0) {
        p->unk148.ptr->a.unkC -= 1;
    } else {
        Player_BoostModeEngage(p);
    }
}
static inline void sub_8015568__shared_inline(Player *p)
{
    Player *partner = ((1 != 0) ? &gPlayers[p->charFlags.partnerIndex] : &gPlayers[gStageData.playerIndex]);
    sub_80193A4(p);
    Player_StopSong(p, 0x21C);
    if (p->moveState & 0x00400000) {
        p->timeSinceTagActionCharge = 0;
        p->moveState &= ~0x00400000;
    }
    if (0x00800000 & p->moveState) {
        p->moveState &= ~0x00800000;
        partner->qWorldX = p->qWorldX;
        partner->qWorldY = p->qWorldY;
        partner->moveState &= 0xFEFFFFFF;
    }
}
static inline void AdvanceVariant(Player *p)
{
    if (p->taskTagAction != ((void *)0)) {
        Strc_PlayerStrc30 *strcTag = (void *)(0x03000000 + ((p->taskTagAction)->data));
        strcTag->s.variant = 1;
        p->taskTagAction->main = sub_8019150;
    }
}
bool16 IsInWater(s16 worldX, s16 worldY, s16 *outYPos);
void Player_StopSong(Player *p, u16 song);
extern u8 *gDemoRecordings[];
void DemoPlayAlloc(Player *p, s16 zoneIndex);
void DemoPlayFree(Player *p);
void Player_8005380(Player *p);
void Player_80077CC(Player *p);
void SetPlayerCallback(Player *p, void (*callback)(Player *));
const s16 gUnknown_080CE5FC[8] = {
    0x112, 0x117, 0x115, 0x119, 0x113, 0x118, 0x114, 0x116,
};
const s16 gUnknown_080CE60C[8] = {
    0x11A, 0x11F, 0x11D, 0x121, 0x11B, 0x120, 0x11C, 0x11E,
};
const s16 gUnknown_080CE61C[8][2] = {
    { 0x0800, 0x0000 },
    { 0x0599, 0x0599 },
    { 0x0000, 0x0800 },
    { 0xFA67, 0x0599 },
    { 0xF800, 0x0000 },
    { 0xFA67, 0xFA67 },
    { 0x0000, 0xF800 },
    { 0x0599, 0xFA67 },
};
s16 sub_801139C(Player *p);
s16 sub_8011434(Player *p);
static inline void test(Player *p, s32 qSpeedCap, u8 layer, bool32 negative)
{
    s32 worldX;
    s32 worldY;
    s32 res;
    s32 delta;
    u8 mask;
    if (negative) {
        worldX = -3 - p->spriteOffsetY + ((int)((p->qWorldX) >> 8));
        worldY = ((int)((p->qWorldY) >> 8));
    } else {
        worldX = +((int)((p->qWorldY) >> 8));
        worldX += +3 + p->spriteOffsetY;
        worldY = ((int)((p->qWorldX) >> 8));
    }
    mask = layer;
    if (p->qSpeedAirY <= qSpeedCap - 1) {
        mask |= 0x80;
    }
    if (negative) {
        delta = -8;
    } else {
        delta = +8;
    }
    res = sa2__sub_801E4E4(worldX, worldY, mask, delta, ((void *)0), sa2__sub_801EE64);
    if (res <= 0) {
        p->qWorldY -= ((s32)((res)*256));
    }
}
extern const u16 gUnknown_080CE7E2[][2];
extern const s16 gUnknown_080CE6A8[4][2];
const s16 gUnknown_080CE6A8[4][2] = {
    { 0x14A, 0x351 },
    { 0x640, 0x411 },
    { 0x0F0, 0x261 },
    { 0x4B8, 0x141 },
};
void Player_80149E4(Player *p);
const s16 gUnknown_080CE6B8[NUM_CHARACTERS][2] = {
    [SONIC] = { 0x0160, 0x02C0 }, [CREAM] = { 0x01C0, 0x0380 }, [TAILS] = { 0x01A0, 0x0340 },
    [KNUCKLES] = { 0x0140, 0x0280 }, [AMY] = { 0x0180, 0x0300 },
};
void sub_8016D30(Player *p);
void sub_8016E50(Player *p);
void sub_8017004(Player *p);
const s8 gUnknown_080CE7A8[][2] = { { +18, -20 }, { +00, -24 }, { -16, -14 }, { -24, +00 } };
const s8 gUnknown_080CE7B0[][2] = { { -19, +21 }, { -23, +12 }, { -23, +05 }, { -23, -05 } };
const s8 gUnknown_080CE7B8[][2] = { { -16, -14 }, { -22, +00 }, { -16, +14 }, { +00, +22 } };
const s8 gUnknown_080CE7C0[][2] = { { -26, -02 }, { -02, +8 }, { +25, -2 }, { +16, -6 } };
const s8 gUnknown_080CE7C8[][2] = { { +5, +0 }, { -5, +0 }, { +0, +5 }, { +0, -5 }, { +4, +4 }, { +4, -4 }, { -4, +4 }, { -4, -4 } };
void sub_8019150(void);
void sub_80193A4(Player *p);
const s16 gPlayerCharacterIdleAnims[NUM_CHARACTERS] = {
    [SONIC] = 0, [CREAM] = 163, [TAILS] = 326, [KNUCKLES] = 489, [AMY] = 652,
};
const u16 gUnknown_080CE7E2[][2] = {
    { 0, 0 },
    { 0x1, 0 },
    { 0x2, 0 },
    { 0x3, 0 },
    { 0x4, 0 },
    { 0x5, 0 },
    { 0x6, 0 },
    { 0x7, 0 },
    { 0x8, 0 },
    { 0x9, 0 },
    { 0xa, 0 },
    { 0xb, 0 },
    { 0xc, 0 },
    { 0xd, 0 },
    { 0xe, 0 },
    { 0xf, 0 },
    { 0x10, 0 },
    { 0x11, 0 },
    { 0x12, 0 },
    { 0x13, 0 },
    { 0x14, 0 },
    { 0x15, 0 },
    { 0x16, 0 },
    { 0x17, 0 },
    { 0x18, 0 },
    { 0x19, 0 },
    { 0x1a, 0 },
    { 0x1b, 0 },
    { 0x1c, 0 },
    { 0x1d, 0 },
    { 0x1e, 0 },
    { 0x1f, 0 },
    { 0x20, 0 },
    { 0x21, 0 },
    { 0x22, 0 },
    { 0x23, 0 },
    { 0x24, 0 },
    { 0x25, 0 },
    { 0x26, 0 },
    { 0x27, 0 },
    { 0x28, 0 },
    { 0x29, 0 },
    { 0x2a, 0 },
    { 0x2b, 0 },
    { 0x2c, 0 },
    { 0x2d, 0 },
    { 0x2e, 0 },
    { 0x2f, 0 },
    { 0x30, 0 },
    { 0x31, 0 },
    { 0x32, 0 },
    { 0x33, 0 },
    { 0x34, 0 },
    { 0x35, 0 },
    { 0x36, 0 },
    { 0x37, 0 },
    { 0x38, 0 },
    { 0x38, 0 },
    { 0x3a, 0 },
    { 0x3b, 0 },
    { 0x3c, 0 },
    { 0x3d, 0 },
    { 0x3e, 0 },
    { 0x3f, 0 },
    { 0x40, 0 },
    { 0x41, 0 },
    { 0x42, 0 },
    { 0x43, 0 },
    { 0x44, 0 },
    { 0x45, 0 },
    { 0x46, 0 },
    { 0x47, 0 },
    { 0x48, 0 },
    { 0x49, 0 },
    { 0x4a, 0 },
    { 0x4b, 0 },
    { 0x4c, 0 },
    { 0x4d, 0 },
    { 0x4e, 0 },
    { 0x4f, 0 },
    { 0x50, 0 },
    { 0x51, 0 },
    { 0x52, 0 },
    { 0x53, 0 },
    { 0x54, 0 },
    { 0x55, 0 },
    { 0x56, 0 },
    { 0x57, 0 },
    { 0x58, 0 },
    { 0x59, 0 },
    { 0x5a, 0 },
    { 0x5b, 0 },
    { 0x5c, 0 },
    { 0x5d, 0 },
    { 0x5e, 0 },
    { 0x5f, 0 },
    { 0x60, 0 },
    { 0x61, 0 },
    { 0x62, 0 },
    { 0x63, 0 },
    { 0x64, 0 },
    { 0x65, 0 },
    { 0x66, 0 },
    { 0x67, 0 },
    { 0x68, 0 },
    { 0x69, 0 },
    { 0x6a, 0 },
    { 0x6b, 0 },
    { 0x6c, 0 },
    { 0x6d, 0 },
    { 0x59, 0 },
    { 0x6f, 0 },
    { 0x6d, 0 },
    { 0x71, 0 },
    { 0x72, 0 },
    { 0x73, 0 },
    { 0x74, 0 },
    { 0x75, 0 },
    { 0x76, 0 },
    { 0x77, 0 },
    { 0x78, 0 },
    { 0x79, 0 },
    { 0x7a, 0 },
    { 0x7b, 0 },
    { 0x7c, 0 },
    { 0x7d, 0 },
    { 0x7e, 0 },
    { 0x7f, 0 },
    { 0x80, 0 },
    { 0x81, 0 },
    { 0x82, 0 },
    { 0x83, 0 },
    { 0x84, 0 },
    { 0x85, 0 },
    { 0x86, 0 },
    { 0x87, 0 },
    { 0x88, 0 },
    { 0x89, 0 },
    { 0x8a, 0 },
    { 0x8b, 0 },
    { 0x8c, 0 },
    { 0x8d, 0 },
    { 0x8e, 0 },
    { 0x8f, 0 },
    { 0x90, 0 },
    { 0x91, 0 },
    { 0x92, 0 },
    { 0x93, 0 },
    { 0x94, 0 },
    { 0x95, 0 },
    { 0x96, 0 },
    { 0x97, 0 },
    { 0x98, 0 },
    { 0x99, 0 },
    { 0x9a, 0 },
    { 0x9b, 0 },
    { 0x9c, 0 },
    { 0x9d, 0 },
    { 0x9e, 0 },
    { 0x9f, 0 },
    { 0xa0, 0 },
    { 0xa1, 0 },
    { 0xa2, 0 },
    { 0x39, 0 },
    { 0x39, 1 },
    { 0x25, 0 },
    { 0x26, 0 },
    { 0x2b, 0 },
    { 0x2a, 0 },
    { 0x69, 0 },
    { 0x6b, 0 },
    { 0x19, 0 },
    { 0x50, 0 },
    { 0x68, 0 },
    { 0x60, 0 },
    { 0x5e, 0 },
    { 0x5f, -1 },
    { 0x73, 0 },
    { 0x73, 1 },
    { 0x75, 0 },
    { 0xc8, 0 },
    { 0xc9, 0 },
    { 0xcb, 0 },
    { 0xcc, 0 },
    { 0xcd, 0 },
    { 0xce, 0 },
    { 0xd2, 0 },
    { 0xf4, 0 },
    { 0xbc, 0 },
    { 0xbc, 1 },
    { 0xbd, 0 },
    { 0xbe, 0 },
    { 0xc0, 0 },
    { 0xee, 0 },
    { 0xef, 0 },
    { 0xf0, 0 },
    { 0xf1, 0 },
    { 0x10b, 0 },
    { 0x10c, 0 },
    { 0x103, 0 },
    { 0x101, 0 },
    { 0x102, -1 },
    { 0x16b, 0 },
    { 0x16c, 0 },
    { 0x170, 0 },
    { 0x171, 0 },
    { 0x15f, 0 },
    { 0x19d, 0 },
    { 0x160, 0 },
    { 0x163, 0 },
    { 0x163, 1 },
    { 0x164, 0 },
    { 0x165, 0 },
    { 0x166, 0 },
    { 0x189, 0 },
    { 0x18a, 0 },
    { 0x18b, 0 },
    { 0x18c, 0 },
    { 0x18d, 0 },
    { 0x1ae, 0 },
    { 0x1af, 0 },
    { 0x1b1, 0 },
    { 0x19b, 0 },
    { 0x1a6, 0 },
    { 0x1a4, 0 },
    { 0x1a5, -1 },
    { 0x20e, 0 },
    { 0x20f, 0 },
    { 0x239, 0 },
    { 0x23a, 0 },
    { 0x213, 0 },
    { 0x202, 0 },
    { 0x203, -1 },
    { 0x204, 0 },
    { 0x205, 0 },
    { 0x206, 1 },
    { 0x206, 0 },
    { 0x208, 0 },
    { 0x23b, 0 },
    { 0x23c, 2 },
    { 0x234, 0 },
    { 0x235, 0 },
    { 0x236, 0 },
    { 0x237, 0 },
    { 0x21f, 0 },
    { 0x23c, 3 },
    { 0x5f3, 0 },
    { 0x296, 0 },
    { 0x2c0, 0 },
    { 0x2bc, 0 },
    { 0x2bd, 0 },
    { 0x2be, 0 },
    { 0x2f8, 0 },
    { 0x2a5, 0 },
    { 0x2b1, 0 },
    { 0x2b2, 0 },
    { 0x2f7, 0 },
    { 0x2d5, 0 },
    { 0x2d6, 0 },
    { 0x2b7, 0 },
    { 0x2b8, 0 },
    { 0x2a9, 0 },
    { 0x2ab, 0 },
    { 0x2f4, 0 },
    { 0x2f5, 0 },
    { 0x2ec, 0 },
    { 0x2ea, 0 },
    { 0x2eb, -1 },
    { 0x2b1, 0 },
    { 0x2e2, 0 },
    { 1305, 2 },
    { 1305, 1 },
    { 1305, 3 },
    { 1305, 0 },
    { 1305, 6 },
    { 1305, 14 },
    { 1305, 18 },
    { 1305, 10 },
    { 1305, 4 },
    { 1305, 8 },
    { 1305, 16 },
    { 1305, 12 },
    { 1305, 7 },
    { 1305, 15 },
    { 1305, 19 },
    { 1305, 11 },
    { 1305, 5 },
    { 1305, 9 },
    { 1305, 17 },
    { 1305, 13 },
    { 1306, 0 },
    { 1306, 1 },
    { 1312, 0 },
    { 1308, 0 },
    { 1308, 1 },
    { 1308, 2 },
    { 1308, 3 },
    { 1308, 4 },
    { 1308, 5 },
    { 1308, 6 },
    { 1271, 0 },
    { 1271, 2 },
    { 1271, 3 },
    { 1271, 1 },
    { 1271, 4 },
    { 1271, 0 },
    { 1271, 5 },
    { 1271, 0 },
};
const s16 gUnknown_080CECB2[RSF_COUNT][2] = {
    { 8, ((s32)((0.25)*256)) }, { 12, ((s32)((0.25)*256)) }, { 14, ((s32)((0.25)*256)) }, { 16, ((s32)((0.25)*256)) }, { 18, ((s32)((0.25)*256)) },
};
const s16 gUnknown_080CECC6[RSF_COUNT] = {
    ((s32)((8.00)*256)), ((s32)((7.96875)*256)), ((s32)((6.5625)*256)), ((s32)((5.625)*256)), ((s32)((4.21875)*256)),
};
void Player_BoostModeEngage(Player *p);
