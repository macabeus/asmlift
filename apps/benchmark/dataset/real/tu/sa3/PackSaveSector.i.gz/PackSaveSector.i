typedef long int ptrdiff_t;
typedef unsigned long int size_t;
typedef int wchar_t;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef int int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef uint16_t winreg_t;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
typedef u16 MetatileIndexType;
typedef u8 int_vcount;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef u8 bool8;
typedef u16 bool16;
typedef u32 bool32;
struct BgCnt
{
    u16 priority:2;
    u16 charBaseBlock:2;
    u16 dummy:2;
    u16 mosaic:1;
    u16 palettes:1;
    u16 screenBaseBlock:5;
    u16 areaOverflowMode:1;
    u16 screenSize:2;
};
typedef volatile struct BgCnt vBgCnt;
struct PlttData
{
    u16 r:5;
    u16 g:5;
    u16 b:5;
    u16 unused_15:1;
};
typedef struct __attribute__((packed)) OamDataShort { u32 y : 8; u32 affineMode : 2; u32 objMode : 2; u32 mosaic : 1; u32 bpp : 1; u32 shape : 2; u32 x : 9; u32 matrixNum : 5; u32 size : 2; u16 tileNum : 10; u16 priority : 2; u16 paletteNum : 4; } OamDataShort;;
typedef union {
    struct {
             u32 y:8;
             u32 affineMode:2;
             u32 objMode:2;
             u32 mosaic:1;
             u32 bpp:1;
             u32 shape:2;
             u32 x:9;
             u32 matrixNum:5;
             u32 size:2;
             u16 tileNum:10;
             u16 priority:2;
             u16 paletteNum:4;
             u16 fractional:8;
             u16 integer:7;
             u16 sign:1;
    } split;
    struct {
        u16 attr0;
        u16 attr1;
        u16 attr2;
        u16 affineParam;
    } all;
    u16 raw[4];
} OamData;
struct BgAffineSrcData
{
    s32 texX;
    s32 texY;
    s16 scrX;
    s16 scrY;
    s16 sx;
    s16 sy;
    u16 alpha;
};
struct BgAffineDstData
{
    s16 pa;
    s16 pb;
    s16 pc;
    s16 pd;
    s32 dx;
    s32 dy;
};
struct ObjAffineSrcData
{
    s16 xScale;
    s16 yScale;
    u16 rotation;
};
struct SioNormalCnt
{
    u16 sck_I_O:1;
    u16 sck:1;
    u16 ackRecv:1;
    u16 ackSend:1;
    u16 unused_6_4:3;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct SioMultiCnt
{
    u16 baudRate:2;
    u16 si:1;
    u16 sd:1;
    u16 id:2;
    u16 error:1;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u16 data;
};
struct SioUartCnt
{
    u16 baudRate:2;
    u16 ctsEnable:1;
    u16 paritySelect:1;
    u16 transDataFull:1;
    u16 recvDataEmpty:1;
    u16 error:1;
    u16 length:1;
    u16 fifoEnable:1;
    u16 parityEnable:1;
    u16 transEnable:1;
    u16 recvEnable:1;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct JoyCnt
{
    u8 ifReset:1;
    u8 ifRecv:1;
    u8 ifSend:1;
    u8 unused_5_3:3;
    u8 ifEnable:1;
    u8 unused_7:1;
};
struct JoyStat
{
    u8 unused_0:1;
    u8 recv:1;
    u8 unused_2:1;
    u8 send:1;
    u8 flags:2;
    u8 unused_7_6:2;
};
struct RCnt
{
    u8 sc:1;
    u8 sd:1;
    u8 si:1;
    u8 so:1;
    u8 sc_i_o:1;
    u8 sd_i_o:1;
    u8 si_i_o:1;
    u8 so_i_o:1;
    u8 ifEnable:1;
    u8 unused_13_9:5;
    u8 sioModeMaster:2;
};
struct MultiBootParam
{
    u32 system_work[5];
    u8 handshake_data;
    u8 padding;
    u16 handshake_timeout;
    u8 probe_count;
    u8 client_data[3];
    u8 palette_data;
    u8 response_bit;
    u8 client_bit;
    u8 reserved1;
    u8 *boot_srcp;
    u8 *boot_endp;
    u8 *masterp;
    u8 *reserved2[3];
    u32 system_work2[4];
    u8 sendflag;
    u8 probe_target_bit;
    u8 check_wait;
    u8 server_type;
};
typedef struct {
    u32 srcLength : 16;
    u32 srcWidth : 8;
    u32 dstWidth : 8;
} BitUnPackData;
void SoftReset(u32 resetFlags);
void SoftResetExram(u32 resetFlags);
void RegisterRamReset(u32 resetFlags);
void VBlankIntrWait(void);
u16 Sqrt(u32 num);
u16 ArcTan2(s16 x, s16 y);
void CpuSet(const void *src, void *dest, u32 control);
void CpuFastSet(const void *src, void *dest, u32 control);
void BgAffineSet(struct BgAffineSrcData *src, struct BgAffineDstData *dest, s32 count);
void ObjAffineSet(struct ObjAffineSrcData *src, void *dest, s32 count, s32 offset);
void LZ77UnCompWram(const void *src, void *dest);
void LZ77UnCompVram(const void *src, void *dest);
void RLUnCompWram(const void *src, void *dest);
void RLUnCompVram(const void *src, void *dest);
int MultiBoot(struct MultiBootParam *mp);
s32 Div(s32 num, s32 denom);
s32 DivArm(s32 denom, s32 num);
s32 Mod(s32 num, s32 denom);
s32 ModArm(s32 denom, s32 num);
void SoundBiasReset(void);
void SoundBiasSet(void);
void AGBPrintInit(void);
void AGBPutc(const char cChr);
void AGBPrint(const char *pBuf);
void AGBPrintf(const char *pBuf, ...);
void AGBPrintFlush1Block(void);
void AGBPrintFlush(void);
void AGBAssert(const char *pFile, int nLine, const char *pExpression, int nStopProgram);
typedef void (*VoidFn)(void);
typedef struct {
    s16 x;
    s16 y;
} Vec2_16;
typedef struct {
    u16 x;
    u16 y;
} Vec2_u16;
typedef struct {
    s32 x;
    s32 y;
} Vec2_32;
typedef struct {
    u8 reserved : 4;
    u8 compressedType : 4;
    u32 size : 24;
    void *data;
} RLCompressed;
struct BlendRegs {
    u16 bldCnt;
    u16 bldAlpha;
    u16 bldY;
};
typedef struct {
               u16 pa, pb, pc, pd;
               u32 x, y;
} BgAffineReg;
typedef void (*HBlankIntrFunc)(int_vcount vcount);
typedef void (*IntrFunc)(void);
typedef bool32 (*VBlankFunc)(void);
extern void *iwram_end;
extern void *ewram_end;
extern void *rom_footer;
struct EwramNode {
              struct EwramNode *next;
              s32 state;
              u8 space[0];
};
void EwramInitHeap(void);
void *EwramMalloc(u32);
void EwramFree(void *);
extern u8 gEwramHeap[0x20080];
typedef int __int32_t;
typedef unsigned int __uint32_t;
void * memchr (const void *, int, size_t);
int memcmp (const void *, const void *, size_t);
void * memcpy (void *, const void *, size_t);
void * memmove (void *, const void *, size_t);
void * memset (void *, int, size_t);
char *strcat (char *, const char *);
char *strchr (const char *, int);
int strcmp (const char *, const char *);
int strcoll (const char *, const char *);
char *strcpy (char *, const char *);
size_t strcspn (const char *, const char *);
char *strerror (int);
size_t strlen (const char *);
char *strncat (char *, const char *, size_t);
int strncmp (const char *, const char *, size_t);
char *strncpy (char *, const char *, size_t);
char *strpbrk (const char *, const char *);
char *strrchr (const char *, int);
size_t strspn (const char *, const char *);
char *strstr (const char *, const char *);
char *strtok (char *, const char *);
size_t strxfrm (char *, const char *, size_t);
char *strtok_r (char *, const char *, char **);
int bcmp (const char *, const char *, size_t);
void bcopy (const char *, char *, size_t);
void bzero (char *, size_t);
int ffs (int);
char *index (const char *, int);
void * memccpy (void *, const void *, int, size_t);
char *rindex (const char *, int);
int strcasecmp (const char *, const char *);
char *strdup (const char *);
int strncasecmp (const char *, const char *, size_t);
char *strsep (char **, const char *);
char *strlwr (char *);
char *strupr (char *);
typedef struct Rect8 {
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} Rect8;
typedef u16 AnimId;
struct GraphicsData {
               const void *src;
               void *dest;
               u16 size;
               AnimId anim;
};
typedef struct {
               struct GraphicsData graphics;
               u16 *layoutVram;
               const u16 *layout;
               u16 xTiles;
               u16 yTiles;
               u16 unk18;
               u16 unk1A;
               u16 tilemapId;
               u16 unk1E;
               u16 unk20;
               u16 unk22;
               u16 unk24;
               u16 targetTilesX;
               u16 targetTilesY;
               u8 paletteOffset;
               u8 animFrameCounter;
               u8 animDelayCounter;
               u16 flags;
               u16 scrollX;
               u16 scrollY;
               u16 prevScrollX;
               u16 prevScrollY;
               const u16 *metatileMap;
               u16 mapWidth;
               u16 mapHeight;
} Background;
typedef struct {
               u16 oamIndex;
               u16 numSubframes;
               u16 width;
               u16 height;
               s16 offsetX;
               s16 offsetY;
} SpriteOffset;
typedef struct {
               s32 index;
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} HitboxOld;
typedef struct {
               s32 index;
               Rect8 b;
} Hitbox;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[1];
} Sprite;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[2];
} Sprite2;
typedef struct {
               u16 rotation;
               s16 qScaleX;
               s16 qScaleY;
               s16 x;
               s16 y;
} SpriteTransform;
typedef struct {
               s16 unk0[4];
               s16 qDirX;
               s16 qDirY;
               s16 unkC[2];
               s32 posX;
               s32 posY;
               s16 unk18[2][2];
               u16 affineIndex;
} UnkSpriteStruct;
typedef struct {
               u32 numTiles;
               AnimId anim;
               u8 variant;
} TileInfo;
typedef struct {
               AnimId anim;
               u8 variant;
               u32 numTiles;
} TileInfo2;
typedef struct PACKED {
               u16 numTiles;
               AnimId anim;
               u16 variant;
} TileInfo_16;
extern const u8 gOamShapesSizes[12][2];
typedef enum {
    ACMD_RESULT__ANIM_CHANGED = -1,
    ACMD_RESULT__ENDED = 0,
    ACMD_RESULT__RUNNING = +1,
} AnimCmdResult;
AnimCmdResult UpdateSpriteAnimation(Sprite *);
void DisplaySprite(Sprite *s);
void DisplaySprites(Sprite *s, Vec2_16 *positions, u16 count);
void DrawBackground(Background *);
bool32 sa2__sub_8002B20(void);
u32 sa2__sub_80039E4(void);
u32 sa2__sub_8004010(void);
s16 sa2__sub_8004418(s16 x, s16 y);
void ProcessOamBuffers(void);
OamData *OamMalloc(u8 order);
void TransformSprite(Sprite *sprite, SpriteTransform *transform);
void UnusedTransform(Sprite *, SpriteTransform *);
s16 sa2__sub_8004418(s16 x, s16 y);
extern u8 gNextFreeAffineIndex;
struct Task;
typedef void (*TaskMain)(void);
typedef void (*TaskDestructor)(struct Task *);
typedef u16 TaskPtr;
typedef u32 TaskPtr32;
typedef u16 IwramData;
typedef struct Task {
               TaskPtr parent;
               TaskPtr prev;
               TaskPtr next;
               IwramData data;
               TaskMain main;
               TaskDestructor dtor;
               u16 priority;
               u16 flags;
} Task;
typedef u16 IwramNodePtr;
typedef u32 IwramNodePtr32;
struct IwramNode {
    IwramNodePtr next;
    s16 state;
    u8 __attribute__((aligned(sizeof(void *)))) space[0];
};
extern struct Task gTasks[128];
extern struct Task gEmptyTask;
extern struct Task *gTaskPtrs[128];
extern s32 gNumTasks;
extern struct Task *gNextTaskToCheckForDestruction;
extern struct Task *gNextTask;
extern struct Task *gCurTask;
extern u8 gIwramHeap[((0x881) * sizeof(uintptr_t))];
u32 TasksInit(void);
void TasksExec(void);
struct Task *TaskCreate(TaskMain taskMain, u16 structSize, u16 priority, u16 flags, TaskDestructor taskDestructor);
void TaskDestroy(struct Task *);
void *IwramMalloc(u16);
void IwramFree(void *p);
void TasksDestroyInPriorityRange(u16, u16);
typedef struct {
    u16 index : 10;
    u16 xFlip : 1;
    u16 yFlip : 1;
    u16 pal : 4;
} Tile;
typedef struct {
               u16 xTiles;
               u16 yTiles;
               u16 animTileSize;
               u8 animFrameCount;
               u8 animDelay;
               const u8 *tiles;
               u32 tilesSize;
               const u16 *palette;
               u16 palOffset;
               u16 palLength;
               const u16 *map;
} Tilemap;
struct MapHeader {
               Tilemap tileset;
               const u16 *metatileMap;
               u16 mapWidth;
               u16 mapHeight;
};
struct MultiSioPacket {
    u8 frameCounter;
    u8 recvErrorFlags : 4;
    u8 loadRequest : 1;
    u8 downloadSuccessFlag : 1;
    u8 loadSuccessFlag : 1;
    u8 reserved_0 : 1;
    u16 checkSum;
    u16 data[24 / 2];
    u16 overrunCatch[2];
};
struct MultiSioArea {
    u8 type;
    u8 state;
    u8 connectedFlags;
    u8 recvSuccessFlags;
    u8 syncRecvFlag[4];
    u8 downloadSuccessFlags : 4;
    u8 loadEnable : 1;
    u8 loadRequest : 1;
    u8 loadSuccessFlag : 1;
    u8 startFlag : 1;
    u8 hardError;
    u8 recvFlagsAvailableCounter;
    u8 sendFrameCounter;
    u8 recvFrameCounter[4][2];
    s32 sendBufCounter;
    s32 recvBufCounter[4];
    u16 *nextSendBufp;
    u16 *currentSendBufp;
    u16 *currentRecvBufp[4];
    u16 *lastRecvBufp[4];
    u16 *recvCheckBufp[4];
    struct MultiSioPacket sendBuf[2];
    struct MultiSioPacket recvBuf[4][3];
};
extern u32 gMultiSioRecvFuncBuf[0x40 / 4];
extern u8 gUnknown_03002BE0[0x10];
extern u32 gUnknown_03002BF0;
extern u32 gMultiSioIntrFuncBuf[0x120 / 4];
extern struct MultiSioArea gMultiSioArea;
extern void MultiSioInit(u32 connectedFlags);
void MultiSioStart(void);
void MultiSioStop(void);
extern u32 MultiSioMain(void *sendp, void *recvp, u32 loadRequest);
struct MultiSioReturn {
    u32 recvSuccessFlags : 4;
    u32 loadEnable : 1;
    u32 loadRequest : 1;
    u32 loadSuccessFlag : 1;
    u32 type : 1;
    u32 connectedFlags : 4;
    u32 hardError : 1;
    u32 idOverError : 1;
    u32 reserved : 1;
    u32 recvFlagsAvailable : 1;
};
extern void MultiSioIntr(void);
extern void MultiSioSendDataSet(void *sendp, u32 loadReq);
extern u32 MultiSioRecvDataCheck(void *recvp);
struct InputRecorder {
               s32 playbackHead;
               s32 recordHead;
               u8 mode;
};
void InputRecorderResetRecordHead(void);
void InputRecorderResetPlaybackHead(void);
void InputRecorderLoadTape(void);
u16 InputRecorderRead(void);
void InputRecorderWrite(u16);
typedef AnimCmdResult (*AnimationCommandFunc)(void *cursor, Sprite *sprite);
typedef struct {
               s32 cmdId;
               s32 tileIndex;
               u32 numTilesToCopy;
} ACmd_GetTiles;
typedef struct {
               s32 cmdId;
               s32 palId;
               u16 numColors;
               u16 insertOffset;
} ACmd_GetPalette;
typedef struct {
               s32 cmdId;
               s32 offset;
} ACmd_JumpBack;
typedef struct {
               s32 cmdId;
} ACmd_4;
typedef struct {
               s32 cmdId;
               u16 songId;
} ACmd_PlaySoundEffect;
typedef struct {
               s32 cmdId;
               Hitbox hitbox;
} ACmd_Hitbox;
typedef struct {
               s32 cmdId;
               u16 x;
               u16 y;
} ACmd_TranslateSprite;
typedef struct {
               s32 cmdId;
               s32 unk4;
               s32 unk8;
} ACmd_8;
typedef struct {
               s32 cmdId;
               AnimId animId;
               u16 variant;
} ACmd_SetIdAndVariant;
typedef struct {
               s32 cmdId;
               s32 unk4;
               s32 unk8;
               s32 unkC;
} ACmd_10;
typedef struct {
               s32 cmdId;
               s32 priority;
} ACmd_SetSpritePriority;
typedef struct {
               s32 cmdId;
               s32 orderIndex;
} ACmd_SetOamOrder;
typedef struct {
    s32 delay;
    s32 index;
} ACmd_ShowFrame;
typedef union {
    s32 id;
    ACmd_GetTiles tiles;
    ACmd_GetPalette pal;
    ACmd_JumpBack jump;
    ACmd_4 end;
    ACmd_PlaySoundEffect sfx;
    ACmd_Hitbox _6;
    ACmd_TranslateSprite translate;
    ACmd_8 _8;
    ACmd_SetIdAndVariant setAnimId;
    ACmd_10 _10;
    ACmd_SetSpritePriority _11;
    ACmd_SetOamOrder setOamOrder;
    ACmd_ShowFrame show;
} ACmd;
u32 Base10DigitsToHexNibbles(u16 num);
extern const ACmd **const gAnimations[1524];
extern const SpriteOffset *const gSpriteDimensions[1524];
extern const OamDataShort *const gSpriteOamData[1524];
extern const u16 gSpritePalettes[][16];
struct MultiSioData_0_0 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u32 unk4;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_1 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_2 {
    u8 unk0;
    u8 filler1;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_3 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u32 unk8;
    u16 unkC;
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_4 {
    u16 unk0;
    s16 x;
    s16 y;
    u16 unk6;
    u16 unk8;
    u8 unkA;
    u8 unkB;
    u8 unkC;
    u8 unkD;
    u8 unkE;
    u8 numRings;
    u8 unk10;
    u8 unk11;
    u8 unk12;
    u8 unk13;
};
struct MultiSioData_0_5 {
    u16 unk0;
    s16 x;
    s16 y;
    u8 filler3[0x9];
    u8 sioId;
    u8 unk10;
    u8 unk11;
    u8 unk12;
    u8 unk13;
};
union MultiSioData {
    struct MultiSioData_0_0 pat0;
    struct MultiSioData_0_1 pat1;
    struct MultiSioData_0_2 pat2;
    struct MultiSioData_0_3 pat3;
    struct MultiSioData_0_4 pat4;
    struct MultiSioData_0_5 pat5;
    u8 raw[24];
};
typedef u32 collPxDim_t;
typedef struct Collision {
               const s8 *height_map;
               const u8 *tile_rotation;
               const u16 *metatiles;
               const MetatileIndexType *map[2];
               const u16 *flags;
               u16 levelX, levelY;
               collPxDim_t pxWidth, pxHeight;
} Collision;
struct Unk_03003674_1_Sub {
    u16 unk0, unk2, unk4, unk6;
    s16 unk8, unkA;
};
struct Unk_03003674_1_Full {
    struct Unk_03003674_1_Sub sub;
    u32 unkC;
};
union Unk_03003674_1 {
    const struct Unk_03003674_1_Sub *sub;
    const struct Unk_03003674_1_Full *full;
};
struct Unk_03003674 {
    const union Unk_03003674_0 *const *unk0;
    const union Unk_03003674_1 *unk4;
    const u16 *const *unk8;
    const void *unkC;
    const void *unk10;
    const void *unk14;
    const s32 *unk18;
};
struct SpriteTables {
               const ACmd **const *animations;
               const SpriteOffset *const *dimensions;
               const u16 **const oamData;
               const u16 *const palettes;
               const u8 *const tiles_4bpp;
               const u8 *const tiles_8bpp;
               const void *const unk18;
};
extern u32 gFlags;
extern u32 gFlagsPreVBlank;
extern u32 gFrameCount;
extern IntrFunc gIntrTable[16];
extern IntrFunc const gIntrTableTemplate[14];
extern u32 gIntrMainBuf[0x80];
extern struct Task *gCurTask;
extern struct Task gTasks[128];
extern struct Task *gTaskPtrs[128];
extern struct Task *gNextTask;
extern struct Task gEmptyTask;
extern s32 gNumTasks;
extern u16 gInput;
extern u16 gPrevInput;
extern u16 gPhysicalInput;
extern u16 gReleasedKeys;
extern u16 gRepeatedKeys;
extern u16 gPressedKeys;
extern u8 gKeysFirstRepeatIntervals[10];
extern u8 gRepeatedKeysTestCounter[10];
extern u8 gKeysContinuedRepeatIntervals[10];
extern const u8 *gInputPlaybackData;
extern struct InputRecorder gInputRecorder;
extern u16 *gInputRecorderTapeBuffer;
extern union MultiSioData gMultiSioSend;
extern union MultiSioData gMultiSioRecv[4];
extern u32 gMultiSioStatusFlags;
extern bool8 gMultiSioEnabled;
extern HBlankIntrFunc gHBlankIntrs[4];
extern HBlankIntrFunc gHBlankCallbacks[4];
extern u8 gNumHBlankCallbacks;
extern u8 gNumHBlankIntrs;
extern void *gVramHeapStartAddr;
extern u16 gVramHeapMaxTileSlots;
extern u16 gVramHeapState[256];
extern bool8 gExecSoundMain;
extern u16 gDispCnt;
extern winreg_t gWinRegs[6];
extern struct BlendRegs gBldRegs;
extern BgAffineReg gBgAffineRegs[2];
extern u16 gObjPalette[0x200 / sizeof(u16)];
extern u16 gBgPalette[0x200 / sizeof(u16)];
extern u16 gBgCntRegs[4];
extern s16 gBgScrollRegs[4][2];
extern OamData gOamMallocBuffer[128];
extern OamData gOamBuffer[128];
extern int_vcount gBgOffsetsBuffer[2][160][4];
extern Background *gBackgroundsCopyQueue[16];
extern void *gBgOffsetsHBlankPrimary;
extern u16 sa2__gUnknown_030017F0;
extern Vec2_16 gSpriteOffset;
extern u8 gOamMallocOrders_StartIndex[32];
extern IntrFunc gVBlankCallbacks[4];
extern u8 gOamFreeIndex;
extern u16 sa2__gUnknown_03001944;
extern u8 gNumVBlankIntrs;
extern s16 sa2__gUnknown_0300194C;
extern Tilemap **gTilemapsRef;
extern u8 gBgSprites_Unknown2[4][4];
extern u8 gBgSprites_Unknown1[16];
extern struct GraphicsData gVramGraphicsCopyQueue[32];
extern u8 gVramGraphicsCopyQueueIndex;
extern void *gBgOffsetsHBlankSecondary;
extern void *sa2__gUnknown_030022C0;
extern s16 sa2__gUnknown_03002820;
extern u8 sa2__gUnknown_03002874;
extern void *gHBlankCopyTarget;
extern u8 gBackgroundsCopyQueueIndex;
extern u8 gHBlankCopySize;
extern u16 sa2__gUnknown_03002A8C;
extern u8 gOamFirstPausedIndex;
extern u8 gBackgroundsCopyQueueCursor;
extern Sprite *gBgSprites[16];
extern u8 gNumVBlankCallbacks;
extern void *gBgOffsetsPrimary;
extern u16 sa2__gUnknown_03004D58;
extern u8 gVramGraphicsCopyCursor;
extern u8 gOamMallocOrders_EndIndex[0x20];
extern u8 gBgSpritesCount;
extern u16 sa2__gUnknown_03005394;
extern u16 sa2__gUnknown_03005398;
extern IntrFunc gVBlankIntrs[4];
extern s32 gPseudoRandom;
extern u8 gOamMallocCopiedOrder[128];
extern struct MultiBootParam gMultiBootParam;
extern const struct SpriteTables *gRefSpriteTables;
void EngineInit(void);
void EngineMainLoop(void);
extern u32 gFlags;
struct MP2KTrack;
struct MP2KPlayerState;
typedef void (*MP2KEventNoteFunc)(u8, struct MP2KPlayerState *, struct MP2KTrack *);
typedef void (*MP2KEventFunc)(struct MP2KPlayerState *, struct MP2KTrack *);
typedef void (*CgbSoundFunc)(void);
typedef void (*CgbOscOffFunc)(u8);
typedef u32 (*MidiKeyToCgbFreqFunc)(u8, u8, u8);
typedef void (*ExtVolPitFunc)(void);
typedef void (*MPlayMainFunc)(struct MP2KPlayerState *);
struct MixerSource {
    u8 status;
    u8 type;
    u8 rightVol;
    u8 leftVol;
    union {
        struct {
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
            u8 key;
            u8 envelopeVol;
            u8 envelopeGoal;
            u8 envelopeCtr;
            u8 echoVol;
            u8 echoLen;
            u8 padding1;
            u8 padding2;
            u8 gateTime;
            u8 untransposedKey;
            u8 velocity;
            u8 priority;
            u8 rhythmPan;
            u8 padding3;
            u8 padding4;
            u8 padding5;
            u8 padding6;
            u8 sustainGoal;
            u8 nrx4;
            u8 pan;
            u8 panMask;
            u8 cgbStatus;
            u8 length;
            u8 sweep;
            u32 freq;
        } cgb;
        struct {
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
            u8 key;
            u8 envelopeVol;
            u8 envelopeVolR;
            u8 envelopeVolL;
            u8 echoVol;
            u8 echoLen;
            u8 padding1;
            u8 padding2;
            u8 gateTime;
            u8 untransposedKey;
            u8 velocity;
            u8 priority;
            u8 rhythmPan;
            u8 padding3;
            u8 padding4;
            u8 padding5;
            u32 ct;
            float fw;
            u32 freq;
        } sound;
    } data;
    void *wav;
    void *current;
    struct MP2KTrack *track;
    struct MixerSource *prev;
    struct MixerSource *next;
    u32 padding7;
    u32 blockCount;
};
struct SoundMixerState {
    u32 lockStatus;
    vu8 dmaCounter;
    u8 reverb;
    u8 numChans;
    u8 masterVol;
    u8 freqOption;
    u8 extensionFlags;
    u8 cgbCounter15;
    u8 framesPerDmaCycle;
    u8 maxScanlines;
    u8 gap[3];
    s32 samplesPerFrame;
    s32 sampleRate;
    s32 sampleRateReciprocal;
    struct MixerSource *cgbChans;
    MPlayMainFunc MPlayMainHead;
    struct MP2KPlayerState *musicPlayerHead;
    CgbSoundFunc CgbSound;
    CgbOscOffFunc CgbOscOff;
    MidiKeyToCgbFreqFunc MidiKeyToCgbFreq;
    void **MPlayJumpTable;
    MP2KEventNoteFunc plynote;
    ExtVolPitFunc ExtVolPit;
    void *reserved2;
    void *reserved3;
    void *reversed4;
    void *reserved5;
    struct MixerSource chans[12];
    s8 pcmBuffer[1584 * 2];
};
struct MP2KVoiceGroup {
    u8 type;
    u8 drumKey;
    u8 cgbLength;
    u8 pan_sweep;
    union {
        struct {
            struct WaveData *wav;
            u8 attack;
            u8 decay;
            u8 sustain;
            u8 release;
        } sound;
        struct {
            struct MP2KVoiceGroup *group;
            u8 *keySplitTable;
        } keySplit;
    } data;
};
struct WaveData {
    u16 type;
    u16 status;
    u32 freq;
    u32 loopStart;
    u32 size;
    s8 data[1];
};
struct MP2KSongHeader {
    u8 trackCount;
    u8 blockCount;
    u8 priority;
    u8 reverb;
    struct MP2KVoiceGroup *voicegroup;
    u8 *part[1];
};
struct MP2KTrack {
    u8 status;
    u8 wait;
    u8 patternLevel;
    u8 repeatCount;
    u8 gateTime;
    u8 key;
    u8 velocity;
    u8 runningStatus;
    s8 keyShiftCalculated;
    u8 pitchCalculated;
    s8 keyShift;
    s8 keyShiftPublic;
    s8 tune;
    u8 pitchPublic;
    s8 bend;
    u8 bendRange;
    u8 volRightCalculated;
    u8 volLeftCalculated;
    u8 vol;
    u8 volPublic;
    s8 pan;
    s8 panPublic;
    s8 modCalculated;
    u8 modDepth;
    u8 modType;
    u8 lfoSpeed;
    u8 lfoSpeedCounter;
    u8 lfoDelay;
    u8 lfoDelayCounter;
    u8 priority;
    u8 echoVolume;
    u8 echoLength;
    struct MixerSource *chan;
    struct MP2KVoiceGroup voicegroup;
    u8 gap[10];
    u16 unk_3A;
    u32 unk_3C;
    u8 *cmdPtr;
    u8 *patternStack[3];
};
struct MP2KPlayerState {
    struct MP2KSongHeader *songHeader;
    u32 status;
    u8 trackCount;
    u8 priority;
    u8 cmd;
    bool8 checkSongPriority;
    u32 clock;
    u8 padding[8];
    u8 *memAccArea;
    u16 tempoRawBPM;
    u16 tempoScale;
    u16 tempoInterval;
    u16 tempoCounter;
    u16 fadeInterval;
    u16 fadeCounter;
    u16 fadeOV;
    struct MP2KTrack *tracks;
    struct MP2KVoiceGroup *voicegroup;
    u32 lockStatus;
    MPlayMainFunc nextPlayerFunc;
    struct MP2KPlayerState *nextPlayer;
};
struct MusicPlayer {
    struct MP2KPlayerState *info;
    struct MP2KTrack *track;
    u8 numTracks;
    u16 unk_A;
};
struct Song {
    struct MP2KSongHeader *header;
    u16 ms;
    u16 me;
};
typedef void (*XcmdFunc)(struct MP2KPlayerState *, struct MP2KTrack *);
extern char SoundMainRAM[];
extern u8 gMPlayMemAccArea[];
extern void *gMPlayJumpTable[];
extern struct MixerSource gCgbChans[];
extern const struct MusicPlayer gMPlayTable[];
extern const struct Song gSongTable[];
extern const XcmdFunc gXcmdTable[];
extern const u8 gClockTable[];
extern const u8 gScaleTable[];
extern const u32 gFreqTable[];
extern const u16 gPcmSamplesPerVBlankTable[];
extern void *const gMPlayJumpTableTemplate[];
extern const u8 gCgbScaleTable[];
extern const s16 gCgbFreqTable[];
extern const u8 gNoiseTable[];
extern const u8 gCgb3Vol[];
extern char gNumMusicPlayers[];
extern char gMaxLines[];
u32 MidiKeyToFreq(struct WaveData *wav, u8 key, u8 fineAdjust);
u32 umul3232H32(u32 multiplier, u32 multiplicand);
void SoundMain(void);
void SoundMainBTM(void *ptr);
void TrackStop(struct MP2KPlayerState *player, struct MP2KTrack *track);
void MP2KPlayerMain(struct MP2KPlayerState *);
void ClearChain(struct MixerSource *chan);
void MP2KClearChain(struct MixerSource *chan);
void MPlayContinue(struct MP2KPlayerState *mplayInfo);
void MPlayStart(struct MP2KPlayerState *mplayInfo, struct MP2KSongHeader *songHeader);
void MPlayStop(struct MP2KPlayerState *mplayInfo);
void FadeOutBody(struct MP2KPlayerState *mplayInfo);
void TrkVolPitSet(struct MP2KPlayerState *mplayInfo, struct MP2KTrack *track);
void MPlayFadeOut(struct MP2KPlayerState *mplayInfo, u16 speed);
void Clear64byte(void *addr);
void SoundInit(struct SoundMixerState *soundInfo);
void MPlayExtender(struct MixerSource *cgbChans);
void m4aSoundMode(u32 mode);
void MPlayOpen(struct MP2KPlayerState *mplayInfo, struct MP2KTrack *tracks, u8 trackCount);
void CgbSound(void);
void CgbOscOff(u8);
void CgbModVol(struct MixerSource *chan);
u32 MidiKeyToCgbFreq(u8, u8, u8);
void MPlayJumpTableCopy(void **mplayJumpTable);
void SampleFreqSet(u32 freq);
void m4aSoundVSyncOn(void);
void m4aSoundVSyncOff(void);
void m4aMPlayTempoControl(struct MP2KPlayerState *mplayInfo, u16 tempo);
void m4aMPlayVolumeControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, u16 volume);
void m4aMPlayPitchControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s16 pitch);
void m4aMPlayPanpotControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s8 pan);
void ClearModM(struct MP2KTrack *track);
void m4aMPlayModDepthSet(struct MP2KPlayerState *mplayInfo, u16 trackBits, u8 modDepth);
void m4aMPlayLFOSpeedSet(struct MP2KPlayerState *mplayInfo, u16 trackBits, u8 lfoSpeed);
void MP2K_event_fine(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_goto(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_patt(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_pend(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_rept(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_memacc(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_prio(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_tempo(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_keysh(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_voice(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_vol(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_pan(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_bend(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_bendr(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_lfos(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_lfodl(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_mod(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_modt(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_tune(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_port(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_endtie(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_nxx(u8 clock, struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xxx(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xwave(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xtype(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xatta(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xdeca(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xsust(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xrele(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xiecv(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xiecl(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xleng(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xswee(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd_0C(struct MP2KPlayerState *, struct MP2KTrack *);
void MP2K_event_xcmd_0D(struct MP2KPlayerState *, struct MP2KTrack *);
extern struct SoundMixerState gSoundInfo;
extern struct MP2KPlayerState gMPlayInfo_BGM;
extern struct MP2KPlayerState gMPlayInfo_SE1;
extern struct MP2KPlayerState gMPlayInfo_SE2;
extern struct MP2KPlayerState gMPlayInfo_SE3;
void m4aSoundVSync(void);
void m4aSoundInit(void);
void m4aSoundMain(void);
void m4aSongNumStart(u16);
void m4aSongNumStartOrChange(u16);
void m4aSongNumStartOrContinue(u16);
void m4aSongNumStop(u16 n);
void m4aMPlayAllStop(void);
void m4aMPlayAllContinue(void);
void m4aMPlayContinue(struct MP2KPlayerState *mplayInfo);
void m4aMPlayFadeOut(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayFadeOutTemporarily(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayFadeIn(struct MP2KPlayerState *mplayInfo, u16 speed);
void m4aMPlayImmInit(struct MP2KPlayerState *mplayInfo);
void m4aMPlayTempoControl(struct MP2KPlayerState *mplayInfo, u16 tempo);
void m4aMPlayVolumeControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, u16 volume);
void m4aMPlayPitchControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s16 pitch);
void m4aMPlayPanpotControl(struct MP2KPlayerState *mplayInfo, u16 trackBits, s8 pan);
u16 IdentifyFlash(void);
void ReadFlash(u16 sectorNum, u32 offset, void *dest, u32 size);
u32 ProgramFlashSectorAndVerifyNBytes(u16 sectorNum, void *dataSrc, u32 n);
u16 SetFlashTimerIntr(u8 timerNum, void (**intrFunc)(void));
extern u16 (*EraseFlashSector)(u16);
struct FlashSector {
    u32 size;
    u8 shift;
    u16 count;
    u16 top;
};
struct FlashType {
    u32 romSize;
    struct FlashSector sector;
    u16 wait[2];
    union {
        struct {
            u8 makerId;
            u8 deviceId;
        } separate;
        u16 joined;
    } ids;
};
struct FlashSetupInfo {
    u16 (*programFlashSector)(u16, void *);
    u16 (*eraseFlashChip)(void);
    u16 (*eraseFlashSector)(u16);
    u16 (*WaitForFlashWrite)(u8, u8 *, u8);
    const u16 *maxTime;
    struct FlashType type;
};
extern u16 gFlashNumRemainingBytes;
extern u16 (*ProgramFlashSector)(u16, void *);
extern u16 (*EraseFlashChip)(void);
extern u16 (*EraseFlashSector)(u16);
extern const u16 *gFlashMaxTime;
extern const struct FlashType *gFlash;
extern u8 gFlashTimeoutFlag;
extern u8 (*PollFlashStatus)(u8 *);
extern u16 (*WaitForFlashWrite)(u8, u8 *, u8);
extern const struct FlashSetupInfo LE39FW512;
extern const struct FlashSetupInfo MN63F805MNP;
extern const struct FlashSetupInfo MX29L512;
extern const struct FlashSetupInfo DefaultFlash512K;
void SwitchFlashBank(u8 bankNum);
u16 ReadFlashId(void);
void StartFlashTimer(u8 phase);
void SetReadFlash1(u16 *dest);
void StopFlashTimer(void);
u16 SetFlashTimerIntr(u8 timerNum, void (**intrFunc)(void));
u32 ProgramFlashSectorAndVerify(u16 sectorNum, u8 *src);
void ReadFlash(u16 sectorNum, u32 offset, void *dest, u32 size);
u32 ProgramFlashSectorAndVerifyNBytes(u16 sectorNum, void *dataSrc, u32 n);
u16 WaitForFlashWrite512K_Common(u8 phase, u8 *addr, u8 lastData);
u16 WaitForFlashWrite_Common(u8 phase, u8 *addr, u8 lastData);
u16 ProgramByte(u8 *src, u8 *dest);
u16 EraseFlashChip_LE(void);
u16 EraseFlashSector_LE(u16 sectorNum);
u16 ProgramFlashSector_LE(u16 sectorNum, void *src);
u16 ProgramFlashSector_MX(u16 sectorNum, void *src);
u16 EraseFlashChip_MX(void);
u16 EraseFlashSector_MX(u16 sectorNum);
u16 IdentifyFlash(void);
void *VramMalloc(u32);
void VramResetHeapState(void);
void VramFree(void *);
typedef enum {
    CHARACTER_SONIC,
    CHARACTER_CREAM,
    CHARACTER_TAILS,
    CHARACTER_KNUCKLES,
    CHARACTER_AMY,
    NUM_CHARACTERS
} ECharacters;
void GameStart(void);
extern const s16 gPlayerCharacterIdleAnims[NUM_CHARACTERS];
typedef struct __attribute__((packed)) MapEntity { u8 x; u8 y; u8 index; union { s8 sData[5]; u8 uData[5]; } d; } MapEntity;;
typedef struct __attribute__((packed)) MapEntity_Itembox { u8 x; u8 y; u8 index; } MapEntity_Itembox;;
typedef struct __attribute__((packed)) MapEntity_Ring { u8 x; u8 y; } MapEntity_Ring;;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 unk8;
               u8 unk9;
               u8 meX;
               u8 id;
} SpriteBase;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u16 unk8;
               u8 meX;
               u8 id;
} SpriteBase2;
typedef struct {
               MapEntity *me;
               s32 qWorldX;
               s32 qWorldY;
               u16 regionX;
               u16 regionY;
               u16 unk10;
               s16 unk12;
               u8 meX;
               u8 id;
               u8 unk16;
               u8 unk17;
               u8 unk18;
               u8 unk19;
} SpriteBase3;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 filler8[0x2];
               u16 qSpeedAirX;
               u16 qSpeedAirY;
               u8 meX;
               u8 id;
} SpriteBase4;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 meX;
               u8 id;
               u8 unkA;
               u8 unkB;
} SpriteBase5;
typedef struct {
    SpriteBase base;
    Sprite s;
} EnemyBase;
typedef enum {
    SONIC,
    CREAM,
    TAILS,
    KNUCKLES,
    AMY,
    PLAYERCHAR_COUNT,
    PLAYERCHAR_NONE = 0xFF,
} eCharacter;
struct Player;
typedef struct Player Player;
typedef void (*PlayerCallback)(Player *p);
typedef union __attribute__((packed)) StateNum { u16 raw; struct { u8 subCount : 4; u8 other : 3; u8 subHighBit : 1; s8 highValue : 8; } split; } StateNum;;
typedef struct {
               SpriteTransform tf;
               Sprite2 s;
} PlayerSpriteInfo;
typedef struct PlayerUnkC4 {
    u32 unk0;
    s16 playerId;
} PlayerUnkC4;
typedef struct PlayerUnk148_A {
    s16 unk0;
    s16 unk2;
    u8 unk4;
    u8 unk5;
    u8 unk6;
    u8 unk7;
    s16 unk8;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_A;
typedef struct PlayerUnk148_B {
    s16 unk0;
    u8 unk2;
    u8 unk3;
    u8 unk4;
    u8 unk5;
    u8 unk6;
    u8 unk7;
    u8 unk8;
    u8 unk9;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_B;
typedef struct PlayerUnk148_C {
    s16 unk0;
    u8 unk2;
    u8 unk3;
    u8 *tiles;
    u8 unk8;
    u8 unk9;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_C;
typedef struct PlayerUnk148_D {
    u8 unk0[0x8];
    u16 unk8;
    s16 someAnim0;
    Sprite s;
} PlayerUnk148_D;
typedef union PlayerUnk148 {
    PlayerUnk148_A a;
    PlayerUnk148_B b;
    PlayerUnk148_C c;
    PlayerUnk148_D d;
} PlayerUnk148;
struct Player {
    PlayerCallback callback;
               u32 moveState;
               u32 moveState2;
    u32 unkC;
               s32 qWorldX;
               s32 qWorldY;
    s16 qSpeedAirX;
    s16 qSpeedAirY;
    s16 qSpeedGround;
    u16 keyInput;
    u16 keyInput2;
    u16 unk22;
               s8 spriteOffsetX;
               s8 spriteOffsetY;
               u8 unk26;
               u8 layer;
    struct {
        u8 unk28;
        u8 unk29;
        u8 character : 4;
        u8 padding1 : 4;
        u8 partnerIndex : 2;
        u8 someIndex : 3;
        u8 someFlag0 : 1;
        u8 someFlag1 : 1;
        u8 boostIsActive : 1;
        u8 unk2C_01 : 1;
        u8 unk2C_02 : 1;
        u8 unk2C_04 : 1;
        u8 unk2C_08 : 1;
        u8 unk2C_10 : 1;
        u8 unk2C_20 : 1;
        u8 unk2C_40 : 1;
        u8 unk2C_80 : 1;
                   u8 unk2D_0 : 4;
                   u8 ringSpeedFactor : 4;
        u8 state0_subCount : 4;
        u8 state0_other : 3;
        u8 state0_subHighBit : 1;
        u8 state0_highValue : 8;
        s16 anim0;
        s16 anim1;
        u16 anim2;
        u16 state1;
    } charFlags;
    s32 qUnk38;
    s32 qUnk3C;
    s16 unk40;
    s16 unk42;
    s16 unk44;
    s16 Spindash_Velocity;
    s16 unk48;
    s16 framesInvulnerable;
    s16 framesInvincible;
    s16 unk4E;
    s16 boostEffectCounter;
    s16 idleAndCamCounter;
               s16 unk54;
    s8 unk56;
    s8 unk57;
    u8 unk58;
    u8 unk59;
    u8 unk5A;
    u8 unk5B;
    u8 unk5C;
    u8 unk5D;
    s16 unk5E;
    s16 unk60;
    s16 unk62;
    u16 unk64;
    s16 unk66;
    u8 unk68;
    u8 unk69;
    u8 filler6A[0x2];
               Sprite *sprColliding;
    s32 qUnk70;
    s32 qUnk74;
    s8 unk78[0x10];
    s32 unk88;
    s32 unk8C;
    s32 unk90;
    s32 unk94;
    u8 unk98;
    u8 unk99;
    u8 unk9A;
    u8 unk9B;
               s16 qCamOffsetX;
               s16 qCamOffsetY;
               s16 unkA0;
               s16 unkA2;
    u8 unkA4;
    u8 PaddingA5[0x3];
    u32 unkA8;
    u32 unkAC;
    u32 unkB0;
    u32 unkB4;
    u32 unkB8;
    u32 unkBC;
    u16 unkC0;
    u16 unkC2;
    struct Task *unkC4[0x03];
    struct Task *taskTagAction;
    struct Task *unkD4;
    struct Task *unkD8;
    struct Task *unkDC;
    PlayerSpriteInfo *spriteInfoBody;
    PlayerSpriteInfo *spriteInfoLimbs;
    Vec2_16 unkE8;
    u8 unkEC;
    s32 qUnkF0;
    u16 palette[16];
    Sprite sprShield;
    u8 unk13C;
    u8 unk13D;
    u16 *demoplayInput_Start;
    u16 *demoplayInput_Current;
    union {
        PlayerUnk148 *ptr;
        u8 arr_u8[4];
        s16 arr_s16[2];
    } unk148;
    union {
        u8 arr_u8[4];
        s16 arr_s16[2];
    } unk14C;
};
extern Player gPlayers[4];
typedef struct Struc_3001150 {
    u8 filler0[0x1C];
    u8 filler1C[0x4];
    u8 filler20[0x450];
} Struc_3001150;
Struc_3001150 gUnknown_03001150;
extern s16 sub_801480C(Player *p);
void Call__Player_8014550(Player *p);
bool32 sub_802C080(Player *p);
bool32 sub_802C0D4(Player *p);
typedef struct {
    u16 jump;
    u16 attack;
    u16 trick;
} ButtonConfig;
typedef struct {
    u8 jump;
    u8 attack;
    u8 trick;
} ButtonConfigPacked;
extern ButtonConfig gPlayerControls;
void SetPlayerControls(u16 jump, u16 attack, u16 trick);
enum eLanguage { JAPANESE = 0, ENGLISH = 1, GERMAN = 2, FRENCH = 3, SPANISH = 4, ITALIAN = 5, NUM_LANGUAGES };
typedef struct {
    u8 Act1 : 1;
    u8 Act2 : 1;
    u8 Act3 : 1;
    u8 Boss : 1;
    u8 BonusCapsule : 1;
    u8 BonusEnemies : 1;
    u8 Bit7 : 1;
} ZoneCompletion;
typedef struct {
    u8 Bronze : 1;
    u8 Silver : 1;
    u8 Gold : 1;
} MedalCollection;
typedef struct {
               u32 playerId;
               u16 playerName[6];
               bool8 slotFilled;
               u8 wins;
               u8 losses;
               u8 draws;
} VsRecords;
typedef struct {
               u8 slotFilled;
               u8 wins;
               u8 draws;
               u8 losses;
               u32 playerId;
               u16 playerName[6];
} VsRecords2;
typedef struct TimeRecord {
    u8 character1;
    u8 character2;
    u16 time;
} TimeRecord;
typedef struct TimeRecords {
    TimeRecord table[7][4][5];
} TimeRecords;
typedef struct {
               u32 playerId;
               u16 playerName[6];
               u8 unlockedCharacters;
               u8 unlockedZones;
               u8 continueZone;
               u8 unk13;
               u16 chaoCount[7];
               u8 specialKeys[7];
               u8 unlockedStages[9];
               u8 collectedEmeralds;
               u8 unlockFlags;
               u16 unk34;
               u8 unk36;
               u8 collectedMedals[9][4];
               u8 unk5B;
               u8 unk5C;
               u8 unk5D;
               u16 unk5E;
               u8 vsWins;
               u8 vsLosses;
               u8 vsDraws;
               u8 unk63;
               VsRecords vsRecords[10];
                TimeRecords timeRecords;
                ButtonConfig buttonConfig;
                u8 difficulty;
                bool8 disableTimeLimit;
                u8 language;
                u8 unk367;
} SaveGame;
extern SaveGame gLoadedSaveGame;
extern SaveGame gUnknown_03000980;
typedef struct SaveSectorHeader {
                u32 magicNumber;
                u32 sectorId;
} SaveSectorHeader;
typedef struct {
    SaveSectorHeader header;
                u32 playerId;
                u16 playerName[6];
                u8 unk18;
                u8 unlockedCharacters;
                u8 unlockedZones;
                u8 continueZone;
                u8 unk1C;
                u16 chaoCount[7];
                u8 specialKeys[7];
                u8 unlockedStages[9];
                u8 collectedEmeralds;
                u8 unlockFlags;
                u8 collectedMedals[9][4];
                u16 unk62;
                u8 vsWins;
                u8 vsDraws;
                u8 vsLosses;
    u8 unk67;
    VsRecords2 vsRecords[10];
                TimeRecords timeRecords;
                ButtonConfigPacked buttonConfig;
                u8 difficulty;
                bool8 disableTimeLimit;
                u8 language;
                u8 unk367;
                u32 checksum;
} SaveSectorData;
extern SaveSectorData gSaveSectorData;
void InsertMultiplayerProfile(u32 playerId, u16 *name);
void RecordOwnMultiplayerResult(s16 result);
void RecordMultiplayerResult(u32 id, u16 *name, s16 result);
void SaveInit(void);
bool16 SaveGameExists(void);
s16 NewSaveGame(void);
s16 LoadSaveGame(void);
void LoadCompletedSaveGame(void);
bool32 WriteSaveGame(void);
typedef struct {
               s32 qWorldX;
               s32 qWorldY;
               s32 qWorldX2;
               s32 qWorldY2;
               s16 unk10;
               s16 unk12;
               s16 unk14;
               u16 moveState;
               u8 unk18;
               u8 unk19;
               u8 unk1A;
               u8 unk1B;
               u8 unk1C;
               u8 unk1D;
               u8 filler1E[0x2];
               Sprite2 s;
               Player *player;
               Player *unk54;
} Cheese;
typedef struct {
               u8 language;
               u8 difficulty;
               u8 unk2;
               u8 gameMode;
               u8 unk4;
               u8 unk5;
               u8 playerIndex;
               u8 unk7;
               u8 unk8;
               u8 zone;
               u8 act;
               u8 entryIndex;
               u8 unkC;
               u8 unkD;
               u16 currMapIndex;
               u16 unk10;
               u16 nextMapIndex;
               ButtonConfig buttonConfig;
               u32 timer;
               u8 unk20;
               u8 unk21;
               u8 filler22[2];
               u32 unk24;
               u16 respawnX;
               u16 respawnY;
               u8 platformTimerEnableBits;
               u8 springTimerEnableBits;
               u16 platformTimers[8];
               u16 springTimers[8];
               u16 unk4E[8];
               s16 unk5E[8];
               u16 unk6E[8];
               u8 filler7E[0x2];
               u16 *unk80;
               u8 unk84;
               u8 unk85;
               u8 unk86;
               u8 flagSpKey;
               u8 PADDING42[0x04];
               u16 unk8C;
               u8 unk8E;
               u8 unk8F;
               struct Task *task90;
               u32 unk94;
               struct Task *taskCheese;
               struct Task *task9C;
               u32 unkA0;
               u32 unkA4;
               u32 unkA8;
               u16 rings;
               u16 levelTimer;
               u16 unkB0;
               u16 unkB2;
               u8 lives;
               u8 unkB5;
               u8 unkB6;
               u8 unkB7;
               u8 unkB8;
               u8 unkB9;
               u8 unkBA;
               u8 unkBB;
               u8 unkBC;
               u8 unkBD;
               u8 unkBE[7];
} StageData;
extern StageData gStageData;
typedef enum {
    ACT_TYPE_ACT_1 = 0x01,
    ACT_TYPE_ACT_2 = 0x02,
    ACT_TYPE_ACT_3 = 0x04,
    ACT_TYPE_BOSS = 0x08,
    ACT_TYPE_MINIGAME_CAPSULE = 0x10,
    ACT_TYPE_MINIGAME_ENEMIES = 0x20,
    ACT_TYPE_40 = 0x40,
    ACT_TYPE_80 = 0x80,
} eActType;
void PackSaveSector(SaveSectorData *sector, SaveGame *save)
{
    s16 i;
    s16 j;
    s16 k;
    sector->header.magicNumber = 0x47544E4C;
    sector->header.sectorId += 1;
    sector->playerId = save->playerId;
    for (i = 0; i < 6; i++) {
        sector->playerName[i] = save->playerName[i];
    }
    sector->unk18 = 0;
    sector->unlockedCharacters = save->unlockedCharacters;
    sector->unlockedZones = save->unlockedZones;
    sector->continueZone = save->continueZone;
    sector->unk1C = 0;
    for (i = 0; i < 7; i++) {
        sector->chaoCount[i] = save->chaoCount[i];
    }
    for (i = 0; i < 7; i++) {
        sector->specialKeys[i] = save->specialKeys[i];
    }
    for (i = 0; i < 9; i++) {
        sector->unlockedStages[i] = save->unlockedStages[i];
    }
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 4; j++) {
            sector->collectedMedals[i][j] = save->collectedMedals[i][j];
        }
    }
    sector->collectedEmeralds = save->collectedEmeralds;
    sector->unk62 = save->unk34;
    sector->unlockFlags = save->unlockFlags;
    sector->vsWins = save->vsWins;
    sector->vsDraws = save->vsDraws;
    sector->vsLosses = save->vsLosses;
    sector->unk67 = 0;
    for (i = 0; i < 10; i++) {
        sector->vsRecords[i].slotFilled = save->vsRecords[i].slotFilled;
        sector->vsRecords[i].wins = save->vsRecords[i].wins;
        sector->vsRecords[i].draws = save->vsRecords[i].draws;
        sector->vsRecords[i].losses = save->vsRecords[i].losses;
        sector->vsRecords[i].playerId = save->vsRecords[i].playerId;
        for (j = 0; j < 6; j++) {
            sector->vsRecords[i].playerName[j] = save->vsRecords[i].playerName[j];
        }
    }
    for (i = 0; i < (s32)(sizeof(save->timeRecords.table) / sizeof((save->timeRecords.table)[0])); i++) {
        for (j = 0; j < (s32)(sizeof(save->timeRecords.table[0]) / sizeof((save->timeRecords.table[0])[0])); j++) {
            for (k = 0; k < (s32)(sizeof(save->timeRecords.table[0][0]) / sizeof((save->timeRecords.table[0][0])[0])); k++) {
                sector->timeRecords.table[i][j][k].character1 = save->timeRecords.table[i][j][k].character1;
                sector->timeRecords.table[i][j][k].character2 = save->timeRecords.table[i][j][k].character2;
                sector->timeRecords.table[i][j][k].time = save->timeRecords.table[i][j][k].time;
            }
        }
    }
    switch (save->buttonConfig.jump) {
        case 0x0001:
            sector->buttonConfig.jump = 1;
            break;
        case 0x0002:
            sector->buttonConfig.attack = 1;
            break;
        case 0x0100:
            sector->buttonConfig.trick = 1;
            break;
    }
    switch (save->buttonConfig.attack) {
        case 0x0001:
            sector->buttonConfig.jump = 2;
            break;
        case 0x0002:
            sector->buttonConfig.attack = 2;
            break;
        case 0x0100:
            sector->buttonConfig.trick = 2;
            break;
    }
    switch (save->buttonConfig.trick) {
        case 0x0001:
            sector->buttonConfig.jump = 4;
            break;
        case 0x0002:
            sector->buttonConfig.attack = 4;
            break;
        case 0x0100:
            sector->buttonConfig.trick = 4;
            break;
    }
    sector->difficulty = save->difficulty;
    sector->disableTimeLimit = save->disableTimeLimit;
    sector->language = save->language;
    sector->unk367 = 0;
    sector->checksum = GetSaveSectorChecksum(sector);
}
