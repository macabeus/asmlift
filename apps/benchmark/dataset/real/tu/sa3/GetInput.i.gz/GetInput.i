typedef long int ptrdiff_t;
typedef unsigned long int size_t;
typedef int wchar_t;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef int int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef uint16_t winreg_t;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
typedef u16 MetatileIndexType;
typedef u8 int_vcount;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef u8 bool8;
typedef u16 bool16;
typedef u32 bool32;
struct BgCnt
{
    u16 priority:2;
    u16 charBaseBlock:2;
    u16 dummy:2;
    u16 mosaic:1;
    u16 palettes:1;
    u16 screenBaseBlock:5;
    u16 areaOverflowMode:1;
    u16 screenSize:2;
};
typedef volatile struct BgCnt vBgCnt;
struct PlttData
{
    u16 r:5;
    u16 g:5;
    u16 b:5;
    u16 unused_15:1;
};
typedef struct __attribute__((packed)) OamDataShort { u32 y : 8; u32 affineMode : 2; u32 objMode : 2; u32 mosaic : 1; u32 bpp : 1; u32 shape : 2; u32 x : 9; u32 matrixNum : 5; u32 size : 2; u16 tileNum : 10; u16 priority : 2; u16 paletteNum : 4; } OamDataShort;;
typedef union {
    struct {
             u32 y:8;
             u32 affineMode:2;
             u32 objMode:2;
             u32 mosaic:1;
             u32 bpp:1;
             u32 shape:2;
             u32 x:9;
             u32 matrixNum:5;
             u32 size:2;
             u16 tileNum:10;
             u16 priority:2;
             u16 paletteNum:4;
             u16 fractional:8;
             u16 integer:7;
             u16 sign:1;
    } split;
    struct {
        u16 attr0;
        u16 attr1;
        u16 attr2;
        u16 affineParam;
    } all;
    u16 raw[4];
} OamData;
struct BgAffineSrcData
{
    s32 texX;
    s32 texY;
    s16 scrX;
    s16 scrY;
    s16 sx;
    s16 sy;
    u16 alpha;
};
struct BgAffineDstData
{
    s16 pa;
    s16 pb;
    s16 pc;
    s16 pd;
    s32 dx;
    s32 dy;
};
struct ObjAffineSrcData
{
    s16 xScale;
    s16 yScale;
    u16 rotation;
};
struct SioNormalCnt
{
    u16 sck_I_O:1;
    u16 sck:1;
    u16 ackRecv:1;
    u16 ackSend:1;
    u16 unused_6_4:3;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct SioMultiCnt
{
    u16 baudRate:2;
    u16 si:1;
    u16 sd:1;
    u16 id:2;
    u16 error:1;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u16 data;
};
struct SioUartCnt
{
    u16 baudRate:2;
    u16 ctsEnable:1;
    u16 paritySelect:1;
    u16 transDataFull:1;
    u16 recvDataEmpty:1;
    u16 error:1;
    u16 length:1;
    u16 fifoEnable:1;
    u16 parityEnable:1;
    u16 transEnable:1;
    u16 recvEnable:1;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct JoyCnt
{
    u8 ifReset:1;
    u8 ifRecv:1;
    u8 ifSend:1;
    u8 unused_5_3:3;
    u8 ifEnable:1;
    u8 unused_7:1;
};
struct JoyStat
{
    u8 unused_0:1;
    u8 recv:1;
    u8 unused_2:1;
    u8 send:1;
    u8 flags:2;
    u8 unused_7_6:2;
};
struct RCnt
{
    u8 sc:1;
    u8 sd:1;
    u8 si:1;
    u8 so:1;
    u8 sc_i_o:1;
    u8 sd_i_o:1;
    u8 si_i_o:1;
    u8 so_i_o:1;
    u8 ifEnable:1;
    u8 unused_13_9:5;
    u8 sioModeMaster:2;
};
struct MultiBootParam
{
    u32 system_work[5];
    u8 handshake_data;
    u8 padding;
    u16 handshake_timeout;
    u8 probe_count;
    u8 client_data[3];
    u8 palette_data;
    u8 response_bit;
    u8 client_bit;
    u8 reserved1;
    u8 *boot_srcp;
    u8 *boot_endp;
    u8 *masterp;
    u8 *reserved2[3];
    u32 system_work2[4];
    u8 sendflag;
    u8 probe_target_bit;
    u8 check_wait;
    u8 server_type;
};
typedef struct {
    u32 srcLength : 16;
    u32 srcWidth : 8;
    u32 dstWidth : 8;
} BitUnPackData;
void SoftReset(u32 resetFlags);
void SoftResetExram(u32 resetFlags);
void RegisterRamReset(u32 resetFlags);
void VBlankIntrWait(void);
u16 Sqrt(u32 num);
u16 ArcTan2(s16 x, s16 y);
void CpuSet(const void *src, void *dest, u32 control);
void CpuFastSet(const void *src, void *dest, u32 control);
void BgAffineSet(struct BgAffineSrcData *src, struct BgAffineDstData *dest, s32 count);
void ObjAffineSet(struct ObjAffineSrcData *src, void *dest, s32 count, s32 offset);
void LZ77UnCompWram(const void *src, void *dest);
void LZ77UnCompVram(const void *src, void *dest);
void RLUnCompWram(const void *src, void *dest);
void RLUnCompVram(const void *src, void *dest);
int MultiBoot(struct MultiBootParam *mp);
s32 Div(s32 num, s32 denom);
s32 DivArm(s32 denom, s32 num);
s32 Mod(s32 num, s32 denom);
s32 ModArm(s32 denom, s32 num);
void SoundBiasReset(void);
void SoundBiasSet(void);
void AGBPrintInit(void);
void AGBPutc(const char cChr);
void AGBPrint(const char *pBuf);
void AGBPrintf(const char *pBuf, ...);
void AGBPrintFlush1Block(void);
void AGBPrintFlush(void);
void AGBAssert(const char *pFile, int nLine, const char *pExpression, int nStopProgram);
typedef void (*VoidFn)(void);
typedef struct {
    s16 x;
    s16 y;
} Vec2_16;
typedef struct {
    u16 x;
    u16 y;
} Vec2_u16;
typedef struct {
    s32 x;
    s32 y;
} Vec2_32;
typedef struct {
    u8 reserved : 4;
    u8 compressedType : 4;
    u32 size : 24;
    void *data;
} RLCompressed;
struct BlendRegs {
    u16 bldCnt;
    u16 bldAlpha;
    u16 bldY;
};
typedef struct {
               u16 pa, pb, pc, pd;
               u32 x, y;
} BgAffineReg;
typedef void (*HBlankIntrFunc)(int_vcount vcount);
typedef void (*IntrFunc)(void);
typedef bool32 (*VBlankFunc)(void);
extern void *iwram_end;
extern void *ewram_end;
extern void *rom_footer;
struct EwramNode {
              struct EwramNode *next;
              s32 state;
              u8 space[0];
};
void EwramInitHeap(void);
void *EwramMalloc(u32);
void EwramFree(void *);
extern u8 gEwramHeap[0x20080];
typedef int __int32_t;
typedef unsigned int __uint32_t;
void * memchr (const void *, int, size_t);
int memcmp (const void *, const void *, size_t);
void * memcpy (void *, const void *, size_t);
void * memmove (void *, const void *, size_t);
void * memset (void *, int, size_t);
char *strcat (char *, const char *);
char *strchr (const char *, int);
int strcmp (const char *, const char *);
int strcoll (const char *, const char *);
char *strcpy (char *, const char *);
size_t strcspn (const char *, const char *);
char *strerror (int);
size_t strlen (const char *);
char *strncat (char *, const char *, size_t);
int strncmp (const char *, const char *, size_t);
char *strncpy (char *, const char *, size_t);
char *strpbrk (const char *, const char *);
char *strrchr (const char *, int);
size_t strspn (const char *, const char *);
char *strstr (const char *, const char *);
char *strtok (char *, const char *);
size_t strxfrm (char *, const char *, size_t);
char *strtok_r (char *, const char *, char **);
int bcmp (const char *, const char *, size_t);
void bcopy (const char *, char *, size_t);
void bzero (char *, size_t);
int ffs (int);
char *index (const char *, int);
void * memccpy (void *, const void *, int, size_t);
char *rindex (const char *, int);
int strcasecmp (const char *, const char *);
char *strdup (const char *);
int strncasecmp (const char *, const char *, size_t);
char *strsep (char **, const char *);
char *strlwr (char *);
char *strupr (char *);
typedef struct Rect8 {
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} Rect8;
typedef u16 AnimId;
struct GraphicsData {
               const void *src;
               void *dest;
               u16 size;
               AnimId anim;
};
typedef struct {
               struct GraphicsData graphics;
               u16 *layoutVram;
               const u16 *layout;
               u16 xTiles;
               u16 yTiles;
               u16 unk18;
               u16 unk1A;
               u16 tilemapId;
               u16 unk1E;
               u16 unk20;
               u16 unk22;
               u16 unk24;
               u16 targetTilesX;
               u16 targetTilesY;
               u8 paletteOffset;
               u8 animFrameCounter;
               u8 animDelayCounter;
               u16 flags;
               u16 scrollX;
               u16 scrollY;
               u16 prevScrollX;
               u16 prevScrollY;
               const u16 *metatileMap;
               u16 mapWidth;
               u16 mapHeight;
} Background;
typedef struct {
               u16 oamIndex;
               u16 numSubframes;
               u16 width;
               u16 height;
               s16 offsetX;
               s16 offsetY;
} SpriteOffset;
typedef struct {
               s32 index;
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} HitboxOld;
typedef struct {
               s32 index;
               Rect8 b;
} Hitbox;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[1];
} Sprite;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[2];
} Sprite2;
typedef struct {
               u16 rotation;
               s16 qScaleX;
               s16 qScaleY;
               s16 x;
               s16 y;
} SpriteTransform;
typedef struct {
               s16 unk0[4];
               s16 qDirX;
               s16 qDirY;
               s16 unkC[2];
               s32 posX;
               s32 posY;
               s16 unk18[2][2];
               u16 affineIndex;
} UnkSpriteStruct;
typedef struct {
               u32 numTiles;
               AnimId anim;
               u8 variant;
} TileInfo;
typedef struct {
               AnimId anim;
               u8 variant;
               u32 numTiles;
} TileInfo2;
typedef struct PACKED {
               u16 numTiles;
               AnimId anim;
               u16 variant;
} TileInfo_16;
extern const u8 gOamShapesSizes[12][2];
typedef enum {
    ACMD_RESULT__ANIM_CHANGED = -1,
    ACMD_RESULT__ENDED = 0,
    ACMD_RESULT__RUNNING = +1,
} AnimCmdResult;
AnimCmdResult UpdateSpriteAnimation(Sprite *);
void DisplaySprite(Sprite *s);
void DisplaySprites(Sprite *s, Vec2_16 *positions, u16 count);
void DrawBackground(Background *);
bool32 sa2__sub_8002B20(void);
u32 sa2__sub_80039E4(void);
u32 sa2__sub_8004010(void);
s16 sa2__sub_8004418(s16 x, s16 y);
void ProcessOamBuffers(void);
OamData *OamMalloc(u8 order);
void TransformSprite(Sprite *sprite, SpriteTransform *transform);
void UnusedTransform(Sprite *, SpriteTransform *);
s16 sa2__sub_8004418(s16 x, s16 y);
extern u8 gNextFreeAffineIndex;
struct Task;
typedef void (*TaskMain)(void);
typedef void (*TaskDestructor)(struct Task *);
typedef u16 TaskPtr;
typedef u32 TaskPtr32;
typedef u16 IwramData;
typedef struct Task {
               TaskPtr parent;
               TaskPtr prev;
               TaskPtr next;
               IwramData data;
               TaskMain main;
               TaskDestructor dtor;
               u16 priority;
               u16 flags;
} Task;
typedef u16 IwramNodePtr;
typedef u32 IwramNodePtr32;
struct IwramNode {
    IwramNodePtr next;
    s16 state;
    u8 __attribute__((aligned(sizeof(void *)))) space[0];
};
extern struct Task gTasks[128];
extern struct Task gEmptyTask;
extern struct Task *gTaskPtrs[128];
extern s32 gNumTasks;
extern struct Task *gNextTaskToCheckForDestruction;
extern struct Task *gNextTask;
extern struct Task *gCurTask;
extern u8 gIwramHeap[((0x881) * sizeof(uintptr_t))];
u32 TasksInit(void);
void TasksExec(void);
struct Task *TaskCreate(TaskMain taskMain, u16 structSize, u16 priority, u16 flags, TaskDestructor taskDestructor);
void TaskDestroy(struct Task *);
void *IwramMalloc(u16);
void IwramFree(void *p);
void TasksDestroyInPriorityRange(u16, u16);
typedef struct {
    u16 index : 10;
    u16 xFlip : 1;
    u16 yFlip : 1;
    u16 pal : 4;
} Tile;
typedef struct {
               u16 xTiles;
               u16 yTiles;
               u16 animTileSize;
               u8 animFrameCount;
               u8 animDelay;
               const u8 *tiles;
               u32 tilesSize;
               const u16 *palette;
               u16 palOffset;
               u16 palLength;
               const u16 *map;
} Tilemap;
struct MapHeader {
               Tilemap tileset;
               const u16 *metatileMap;
               u16 mapWidth;
               u16 mapHeight;
};
struct MultiSioPacket {
    u8 frameCounter;
    u8 recvErrorFlags : 4;
    u8 loadRequest : 1;
    u8 downloadSuccessFlag : 1;
    u8 loadSuccessFlag : 1;
    u8 reserved_0 : 1;
    u16 checkSum;
    u16 data[24 / 2];
    u16 overrunCatch[2];
};
struct MultiSioArea {
    u8 type;
    u8 state;
    u8 connectedFlags;
    u8 recvSuccessFlags;
    u8 syncRecvFlag[4];
    u8 downloadSuccessFlags : 4;
    u8 loadEnable : 1;
    u8 loadRequest : 1;
    u8 loadSuccessFlag : 1;
    u8 startFlag : 1;
    u8 hardError;
    u8 recvFlagsAvailableCounter;
    u8 sendFrameCounter;
    u8 recvFrameCounter[4][2];
    s32 sendBufCounter;
    s32 recvBufCounter[4];
    u16 *nextSendBufp;
    u16 *currentSendBufp;
    u16 *currentRecvBufp[4];
    u16 *lastRecvBufp[4];
    u16 *recvCheckBufp[4];
    struct MultiSioPacket sendBuf[2];
    struct MultiSioPacket recvBuf[4][3];
};
extern u32 gMultiSioRecvFuncBuf[0x40 / 4];
extern u8 gUnknown_03002BE0[0x10];
extern u32 gUnknown_03002BF0;
extern u32 gMultiSioIntrFuncBuf[0x120 / 4];
extern struct MultiSioArea gMultiSioArea;
extern void MultiSioInit(u32 connectedFlags);
void MultiSioStart(void);
void MultiSioStop(void);
extern u32 MultiSioMain(void *sendp, void *recvp, u32 loadRequest);
struct MultiSioReturn {
    u32 recvSuccessFlags : 4;
    u32 loadEnable : 1;
    u32 loadRequest : 1;
    u32 loadSuccessFlag : 1;
    u32 type : 1;
    u32 connectedFlags : 4;
    u32 hardError : 1;
    u32 idOverError : 1;
    u32 reserved : 1;
    u32 recvFlagsAvailable : 1;
};
extern void MultiSioIntr(void);
extern void MultiSioSendDataSet(void *sendp, u32 loadReq);
extern u32 MultiSioRecvDataCheck(void *recvp);
struct InputRecorder {
               s32 playbackHead;
               s32 recordHead;
               u8 mode;
};
void InputRecorderResetRecordHead(void);
void InputRecorderResetPlaybackHead(void);
void InputRecorderLoadTape(void);
u16 InputRecorderRead(void);
void InputRecorderWrite(u16);
typedef AnimCmdResult (*AnimationCommandFunc)(void *cursor, Sprite *sprite);
typedef struct {
               s32 cmdId;
               s32 tileIndex;
               u32 numTilesToCopy;
} ACmd_GetTiles;
typedef struct {
               s32 cmdId;
               s32 palId;
               u16 numColors;
               u16 insertOffset;
} ACmd_GetPalette;
typedef struct {
               s32 cmdId;
               s32 offset;
} ACmd_JumpBack;
typedef struct {
               s32 cmdId;
} ACmd_4;
typedef struct {
               s32 cmdId;
               u16 songId;
} ACmd_PlaySoundEffect;
typedef struct {
               s32 cmdId;
               Hitbox hitbox;
} ACmd_Hitbox;
typedef struct {
               s32 cmdId;
               u16 x;
               u16 y;
} ACmd_TranslateSprite;
typedef struct {
               s32 cmdId;
               s32 unk4;
               s32 unk8;
} ACmd_8;
typedef struct {
               s32 cmdId;
               AnimId animId;
               u16 variant;
} ACmd_SetIdAndVariant;
typedef struct {
               s32 cmdId;
               s32 unk4;
               s32 unk8;
               s32 unkC;
} ACmd_10;
typedef struct {
               s32 cmdId;
               s32 priority;
} ACmd_SetSpritePriority;
typedef struct {
               s32 cmdId;
               s32 orderIndex;
} ACmd_SetOamOrder;
typedef struct {
    s32 delay;
    s32 index;
} ACmd_ShowFrame;
typedef union {
    s32 id;
    ACmd_GetTiles tiles;
    ACmd_GetPalette pal;
    ACmd_JumpBack jump;
    ACmd_4 end;
    ACmd_PlaySoundEffect sfx;
    ACmd_Hitbox _6;
    ACmd_TranslateSprite translate;
    ACmd_8 _8;
    ACmd_SetIdAndVariant setAnimId;
    ACmd_10 _10;
    ACmd_SetSpritePriority _11;
    ACmd_SetOamOrder setOamOrder;
    ACmd_ShowFrame show;
} ACmd;
u32 Base10DigitsToHexNibbles(u16 num);
extern const ACmd **const gAnimations[1524];
extern const SpriteOffset *const gSpriteDimensions[1524];
extern const OamDataShort *const gSpriteOamData[1524];
extern const u16 gSpritePalettes[][16];
struct MultiSioData_0_0 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u32 unk4;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_1 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_2 {
    u8 unk0;
    u8 filler1;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u16 unk8[3];
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_3 {
    u16 unk0;
    u8 unk2;
    u8 unk3;
    u16 unk4;
    u16 unk6;
    u32 unk8;
    u16 unkC;
    u8 unkE;
    u8 unkF;
    u32 unk10;
};
struct MultiSioData_0_4 {
    u16 unk0;
    s16 x;
    s16 y;
    u16 unk6;
    u16 unk8;
    u8 unkA;
    u8 unkB;
    u8 unkC;
    u8 unkD;
    u8 unkE;
    u8 numRings;
    u8 unk10;
    u8 unk11;
    u8 unk12;
    u8 unk13;
};
struct MultiSioData_0_5 {
    u16 unk0;
    s16 x;
    s16 y;
    u8 filler3[0x9];
    u8 sioId;
    u8 unk10;
    u8 unk11;
    u8 unk12;
    u8 unk13;
};
union MultiSioData {
    struct MultiSioData_0_0 pat0;
    struct MultiSioData_0_1 pat1;
    struct MultiSioData_0_2 pat2;
    struct MultiSioData_0_3 pat3;
    struct MultiSioData_0_4 pat4;
    struct MultiSioData_0_5 pat5;
    u8 raw[24];
};
typedef u32 collPxDim_t;
typedef struct Collision {
               const s8 *height_map;
               const u8 *tile_rotation;
               const u16 *metatiles;
               const MetatileIndexType *map[2];
               const u16 *flags;
               u16 levelX, levelY;
               collPxDim_t pxWidth, pxHeight;
} Collision;
struct Unk_03003674_1_Sub {
    u16 unk0, unk2, unk4, unk6;
    s16 unk8, unkA;
};
struct Unk_03003674_1_Full {
    struct Unk_03003674_1_Sub sub;
    u32 unkC;
};
union Unk_03003674_1 {
    const struct Unk_03003674_1_Sub *sub;
    const struct Unk_03003674_1_Full *full;
};
struct Unk_03003674 {
    const union Unk_03003674_0 *const *unk0;
    const union Unk_03003674_1 *unk4;
    const u16 *const *unk8;
    const void *unkC;
    const void *unk10;
    const void *unk14;
    const s32 *unk18;
};
struct SpriteTables {
               const ACmd **const *animations;
               const SpriteOffset *const *dimensions;
               const u16 **const oamData;
               const u16 *const palettes;
               const u8 *const tiles_4bpp;
               const u8 *const tiles_8bpp;
               const void *const unk18;
};
extern u32 gFlags;
extern u32 gFlagsPreVBlank;
extern u32 gFrameCount;
extern IntrFunc gIntrTable[16];
extern IntrFunc const gIntrTableTemplate[14];
extern u32 gIntrMainBuf[0x80];
extern struct Task *gCurTask;
extern struct Task gTasks[128];
extern struct Task *gTaskPtrs[128];
extern struct Task *gNextTask;
extern struct Task gEmptyTask;
extern s32 gNumTasks;
extern u16 gInput;
extern u16 gPrevInput;
extern u16 gPhysicalInput;
extern u16 gReleasedKeys;
extern u16 gRepeatedKeys;
extern u16 gPressedKeys;
extern u8 gKeysFirstRepeatIntervals[10];
extern u8 gRepeatedKeysTestCounter[10];
extern u8 gKeysContinuedRepeatIntervals[10];
extern const u8 *gInputPlaybackData;
extern struct InputRecorder gInputRecorder;
extern u16 *gInputRecorderTapeBuffer;
extern union MultiSioData gMultiSioSend;
extern union MultiSioData gMultiSioRecv[4];
extern u32 gMultiSioStatusFlags;
extern bool8 gMultiSioEnabled;
extern HBlankIntrFunc gHBlankIntrs[4];
extern HBlankIntrFunc gHBlankCallbacks[4];
extern u8 gNumHBlankCallbacks;
extern u8 gNumHBlankIntrs;
extern void *gVramHeapStartAddr;
extern u16 gVramHeapMaxTileSlots;
extern u16 gVramHeapState[256];
extern bool8 gExecSoundMain;
extern u16 gDispCnt;
extern winreg_t gWinRegs[6];
extern struct BlendRegs gBldRegs;
extern BgAffineReg gBgAffineRegs[2];
extern u16 gObjPalette[0x200 / sizeof(u16)];
extern u16 gBgPalette[0x200 / sizeof(u16)];
extern u16 gBgCntRegs[4];
extern s16 gBgScrollRegs[4][2];
extern OamData gOamMallocBuffer[128];
extern OamData gOamBuffer[128];
extern int_vcount gBgOffsetsBuffer[2][160][4];
extern Background *gBackgroundsCopyQueue[16];
extern void *gBgOffsetsHBlankPrimary;
extern u16 sa2__gUnknown_030017F0;
extern Vec2_16 gSpriteOffset;
extern u8 gOamMallocOrders_StartIndex[32];
extern IntrFunc gVBlankCallbacks[4];
extern u8 gOamFreeIndex;
extern u16 sa2__gUnknown_03001944;
extern u8 gNumVBlankIntrs;
extern s16 sa2__gUnknown_0300194C;
extern Tilemap **gTilemapsRef;
extern u8 gBgSprites_Unknown2[4][4];
extern u8 gBgSprites_Unknown1[16];
extern struct GraphicsData gVramGraphicsCopyQueue[32];
extern u8 gVramGraphicsCopyQueueIndex;
extern void *gBgOffsetsHBlankSecondary;
extern void *sa2__gUnknown_030022C0;
extern s16 sa2__gUnknown_03002820;
extern u8 sa2__gUnknown_03002874;
extern void *gHBlankCopyTarget;
extern u8 gBackgroundsCopyQueueIndex;
extern u8 gHBlankCopySize;
extern u16 sa2__gUnknown_03002A8C;
extern u8 gOamFirstPausedIndex;
extern u8 gBackgroundsCopyQueueCursor;
extern Sprite *gBgSprites[16];
extern u8 gNumVBlankCallbacks;
extern void *gBgOffsetsPrimary;
extern u16 sa2__gUnknown_03004D58;
extern u8 gVramGraphicsCopyCursor;
extern u8 gOamMallocOrders_EndIndex[0x20];
extern u8 gBgSpritesCount;
extern u16 sa2__gUnknown_03005394;
extern u16 sa2__gUnknown_03005398;
extern IntrFunc gVBlankIntrs[4];
extern s32 gPseudoRandom;
extern u8 gOamMallocCopiedOrder[128];
extern struct MultiBootParam gMultiBootParam;
extern const struct SpriteTables *gRefSpriteTables;
void EngineInit(void);
void EngineMainLoop(void);
void GetInput(void)
{
    s8 i;
    u8 *repeatKeyCounters = gRepeatedKeysTestCounter, *firstIntervals = gKeysFirstRepeatIntervals,
       *continuedHoldIntervals = gKeysContinuedRepeatIntervals;
    gInput = (~(*(vu16 *)(0x4000000 + 0x130)) & 0x03FF);
    gPhysicalInput = gInput;
    if (gInputRecorder.mode == 1) {
        InputRecorderWrite(gInput);
    } else if (gInputRecorder.mode == 2) {
        gInput = InputRecorderRead();
    }
    gPressedKeys = (gInput ^ gPrevInput) & gInput;
    gReleasedKeys = (gInput ^ gPrevInput) & gPrevInput;
    gPrevInput = gInput;
    gRepeatedKeys = gPressedKeys;
    for (i = 0; i < 10; i++) {
        if (!(((gInput) >> (i)) & 1)) {
            repeatKeyCounters[i] = firstIntervals[i];
        } else if (repeatKeyCounters[i] > 0) {
            repeatKeyCounters[i]--;
        } else {
            gRepeatedKeys |= 1 << i;
            repeatKeyCounters[i] = continuedHoldIntervals[i];
        }
    }
}
