typedef long int ptrdiff_t;
typedef unsigned long int size_t;
typedef int wchar_t;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef int int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef uint16_t winreg_t;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
typedef u16 MetatileIndexType;
typedef u8 int_vcount;
typedef volatile u8 vu8;
typedef volatile u16 vu16;
typedef volatile u32 vu32;
typedef volatile u64 vu64;
typedef volatile s8 vs8;
typedef volatile s16 vs16;
typedef volatile s32 vs32;
typedef volatile s64 vs64;
typedef float f32;
typedef double f64;
typedef u8 bool8;
typedef u16 bool16;
typedef u32 bool32;
struct BgCnt
{
    u16 priority:2;
    u16 charBaseBlock:2;
    u16 dummy:2;
    u16 mosaic:1;
    u16 palettes:1;
    u16 screenBaseBlock:5;
    u16 areaOverflowMode:1;
    u16 screenSize:2;
};
typedef volatile struct BgCnt vBgCnt;
struct PlttData
{
    u16 r:5;
    u16 g:5;
    u16 b:5;
    u16 unused_15:1;
};
typedef struct __attribute__((packed)) OamDataShort { u32 y : 8; u32 affineMode : 2; u32 objMode : 2; u32 mosaic : 1; u32 bpp : 1; u32 shape : 2; u32 x : 9; u32 matrixNum : 5; u32 size : 2; u16 tileNum : 10; u16 priority : 2; u16 paletteNum : 4; } OamDataShort;;
typedef union {
    struct {
             u32 y:8;
             u32 affineMode:2;
             u32 objMode:2;
             u32 mosaic:1;
             u32 bpp:1;
             u32 shape:2;
             u32 x:9;
             u32 matrixNum:5;
             u32 size:2;
             u16 tileNum:10;
             u16 priority:2;
             u16 paletteNum:4;
             u16 fractional:8;
             u16 integer:7;
             u16 sign:1;
    } split;
    struct {
        u16 attr0;
        u16 attr1;
        u16 attr2;
        u16 affineParam;
    } all;
    u16 raw[4];
} OamData;
struct BgAffineSrcData
{
    s32 texX;
    s32 texY;
    s16 scrX;
    s16 scrY;
    s16 sx;
    s16 sy;
    u16 alpha;
};
struct BgAffineDstData
{
    s16 pa;
    s16 pb;
    s16 pc;
    s16 pd;
    s32 dx;
    s32 dy;
};
struct ObjAffineSrcData
{
    s16 xScale;
    s16 yScale;
    u16 rotation;
};
struct SioNormalCnt
{
    u16 sck_I_O:1;
    u16 sck:1;
    u16 ackRecv:1;
    u16 ackSend:1;
    u16 unused_6_4:3;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct SioMultiCnt
{
    u16 baudRate:2;
    u16 si:1;
    u16 sd:1;
    u16 id:2;
    u16 error:1;
    u16 enable:1;
    u16 unused_11_8:4;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u16 data;
};
struct SioUartCnt
{
    u16 baudRate:2;
    u16 ctsEnable:1;
    u16 paritySelect:1;
    u16 transDataFull:1;
    u16 recvDataEmpty:1;
    u16 error:1;
    u16 length:1;
    u16 fifoEnable:1;
    u16 parityEnable:1;
    u16 transEnable:1;
    u16 recvEnable:1;
    u16 mode:2;
    u16 ifEnable:1;
    u16 unused_15:1;
    u8 data;
    u8 unused_31_24;
};
struct JoyCnt
{
    u8 ifReset:1;
    u8 ifRecv:1;
    u8 ifSend:1;
    u8 unused_5_3:3;
    u8 ifEnable:1;
    u8 unused_7:1;
};
struct JoyStat
{
    u8 unused_0:1;
    u8 recv:1;
    u8 unused_2:1;
    u8 send:1;
    u8 flags:2;
    u8 unused_7_6:2;
};
struct RCnt
{
    u8 sc:1;
    u8 sd:1;
    u8 si:1;
    u8 so:1;
    u8 sc_i_o:1;
    u8 sd_i_o:1;
    u8 si_i_o:1;
    u8 so_i_o:1;
    u8 ifEnable:1;
    u8 unused_13_9:5;
    u8 sioModeMaster:2;
};
struct MultiBootParam
{
    u32 system_work[5];
    u8 handshake_data;
    u8 padding;
    u16 handshake_timeout;
    u8 probe_count;
    u8 client_data[3];
    u8 palette_data;
    u8 response_bit;
    u8 client_bit;
    u8 reserved1;
    u8 *boot_srcp;
    u8 *boot_endp;
    u8 *masterp;
    u8 *reserved2[3];
    u32 system_work2[4];
    u8 sendflag;
    u8 probe_target_bit;
    u8 check_wait;
    u8 server_type;
};
typedef struct {
    u32 srcLength : 16;
    u32 srcWidth : 8;
    u32 dstWidth : 8;
} BitUnPackData;
void SoftReset(u32 resetFlags);
void SoftResetExram(u32 resetFlags);
void RegisterRamReset(u32 resetFlags);
void VBlankIntrWait(void);
u16 Sqrt(u32 num);
u16 ArcTan2(s16 x, s16 y);
void CpuSet(const void *src, void *dest, u32 control);
void CpuFastSet(const void *src, void *dest, u32 control);
void BgAffineSet(struct BgAffineSrcData *src, struct BgAffineDstData *dest, s32 count);
void ObjAffineSet(struct ObjAffineSrcData *src, void *dest, s32 count, s32 offset);
void LZ77UnCompWram(const void *src, void *dest);
void LZ77UnCompVram(const void *src, void *dest);
void RLUnCompWram(const void *src, void *dest);
void RLUnCompVram(const void *src, void *dest);
int MultiBoot(struct MultiBootParam *mp);
s32 Div(s32 num, s32 denom);
s32 DivArm(s32 denom, s32 num);
s32 Mod(s32 num, s32 denom);
s32 ModArm(s32 denom, s32 num);
void SoundBiasReset(void);
void SoundBiasSet(void);
void AGBPrintInit(void);
void AGBPutc(const char cChr);
void AGBPrint(const char *pBuf);
void AGBPrintf(const char *pBuf, ...);
void AGBPrintFlush1Block(void);
void AGBPrintFlush(void);
void AGBAssert(const char *pFile, int nLine, const char *pExpression, int nStopProgram);
typedef void (*VoidFn)(void);
typedef struct {
    s16 x;
    s16 y;
} Vec2_16;
typedef struct {
    u16 x;
    u16 y;
} Vec2_u16;
typedef struct {
    s32 x;
    s32 y;
} Vec2_32;
typedef struct {
    u8 reserved : 4;
    u8 compressedType : 4;
    u32 size : 24;
    void *data;
} RLCompressed;
struct BlendRegs {
    u16 bldCnt;
    u16 bldAlpha;
    u16 bldY;
};
typedef struct {
               u16 pa, pb, pc, pd;
               u32 x, y;
} BgAffineReg;
typedef void (*HBlankIntrFunc)(int_vcount vcount);
typedef void (*IntrFunc)(void);
typedef bool32 (*VBlankFunc)(void);
extern void *iwram_end;
extern void *ewram_end;
extern void *rom_footer;
struct EwramNode {
              struct EwramNode *next;
              s32 state;
              u8 space[0];
};
void EwramInitHeap(void);
void *EwramMalloc(u32);
void EwramFree(void *);
extern u8 gEwramHeap[0x20080];
typedef struct Rect8 {
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} Rect8;
typedef u16 AnimId;
struct GraphicsData {
               const void *src;
               void *dest;
               u16 size;
               AnimId anim;
};
typedef struct {
               struct GraphicsData graphics;
               u16 *layoutVram;
               const u16 *layout;
               u16 xTiles;
               u16 yTiles;
               u16 unk18;
               u16 unk1A;
               u16 tilemapId;
               u16 unk1E;
               u16 unk20;
               u16 unk22;
               u16 unk24;
               u16 targetTilesX;
               u16 targetTilesY;
               u8 paletteOffset;
               u8 animFrameCounter;
               u8 animDelayCounter;
               u16 flags;
               u16 scrollX;
               u16 scrollY;
               u16 prevScrollX;
               u16 prevScrollY;
               const u16 *metatileMap;
               u16 mapWidth;
               u16 mapHeight;
} Background;
typedef struct {
               u16 oamIndex;
               u16 numSubframes;
               u16 width;
               u16 height;
               s16 offsetX;
               s16 offsetY;
} SpriteOffset;
typedef struct {
               s32 index;
               s8 left;
               s8 top;
               s8 right;
               s8 bottom;
} HitboxOld;
typedef struct {
               s32 index;
               Rect8 b;
} Hitbox;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[1];
} Sprite;
typedef struct {
               u8 *tiles;
               u32 frameNum;
               u32 frameFlags;
               u16 anim;
               u16 animCursor;
               s16 x;
               s16 y;
               s16 oamFlags;
               s16 qAnimDelay;
               u16 prevAnim;
               u8 variant;
               u8 prevVariant;
               u8 animSpeed;
               u8 oamBaseIndex;
               u8 numSubFrames;
               u8 palId;
               Hitbox hitboxes[2];
} Sprite2;
typedef struct {
               u16 rotation;
               s16 qScaleX;
               s16 qScaleY;
               s16 x;
               s16 y;
} SpriteTransform;
typedef struct {
               s16 unk0[4];
               s16 qDirX;
               s16 qDirY;
               s16 unkC[2];
               s32 posX;
               s32 posY;
               s16 unk18[2][2];
               u16 affineIndex;
} UnkSpriteStruct;
typedef struct {
               u32 numTiles;
               AnimId anim;
               u8 variant;
} TileInfo;
typedef struct {
               AnimId anim;
               u8 variant;
               u32 numTiles;
} TileInfo2;
typedef struct PACKED {
               u16 numTiles;
               AnimId anim;
               u16 variant;
} TileInfo_16;
extern const u8 gOamShapesSizes[12][2];
typedef enum {
    ACMD_RESULT__ANIM_CHANGED = -1,
    ACMD_RESULT__ENDED = 0,
    ACMD_RESULT__RUNNING = +1,
} AnimCmdResult;
AnimCmdResult UpdateSpriteAnimation(Sprite *);
void DisplaySprite(Sprite *s);
void DisplaySprites(Sprite *s, Vec2_16 *positions, u16 count);
void DrawBackground(Background *);
bool32 sa2__sub_8002B20(void);
u32 sa2__sub_80039E4(void);
u32 sa2__sub_8004010(void);
s16 sa2__sub_8004418(s16 x, s16 y);
void ProcessOamBuffers(void);
OamData *OamMalloc(u8 order);
void TransformSprite(Sprite *sprite, SpriteTransform *transform);
void UnusedTransform(Sprite *, SpriteTransform *);
s16 sa2__sub_8004418(s16 x, s16 y);
extern u8 gNextFreeAffineIndex;
struct MultiSioPacket {
    u8 frameCounter;
    u8 recvErrorFlags : 4;
    u8 loadRequest : 1;
    u8 downloadSuccessFlag : 1;
    u8 loadSuccessFlag : 1;
    u8 reserved_0 : 1;
    u16 checkSum;
    u16 data[24 / 2];
    u16 overrunCatch[2];
};
struct MultiSioArea {
    u8 type;
    u8 state;
    u8 connectedFlags;
    u8 recvSuccessFlags;
    u8 syncRecvFlag[4];
    u8 downloadSuccessFlags : 4;
    u8 loadEnable : 1;
    u8 loadRequest : 1;
    u8 loadSuccessFlag : 1;
    u8 startFlag : 1;
    u8 hardError;
    u8 recvFlagsAvailableCounter;
    u8 sendFrameCounter;
    u8 recvFrameCounter[4][2];
    s32 sendBufCounter;
    s32 recvBufCounter[4];
    u16 *nextSendBufp;
    u16 *currentSendBufp;
    u16 *currentRecvBufp[4];
    u16 *lastRecvBufp[4];
    u16 *recvCheckBufp[4];
    struct MultiSioPacket sendBuf[2];
    struct MultiSioPacket recvBuf[4][3];
};
extern u32 gMultiSioRecvFuncBuf[0x40 / 4];
extern u8 gUnknown_03002BE0[0x10];
extern u32 gUnknown_03002BF0;
extern u32 gMultiSioIntrFuncBuf[0x120 / 4];
extern struct MultiSioArea gMultiSioArea;
extern void MultiSioInit(u32 connectedFlags);
void MultiSioStart(void);
void MultiSioStop(void);
extern u32 MultiSioMain(void *sendp, void *recvp, u32 loadRequest);
struct MultiSioReturn {
    u32 recvSuccessFlags : 4;
    u32 loadEnable : 1;
    u32 loadRequest : 1;
    u32 loadSuccessFlag : 1;
    u32 type : 1;
    u32 connectedFlags : 4;
    u32 hardError : 1;
    u32 idOverError : 1;
    u32 reserved : 1;
    u32 recvFlagsAvailable : 1;
};
extern void MultiSioIntr(void);
extern void MultiSioSendDataSet(void *sendp, u32 loadReq);
extern u32 MultiSioRecvDataCheck(void *recvp);
struct Task;
typedef void (*TaskMain)(void);
typedef void (*TaskDestructor)(struct Task *);
typedef u16 TaskPtr;
typedef u32 TaskPtr32;
typedef u16 IwramData;
typedef struct Task {
               TaskPtr parent;
               TaskPtr prev;
               TaskPtr next;
               IwramData data;
               TaskMain main;
               TaskDestructor dtor;
               u16 priority;
               u16 flags;
} Task;
typedef u16 IwramNodePtr;
typedef u32 IwramNodePtr32;
struct IwramNode {
    IwramNodePtr next;
    s16 state;
    u8 __attribute__((aligned(sizeof(void *)))) space[0];
};
extern struct Task gTasks[128];
extern struct Task gEmptyTask;
extern struct Task *gTaskPtrs[128];
extern s32 gNumTasks;
extern struct Task *gNextTaskToCheckForDestruction;
extern struct Task *gNextTask;
extern struct Task *gCurTask;
extern u8 gIwramHeap[((0x881) * sizeof(uintptr_t))];
u32 TasksInit(void);
void TasksExec(void);
struct Task *TaskCreate(TaskMain taskMain, u16 structSize, u16 priority, u16 flags, TaskDestructor taskDestructor);
void TaskDestroy(struct Task *);
void *IwramMalloc(u16);
void IwramFree(void *p);
void TasksDestroyInPriorityRange(u16, u16);
typedef enum {
    CHARACTER_SONIC,
    CHARACTER_CREAM,
    CHARACTER_TAILS,
    CHARACTER_KNUCKLES,
    CHARACTER_AMY,
    NUM_CHARACTERS
} ECharacters;
void GameStart(void);
extern const s16 gPlayerCharacterIdleAnims[NUM_CHARACTERS];
typedef struct __attribute__((packed)) MapEntity { u8 x; u8 y; u8 index; union { s8 sData[5]; u8 uData[5]; } d; } MapEntity;;
typedef struct __attribute__((packed)) MapEntity_Itembox { u8 x; u8 y; u8 index; } MapEntity_Itembox;;
typedef struct __attribute__((packed)) MapEntity_Ring { u8 x; u8 y; } MapEntity_Ring;;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 unk8;
               u8 unk9;
               u8 meX;
               u8 id;
} SpriteBase;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u16 unk8;
               u8 meX;
               u8 id;
} SpriteBase2;
typedef struct {
               MapEntity *me;
               s32 qWorldX;
               s32 qWorldY;
               u16 regionX;
               u16 regionY;
               u16 unk10;
               s16 unk12;
               u8 meX;
               u8 id;
               u8 unk16;
               u8 unk17;
               u8 unk18;
               u8 unk19;
} SpriteBase3;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 filler8[0x2];
               u16 qSpeedAirX;
               u16 qSpeedAirY;
               u8 meX;
               u8 id;
} SpriteBase4;
typedef struct {
               MapEntity *me;
               u16 regionX;
               u16 regionY;
               u8 meX;
               u8 id;
               u8 unkA;
               u8 unkB;
} SpriteBase5;
typedef struct {
    SpriteBase base;
    Sprite s;
} EnemyBase;
typedef enum {
    SONIC,
    CREAM,
    TAILS,
    KNUCKLES,
    AMY,
    PLAYERCHAR_COUNT,
    PLAYERCHAR_NONE = 0xFF,
} eCharacter;
struct Player;
typedef struct Player Player;
typedef void (*PlayerCallback)(Player *p);
typedef union __attribute__((packed)) StateNum { u16 raw; struct { u8 subCount : 4; u8 other : 3; u8 subHighBit : 1; s8 highValue : 8; } split; } StateNum;;
typedef struct {
               SpriteTransform tf;
               Sprite2 s;
} PlayerSpriteInfo;
typedef struct PlayerUnkC4 {
    u32 unk0;
    s16 playerId;
} PlayerUnkC4;
typedef struct PlayerUnk148_A {
    s16 unk0;
    s16 unk2;
    u8 unk4;
    u8 unk5;
    u8 unk6;
    u8 unk7;
    s16 unk8;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_A;
typedef struct PlayerUnk148_B {
    s16 unk0;
    u8 unk2;
    u8 unk3;
    u8 unk4;
    u8 unk5;
    u8 unk6;
    u8 unk7;
    u8 unk8;
    u8 unk9;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_B;
typedef struct PlayerUnk148_C {
    s16 unk0;
    u8 unk2;
    u8 unk3;
    u8 *tiles;
    u8 unk8;
    u8 unk9;
    u8 unkA;
    u8 unkB;
    s16 unkC;
} PlayerUnk148_C;
typedef struct PlayerUnk148_D {
    u8 unk0[0x8];
    u16 unk8;
    s16 someAnim0;
    Sprite s;
} PlayerUnk148_D;
typedef union PlayerUnk148 {
    PlayerUnk148_A a;
    PlayerUnk148_B b;
    PlayerUnk148_C c;
    PlayerUnk148_D d;
} PlayerUnk148;
struct Player {
    PlayerCallback callback;
               u32 moveState;
               u32 moveState2;
    u32 unkC;
               s32 qWorldX;
               s32 qWorldY;
    s16 qSpeedAirX;
    s16 qSpeedAirY;
    s16 qSpeedGround;
    u16 keyInput;
    u16 keyInput2;
    u16 unk22;
               s8 spriteOffsetX;
               s8 spriteOffsetY;
               u8 unk26;
               u8 layer;
    struct {
        u8 unk28;
        u8 unk29;
        u8 character : 4;
        u8 padding1 : 4;
        u8 partnerIndex : 2;
        u8 someIndex : 3;
        u8 someFlag0 : 1;
        u8 someFlag1 : 1;
        u8 boostIsActive : 1;
        u8 unk2C_01 : 1;
        u8 unk2C_02 : 1;
        u8 unk2C_04 : 1;
        u8 unk2C_08 : 1;
        u8 unk2C_10 : 1;
        u8 unk2C_20 : 1;
        u8 unk2C_40 : 1;
        u8 unk2C_80 : 1;
                   u8 unk2D_0 : 4;
                   u8 ringSpeedFactor : 4;
        u8 state0_subCount : 4;
        u8 state0_other : 3;
        u8 state0_subHighBit : 1;
        u8 state0_highValue : 8;
        s16 anim0;
        s16 anim1;
        u16 anim2;
        u16 state1;
    } charFlags;
    s32 qUnk38;
    s32 qUnk3C;
    s16 unk40;
    s16 unk42;
    s16 unk44;
    s16 Spindash_Velocity;
    s16 unk48;
    s16 framesInvulnerable;
    s16 framesInvincible;
    s16 unk4E;
    s16 boostEffectCounter;
    s16 idleAndCamCounter;
               s16 unk54;
    s8 unk56;
    s8 unk57;
    u8 unk58;
    u8 unk59;
    u8 unk5A;
    u8 unk5B;
    u8 unk5C;
    u8 unk5D;
    s16 unk5E;
    s16 unk60;
    s16 unk62;
    u16 unk64;
    s16 unk66;
    u8 unk68;
    u8 unk69;
    u8 filler6A[0x2];
               Sprite *sprColliding;
    s32 qUnk70;
    s32 qUnk74;
    s8 unk78[0x10];
    s32 unk88;
    s32 unk8C;
    s32 unk90;
    s32 unk94;
    u8 unk98;
    u8 unk99;
    u8 unk9A;
    u8 unk9B;
               s16 qCamOffsetX;
               s16 qCamOffsetY;
               s16 unkA0;
               s16 unkA2;
    u8 unkA4;
    u8 PaddingA5[0x3];
    u32 unkA8;
    u32 unkAC;
    u32 unkB0;
    u32 unkB4;
    u32 unkB8;
    u32 unkBC;
    u16 unkC0;
    u16 unkC2;
    struct Task *unkC4[0x03];
    struct Task *taskTagAction;
    struct Task *unkD4;
    struct Task *unkD8;
    struct Task *unkDC;
    PlayerSpriteInfo *spriteInfoBody;
    PlayerSpriteInfo *spriteInfoLimbs;
    Vec2_16 unkE8;
    u8 unkEC;
    s32 qUnkF0;
    u16 palette[16];
    Sprite sprShield;
    u8 unk13C;
    u8 unk13D;
    u16 *demoplayInput_Start;
    u16 *demoplayInput_Current;
    union {
        PlayerUnk148 *ptr;
        u8 arr_u8[4];
        s16 arr_s16[2];
    } unk148;
    union {
        u8 arr_u8[4];
        s16 arr_s16[2];
    } unk14C;
};
extern Player gPlayers[4];
typedef struct Struc_3001150 {
    u8 filler0[0x1C];
    u8 filler1C[0x4];
    u8 filler20[0x450];
} Struc_3001150;
Struc_3001150 gUnknown_03001150;
extern s16 sub_801480C(Player *p);
void Call__Player_8014550(Player *p);
bool32 sub_802C080(Player *p);
bool32 sub_802C0D4(Player *p);
typedef struct {
    u16 jump;
    u16 attack;
    u16 trick;
} ButtonConfig;
typedef struct {
    u8 jump;
    u8 attack;
    u8 trick;
} ButtonConfigPacked;
extern ButtonConfig gPlayerControls;
void SetPlayerControls(u16 jump, u16 attack, u16 trick);
enum eLanguage { JAPANESE = 0, ENGLISH = 1, GERMAN = 2, FRENCH = 3, SPANISH = 4, ITALIAN = 5, NUM_LANGUAGES };
typedef struct {
    u8 Act1 : 1;
    u8 Act2 : 1;
    u8 Act3 : 1;
    u8 Boss : 1;
    u8 BonusCapsule : 1;
    u8 BonusEnemies : 1;
    u8 Bit7 : 1;
} ZoneCompletion;
typedef struct {
    u8 Bronze : 1;
    u8 Silver : 1;
    u8 Gold : 1;
} MedalCollection;
typedef struct {
               u32 playerId;
               u16 playerName[6];
               bool8 slotFilled;
               u8 wins;
               u8 losses;
               u8 draws;
} VsRecords;
typedef struct {
               u8 slotFilled;
               u8 wins;
               u8 draws;
               u8 losses;
               u32 playerId;
               u16 playerName[6];
} VsRecords2;
typedef struct TimeRecord {
    u8 character1;
    u8 character2;
    u16 time;
} TimeRecord;
typedef struct TimeRecords {
    TimeRecord table[7][4][5];
} TimeRecords;
typedef struct {
               u32 playerId;
               u16 playerName[6];
               u8 unlockedCharacters;
               u8 unlockedZones;
               u8 continueZone;
               u8 unk13;
               u16 chaoCount[7];
               u8 specialKeys[7];
               u8 unlockedStages[9];
               u8 collectedEmeralds;
               u8 unlockFlags;
               u16 unk34;
               u8 unk36;
               u8 collectedMedals[9][4];
               u8 unk5B;
               u8 unk5C;
               u8 unk5D;
               u16 unk5E;
               u8 vsWins;
               u8 vsLosses;
               u8 vsDraws;
               u8 unk63;
               VsRecords vsRecords[10];
                TimeRecords timeRecords;
                ButtonConfig buttonConfig;
                u8 difficulty;
                bool8 disableTimeLimit;
                u8 language;
                u8 unk367;
} SaveGame;
extern SaveGame gLoadedSaveGame;
extern SaveGame gUnknown_03000980;
typedef struct SaveSectorHeader {
                u32 magicNumber;
                u32 sectorId;
} SaveSectorHeader;
typedef struct {
    SaveSectorHeader header;
                u32 playerId;
                u16 playerName[6];
                u8 unk18;
                u8 unlockedCharacters;
                u8 unlockedZones;
                u8 continueZone;
                u8 unk1C;
                u16 chaoCount[7];
                u8 specialKeys[7];
                u8 unlockedStages[9];
                u8 collectedEmeralds;
                u8 unlockFlags;
                u8 collectedMedals[9][4];
                u16 unk62;
                u8 vsWins;
                u8 vsDraws;
                u8 vsLosses;
    u8 unk67;
    VsRecords2 vsRecords[10];
                TimeRecords timeRecords;
                ButtonConfigPacked buttonConfig;
                u8 difficulty;
                bool8 disableTimeLimit;
                u8 language;
                u8 unk367;
                u32 checksum;
} SaveSectorData;
extern SaveSectorData gSaveSectorData;
void InsertMultiplayerProfile(u32 playerId, u16 *name);
void RecordOwnMultiplayerResult(s16 result);
void RecordMultiplayerResult(u32 id, u16 *name, s16 result);
void SaveInit(void);
bool16 SaveGameExists(void);
s16 NewSaveGame(void);
s16 LoadSaveGame(void);
void LoadCompletedSaveGame(void);
bool32 WriteSaveGame(void);
